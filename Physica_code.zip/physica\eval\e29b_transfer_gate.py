# Does a limit that accounts for coefficient uncertainty still catch wrong lessons?
import numpy as np, json
from collections import defaultdict
from physica.worldmodel.benchmark import random_machine
from physica.worldmodel.sim import rich_data
from physica.worldmodel.model import discover, verify
from physica.worldmodel.transfer import transfer
LAWS = ["quadratic drag", "cubic drag", "hardening spring", "coupled damping"]
OTHER = {"quadratic drag": ["cubic drag", "hardening spring", "none"], "cubic drag": ["quadratic drag", "coupled damping", "none"],
         "hardening spring": ["quadratic drag", "coupled damping", "none"], "coupled damping": ["hardening spring", "cubic drag", "none"]}
tally = defaultdict(lambda: defaultdict(int))
for law in LAWS:
    for s in range(5):
        rng = np.random.default_rng(7000 + s)
        source = random_machine(law, rng)
        src = discover(rich_data(source, s), rich_data(source, s + 100, 3), source.known(), neural_check=False, seed=s)
        verify(src, rich_data(source, s + 900, 3))
        if src.level != "VERIFIED":
            tally["source not verified"][law] += 1
            continue
        tgts = [("right", law)] + [("wrong", o) for o in OTHER[law]]
        for kind, tl in tgts:
            t_rng = np.random.default_rng(8000 + s)
            target = random_machine(tl, t_rng, scale=float(t_rng.uniform(.6, 1.4)))
            for n in (15, 30, 60):
                rows = target.episode(0.2, 0.5, 1.0, 1.0, 2.0, t_rng)[:n]
                sep = rich_data(target, s + 700, 3)
                t = transfer(src, rows, target.known(), sigma=target.sensor_noise, target_test=sep)
                key = f"{kind} n={n}"
                tally[key]["total"] += 1
                if t.status == "LESSON_REJECTED_BY_THIS_MACHINE":
                    tally[key]["rejected"] += 1
                    continue
                h = next(x for x in t.hypotheses if x.terms)
                x, v, u, a = sep.T
                r = a - (target.known()(x, v, u) + sum(c * src.library[k](x, v, u) for k, c in zip(h.terms, h.coef)))
                phi = np.column_stack([src.library[k](x, v, u) for k in h.terms])
                var = target.sensor_noise**2 + np.einsum("ij,jk,ik->i", phi, h.cov, phi)
                z = float(np.sqrt(np.mean(r**2 / var)))
                rm = float(np.sqrt(np.mean(r**2)))
                known = float(np.sqrt(np.mean((a - target.known()(x, v, u))**2)))
                tally[key]["fixed_pass"] += rm <= 1.3 * target.sensor_noise and rm < .95 * known
                tally[key]["pred_pass"] += z <= 1.3 and rm < .95 * known
                tally[key]["pred_half"] += z <= 1.3 and rm < .5 * known
for k in sorted(tally):
    print(k, dict(tally[k]))
