"""Optional live Muse scientific council for real industrial sensor residuals.

Only source-discovery recordings are sent. Blind-test machines, end-of-run
labels, known failures, and held-out evaluation scores are never sent as
hypothesis context. All outputs are UNVERIFIED and never authorize hardware.
"""
from __future__ import annotations
import json
from pathlib import Path
from .sentinel import DataEvidenceError
from physica.unified.meta import _schema, _parse


def source_context(report:dict)->dict:
    if report.get('schema')!='physica.maintenance.sentinel.v030':
        raise DataEvidenceError('Expected genuine Sentinel evaluation report')
    source=report.get('muse_discovery_source_only',[])
    if not source:raise DataEvidenceError('Need one separate discovery unit absent from blind test')
    source_ids={u['machine_id'] for u in source}
    if source_ids & set(report.get('heldout_test_machine_ids',[])):
        raise DataEvidenceError('Meta context is contaminated with blind test data')
    return {'task':'Explain changing physical behavior and choose a measurement, not predict a known answer.',
      'evidence_split':'SOURCE_DISCOVERY_ONLY_TEST_HIDDEN',
      'data_origin':report['data_origin'],
      'units':'RMS in source units, NOT independently physically calibrated',
      'sources':source[:2],
      'missing_sensors': ['independently calibrated motor-current and speed',
                           'ambient temperature and load', 'qualified bearing inspection'],
      'physical_hypotheses': 'UNVERIFIED; sensor artifacts and load changes are alternatives to wear',
      'safety':'advisory only; no automatic shutdown, startup or repair',
      'blind_test_data_included':False}


def run_council(report_path:str|Path, *,allow_billed_meta:bool=False)->dict:
    report=json.loads(Path(report_path).read_text(encoding='utf-8'))
    context=source_context(report)
    if not allow_billed_meta:
        return {'status':'PREVIEW_ONLY_NOT_META','context':context,
              'requires_explicit_billing_authorization':True,'blind_test_excluded':True}
    from physica.llm import meta_client as client
    if client.is_mock():
        return {'status':'META_NOT_CONFIGURED_ABSTAIN','reason':'MODEL_API_KEY and MOCK=0 required locally'}
    from physica.frontier.meta_council_v026 import _verified, _critic_schema
    tasks=[('wonder','sentinel030_scientist'),('spark','sentinel030_critic'),
           ('wonder','sentinel030_revise')]
    prompts=[
      'Physical-science hypothesis generator. Propose at most 3 falsifiable causes of the train-only vibration change. '
      'Do not confuse a vibration anomaly with a confirmed bearing fault. Consider unmeasured load, sensor placement, '
      'calibration, rotational speed and temperature as confounders. Recommend passive and qualified observations only. '
      'Do not claim prevented downtime, verified intervention, causal discovery or a certified remaining-life estimate.',
      'Adversarial scientific critic. Find observations and confounders that undermine each proposed explanation. '
      'Recommend independent validation and a discriminating sensor measurement. No machine control.',
      'Scientific revision. Revise the candidate hypotheses after criticism. Abstain if source evidence is insufficient. '
      'Do not assert that any explanation is confirmed. No machine control.'
    ]
    records=[]; current=context
    for i,((role,task),system) in enumerate(zip(tasks,prompts)):
        try:
            messages=[{'role':'system','content':system},
                      {'role':'user','content':json.dumps(current,sort_keys=True,allow_nan=False)}]
            if i==1:
                response_format=_critic_schema()
            else:
                response_format=_schema()
            reply=client.complete(role,messages,task,max_completion_tokens=16000,
                    response_format=response_format,require_fresh=True)
            proof=_verified(reply,expected_role=role,task=task)
            if i==1:
                content=json.loads(reply['content'])
                keys={'plausible_alternatives','possible_confounders','falsification_experiment',
                      'reason_to_doubt','revision_guidance'}
                if not isinstance(content,dict) or set(content)!=keys:
                    raise ValueError('Bad Muse critic reply')
            else:
                content=_parse(reply['content'])
            records.append({'role':role,'hypotheses_unverified':content,'receipt':proof})
            current={'source_train_only':context,'earlier_claims':[r['hypotheses_unverified'] for r in records]}
        except Exception as exc:
            # Never leak a provider exception that might contain raw HTTP request/credentials.
            return {'status':'META_SCIENTIST_ABSTAIN','successful_calls':len(records),
                'error_category':type(exc).__name__,'records':records,
                'blind_test_excluded':True, 'physical_discovery_verified':False,
                'no_hardware_actuation':True}
    return {'status':'META_HYPOTHESES_NOT_YET_VERIFIED','scientific_council':records,
        'blind_test_excluded':True,'physical_discovery_verified':False,
        'action':'Collect an independently calibrated, predeclared discriminating measurement',
        'no_hardware_actuation':True}
