( Physica plan, sealed promise 4dac731484064c65 )
G21 G90
G92 X84.500
G1 X79.800 F300
G4 P1.5
M2
