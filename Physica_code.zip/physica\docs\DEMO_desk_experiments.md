# Physica demo: three parts and a 3-minute video

No printer needed. Everything below runs on a laptop, a phone, a ruler, a few coins and some modelling clay.
Real-data parts work offline; Meta parts need `MOCK=0` and your `MODEL_API_KEY` in the terminal (never in the repo).

## Before you film (10 minutes)

```bash
pip install -e ".[dev,video,meta]"
python -m physica.cli verify                       # all PASS
export MOCK=0 MODEL_API_KEY=...                    # PowerShell: $env:MOCK="0"; $env:MODEL_API_KEY="..."
python -m physica.cli meta doctor                  # spark ok, wonder ok, sam ok -> receipts in meta_receipts/
python eval/e16_hidden_cause.py                    # needs PHYSICA_DROPBEAR2 / PHYSICA_DROPBEAR8 (DATA.md)
python -m physica.cli meta scientist               # E18 with live Muse Spark
python -m physica.cli meta evolve --swarm 4        # E19 with live Muse Wonder proposers (a few dollars at most)
python -m physica.studio --open-browser
```

Props: a 30 cm plastic or wooden ruler, a clamp (or a heavy book), a 5 g coin (US nickel), a pea-sized blob of
modelling clay, a kitchen scale (optional), a phone that films slow motion (240 fps), a friend.

---

## Part 1 · Proof it is accurate

1. **Real ground truth, on screen.** Studio front door. The hero chart is a real recording replaying: a hidden roller
   slides along a steel beam; Physica's line (from vibration only) follows the position sensor's line. Scroll to
   *Accurate*: 2.40 mm median vs 3.37 mm for the dataset authors' published method, nothing tuned to that beam, and error
   bars that covered the truth 96% of the time on data they were never calibrated on.
2. **Live, in front of you.** Clamp the ruler with ~30 cm overhang facing the webcam. *Feel it live* → Start camera →
   draw the box around the free end → flick. It shows the tone (a 30 cm plastic ruler is roughly 4–8 Hz), how long it
   rings, and when you touched it.
   *Independent check:* open a spectrum or accelerometer app on your phone (e.g. phyphox), lay the phone on the ruler,
   flick: same tone within a few percent.
3. **Cause, live.** Press *New reference*, flick twice. Tape the coin on and flick: "tone went DOWN … holding it is ruled
   out". Remove it, press a finger lightly halfway along and flick: "tone went UP … added mass and cracks are ruled
   out". That is the same physics that found the hidden support on the lab beam.
4. `python -m physica.cli verify` in a terminal: 12 claims pass in about 10 seconds.

## Part 2 · Genuine discovery, and teaching another machine

1. **Nobody told it there was a support.** *Discovers* section: the rival causes table. Mass, crack and temperature
   are each ruled out by a one-way physical law before anything is fitted; the beam rang at 1.2–2.2× its bare tone.
2. **The physics-rich video.** `python -m physica.cli sense guitar.mp4 --fps 600`: three separate strings and their
   tones from pixels alone. With your key, `python -m physica.cli meta sam guitar.mp4 --concept "guitar string" --sense`:
   SAM 3.1 finds the strings, Physica feels only those pixels.
3. **Teach a different machine** (two laptops on the same Wi-Fi, or two terminals):
   ```bash
   # laptop B
   python -m physica.studio --host 0.0.0.0 --port 8765
   # laptop A
   python -m physica.cli cause teach cards/explanation_dropbear_support.json --to http://LAPTOP-B-IP:8765
   ```
   B answers "accepted: signature intact". Edit one number in the card and send again: "REJECTED". Then show the
   *Teaches* section: beam B (longer, thicker, other accelerometer, no position sensor) tracks its hidden support with
   0 labels (r = 0.83); with 1–2 labels it beats learning from B's own labels; carrying A's raw curve fails.
4. **The broken promise.** Same section: Physica sealed a promise about B before reading B's truth, and it broke. Say
   it out loud: "the seal can't be edited, so when Physica is wrong, it's on record."
5. **Meta proposes, reality judges.** *Proposes & judges* section (after `meta evolve`): how many programs Muse wrote,
   the best one's score on the search half, on the unseen half, and on beam B, and the verdict. Open `meta_receipts/`
   to show these were live calls. Then *Discovers*: the loosening-clamp card shows Muse Spark's proposal accepted on
   data it never saw, and in the "two things at once" case every proposal rejected.

## Part 3 · More: an experiment Physica designs, the agent, the earlier senses

1. **A real active experiment at home (the best 40 seconds of the video).**
   - Flick the intact ruler in slow motion: `physica cause plan ... --bare-hz` uses it to calibrate (or run
     `python -m physica.cli sense intact.mp4 --fps 240` and read the first tone).
   - Turn around. Your friend either presses the clay blob under the ruler somewhere, **or** cuts a small notch with
     scissors (cheap plastic ruler). You don't know which, or where.
   - Film one slow-motion flick and run
     ```bash
     python -m physica.cli cause plan --length-mm 300 --width-mm 30 --thickness-mm 2 --material plastic \
        --bare-hz <intact tone> --video changed.mp4 --coin-g 5 --out promise.json
     ```
     Physica says what it believes (clay or notch, and where), which coin placement will settle it, and seals the tones
     it expects. Read the 16-character anchor out loud (or post it) so the time is witnessed.
   - Tape the coin where it says, film, `python -m physica.cli cause reveal promise.json --video after.mp4`:
     promise held or broken, and the updated belief. Your friend reveals the truth.
   Simulation says one chosen coin placement gets the cause right about as often as two random ones (E17); this is
   where you test that on a real ruler. Report it either way.
2. **Ask the agent.** *Meta inside* → Ask. With your key, Muse Wonder calls Physica's tools (evidence, find the cause,
   plan the experiment, seal) and answers with numbers that came from the tools.
3. **The earlier senses** in `/lab`: Feel Check on real drone flights (damage felt with no damage data; the skill
   carried to a different drone), the Body Bank, machine code with promises (ArduPilot, PLC, G-code).

---

## 3-minute video script

| Time | Show | Say |
|---|---|---|
| 0:00–0:15 | Studio hero chart replaying | "This line is a hidden support sliding along a steel beam, measured by a position sensor. This one is Physica, from vibration alone. Nobody told it the support exists." |
| 0:15–0:40 | Rival-causes table; accuracy tiles | "It ruled out mass, cracks and temperature with physics, because each can only move the tones one way. Then it located the support: 2.4 millimetres median, against 3.4 for the lab's own published method, with nothing tuned to that beam." |
| 0:40–1:05 | Webcam: flick, coin, finger | "It works on anything that vibrates. Coin on: tone down, so holding it is ruled out. Finger: tone up, so mass is ruled out." |
| 1:05–1:35 | Two laptops: teach, accepted, tampered → rejected; learning curve | "Physica doesn't copy numbers between machines; it sends a signed explanation. This beam is longer, thicker, with a different sensor and no position sensor, and it tracks its support from the first second." |
| 1:35–2:05 | Proposes & judges; `meta_receipts/`; loosening-clamp card | "This is the pattern behind this year's AI math results, like the Navier–Stokes claim: thousands of proposals, one strict judge. Mathematics has Lean. The physical world doesn't, so we built one. Muse writes new senses and new causes; Physica accepts only what holds up on a machine they never saw. This one was better on one beam and worse on the other, so it was rejected." |
| 2:05–2:45 | Ruler + clay/notch active experiment, sealed anchor, reveal | "My friend changed this ruler. Physica tells me where to put a coin to find out what, seals what it expects, and here's the reveal." |
| 2:45–3:00 | Why-it-matters section; the broken promise | "Thinking is getting cheap; checking against reality isn't. Physica feels why things change, proves it, and teaches it. And when it's wrong, like here, it's on record." |

Label on screen whenever a part is simulation, and whether Meta calls are live (the chip in the top right says so).
