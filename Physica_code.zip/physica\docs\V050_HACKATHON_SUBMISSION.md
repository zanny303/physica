# Physica v0.5 — Meta hackathon entry pack

## One sentence

**One machine learns a physical consequence through sound. Another machine can predict what it will see—before doing the experiment—and knows when the lesson does not apply.**

## The scientific problem and why Meta is essential

Physical AI is often trained to identify objects, classify sounds, or imitate actions. Physica's different question is whether a measured **intervention → mechanism → consequence** can be transported to an unfamiliar body and sensory apparatus with uncertainty and falsification.

Muse Spark is not an assistant on top of our dashboard. In a *live demo* it must identify relevant scene context and confounders that affect which physical hypotheses are plausible; SAM 3.1 must track the part whose independent calibration contributes measurable motion; Muse Wonder must propose distinct *testable* physical explanations and a constrained experiment. CIRTE evaluates whether the experiment separates those explanations and whether a transferable consequence follows. V-JEPA 2 can be an additional separately validated visual prior, NOT a fictitious force sensor.

**Essential ablation:** Run exactly the same held-out fixture/experiment with (a) no Meta context/geometry; (b) SAM only; (c) Muse proposed hypotheses; (d) full workflow. Lock evaluation protocol before calls, collect independent truth, and report correct/incorrect/abstained outcomes. Without a recorded live call and measured improvement, do not claim Meta improves accuracy.

## Three-minute demonstration script

**00:00–00:15.** Show Machine B. On screen, a cryptographic forecast is *already sealed*. “This machine has never seen this experiment, but another machine has.” **Use a REAL video only after verified evidence exists.** Until then clearly watermark **SIMULATED REHEARSAL**.

**00:15–00:40.** Machine A vibrates. Its microphone records pressure in pascals. A paired calibration relates pressure to physical vibration. Show an actual waveform and a physical state estimate with uncertainty.

**00:40–01:05.** Muse Spark interprets objects, mount, plausible confounders; SAM tracks the structural part, and independent calibration converts a track to displacement. If either signal is unavailable say so; replay is not live execution.

**01:05–01:30.** Muse Wonder proposes “added mass,” “loose mounting,” “operating-state change,” and which safe experiment distinguishes them. CIRTE refuses a destructive action and chooses the high-information supervised probe.

**01:30–01:55.** Show Physica Physical Experience Language. A's measured action/response is converted to a transferable, dimensionless causal hypothesis. B's physical properties and vision sensor operator reconstruct a predicted curve in **B's own sensor units**. Publish hash externally, perform real B experiment, reveal curve.

**01:55–02:20.** Change the mount or present shifted dynamics. Physica says **REFUSE** and explains the independent probe mismatch. This matters more than an always-confident prediction.

**02:20–02:42.** Let B's signed outcome create a candidate updated physical memory; use it to forecast C. Display an independent C result only if actually measured. Show physics-only / CRATE / nearest transfer / CIRTE errors with same sensor budget and true hardware measurements.

**02:42–03:00.** Close: “AI already knows many words. Physica is teaching machines a language for what physical experiments actually mean. One body can learn; another can use the lesson.”

## Submission checklist

- [ ] Real footage and true calibrated sensor reference on **three independent** fixtures if possible; two is better than a fictional third.
- [ ] Physically publish B/C prediction hashes before tests. Include raw time-stamped sensor CSVs and external proof of chronology.
- [ ] Capture genuine authenticated Spark, SAM, Wonder responses, model IDs, prompts, raw output hashes and API cost; never commit private API keys.
- [ ] Show positive and negative model predictions; include failed trials and compatibility refusals.
- [ ] Independent holdout for SAM calibration-vs-evaluation; pre-register equal-budget Meta-on/off ablation.
- [ ] Validate camera-to-meter scale, audio pressure response calibration and synchronization.
- [ ] Show reproducible offline software commands and selected test log, not a fictitious full-suite pass.
- [ ] No uncontrolled/damaging hardware actuation; all actions supervised and reversible.

**Submission deadline:** see official https://dev.meta.ai/events/global-hackathon for current authoritative deadline and eligibility. This repo cannot guarantee any ranking, prize or scientific discovery.
