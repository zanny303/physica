"""Simulation-only shifted-parameter audit of the *actual signed* forecast path."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .core import Body, Sense
from .v08_benchmark import produce_episode, rmse_camera
from .mechanism_transfer import discover_and_sign, make_target_probe_certificate
from .prospective_v08 import simulate_future, seal_future_sensations


def evaluate(seed=25):
    A=Body('stress_source_A',.12,22.,.13,.25,1.)
    B=Body('stress_target_B',.14,24.,.15,.28,1.)
    source=discover_and_sign(A,[produce_episode(A,f'train{i}',.22,.01,seed=seed+i,amplitude=.075+.018*i)
        for i in range(2)],[produce_episode(A,'heldout',.22,.01,seed=seed+11,amplitude=.095)],displacement_reference_m=.01)
    t=np.linspace(0,.35,71)
    force=.03*np.sin(t*13.)
    initial=(.003,.01)
    senses={'camera':Sense('camera','sight','mm',(1000.,0.),0.,.15,'stress_calibration')}
    rows=[]
    for beta in (.22,.26,.30,.35,.40,.45,.50,.65,.80):
        probe=produce_episode(B,f'probe_{beta}',beta,.01,seed=seed+175,amplitude=.025)
        cert=make_target_probe_certificate(source,B,probe,displacement_reference_m=.01)
        sealed=seal_future_sensations(source,B,senses,times_s=t,force_n=force,initial_state=initial,
               displacement_reference_m=.01,probe_certificate=cert,experiment_id=f'main_{beta}')
        row={'hidden_target_coefficient':beta,'probe_status':cert['status'],
             'signed_forecast_status':sealed['status'],'prediction_rmse_mm':None,'adaptation':None}
        if sealed['status']=='SEALED_FUTURE_SENSATIONS':
            # The target main response is generated AFTER the forecast is sealed.
            truth=simulate_future(B,t,force,initial,beta=beta,displacement_reference_m=.01)
            row['prediction_rmse_mm']=rmse_camera(np.asarray(sealed['payload']['predicted_state_m_m_s']),truth)
            row['adaptation']=sealed['payload']['adaptation']['status']
        rows.append(row)
    return {'origin':'SIMULATED_ONLY','meta_authenticated_calls':0,'real_hardware_trials':0,
            'not_field_validated':True,
            'notice':'Low-force probe may fail to reveal other kinds of unmodeled mechanisms; this tests a pre-specified coefficient shift only.',
            'rows':rows}


def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--seed',type=int,default=25)
    a=p.parse_args();r=evaluate(a.seed)
    dest=Path(a.out);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(r,indent=2)+'\n')
    print('SIMULATION ONLY:',[(x['hidden_target_coefficient'],x['adaptation'] or x['signed_forecast_status']) for x in r['rows']])

if __name__=='__main__':main()
