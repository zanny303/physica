"""From one film, with nothing typed. Muse watches and names the parts that matter, Muse points at them, SAM pins each one through the
film, and Physica reads the motion of only those pixels. Each step does what the others can't.

Muse never supplies a measured number here. It gets the film and decides where to look. Code does the measuring.
"""
from __future__ import annotations

import base64
import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np

from physica.llm import meta_client as mc
from physica.touch import video

SPARK = "spark"
FELT_SNR = 20.0
SMALLEST_PX = 0.002

_PARTS = {"title": "PhysicaScout", "type": "object", "additionalProperties": False, "required": ["machine", "seen", "parts", "possible_causes"], "properties": {
    "machine": {"type": "string"}, "seen": {"type": "string"},
    "parts": {"type": "array", "items": {"type": "object", "additionalProperties": False, "required": ["name", "why"], "properties": {"name": {"type": "string"}, "why": {"type": "string"}}}},
    "possible_causes": {"type": "array", "items": {"type": "string"}}}}
_POINTS = {"title": "PhysicaPoints", "type": "object", "additionalProperties": False, "required": ["points"], "properties": {"points": {"type": "array", "items": {
    "type": "object", "additionalProperties": False, "required": ["object_name", "x", "y"], "properties": {"object_name": {"type": "string"}, "x": {"type": "integer"}, "y": {"type": "integer"}}}}}}

WATCH = """You're looking at a phone film of a real machine, and you've never seen this one. Say what it is and what is moving. Name up to {most} physical parts \
worth measuring, most important first. Say why for each in one short sentence. List what could cause any problem you can see. Say plainly if you can't tell. Don't state any frequency or other number \
you didn't get from a tool. Part names must be short nouns a person could point at. {extra}Reply as JSON with machine, seen, parts (name, why), and possible_causes."""
POINT = """Point to each of these objects in the image: {names}. Coordinates are on a 0 to 1000 grid, with (0,0) at the top left, x going right and y going down. \
Choose a pixel squarely on the object. Reply as JSON: {{"points": [{{"object_name": "<name>", "x": <int>, "y": <int>}}]}}. Leave out anything you can't see."""
ASK_TONE = """Watch this film of a machine. What's the main vibration frequency of the {part}, in hertz? Give your best number, even if unsure. Reply as JSON: {{"hz": <number or null>, "why": "<one sentence>"}}."""


def parse_json(text: str | None) -> dict:
    """Muse's JSON, with any code fence around it removed."""
    if not text:
        raise ValueError("Muse gave no reply")
    t = text.strip()
    m = re.search(r"\{.*\}", t, re.S)
    if not m:
        raise ValueError("no JSON in Muse's reply")
    return json.loads(m.group(0))


def ffmpeg() -> str:
    found = shutil.which("ffmpeg")
    if found:
        return found
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception as e:
        raise RuntimeError("no video tool found. Run: python -m pip install imageio-ffmpeg") from e


def film_info(path: str | Path) -> dict:
    import cv2
    cap = cv2.VideoCapture(str(path))
    try:
        info = {"frames": int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), "fps": float(cap.get(cv2.CAP_PROP_FPS)), "w": int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), "h": int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))}
    finally:
        cap.release()
    if info["frames"] <= 0 or info["w"] <= 0:
        raise ValueError(f"can't read {path} as a video")
    return info


def _run(args: list[str]) -> None:
    r = subprocess.run([ffmpeg(), "-y", "-v", "error", *args], capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError("video conversion failed: " + r.stderr[-300:])


def muse_clip(src: str | Path, out: str | Path, seconds: float = 20.0, fps: int = 30, short: int = 480) -> Path:
    """What Muse watches: an ordinary H.264 mp4. Meta documents mp4, and advises clips longer than a few seconds at 448 pixels or more."""
    i = film_info(src)
    scale = f"scale=-2:{short}" if i["h"] <= i["w"] else f"scale={short}:-2"
    _run(["-i", str(src), "-t", f"{seconds:g}", "-vf", f"fps={fps},{scale},format=yuv420p", "-c:v", "libx264", "-preset", "veryfast", "-crf", "24", "-an", str(out)])
    return Path(out)


def sam_clip(src: str | Path, out: str | Path, most_frames: int = 120, long_side: int = 1280) -> dict:
    """What SAM tracks: every Kth frame, so a long slow-motion film costs cents. SAM frame i is film frame i*K."""
    i = film_info(src)
    every = max(int(np.ceil(i["frames"] / most_frames)), 1)
    k = min(long_side / max(i["w"], i["h"]), 1.0)
    w, h = int(round(i["w"] * k / 2) * 2), int(round(i["h"] * k / 2) * 2)
    args = ["-i", str(src), "-vf", f"select=not(mod(n\\,{every})),scale={w}:{h},format=yuv420p", "FRAMES", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-an", str(out)]
    try:      # newer video tools dropped the old flag, and older ones don't have the new one
        _run(sum((["-fps_mode", "passthrough"] if x == "FRAMES" else [x] for x in args), []))
    except RuntimeError:
        _run(sum((["-vsync", "0"] if x == "FRAMES" else [x] for x in args), []))
    got = film_info(out)
    return {"path": str(out), "every": every, "w": got["w"], "h": got["h"], "frames": got["frames"], "film_w": i["w"], "film_h": i["h"]}


def still(path: str | Path, frame: int = 0, longest: int = 1280) -> tuple[str, np.ndarray]:
    import cv2
    cap = cv2.VideoCapture(str(path))
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame)
    ok, f = cap.read()
    cap.release()
    if not ok:
        raise ValueError(f"can't read frame {frame} of {path}")
    k = longest / max(f.shape[:2])
    small = cv2.resize(f, None, fx=k, fy=k, interpolation=cv2.INTER_AREA) if k < 1 else f
    _, buf = cv2.imencode(".jpg", small, [int(cv2.IMWRITE_JPEG_QUALITY), 88])
    return "data:image/jpeg;base64," + base64.b64encode(buf.tobytes()).decode(), f


def watch(film: str | Path, role: str = SPARK, most: int = 5, extra: str = "", task: str = "physica_scout_watch") -> dict:
    """Muse watches the film and decides what's worth measuring."""
    with tempfile.TemporaryDirectory() as d:
        clip = muse_clip(film, Path(d) / "watch.mp4")
        part = mc.video_part(clip)
    r = mc.respond(role, [{"role": "user", "content": [{"type": "input_text", "text": WATCH.format(most=most, extra=extra)}, part]}], task, schema=_PARTS, media_usd=0.10, effort="medium")
    out = parse_json(r["content"])
    return {**out, "model": r["model"], "usd": r["usd"], "receipt": r["receipt_path"], "parts": [p for p in out.get("parts", []) if p.get("name")][:most]}


def point(image_url: str, names: list[str], role: str = SPARK, task: str = "physica_scout_point") -> dict[str, tuple[int, int]]:
    """Muse points on the still. Grid values are clamped, since Meta warns they can land slightly out of range."""
    quoted = ", ".join(f'"{n}"' for n in names)
    r = mc.respond(role, [{"role": "user", "content": [{"type": "input_text", "text": POINT.format(names=quoted)}, {"type": "input_image", "image_url": image_url}]}], task, schema=_POINTS, effort="medium")
    got = parse_json(r["content"]).get("points") or []
    return {str(p["object_name"]): (int(np.clip(p["x"], 0, 1000)), int(np.clip(p["y"], 0, 1000))) for p in got if "x" in p and "y" in p}


def point_prompt(points_px: dict[str, tuple[int, int]], w: int, h: int, frame: int = 0) -> tuple[str, dict[str, str]]:
    """SAM's own token grammar: up to 16 named objects in one request, so naming six parts costs the same as one."""
    if not points_px:
        raise ValueError("no points to send to SAM")
    ids = {str(i + 1): name for i, name in enumerate(list(points_px)[:16])}
    body = ",".join(f"{i}<|point;x={points_px[n][0]};y={points_px[n][1]};w={w};h={h}|>" for i, n in ids.items())
    return f"<{frame}f>{body}", ids


def parse_masks(text: str) -> dict[int, dict[str, dict]]:
    """Per frame and object: the box and its mask. Meta's parser reads the stream. A mask is local to its box, not the whole frame."""
    from meta_sam_parser import decode_mask_to_raster, video_segmentation_format
    from meta_sam_parser._types import CompletedOutcome
    parser = video_segmentation_format().create_parser()
    parser.push(text)
    frames: dict[int, dict[str, dict]] = {}
    for r in parser.finish(CompletedOutcome()).result.records:
        if getattr(r, "kind", "") != "mask" or r.frame is None:
            continue
        m = r.mask
        raster = np.frombuffer(decode_mask_to_raster(m), np.uint8).reshape(m.height, m.width).astype(bool)
        b = r.bounds
        frames.setdefault(r.frame.frame_index, {})[str(r.object_id)] = {"box": (int(b.left), int(b.top), int(b.right), int(b.bottom)), "mask": raster, "confidence": r.confidence}
    return frames


def full_mask(rec: dict, h: int, w: int) -> np.ndarray:
    out = np.zeros((h, w), bool)
    x1, y1, x2, y2 = rec["box"]
    m = rec["mask"]
    if (y2 - y1, x2 - x1) != m.shape:      # a box-local raster should match its box. If it doesn't, fit it rather than misplace it
        import cv2
        m = cv2.resize(m.astype(np.uint8), (max(x2 - x1, 1), max(y2 - y1, 1)), interpolation=cv2.INTER_NEAREST).astype(bool)
    ye, xe = min(y2, h), min(x2, w)
    if ye > y1 >= 0 and xe > x1 >= 0:
        out[y1:ye, x1:xe] = m[: ye - y1, : xe - x1]
    return out


def steady_mask(frames: dict[int, dict[str, dict]], obj: str, h: int, w: int) -> np.ndarray:
    """The pixels that belong to this part in at least half the frames that show it."""
    masks = [full_mask(f[obj], h, w) for f in frames.values() if obj in f]
    if not masks:
        return np.zeros((h, w), bool)
    return np.mean(masks, axis=0) >= 0.5


def load_region(film: str | Path, box: tuple[int, int, int, int] | None = None, most_frames: int = 1024, long_side: int = 192, skip: int = 0) -> tuple[np.ndarray, float]:
    """Only the pixels asked for, so a long slow-motion film doesn't have to fit in memory. Returns the frames and the scale applied."""
    import cv2
    cap = cv2.VideoCapture(str(film))
    frames, k = [], 1.0
    i = 0
    while len(frames) < most_frames:
        ok, f = cap.read()
        if not ok:
            break
        i += 1
        if i <= skip:
            continue
        if box is not None:
            x1, y1, x2, y2 = box
            f = f[max(y1, 0):y2, max(x1, 0):x2]
        g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
        k = min(long_side / max(g.shape), 1.0)
        if k < 1:
            g = cv2.resize(g, None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
        frames.append(g.astype(np.float32) / 255)
    cap.release()
    if len(frames) < 16:
        raise ValueError(f"not enough frames in {film}")
    return np.stack(frames), k


def _without_keyframes(Y: np.ndarray) -> np.ndarray:
    """Video compression re-draws the picture every so often, which looks like every pixel jumping at once. Those jumps would read as a false
    tone at the keyframe rhythm, so remove the frames where motion jumps far beyond its usual size, and keep everything else."""
    from scipy.ndimage import median_filter
    d = np.diff(Y, axis=0)
    size = np.median(np.abs(d), axis=1)
    usual = median_filter(size, size=11, mode="nearest")      # compared with the frames around it, since a real ring-down also shrinks over time
    jump = size > 6 * np.maximum(usual, 1e-9)
    d[jump] = 0
    out = np.concatenate([np.zeros((1, Y.shape[1]), Y.dtype), np.cumsum(d, axis=0)])
    return out - out.mean(0)


def read_tone(V: np.ndarray, fps: float, pixels: np.ndarray | None = None, lowest_hz: float = 2.0, most_pixels: int = 1500) -> dict:
    """The strongest steady tone in these pixels, reading motion both ways. SAM's mask only chooses which pixels count.
    A tone has to stand well clear of its neighbours in frequency and have real size. If nothing does, this says it couldn't feel anything."""
    from scipy.signal import welch
    best = None
    for direction in ("horizontal", "vertical"):
        M = video.motion(V, wavelength=6, sigma=2.5, step=2, keep=0.5, direction=direction)
        Y = M["signals"]
        if pixels is not None:
            keep = pixels[M["rows"], M["cols"]]
            if keep.sum() < 4:
                continue
            Y = Y[:, keep]
        if Y.shape[1] < 2:
            continue
        if Y.shape[1] > most_pixels:
            Y = Y[:, np.linspace(0, Y.shape[1] - 1, most_pixels).astype(int)]
        Y = _without_keyframes(Y.astype(np.float64))
        U, sv, _ = np.linalg.svd(Y, full_matrices=False)      # motion shared across pixels adds up, while noise doesn't
        C = U[:, :4] * sv[:4]
        f, P = welch(C, fs=fps, nperseg=min(len(C), 512), axis=0, detrend="linear")
        p = P.sum(1) / Y.shape[1]
        band = np.where((f >= max(lowest_hz, 4 * fps / len(C))) & (f <= 0.45 * fps))[0]
        if len(band) < 8:
            continue
        i = band[int(np.argmax(p[band] * f[band]))]       # slow drift is always largest, so favour peaks over the general slope
        around = np.r_[max(i - 12, band[0]):max(i - 2, band[0]), min(i + 3, band[-1]):min(i + 13, band[-1] + 1)]
        snr = float(p[i] / max(np.median(p[around]) if len(around) else np.median(p[band]), 1e-18))
        hz = float(f[i])
        if 0 < i < len(p) - 1:
            a, b, c = np.log(p[i - 1:i + 2] + 1e-30)
            hz += float(np.clip(0.5 * (a - c) / (a - 2 * b + c - 1e-12), -0.5, 0.5)) * float(f[1] - f[0])
        row = {"tone_hz": round(hz, 2), "snr": round(snr, 1), "direction": direction, "pixels": int(Y.shape[1]), "motion_px": round(float(np.sqrt(p[i] * (f[1] - f[0]))), 4)}
        clear = lambda r: r["snr"] >= FELT_SNR and r["motion_px"] >= SMALLEST_PX  # noqa: E731
        # Of two clear readings, trust the direction with the larger motion. Compression can leave a tiny, very clean copy in the other.
        if best is None or (clear(row), row["motion_px"]) > (clear(best), best["motion_px"]):
            best = row
    if best is None:
        return {"felt": False, "reason": "not enough textured pixels here to read motion"}
    best["felt"] = bool(best["snr"] >= FELT_SNR and best["motion_px"] >= SMALLEST_PX)
    if not best["felt"]:
        best["reason"] = "no tone stands clear of the noise here"
    return best


def _box_of(mask: np.ndarray, pad: float = 0.1) -> tuple[int, int, int, int] | None:
    ys, xs = np.where(mask)
    if not len(xs):
        return None
    w, h = xs.max() - xs.min() + 1, ys.max() - ys.min() + 1
    return (int(max(xs.min() - pad * w, 0)), int(max(ys.min() - pad * h, 0)), int(min(xs.max() + pad * w + 1, mask.shape[1])), int(min(ys.max() + pad * h + 1, mask.shape[0])))


class Film:
    """One film that Muse can ask about. Boxes and masks are kept in SAM clip pixels, and mapped to the film when read."""

    def __init__(self, path: str | Path, fps: float | None = None, workdir: str | Path | None = None):
        self.path, self.info = Path(path), film_info(path)
        self.fps = float(fps or self.info["fps"])
        self.work = Path(workdir or tempfile.mkdtemp(prefix="physica_scout_"))
        self.work.mkdir(parents=True, exist_ok=True)
        self.clip: dict | None = None
        self.parts: dict[str, dict] = {}
        self.frames: dict[int, dict[str, dict]] = {}
        self.ids: dict[str, str] = {}
        self.usd = 0.0
        self.calls: list[dict] = []

    def _clip(self) -> dict:
        if not self.clip:
            self.clip = sam_clip(self.path, self.work / f"{self.path.stem}_sam.mp4")
        return self.clip

    def _log(self, tool: str, **said) -> None:
        self.calls.append({"tool": tool, **said})

    def still(self, seconds: float | None = None) -> str:
        f = 0 if seconds is None else int(np.clip(seconds * self.fps, 0, self.info["frames"] - 1))
        return still(self.path, f)[0]

    def pin(self, points_grid: dict[str, tuple[int, int]]) -> dict[str, dict]:
        """Grid points from Muse become SAM's point prompts, with all parts in one request. Masks are kept."""
        c = self._clip()
        px = {n: (int(round(g[0] / 1000 * (c["w"] - 1))), int(round(g[1] / 1000 * (c["h"] - 1)))) for n, g in points_grid.items()}
        prompt, ids = point_prompt(px, c["w"], c["h"])
        r = mc.sam_text(c["path"], prompt, {"propagation_direction": "forward"}, c["frames"], "physica_scout_sam")
        self.usd += r["usd"]
        (self.work / f"{self.path.stem}_sam_{len(self.calls)}.txt").write_text(r["text"], encoding="utf-8")
        frames = parse_masks(r["text"])
        self.frames, self.ids = frames, ids
        out = {}
        for i, name in ids.items():
            mask = steady_mask(frames, i, c["h"], c["w"])
            seen = sum(1 for f in frames.values() if i in f)
            self.parts[name] = out[name] = {"mask": mask, "point_px": px[name], "frames_tracked": seen, "frames_sent": c["frames"], "area_pct": round(100 * float(mask.mean()), 2)}
        self._log("sam_points", parts=list(ids.values()), frames=c["frames"], usd=r["usd"])
        return out

    def mask_at(self, name: str, film_frame: int, shape_hw: tuple[int, int]) -> np.ndarray | None:
        """This part's mask at the nearest tracked moment, in the pixels of a loaded film. For parts that travel, like a print head."""
        import cv2
        i = next((k for k, n in self.ids.items() if n == name), None)
        shown = [f for f, recs in self.frames.items() if i in recs]
        if i is None or not shown:
            return None
        c = self._clip()
        near = min(shown, key=lambda f: abs(f * c["every"] - film_frame))
        m = full_mask(self.frames[near][i], c["h"], c["w"]).astype(np.uint8)
        return cv2.resize(m, (shape_hw[1], shape_hw[0]), interpolation=cv2.INTER_NEAREST).astype(bool)

    def pin_noun(self, noun: str) -> dict:
        """The way a person does it today: type a noun. Costs one SAM request per part."""
        c = self._clip()
        r = mc.sam_text(c["path"], noun, {"mask_encoding": "one_bit"}, c["frames"], "physica_scout_sam_noun")
        self.usd += r["usd"]
        frames = parse_masks(r["text"])
        ids = sorted({i for f in frames.values() for i in f}, key=lambda i: -sum(1 for f in frames.values() if i in f))
        mask = steady_mask(frames, ids[0], c["h"], c["w"]) if ids else np.zeros((c["h"], c["w"]), bool)
        self.parts[noun] = {"mask": mask, "frames_tracked": sum(1 for f in frames.values() if ids and ids[0] in f), "frames_sent": c["frames"], "area_pct": round(100 * float(mask.mean()), 2)}
        return self.parts[noun]

    def pixels_of(self, name: str, skip_frames: int = 0) -> tuple[np.ndarray, np.ndarray, tuple[int, int, int, int]] | None:
        """This part's frames and which of their pixels belong to it, from SAM's mask."""
        import cv2
        part = self.parts.get(name)
        if not part or not part["mask"].any():
            return None
        c = self._clip()
        sx, sy = c["film_w"] / c["w"], c["film_h"] / c["h"]
        cbox = _box_of(part["mask"])
        box = (int(cbox[0] * sx), int(cbox[1] * sy), int(np.ceil(cbox[2] * sx)), int(np.ceil(cbox[3] * sy)))
        V, _ = load_region(self.path, box, skip=skip_frames)
        crop = part["mask"][cbox[1]:cbox[3], cbox[0]:cbox[2]].astype(np.uint8)
        return V, cv2.resize(crop, (V.shape[2], V.shape[1]), interpolation=cv2.INTER_NEAREST).astype(bool), box

    def feel(self, name: str, skip_frames: int = 0) -> dict:
        """Physica reads this part's pixels."""
        part = self.parts.get(name)
        got_pixels = self.pixels_of(name, skip_frames)
        if got_pixels is None:
            return {"part": name, "felt": False, "reason": "SAM didn't find this part"}
        V, pixels, box = got_pixels
        got = {"part": name, **read_tone(V, self.fps, pixels), "box_in_film": box, "area_pct": part["area_pct"], "frames_tracked": part["frames_tracked"], "frames_sent": part["frames_sent"]}
        self._log("physica_feel", part=name, tone_hz=got.get("tone_hz"), felt=got["felt"])
        return got

    def mask_overlap(self, name: str, film_box: tuple[int, int, int, int]) -> float:
        """How much of this part's mask lies inside a box a person drew before the run."""
        part = self.parts.get(name)
        if not part or not part["mask"].any():
            return 0.0
        c = self._clip()
        sx, sy = c["film_w"] / c["w"], c["film_h"] / c["h"]
        x1, y1, x2, y2 = film_box
        m = part["mask"]
        inside = m[int(y1 / sy):int(np.ceil(y2 / sy)), int(x1 / sx):int(np.ceil(x2 / sx))].sum()
        return round(float(inside / m.sum()), 3)


COLOURS = [(193, 227, 79), (75, 184, 242), (136, 123, 255), (255, 157, 179), (120, 220, 255), (90, 200, 120)]


def overlay(F: "Film", frame: int = 0, longest: int = 960) -> str | None:
    """The first tracked frame, with each part's mask in its own colour."""
    import cv2
    if not F.frames:
        return None
    c = F._clip()
    near = min(F.frames, key=lambda f: abs(f - frame))
    cap = cv2.VideoCapture(c["path"])
    cap.set(cv2.CAP_PROP_POS_FRAMES, near)
    ok, img = cap.read()
    cap.release()
    if not ok:
        return None
    for j, (i, name) in enumerate(F.ids.items()):
        rec = F.frames[near].get(i)
        if not rec:
            continue
        m = full_mask(rec, c["h"], c["w"])
        col = np.array(COLOURS[j % len(COLOURS)], np.float32)
        img[m] = (0.45 * img[m] + 0.55 * col).astype(np.uint8)
        ys, xs = np.where(m)
        if len(xs):
            cv2.putText(img, name, (int(xs.min()), max(int(ys.min()) - 6, 14)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLOURS[j % len(COLOURS)], 1, cv2.LINE_AA)
    k = longest / max(img.shape[:2])
    if k < 1:
        img = cv2.resize(img, None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
    return "data:image/jpeg;base64," + base64.b64encode(cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 85])[1].tobytes()).decode()


def masks_film(F: "Film", out: str | Path, fps: int = 12) -> Path:
    """SAM following each part through the film, for the video. Only what SAM really returned."""
    import cv2
    c = F._clip()
    tmp = Path(out).with_suffix(".raw.mp4")
    vw = cv2.VideoWriter(str(tmp), cv2.VideoWriter_fourcc(*"mp4v"), fps, (c["w"], c["h"]))
    cap = cv2.VideoCapture(c["path"])
    i = 0
    while True:
        ok, img = cap.read()
        if not ok:
            break
        for j, (obj, name) in enumerate(F.ids.items()):
            rec = F.frames.get(i, {}).get(obj)
            if rec:
                m = full_mask(rec, c["h"], c["w"])
                col = np.array(COLOURS[j % len(COLOURS)], np.float32)
                img[m] = (0.5 * img[m] + 0.5 * col).astype(np.uint8)
                ys, xs = np.where(m)
                if len(xs):
                    cv2.putText(img, name, (int(xs.min()), max(int(ys.min()) - 6, 14)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, COLOURS[j % len(COLOURS)], 1, cv2.LINE_AA)
        vw.write(img)
        i += 1
    cap.release()
    vw.release()
    _run(["-i", str(tmp), "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", str(out)])
    tmp.unlink(missing_ok=True)
    return Path(out)


def scout(film: str | Path, fps: float | None = None, workdir: str | Path | None = None, role: str = SPARK, on_step=print, most: int = 5) -> dict:
    """The whole path from one film. Nothing typed. Each step is logged, so a viewer can see it, and a miss stays in the record."""
    F = Film(film, fps, workdir)
    seen = watch(film, role, most)
    on_step(f"Muse watched the film: {seen['machine']}. {seen['seen']}")
    for p in seen["parts"]:
        on_step(f"  Worth measuring: {p['name']}. {p['why']}")
    names = [p["name"] for p in seen["parts"]]
    grid = point(F.still(), names, role) if names else {}
    grid = {n: grid[n] for n in names if n in grid}
    on_step(f"Muse pointed at {len(grid)} of {len(names)} parts.")
    rows = []
    if grid:
        F.pin(grid)
        for n in grid:
            felt = F.feel(n)
            on_step(f"  {n}: " + (f"{felt['tone_hz']} Hz, clear of the noise by {felt['snr']:g} times" if felt["felt"] else f"can't tell. {felt.get('reason')}"))
            rows.append({**felt, "grid_point": list(grid[n]), "why": next(p["why"] for p in seen["parts"] if p["name"] == n)})
    picture = overlay(F) if grid else None
    if grid and workdir:
        try:
            masks_film(F, Path(workdir) / f"{Path(film).stem}_masks.mp4")
        except Exception as e:     # the numbers stand without the clip
            on_step(f"Couldn't make the masks clip: {str(e)[:100]}")
    return {"label": "MUSE LOOKS, SAM PINS, PHYSICA FEELS", "overlay": picture, "film": str(film), "fps": F.fps, "typed_words": 0, "machine": seen["machine"], "seen": seen["seen"], "possible_causes": seen.get("possible_causes", []),
            "parts": rows, "not_pointed": [n for n in names if n not in grid], "usd": round(seen["usd"] + F.usd, 4), "calls": F.calls, "model": seen["model"], "limit": "Pixel motion in one film, not a contact sensor"}
