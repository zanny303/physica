"""Muse as grounded scientific hypothesis *proposer*, not an arithmetic oracle.

Official Meta Model API auth remains private. A live request cannot prove an
experiment until paired held-out physical data validate the proposal. Incoming
model JSON is untrusted, no arbitrary Python code or hardware commands allowed.
"""
from __future__ import annotations
from dataclasses import asdict,replace
import hashlib,json,math
from pathlib import Path
from .signals import MechanicalContext
from .eig import CandidateAction,rank_eig
from .discovery import calibrated_meta_prior

ALLOWED_MECHANISMS={'added_mass','reduced_stiffness','increased_damping','sensor_bias'}


def new_hypothesis_from_muse(suggestion, reference:MechanicalContext, *,verified_parameter_calibration):
    """Accept a mechanism candidate only as a bounded, testable hypothesis.

    A numeric parameter is never trusted merely because the LLM supplied it.
    Requires independent calibration for parameter values / legal range.
    """
    if not isinstance(suggestion,dict):return {'status':'refused_unstructured_model_hypothesis'}
    family=suggestion.get('mechanism_family')
    if family not in ALLOWED_MECHANISMS:return {'status':'needs_human_mechanism_specification'}
    param=suggestion.get('parameter_source')
    if param!='independently_calibrated':return {'status':'refused_uncalibrated_model_parameter'}
    params=verified_parameter_calibration.get(family) if isinstance(verified_parameter_calibration,dict) else None
    if not isinstance(params,dict) or 'value' not in params or 'evidence_sha256' not in params:
        return {'status':'missing_independent_parameter_calibration'}
    v=params['value'];h=params['evidence_sha256']
    if (not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v) or v<=0
        or not isinstance(h,str) or len(h)!=64):
        return {'status':'invalid_parameter_calibration'}
    if family=='sensor_bias':
        return {'status':'test_sensor_calibration_first','mechanism':'sensor_bias',
                'requires_new_independent_sensor':True}
    if family=='added_mass':
        mass=reference.mass_kg+v;stiffness=reference.stiffness_n_m;damping=reference.damping_ratio
    elif family=='reduced_stiffness':
        if v>=1:return {'status':'out_of_physical_parameter_bounds'}
        mass=reference.mass_kg;stiffness=reference.stiffness_n_m*(1-v);damping=reference.damping_ratio
    else:
        if reference.damping_ratio+v>=1:return {'status':'out_of_physical_parameter_bounds'}
        mass=reference.mass_kg;stiffness=reference.stiffness_n_m;damping=reference.damping_ratio+v
    frequency=math.sqrt(stiffness/mass)/(2*math.pi)
    c=replace(reference,mass_kg=mass,stiffness_n_m=stiffness,
             fundamental_hz=frequency,damping_ratio=damping)
    return {'status':'new_testable_hypothesis_NOT_VERIFIED','mechanism':family,
            'physical_context':asdict(c),'parameter_evidence_hash':h,
            'meta_cannot_supply_measured_parameters':True,
            'required_next_step':'independent approved intervention plus preregistered predicted observable'}


def grounded_plan(spec,*,meta_reply=None,meta_calibration_counts=None,seed=50):
    """Compare identical action set with and without grounded Meta context.

    No retrospective optimization on the independent held-out response.
    Metamodel can suggest candidate labels, but priors only change if external
    held-out reliability stats authorize adjustment.
    """
    if 'observed_target_response' in spec or 'heldout_truth' in spec:
        raise ValueError('target response leakage into prospective planning')
    actions=[CandidateAction(**v) for v in spec['probes']]
    priors=spec['priors'];baseline=rank_eig(priors,actions,seed=seed)
    if not meta_reply:
        return {'mode':'no_meta', 'plan':baseline,'meta_benefit':'not_evaluated',
                'hardware_actuation_allowed':False}
    if not isinstance(meta_reply,dict):raise ValueError('Meta reply must be untrusted JSON object')
    hints=[]
    for v in meta_reply.get('hypotheses',[]):
        if isinstance(v,dict) and v.get('name') in priors and v['name'] not in hints:
            hints.append(v['name'])
    meta_prior=calibrated_meta_prior(priors,hints,calibration_counts=meta_calibration_counts)
    ranked=rank_eig(meta_prior['prior'],actions,seed=seed)
    recommended=meta_reply.get('suggested_action')
    if recommended not in {a.action_id for a in actions}:recommended=None
    return {'mode':'meta_context_proposed_plan',
            'meta_context_hypotheses_only':hints,
            'proposed_action_not_authorized':recommended,
            'meta_prior_status':meta_prior['status'],
            'no_meta_plan':baseline,'with_meta_plan':ranked,
            'meta_changed_ranked_action':baseline['chosen_action_id']!=ranked['chosen_action_id'],
            'meta_benefit':'NOT_DEMONSTRATED_UNTIL_HELDOUT_PHYSICAL_METRICS',
            'safety_authority':'numerical safe-policy only; no actuation',
            'hardware_actuation_allowed':False}


def live_grounded_plan(spec,*,video_path,allow_billing=False,meta_calibration_counts=None):
    if not allow_billing:raise PermissionError('live Meta calls require --allow-billed-meta')
    from .meta_context import live_muse_scientist
    allowed=[p['action_id'] for p in spec['probes']]
    facts={'experiment_request_sha256':hashlib.sha256(json.dumps(spec,sort_keys=True).encode()).hexdigest(),
           'known_physical_mechanisms':list(spec['priors']),
           'calibrated_scene_facts':spec.get('grounded_scene_facts',{}),
           'unknown_sensors':spec.get('unknown_sensors',[]),
           'all_suggestions_untrusted':True}
    spark=live_muse_scientist(facts,allowed,video_path=video_path,role='spark')
    wonder=live_muse_scientist({**facts,'spark_context':spark['reply']},allowed,
                               video_path=video_path,role='wonder')
    result=grounded_plan(spec,meta_reply=wonder['reply'],
                         meta_calibration_counts=meta_calibration_counts)
    result['actual_meta_responses']=[{'model_id':r['model_id'],'request_sha256':r['request_sha256'],
                                    'response_hash':hashlib.sha256(json.dumps(r['reply'],sort_keys=True).encode()).hexdigest()}
                                   for r in [spark,wonder]]
    result['authenticated_called']=True
    result['no_meta_hardware_performance_claim']=True
    return result
