"""E11: WHERE is the feeling coming from? Body-map attribution vs 'the loudest arm'.

The body map is learned from the first half of ONE healthy flight per drone (no damage data, no motor telemetry,
no drone model). It is then judged on every damaged flight.
  Bebop 2: band 95-200 Hz (Physica's standard band); felt windows and their line come from the E1 self-model.
  3DR Solo: band 80-130 Hz, i.e. 0.4-0.65x its main line: where Order Feel located the leftover on arrival (E9,
            no labels used). Every window after the first is judged (Solo damage is felt everywhere, E9).
The method was frozen before its first run on damage data. This is the first-run configuration.
"""
from __future__ import annotations

import numpy as np

from common import CFG, SINGLE, binom_ci, cluster_boot_ci, healthy_split, padre_features, save_result
from physica import config
from physica.data import padre, solo
from physica.feel.body_map import BodyMap
from physica.feel.selfmodel import OperatingPointSelfModel
from physica.library import cards


def summarise(rows: list[dict]) -> dict:
    groups = {}
    for r in rows:
        groups.setdefault(r["flight"], []).append(r)
    hit = [np.array([r["best_ok"] for r in g], float) for g in groups.values()]
    base = [np.array([r["loudest_ok"] for r in g], float) for g in groups.values()]
    k, n = int(sum(h.sum() for h in hit)), sum(len(h) for h in hit)
    kb = int(sum(b.sum() for b in base))
    named = [r for r in rows if len(r["answer"]) == 1]
    agree = [r for r in rows if r["best"] == r["loudest"]]
    per = {fl: {"truth": g[0]["truth"], "windows": len(g),
                "body_map_majority": max(set(r["best"] for r in g), key=[r["best"] for r in g].count),
                "body_map_acc": round(float(np.mean([r["best_ok"] for r in g])), 2),
                "loudest_arm_acc": round(float(np.mean([r["loudest_ok"] for r in g])), 2)} for fl, g in groups.items()}
    return {"windows": n, "body_map_acc": k / n, "body_map_ci95_exact": binom_ci(k, n),
            "body_map_ci95_cluster_by_flight": cluster_boot_ci(hit),
            "loudest_arm_acc": kb / n, "loudest_arm_ci95_exact": binom_ci(kb, n),
            "answer_contains_truth": float(np.mean([r["set_ok"] for r in rows])),
            "cues_agree": len(agree) / n, "acc_when_cues_agree": float(np.mean([r["best_ok"] for r in agree])) if agree else None,
            "acc_when_cues_agree_ci95_exact": binom_ci(int(sum(r["best_ok"] for r in agree)), len(agree)) if agree else None,
            "named_one_rotor": len(named) / n,
            "acc_when_named": float(np.mean([r["best_ok"] for r in named])) if named else None,
            "flights_majority_correct": f"{sum(v['body_map_majority'] in v['truth'] for v in per.values())}/{len(per)}",
            "per_flight": per}


def bebop() -> tuple[dict, BodyMap]:
    cal = healthy_split()["calib"]
    bm = BodyMap().fit(padre.load("0000").acc, padre.FS, (95.0, 200.0), windows_idx=cal)
    h = padre_features("0000")
    sm = OperatingPointSelfModel(unit_names=list("ABCD")).fit(h["op"][cal], h["lvl"][cal])
    thr = sm.calibrate_threshold(h["op"][cal], h["lvl"][cal], CFG.q, CFG.margin)
    rows = []
    for r in "ABCD":
        for c in SINGLE[r]:
            d = padre_features(c)
            z = sm.z(d["op"], d["lvl"])
            S = bm.stft(padre.load(c).acc, padre.FS)
            for i in range(min(len(S), len(z))):
                if z[i].max() <= thr:
                    continue
                loud = "ABCD"[int(z[i].argmax())]
                a = bm.attribute(S[i], float(d["op"][i, z[i].argmax()]))
                rows.append({"flight": c, "truth": [r], "best": a["best"], "answer": a["answer"],
                             "best_ok": a["best"] == r, "set_ok": r in a["answer"], "loudest_ok": loud == r,
                             "loudest": loud})
    return summarise(rows), bm


def solo_run() -> tuple[dict, BodyMap]:
    h = solo.load("0000")
    n = h.acc.shape[0] // int(5 * solo.FS)
    bm = BodyMap().fit(h.acc, solo.FS, (80.0, 130.0), windows_idx=range(n // 2))
    f = bm.freqs(solo.FS)
    rows = []
    for c in [x for x in solo.CODES if x != "0000"]:
        truth = solo.damaged_rotors(c)
        S = bm.stft(solo.load(c).acc, solo.FS)
        for i in range(1, len(S)):
            line = bm.strongest_line(S[i])
            k = int(np.argmin(np.abs(f - line)))
            P = (np.abs(S[i]) ** 2).mean(0)[k].reshape(4, -1).sum(-1)
            loud = "ABCD"[int(P.argmax())]
            a = bm.attribute(S[i], line)
            rows.append({"flight": c, "truth": truth, "best": a["best"], "answer": a["answer"],
                         "best_ok": a["best"] in truth, "set_ok": bool(set(a["answer"]) & set(truth)),
                         "loudest_ok": loud in truth, "loudest": loud})
    return summarise(rows), bm


def main():
    import shutil

    for c in cards.all_cards():
        if "body map" in c.get("tags", []):
            shutil.rmtree(config.CARDS_DIR / c["id"], ignore_errors=True)
    out = {}
    for name, fn, machine in (("bebop", bebop, "Parrot Bebop 2"), ("solo", solo_run, "3DR Solo")):
        res, bm = fn()
        res["fingerprint_overlap"] = bm.overlap().round(2).tolist()
        res["healthy_windows_used_per_rotor"] = bm.used
        out[name] = res
        print(f"{machine}: body map {res['body_map_acc']:.3f} {np.round(res['body_map_ci95_exact'], 3)} vs loudest arm "
              f"{res['loudest_arm_acc']:.3f} | flights {res['flights_majority_correct']} | named one rotor "
              f"{res['named_one_rotor']:.2f}, right when named {res['acc_when_named']} | cues agree "
              f"{res['cues_agree']:.2f}, right when they agree {res['acc_when_cues_agree']:.3f}")
        c = cards.new_card("sense", f"Body map of the {machine}: each rotor's vibration fingerprint across the frame, "
                           "learned from healthy flight only; attributes a felt line to the rotor it matches",
                           {"type": "quadcopter", "model": machine, "id": "padre-bebop2" if name == "bebop" else "padre-solo"},
                           units="|<pattern, fingerprint>|^2",
                           metrics={"attribution_acc": res["body_map_acc"], "loudest_arm_acc": res["loudest_arm_acc"],
                                    "fingerprint_overlap": res["fingerprint_overlap"]},
                           tags=["body map"])
        cards.save(c, model=bm.to_dict(), evidence={"E11.json": "see eval/results/E11_body_map.json"})
    save_result("E11_body_map", out)


if __name__ == "__main__":
    main()
