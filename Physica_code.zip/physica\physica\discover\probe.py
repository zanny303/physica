"""Probe (SPEC 4.3): choose the next recording/window that best separates surviving theories,
weighted by whether the answer could change the decision. Refuse tests that can't change it, and say
'can't tell' when the data available can't separate theories that disagree where it matters."""
from __future__ import annotations

import numpy as np


def next_test(preds: dict[str, np.ndarray], candidates: np.ndarray, decision_scale: float,
              already: set[int] | None = None) -> dict:
    """preds: theory name -> predictions at every candidate (same order). decision_scale: how big a prediction
    difference must be to change a decision (e.g. sigma * threshold)."""
    P = np.vstack(list(preds.values()))
    spread = P.max(axis=0) - P.min(axis=0)
    value = spread / max(decision_scale, 1e-12)
    if already:
        value[list(already)] = -np.inf
    i = int(np.argmax(value))
    if value[i] < 1.0:
        return {"action": "refuse", "text": "I won't run another test: every surviving theory gives the same decision "
                                            "on everything I could test.", "max_value": float(value[i])}
    return {"action": "test", "index": i, "candidate": float(candidates[i]), "value": float(value[i])}


def cant_tell(preds_in_range: dict[str, np.ndarray], preds_outside: dict[str, np.ndarray], decision_scale: float,
              experiment: str) -> dict | None:
    """Theories agree on the data we have but disagree where the decision lives -> ask for the experiment."""
    a = np.vstack(list(preds_in_range.values()))
    b = np.vstack(list(preds_outside.values()))
    agree_in = float((a.max(0) - a.min(0)).max()) < decision_scale
    disagree_out = float((b.max(0) - b.min(0)).max()) >= decision_scale
    if agree_in and disagree_out:
        return {"verdict": "can't tell", "text": f"The data I have can't separate these theories, and they disagree "
                                                 f"where it matters. Needed: {experiment}."}
    return None
