# Physica: Giving AI the ability to feel — submission film, 3 minutes

**What the film must show is an intended shooting script, NOT recorded results. Never label synthetic demos as real measurements.**

**0:00–0:15** Open with a sealed prediction over Machine B. “Today AI recognizes the world. Physica is designed to predict what interacting with the world will *feel* like.”

**0:15–0:50** Machine A: camera/microphone/strain sensor, a force measurement and distinct actions. Show action-conditioned expected sensations, actual measurements, and the physical innovation. Before/after baseline; expose an unexpected mechanism.

**0:50–1:20** Meta Spark examines the fixture and confounders. SAM tracks a moving part and stationary reference, yielding calibrated camera evidence. Wonder proposes a falsifiable contact mechanism and alternative. Show both Meta-on and Meta-off results from actual saved inference. If live calls unavailable, label “integration preview, no authenticated model calls.”

**1:20–1:50** The intervention selector asks which safe test both diagnoses A and creates knowledge that B can reuse. Seal its prediction before the action; film the actual action only with appropriate supervision, then independently measure and reveal whether the forecast worked.

**1:50–2:15** A's signed physical experience teaches B a normalized consequence. B has a different body and another sensor. A predeclared low-force target probe checks compatibility, and B's sealed prediction is measured. Switch the boundary condition: show a *refusal*.

**2:15–2:40** Use the retained Physica Discover real-video holdout challenge and Physica Lens home video workflow. State their evidence limits. If only simulation was completed, use a visible, persistent **SIMULATION ONLY** overlay.

**2:40–3:00** Chart genuine same-budget baselines: physics-only, local system ID, CIRTE transfer, CIRTE+Meta (only if authenticated outputs and an independent evaluation exist). “Machines don't have to experience every failure to learn what an interaction means. Physica aims to make their physical lessons testable and shareable.”

No unmeasured percentage, inference, scene, or physical outcome should appear as achieved. Finish with a QR link to the source and independent evidence. Do not claim that subjective consciousness or general five-sense autonomy has been achieved.
