"""One complete candidate: different sensory configurations, learn, predict, reveal.

Sealed prediction / reveal are separate functions so the forecast cannot read
future outcome. SHA-256 here is integrity only, NOT trusted external chronology.
No hardware actuation or guaranteed physical performance.
"""
import argparse,json
from pathlib import Path
import numpy as np
from physica.causal_memory.core import Sensor,decode,sense,features,hash_json,prospective
from .transfer import build_source_prior,adapt,predict_future,SourcePrior
from .benchmark import BASE

SOURCE_SENSORS=(Sensor('A_acoustic_proxy',.08,1.,.01),Sensor('A_contact_proxy',1.,.25,.01))
TARGET_SENSORS=(Sensor('B_camera_proxy',1.,0.,.01),Sensor('B_inertial_proxy',.1,1.,.01))

def _calibrated_row(rng,coef,body,sensors):
    physical=np.array([rng.uniform(-.65,.65),rng.uniform(-.45,.45)])
    action=float(rng.uniform(-.8,.8))
    observed={s.name: sense(physical,[s])[s.name]+rng.normal(0,s.noise_sd) for s in sensors}
    inferred=decode(observed,sensors)
    acceleration=float(features(physical,action)@coef+rng.normal(0,.02))
    return {'body_id':body,'intervention_type':'controlled','state':inferred.tolist(),
            'action':action,'acceleration':acceleration, 'observations':observed,
            'calibration_origin':'SIMULATED_KNOWN_SENSOR_OPERATORS'}

def prepare_experience(prior,target_local,target_probe,initial_observations,planned_actions,dt=.02,
                       target_sensors=TARGET_SENSORS):
    if not isinstance(initial_observations,dict):raise ValueError('initial calibrated sensing required')
    start=decode(initial_observations,target_sensors)
    adaptation=adapt(prior,target_local,target_probe,noise_sd=.025)
    if adaptation['choice']=='probe_first_model_mismatch':
        return {'status':'REFUSE_UNMODELLED_DYNAMICS','reason':'probe failed',
                'no_prediction_released':True}
    projected=predict_future(adaptation,start,planned_actions,dt,target_sensors)
    decision={'schema':'physica.research_v09.forecast.v1',
        'origin':'SIMULATED_EXAMPLE_ONLY','status':'FORECAST_COMMITTED_NOT_REVEALED',
        'source_experiments':prior.source_observations,'target_experiments':len(target_local)+len(target_probe),
        'action_plan':list(planned_actions),'dt_seconds':dt,
        'target_sensor_calibration':[s.__dict__ for s in target_sensors],
        'initial_senses':initial_observations,
        'adaptation':adaptation,'prediction':projected,
        'limitations':['source and target share a 2-dimensional calibrated physics state',
                       'the proposed action is not performed automatically',
                       'SHA-256 is an integrity check, not trusted chronological proof']}
    digest=hash_json(decision)
    return {'forecast':decision,'sha256_commitment':digest}

def reveal_experience(bundle,measured_future):
    doc=bundle.get('forecast')
    if not isinstance(doc,dict) or hash_json(doc)!=bundle.get('sha256_commitment'):
        raise ValueError('tampered forecast')
    if doc.get('status')!='FORECAST_COMMITTED_NOT_REVEALED':raise ValueError('wrong forecast status')
    predicted=doc['prediction']; names=[s['name'] for s in doc['target_sensor_calibration']]
    if len(measured_future)!=len(predicted):raise ValueError('mismatched future sample count')
    p=np.asarray([[frame['senses'][name] for name in names] for frame in predicted],float)
    y=np.asarray([[frame[name] for name in names] for frame in measured_future],float)
    if not np.isfinite(y).all():raise ValueError('invalid real/recorded future')
    return {'status':'REVEALED','origin':doc['origin'],'forecast_sha256':bundle['sha256_commitment'],
            'future_sensation_rmse':float(np.sqrt(np.mean((p-y)**2))),
            'per_sense_rmse':{name:float(np.sqrt(np.mean((p[:,i]-y[:,i])**2))) for i,name in enumerate(names)},
            'measurement_count':len(measured_future),
            'meaning':'Prediction comparison only; not proof of general causal identification'}

def synthetic_demo(seed=912):
    rng=np.random.default_rng(seed)
    population={}
    for j in range(10):
        coef=BASE+rng.normal(0,[.005,.005,.005,.12,.01],5)
        population[f'A{j}']=[_calibrated_row(rng,coef,f'A{j}',SOURCE_SENSORS) for _ in range(60)]
    prior=build_source_prior(population,noise_sd=.025)
    target_coef=BASE+rng.normal(0,[.005,.005,.005,.15,.01],5)
    local=[_calibrated_row(rng,target_coef,'B',TARGET_SENSORS) for _ in range(10)]
    probe=[_calibrated_row(rng,target_coef,'B',TARGET_SENSORS) for _ in range(10)]
    state=np.array([.15,-.05]);initial_observed=sense(state,TARGET_SENSORS)
    actions=(.2*np.sin(np.arange(60)*.2)).tolist()
    prepared=prepare_experience(prior,local,probe,initial_observed,actions,target_sensors=TARGET_SENSORS)
    if prepared.get('status')=='REFUSE_UNMODELLED_DYNAMICS':return {'origin':'SIMULATED','status':'REFUSED','decision':prepared}
    true_frames=prospective(state,actions,.02,target_coef,TARGET_SENSORS)
    hidden_actual=[frame['senses'] for frame in true_frames]
    verified=reveal_experience(prepared,hidden_actual)
    baseline=prospective(state,actions,.02,prepared['forecast']['adaptation']['local_coefficients'],TARGET_SENSORS)
    local_err=float(np.sqrt(np.mean((np.asarray([[f['senses'][k] for k in hidden_actual[0]] for f in baseline])-np.asarray([[f[k] for k in hidden_actual[0]] for f in hidden_actual]))**2)))
    return {'origin':'SIMULATED','status':'REVEALED',
            'source_senses':[x.name for x in SOURCE_SENSORS],
            'target_senses':[x.name for x in TARGET_SENSORS],
            'commitment':prepared['sha256_commitment'],
            'forecast':prepared['forecast'],'reveal':verified,
            'target_only_future_sense_rmse':local_err,
            'known_limitation':'Calibration/physics family and intervention actions are supplied by simulator; not real world sensing'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--seed',type=int,default=912)
    a=p.parse_args();r=synthetic_demo(a.seed);out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='forecast'},indent=2))
if __name__=='__main__':main()
