"""Transparent synthetic CSG benchmark: different sensors, different bodies.

Generates target outcomes ONLY AFTER signed forecast stage, but the same
program controls simulator and signatures: not an independently witnessed study.
No data here came from real hardware or live Meta API.
"""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import copy,hashlib,json,math
import numpy as np
from scipy.interpolate import CubicSpline
from physica.experience.causal_transport import twin_response,fit_memory,trace
from physica.experience.transport import BodyCalibration
from physica.library import sign as signer
from .signals import Channel,MechanicalContext
from .fusion import infer_state,rank_hypotheses,physical_tokens
from .language import experience_record,translate,verify_record
from .meta_context import curate_context_reply,fuse_context_and_physics


def cal(body,freq,k,force=.35,z=.06,boundary='clamped_strip'):
    return MechanicalContext(body_id=body,boundary_class=boundary,
        mass_kg=k/(2*math.pi*freq)**2,fundamental_hz=freq,
        damping_ratio=z,stiffness_n_m=k,applied_force_n=force,
        action_family='reversible_step_force',calibration_id='independent_synthetic_'+body,
        provenance='simulation')


def body_cal(c):
    return BodyCalibration(machine_id=c.body_id,boundary_class=c.boundary_class,
        action_class=c.action_family,fundamental_hz=c.fundamental_hz,
        stiffness_n_per_m=c.stiffness_n_m,applied_step_force_n=c.applied_force_n,
        mode_ratios=(1.,),damping_ratios=(c.damping_ratio,),
        calibration_id=c.calibration_id,verified_sensor=True)


def time_grid(c,num=160):return np.linspace(0,2.,num)/c.fundamental_hz


def outcome_truth(ctx,t,*,hidden_amplitude=.06,shifted_dynamics=False):
    """Transparent oscillator with shared or shifted unmodelled compliance."""
    tau=t*ctx.fundamental_hz
    base=twin_response(t,body_cal(ctx))
    if shifted_dynamics:
        r=hidden_amplitude*(1-np.exp(-4*tau))*np.sin(17*tau)*np.exp(-.25*tau)
    else:
        r=hidden_amplitude*(1-np.exp(-6*tau))*np.sin(9*tau)*np.exp(-1.1*tau)
    return base+ctx.applied_force_n/ctx.stiffness_n_m*r


def make_channel(ctx,t,y,observable,modality,sigma,rng,sensor_id):
    # Independent generated sensor data is *converted* to canonical SI, as a
    # real sensor requires an independently calibrated raw->SI conversion.
    cs=CubicSpline(t,y,bc_type='natural')
    vals={'displacement':y,'velocity':cs(t,1),'acceleration':cs(t,2)}[observable]
    values=vals+rng.normal(0,sigma,len(t))
    units={'displacement':'m','velocity':'m/s','acceleration':'m/s^2'}
    raw_unit='pixel' if modality=='vision' else ('Pa' if modality=='hearing' else 'm/s^2')
    gain=1/0.0001 if modality=='vision' else (14. if modality=='hearing' else 1.)
    digest=hashlib.sha256(np.asarray(values,dtype='<f8').tobytes()).hexdigest()
    return Channel(sensor_id=sensor_id,modality=modality,observable=observable,
        time_s=tuple(t),values=tuple(values),unit=units[observable],sigma=sigma,
        calibration_id='independent_sim_'+sensor_id,body_id=ctx.body_id,
        raw_unit=raw_unit,conversion_gain=gain,origin='simulation',source_sha256=digest)


def synthetic_observations(ctx,rng,*,modalities=('hearing','proprioception'),amp=.06,shift=False):
    t=time_grid(ctx);y=outcome_truth(ctx,t,hidden_amplitude=amp,shifted_dynamics=shift)
    choices={'hearing':('velocity',.00035),
             'proprioception':('acceleration',.022),
             'vision':('displacement',.000055),
             'touch':('displacement',.000075)}
    channels=[make_channel(ctx,t,y,choices[mod][0],mod,choices[mod][1],rng,mod+'_'+ctx.body_id)
              for mod in modalities]
    return t,y,channels


def _signature(record):
    raw=signer.canonical(record);digest=hashlib.sha256(raw).hexdigest()
    return {'prediction':record,'sha256':digest,
            'signature_ed25519':signer.sign({'prediction':record,'sha256':digest}),
            'provenance':'simulation','no_independent_witness':True}


def _verify_signature(record):
    try:
        p=record['prediction'];h=hashlib.sha256(signer.canonical(p)).hexdigest()
        return h==record['sha256'] and signer.verify({'prediction':p,'sha256':h},record['signature_ed25519'])
    except (KeyError,ValueError,TypeError):return False


def _strip_numpy(result):return {k:v for k,v in result.items() if k not in ('state',)}


def _train_token(ctx,t,sensors,*,cause='external_mount_compliance'):
    estimate=infer_state(sensors,ctx)
    token=physical_tokens(ctx,estimate,cause=cause,action_id='supervised_low_force_step',
                          source_sha256s=[c.source_sha256 for c in sensors],
                          provenance='simulation',checked_outcome=True)
    return experience_record(token),estimate


def _rmse(a,b):
    a=np.asarray(a);b=np.asarray(b)
    return float(np.sqrt(np.mean((a-b)**2)))


def one_trial(seed=31,*,shift=False):
    rng=np.random.default_rng(seed)
    A=cal('A',4.1,125.,z=.060)
    B=cal('B',5.3,180.,z=.061)
    C=cal('C',3.8,105.,z=.059)
    ta,ya,ca=synthetic_observations(A,rng,amp=.062)
    envelope,estimated_a=_train_token(A,ta,ca)
    tb=time_grid(B)
    predicted_b=translate(envelope,B,tb,target_modality='vision',target_observable='displacement')
    if predicted_b['status']!='unverified_cross_sensory_forecast':
        raise RuntimeError('A->B translation refused: '+predicted_b['reason'])
    # Commit BEFORE synthesizing/evaluating target B observation.
    seal_b=_signature({'source_A_sha256':envelope['word_sha256'],
                        'target_B_calibration':asdict(B),
                        'time_s':predicted_b['time_s'],
                        'predicted_values':predicted_b['predicted_values'],
                        'unit':'m','status':'UNVERIFIED_SIMULATION_PREDICTION'})
    # This is generated afterwards in code, not independent physical timing.
    tb,yb,cb=synthetic_observations(B,rng,modalities=('vision',),amp=.084,shift=shift)
    measured_b=np.asarray(cb[0].values)
    err_b=_rmse(predicted_b['predicted_values'],measured_b)
    # B's local response is now a verified simulated observation; publish as
    # *another* experience with its own original sensor evidence hash.
    env_b,estimated_b=_train_token(B,tb,cb)
    tc=time_grid(C)
    pred_a_to_c=translate(envelope,C,tc,target_modality='vision',target_observable='displacement')
    pred_b_to_c=translate(env_b,C,tc,target_modality='vision',target_observable='displacement')
    mem=fit_memory([trace(body_cal(A),ta,estimated_a['displacement_m']),
                    trace(body_cal(B),tb,estimated_b['displacement_m'])])
    pred_c=mem.forecast(body_cal(C),tc)
    pred_c_via_crate=np.asarray(pred_c['displacement_m'])
    source_a=np.asarray(pred_a_to_c['predicted_values'])
    source_b=np.asarray(pred_b_to_c['predicted_values'])
    baseline=twin_response(tc,body_cal(C))
    seal_c=_signature({'source_A_sha256':envelope['word_sha256'],
                       'source_B_sha256':env_b['word_sha256'],
                       'target_C_calibration':asdict(C),
                       'predicted_values':pred_c_via_crate.tolist(),
                       'time_s':tc.tolist(),'unit':'m',
                       'status':'UNVERIFIED_SIMULATION_PREDICTION'})
    _,yc,cc=synthetic_observations(C,rng,modalities=('vision',),amp=.090,shift=shift)
    measured_c=np.asarray(cc[0].values)
    ablations={}
    for label,selected in [('hearing_only',[ca[0]]),('acceleration_only',[ca[1]]),('both_modalities',ca)]:
        estimate=infer_state(selected,A)
        ablations[label]={'state_estimation_rmse_m':_rmse(estimate['displacement_m'],ya),
                          'log_likelihood_conditional_not_cross_comparable':estimate['log_likelihood']}
    if not _verify_signature(seal_b) or not _verify_signature(seal_c):
        raise RuntimeError('synthetic record integrity failed')
    # Demonstrate refusal for wrong mounting and forbidden chemistry translation.
    incompatible=cal('D',4.1,125.,boundary='free_free')
    refused=translate(envelope,incompatible,tc,target_modality='vision',target_observable='displacement')
    chemistry_refusal=translate(envelope,C,tc,target_modality='smell',target_observable='gas_concentration')
    return {'seed':seed,'provenance':'SIMULATION_ONLY','B_forecast_error_m':err_b,
        'C_results_rmse_m':{'physics_only':_rmse(baseline,measured_c),
                            'A_only_sensor_transfer':_rmse(source_a,measured_c),
                            'B_nearest_source':_rmse(source_b,measured_c),
                            'A_B_CRATE_memory':_rmse(pred_c_via_crate,measured_c)},
        'A_sensory_ablation':ablations,
        'incompatible_body':refused['status'],'chemical_translation':chemistry_refusal['status'],
        'A_to_B_sensor_translation':{'source_modalities':['hearing','proprioception'],
                                    'target_modality':'vision',
                                    'B_prediction_signed_before_simulated_B_measurement':True},
        'learning_protocol':'A source -> B signed forecast -> B simulated observation -> C signed forecast -> C simulated observation',
        'envelope_A':envelope,'envelope_B':env_b,
        'seals':{'B':seal_b,'C':seal_c},
        'curves':{'tau':(tc*C.fundamental_hz).tolist(),
                  'C_physics_m':baseline.tolist(),
                  'C_from_A_m':source_a.tolist(),
                  'C_from_B_m':source_b.tolist(),
                  'C_from_AB_m':pred_c_via_crate.tolist(),
                  'C_observation_m':measured_c.tolist()},
        'limitations':['one synthetic oscillator family','independently supplied target mass/stiffness/frequency',
                       'none of the simulated cameras/microphones are real',
                       'no Meta API calls or real SAM inference',
                       'signed by local key; not externally witnessed chronology']}


def benchmark(seed=31,n=24):
    if not 3<=n<=100:raise ValueError('benchmark size 3..100')
    runs=[one_trial(seed+i) for i in range(n)]
    labels=list(runs[0]['C_results_rmse_m'])
    mean={k:float(np.mean([r['C_results_rmse_m'][k] for r in runs])) for k in labels}
    median={k:float(np.median([r['C_results_rmse_m'][k] for r in runs])) for k in labels}
    ablation={k:float(np.mean([r['A_sensory_ablation'][k]['state_estimation_rmse_m'] for r in runs]))
              for k in runs[0]['A_sensory_ablation']}
    # OOD: same nominal calibrations, changed hidden residual dynamics. Must not
    # imply a valid 90% interval on shifted targets; test drift/generalization.
    shifted=[one_trial(seed+300+i,shift=True) for i in range(max(6,n//3))]
    shifted_mean={k:float(np.mean([r['C_results_rmse_m'][k] for r in shifted])) for k in labels}
    return {'benchmark':'physica.csg.v042.synthetics','seed':seed,'n_source_like':n,
            'n_hidden_dynamics_shift':len(shifted),'unit':'m','means_rmse_m':mean,
            'medians_rmse_m':median,'means_shifted_rmse_m':shifted_mean,
            'source_A_state_ablation_rmse_m':ablation,
            'ablation_warning':'comparing model evidence between different sensor sets is invalid; compare state estimation errors',
            'honest_limitations':['simulation only','narrow shared oscillator family',
                  'not held-out real Meta/SAM/V-JEPA evaluation','not a physical scientific breakthrough',
                  'source and target calibration known','no validated coverage under shift'],
            'no_guaranteed_winner':True}


def showcase(out_dir,*,seed=31,n=12):
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    one=one_trial(seed);score=benchmark(seed,n)
    (out/'benchmark.json').write_text(json.dumps(score,indent=2,sort_keys=True)+'\n')
    (out/'pel_A.json').write_text(json.dumps(one['envelope_A'],indent=2)+'\n')
    (out/'pel_B.json').write_text(json.dumps(one['envelope_B'],indent=2)+'\n')
    (out/'signed_B_prediction.json').write_text(json.dumps(one['seals']['B'],indent=2)+'\n')
    (out/'signed_C_prediction.json').write_text(json.dumps(one['seals']['C'],indent=2)+'\n')
    (out/'trace.json').write_text(json.dumps({k:v for k,v in one.items() if k not in ('envelope_A','envelope_B','seals')},indent=2)+'\n')
    html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Physica CSG Lab • SYNTHETIC</title><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;background:#0d1523;color:#eaf1fa;font:16px system-ui,Arial}.wrap{max-width:1080px;margin:auto;padding:32px}.hero{background:#16283f;border:1px solid #3c576c;border-radius:18px;padding:24px;margin-bottom:20px}.warn{color:#f6ca66}.badge{background:#31465f;padding:6px 10px;border-radius:20px;font-size:12px}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}.card{background:#15263b;border:1px solid #3b5268;padding:20px;border-radius:12px}.num{font-size:27px;font-weight:700;color:#86dfce}svg{max-width:100%;background:#111c2b;border-radius:10px}button{padding:10px 15px;background:#1da995;color:white;border:0;border-radius:8px;cursor:pointer}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#08111e;padding:12px;border-radius:8px}code{font-size:13px}</style></head><body><div class="wrap"><div class="hero"><span class="badge">Physica v0.4.2 • Causal Sensory Grammar</span><h1>One machine hears. Another sees. A third tests what they learned.</h1><p>A physically normalized experience moves across different sensors and different machine calibrations. Prediction hashes are sealed before simulator outcomes are produced.</p><p class="warn">ALL EVIDENCE IN THIS PAGE IS SYNTHETIC. No live Meta API, cameras, microphones or independently witnessed physical experiments.</p></div><div class="cards" id="cards"></div><h2>Machine C: counterfactual prediction versus simulation</h2><svg id="plot" viewBox="0 0 960 350" role="img" aria-label="Predictions and synthetic observations"></svg><h2>Sensor ablation on Machine A</h2><div class="cards" id="ablations"></div><h2>Trust and transfer rules</h2><pre id="details"></pre><h2>Algorithm provenance</h2><p>Implemented: calibrated multiple-observation Kalman filter, physics-normalized action→response words, cross-sensory forecast, CRATE shared residual memory, source/target checking and synthetic sign/reveal. Not yet implemented: a learned universal sensory translator or independently validated V-JEPA physics readout.</p></div><script>const trial=TRIAL_JSON, score=SCORE_JSON; const c=trial.C_results_rmse_m;document.getElementById('cards').innerHTML=Object.entries(c).map(([k,v])=>`<div class="card"><div>${k.replaceAll('_',' ')}</div><div class="num">${(v*1e3).toFixed(3)} mm</div></div>`).join('');document.getElementById('ablations').innerHTML=Object.entries(score.source_A_state_ablation_rmse_m).map(([k,v])=>`<div class="card">${k.replaceAll('_',' ')}<div class="num">${(v*1e3).toFixed(3)} mm</div></div>`).join('');let x=trial.curves.tau;let key=['C_observation_m','C_physics_m','C_from_A_m','C_from_AB_m'];let colors=['#eee','#fba','#5be8f5','#55dba6'];let all=key.flatMap(k=>trial.curves[k]);let mn=Math.min(...all),mx=Math.max(...all),sx=q=>36+(q-x[0])/(x[x.length-1]-x[0])*895,sy=q=>320-(q-mn)/(mx-mn)*280;document.getElementById('plot').innerHTML=key.map((k,i)=>`<polyline fill="none" stroke="${colors[i]}" stroke-width="${i===0?2.8:1.8}" points="${x.map((xx,j)=>sx(xx)+','+sy(trial.curves[k][j])).join(' ')}"/>`).join('')+key.map((k,i)=>`<text x="${48+i*208}" y="24" fill="${colors[i]}" font-size="13">${k.replaceAll('_',' ')}</text>`).join('');document.getElementById('details').textContent=JSON.stringify({B_hash:trial.seals?.B?.sha256||'see signed_B_prediction.json',A_to_B:trial.A_to_B_sensor_translation,incompatible_body:trial.incompatible_body,chemical_translation:trial.chemical_translation,benchmark:score.means_rmse_m,limitations:trial.limitations},null,2);</script></body></html>'''
    # Offline HTML; no runtime fetch, no external Javascript.
    html=html.replace('TRIAL_JSON',json.dumps({k:v for k,v in one.items() if k not in ('envelope_A','envelope_B','seals')}))
    html=html.replace('SCORE_JSON',json.dumps(score))
    (out/'experience_lab.html').write_text(html)
    return {'out_dir':str(out),'benchmark':score,'files':sorted(p.name for p in out.iterdir())}
