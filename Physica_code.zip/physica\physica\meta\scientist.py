"""Muse Spark as the scientist: when none of Physica's rivals explains what it feels, ask for new ones.

Spark never gets to be right by saying so. It proposes causes as structured JSON built from physical parts Physica
can simulate (a mass, a support, a crack, a loosening clamp, a uniform change), each with the range of places and
strengths it believes. Physica builds each proposal into its beam model, fits it to the first half of the felt
tones, and judges it only on the second half, against every built-in rival. Proposals are data, never code.

No key: an offline stand-in returns a fixed, author-written proposal, labelled as such (it is NOT Meta).
"""
from __future__ import annotations

import json

import numpy as np

from physica.cause import discover as D
from physica.cause.fe import Beam
from physica.llm import meta_client as mc

PARTS = {
    "mass": "something heavy at a place (strength = mass / body mass, 0.01-5)",
    "support": "something holding the body at a place (strength = spring k L^3/EI, 10-1e5)",
    "crack": "the body weakened around a place (strength = fraction of stiffness lost, 0.05-0.95)",
    "clamp": "the clamp at the root loosening (strength = rotational stiffness k_rot L/EI, 0.1-1e4; lower = looser)",
    "uniform": "the whole body stiffer/softer (strength = EI multiplier, 0.5-2)",
}

SCHEMA = {
    "type": "json_schema",
    "json_schema": {"name": "rivals", "strict": True, "schema": {
        "type": "object", "additionalProperties": False, "required": ["rivals", "next_measurement", "abstain"],
        "properties": {
            "abstain": {"type": "boolean"},
            "next_measurement": {"type": "string"},
            "rivals": {"type": "array", "maxItems": 4, "items": {
                "type": "object", "additionalProperties": False, "required": ["name", "why", "part", "place", "strength"],
                "properties": {
                    "name": {"type": "string"}, "why": {"type": "string"},
                    "part": {"type": "string", "enum": list(PARTS)},
                    "place": {"type": "array", "items": {"type": "number"}, "minItems": 2, "maxItems": 2},
                    "strength": {"type": "array", "items": {"type": "number"}, "minItems": 2, "maxItems": 2}}}}}}},
}

SYSTEM = ("You are the scientist inside Physica, a system that feels physical bodies through their natural "
          "frequencies. You are shown what a clamped beam's tones did and which built-in explanations failed and why. "
          "Propose up to 4 NEW physical causes, each built from ONE of these parts: "
          + "; ".join(f"{k}: {v}" for k, v in PARTS.items())
          + ". Give place as [from, to] in fractions of the length from the clamp (use [0, 0] for clamp and uniform) "
            "and strength as [low, high]. Physica will test each against data you have not seen; you gain nothing by "
            "guessing. If you can't propose anything testable, set abstain=true and say what to measure next.")


@mc.register_mock("propose_rival")
def _stand_in(messages):
    return json.dumps({"abstain": False, "next_measurement": "film the root of the clamp while flicking",
                       "rivals": [
                           {"name": "loosening clamp", "why": "AUTHOR-WRITTEN OFFLINE STAND-IN, NOT META: all tones fall "
                            "but the higher ones fall less, as when the root can rotate", "part": "clamp",
                            "place": [0, 0], "strength": [0.3, 3000]},
                           {"name": "warming", "why": "AUTHOR-WRITTEN OFFLINE STAND-IN, NOT META: temperature softens "
                            "the whole body", "part": "uniform", "place": [0, 0], "strength": [0.5, 1.0]}]})


def context(beam: Beam, f1, f2, disc: dict) -> str:
    f1, f2 = np.asarray(f1, float), np.asarray(f2, float)
    q = lambda a: [round(float(v), 2) for v in np.nanpercentile(a, [5, 50, 95])]  # noqa: E731
    return json.dumps({"body": beam.describe(), "tone1_hz_5_50_95": q(f1), "tone2_hz_5_50_95": q(f2),
                       "tone2_over_tone1_5_50_95": q(f2 / f1), "first_felt": [round(float(f1[0]), 2), round(float(f2[0]), 2)],
                       "last_felt": [round(float(f1[-1]), 2), round(float(f2[-1]), 2)],
                       "built_in_rivals": [{k: r[k] for k in ("rival", "status", "explained_pct", "say")} for r in disc["rivals"]]})


def ask(beam: Beam, f1, f2, disc: dict, role: str = "spark") -> dict:
    msgs = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": context(beam, f1, f2, disc)}]
    r = mc.complete(role, msgs, task="propose_rival", response_format=SCHEMA, max_completion_tokens=16000)
    text = r["content"] or "{}"
    try:
        prop = json.loads(text[text.find("{"): text.rfind("}") + 1])
    except json.JSONDecodeError:
        prop = {"abstain": True, "rivals": [], "next_measurement": "(unparseable answer)", "raw": text[:500]}
    prop["_mode"], prop["_model"] = r["mode"], r["model"]
    return prop


def _curves(beam: Beam, part: str, places, strengths):
    out = {}
    for s in strengths:
        if part == "clamp":
            out[(0.0, s)] = beam.freqs(2, clamp_rot=s)
        elif part == "uniform":
            out[(0.0, s)] = beam.bare(2) * np.sqrt(s)
        else:
            for x in places:
                if part == "mass":
                    out[(x, s)] = beam.freqs(2, masses=[(x, s)])
                elif part == "support":
                    out[(x, s)] = beam.freqs(2, springs=[(x, s)])
                elif part == "crack":
                    ei = np.ones(beam.n_el)
                    lo, hi = int(max(x - 0.025, 0) * beam.n_el), int(min(x + 0.025, 1) * beam.n_el) + 1
                    ei[lo:hi] *= 1 - s
                    out[(x, s)] = beam.freqs(2, ei=ei)
    return out


def test(beam: Beam, f1, f2, rival: dict, tol: float = 0.03) -> dict:
    """Build the proposed cause, let it pick its hidden state per window on the FIRST half (place fixed, strength may
    drift), then judge only the SECOND half: share of windows where both tones are within tolerance."""
    part = rival["part"]
    if part not in PARTS:
        return {"name": rival.get("name"), "accepted": False, "why": f"unknown part {part}"}
    p0, p1 = sorted(np.clip(rival.get("place", [0, 0]), 0.0, 1.0))
    s0, s1 = sorted(np.clip(rival.get("strength", [1, 1]), 1e-3, 1e6))
    places = np.linspace(max(p0, 0.02), max(p1, 0.02), 1 if part in ("clamp", "uniform") else 12)
    ns = 80 if part in ("clamp", "uniform") else 24
    strengths = np.geomspace(s0, s1, ns) if s1 / s0 > 3 else np.linspace(s0, s1, ns)
    C = _curves(beam, part, places, strengths)
    keys = list(C)
    M = np.log(np.array([C[k] for k in keys]))
    Y = np.log(np.c_[f1, f2])
    ok = np.isfinite(Y).all(1)
    R = np.abs(Y[ok][:, None, :] - M[None, :, :]).max(2)  # worst tone per (window, state)
    n = len(R)
    first, second = np.arange(n) < n // 2, np.arange(n) >= n // 2
    xs = np.array([k[0] for k in keys])
    # place is a property of the body: choose it on the first half, then let only the strength move
    best_place = min(set(xs.tolist()), key=lambda x: np.sum(np.minimum(R[first][:, xs == x].min(1), 0.2)))
    sel = xs == best_place
    fit = R[:, sel].min(1)
    k_best = np.array(keys, dtype=object)[sel][R[:, sel].argmin(1)]
    return {"name": rival.get("name"), "part": part, "place": float(best_place), "why": rival.get("why"),
            "explained_first_half_pct": float(100 * np.mean(fit[first] <= tol)),
            "explained_second_half_pct": float(100 * np.mean(fit[second] <= tol)),
            "strength_path": [float(k[1]) for k in k_best[::max(len(k_best) // 40, 1)]]}


def builtin_second_half(beam: Beam, f1, f2, tol: float = 0.03) -> dict:
    """Same judge for the built-in rivals (both tones within tolerance, second half only)."""
    out = {}
    n = len(f1)
    sl = slice(n // 2, None)
    for rival in ("mass", "crack", "support"):
        best = 0.0
        for s in D.RIVALS[rival]["strengths"]:
            C = np.log(D.curves(beam, rival, s, n=2))
            Y = np.log(np.c_[f1, f2])[sl]
            R = np.abs(Y[:, None, :] - C[None]).max(2).min(1)
            best = max(best, float(100 * np.mean(R <= tol)))
        out[rival] = best
    sc = (f1 / beam.bare(1)[0]) ** 2
    ratio_ok = np.abs(np.log((f2 / f1) / (beam.bare(2)[1] / beam.bare(2)[0]))) <= tol
    out["uniform"] = float(100 * np.mean((ratio_ok & (np.abs(sc - 1) < 0.1))[sl]))
    return out


def investigate(beam: Beam, f1, f2, role: str = "spark", accept_pct: float = 80.0) -> dict:
    disc = D.discover(beam, f1, f2)
    res = {"built_in": disc["verdict"], "built_in_second_half_pct": builtin_second_half(beam, f1, f2)}
    if disc["verdict"].get("cause") and disc["verdict"]["explained_pct"] >= accept_pct:
        res["asked_scientist"] = False
        return res
    prop = ask(beam, f1, f2, disc, role)
    res["asked_scientist"] = True
    res["scientist"] = {"mode": prop.get("_mode"), "model": prop.get("_model"), "abstain": prop.get("abstain"),
                        "next_measurement": prop.get("next_measurement")}
    tests = [test(beam, f1, f2, r) for r in prop.get("rivals", [])]
    best_builtin = max(res["built_in_second_half_pct"].values())
    for t in tests:
        t["accepted"] = bool(t.get("explained_second_half_pct", 0) >= accept_pct and
                             t["explained_second_half_pct"] > best_builtin + 10)
    res["proposals_tested"] = tests
    acc = [t for t in tests if t["accepted"]]
    res["verdict"] = (f"New cause accepted: {acc[0]['name']} (explains {acc[0]['explained_second_half_pct']:.0f}% of "
                      f"moments it was not fitted on; best built-in rival {best_builtin:.0f}%)." if acc else
                      "No proposal survived the held-out test; Physica keeps saying it doesn't know.")
    return res
