"""Physica Dual-World Causal Residuals (experimental, v0.3).

A mechanistic world and a learned visual-world prediction must be expressed
on the SAME calibrated observable to be compared. Model outputs in unrelated
latent dimensions have no meaningful KL divergence. This module never calls an
AI model, actuates hardware, or treats a mock forecast as real evidence.

Algorithm: eligible actions ranked by information gain + bounded symmetric
Gaussian forecast disagreement - risk/cost. After a *real* observation,
score each model independently (standardized surprise and Gaussian NLL).
The combination is an experimental architecture, not a proven new theorem.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import exp, isfinite, log, pi
from typing import Mapping
from .pacer import Experiment, expected_information_gain, normalize


@dataclass(frozen=True)
class CalibratedForecast:
    observable: str
    unit: str
    mean: float
    sigma: float
    model_id: str
    origin: str                         # mechanistic, model, synthetic, replay
    calibration_evidence: str | None = None

    def __post_init__(self):
        if not self.observable.strip() or not self.unit.strip() or not self.model_id.strip():
            raise ValueError("observable, unit and model ID are required")
        if not isfinite(self.mean) or not isfinite(self.sigma) or self.sigma <= 0:
            raise ValueError("mean and strictly positive sigma must be finite")
        if self.origin not in ("mechanistic", "model", "synthetic", "replay"):
            raise ValueError("unknown forecast origin")

    @property
    def calibrated(self) -> bool:
        return bool(self.calibration_evidence and self.calibration_evidence.strip())


def symmetric_gaussian_kl(x: CalibratedForecast, y: CalibratedForecast) -> float:
    """0.5*(KL(x||y)+KL(y||x)), nats; identical measured quantity required."""
    if x.observable != y.observable or x.unit != y.unit:
        raise ValueError("incommensurate observables: add a calibrated mapping first")
    if not x.calibrated or not y.calibrated:
        raise ValueError("missing uncertainty calibration evidence")
    va, vb = x.sigma**2, y.sigma**2
    delta = (x.mean-y.mean)**2
    result = 0.25 * (va/vb + vb/va - 2 + delta * (1/va+1/vb))
    return float(result)


def outcome_score(forecast: CalibratedForecast, observed: float, unit: str) -> dict:
    if not isfinite(observed):
        raise ValueError("non-finite observed value")
    if forecast.unit != unit:
        raise ValueError("observation unit mismatch")
    if not forecast.calibrated:
        raise ValueError("uncalibrated uncertainty")
    z = (observed - forecast.mean) / forecast.sigma
    return {"model_id": forecast.model_id, "residual": observed-forecast.mean,
            "standardized_residual": z,
            "gaussian_nll": .5*log(2*pi*forecast.sigma**2) + .5*z*z,
            "within_95pct_nominal": abs(z) <= 1.96}


def rank_actions(prior: Mapping[str, float], actions: list[Experiment],
                 paired_forecasts: Mapping[str, tuple[CalibratedForecast, CalibratedForecast]],
                 *, disagreement_weight: float = .40, risk_weight: float = 1.,
                 cost_weight: float = .05, max_risk: float = .15,
                 allow_partial: bool = False) -> dict:
    """Risk-first ranking; disagreement does not authorize dangerous actions.

    Paired predictions must correspond to the Experiment's scalar observable
    and unit; default refuses actions without both calibrated forecasts.
    This refuses invented V-JEPA outputs and guards against using unrelated
    latent embeddings as if they were calibrated physical forecasts.
    """
    normalize(prior)
    if not actions: raise ValueError("no actions")
    if len(set(a.action_id for a in actions)) != len(actions):
        raise ValueError("duplicate action IDs")
    if not all(isfinite(v) and v >= 0 for v in (disagreement_weight, risk_weight, cost_weight)):
        raise ValueError("weights must be finite and nonnegative")
    ranking = []
    for action in actions:
        r = {"action_id": action.action_id, "risk": action.risk,
             "irreversible": action.irreversible}
        if action.irreversible or not action.safety_approved or action.risk > max_risk:
            ranking.append({**r, "status": "rejected_safety"})
            continue
        pair = paired_forecasts.get(action.action_id)
        if not pair:
            if not allow_partial:
                ranking.append({**r, "status":"rejected_missing_dual_forecast"})
                continue
            disagreement = 0.0
            pair_status = "physics_only_ablation"
        else:
            physics, visual = pair
            if physics.unit != action.unit or visual.unit != action.unit:
                ranking.append({**r, "status":"rejected_unit_mismatch"})
                continue
            try:
                disagreement = symmetric_gaussian_kl(physics, visual)
            except ValueError as exc:
                ranking.append({**r,"status":"rejected_incompatible_forecasts","reason":str(exc)})
                continue
            pair_status = "both_forecasts_calibrated"
        eig = expected_information_gain(prior, action)
        bounded_disagreement = - __import__('math').expm1(-disagreement) # 1 - exp(-KL), stable
        utility = (eig + disagreement_weight*bounded_disagreement
                   - risk_weight*action.risk - cost_weight*action.cost)
        ranking.append({**r, "status":"eligible", "forecast_status":pair_status,
                        "eig_nats": eig, "symmetric_kl_nats":disagreement,
                        "bounded_disagreement":bounded_disagreement,
                        "utility":utility})
    ranking.sort(key=lambda r:(r.get("utility",float("-inf")),r["action_id"]),reverse=True)
    eligible=[r for r in ranking if r["status"]=="eligible"]
    return {"decision":"safe_experiment" if eligible else "stop_no_safe_dual_forecast",
            "chosen":eligible[0]["action_id"] if eligible else None,
            "ranking":ranking,
            "method":"EIG + bounded symmetric Gaussian KL - risk - cost",
            "warning":"requires calibrated same-observable forecasts; never an actuation permit"}
