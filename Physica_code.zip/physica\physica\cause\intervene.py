"""Causal Modal Intervention: when feeling alone can't settle WHY a body changed, do the experiment that will.

A body's tones dropped. Was it something heavy sitting on it, or a crack? Where? Several answers can explain the
same tones. Physica holds all of them at once (a belief over cause x place x strength), then asks: which small,
safe thing could I do to it next (tape a coin at a chosen place, or just measure again) whose result would split
my remaining answers the most? That is the expected information gain of each experiment. Before doing it, Physica
SEALS what it expects to feel (tone intervals); afterwards it reveals, grades its own promise and updates.

Interventions are causal: Physica changes the body itself (adds a known mass at a chosen place), it doesn't wait
for nature to do it. A coin moves the tones differently depending on the hidden cause, because the hidden cause
reshapes how the body bends (its mode shapes).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from physica import seal as _seal
from physica.cause.fe import Beam

CAUSES = ("mass", "crack", "none")


@dataclass
class Intervention:
    kind: str            # "coin" or "again"
    place: float = 0.0   # fraction of length from the clamp
    mass_frac: float = 0.0
    cost: float = 1.0

    def say(self, beam: Beam | None = None) -> str:
        if self.kind == "again":
            return "measure it again, unchanged"
        mm = f" ({self.place * beam.length * 1e3:.0f} mm from the clamp)" if beam else ""
        return f"tape the coin at {100 * self.place:.0f}% of the length{mm}"

    def key(self):
        return (self.kind, round(self.place, 3), round(self.mass_frac, 4))


def hypotheses(places=np.linspace(0.08, 0.97, 24), mass_fracs=(0.03, 0.06, 0.1, 0.16, 0.25, 0.4),
               crack_losses=(0.2, 0.35, 0.5, 0.65, 0.8)):
    H = [("none", 0.0, 0.0)]
    H += [("mass", float(x), float(m)) for x in places for m in mass_fracs]
    H += [("crack", float(x), float(c)) for x in places for c in crack_losses]
    return H


def tones(beam: Beam, h, iv: Intervention | None, n: int = 3) -> np.ndarray:
    cause, x, s = h
    masses, ei = [], None
    if cause == "mass":
        masses.append((x, s))
    elif cause == "crack":
        ei = np.ones(beam.n_el)
        lo, hi = int(max(x - 0.025, 0) * beam.n_el), int(min(x + 0.025, 1) * beam.n_el) + 1
        ei[lo:hi] *= 1 - s
    if iv is not None and iv.kind == "coin":
        masses.append((iv.place, iv.mass_frac))
    return beam.freqs(n, masses=masses, ei=ei)


@dataclass
class Investigation:
    beam: Beam
    coin_frac: float
    noise_rel: float = 0.006        # tone measurement + model error (relative), stated up front
    promise_inflate: float = 2.5    # promises also carry the error of a coarse belief grid (calibrated in E17)
    places: tuple = (0.2, 0.35, 0.5, 0.65, 0.8, 1.0)
    n_tones: int = 3
    H: list = field(default_factory=hypotheses)
    log_post: np.ndarray | None = None
    history: list = field(default_factory=list)
    _pred: dict = field(default_factory=dict, repr=False)

    def __post_init__(self):
        self.log_post = np.zeros(len(self.H)) - np.log(len(self.H))
        self.menu = [Intervention("again")] + [Intervention("coin", p, self.coin_frac) for p in self.places]

    def predicted(self, iv: Intervention | None) -> np.ndarray:
        k = None if iv is None else iv.key()
        if k not in self._pred:
            self._pred[k] = np.log(np.array([tones(self.beam, h, None if iv is None or iv.kind == "again" else iv,
                                                   self.n_tones) for h in self.H]))
        return self._pred[k]

    @property
    def post(self) -> np.ndarray:
        p = np.exp(self.log_post - self.log_post.max())
        return p / p.sum()

    def observe(self, felt_hz, iv: Intervention | None = None) -> None:
        y = np.log(np.asarray(felt_hz, float)[:self.n_tones])
        P = self.predicted(iv)
        ok = np.isfinite(y)
        r = (P[:, ok] - y[ok]) / self.noise_rel
        self.log_post = self.log_post - 0.5 * np.sum(np.minimum(r ** 2, 400), 1)  # robust: cap any one tone's say
        self.history.append({"did": "first feel" if iv is None else iv.say(self.beam), "felt_hz": list(map(float, felt_hz))})

    def belief(self) -> dict:
        p = self.post
        by = {c: float(sum(pi for pi, h in zip(p, self.H) if h[0] == c)) for c in CAUSES}
        top = max(by, key=by.get)
        xs = np.array([h[1] for h in self.H])
        sel = np.array([h[0] == top for h in self.H])
        w = p * sel
        w = w / w.sum() if w.sum() > 0 else w
        place = float(w @ xs) if top != "none" else None
        spread = float(np.sqrt(w @ (xs - (place or 0)) ** 2)) if top != "none" else None
        return {"cause": top, "confidence": by[top], "by_cause": by, "place": place, "place_sd": spread}

    def _entropy(self, p):
        p = p[p > 1e-12]
        return float(-(p * np.log(p)).sum())

    def gain(self, iv: Intervention, samples: int = 200, rng=None) -> float:
        """Expected information gain about (cause, place), by simulation from the current belief."""
        rng = rng or np.random.default_rng(0)
        p = self.post
        P = self.predicted(iv)
        labels = np.array([CAUSES.index(h[0]) * 100 + int(round(h[1] * 20)) for h in self.H])
        uniq, inv = np.unique(labels, return_inverse=True)

        def marg(q):
            return np.bincount(inv, weights=q, minlength=len(uniq))

        H0 = self._entropy(marg(p))
        idx = rng.choice(len(p), size=samples, p=p)
        Hs = []
        for i in idx:
            y = P[i] + rng.normal(0, self.noise_rel, P.shape[1])
            lp = np.log(p + 1e-300) - 0.5 * np.sum(np.minimum(((P - y) / self.noise_rel) ** 2, 400), 1)
            q = np.exp(lp - lp.max())
            Hs.append(self._entropy(marg(q / q.sum())))
        return H0 - float(np.mean(Hs))

    def next_experiment(self, rng=None) -> tuple[Intervention, list]:
        scores = [(self.gain(iv, rng=rng) / iv.cost, iv) for iv in self.menu]
        scores.sort(key=lambda s: -s[0])
        return scores[0][1], [{"do": iv.say(self.beam), "gain_bits": g / np.log(2)} for g, iv in scores]

    def promise(self, iv: Intervention, q: float = 0.9) -> dict:
        """Sealed prediction of the tones Physica will feel after iv: posterior-predictive intervals."""
        p = self.post
        P = self.predicted(iv)
        rng = np.random.default_rng(1)
        idx = rng.choice(len(p), size=2000, p=p)
        draws = P[idx] + rng.normal(0, self.noise_rel * self.promise_inflate, (2000, P.shape[1]))
        lo, hi = np.quantile(np.exp(draws), [(1 - q) / 2, (1 + q) / 2], axis=0)
        intervals = {f"tone{k + 1}_hz": [float(lo[k]), float(hi[k])] for k in range(P.shape[1])}
        return _seal.seal({"intervals": intervals, "action": iv.say(self.beam), "belief": self.belief()},
                          "what Physica will feel after its next experiment")


def run(beam: Beam, truth, coin_frac: float, policy: str = "eig", budget: int = 3, noise_rel: float = 0.006,
        truth_beam: Beam | None = None, seed: int = 0) -> dict:
    """One investigation against a known hidden truth (simulation): first feel, then `budget` experiments."""
    rng = np.random.default_rng(seed)
    tb = truth_beam or beam
    inv = Investigation(beam, coin_frac, noise_rel=noise_rel)

    def feel(iv):
        f = tones(tb, truth, None if iv is None or iv.kind == "again" else iv, inv.n_tones)
        return f * np.exp(rng.normal(0, noise_rel * 0.7, len(f)))

    inv.observe(feel(None))
    steps, promises = [inv.belief()], []
    for _ in range(budget):
        if policy == "eig":
            iv, _ = inv.next_experiment(rng)
        elif policy == "random":
            iv = inv.menu[rng.integers(1, len(inv.menu))]
        elif policy == "again":
            iv = inv.menu[0]
        else:
            break
        s = inv.promise(iv)
        felt = feel(iv)
        rv = _seal.reveal(s, {f"tone{k + 1}_hz": float(v) for k, v in enumerate(felt)}, _seal.interval_grade)
        promises.append(rv["held"])
        inv.observe(felt, iv)
        steps.append(inv.belief())
    b = steps[-1]
    right = b["cause"] == truth[0]
    place_err = abs(b["place"] - truth[1]) if right and truth[0] != "none" and b["place"] is not None else None
    return {"truth": truth, "final": b, "right_cause": right, "place_err": place_err, "steps": steps,
            "promises_held": promises}
