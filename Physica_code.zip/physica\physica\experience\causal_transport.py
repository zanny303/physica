"""CRATE: Causal Residual Alignment and Transport of Experience, v0.4 research prototype.

A physically normalized, cross-body *correction to an explicit mechanistic twin*.
Not a discovered universal law. Only valid for calibrated, comparable, approximately
linear, step-excited machines. Uses source-only splits, finite-sample conformal
calibration and optional local low-force probe updating. No actuator commands.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import ceil, isfinite
from typing import Sequence
import hashlib, json
import numpy as np
from .transport import BodyCalibration, compatibility


def _arr(x):
    a=np.asarray(x,dtype=float)
    if a.ndim!=1 or len(a)<8 or not np.all(np.isfinite(a)):
        raise ValueError('finite vector of >=8 samples required')
    return a


def twin_response(t, c:BodyCalibration):
    """Second-order mass-spring-damper step response in metres (baseline)."""
    t=np.asarray(t,dtype=float)
    z=float(c.damping_ratios[0]); w=2*np.pi*c.fundamental_hz
    d=np.sqrt(1-z*z)
    return c.applied_step_force_n/c.stiffness_n_per_m*(1-np.exp(-z*w*t)*(
        np.cos(d*w*t)+z/d*np.sin(d*w*t)))


@dataclass(frozen=True)
class CausalTrace:
    body: BodyCalibration
    time_s: tuple[float,...]
    displacement_m: tuple[float,...]
    provenance: str
    evidence_hash: str
    # Signed transport/reveal may be verified by the field protocol; this type
    # alone is NOT proof of authentic hardware provenance.
    def __post_init__(self):
        t=_arr(self.time_s); y=_arr(self.displacement_m)
        if len(t)!=len(y) or np.any(np.diff(t)<=0) or t[0]<0:
            raise ValueError('times must increase and match displacements')
        if self.provenance not in ('simulation','real_sensor'):
            raise ValueError('provenance must be explicit')
        if len(self.evidence_hash)!=64 or any(x not in '0123456789abcdef' for x in self.evidence_hash):
            raise ValueError('SHA256 evidence hash required')


def trace(body,t,y,provenance='simulation'):
    y=np.asarray(y,dtype=float); t=np.asarray(t,dtype=float)
    digest=hashlib.sha256(np.asarray(y,dtype='<f8').tobytes()).hexdigest()
    return CausalTrace(body,tuple(t),tuple(y),provenance,digest)


def aligned_residual(entry:CausalTrace, grid_tau):
    """R(tau)=[observed - mechanistic_twin]*stiffness/force.
    No interpolation outside the source time range and no silent unit changes.
    """
    t=np.asarray(entry.time_s); tau=t*entry.body.fundamental_hz
    grid=np.asarray(grid_tau)
    if grid[0]<tau[0]-1e-10 or grid[-1]>tau[-1]+1e-10:
        raise ValueError('source does not span target dimensionless timeline')
    r=(np.asarray(entry.displacement_m)-twin_response(t,entry.body))*entry.body.stiffness_n_per_m/entry.body.applied_step_force_n
    return np.interp(grid,tau,r)


@dataclass
class ResidualMemory:
    grid_tau: np.ndarray
    mean: np.ndarray
    source_count: int
    residual_library: np.ndarray
    source_ids: tuple[str,...]
    version: str = 'physica.crate/v1'
    # Store immutable calibration anchors with the memory itself.  Checking
    # compatibility only in a showcase or caller is a safety bypass.
    source_calibrations: tuple[BodyCalibration, ...] = ()

    def assess_probe_shift(self, target: BodyCalibration, probe: CausalTrace, *,
                           conformal_q: float | None, sensor_sigma_m: float | None = None):
        """Falsification check *before* extrapolating from a low-force B probe.

        Whole-machine conformal q must come from independent held-out calibration.
        Passing is provisional evidence of source-like dynamics, NEVER permission
        to actuate or a guarantee under distribution shift.
        """
        if not self.source_calibrations or len(self.source_calibrations)!=self.source_count:
            raise ValueError('CRATE memory has no source compatibility evidence')
        for source in self.source_calibrations:
            match=compatibility(source,target)
            if match['status']!='comparable':
                raise ValueError('incompatible target body: '+','.join(match['reasons']))
        if probe.body.machine_id!=target.machine_id:
            raise ValueError('local probe is not from target machine')
        if compatibility(probe.body,target)['status']!='comparable':
            raise ValueError('local probe action or body incompatible')
        if (not np.isclose(probe.body.fundamental_hz,target.fundamental_hz,rtol=1e-9)
            or not np.isclose(probe.body.stiffness_n_per_m,target.stiffness_n_per_m,rtol=1e-9)):
            raise ValueError('local probe calibration differs from target')
        if probe.body.applied_step_force_n>=target.applied_step_force_n:
            raise ValueError('OOD guard requires strictly lower-force prior probe')
        if conformal_q is None:
            return {'status':'insufficient_heldout_calibration','source_like':False,
                    'hardware_actuation_allowed':False}
        if not isfinite(conformal_q) or conformal_q<0:
            raise ValueError('finite nonnegative conformal q required')
        # Low-force probes amplify absolute sensor noise in k/F normalisation.
        # A source-force q alone is NOT a calibrated low-force gate threshold.
        if sensor_sigma_m is None:
            return {'status':'insufficient_probe_noise_calibration','source_like':False,
                    'hardware_actuation_allowed':False}
        if not isfinite(sensor_sigma_m) or sensor_sigma_m<0:
            raise ValueError('finite nonnegative independently measured probe sensor noise required')
        tau=np.asarray(probe.time_s)*target.fundamental_hz
        if tau[0]<self.grid_tau[0]-1e-10 or tau[-1]>self.grid_tau[-1]+1e-10:
            raise ValueError('probe extends outside trained time support')
        observed=aligned_residual(probe,tau)
        expected=np.interp(tau,self.grid_tau,self.mean)
        score=float(np.max(np.abs(observed-expected)))
        # 3.5 sigma is a declared heuristic maximum-over-samples noise buffer,
        # NOT a conformally calibrated false-positive rate for low-force probes.
        noise_buffer=3.5*sensor_sigma_m*probe.body.stiffness_n_per_m/probe.body.applied_step_force_n
        threshold=float(conformal_q+noise_buffer)
        passed=score<=threshold
        return {'status':'provisionally_source_like' if passed else 'rejected_domain_shift',
                'source_like':passed,'max_dimensionless_deviation':score,
                'effective_heuristic_threshold':threshold,'sensor_noise_buffer':noise_buffer,
                'heldout_conformal_q':float(conformal_q),
                'hardware_actuation_allowed':False,
                'warning':'Statistical consistency is not physical safety certification'}

    def forecast(self, target:BodyCalibration, t_s, *, local_probe:CausalTrace|None=None,
                 observation_noise_m:float=0., conformal_q:float|None=None):
        if not self.source_calibrations or len(self.source_calibrations)!=self.source_count:
            raise ValueError('CRATE memory has no source compatibility evidence')
        for source in self.source_calibrations:
            comparison=compatibility(source,target)
            if comparison['status']!='comparable':
                raise ValueError('incompatible target body for CRATE transfer: '+','.join(comparison['reasons']))
        t=_arr(t_s)
        if t[0]<0 or np.any(np.diff(t)<=0): raise ValueError('invalid target grid')
        tau=t*target.fundamental_hz
        if tau[0]<self.grid_tau[0]-1e-10 or tau[-1]>self.grid_tau[-1]+1e-10:
            raise ValueError('target timeline outside experience support')
        r=np.interp(tau,self.grid_tau,self.mean)
        adaptation='zero_shot'
        if local_probe is not None:
            if local_probe.body.machine_id!=target.machine_id:
                raise ValueError('local probe belongs to another machine')
            if compatibility(local_probe.body,target)['status']!='comparable':
                raise ValueError('local probe incompatible')
            # Same body calibration except force may differ: causal update must be
            # normalized by the *probe* force, not by target test force.
            if any(abs(getattr(local_probe.body,n)-getattr(target,n))>1e-9
                   for n in ('fundamental_hz','stiffness_n_per_m')):
                raise ValueError('local probe and target calibration differ')
            tp=np.asarray(local_probe.time_s)*target.fundamental_hz
            rp=aligned_residual(local_probe,tp)
            # Kernel smoothing of the observed residual innovation, shrunk
            # toward the transferred prior to control small-sample overfitting.
            old=np.interp(tp,self.grid_tau,self.mean)
            innovations=rp-old
            distances=(tau[:,None]-tp[None,:])/.13
            kernel=np.exp(-.5*distances**2)
            denom=np.sum(kernel,axis=1)
            correction=np.divide(kernel@innovations,denom,out=np.zeros(len(t)),where=denom>1e-9)
            # a full local time-series is one local *intervention*, not one sample
            r=r+.65*correction
            adaptation='one_local_probe'
        center=twin_response(t,target)+r*target.applied_step_force_n/target.stiffness_n_per_m
        noise=max(0.,float(observation_noise_m))
        if not isfinite(noise):raise ValueError('invalid sensor noise')
        spread=np.std(self.residual_library,axis=0,ddof=1) if self.source_count>=2 else np.zeros_like(self.mean)
        uncertainty=np.interp(tau,self.grid_tau,spread)*target.applied_step_force_n/target.stiffness_n_per_m
        if conformal_q is not None:
            if conformal_q<0 or not isfinite(conformal_q):raise ValueError('bad conformal quantile')
            half=np.sqrt(uncertainty**2+noise**2)+conformal_q*target.applied_step_force_n/target.stiffness_n_per_m
        else:
            half=None
        return {'status':'unverified_prediction','origin':'source_memory_plus_physics',
                'adaptation':adaptation,'model':'CRATE', 'time_s':t.tolist(),
                'displacement_m':center.tolist(), 'lower_m':(center-half).tolist() if half is not None else None,
                'upper_m':(center+half).tolist() if half is not None else None,
                'calibration':'source_split_conformal' if conformal_q is not None else 'UNCALIBRATED',
                'experience_sources':list(self.source_ids),
                'warning':'No distribution-free coverage guarantee under domain shift; NO actuation authorization'}


def fit_memory(sources:Sequence[CausalTrace], *, grid_tau=None):
    if len(sources)<2:raise ValueError('require >=2 distinct source machines')
    if len(set(t.body.machine_id for t in sources))!=len(sources):
        raise ValueError('leakage/duplicate machine ID across source experiences')
    first=sources[0]
    for x in sources[1:]:
        if compatibility(first.body,x.body)['status']!='comparable':
            raise ValueError('incompatible source bodies')
    if grid_tau is None:
        hi=min(s.time_s[-1]*s.body.fundamental_hz for s in sources)
        lo=max(s.time_s[0]*s.body.fundamental_hz for s in sources)
        grid=np.linspace(lo,hi,250)
    else:grid=_arr(grid_tau)
    traces=np.vstack([aligned_residual(e,grid) for e in sources])
    return ResidualMemory(grid,np.mean(traces,axis=0),len(sources),traces,
                          tuple(s.body.machine_id for s in sources),
                          source_calibrations=tuple(s.body for s in sources))


def conformal_calibrate(train:Sequence[CausalTrace], heldout:Sequence[CausalTrace], *, alpha=.10):
    """Split conformal on held-out WHOLE MACHINES, dimensionless absolute residuals.
    Calibration units correspond to normalized displacement; max-over-time score
    gives a conservative simultaneous band on the chosen time grid.
    """
    if not 0<alpha<1:raise ValueError('alpha must be 0..1')
    if not heldout:raise ValueError('heldout machines required')
    train_ids={s.body.machine_id for s in train}
    if train_ids.intersection(s.body.machine_id for s in heldout):
        raise ValueError('calibration leakage: train/heldout machines overlap')
    mem=fit_memory(train)
    scores=[]
    for h in heldout:
        if compatibility(train[0].body,h.body)['status']!='comparable':raise ValueError('heldout incompatibility')
        errors=aligned_residual(h,mem.grid_tau)-mem.mean
        # deviation of memory mean (no need to double count empirical spread in this bound)
        scores.append(float(np.max(np.abs(errors))))
    n=len(scores)
    k=ceil((n+1)*(1-alpha))
    q=float(sorted(scores)[k-1]) if k<=n else float('inf')
    return {'q_dimensionless':q if np.isfinite(q) else None,
            'alpha':alpha,'calibration_machines':n,
            'guarantee':'exchangeable source-like machines only; not novel hardware under distribution shift',
            'scores':scores, 'coverage_supported':k<=n}


def rmse(a,b):
    return float(np.sqrt(np.mean((_arr(a)-_arr(b))**2)))


def select_safe_probe(candidates:list[dict],cal:BodyCalibration,*,max_deflection_m=.004,
                      min_snr=3.,sensor_sigma_m=1e-5):
    """Fail-closed selection: no NaN/Inf, coercion to unsafe values, or
    undocumented actuation. Invalid candidates remain visible as rejections.
    """
    limits=(float(max_deflection_m),float(min_snr),float(sensor_sigma_m))
    if any(not isfinite(v) for v in limits) or limits[0]<=0 or limits[1]<=0 or limits[2]<=0:
        raise ValueError('finite positive safety and sensor thresholds required')
    ranking=[]
    for i,c in enumerate(candidates):
        cid=str(c.get('id',f'candidate_{i}'))
        try:
            if any(isinstance(c.get(k),bool) for k in ('force_n','risk','cost')):
                raise ValueError('boolean is not a physical quantity')
            force=float(c['force_n']); risk=float(c['risk']);cost=float(c.get('cost',0.))
            if any(not isfinite(x) for x in (force,risk,cost)):
                raise ValueError('nonfinite candidate numeric input')
            if force<=0 or risk<0 or cost<0:
                raise ValueError('invalid force, risk or cost')
            snr=force/cal.stiffness_n_per_m/limits[2]
            deflection=2*force/cal.stiffness_n_per_m
            utility=float(np.log1p(snr)-8*risk-.1*cost)
            if any(not isfinite(x) for x in (snr,deflection,utility)):
                raise ValueError('nonfinite derived utility')
        except (KeyError,TypeError,ValueError,OverflowError) as exc:
            ranking.append({'id':cid,'status':'rejected_invalid_numeric',
                            'reason':str(exc),'snr_proxy':None,
                            'predicted_peak_deflection_m':None,'utility':None})
            continue
        unsafe=(c.get('approved') is not True or c.get('irreversible') is not False
                or risk>.12 or deflection>limits[0])
        status='rejected_safety' if unsafe else ('rejected_low_snr' if snr<limits[1] else 'eligible')
        ranking.append({'id':cid,'status':status,'snr_proxy':snr,
                        'predicted_peak_deflection_m':deflection,
                        'utility':utility if status=='eligible' else None})
    choices=[c for c in ranking if c['status']=='eligible']
    # Constrain first; then select lowest predicted deflection among adequate SNR.
    choices.sort(key=lambda c:(c['predicted_peak_deflection_m'],-c['snr_proxy']))
    return {'chosen':choices[0]['id'] if choices else None,'ranking':ranking,
            'authority':'physics_safety_gate','hardware_actuation_allowed':False}
