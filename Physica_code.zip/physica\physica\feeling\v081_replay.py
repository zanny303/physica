"""Auditable, deliberately SYNTHETIC, prediction-before-observation replay.

This module separates the call to seal_future_sensations from the generation of
simulated target truth. It does NOT establish independent chronology, hardware
validity or a calibration guarantee. For real experiments use the v08 CLI's
separate forecast/reveal commands and an external timestamp/witness.
"""
from __future__ import annotations
from pathlib import Path
import json
import numpy as np
from .core import Body, Sense
from .mechanism_transfer import discover_and_sign, make_target_probe_certificate
from .hierarchical_transfer_v08 import combine_source_and_probe
from .prospective_v08 import (simulate_future, seal_future_sensations,
                               score_future_reveal, verify_reveal_receipt)
from .v08_benchmark import produce_episode, rmse_camera


def _dump(out:Path, name, value):
    dst=out/name
    dst.write_text(json.dumps(value,indent=2)+'\n')


def run(outdir, *, seed=2026, target_beta=.244):
    if not np.isfinite(target_beta) or abs(target_beta)>3:
        raise ValueError('invalid synthetic target mechanism')
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(seed)
    ref=.01
    A=Body('A_synthetic',.12,22.,.13,.25,1.)
    B=Body('B_synthetic',.141,24.,.15,.28,1.)
    train=[produce_episode(A,f'A_train_{i}',.22,ref,seed=seed+i,amplitude=.075+.015*i) for i in range(2)]
    heldout=[produce_episode(A,'A_heldout',.22,ref,seed=seed+17,amplitude=.10,phase=.6)]
    lesson=discover_and_sign(A,train,heldout,displacement_reference_m=ref)
    if lesson['status']!='CANDIDATE_SIGNED_REQUIRES_TARGET_PROBE':raise RuntimeError('lesson refused')
    probe=produce_episode(B,'B_probe',target_beta,ref,seed=seed+101,amplitude=.025,phase=.4)
    cert=make_target_probe_certificate(lesson,B,probe,displacement_reference_m=ref)
    if cert['status']!='ACCEPT_PROBE_MODEL_CONDITIONAL':raise RuntimeError('probe refused')
    _dump(out,'01_source_lesson.json',lesson)
    _dump(out,'02_probe_certificate.json',cert)
    t=np.linspace(0.,.7,141)
    force=.105*(np.sin(8.3*t+.7)+.35*np.sin(19.7*t+.21))
    initial=(.0035+.0003*np.sin(.7),.012)
    camera=Sense('camera','sight','mm',(1000.,0.),0.,.15,'B_synthetic_camera_calibration')
    request={'experiment_id':'B_blind_unseen','target_body':B.__dict__,
             'senses':{'camera':camera.__dict__},'times_s':t.tolist(),
             'applied_force_n':force.tolist(),'initial_state_m_m_s':list(initial),
             'displacement_reference_m':ref}
    _dump(out,'03_request_before_outcome.json',request)
    forecast=seal_future_sensations(lesson,B,{'camera':camera},times_s=t,force_n=force,
                 initial_state=initial,displacement_reference_m=ref,
                 probe_certificate=cert,experiment_id=request['experiment_id'])
    if forecast['status']!='SEALED_FUTURE_SENSATIONS':raise RuntimeError('forecast refused')
    _dump(out,'04_SEALED_BEFORE_OUTCOME.json',forecast)
    # Below this line, and ONLY now, synthesize hidden target response.
    hidden_truth=simulate_future(B,t,force,initial,beta=target_beta,displacement_reference_m=ref)
    measured={'camera':(1000.*hidden_truth[:,0]+rng.normal(0.,camera.noise_std,len(t))).tolist()}
    reveal_input={'experiment_id':'B_blind_unseen','measurement_origin':'SIMULATED','observed_by_sensor':measured}
    _dump(out,'05_outcome_generated_after_seal_SIMULATED.json',reveal_input)
    receipt=score_future_reveal(forecast, measured,measurement_origin='SIMULATED',
                                  experiment_id=request['experiment_id'])
    if not verify_reveal_receipt(receipt,forecast,measured):raise RuntimeError('receipt invalid')
    _dump(out,'06_signed_reveal_receipt.json',receipt)
    posterior=combine_source_and_probe(lesson,B,cert['payload']['measured_episode'],ref,certificate=cert)
    local=simulate_future(B,t,force,initial,beta=posterior['local_only_coefficient'],displacement_reference_m=ref)
    source=simulate_future(B,t,force,initial,beta=posterior['source_only_coefficient'],displacement_reference_m=ref)
    baseline=simulate_future(B,t,force,initial,beta=0.,displacement_reference_m=ref)
    summary={'origin':'SIMULATED_ONLY','real_hardware_trials':0,'meta_authenticated_calls':0,
       'forecast_hash':forecast['sha256'],'receipt_hash':receipt['receipt_sha256'],
       'sealed_adaptation':forecast['payload']['adaptation']['status'],
       'predicted_coefficient':forecast['payload']['dimensionless_coefficient'],
       'target_beta_hidden_until_after_forecast':target_beta,
       'signed_forecast_rmse_mm_vs_noiseless_truth':rmse_camera(np.asarray(forecast['payload']['predicted_state_m_m_s']),hidden_truth),
       'comparators_same_target_probe':{
           'physics_no_mechanism_rmse_mm':rmse_camera(baseline,hidden_truth),
           'source_only_rmse_mm':rmse_camera(source,hidden_truth),
           'target_only_rmse_mm':rmse_camera(local,hidden_truth)},
       'source_experiments':3,'target_probe_experiments':1,
       'important_limitation':'Source knowledge gets three independent source experiments; no real-world chronological evidence or Meta advantage'}
    _dump(out,'07_result_and_fair_baselines.json',summary)
    return summary


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',default='demo/v081_prospective')
    parser.add_argument('--seed',type=int,default=2026)
    parser.add_argument('--target-beta',type=float,default=.244)
    args=parser.parse_args()
    print(json.dumps(run(args.out,seed=args.seed,target_beta=args.target_beta),indent=2))
