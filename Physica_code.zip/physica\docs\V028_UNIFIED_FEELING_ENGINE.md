# Physica v0.28 — shared physical feeling, inquiry and evidence

## What is new

This release **preserves v0.27's 1D Feel → Experience → Curiosity → Discover → Experiment → Learn → Transfer workflow** and adds a shared `FeltExperience` record for three applications:

- **Printer**: inferred ringing frequency, damping, video-pixel ringing, and matched before/after repeats. `touch.printer_video.check` remeasures the recording frame clock and can provide exploratory bootstrap intervals over ringing windows. This is not a force measurement or proof a print got better.
- **Turbine**: blade-mode residuals, thermal context and uncertainty. Historical false negatives for cracks are preserved. **ALL turbine results remain industrial advisory; never use this software to restart, operate or clear a turbine.** A `weather only` classifier result is NOT permission to operate.
- **F1**: estimated aerodynamic and vehicle-dynamics quantities, with explicit status as **inferred**, not sensors that directly measure downforce or grip. Archived evaluation files are not independently recomputed here.

One *method* spans the three fields, **not a universal physical law or general learned representation**. Numerical fitting and falsification must remain domain-specific.

## Shared evidence contract

`physica/unified/schema.py` distinguishes measured, inferred and simulated quantities, units, sources, calibration references, and `train`/`validation`/`test` data splits. Numeric surprise requires both observation and model uncertainty and a calibration hash; missing values produce **can't tell**, not confidence theater. SHA256 is integrity protection, **not proof of an external timestamp or accuracy of calibration**.

`physica/unified/engine.py` computes prediction discrepancies, refuses uncalibrated certainty, proposes domain-appropriate *review-only* next measurements and optionally ranks pre-approved, calibrated rival-experiment forecasts by expected information gain. Ranking requires the operator's rival hypotheses and likelihood scales; it does **not discover those likelihoods for free**.

`physica/unified/field.py` is a strict CSV bridge: separate observation and forecast files, monotonic timestamps and matching forecast/observation sample times in this simplified single-signal format (control schedules require separate experimental verification), a calibration JSON and optional forecast hash commitment. It reports conservative average sensory innovation and trajectory RMSE. Prediction commitments need independent external witnessing to establish real chronology.

## What Meta can do

There are two related but distinct ways to use Meta:

1. Existing **v0.27 1D real scientific investigation**, with authenticated Wonder → Spark → Wonder and bounded numerical expression-fitting. You need calibrated 1D mechanical episodes (x, v, u, acceleration), the source/target manifests, actual measurements and your locally stored key. The original runbook explains this.
2. New **v0.28 cross-domain scientific council** (`physica.unified.meta.run_domain_research_council`): training-only `FeltExperience` → Muse Wonder proposes up to three falsifiable mechanisms → Spark criticizes → Wonder revises → receive source-bound API receipts. Domain-specific physical models must test the proposals. The council **does not** use the 1D equation fitter on F1 or turbine data or claim verified discovery merely because three models were consulted.

The existing Muse council prompt no longer hints at the simulator's hidden equation. Structured replies are retried once if parsing fails; invalid responses in the full v0.27 investigation are recorded as a science abstention. API retries may incur costs; set `PHYSICA_BUDGET_USD` locally. No API key is bundled or needed for offline demos.

### Local startup

```powershell
python -m pip install -e ".[dev]"
python -m physica.studio --open-browser
```

Navigate to **http://127.0.0.1:8765/feel** for the shared physical feeling workbench. It never calls paid APIs or actuates machinery.

### Use supported legacy JSON reports

```powershell
python -m physica.unified.cli --domain printer --input examples/unified_v028/printer_before_SIMULATED.json --after examples/unified_v028/printer_after_SIMULATED.json --simulated --out demo/printer_felt.json
python -m physica.unified.cli --domain turbine --input examples/unified_v028/turbine_ILLUSTRATIVE_FALSE_NEGATIVE.json --simulated --out demo/turbine_felt.json
python -m physica.unified.cli --domain f1 --input eval/results/E24_f1_race_engineer.json --car-id 44 --out demo/f1_felt.json
```

The F1 file is an **archived real-telemetry evaluation report whose raw underlying datasets are not bundled**. The new output uses `dataset_origin=unknown` absent a supplied raw recording SHA256.

### Use real recorded signals

Put a `manifest.json`, calibration JSON, observed sensor CSV, and forecast CSV in the **same field experiment folder**. See `examples/unified_v028/field_manifest_SIMULATED.json` and its tiny **simulation** files for the exact schema. In the real case use instrument documentation, aligned timestamps and independently retained raw files.

```powershell
python -m physica.unified.cli --field-manifest --input examples/unified_v028/field_manifest_SIMULATED.json --out demo/field_felt.json
```

If you have a forecast hash receipt with `forecast_sha256` and `system_id`, add its filename under `forecast_commit` in the manifest. The tool checks that receipt matches the sealed forecast bytes; **a local hash by itself does not establish that a forecast preceded the test**.

### Run live Muse with your own key

```powershell
$env:MODEL_API_KEY = "YOUR_PRIVATE_KEY"
$env:MOCK = "0"
$env:PHYSICA_BUDGET_USD = "5"
python -m physica.frontier.meta_ready_v026 doctor
python -m physica.frontier.meta_ready_v026 live-smoke --role wonder --allow-billed-meta
python -m physica.unified.cli --field-manifest --input REAL_FIELD_FOLDER/manifest.json --live-meta --allow-billed-meta --out demo/live_muse_inquiry.json
```

The third command **requires `evidence_split=train`** and makes potentially billable live Meta calls. It outputs **unverified** hypotheses and possible observations, not a scientific discovery. Validate proposed mechanisms against separate held-out experiments. The legacy one-dimensional scientific loop remains available in `physica.frontier.feeling_discovery_loop_v027`.

## Remaining scientific limitations

- No authenticated Meta API run or real sensor experiment was executed during development here.
- The shared domain adapters do **not** automatically compile Muse's F1/turbine suggestions into new physical models or run real interventions.
- Real-data raw archives for historical E20/E24 examples were not in the distribution; do not claim those were independently reproduced by this version.
- An AI cannot infer calibration, missing hidden variables, damage or physical causality merely by producing confident text.
- The optical printer uncertainty intervals assume repeated video windows; those are correlated and **not formal frequentist coverage guarantees**.
- Unknown machines, autonomous industrial controls and full glasses integration remain out of scope.
- A scientific breakthrough needs independent, preregistered prospective experiments against baselines with an explicit failure rate and fair experimental budget.
