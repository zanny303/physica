"""physica meta: status | doctor | ask | scientist | sam | senses | freeze   (live calls need MOCK=0 and MODEL_API_KEY)."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from physica.llm import meta_client as mc


def _tiny_video(path: Path) -> Path:
    import cv2
    import numpy as np

    w = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 30, (320, 240))
    for k in range(60):
        f = np.zeros((240, 320, 3), np.uint8)
        y = int(120 + 40 * np.sin(2 * np.pi * k / 30))
        cv2.rectangle(f, (140, y - 15), (180, y + 15), (255, 255, 255), -1)
        w.write(f)
    w.release()
    return path


def _moving_square(path: Path) -> Path:
    """Long and large enough for Muse: Meta advises more than a few seconds at 448 pixels or more."""
    import cv2
    import numpy as np

    w = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 30, (640, 480))
    for k in range(240):
        f = np.full((480, 640, 3), 30, np.uint8)
        x = int(320 + 120 * np.sin(2 * np.pi * k / 120))
        cv2.rectangle(f, (x - 50, 190), (x + 50, 290), (255, 255, 255), -1)
        w.write(f)
    w.release()
    return path


def doctor() -> dict:
    """Three small live calls (a few cents at most): Spark answers, Wonder calls a tool, SAM tracks a square."""
    out = {"status": mc.status()}
    if mc.is_mock():
        out["verdict"] = "MOCK mode: set MOCK=0 and MODEL_API_KEY in your terminal (not in the repo) to run live."
        return out
    try:
        r = mc.complete("spark", [{"role": "user", "content": "Reply with exactly: PHYSICA OK"}], task="doctor_spark",
                        max_completion_tokens=2000)
        out["spark"] = {"ok": "OK" in (r["content"] or ""), "said": r["content"], "mode": r["mode"]}
    except Exception as e:
        out["spark"] = {"ok": False, "error": str(e)[:300]}
    try:
        tool = [{"type": "function", "function": {"name": "feel_tone", "description": "Return the tone of a body",
                                                  "parameters": {"type": "object", "properties": {"body": {"type": "string"}},
                                                                 "required": ["body"], "additionalProperties": False}}}]
        r = mc.complete("wonder", [{"role": "user", "content": "Use the tool to feel the tone of the ruler."}],
                        task="doctor_wonder", tools=tool, tool_choice="auto", max_completion_tokens=2000)
        out["wonder"] = {"ok": bool(r["tool_calls"]), "tool_calls": r["tool_calls"], "mode": r["mode"]}
    except Exception as e:
        out["wonder"] = {"ok": False, "error": str(e)[:300]}
    try:
        p = _tiny_video(mc.config.STATE_DIR / "doctor_square.mp4")
        r = mc.sam_video(p, "white square", n_frames=60, task="doctor_sam")
        out["sam"] = {"ok": len(r["frames"]) > 0, "frames_with_boxes": len(r["frames"])}
    except Exception as e:
        out["sam"] = {"ok": False, "error": str(e)[:300]}
    out["receipts_dir"] = str(mc.RECEIPTS)
    return out


def preflight() -> dict:
    """Before filming: one fresh call for each Meta step the demo uses. Says pass or fail for each, and what it cost."""
    import json as _json

    from physica.touch import printer_muse as PM
    if mc.is_mock():
        return {"ready": False, "checks": {}, "say": "No live key in this window: set it first"}
    before = mc.status().get("spent_usd", 0.0)
    checks = {}

    def run(name, fn):
        try:
            detail = fn()
            checks[name] = {"pass": True, "detail": detail}
        except Exception as e:
            checks[name] = {"pass": False, "detail": str(e)[:240]}

    def spark():
        got, _ = PM._ask("spark", "Reply with the JSON the schema asks for.", "Is 2+2 equal to 4?", "preflight_spark", PM._schema("Preflight", {"yes": {"type": "boolean"}}))
        if got.get("yes") is not True:
            raise RuntimeError("wrong answer")
        return "answered"

    def wonder_tool():
        tool = [{"type": "function", "function": {"name": "feel_tone", "description": "Return the tone of a body", "parameters": {
            "type": "object", "properties": {"body": {"type": "string"}}, "required": ["body"], "additionalProperties": False}}}]
        r = mc.complete("wonder", [{"role": "user", "content": "Use the tool to feel the tone of the ruler."}], "preflight_wonder_tool", tools=tool, tool_choice="auto",
                        max_completion_tokens=16000, require_fresh=True)
        if not r.get("tool_calls"):
            raise RuntimeError("it didn't call the tool")
        return "called a tool"

    def sees():
        import base64

        import cv2
        import numpy as np
        img = np.full((240, 320, 3), 40, np.uint8)
        img[60:180, 100:220] = (0, 0, 255)
        url = "data:image/jpeg;base64," + base64.b64encode(cv2.imencode(".jpg", img)[1].tobytes()).decode()
        got, _ = PM._ask("wonder", "Reply with the JSON the schema asks for.", PM._parts("What colour is the square?", [("Picture:", url)]), "preflight_vision", PM._schema("PreflightSee", {"colour": {"type": "string"}}))
        if "red" not in str(got.get("colour", "")).lower():
            raise RuntimeError(f"said {got.get('colour')}")
        return "saw a red square"

    def sam():
        p = _tiny_video(mc.config.STATE_DIR / "doctor_square.mp4")
        r = mc.sam_video(p, "white square", n_frames=60, task="preflight_sam")
        if not r["frames"]:
            raise RuntimeError("no boxes")
        return f"found it in {len(r['frames'])} frames"

    def ideas():
        sample = {"change": {"verdict": "changed", "tone_now_hz": 38.5, "tone_baseline_hz": 41.7, "reason": "SAMPLE NUMBERS, NOT A REAL FILM: the tone fell 3.2 Hz"}}
        got = PM.propose(sample)
        return f"{got['proposed']} proposed, {len(got['rivals'])} testable after Spark's challenge"

    def watches():
        from physica.meta import scout as SC
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            clip = SC.muse_clip(_moving_square(Path(d) / "square.mp4"), Path(d) / "watch.mp4")
            part = mc.video_part(clip)
        r = mc.respond("spark", [{"role": "user", "content": [{"type": "input_text", "text": "Watch this film. In a few words, what shape moves, and which way?"}, part]}], "preflight_video", media_usd=0.05, effort="low")
        if not r.get("content"):
            raise RuntimeError(f"no reply about the film: {r.get('empty_why')}")
        return f"watched it and said: {r['content'][:90]}"

    def masks():
        from physica.meta import scout as SC
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            c = SC.sam_clip(_moving_square(Path(d) / "square.mp4"), Path(d) / "sam.mp4", most_frames=60)
            prompt, ids = SC.point_prompt({"square": (int(c["w"] / 2), int(c["h"] / 2))}, c["w"], c["h"])
            r = mc.sam_text(c["path"], prompt, {"propagation_direction": "forward"}, c["frames"], "preflight_sam_points")
        frames = SC.parse_masks(r["text"])
        if not frames:
            raise RuntimeError("no masks came back")
        rec = next(iter(frames.values())).get("1") or {}
        if rec is None or "mask" not in rec:
            raise RuntimeError("no mask for the point")
        return f"masks on {len(frames)} frames, raster {rec['mask'].shape[0]} by {rec['mask'].shape[1]}"

    def keeps_going():
        tool = [{"type": "function", "function": {"name": "feel_tone", "description": "Return the tone of a body", "parameters": {
            "type": "object", "properties": {"body": {"type": "string"}}, "required": ["body"], "additionalProperties": False}}}]
        r = mc.respond("wonder", [{"role": "user", "content": [{"type": "input_text", "text": "Use the tool to feel the tone of the ruler, then tell me the number."}]}], "preflight_responses_tool", tools=tool, max_output_tokens=8000, effort="low")
        if not r.get("tool_calls"):
            raise RuntimeError("it didn't call the tool")
        out = [{"type": "function_call_output", "call_id": c["id"], "output": _json.dumps({"tone_hz": 13.2})} for c in r["tool_calls"]]
        r2 = mc.respond("wonder", out, "preflight_responses_tool", tools=tool, previous_response_id=r["response_id"], max_output_tokens=8000, effort="low")
        if "13.2" not in (r2.get("content") or ""):
            raise RuntimeError("it didn't use the tool's result")
        return "kept its place across a tool call"

    film_checks = {"Muse watches a real video": watches, "Muse keeps reasoning across tools (Responses)": keeps_going, "SAM returns masks from a point": masks}
    run("Muse Spark answers in the required format", spark)
    run("Muse Wonder calls a tool", wonder_tool)
    run("Muse Wonder reads a picture", sees)
    run("SAM 3.1 tracks an object in video", sam)
    run("Muse proposes and Spark challenges printer causes", ideas)
    ready = all(c["pass"] for c in checks.values())
    for name, fn in film_checks.items():
        run(name, fn)
    return {"ready": ready, "film_path_ready": all(checks[n]["pass"] for n in film_checks), "checks": checks, "cost_usd": round(mc.status().get("spent_usd", 0.0) - before, 4)}


def main(argv=None):
    ap = argparse.ArgumentParser(prog="physica meta", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status")
    sub.add_parser("doctor")
    sub.add_parser("preflight", help="one live test of every Meta step in the demo, before you film")
    a = sub.add_parser("ask")
    a.add_argument("question")
    sub.add_parser("scientist")
    ev = sub.add_parser("evolve", help="Meta writes new senses; real beams judge them (E19)")
    ev.add_argument("--generations", type=int, default=4)
    ev.add_argument("--n", type=int, default=8)
    ev.add_argument("--swarm", type=int, default=1)
    s = sub.add_parser("sam")
    s.add_argument("video")
    s.add_argument("--concept", required=True)
    s.add_argument("--sense", action="store_true", help="then feel the first tracked object only")
    s.add_argument("--fps", type=float)
    sc = sub.add_parser("scout", help="from one film, nothing typed: Muse looks, SAM pins, Physica feels")
    sc.add_argument("video")
    sc.add_argument("--fps", type=float)
    sc.add_argument("--out", default=None)
    sc.add_argument("--allow-billed-meta", action="store_true")
    st = sub.add_parser("scout-test", help="the same films with Muse, SAM or Physica removed, one at a time")
    st.add_argument("folder", nargs="?", default="scout")
    st.add_argument("--show", action="store_true", help="reprint the table from saved results. No calls")
    st.add_argument("--preview", action="store_true", help="check the films and boxes, and print the sealed rules. No calls")
    st.add_argument("--allow-billed-meta", action="store_true")
    cs = sub.add_parser("cases", help="real footage from the internet, with published or known answers")
    cs.add_argument("--case", choices=["tacoma", "guitar"], default=None)
    cs.add_argument("--folder", default=None)
    cs.add_argument("--allow-billed-meta", action="store_true")
    sub.add_parser("freeze")
    t = sub.add_parser("senses", help="score Muse with and without Physica's senses on real blade cases")
    t.add_argument("--per-class", type=int, default=12)
    t.add_argument("--seed", type=int, default=2028)
    t.add_argument("--role", choices=["spark", "wonder"], default="spark")
    t.add_argument("--include-verdict", action="store_true", help="also show Muse Physica's own verdict")
    t.add_argument("--allow-billed-meta", action="store_true", help="make the live calls (without it: free preview)")
    t.add_argument("--show", action="store_true", help="free: print the saved result, with Physica + Muse as a reviewer")
    t.add_argument("--both", action="store_true", help="with --show: both runs together, with no case counted twice")
    t.add_argument("--confirm", action="store_true", help="the same test on cases the first run never used, with the reviewer rule already fixed")
    t.add_argument("--retry-no-answer", action="store_true", help="ask again only where Muse gave no usable reply, with more room. The first run is kept")
    t.add_argument("--resume", action="store_true", help="keep answers already saved by an interrupted run")
    t.add_argument("--out", default=None)
    args = ap.parse_args(argv)
    if args.cmd == "status":
        print(json.dumps(mc.status(), indent=1))
    elif args.cmd == "doctor":
        print(json.dumps(doctor(), indent=1, default=str))
    elif args.cmd == "ask":
        from physica.meta import agent

        r = agent.ask(args.question)
        print(f"[{r['mode']} | {r['model']}]")
        for t in r["trace"]:
            print(f"  tool {t['tool']}({json.dumps(t['args'])[:120]})")
        print(r["answer"])
    elif args.cmd == "scientist":
        sys.path.insert(0, str(mc.config.REPO_ROOT))
        from eval import e18_new_cause

        e18_new_cause.main()
    elif args.cmd == "evolve":
        sys.path.insert(0, str(mc.config.REPO_ROOT))
        from eval import e19_evolve_sense

        e19_evolve_sense.main(args.generations, args.n, args.swarm)
    elif args.cmd == "sam":
        from physica.meta.sam import object_boxes

        r = mc.sam_video(args.video, args.concept)
        boxes = object_boxes(r["frames"])
        print(json.dumps({"objects": {k: [round(v, 1) for v in b] for k, b in boxes.items()},
                          "frames": len(r["frames"])}, indent=1))
        if args.sense and boxes:
            import cv2

            from physica.meta.sam import box_mask  # noqa: F401
            from physica.sense import sense

            cap = cv2.VideoCapture(args.video)
            W, H = cap.get(cv2.CAP_PROP_FRAME_WIDTH), cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            any_rec = next(iter(r["frames"].values()))[0]
            sw, sh = any_rec["size"] if any_rec["size"][0] else (W, H)
            x1, y1, x2, y2 = next(iter(boxes.values()))
            region = (x1 * W / sw, y1 * H / sh, x2 * W / sw, y2 * H / sh)
            out = sense(args.video, fps=args.fps, region=region)
            print("\n".join(out["summary"]))
    elif args.cmd == "preflight":
        r = preflight()
        for name, c in r["checks"].items():
            print(f"  {'PASS' if c['pass'] else 'FAIL'}  {name}: {c['detail']}")
        print("READY" if r["ready"] else (r.get("say") or "NOT READY: send the failed line to get it fixed"))
        if r["ready"] and not r.get("film_path_ready"):
            print("The film path isn't ready, so Muse would get photos only. Send the failed line to get it fixed.")
        if "cost_usd" in r:
            print(f"Cost by Meta's published prices: about ${r['cost_usd']}")
    elif args.cmd == "scout":
        if not args.allow_billed_meta:
            raise SystemExit("This makes live Meta calls: Muse twice, SAM once. Add --allow-billed-meta to run it.")
        from physica.meta import scout as SC
        r = SC.scout(args.video, args.fps, Path(args.video).with_suffix("").as_posix() + "_scout")
        out = Path(args.out or Path(args.video).with_suffix(".scout.json"))
        out.write_text(json.dumps(r, indent=1, default=float))
        print(f"\nCost ${r['usd']}. Words typed: {r['typed_words']}. Saved {out}. Check any tone against a second reading before you trust it.")
    elif args.cmd == "cases":
        from physica.meta import cases as CS
        r = CS.run(args.folder or CS.CLIPS, args.allow_billed_meta, only=args.case)
        print(f"\nSaved {CS.OUT}. {'Live Muse and SAM calls were made.' if args.allow_billed_meta else 'No Meta calls. Add --allow-billed-meta to bring in Muse and SAM.'}")
    elif args.cmd == "scout-test":
        from physica.meta import scout_test as T
        if args.show:
            if not T.OUT.exists():
                raise SystemExit("no saved run yet")
            print(T.show(json.loads(T.OUT.read_text())))
            return
        manifest_path = Path(args.folder) / "scout_manifest.json"
        if not manifest_path.exists():
            raise SystemExit(f"{manifest_path} is missing. Draw each box first on the /try/box page, which writes this file")
        manifest = json.loads(manifest_path.read_text())
        missing = [k for k in manifest["films"] if not (Path(args.folder) / k).exists()]
        if missing:
            raise SystemExit(f"films not found: {missing}")
        print(f"{len(manifest['films'])} machines. Rules, fixed before any call:")
        for r in T.RULES:
            print(f"  {r['claim']}: {r['must_hold']}.")
        if args.preview or not args.allow_billed_meta:
            print("Nothing was sent. Add --allow-billed-meta to run it. Expect about $1 to $3.")
            return
        res = T.run(args.folder, manifest)
        print("\n" + T.show(res))
    elif args.cmd == "senses":
        from physica.meta import senses_test as ST

        if args.show and args.both:
            read = lambda p: json.loads(p.read_text()) if p.exists() else None  # noqa: E731
            both = ST.pooled(read(ST.RESULTS), read(ST.CONFIRM))
            if not both:
                raise SystemExit("No completed run to show yet")
            ST.show(both)
            return
        if args.show:
            target = Path(args.out or (ST.CONFIRM if args.confirm else ST.RESULTS))
            if not target.exists():
                raise SystemExit(f"No saved result at {target}")
            ST.show(ST.with_review(json.loads(target.read_text())))
            return
        if args.confirm:
            if not ST.RESULTS.exists():
                raise SystemExit("Run the first test before confirming it")
            used = {r["id"] for r in json.loads(ST.RESULTS.read_text())["rows"]}
            ST.show(ST.run(per_class=args.per_class, seed=2029, role=args.role, include_verdict=args.include_verdict, allow_billed_meta=args.allow_billed_meta,
                           resume=args.resume, retry_no_answer=args.retry_no_answer, out=args.out or ST.CONFIRM, exclude=used))
            return
        ST.show(ST.run(per_class=args.per_class, seed=args.seed, role=args.role, include_verdict=args.include_verdict,
                       allow_billed_meta=args.allow_billed_meta, resume=args.resume or args.retry_no_answer, retry_no_answer=args.retry_no_answer, out=args.out or ST.RESULTS))
    elif args.cmd == "freeze":
        print("copied", mc.freeze_for_replay(), "cached answers into replay/llm/")


if __name__ == "__main__":
    main()
