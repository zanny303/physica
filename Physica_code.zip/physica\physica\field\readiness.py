"""Independent measurement preflight for real Physica experiments.

This is a *gate*, not a demonstration of accuracy. It rejects missing time,
calibration, sensor-unit, chronology, and physical provenance evidence.
It never substitutes simulated sensor values or invokes actuators.
"""
from __future__ import annotations
import csv
from datetime import datetime
import hashlib
import importlib.util
import json
from math import isfinite, pi, sqrt
import os
from pathlib import Path
import statistics

REQUIRED_COLUMNS = ('time_s', 'displacement_m', 'force_n')


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def _finite_positive(value, label):
    try:
        v = float(value)
    except (TypeError, ValueError):
        raise ValueError(f'{label}: positive finite number required') from None
    if not isfinite(v) or v <= 0:
        raise ValueError(f'{label}: positive finite number required')
    return v


def _sha_form(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def _utc(value, label):
    if not isinstance(value, str):
        raise ValueError(f'{label}: UTC ISO timestamp required')
    try:
        dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError:
        raise ValueError(f'{label}: invalid ISO timestamp') from None
    if dt.utcoffset() is None or dt.utcoffset().total_seconds() != 0:
        raise ValueError(f'{label}: timezone-aware UTC timestamp required')
    return dt


def _read_csv(path: Path):
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open(newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or any(name not in reader.fieldnames for name in REQUIRED_COLUMNS):
            raise ValueError('CSV requires time_s,displacement_m,force_n in SI units')
        if any(col not in (*REQUIRED_COLUMNS, 'velocity_m_s', 'audio_pressure_pa') for col in reader.fieldnames):
            raise ValueError('unexpected CSV fields; avoid silently confusing sensor units')
        rows = list(reader)
    if len(rows) < 25:
        raise ValueError('25+ synchronized samples are required')
    cols = {}
    for col in reader.fieldnames:
        try:
            vals = [float(r[col]) for r in rows]
        except (TypeError, ValueError):
            raise ValueError(f'{col}: nonnumeric or missing measurement') from None
        if not all(isfinite(x) for x in vals):
            raise ValueError(f'{col}: NaN/infinite measurements rejected')
        cols[col] = vals
    return cols


def validate_field_trial(meta_path, csv_path, *, video_path=None):
    """Produce a cautious report. `ready` means *measurable*, not *correct*.

    Exact requested evidence is never synthesized. A successful preflight is
    still NOT a proof that a predictive model will fit this system.
    """
    mp = Path(meta_path)
    cp = Path(csv_path)
    meta = json.loads(mp.read_text(encoding='utf-8'))
    if not isinstance(meta, dict):
        raise ValueError('metadata must be an object')
    data = _read_csv(cp)
    errors = []
    warnings = []
    def require(ok, explanation):
        if not ok:
            errors.append(explanation)
    require(meta.get('schema') == 'physica.real-field.v1', 'incorrect field metadata schema')
    require(meta.get('origin') == 'REAL_MEASUREMENT', 'simulation or unknown origin is not real evidence')
    require(meta.get('human_authorized') is True, 'human experiment authorization missing')
    for name in ('experiment_id', 'machine_id', 'boundary_class'):
        require(isinstance(meta.get(name), str) and bool(meta.get(name).strip()), f'missing {name}')
    calibration = meta.get('calibration', {})
    require(isinstance(calibration, dict), 'calibration record missing')
    calibration = calibration if isinstance(calibration, dict) else {}
    for key in ('displacement', 'force'):
        c = calibration.get(key, {})
        require(isinstance(c, dict) and c.get('origin') == 'independent_fixture' and
                isinstance(c.get('id'), str) and bool(c['id'].strip()),
                f'{key}: independently recorded sensor calibration required')
        require(isinstance(c, dict) and c.get('unit') == ('m' if key == 'displacement' else 'N'),
                f'{key}: calibration unit mismatch')
    raw_hash = _sha(cp)
    require(meta.get('raw_sensor_csv_sha256') == raw_hash, 'raw CSV evidence hash mismatch')
    t = data['time_s']
    deltas = [b-a for a,b in zip(t,t[1:])]
    require(t[0] >= 0 and all(dt > 0 for dt in deltas), 'nonmonotonic or negative timestamps')
    if not all(dt > 0 for dt in deltas):
        return {'status':'REFUSE_INCOMPLETE_REAL_DATA', 'errors':errors, 'warnings':warnings,
                'raw_sensor_csv_sha256':raw_hash, 'record_count':len(t), 'hardware_actuation_allowed':False}
    median_dt = statistics.median(deltas)
    jitter = max(abs(dt-median_dt) for dt in deltas)/median_dt
    fs_hz = 1.0/median_dt
    duration_s = t[-1]-t[0]
    if jitter > 0.05:
        errors.append(f'clock/sample spacing variation exceeds 5% ({jitter:.1%})')
    if any(abs(f) > 1e-9 for f in data['force_n']):
        warnings.append('Force is nonzero: use a measured/load-cell-calibrated stimulus, not an estimated tap')
    else:
        warnings.append('Zero-force free decay: initial deflection and release must be separately documented')
    if 'velocity_m_s' not in data:
        warnings.append('No independently measured velocity: avoid claiming nonlinear force-law discovery from noisy position derivatives')
    if 'audio_pressure_pa' not in data:
        warnings.append('No calibrated audio channel: do not claim acoustic/two-sense empirical validation')
    body = meta.get('body')
    frequency_hz = None
    if not isinstance(body, dict):
        errors.append('mass_kg and stiffness_n_m body calibration required')
    else:
        try:
            mass = _finite_positive(body.get('mass_kg'), 'mass_kg')
            stiffness = _finite_positive(body.get('stiffness_n_m'), 'stiffness_n_m')
            frequency_hz = sqrt(stiffness/mass)/(2*pi)
            if fs_hz < 20*frequency_hz:
                errors.append(f'undersampled free vibration: {fs_hz:.1f} Hz sampling < 20x estimated {frequency_hz:.1f} Hz natural frequency')
            if duration_s*frequency_hz < 5:
                warnings.append('Less than 5 nominal oscillation periods recorded; damping estimates may be unreliable')
        except ValueError as e:
            errors.append(str(e))
    chron = meta.get('chronology', {})
    if not isinstance(chron, dict):
        chron = {}
    try:
        sealed_dt = _utc(chron.get('external_sealed_at_utc'), 'external_sealed_at_utc')
        measured_dt = _utc(chron.get('experiment_started_at_utc'), 'experiment_started_at_utc')
        require(sealed_dt < measured_dt, 'forecast was not committed before the experiment')
    except ValueError as e:
        errors.append(str(e))
    require(_sha_form(chron.get('sealed_prediction_sha256')),
            'independent sealed prediction digest missing')
    require(isinstance(chron.get('witness_or_timestamp_service'), str) and bool(chron.get('witness_or_timestamp_service').strip()),
            'independent timestamp/witness record missing (local signature is insufficient)')
    video_digest = None
    if video_path is not None:
        vp=Path(video_path)
        if not vp.is_file() or vp.suffix.lower() not in ('.mp4','.mov'):
            errors.append('requested video missing or unsupported')
        else:
            video_digest=_sha(vp)
            require(video_digest == meta.get('video_sha256'), 'video evidence digest mismatch')
            cam=meta.get('camera', {})
            try:
                _finite_positive(cam.get('meters_per_pixel'), 'camera.meters_per_pixel')
                _finite_positive(cam.get('fps'), 'camera.fps')
            except (AttributeError,ValueError) as e:
                errors.append(str(e))
            require(bool(cam.get('static_reference_track')),
                    'fixed reference required; camera movement must be compensated')
            if not cam.get('clock_synchronized_to_csv'):
                errors.append('camera and CSV clocks not independently synchronized')
    else:
        warnings.append('No video supplied: SAM/visual evidence cannot be established by this preflight')
    metrics={'num_samples':len(t),'duration_s':duration_s,'sampling_rate_hz':fs_hz,
             'sample_spacing_max_relative_jitter':jitter, 'estimated_natural_frequency_hz':frequency_hz,
             'displacement_range_m':[min(data['displacement_m']), max(data['displacement_m'])],
             'max_abs_force_n':max(map(abs,data['force_n']))}
    return {'schema':'physica.field-preflight.v082',
            'status':'READY_FOR_SUPERVISED_VALIDATION' if not errors else 'REFUSE_INCOMPLETE_REAL_DATA',
            'errors':errors,'warnings':warnings,'metrics':metrics,
            'raw_sensor_csv_sha256':raw_hash,'video_sha256':video_digest,
            'real_predictions_verified':False,'meta_calls_verified':False,
            'independent_physics_accuracy_established':False,'hardware_actuation_allowed':False,
            'explanation':'Passing preflight checks evidence integrity and minimum measurement sufficiency; it does not show the physics algorithm succeeds.'}


def meta_contract_preflight(*, include_credential_presence=False):
    """Offline, no billed calls: check SDK readiness and documented adapter assumptions."""
    openai = importlib.util.find_spec('openai') is not None
    parser = importlib.util.find_spec('meta_sam_parser') is not None
    from physica.experience.meta_live import API, SCIENTIST_SCHEMA, DEFAULTS
    schema = SCIENTIST_SCHEMA['schema']
    structured_ok = (SCIENTIST_SCHEMA['type']=='json_schema' and
                     SCIENTIST_SCHEMA.get('strict') is True and
                     schema.get('additionalProperties') is False and
                     set(schema['properties']) == set(schema['required']))
    r = {'schema':'physica.meta-readiness.v082','official_model_api_base':API,
         'models_declared':DEFAULTS,'responses_structured_output_shape_valid':structured_ok,
         'sdk_openai_installed':openai,'sam_official_parser_installed':parser,
         'authenticated_calls_executed':False,'sam_segmentations_verified':False,
         'physical_meta_ablation_passed':False,'will_execute_billable_calls':False,
         'documentation':['https://dev.meta.ai/docs/protocols/responses',
                          'https://dev.meta.ai/docs/sam/client-libraries']}
    if include_credential_presence:
        r['credential_env_present'] = bool(os.getenv('MODEL_API_KEY'))
    return r


def score_sealed_real_trial(meta_path, csv_path, sealed_path, *, video_path=None):
    """Read actual CSV only *after* preflight + signed prediction checks.

    Does not execute experiments or equate an operator-written REAL flag with
    independent proof of provenance; the video/witness must be inspected.
    A deliberately strict first field path supports calibrated displacement in m.
    """
    report=validate_field_trial(meta_path,csv_path,video_path=video_path)
    if report['status'] != 'READY_FOR_SUPERVISED_VALIDATION':
        return {'status':'REFUSE_FAILED_PREFLIGHT','preflight':report}
    sealed=json.loads(Path(sealed_path).read_text(encoding='utf-8'))
    payload=sealed.get('payload',{}) if isinstance(sealed,dict) else {}
    if (sealed.get('status')!='SEALED_FUTURE_SENSATIONS' or
        payload.get('evidence_origin')!='PROSPECTIVE_SENSOR_DATA'):
        return {'status':'REFUSE_NOT_REAL_SEALED_PREDICTION','preflight':report}
    from physica.feeling.prospective_v08 import score_future_reveal, verify_reveal_receipt
    from physica.library import sign
    if not sign.verify(payload,sealed.get('signature_ed25519','')):
        return {'status':'REFUSE_BAD_SIGNATURE','preflight':report}
    meta=json.loads(Path(meta_path).read_text(encoding='utf-8'))
    if meta['experiment_id']!=payload.get('experiment_id'):
        return {'status':'REFUSE_EXPERIMENT_ID_MISMATCH','preflight':report}
    if meta['chronology']['sealed_prediction_sha256']!=sealed.get('sha256'):
        return {'status':'REFUSE_DIFFERENT_FORECAST','preflight':report}
    if meta['machine_id']!=payload.get('body',{}).get('body_id'):
        return {'status':'REFUSE_DIFFERENT_MACHINE','preflight':report}
    raw=_read_csv(Path(csv_path))
    t=raw['time_s']
    predicted_time=payload.get('times_s',[])
    if (len(t)!=len(predicted_time) or
        any(abs((obs-t[0])-expected)>0.25*statistics.median([b-a for a,b in zip(t,t[1:])])
            for obs,expected in zip(t,predicted_time))):
        return {'status':'REFUSE_CLOCK_MISMATCH','preflight':report}
    # No fabricated modality translation. For this conservative field path
    # require one displacement sensor with independently calibrated 1:1 gains.
    senses=payload.get('senses',{})
    if len(senses)!=1:
        return {'status':'REFUSE_UNSUPPORTED_SENSOR_MAPPING','preflight':report}
    sensor_id,sense=next(iter(senses.items()))
    if not (sense.get('unit')=='m' and sense.get('modality')=='sight' and
            list(sense.get('state_gains',[]))==[1.0,0.0] and
            float(sense.get('offset',float('nan')))==0.0 and
            sense.get('calibration_origin')=='independent_fixture'):
        return {'status':'REFUSE_UNSUPPORTED_SENSOR_MAPPING','preflight':report}
    measured={sensor_id:raw['displacement_m']}
    receipt=score_future_reveal(sealed,measured,measurement_origin='REAL_MEASUREMENT',
                                experiment_id=meta['experiment_id'])
    if receipt.get('status')!='MEASURED_AFTER_SEAL' or not verify_reveal_receipt(receipt,sealed,measured):
        return {'status':'REFUSE_REVEAL_VERIFICATION_FAILED','preflight':report}
    return {'status':'SIGNED_REAL_DATA_COMPARISON_COMPUTED',
            'receipt':receipt,'preflight':report,
            'evidence_status':'RAW_CSV_AND_DECLARED_PROVENANCE_VERIFIED_SOFTWARE_ONLY',
            'needs_external_witness_review':True,
            'physical_prediction_validity_established':False,
            'hardware_actuation_allowed':False}


def live_meta_smoke(*, allow_billing=False, role='spark'):
    """Optional real provider smoke test; never pretends to run when offline.

    Verifies request/structured response plumbing only. This is *not* a
    scientific Meta ablation or an end-to-end SAM tracking test.
    """
    if not allow_billing:
        raise PermissionError('explicit --allow-billed-meta required')
    if role not in ('spark','wonder','both'):
        raise ValueError('role must be spark, wonder, or both')
    from physica.experience.meta_live import muse_scientist
    roles=['spark','wonder'] if role=='both' else [role]
    checks=[]
    for model_role in roles:
        reply=muse_scientist({
            'task':'API contract check, NOT an actual physical experiment',
            'recording_provided':False,
            'measurement_provided':False,
            'physical_claim':'no physical hypothesis can be verified',
        }, [], role=model_role)
        checks.append({'role':model_role, 'model_id':reply['model_id'],
                       'request_sha256':reply['request_sha256'],
                       'structured_hypotheses_count':len(reply['reply'].get('hypotheses',[])),
                       'actuation_authority':reply['actuation_authority'],
                       'status':'AUTHENTICATED_API_RETURNED_STRUCTURED_RESPONSE_NOT_PHYSICAL_VALIDATION'})
    return {'status':'LIVE_META_SMOKE_COMPLETED', 'checks':checks,
            'physical_model_improvement_proven':False,
            'sam_tracking_verified':False,
            'scientific_hypothesis_verified':False,
            'hardware_actuation_allowed':False}
