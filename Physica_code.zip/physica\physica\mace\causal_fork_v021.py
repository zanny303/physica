"""v0.21.1: an evidence-sealed, hypothesis-discriminating A -> B -> C simulation.

This is an executable RESEARCH BENCHMARK, not real physical-law discovery,
Meta inference, hardware actuation, or an independently witnessed chronology.
Source A has two validation interventions; targets use different CALIBRATED
simulated sensor packages. All future outcomes are generated after a complete
forecast artifact is durably written. Target-only sees the *same* candidate
family and every target observation the transferred model sees.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
import numpy as np

from .agentic_v013 import KNOWN, search, _collinearity_ok
from .mechanisms import fit, score, validate_term
from .simulation import forecast_without_truth, DT, plan
from .discovery_observatory import _approved_probe_selection
from .unknown_physics import residual_diagnostics

# Deliberately outside the v0.13 fixed sin frequency grid. It is still in the
# declared *expanded* grammar, so recovery is NOT unrestricted discovery.
PHASE = validate_term({'id': 'phase_7_2p5',
    'factors': [{'field':'x','transform':'linear'}, {'field':'v','transform':'linear'}],
    'basis':'sin_linear_combination','phase_weights':[7.,2.5]})
ACTUATIONS = (-.35,-.2,0.,.2,.35)


def _measured_episode(body, seed, episode, *, n=100, fixed_action=None, action_sequence=None):
    """SIMULATOR ONLY. The hidden equation stays in this evidence generator."""
    rng=np.random.default_rng(seed+22451)
    spec=plan(seed,n)
    if action_sequence is not None:
        if fixed_action is not None or len(action_sequence)!=n:raise ValueError('invalid approved action sequence')
        u=np.asarray(action_sequence,dtype=float)
        if not np.isfinite(u).all() or (abs(u)>.65).any():raise ValueError('unapproved action')
    else:
        u=spec['u'].copy() if fixed_action is None else np.full(n,float(fixed_action))
    ambient=spec['temperature_delta']
    # Vary initial conditions so a periodic term cannot be approximated as
    # just stiffness on one narrow trajectory.
    x=.18+.20*np.sin(seed*1.31)
    v=.02+.11*np.cos(seed*.83)
    initial=[float(x),float(v)]
    rows=[]
    for i in range(n):
        a=-.82*x-.34*v+float(u[i])+(body['thermal']*float(ambient[i])/8)*np.tanh(v)
        a+=body['periodic']*np.sin(7*x+2.5*v)
        x_noise=x+rng.normal(0, .00018)
        v_noise=v+rng.normal(0, .00018)
        # Simulated sensors are assumed to have independently supplied correct
        # calibrations; camera/audio readings do not establish such a map in reality.
        if body['sensor']=='camera_imu':
            obs={'camera_m':float(x_noise),'inertial_velocity_mps':float(v_noise),
                 'imu_accel_mps2':float(a+rng.normal(0,.008))}
        else:
            obs={'encoder_m':float(x_noise),'acoustic_speed_proxy':float(.85*v_noise),
                 'imu_accel_mps2':float(a+rng.normal(0,.008))}
        rows.append({'body_id':body['id'],'episode_id':episode,'intervention_type':'controlled',
           't':float(i*DT),'x':float(x_noise),'v':float(v_noise),
           'u':float(u[i]),'temperature_delta':float(ambient[i]),
           'acceleration':float(a+rng.normal(0,.009)),
           'sensors':obs})
        v+=DT*a;x+=DT*v
    return {'initial':initial,'rows':rows,'action':u.tolist(),
            'temperature_delta':ambient.tolist(),'dt':DT}


def _extended_phase_library():
    """Same source/target mathematical capacity; no knowledge of truth passed."""
    for wx in [float(i) for i in range(1,9)]:
        for wv in [0.,.5,1.,1.5,2.,2.5,3.]:
            factors=[{'field':'x','transform':'linear'}];weights=[wx]
            if wv:
                factors.append({'field':'v','transform':'linear'});weights.append(wv)
            yield validate_term({'id':f'extended_{int(wx)}_{str(wv).replace(".","p")}',
                    'factors':factors,'basis':'sin_linear_combination','phase_weights':weights})

EXTENDED=tuple(_extended_phase_library())


def _rank_terms(train, validation, *, candidates=EXTENDED, min_gain=.12):
    """Select from predeclared grammar on disjoint validation episodes only."""
    known=fit(train,KNOWN); base_score=score(validation,known)
    groups={}
    for r in validation:groups.setdefault(r['episode_id'],[]).append(r)
    best=None;leaderboard=[]
    for term in candidates:
        try:
            if not _collinearity_ok(train,KNOWN+[term]):continue
            model=fit(train,KNOWN+[term]);err=score(validation,model)
            episodes=[score(group,model)<score(group,known)*.96 for group in groups.values()]
            gain=(base_score-err)/max(base_score,1e-12)
            if all(episodes) and gain>=min_gain:
                leaderboard.append((err,term,model))
                if best is None or err<best[0]:best=(err,term,model)
        except (ValueError,OverflowError,FloatingPointError,np.linalg.LinAlgError):pass
    leaderboard.sort(key=lambda t:t[0])
    return {'model':best[2] if best else known,'term':best[1] if best else None,
            'validation_rmse':float(best[0] if best else base_score),
            'known_validation_rmse':float(base_score),
            'ranked':[{'term':a[1]['id'],'rmse':float(a[0])} for a in leaderboard[:8]],
            'candidates_available':len(candidates)}


def _target_models(local, validation, source_term):
    """Equal target data and FULL expanded grammar in both competing arms.

    Selection is made on a separate target validation episode; both arms are
    then refit on precisely the same local+validation+probe measurements.
    """
    blind=_rank_terms(local,validation, min_gain=.08)
    if source_term is not None:
        source=fit(local,KNOWN+[source_term])
        s_score=score(validation,source)
        l_score=score(validation,blind['model'])
        use_source=bool(s_score < l_score*.985)
        source_validation=float(s_score)
    else:
        use_source=False;source_validation=None
    return {'blind_term':blind['term'],'source_term':source_term,'accepted':use_source,
        'blind_validation_rmse':blind['validation_rmse'],
        'source_validation_rmse':source_validation,
        'decision':'SOURCE_STRUCTURE' if use_source else 'REFUSE_TRANSFER',
        'all_candidate_terms_accessible_to_local_baseline':True}


def _payload_digest(payload):
    return hashlib.sha256(json.dumps(payload,sort_keys=True,allow_nan=False,
                                      separators=(',',':')).encode('utf-8')).hexdigest()


def verify_receipt(path):
    """Check content only, not independent time or authenticity."""
    record=json.loads(Path(path).read_text(encoding='utf-8'))
    return bool(record.get('digest_sha256')==_payload_digest(record['frozen']))


def _write(path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2,sort_keys=True,allow_nan=False),encoding='utf-8')


def _safe_forecast(model, initial, action, ambient):
    try:
        return forecast_without_truth(model,initial,
                       {'dt':DT,'u':action,'temperature_delta':ambient})
    except (ValueError,OverflowError,FloatingPointError):return None


def _series_rmse(expected,actual, sensor):
    if expected is None:return None
    key='camera_m' if sensor=='camera_imu' else 'audio_m_per_s'
    # model returns x and .85*v; compare against independent noisy physical
    # measurement, not the simulator's latent ground-truth state.
    observed=[r['sensors']['camera_m' if sensor=='camera_imu' else 'acoustic_speed_proxy']
              for r in actual['rows'][1:]]
    predicted=[r[key] for r in expected[:len(observed)]]
    if len(predicted)!=len(observed):return None
    return float(np.sqrt(np.mean((np.asarray(predicted)-np.asarray(observed))**2)))


def run(out, *, seed=2026, source_mode='source_search', meta_model='muse-spark-1.3', allow_billed=False):
    if source_mode not in ('source_search','human_nominee','no_new_mechanism','live_meta'):
        raise ValueError('unknown source discovery mode')
    if not isinstance(seed,int) or seed<0 or seed>10_000_000:raise ValueError('bad seed')
    if source_mode=='live_meta' and not allow_billed:
        raise PermissionError('Explicit approval required for billed Meta inference')
    if source_mode!='live_meta' and allow_billed:
        raise ValueError('Offline mode must not authorize billed Meta inference')
    if meta_model not in ('muse-spark-1.3','muse-wonder-1.0'):
        raise ValueError('unsupported Meta model')
    root=Path(out);root.mkdir(parents=True,exist_ok=True)
    source={'id':'A','thermal':.78,'periodic':.43,'sensor':'camera_imu'}
    # Only TRAIN and TWO validation episodes are created before discovering.
    train=sum((_measured_episode(source,seed+i,'A_training_'+str(i),n=90)['rows'] for i in range(3)),[])
    validation=sum((_measured_episode(source,seed+10+i,'A_validation_'+str(i),n=75)['rows'] for i in range(2)),[])
    fixed=search(train,validation,max_candidates=90,min_gain=.1)
    expanded=_rank_terms(train,validation)
    meta_receipt={'status':'NOT_CALLED_OFFLINE','model':None}
    if source_mode=='no_new_mechanism':picked=fixed['model'];candidate=None
    elif source_mode=='human_nominee':
        candidate=PHASE;picked=fit(train,KNOWN+[PHASE])
    elif source_mode=='live_meta':
        from .open_world_meta import live_nominate
        # The real Meta proposal is NOT given the simulator law, phase-grid
        # answer, frozen test, or target-machine outcomes.
        context={'task':'Propose a falsifiable bounded unknown-physics term, or request a sensor',
           'fields':['x','v','u','temperature_delta'],
           'training_rows':len(train),'validation_episodes':2,
           'current_source_blind_selected_term':fixed['selected_term'],
           'validation_residuals':residual_diagnostics(validation,fixed['model']),
           'restrictions':'No hardware actuation; do not infer physical truth from these synthetic scores'}
        reply=live_nominate(context,model=meta_model,allow_billed=True)
        raw=reply.get('candidate')
        meta_receipt={k:reply.get(k) for k in ('status','origin','request_sha256','response_sha256','model_response_id','model')}
        candidate=validate_term(raw) if raw else None
        nominated=fit(train,KNOWN+[candidate]) if candidate else None
        # Must outperform a predeclared, source-blind EXPANDED dictionary;
        # otherwise there is no claim of contribution by Meta.
        candidate_gain=bool(nominated and score(validation,nominated)<expanded['validation_rmse']*.98)
        meta_receipt['candidate_validation_gain_over_expanded_search']=candidate_gain
        if not candidate_gain: candidate=None
        picked=nominated if candidate_gain else expanded['model']
    else:
        candidate=expanded['term'];picked=expanded['model']
    source_summary={'mode':source_mode,'origin':'SYNTHETIC_CALIBRATED_SIMULATOR',
      'source_baseline_term':fixed['selected_term'],
      'meta_execution':meta_receipt,
      'source_expanded_term':expanded['term'],
      'human_nominee_if_supplied':PHASE if source_mode=='human_nominee' else None,
      'source_validation_baseline_rmse':float(fixed['validation_selected_rmse']),
      'source_validation_expanded_rmse':expanded['validation_rmse'],
      'unmeasured_truth_hidden_from_model_fitting':True,
      'experiment_labels':list(sorted({r['episode_id'] for r in validation}))}
    _write(root/'01_SOURCE_DISCOVERY.json',source_summary)
    # This is a useful discriminating experiment even when source and
    # candidate have different explanations. Planned before its truth exists.
    source_probe=_approved_probe_selection(fixed['model'],picked)
    source_seed=seed+23
    source_future_spec=plan(source_seed,100)
    chosen_source_action=source_probe['selected_action']
    if chosen_source_action is not None:
        source_future_spec['u'][:]=chosen_source_action
    source_future={'seed':source_seed,'action':source_future_spec['u'].tolist(),
       'temperature_delta':source_future_spec['temperature_delta'].tolist(),
       'dt':DT,'initial':_measured_initial(source_seed),
       'discriminating_probe':source_probe,
       'baseline_future':_safe_forecast(fixed['model'],_measured_initial(source_seed),
                 source_future_spec['u'].tolist(),source_future_spec['temperature_delta'].tolist()),
       'expanded_future':_safe_forecast(picked,_measured_initial(source_seed),
                 source_future_spec['u'].tolist(),source_future_spec['temperature_delta'].tolist())}
    bodies=[{'id':'B','thermal':.65,'periodic':.35,'sensor':'camera_imu'},
            {'id':'C','thermal':.9,'periodic':.52,'sensor':'encoder_acoustic'}]
    frozen_targets=[];adaptation=[]
    for j,body in enumerate(bodies):
        offset=seed+100+j*100
        local=_measured_episode(body,offset,'target_local_'+body['id'],n=26)['rows']
        valid=_measured_episode(body,offset+1,'target_validation_'+body['id'],n=27)['rows']
        # B/C have the same local data and equal candidate grammar. Probe
        # chosen without ever seeing the prospective final target outcome.
        cold=fit(local+valid,KNOWN)
        warm=fit(local+valid,KNOWN+[candidate]) if candidate is not None else cold
        probe=_approved_probe_selection(cold,warm)
        action=probe['selected_action']
        if action is None: action=0.
        # Read an additional distinct intervention with a fresh initial state.
        # A disagreement in accepted structure is a reason to request a second
        # calibrated observation rather than guessing or overclaiming transfer.
        p=_measured_episode(body,offset+2,'target_shared_probe_1_'+body['id'],n=25,fixed_action=action)
        pilot=local+p['rows'];probe_history=[{'action':action,'sample_count':25,'reason':'MAXIMIZE_FORECAST_DISAGREEMENT'}]
        decision=_target_models(pilot,valid,candidate)
        if candidate is not None and (decision['blind_term'] is None or
                                      decision['blind_term']['phase_weights']!=candidate['phase_weights'] or
                                      min(decision['blind_validation_rmse'],decision['source_validation_rmse'] or 1e6)>.02):
            # A second reversible, synthetic probe deliberately visits the
            # opposite end of the bounded control range to improve coverage.
            # A real device would need its own safety envelope and approval.
            second_action=(.35 if action<=0 else -.35)
            second=_measured_episode(body,offset+3,'target_shared_probe_2_'+body['id'],
                                     n=25,fixed_action=second_action)
            pilot+=second['rows']
            probe_history.append({'action':second_action,'sample_count':25,
                                  'reason':'VALIDATION_AMBIGUITY_REQUEST_MORE_EVIDENCE'})
            decision=_target_models(pilot,valid,candidate)
        blind_term=decision['blind_term']
        shared=pilot+valid
        local_model=fit(shared,KNOWN+([blind_term] if blind_term is not None else []))
        source_model=fit(shared,KNOWN+[candidate]) if candidate is not None else local_model
        accepted=decision['accepted'] and candidate is not None
        selected_model=source_model if accepted else local_model
        # predeclared future plan: no simulated future measurements generated here.
        future_seed=offset+7
        initial=_measured_initial(future_seed)
        specified=plan(future_seed,90)
        ambient=specified['temperature_delta'].tolist()
        # Goal-directed planning, entirely offline and review-only: choose a
        # bounded constant force expected to minimize terminal displacement.
        # It does not assert safety of any real machine actuation.
        choices=[]
        for u0 in ACTUATIONS:
            tentative=_safe_forecast(selected_model,initial,[u0]*90,ambient)
            if tentative is None: continue
            choices.append((abs(tentative[-1]['x'])+.015*abs(u0),float(u0),tentative[-1]['x']))
        preferred=min(choices) if choices else None
        goal_action=preferred[1] if preferred else None
        u=[goal_action]*90 if goal_action is not None else specified['u'].tolist()
        goal={'objective':'minimize terminal displacement with bounded commanded action',
              'selected_action':goal_action,
              'predicted_terminal_x':preferred[2] if preferred else None,
              'approved_for_hardware':False,'model_conditional':True}
        fselected=_safe_forecast(selected_model,initial,u,ambient)
        flocal=_safe_forecast(local_model,initial,u,ambient)
        fsource=_safe_forecast(source_model,initial,u,ambient)
        frozen_targets.append({'body':body['id'],'sensor_package':body['sensor'],
          'sensor_calibration_assumed_not_empirically_verified':True,
          'frozen_decision':decision,'new_probe':{
             'selected_action':probe['selected_action'],
             'executed_in_simulation_only':True,'samples_shared_equally':len(pilot)-len(local),
             'probe_history':probe_history,
             'planner':probe},
          'goal_directed_plan':goal,
          'predeclared_future':{'seed':future_seed,'initial_state':initial,
             'action':u,'temperature_delta':ambient,'dt':DT},
          'selected_model':selected_model,'local_model':local_model,'source_model':source_model,
          'selected_forecast':fselected,'target_only_forecast':flocal,
          'source_structure_forecast':fsource,
          'no_future_truth_read_to_create_forecast':True})
        adaptation.append({'body':body['id'],'decision':decision['decision'],
                          'new_probe_action':probe['selected_action']})
    frozen={'schema':'physica.v0211.prospective.v1','origin':'SYNTHETIC_SIMULATOR',
      'source_discovery':source_summary,'source_discriminating_experiment':source_future,'target_research':frozen_targets,
      'note':'These are complete future forecasts; outcome files DO NOT YET EXIST at time of creation.'}
    receipt={'frozen':frozen,'digest_sha256':_payload_digest(frozen),
      'written_utc':datetime.now(timezone.utc).isoformat(),
      'chronology_warning':'Local file and hash are not an independently witnessed timestamp',
      'algorithm':'SHA-256 canonical JSON UTF-8'}
    _write(root/'02_FULL_FROZEN_FORECAST_BEFORE_REVEAL.json',receipt)
    if not verify_receipt(root/'02_FULL_FROZEN_FORECAST_BEFORE_REVEAL.json'):
        raise RuntimeError('forecast integrity check failed')
    # Source lockbox is likewise opened only after its complete forecast has
    # been written. Compare both models against independent sensor readings.
    src_actual=_measured_episode(source,source_seed,'source_never_seen_test',n=100,
                 fixed_action=chosen_source_action)
    source_result={'probe_selected':chosen_source_action,
       'real_experiment':False,
       'baseline_camera_rmse':_series_rmse(source_future['baseline_future'],src_actual,'camera_imu'),
       'expanded_camera_rmse':_series_rmse(source_future['expanded_future'],src_actual,'camera_imu')}
    outcomes=[]
    # NO target future function called until AFTER full receipt written to disk.
    for body,f in zip(bodies,frozen_targets):
        spec=f['predeclared_future'];seed_t=spec['seed']
        truth=_measured_episode(body,seed_t,'NEW_UNSEEN_TEST_'+body['id'],n=len(spec['action']),action_sequence=spec['action'])
        sensor=body['sensor']
        e=_series_rmse(f['selected_forecast'],truth,sensor)
        local_e=_series_rmse(f['target_only_forecast'],truth,sensor)
        source_e=_series_rmse(f['source_structure_forecast'],truth,sensor)
        actual_terminal_x=float(truth['rows'][-1]['x'])
        goal_plan=f['goal_directed_plan']
        neutral=_measured_episode(body,seed_t,'COUNTERFACTUAL_NEUTRAL_'+body['id'],
               n=len(spec['action']),fixed_action=0.)
        outcomes.append({'body':body['id'],'measured_modality':sensor,
            'goal':goal_plan,
            'observed_terminal_displacement_m':actual_terminal_x,
            'simulated_neutral_terminal_displacement_m':float(neutral['rows'][-1]['x']),
            'outcome_better_than_simulated_neutral':bool(abs(actual_terminal_x)<abs(neutral['rows'][-1]['x'])),
            'selected_rmse':e,'target_only_rmse':local_e,
            'source_structure_rmse':source_e,
            'selected_is_better_than_target_only':bool(e is not None and local_e is not None and e < local_e-1e-10),
            'transfer_accepted':f['frozen_decision']['accepted'],
            'real_world':False,'meta_inference_executed':False,
            'measured_series':[
               r['sensors']['camera_m' if sensor=='camera_imu' else 'acoustic_speed_proxy']
               for r in truth['rows'][1::3]],
            'predicted_series':[
               r['camera_m' if sensor=='camera_imu' else 'audio_m_per_s']
               for r in (f['selected_forecast'] or [])[::3]],
            'target_only_series':[
               r['camera_m' if sensor=='camera_imu' else 'audio_m_per_s']
               for r in (f['target_only_forecast'] or [])[::3]]})
    result={'schema':'physica.v0211.causal_fork','origin':'SYNTHETIC_SIMULATOR',
      'source_discovery':source_summary,'source_lockbox':source_result,'target_outcomes':outcomes,
      'selected_probe_counts':sum(x['new_probe']['selected_action'] is not None for x in frozen_targets),
      'commitment_digest_sha256':receipt['digest_sha256'],
      'receipt_reverified_after_observation':verify_receipt(root/'02_FULL_FROZEN_FORECAST_BEFORE_REVEAL.json'),
      'comparison':'Same target data and expanded dictionary; local baseline can refuse source transfer',
      'preliminary_not_real_causal_law':True,'real_physical_experiments':0,
      'meta_execution':meta_receipt,'independent_timestamp':False,
      'limitations':['Ground truth is a known simulator law, even though search never receives it directly',
        'Calibration maps are assumed exact and both targets expose recoverable x and v',
        'Source-selected structure is in a finite expanded phase dictionary',
        'Target-only has full candidate capacity but no separate hierarchical empirical-Bayes baseline',
        'No autonomous actuation or safety certification']}
    _write(root/'03_REVEALED_RESULTS.json',result)
    return result


def _measured_initial(seed):
    return [float(.18+.20*np.sin(seed*1.31)),float(.02+.11*np.cos(seed*.83))]


def benchmark(out, *, seeds=12, first_seed=2026):
    if not isinstance(seeds,int) or not 1<=seeds<=36:raise ValueError('benchmark seeds must be 1..36')
    root=Path(out);root.mkdir(parents=True,exist_ok=True)
    results=[]
    for i in range(seeds):
        r=run(root/f'seed_{first_seed+i}',seed=first_seed+i)
        a=r['source_lockbox']
        for t in r['target_outcomes']:
            results.append({'seed':first_seed+i,'target':t['body'],
                            'sensor':t['measured_modality'],
                            'selected_rmse':t['selected_rmse'],
                            'target_only_rmse':t['target_only_rmse'],
                            'source_structure_rmse':t['source_structure_rmse'],
                            'transfer_accepted':t['transfer_accepted'],
                            'goal_better_than_neutral':t['outcome_better_than_simulated_neutral'],
                            'source_base_camera_rmse':a['baseline_camera_rmse'],
                            'source_expanded_camera_rmse':a['expanded_camera_rmse']})
    def mean(key):
        usable=[r[key] for r in results if r[key] is not None]
        return float(np.mean(usable)) if usable else None
    report={'schema':'physica.v0211.benchmark','origin':'SYNTHETIC_SIMULATOR',
            'source_seed_count':seeds,'target_case_count':len(results),
            'mean_target_selected_rmse':mean('selected_rmse'),
            'mean_target_only_rmse':mean('target_only_rmse'),
            'mean_source_structure_rmse':mean('source_structure_rmse'),
            'source_lockbox_mean_base_camera_rmse':mean('source_base_camera_rmse'),
            'source_lockbox_mean_expanded_camera_rmse':mean('source_expanded_camera_rmse'),
            'source_transfer_accepted_count':sum(r['transfer_accepted'] for r in results),
            'target_selected_beats_target_only_count':sum(
                 r['selected_rmse'] is not None and r['target_only_rmse'] is not None and
                 r['selected_rmse'] < r['target_only_rmse']-1e-10 for r in results),
            'goal_outcomes_beat_simulated_neutral_count':sum(r['goal_better_than_neutral'] for r in results),
            'all_cases':results,'real_experiments':0,'authenticated_meta_calls':0,
            'qualifications':['No demonstrated algorithmic novelty from source/target transfer',
                'Source expanded grammar is supplied to target-only baseline too',
                'Real transfer needs calibrated physical data and independent outcome witness']}
    _write(root/'BENCHMARK.json',report)
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description='Sealed synthetic hypothesis discrimination and A-B-C experience transfer')
    p.add_argument('--out',required=True)
    p.add_argument('--seed',type=int,default=2026)
    p.add_argument('--source-mode',choices=['source_search','human_nominee','no_new_mechanism'],default='source_search')
    p.add_argument('--verify',default=None,help='Verify previously saved complete forecast receipt content digest')
    p.add_argument('--benchmark-seeds',type=int,default=0,help='Run a multi-seed synthetic baseline comparison')
    p.add_argument('--meta-model',choices=['muse-spark-1.3','muse-wonder-1.0'],default='muse-spark-1.3')
    p.add_argument('--allow-billed-meta',action='store_true')
    args=p.parse_args(argv)
    if args.verify:
        ok=verify_receipt(args.verify)
        print(json.dumps({'verified':ok,'independent_timestamp':False}))
        if not ok:raise SystemExit(2)
        return
    if args.benchmark_seeds:
        if args.source_mode!='source_search' or args.allow_billed_meta:
            raise ValueError('benchmarks must be non-billed source-search runs')
        res=benchmark(args.out,seeds=args.benchmark_seeds,first_seed=args.seed)
        print(json.dumps({k:v for k,v in res.items() if k not in ('all_cases','qualifications')},allow_nan=False))
        return
    res=run(args.out,seed=args.seed,source_mode=args.source_mode,meta_model=args.meta_model,allow_billed=args.allow_billed_meta)
    print(json.dumps({'out':str(args.out),'source_mechanism':(res['source_discovery']['source_expanded_term'] or {}).get('id'),
                      'probe_count':res['selected_probe_counts'],'source_lockbox':res['source_lockbox'],
                      'target_summary':[{k:v for k,v in x.items() if k not in ('measured_series','predicted_series','target_only_series')}
                                        for x in res['target_outcomes']]},allow_nan=False))

if __name__=='__main__':main()
