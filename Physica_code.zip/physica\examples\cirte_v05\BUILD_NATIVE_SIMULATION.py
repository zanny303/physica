"""Generate complete OFFLINE CIRTE field fixture. Every sensor is simulated.

For a real demo replace independently measured calibration, microphone/video
CSV, actual low-force probe and independent witness files. DO NOT represent
this fixture as a real physical experiment or a Meta API response.
"""
from __future__ import annotations
import csv,json,sys
from pathlib import Path
from dataclasses import asdict
import numpy as np
from scipy.linalg import expm
from physica.grammar.simulator import cal,time_grid
from physica.grammar.observation import CalibratedSensor
from physica.grammar.cirte_field import source_from_native_manifest,prepare_native,check_native,learn_next_native
from physica.grammar.field import verify_signed


def write_json(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
def write_csv(p,t,y=None):
    with p.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['time_s']+(['value'] if y is not None else []))
        for i,tt in enumerate(t):w.writerow([tt]+([y[i]] if y is not None else []))


def truth(ctx,t):
    w=2*np.pi*ctx.fundamental_hz
    matrix=np.array([[0,1],[-w*w,-2*ctx.damping_ratio*w]])
    eq=-np.linalg.solve(matrix,np.array([0,ctx.applied_force_n/ctx.mass_kg]))
    return np.asarray([(np.eye(2)-expm(matrix*v))@eq for v in t])


def build(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(15)
    A=cal('microphone_A',4.2,125);B=cal('camera_B',4.8,146)
    C=cal('camera_C',3.9,106)
    sensors={
        'mic':CalibratedSensor('micA','hearing','Pa',(0.,2.5),0.,.00015,0.,'independent_sim_mic','simulation',.00015,(-.1,.1)),
        'cam':CalibratedSensor('camB','vision','m',(1.,0.),0.,.00001,0.,'independent_sim_cam','simulation',.00001,(-.1,.1)),
    }
    for label,sensor in sensors.items():write_json(out/(label+'.json'),asdict(sensor))
    # A's microphone native output is acoustic pressure in Pa (not velocity!).
    tA=time_grid(A);xA=truth(A,tA)
    pressure=2.5*xA[:,1]+rng.normal(0,sensors['mic'].noise_std,len(tA))
    write_csv(out/'A_mic_Pa.csv',tA,pressure)
    for body in [A,B,C]:write_json(out/(body.body_id+'_body.json'),asdict(body))
    (out/'A_local_attestation.txt').write_text('SYNTHETIC ATTACHED FIXTURE, not an independent physical witness.\n')
    write_json(out/'source_manifest.json',{
       'body_context':asdict(A),'causal_hypothesis':'elastic_step_response','action_id':'supervised_reversible_step',
       'source_attestation':{'supervisor_acknowledgement':True,'attestation_file':str(out/'A_local_attestation.txt')},
       'channels':[{'sensor_calibration_json':str(out/'mic.json'),
                    'recording_csv':str(out/'A_mic_Pa.csv')}]})
    src=source_from_native_manifest(out/'source_manifest.json',out/'A_signed_PEL.json')
    assert verify_signed(json.loads((out/'A_signed_PEL.json').read_text()))
    summary={'provenance':'SIMULATION_ONLY','A':src,'predictions':{},'reveals':{}}
    source_file=out/'A_signed_PEL.json'
    for name,ctx in [('B',B),('C',C)]:
        t=time_grid(ctx);grid=out/(name+'_times_only.csv')
        write_csv(grid,t)
        # The source-like probe comes from a different, small-force encounter.
        # The pre-declared result is not derived from target's main response CSV.
        write_json(out/(name+'_low_force_probe_SIMULATED.json'),{
            'source':'simulated_low_force_measurement',
            'probe_raw_sha256':'f'*64,
            'normalized_response_error':.005,'normalized_response_sigma':.01})
        source_for_this=source_file
        forecast=out/(name+'_sealed_forecast.json')
        prepared=prepare_native(source_for_this,out/(ctx.body_id+'_body.json'),
             out/'cam.json',grid,out/(name+'_low_force_probe_SIMULATED.json'),forecast)
        assert verify_signed(json.loads(forecast.read_text()))
        # Generate target consequence strictly AFTER forecast sealed. This is
        # enforceable program order but NOT independently witnessed chronology.
        main=out/(name+'_measured_after_commit.csv')
        x=truth(ctx,t)
        video=x[:,0]+rng.normal(0,sensors['cam'].noise_std,len(t))
        write_csv(main,t,video)
        reveal_path=out/(name+'_signed_reveal.json')
        checked=check_native(forecast,main,reveal_path)
        summary['predictions'][name]=prepared;summary['reveals'][name]=checked
        if name=='B':
            learned=learn_next_native(reveal_path,main,out/'B_new_signed_PEL.json',
                                action_id='supervised_reversible_step',causal_hypothesis='elastic_step_response')
            assert verify_signed(json.loads((out/'B_new_signed_PEL.json').read_text()))
            summary['learning_B']=learned
            source_file=out/'B_new_signed_PEL.json'
    write_json(out/'RESULTS_SIMULATION_ONLY.json',summary)
    return summary

if __name__=='__main__':
    print(json.dumps(build(Path(sys.argv[1] if len(sys.argv)>1 else 'examples/cirte_v05/native_demo')),indent=2))
