# Physica v0.12 — Discovery Observatory & Live Sensing (research release candidate)

## Summary and precise evidence boundary

This release retains the v0.11 sensing, feeling, transfer, field, Meta and Studio system. It fixes `field-evaluate` CLI parsing, adds restricted unfamiliar-mechanism search, compares against an all-feature ridge baseline, shows a proper simulation-only *lockbox evidence theater*, and integrates an optical webcam motion-energy view and an explicitly authorized authenticated Muse hypothesis test in Studio.

**This is not a new natural law, proof of AGI, open-world discovery, native Meta glasses application, or evidence of superior cross-embodiment learning on real machines.** A simulation that was written with a temperature-slip term will naturally reward a mechanism candidate that includes that term. Live webcam pixel differences are not calibrated displacement, force, chemistry, friction or a machine diagnosis. A signed record cannot independently attest chronology or data truth.

## Windows terminal (using the PowerShell shell, as indicated by a `PS ...>` prompt)

Extract ZIP into `C:\Users\budhw\Downloads\physicanew` to create its `physica` subdirectory. Back up any earlier project folder or custom datasets first.

```powershell
cd C:\Users\budhw\Downloads\physicanew\physica
$env:PYTHONUTF8 = '1'
..\.venv\Scripts\python.exe -m pip install -e '.[dev,video]'
..\.venv\Scripts\python.exe -m physica.studio --open-browser
```

Open http://127.0.0.1:8765. The home page has an *illustrative* animated signal dashboard and buttons that actually launch the deterministic offline experiments. The **Live sensing** tab requests browser camera permission and analyzes raw browser frames locally. Drag a region over the target in the lower canvas. It estimates time-varying pixel-change energy within the region relative to the rest of the scene; no video frames are uploaded by that tab. Use **Lens** with a recorded video for the existing tracked displacement workflow. Camera motion and illumination changes can still produce false alarms.

For the new scientific exhibit:

```powershell
..\.venv\Scripts\python.exe -m physica.mace.cli discover-unknown --seed 2026 --out demo\studio\mace_unknown_discovery.json
start demo\studio\mace_unknown_discovery.html
```

The new CLI writes JSON and an HTML evidence exhibit. The observatory displays a tested source-machine candidate compared with (a) the linear mechanistic model and (b) the all-candidate ridge model using the same source training and validation episodes.

## Restricted unfamiliar mechanism search — exact protocol

`physica.mace.unknown_physics` dynamically constructs candidate terms *only from independently measured fields*. Grammar terms include square/cube motion, smooth velocity nonlinearities and bounded two-factor interactions with separately measured temperature, electrical current, magnetic and ultrasound channels when actually available. Missing fields do not become virtual measurements.

1. Train a linear baseline using recorded controlled actions and source sensory measurements.
2. Build a deterministic candidate dictionary from measured source channels, *without reading the outcome of the test episode*.
3. Fit each individual candidate term with the same source training data. Reject aliased or non-identifiable terms.
4. Select a candidate on disjoint validation episodes only if it clears a predeclared minimum relative improvement and improves each validation episode.
5. Freeze the hypothesis and open the held-out **source** test episode once; report the adverse cases too. Multiple-hypothesis testing remains a concern; this is preliminary evidence, not a calibrated p-value.
6. As a stronger classical benchmark, fit ridge regression on the *same full feature dictionary*, tune regularization on the same validation set, and score the same lockbox.

This is a feature-library expansion plus held-out model selection, with explicit rejection of sensor hallucination—not automated invention of arbitrary physics. Compare also against SINDy/PySINDy, GP/latent state-space methods, and neural residual models in subsequent preregistered studies. They are not implemented as baselines in this new release.

**Simulation exhibit (seed 2026):** one known temperature-dependent interaction is deliberately missing from the linear baseline. Source lockbox acceleration RMSE is approximately 0.15469 (linear), 0.03800 (same-dictionary ridge) and 0.00894 (single selected sparse candidate), in the simulator's acceleration units. This result does **not** extrapolate to real systems or establish novel mathematics.

## Real controlled-action dataset

Use the existing MACE manifest schema (`physica.mace.controlled.v1`) and independently collected/calibrated CSV episodes. Each file has columns: `t,x,v,u,acceleration,temperature_delta` with matching SI units, unique episode IDs, and recorded SHA-256 digests. Provide **distinct train/validation/test** episodes; actual remote-controlled physical experiments qualify when instrumented. Self-declared real-data labels do not establish independent witnessing.

```powershell
..\.venv\Scripts\python.exe -m physica.mace.cli discover-unknown --manifest C:\PhysicaData\my_case\manifest.json --out demo\field_discovery.json

# Fixed v0.11 crash: --nomination is now a declared argument
..\.venv\Scripts\python.exe -m physica.mace.cli field-evaluate --manifest C:\PhysicaData\my_case\manifest.json --out demo\field_evaluate.json
```

Paderborn University Bearing DataCenter is real vibration/current evidence useful for passive sensing and generalization, **not** automatically causal intervention evidence. Group splits by bearing ID; compare vibration-only, current-only and multimodal tasks; avoid inventing contact actions. Its license is CC BY-NC 4.0 and requires attribution. https://mb.uni-paderborn.de/en/kat/research/bearing-datacenter

Use future-video withheld-frame forecasting from Discover for visual evaluation, not to claim a video's hidden physical force without proper calibration.

## Meta: real integration, guarded access

Hosted Muse Spark 1.3 and Muse Wonder 1.0 can propose a strict-schema candidate mechanism. `physica.mace.meta` sends only allowlisted experimental context to the official Meta Model API Chat Completions endpoint `https://api.meta.ai/v1/chat/completions`. A validated schema is **not** proof of an explanation; numerical coefficients are always learned from measurements. Live inference has never been executed by this release's builders.

In Studio, on the **Meta & System** tab, you can set a model, check an explicit billable-call acknowledgment, and initiate **one** authenticated call. Set your private `MODEL_API_KEY` in the same Windows Terminal session **before** launching Studio; never paste it into the browser, a recording, a report, or a public repository. The saved report contains source-simulation-held-out Meta-on/Meta-off comparisons and response metadata. It is not proof of general performance, and a remote model can abstain.

For real controlled physical files, the existing explicit command is:

```powershell
$env:MODEL_API_KEY = 'YOUR_OWN_KEY'  # terminal only; never commit
..\.venv\Scripts\python.exe -m physica.mace.cli field-investigate --manifest C:\PhysicaData\my_case\manifest.json --live-meta --allow-billed-meta --out demo\live_field.json
```

The web dashboard does **not** actuate equipment or silently make charged calls. Meta must be evaluated on multiple independent scenarios under equal opportunity and proposal budgets. The no-Meta candidate search should also receive a strong baseline (full feature dictionary and relevant published methods).

Official docs: https://dev.meta.ai/docs/cookbook/structured-output and https://dev.meta.ai/docs/cookbook/quickstart-chat-completions

## Real-time machine vision and Meta glasses

**What runs here:** the live browser camera monitor estimates *pixel change* in a selected region (roughly frame change relative to other pixels); Lens video workflows track optical movement from a recorded clip; optional SAM 3.1 adapters support object tracking, with the official parser and independent stationary-reference and scale verification. No real SAM inference was performed for this release.

**What still requires engineering:** a high-quality live SAM 3.1 tracking service with accepted-frame rate/latency measurements, independently calibrated displacement from track geometry, synchronized microphone/IMU streams, and a consumer diagnosis proven against fault ground truth. A camera-only washing-machine clip does not uniquely establish a failed bearing or motor fault.

Meta's Wearables Device Access Toolkit 1.0 documentation describes supported camera, motion/IMU, microphone/audio and display integrations across eligible devices; an actual compatible iOS/Android client (or Meta display web app with its distinct feature limits) remains to be built. https://developers.meta.com/wearables/faq/ and https://ai.meta.com/blog/segment-anything-model-3/

## Strong scientific roadmap and demonstrations

**Act I (0:00–0:50):** animated home overview clearly labelled illustration → one-click **real code** unfamiliar-mechanism simulator → test lockbox waveform and comparison with all-feature ridge. Show the rejection controls.

**Act II (0:50–1:45):** Discover on an *external* real bearing data file, unseen bearing IDs and separate signal ablations; show a video clip with prefix-only forecast and explicit visual uncertainty. These passive recordings cannot be rebranded as intervention discovery.

**Act III (1:45–2:40):** live webcam preview, select a vibrating region, see measured pixel-change energy, then use Lens to review a recorded clip and evidence-limited appliance or robot-arm diagnosis. Explain what extra force, temperature or current measurement would distinguish causes.

**Act IV (2:40–3:00):** compare Meta hypothesis nomination with a no-Meta fixed dictionary and present the prospective A→B/C transfer research. If Meta has not been authenticated, say "adapter ready, not tested". If transfer fails, show refusal rather than a fabricated success.

For true algorithmic novelty, preregister tests across: (a) new physical mechanisms outside the fixed dictionary; (b) new sensor configurations, (c) new machine geometry/materials; (d) same local and total source experiment budgets, (e) strong SINDy/ARX/neural baselines, (f) false discovery and refusal rates. Use **blind future action-conditioned forecasting**, not reconstruction with future target state supplied. Track total source cost, not only target measurements. Show all losses and performance on rejected transfers.

Related research to compare (not claims of Physica novelty): https://arxiv.org/abs/2605.26087 (DiscoverPhysics, interactive unfamiliar laws); https://pysindy.readthedocs.io/en/stable/ (sparse equation learning); https://link.springer.com/article/10.1007/s44163-026-02122-1 (survey of uncertainty and control in learned physical world models).
