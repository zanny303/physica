"""The outcome contract: before any physics runs or any machine code is written, the goal must be complete,
in range, and promisable on the evidence Physica actually has. Otherwise: a structured refusal, never an action."""
from __future__ import annotations

import json
import math
from pathlib import Path

REQUIRED = {
    "beam": [("forcing_hz", "what frequency should the beam stay away from (Hz)?")],
    "pendulum": [("target", "what angle should the joint reach (rad)?")],
}


def check(spec) -> list[str]:
    """Problems that block acting. Empty list = the goal may be planned."""
    probs = [u for u in spec.unclear if u.startswith("which machine")]
    if spec.machine not in {"beam", "pendulum", "turbine", "drone", "f1"}:
        probs.append("unknown or unsupported machine")
    if not isinstance(spec.context, dict) or not isinstance(spec.constraints, list):
        return probs + ["invalid outcome context or constraint format"]
    for c in spec.constraints:
        if not isinstance(c, dict) or "value" not in c:
            probs.append("invalid or missing constraint value")
        elif isinstance(c["value"], bool) or not isinstance(c["value"], (float, int)) or not math.isfinite(c["value"]):
            probs.append("constraint must be a finite number")
    for key, ask in REQUIRED.get(spec.machine, []):
        v = spec.context.get(key)
        if v is None:
            probs.append(ask)
        elif isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0:
            probs.append(f"{key} must be finite and positive")
    if spec.machine == "beam":
        m = spec.get("tone_hz", "outside_band_pct")
        if m is None or not (0 < m < 50):
            probs.append("the margin must be between 0 and 50%")
    if spec.machine == "pendulum":
        if spec.get("overshoot_pct", "<=") is None and spec.get("settle_s", "<=") is None:
            probs.append("say what 'good' means: an overshoot limit, a settling time, or both")
    return probs


def turbine_never(spec, e20_path: Path) -> dict | None:
    """A 'never run a cracked blade' goal is checked against the blade sense's measured misses."""
    if not any(c.get("op") == "never" for c in spec.constraints):
        return None
    if not e20_path.exists():
        return {"promisable": False, "why": "no measured evidence for the blade sense yet (run eval/e20_wind_blade.py)"}
    d = json.loads(e20_path.read_text())
    conf = d["score"]["confusion"]["crack"]
    missed = conf.get("weather only", 0)
    total = sum(conf.values())
    small = sum(v.get("weather only", 0) for k, v in d["score"]["by_case"].items() if k == "D")
    return {"promisable": missed == 0, "crack_groups": total, "missed_as_weather": missed, "missed_smallest_crack": small,
            "why": (f"Can't promise 'never': on the test campaign {missed} of {total} cracked-blade groups looked like "
                    f"weather ({small} of them the smallest, 5 cm crack). What the evidence supports: cracks that look "
                    f"like ice are caught by the de-icing promise; larger cracks are found far more often. Options: accept "
                    f"this measured risk (review-only logic), add scheduled drone inspections, or improve the sense first.")}
