"""Why did this printer change? Learn its moving mass and stiffness, and test rival causes with a known weight.

The method is Bayesian system identification using the added-mass technique from modal testing. For one mode,

    f = sqrt(k / (m + added)) / (2 pi)    so    1 / f^2 = (4 pi^2 / k) * (m + added)

which is a straight line in the added mass. Films with and without a known, securely fastened weight give its slope
and intercept, and those give the effective moving mass m and stiffness k, with uncertainty from how well films repeat.

A changed tone can mean a change in mass or in stiffness, and one film cannot separate them. They predict different tones once
a known weight goes on, so:
  plan  ranks the available weights by expected information gain, and seals what each cause predicts
  test  measures mass and stiffness as they are now: mass changed, stiffness changed, both, neither, or can't tell
Then the learned state predicts the tone and shaper setting for a new load before it is filmed, and teach passes the
effective-mass fraction to another printer as a starting estimate, scored against not having it.

Limits: this is one mode of one axis, so a tone that is a frame mode will not behave like this and the calibration step
will say so. Effective mass is not scale mass, because belts and pulleys move too. "Neither" and "can't tell" are real
answers. Advice only: nothing here moves a machine, and a person fastens the weight and runs the G-code.
"""
from __future__ import annotations

import hashlib
import json
import math

import numpy as np

from physica import seal as _seal
from physica.unified.engine import choose_probe

TWO_PI = 2 * math.pi
DRAWS = 6000
TONE_MODEL_ERROR = 0.0015    # allowance for what a one-mode model misses, as a fraction of the tone
DECIDE_AT = 0.9
SAME_WITHIN = 0.08           # a property within 8% of healthy counts as unchanged
SELECTION_POLICY = "lightest available weight whose test would reach an answer; information gain is reported, not maximized"
SEPARATE_AT = 4.0            # a test weight must split the two forecasts by this many sd
BETWEEN_PRINTERS = 0.15      # assumed spread of the mass fraction between printers: an assumption, not a measurement


def model_digest(model: dict) -> str:
    """Hash of every number a verdict depends on, so changing the model after sealing is caught."""
    fields = {k: model.get(k) for k in ("tone_hz", "film_sd_hz", "points", "beta", "cov")}
    return hashlib.sha256(json.dumps(fields, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _tones(films: list[dict]) -> list[float]:
    return [f["tone_hz"] for f in films if f.get("ok")]


def _film_sd(base: dict) -> float:
    return float(base["sd_used_hz"])


def calibrate(base: dict, loads: dict[float, list[float]], head_g: float | None = None, seed: int = 11) -> dict:
    """base: usable healthy baseline. loads: {added grams: tones filmed with it fastened on}. Flat-prior Bayesian line fit."""
    if not base.get("usable"):
        return {"usable": False, "reason": base.get("reason", "no usable baseline")}
    sd = _film_sd(base)
    points = [(0.0, float(base["mean_hz"]), int(base["films_used"]))]
    for g, tones in sorted(loads.items()):
        if g <= 0 or len(tones) < 2:
            return {"usable": False, "reason": "each known weight needs a positive mass and at least 2 clear films"}
        points.append((float(g), float(np.mean(tones)), len(tones)))
    if len(points) < 2:
        return {"usable": False, "reason": "film the printer with a known weight fastened on"}
    x = np.array([p[0] for p in points])
    f = np.array([p[1] for p in points])
    n = np.array([p[2] for p in points], float)
    if not np.all(np.diff(f) < 0):
        return {"usable": False, "tones_hz": f.round(3).tolist(), "reason": "the tone did not fall as weight was added, so "
                "this may not be a moving-mass mode. Film again, or try the other axis"}
    y = 1 / f ** 2
    sy = 2 * np.hypot(sd / np.sqrt(n), TONE_MODEL_ERROR * f) / f ** 3
    X = np.column_stack([np.ones_like(x), x])
    cov = np.linalg.inv(X.T @ (X / sy[:, None] ** 2))
    beta = cov @ (X.T @ (y / sy ** 2))
    if beta[0] <= 0 or beta[1] <= 0:
        return {"usable": False, "reason": "the fit gave a non-physical mass or stiffness; film again with a heavier known weight"}
    rng = np.random.default_rng(seed)
    a, b = rng.multivariate_normal(beta, cov, DRAWS).T
    ok = (a > 0) & (b > 0)
    if ok.mean() < 0.99:
        return {"usable": False, "reason": "this weight moved the tone too little to pin down mass and stiffness; use a heavier "
                "one or more films"}
    m_g, k = a[ok] / b[ok], (TWO_PI ** 2 / b[ok]) / 1e3  # b is per gram: k comes out in g/s^2, and 1000 g/s^2 is 1 N/m
    out = {"usable": True, "tone_hz": float(base["mean_hz"]), "film_sd_hz": sd, "points": points,
           "beta": beta.tolist(), "cov": cov.tolist(), "m_g": float(np.mean(m_g)), "m_sd_g": float(np.std(m_g)),
           "k_n_per_m": float(np.mean(k)), "k_sd": float(np.std(k)), "method": "added-mass Bayesian line fit, one mode"}
    if head_g:
        out["head_g"] = float(head_g)
        out["mass_fraction"] = out["m_g"] / float(head_g)
        out["mass_fraction_sd"] = out["m_sd_g"] / float(head_g)
    return out


def _draws(model: dict, seed: int = 12) -> tuple[np.ndarray, np.ndarray]:
    a, b = np.random.default_rng(seed).multivariate_normal(model["beta"], model["cov"], DRAWS).T
    ok = (a > 0) & (b > 0)
    return a[ok] / b[ok], TWO_PI ** 2 / b[ok]  # m in g, k in g/s^2


def _tone(k, m):
    return np.sqrt(k / m) / TWO_PI


def rivals(model: dict, tone_now: float, films_now: int = 1, seed: int = 13) -> dict:
    """Each cause fully explains the tone now, with the other property left at its healthy value."""
    m0, k0 = _draws(model, seed)
    f1 = np.random.default_rng(seed + 1).normal(tone_now, model["film_sd_hz"] / math.sqrt(films_now), len(m0))
    w = (TWO_PI * f1) ** 2
    return {"more_mass": {"k": k0, "m": k0 / w}, "less_stiffness": {"k": w * m0, "m": m0}, "healthy_m": m0, "healthy_k": k0}


def forecast(state: dict, added_g: float) -> tuple[float, float]:
    f = _tone(state["k"], state["m"] + added_g)
    return float(np.mean(f)), float(np.std(f))


def rival_state(model: dict, r: dict, tone_now: float, rival: dict) -> dict | None:
    """A proposed cause as numbers. By construction it explains the tone now: mass_share of the fall comes from mass and
    the rest from stiffness. A cause that says the head's mass and belts aren't involved predicts the weight changes little."""
    if not rival.get("responds_to_weight", True):
        return None
    m0, k0 = r["healthy_m"], r["healthy_k"]
    healthy = float(np.mean(_tone(k0, m0)))
    ratio = (tone_now / healthy) ** 2
    s = float(np.clip(rival.get("mass_share", 1.0), 0, 1))
    return {"k": k0 * ratio ** (1 - s), "m": m0 * ratio ** (-s)}


def _rival_forecast(model: dict, r: dict, tone_now: float, rival: dict, g: float) -> tuple[float, float]:
    st = rival_state(model, r, tone_now, rival)
    return forecast(st, g) if st else (float(tone_now), float(model["film_sd_hz"]))


def plan_test(model: dict, tone_now: float, masses: list[float], films: int = 3, films_now: int = 1, extra_rivals: list[dict] | None = None) -> dict:
    """Rank the available weights by how well they would separate the causes, and seal the forecasts before the test.
    extra_rivals: causes proposed by Muse. If a heavier weight is needed to tell them apart too, that's the weight chosen."""
    r = rivals(model, tone_now, films_now)
    extra_rivals = extra_rivals or []
    noise = model["film_sd_hz"] / math.sqrt(films)
    candidates, table = [], {}
    for g in sorted(set(float(x) for x in masses)):
        if g <= 0:
            continue
        mm, sm = forecast(r["more_mass"], g)
        ms, ss = forecast(r["less_stiffness"], g)
        sigma = math.sqrt(max(sm, ss) ** 2 + noise ** 2 + (TONE_MODEL_ERROR * mm) ** 2)
        table[g] = {"more_mass_hz": round(mm, 3), "more_mass_sd": round(sm, 3), "less_stiffness_hz": round(ms, 3),
                    "less_stiffness_sd": round(ss, 3), "separation_sd": round(abs(mm - ms) / sigma, 2), "sigma_hz": sigma}
        candidates.append({"id": f"{g:g}", "means": [mm, ms], "sigma": sigma, "approved": True, "cost": g / 100, "risk": g / 500})
    ranked = choose_probe(candidates, seed=17) if candidates else {"selected": None, "scores": []}
    # A weight only counts as useful if the two forecasts sit clearly apart.
    # and if the real test would actually reach an answer whichever cause turns out true.
    useful = [g for g, t in table.items() if t["separation_sd"] >= SEPARATE_AT and all(
        _direct_verdict(model, r, tone_now, films_now, t[f"{name}_hz"], noise, g)["verdict"] not in ("can't tell", "neither")
        for name in ("more_mass", "less_stiffness"))]
    chosen = min(useful) if useful else None
    without_extra = chosen
    extra = {}
    for g in table:
        extra[g] = {}
        for rv in extra_rivals:
            mu, sd = _rival_forecast(model, r, tone_now, rv, g)
            sigma = math.sqrt(sd ** 2 + noise ** 2 + (TONE_MODEL_ERROR * mu) ** 2)
            apart = min(abs(mu - table[g]["more_mass_hz"]), abs(mu - table[g]["less_stiffness_hz"])) / max(sigma, table[g]["sigma_hz"])
            extra[g][rv["name"]] = {"forecast_hz": round(mu, 3), "sigma_hz": sigma, "separation_sd": round(apart, 2)}
    if extra_rivals and useful:
        settles_all = [g for g in useful if all(v["separation_sd"] >= SEPARATE_AT for v in extra[g].values())]
        chosen = min(settles_all) if settles_all else max(useful, key=lambda g: min(v["separation_sd"] for v in extra[g].values()))
    out = {"tone_now_hz": round(tone_now, 3), "films_planned": films, "chosen_g_without_muse": without_extra, "muse_rivals": extra_rivals,
           "muse_forecasts_by_weight_g": {f"{g:g}": {n: {"forecast_hz": v["forecast_hz"], "separation_sd": v["separation_sd"]} for n, v in e.items()} for g, e in extra.items()}, "by_weight_g": {f"{g:g}": t for g, t in table.items()},
           "expected_information_gain_nats": {s["id"]: s.get("expected_information_gain_nats") for s in ranked["scores"]},
           "selection_policy": SELECTION_POLICY, "chosen_g": chosen, "status": "TEST_CHOSEN_FOR_HUMAN_REVIEW" if chosen else "NO_AVAILABLE_WEIGHT_SEPARATES_THE_CAUSES",
           "no_hardware_execution": True}
    if chosen:
        t = table[chosen]
        out["sealed"] = _seal.seal({"added_g": chosen, "films": films, "films_now": films_now, "tone_now_hz": float(tone_now),
                                    "model_sha256": model_digest(model), "selection_policy": SELECTION_POLICY, "intervals": {
            "more_mass": [t["more_mass_hz"], t["sigma_hz"]], "less_stiffness": [t["less_stiffness_hz"], t["sigma_hz"]],
            **{n: [v["forecast_hz"], v["sigma_hz"]] for n, v in extra[chosen].items()}}},
            "printer cause forecasts, written before the known weight went on")
    return out


def judge_cause(model: dict, plan: dict, tone_now: float, test_tones: list[float], added_g: float, films_now: int = 1) -> dict:
    """Compare the films with the sealed forecasts. A wrong or unclear result stays as that."""
    if not test_tones:
        return {"verdict": "can't tell", "reason": "no clear ringing in the test films"}
    sealed = plan.get("sealed")
    if not sealed or not _seal.intact(sealed):
        return {"verdict": "can't tell", "reason": "the sealed forecast is missing or was edited"}
    commit = sealed["payload"]["prediction"]
    if abs(commit["added_g"] - added_g) > 1e-9:
        return {"verdict": "can't tell", "reason": f"the forecast was sealed for {commit['added_g']:g} g, "
                f"not {added_g:g} g. Plan the test again before filming"}
    if commit.get("model_sha256") != model_digest(model):
        return {"verdict": "can't tell", "reason": "the printer model changed after the forecast was sealed, so this "
                "test no longer counts. Plan it again"}
    if abs(commit.get("tone_now_hz", float("nan")) - tone_now) > 1e-9 or commit.get("films_now") != films_now:
        return {"verdict": "can't tell", "reason": "the measured starting tone differs from the one sealed with the forecast"}
    r = rivals(model, tone_now, films_now)
    y = float(np.mean(test_tones))
    noise = model["film_sd_hz"] / math.sqrt(len(test_tones))
    rows = {}
    for name in commit["intervals"]:
        mu, planned_sigma = commit["intervals"][name]   # the sealed numbers, not a recalculation
        sigma = max(float(planned_sigma), noise)
        rows[name] = {"forecast_hz": round(mu, 3), "sigma_hz": round(sigma, 3), "z": round((y - mu) / sigma, 2),
                      "loglik": -0.5 * ((y - mu) / sigma) ** 2 - math.log(sigma)}
    ll = np.array([rows[n]["loglik"] for n in rows])
    post = np.exp(ll - ll.max())
    post = post / post.sum()
    for n, p in zip(rows, post):
        rows[n]["probability"] = round(float(p), 3)
        rows[n].pop("loglik")
    out = {"tone_with_weight_hz": round(y, 3), "added_g": added_g, "films": len(test_tones), "rivals": rows,
           "muse_rival_names": [n for n in rows if n not in ("more_mass", "less_stiffness")],
           "top_rival": max(rows, key=lambda n: rows[n]["probability"])}
    return {**out, **_direct_verdict(model, r, tone_now, films_now, y, noise, added_g)}


def _direct_verdict(model: dict, r: dict, tone_now: float, films_now: int, y: float, noise: float, added_g: float) -> dict:
    """The tone now and the tone with the weight give this printer's mass and stiffness as it is today. Compare them with
    healthy, so 'both changed' and a rising tone are possible answers, not forced into one of two causes."""
    m0, k0 = r["healthy_m"], r["healthy_k"]
    rng = np.random.default_rng(29)
    n = len(m0)
    f1 = rng.normal(tone_now, math.hypot(model["film_sd_hz"] / math.sqrt(films_now), TONE_MODEL_ERROR * tone_now), n)
    ft = rng.normal(y, math.hypot(noise, TONE_MODEL_ERROR * y), n)
    b = (1 / ft ** 2 - 1 / f1 ** 2) / added_g
    valid = b > 0
    if valid.mean() < 0.5:
        return {"verdict": "neither", "reason": "the tone didn't fall under the known weight, so neither cause explains it. "
                "Something else changed: ask Muse for more explanations and measure again"}
    m1, k1 = (1 / f1[valid] ** 2) / b[valid], TWO_PI ** 2 / b[valid]
    rm, rk = m1 / m0[valid] - 1, k1 / k0[valid] - 1
    mass_moved, stiff_moved = np.abs(rm) > SAME_WITHIN, np.abs(rk) > SAME_WITHIN
    regions = {"mass": mass_moved & ~stiff_moved, "stiffness": stiff_moved & ~mass_moved, "both": mass_moved & stiff_moved,
               "unclear": ~mass_moved & ~stiff_moved}
    probs = {k: float(v.sum() / max(n, 1)) for k, v in regions.items()}
    best = max(("mass", "stiffness", "both"), key=lambda k: probs[k])
    out = {"probability_by_cause": {k: round(v, 3) for k, v in probs.items()},
           "mass_change_percent": round(100 * float(np.median(rm)), 1), "stiffness_change_percent": round(100 * float(np.median(rk)), 1)}
    if probs[best] < DECIDE_AT:
        return {**out, "verdict": "can't tell", "reason": f"the films don't settle it ({probs[best]:.0%} at most). Use more films or a "
                "heavier known weight"}
    pick = regions[best]
    dm, dk = (m1 - m0[valid])[pick], 100 * rk[pick]
    if best == "mass":
        word = "more mass" if np.median(dm) > 0 else "less mass"
        state = r["more_mass"]["m"]
        d = state - m0
        out.update(verdict=word, change_g=round(float(np.mean(d)), 1), change_sd_g=round(float(np.std(d)), 1),
                   state={"tone_hz": tone_now, "m_g": float(np.mean(state)), "m_sd_g": float(np.std(state))})
        out["reason"] = f"{word}, about {out['change_g']:+.0f} g (+/- {2 * out['change_sd_g']:.0f} g)"
    elif best == "stiffness":
        word = "less stiffness" if np.median(dk) < 0 else "more stiffness"
        d = 100 * (r["less_stiffness"]["k"] / k0 - 1)
        out.update(verdict=word, change_percent=round(float(np.mean(d)), 1), change_sd_percent=round(float(np.std(d)), 1),
                   state={"tone_hz": tone_now, "m_g": float(np.mean(m0)), "m_sd_g": float(np.std(m0))})
        out["reason"] = f"{word}, about {out['change_percent']:+.0f}% (+/- {2 * out['change_sd_percent']:.0f}%)"
    else:
        out.update(verdict="both changed", change_g=round(float(np.mean(dm)), 1), change_sd_g=round(float(np.std(dm)), 1),
                   change_percent=round(float(np.mean(dk)), 1), change_sd_percent=round(float(np.std(dk)), 1),
                   state={"tone_hz": tone_now, "m_g": float(np.mean(m1[pick])), "m_sd_g": float(np.std(m1[pick]))})
        out["reason"] = (f"both changed: mass about {out['change_g']:+.0f} g (+/- {2 * out['change_sd_g']:.0f} g), stiffness about "
                         f"{out['change_percent']:+.0f}% (+/- {2 * out['change_sd_percent']:.0f}%)")
    return out


def predict_tone(tone_hz: float, tone_sd: float, m_g: float, m_sd_g: float, added_g: float, film_sd: float, seed: int = 21) -> dict:
    """Tone after adding weight, from the tone now and the moving mass. Includes the noise of the film that will grade it."""
    rng = np.random.default_rng(seed)
    f = rng.normal(tone_hz, tone_sd, DRAWS)
    m = np.clip(rng.normal(m_g, m_sd_g, DRAWS), 1e-6, None)
    p = f * np.sqrt(m / np.clip(m + added_g, 1e-6, None))
    mu = float(np.mean(p))
    sd = math.sqrt(float(np.var(p)) + film_sd ** 2 + (TONE_MODEL_ERROR * mu) ** 2)
    return {"tone_hz": mu, "sd_hz": sd, "interval_hz": [mu - 1.96 * sd, mu + 1.96 * sd]}


def seal_prediction(name: str, added_g: float, main: dict, compare: dict, source: str) -> dict:
    return _seal.seal({"added_g": added_g, "tone_hz": main["tone_hz"], "interval_hz": main["interval_hz"], "source": source,
                       "compare_with": compare}, f"printer tone forecast for {name} with {added_g:g} g added")


def grade_prediction(sealed: dict, tones: list[float]) -> dict:
    if not _seal.intact(sealed):
        return {"verdict": "INVALID", "held": False, "reason": "the seal was edited"}
    if not tones:
        return {"verdict": "can't tell", "held": None, "reason": "no clear ringing in this film"}
    p = sealed["payload"]["prediction"]
    y = float(np.mean(tones))
    lo, hi = p["interval_hz"]
    errors = {"physica": round(abs(y - p["tone_hz"]), 3)}
    for k, v in (p.get("compare_with") or {}).items():
        errors[k] = round(abs(y - v), 3)
    held = lo <= y <= hi
    return {"verdict": "held" if held else "broken", "held": held, "measured_hz": round(y, 3), "forecast_hz": round(p["tone_hz"], 3),
            "interval_hz": [round(lo, 3), round(hi, 3)], "error_hz": errors, "source": p["source"]}


def verified_at_source(predictions: list[dict]) -> dict:
    """A lesson is verified only if the source printer predicted a load it had never filmed, and no prediction broke."""
    graded = [r["grade"] for r in predictions if (r.get("grade") or {}).get("held") is not None]
    held, broken = sum(g["held"] for g in graded), sum(not g["held"] for g in graded)
    return {"held": held, "broken": broken, "verified": held >= 1 and broken == 0}


def lesson_status(card_verified: bool, grade: dict) -> str:
    """What a lesson earned on the new printer, from its own sealed prediction on a new film."""
    if grade.get("held") is None:
        return "NOT_TESTED_HERE"
    e = grade["error_hz"]
    beat = e["physica"] < e.get("no_lesson_full_head_mass", math.inf) and e["physica"] < e.get("no_model_same_tone", math.inf)
    if not grade["held"] or not beat:
        return "LESSON_FAILED_ON_THIS_PRINTER"
    return "LESSON_APPLIES_ON_THIS_PRINTER" if card_verified else "HELD_BUT_SOURCE_NOT_VERIFIED"


def make_card(model: dict, printer: str, evidence: dict | None = None) -> dict:
    if "mass_fraction" not in model:
        raise ValueError("teach needs the print head's scale weight: calibrate again with --head-g")
    from physica.library import sign
    card = {"schema": "physica.printer_lesson.v1", "claim": "effective moving mass as a fraction of the head's scale mass",
            "from_printer": printer, "mass_fraction": model["mass_fraction"], "mass_fraction_sd": model["mass_fraction_sd"],
            "head_g": model["head_g"], "assumed_between_printers": BETWEEN_PRINTERS,
            "evidence_at_source": evidence or {"held": 0, "broken": 0, "verified": False},
            "limits": ["A starting estimate, to be replaced by the printer's own known-weight films",
                       "Best for similar designs. The spread between printers is assumed, not measured"]}
    return {"payload": card, "signature": sign.sign(card)}


def from_card(signed: dict, base: dict, head_g: float) -> dict:
    """The other printer's lesson as a Gaussian prior on moving mass, combined with this printer's own healthy tone."""
    from physica.library import sign
    card = signed.get("payload") or {}
    if not sign.verify(card, signed.get("signature")):
        raise ValueError("this lesson's signature does not verify")
    if not base.get("usable"):
        raise ValueError(base.get("reason", "this printer needs a usable baseline first"))
    fraction = float(card["mass_fraction"])
    sd = math.hypot(float(card["mass_fraction_sd"]), fraction * float(card["assumed_between_printers"]))
    return {"tone_hz": float(base["mean_hz"]), "tone_sd_hz": float(base["sd_used_hz"]) / math.sqrt(base["films_used"]),
            "m_g": fraction * head_g, "m_sd_g": sd * head_g, "from_printer": card.get("from_printer"), "fraction": fraction,
            "verified_at_source": bool((card.get("evidence_at_source") or {}).get("verified"))}
