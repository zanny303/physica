"""Independent low-force probe: recompute disagreement from raw sensor CSV.

The probe must be recorded BEFORE the target main test. Local file hashes and
Ed25519 do not prove chronology or physical truth: external witness required.
"""
from __future__ import annotations
import hashlib
from dataclasses import replace
import numpy as np
from .field import read_timeseries
from .signals import MechanicalContext
from .observation import CalibratedSensor
from .language import ExperienceEnvelope,verify_record
from scipy.interpolate import CubicSpline


def recompute_probe(source_envelope:dict,target:MechanicalContext,observer:CalibratedSensor,
                    recording_csv,*,probe_force_n:float):
    if not verify_record(source_envelope):raise ValueError('untrusted source PEL')
    if not np.isfinite(probe_force_n) or not 0<probe_force_n<target.applied_force_n:
        raise ValueError('probe must be positive, finite, and strictly lower force than main test')
    times,observed,raw_hash=read_timeseries(recording_csv)
    word=ExperienceEnvelope.model_validate(source_envelope).word
    if target.boundary_class!=word.boundary_class or target.action_family!=word.action_family:
        raise ValueError('mismatched causal intervention; cannot infer applicability')
    tau=times*target.fundamental_hz
    src_tau=np.asarray(word.normalized_time,dtype=float)
    if tau[0]<src_tau[0]-1e-8 or tau[-1]>src_tau[-1]+1e-8:
        raise ValueError('probe outside source normalized time support')
    spline=CubicSpline(src_tau,np.asarray(word.normalized_response),bc_type='natural')
    x=(probe_force_n/target.stiffness_n_m)*spline(tau)
    v=(probe_force_n/target.stiffness_n_m)*target.fundamental_hz*spline(tau,1)
    if not np.all((x>=observer.validated_state_range[0])&(x<=observer.validated_state_range[1])):
        raise ValueError('probe predicted displacement outside sensor calibration')
    if not np.all((v>=observer.validated_velocity_range[0])&(v<=observer.validated_velocity_range[1])):
        raise ValueError('probe predicted velocity outside sensor calibration')
    pred=observer.state_gains[0]*x+observer.state_gains[1]*v+observer.offset
    # Dimensionless likelihood diagnostic in sensor's own calibrated units.
    # Never substitute reported scalar error for independently measured CSV.
    native_scale=max(float(np.sqrt(np.mean((pred-observer.offset)**2))),observer.noise_std)
    err=float(np.sqrt(np.mean((observed-pred)**2))/native_scale)
    # Predictive uncertainty includes independently calibrated sensor noise,
    # but does not include unmodeled transport uncertainty (not certified).
    sigma=float(observer.noise_std/native_scale)
    return {'source':'independent_low_force_measurement' if target.provenance!='simulation' else 'simulated_low_force_measurement',
            'probe_force_n':float(probe_force_n),'probe_raw_sha256':raw_hash,
            'normalized_response_error':err,'normalized_response_sigma':sigma,
            'n_samples':len(times),'observable_unit':observer.output_unit,
            'measurement_model':'calibrated sensor H@[x,v] + offset',
            'limitations':'local probe; must be externally witnessed; repeated noise may be correlated'}
