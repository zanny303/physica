"""Real-video measurement and strictly held-out trajectory forecast.

Optical-flow observations remain pixel motion unless independently calibrated.
ROI must be chosen BEFORE observing future frames. Lens uses retrospective
holdout; a scientific prospective claim requires `prepare` then `check`.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares

@dataclass(frozen=True)
class VideoConfig:
    roi: tuple[int,int,int,int]
    reference_roi: tuple[int,int,int,int]|None=None
    pixels_per_metre: float|None=None
    max_frames: int=360
    axis: str='y'
    def __post_init__(self):
        if len(self.roi)!=4 or any(not isinstance(v,int) for v in self.roi) or self.roi[2]<=3 or self.roi[3]<=3:
            raise ValueError('ROI requires x,y,width,height integers')
        if self.reference_roi is not None and (len(self.reference_roi)!=4 or any(not isinstance(v,int) for v in self.reference_roi) or self.reference_roi[2]<=3 or self.reference_roi[3]<=3):
            raise ValueError('invalid reference ROI')
        if self.pixels_per_metre is not None and (not math.isfinite(self.pixels_per_metre) or self.pixels_per_metre<=0):
            raise ValueError('need independently measured pixels per metre')
        if not 20<=self.max_frames<=3000 or self.axis not in ('x','y'):
            raise ValueError('invalid video sampling configuration')

def _get_cv():
    try: import cv2
    except ImportError as exc: raise RuntimeError('Install video optional dependency: pip install -e ".[video]"') from exc
    return cv2

def _features(gray, box):
    cv2=_get_cv();h,w=gray.shape
    x,y,bw,bh=box
    if min(x,y)<0 or x+bw>w or y+bh>h: raise ValueError('ROI outside video frame')
    mask=np.zeros(gray.shape,np.uint8);mask[y:y+bh,x:x+bw]=255
    p=cv2.goodFeaturesToTrack(gray,mask=mask,maxCorners=100,qualityLevel=.01,minDistance=3,blockSize=3)
    if p is None or len(p)<4:raise ValueError('not enough stable visual features in ROI; add a temporary high-contrast marker')
    return p

def extract_track(video_path, config:VideoConfig, *, frame_limit=None):
    cv2=_get_cv();cap=cv2.VideoCapture(str(video_path))
    if not cap.isOpened():raise ValueError('unsupported or unreadable video')
    try:
        fps=float(cap.get(cv2.CAP_PROP_FPS))
        if not math.isfinite(fps) or fps<=0:raise ValueError('video must carry a valid frame rate')
        n_cap=config.max_frames if frame_limit is None else min(config.max_frames,int(frame_limit))
        if n_cap<10:raise ValueError('need at least ten frames')
        ok,first=cap.read()
        if not ok:raise ValueError('empty video')
        prev=cv2.cvtColor(first,cv2.COLOR_BGR2GRAY)
        def setup(box): return _features(prev,box)
        moving=setup(config.roi)
        anchor=setup(config.reference_roi) if config.reference_roi else None
        mpos=0.;apos=0.;ts=[0.];motion=[0.];refs=[0.]
        axis=0 if config.axis=='x' else 1
        time_index=0;lost=0
        while time_index+1<n_cap:
            ok,frame=cap.read()
            if not ok:break
            now=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
            def follow(points):
                if points is None or len(points)<4:raise ValueError('optical-flow features lost; tracking uncertain')
                nxt,status,_=cv2.calcOpticalFlowPyrLK(prev,now,points,None,winSize=(25,25),maxLevel=3,
                                                      criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,25,.01))
                if nxt is None or status is None:raise ValueError('tracking lost')
                good=status.reshape(-1).astype(bool)
                if good.sum()<4:raise ValueError('fewer than four valid tracked features')
                orig=points.reshape(-1,2)[good];curr=nxt.reshape(-1,2)[good]
                delta=curr-orig
                median=np.median(delta[:,axis]);err=np.abs(delta[:,axis]-median)
                keep=err<=max(2.5,float(4*np.median(err))+1)
                if np.sum(keep)<4:raise ValueError('inconsistent optical-flow tracks')
                return curr[keep].reshape(-1,1,2),float(np.median(delta[keep,axis]))
            moving,dm=follow(moving);mpos+=dm
            if anchor is not None:
                anchor,da=follow(anchor);apos+=da
            time_index+=1
            prev=now
            ts.append(time_index/fps);motion.append(mpos-apos);refs.append(apos)
        if len(ts)<12:raise ValueError('video too short for forecast')
        t=np.asarray(ts);y=np.asarray(motion)
        unit='m' if config.pixels_per_metre is not None else 'px'
        if config.pixels_per_metre is not None:y=y/config.pixels_per_metre
        return {'time_s':t.tolist(),'motion':y.tolist(),'unit':unit,'fps':fps,'frames':len(t),
            'motion_axis':config.axis,'reference_used':config.reference_roi is not None,
            'roi':list(config.roi),'reference_roi':list(config.reference_roi) if config.reference_roi else None,
            'camera_calibration':'independently_supplied' if unit=='m' else 'UNCALIBRATED_PIXELS',
            'limitations':['Optical flow is not force, stiffness, mass or a causal mechanism',
                           'Moving camera and perspective changes require a fixed reference region and independent calibration',
                           'Video motion tracking error not statistically calibrated']}
    finally:cap.release()

def _constant_model(t,y,pred):
    t=np.asarray(t);y=np.asarray(y);p=np.asarray(pred)
    n=max(4,len(t)//3)
    coeff=np.polyfit(t[-n:],y[-n:],1)
    return np.polyval(coeff,p),{'velocity_per_s':float(coeff[0])}

def _oscillator_model(t,y,pred):
    t=np.asarray(t,dtype=float);y=np.asarray(y,dtype=float);pred=np.asarray(pred,dtype=float)
    if len(t)<20: raise ValueError('oscillator requires adequate observations')
    fs=1/np.median(np.diff(t));duration=t[-1]-t[0]
    if duration<=0:raise ValueError('invalid duration')
    dy=y-np.mean(y)
    if np.std(dy)<1e-6: raise ValueError('no usable oscillatory displacement')
    fft=np.fft.rfft(dy*np.hanning(len(dy)))
    frequencies=np.fft.rfftfreq(len(t),d=1/fs)
    eligible=np.where((frequencies>=2/duration)&(frequencies<.35*fs))[0]
    if not len(eligible):raise ValueError('insufficient resolved cycles')
    peaks=eligible[np.argsort(np.abs(fft[eligible]))[-min(4,len(eligible)):]]
    best=None
    def function(p,at):
        offset,dr,freq,a,b=p
        return offset+np.exp(-dr*(at-t[0]))*(a*np.cos(2*np.pi*freq*(at-t[0]))+b*np.sin(2*np.pi*freq*(at-t[0])))
    mag=max(1e-5,float(np.ptp(y)))
    for idx in peaks:
        for d in [0., .1/duration, .5/duration]:
            x0=[float(np.mean(y)),d,float(frequencies[idx]),float(dy[0]),.2*mag]
            res=least_squares(lambda p:function(p,t)-y,x0,bounds=([-np.inf,0.,2/duration,-10*mag,-10*mag],
                               [np.inf,5/duration,.4*fs,10*mag,10*mag]),max_nfev=130)
            err=float(np.mean(res.fun**2))
            if best is None or err<best[0]:best=(err,res.x)
    return function(best[1],pred),{'decay_s_inverse':float(best[1][1]),'frequency_hz':float(best[1][2]),
                                   'oscillator_fit_is_not_proof_of_mechanism':True}

def sealed_video_forecast(track, *, cutoff_fraction=.65, horizon_frames=None):
    """Fit ONLY prefix observations. Future measurements are never passed to fitters."""
    t=np.asarray(track['time_s'],float);y=np.asarray(track['motion'],float)
    if t.ndim!=1 or y.shape!=t.shape or len(t)<25 or not np.all(np.isfinite(t)) or not np.all(np.isfinite(y)):
        raise ValueError('need finite motion series with at least 25 frames')
    if not .4<=cutoff_fraction<=.85: raise ValueError('holdout fraction out of bounds')
    split=max(15,int(len(t)*cutoff_fraction))
    train_t=t[:split];train_y=y[:split]
    # Cross-validation stays entirely in the available prefix.
    inner=max(10,int(len(train_t)*.75))
    cv_t=train_t[inner:]
    cv_scores={}
    for name,fn in [('constant_velocity',_constant_model),('damped_oscillator',_oscillator_model)]:
        try:
            pred,_=fn(train_t[:inner],train_y[:inner],cv_t)
            cv_scores[name]=float(np.sqrt(np.mean((pred-train_y[inner:])**2)))
        except (ValueError,RuntimeError,TypeError):pass
    if not cv_scores:raise ValueError('no adequate forecasting model')
    choice=min(cv_scores,key=cv_scores.get)
    fn=_constant_model if choice=='constant_velocity' else _oscillator_model
    future=t[split:] if horizon_frames is None else (t[split-1]+np.arange(1,horizon_frames+1)*np.median(np.diff(t)))
    yhat,params=fn(train_t,train_y,future)
    return {'model':choice,'forecast_time_s':future.tolist(),'forecast_motion':yhat.tolist(),
            'unit':track['unit'],'training_frame_count':split,'first_withheld_frame':split,
            'training_end_s':float(train_t[-1]),'inner_validation_rmse':cv_scores,
            'fit_parameters':params,'uncertainty':'UNCALIBRATED_NO_PREDICTION_INTERVAL',
            'causal_claim_status':'UNKNOWN_INSUFFICIENT_INTERVENTIONS',
            'no_future_values_used_in_fit':True}

def evaluate_forecast(track,forecast):
    t=np.asarray(track['time_s'],float);y=np.asarray(track['motion'],float)
    fut=np.asarray(forecast['forecast_time_s'],float);pred=np.asarray(forecast['forecast_motion'],float)
    if len(fut)!=len(pred) or not len(fut):raise ValueError('bad forecast')
    ids=np.searchsorted(t,fut)
    ids=np.minimum(ids,len(t)-1)
    left=np.maximum(ids-1,0)
    ids=np.where(np.abs(t[left]-fut)<np.abs(t[ids]-fut),left,ids)
    if np.any(np.abs(t[ids]-fut)>1e-4):raise ValueError('forecast times are not held-out timestamps')
    if np.any(ids<forecast['first_withheld_frame']):raise ValueError('evaluation leakage')
    real=y[ids];errors=real-pred
    rmse=float(np.sqrt(np.mean(errors**2)))
    # Holdout persistence baseline for equal information and horizon.
    last=float(y[forecast['first_withheld_frame']-1]);base=float(np.sqrt(np.mean((real-last)**2)))
    return {'holdout_rmse':rmse,'persistence_rmse':base,'unit':track['unit'],
            'n_holdout':len(fut),'better_than_persistence':bool(rmse<base),
            'independent_real_experiment':False,
            'evaluation_kind':'RETROSPECTIVE_HELDOUT_RECORDED_VIDEO',
            'causal_mechanism_verified':False}

def forecast_next_frames(prefix_track, *, horizon_frames):
    """Prospective forecast: caller supplies ONLY frames that already exist or have been captured.

    A separate future capture is required for independent prospective physical evidence.
    """
    t=np.asarray(prefix_track['time_s'],float);y=np.asarray(prefix_track['motion'],float)
    if not (20<=len(t)<=3000 and 1<=horizon_frames<=1000):raise ValueError('invalid prefix or horizon')
    if np.any(~np.isfinite(y)) or np.any(np.diff(t)<=0):raise ValueError('invalid readings')
    inner=max(10,int(.75*len(t)))
    scores={}
    for name,fn in [('constant_velocity',_constant_model),('damped_oscillator',_oscillator_model)]:
        try:
            forecast,_=fn(t[:inner],y[:inner],t[inner:])
            scores[name]=float(np.sqrt(np.mean((forecast-y[inner:])**2)))
        except (ValueError,RuntimeError):pass
    if not scores:raise ValueError('no forecast model')
    name=min(scores,key=scores.get)
    future=t[-1]+np.arange(1,horizon_frames+1)*np.median(np.diff(t))
    fn=_constant_model if name=='constant_velocity' else _oscillator_model
    yp,params=fn(t,y,future)
    return {'model':name,'forecast_time_s':future.tolist(),'forecast_motion':yp.tolist(),
            'unit':prefix_track['unit'],'training_frame_count':len(t),'first_withheld_frame':len(t),
            'training_end_s':float(t[-1]),'fit_parameters':params,'inner_validation_rmse':scores,
            'uncertainty':'UNCALIBRATED_NO_PREDICTION_INTERVAL',
            'causal_claim_status':'UNKNOWN_INSUFFICIENT_INTERVENTIONS',
            'no_future_values_used_in_fit':True}
