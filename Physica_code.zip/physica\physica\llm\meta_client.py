"""The one door to Meta's Model API. Every Muse and SAM call in Physica goes through here.

Format verified against Meta's developer docs (dev.meta.ai, Oct 2026):
  - Chat:      POST {base}/chat/completions   Authorization: Bearer $MODEL_API_KEY
               model, messages (roles developer/system/user/assistant/tool), max_completion_tokens, tools,
               tool_choice, response_format, reasoning_effort -> choices[0].message.{content, tool_calls}
  - Files:     POST {base}/files (multipart, purpose=user_data)
  - SAM 3.1:   POST {base}/responses  model=sam-3.1, input=[{type: message, role: user, content: [input_text noun
               phrase, input_video file_id]}], stream=true -> text lines per frame with boxes and masks
Model IDs (override in .env): muse-spark-1.3, muse-wonder-1.0, sam-3.1.

Modes:
  live    MOCK=0 and MODEL_API_KEY set. Real calls, cost meter with a hard stop (PHYSICA_BUDGET_USD, default
          $120), and a receipt for every call in meta_receipts/ (committable proof of what Meta actually said).
  replay  a cached answer for this exact request exists (replay/llm/): used, so demos run with no key.
  mock    otherwise: a registered offline stand-in, ALWAYS labelled as not Meta.
The key is read from the environment only; it is never written anywhere.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
import urllib.error
import urllib.request
import uuid
import contextlib
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from physica import config


class BudgetExceeded(RuntimeError):
    """Raised before a call that could push total spend over the hard stop."""


class NotConfigured(RuntimeError):
    pass


DEFAULT_BASE = "https://api.meta.ai/v1"
MODELS = {"spark": ("MODEL_SPARK", "muse-spark-1.3"), "wonder": ("MODEL_WONDER", "muse-wonder-1.0"),
          "sam": ("MODEL_SAM", "sam-3.1")}
# Conservative UPPER-BOUND prices (USD per 1M tokens) used only for the hard stop when you haven't set the real ones
# from Meta's pricing page (PRICE_SPARK_IN/OUT, PRICE_WONDER_IN/OUT, PRICE_SAM_FRAME). They make the stop trip early,
# never late.
# Meta's published prices (dev.meta.ai/docs/pricing-rate-limits, checked 2 Nov 2026), standard mode, per million tokens. Reasoning counts as output.
# Set PRICE_SPARK_IN and friends if they change. SAM bills at least 50 frames per video.
UPPER_BOUND = {"spark": (1.25, 4.25), "wonder": (4.0, 20.0), "sam_frame": 0.0002}
RECEIPTS = config.REPO_ROOT / "meta_receipts"

_MOCKS: dict[str, Callable[[list[dict]], str]] = {}


def register_mock(task: str):
    def deco(fn):
        _MOCKS[task] = fn
        return fn

    return deco


def api_key() -> str | None:
    return os.environ.get("MODEL_API_KEY") or os.environ.get("META_API_KEY")


def base_url() -> str:
    return (os.environ.get("MODEL_API_BASE") or os.environ.get("META_API_BASE_URL") or DEFAULT_BASE).rstrip("/")


def model_id(role: str) -> str:
    env, default = MODELS[role]
    return os.environ.get(env, default)


def is_mock() -> bool:
    if os.environ.get("MOCK", "1") == "1":
        return True
    return not api_key()


def mode() -> str:
    return "mock" if is_mock() else "live"


@dataclass
class Spend:
    path: Path

    def total(self) -> float:
        if not self.path.exists(): return 0.0
        d = json.loads(self.path.read_text(encoding='utf-8'))
        return float(d.get('usd', 0)) + sum(float(r['usd']) for r in d.get('reserved', {}).values())

    def add(self, usd: float, note: str) -> float:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tot = self.total() + usd
        log = []
        try:
            log = json.loads(self.path.read_text()).get("log", [])
        except Exception:
            pass
        log.append({"t": time.time(), "usd": usd, "note": note})
        self.path.write_text(json.dumps({"usd": tot, "log": log[-500:]}, indent=1))
        return tot



@contextlib.contextmanager
def _ledger_lock():
    """Cross-process lock for all budget reservations (Windows and POSIX).

    Serializes only tiny ledger transactions, not entire billable calls. An
    in-flight reservation is charged against the limit before the HTTP request.
    """
    lockfile = config.STATE_DIR / 'spend.json.lock'
    lockfile.parent.mkdir(parents=True, exist_ok=True)
    with open(lockfile, 'a+b') as fd:
        fd.seek(0, 2)
        if fd.tell() == 0:
            fd.write(b'0');fd.flush()
        fd.seek(0)
        if os.name == 'nt':
            import msvcrt
            for _ in range(200):
                try:
                    msvcrt.locking(fd.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    time.sleep(.05)
            else:
                raise TimeoutError('Meta spending ledger is locked')
        else:
            import fcntl
            fcntl.flock(fd.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fd.seek(0)
            if os.name == 'nt':
                msvcrt.locking(fd.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(fd.fileno(), fcntl.LOCK_UN)


def _ledger_read() -> dict:
    p = _spend().path
    if not p.exists():
        return {'usd': 0.0, 'reserved': {}, 'log': []}
    try:
        d=json.loads(p.read_text(encoding='utf-8'))
        if not isinstance(d,dict):raise ValueError()
        d.setdefault('reserved', {});d.setdefault('log', [])
        return d
    except (ValueError, OSError):
        # Corrupt ledger must fail closed; cannot reset billing to zero.
        raise BudgetExceeded('Cannot read Meta spending ledger; refusing paid calls')


def _ledger_write(d: dict) -> None:
    p = _spend().path
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp = p.with_name(p.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        tmp.write_text(json.dumps(d, indent=2, allow_nan=False),encoding='utf-8')
        tmp.replace(p)
    finally:
        if tmp.exists():tmp.unlink()


def _reserve(est: float, task: str) -> str:
    if not (0 < est < 10000):
        raise BudgetExceeded('Invalid cost estimate')
    with _ledger_lock():
        d=_ledger_read()
        used=float(d.get('usd',0)) + sum(float(x['usd']) for x in d['reserved'].values())
        if used + est > budget_usd():
            raise BudgetExceeded(f'Committed/reserved ${used:.3f}; estimate ${est:.3f}; cap ${budget_usd():.2f}')
        rid=uuid.uuid4().hex
        d['reserved'][rid]={'usd':est, 'task':task, 'created':time.time()}
        _ledger_write(d)
        return rid


def _settle(rid: str, charge: float, note: str) -> None:
    """Charge a completed request or release reservation for preflight failure."""
    with _ledger_lock():
        d=_ledger_read()
        if rid not in d['reserved']:
            raise BudgetExceeded('Missing reservation; spending ledger may be corrupted')
        d['reserved'].pop(rid)
        if charge > 0:
            d['usd']=float(d.get('usd',0)) + float(charge)
            d['log'].append({'t':time.time(),'usd':charge,'note':note})
            d['log']=d['log'][-500:]
        _ledger_write(d)

def _spend() -> Spend:
    return Spend(config.STATE_DIR / "spend.json")


def budget_usd() -> float:
    return float(os.environ.get("PHYSICA_BUDGET_USD", "15"))


def _price(role: str) -> tuple[float, float, bool]:
    r = role.upper()
    try:
        return float(os.environ[f"PRICE_{r}_IN"]), float(os.environ[f"PRICE_{r}_OUT"]), True
    except (KeyError, ValueError):
        lo, hi = UPPER_BOUND.get(role, (10.0, 40.0))
        return lo, hi, False


def _guard(est: float, note: str) -> None:
    sp = _spend()
    if sp.total() + est > budget_usd():
        raise BudgetExceeded(f"Spent ${sp.total():.2f}; this call could cost ${est:.3f}; hard stop ${budget_usd():.0f}")


def _key(role: str, model: str, messages: list[dict], params: dict) -> str:
    blob = json.dumps({"role": role, "model": model, "messages": messages, "params": params}, sort_keys=True, default=str)
    return hashlib.sha256(blob.encode()).hexdigest()[:24]


def _cache_paths(k: str) -> list[Path]:
    return [config.REPLAY_DIR / "llm" / f"{k}.json", config.REPO_ROOT / ".cache" / "llm" / f"{k}.json"]


def _write_cache(k: str, payload: dict) -> None:
    p = _cache_paths(k)[1]
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(payload, indent=1, default=str))


def _without_media(value):
    """A copy with inline pictures replaced by their fingerprint, so receipts stay small and hold no footage."""
    if isinstance(value, str) and value.startswith("data:image/"):
        return "inline image sha256:" + hashlib.sha256(value.encode()).hexdigest()
    if isinstance(value, dict):
        return {k: _without_media(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_without_media(v) for v in value]
    return value


def receipt(kind: str, model: str, request: dict, response: dict | str, usage: dict | None, task: str,
            seconds: float) -> Path:
    """A file proving a live call happened and what came back (no key, no headers)."""
    RECEIPTS.mkdir(parents=True, exist_ok=True)
    request = _without_media(request)
    now = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    rid = (response.get("id") if isinstance(response, dict) else None) or uuid.uuid4().hex[:12]
    p = RECEIPTS / f"{now}_{task}_{model}_{str(rid)[-10:]}.json"
    p.write_text(json.dumps({"mode": "LIVE META MODEL API", "kind": kind, "model": model, "task": task,
                             "endpoint": base_url(), "made_utc": now, "seconds": round(seconds, 2),
                             "request_sha256": hashlib.sha256(json.dumps(request, sort_keys=True, default=str).encode()).hexdigest(),
                             "request": request, "response": response, "usage": usage}, indent=1, default=str))
    return p


def _post(url: str, body: dict | bytes, timeout: float = 180.0, content_type: str = "application/json") -> dict:
    key = api_key()
    if not key:
        raise NotConfigured("MODEL_API_KEY is not set")
    data = body if isinstance(body, bytes) else json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, method="POST",
                                 headers={"Authorization": f"Bearer {key}", "Content-Type": content_type})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 (Meta API base from env/default)
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"Meta API {e.code}: {e.read().decode()[:500]}") from None


def complete(role: str, messages: list[dict], task: str, *, tools: list[dict] | None = None,
             tool_choice=None, response_format: dict | None = None, max_completion_tokens: int = 1500,
             reasoning_effort: str | None = None, temperature: float | None = None,
             require_fresh: bool = False) -> dict:
    """One chat turn. Returns {'content', 'tool_calls', 'mode', 'model'}; tool_calls in the API's own shape."""
    if role not in ("spark", "wonder"):
        raise ValueError(f"unknown chat role {role}")
    model = model_id(role)
    params = {"tools": tools, "tool_choice": tool_choice, "response_format": response_format,
              "max_completion_tokens": max_completion_tokens, "reasoning_effort": reasoning_effort, "task": task}
    k = _key(role, model, messages, params)
    for p in ([] if require_fresh else _cache_paths(k)):
        if p.exists():
            d = json.loads(p.read_text())
            if not is_mock() and d.get("mode") != "live":
                continue  # never pass an offline stand-in off as a live answer
            return {"content": d.get("text"), "tool_calls": d.get("tool_calls"), "mode": "replay of " + d.get("mode", "?"),
                    "model": d.get("model", model)}
    if is_mock():
        if require_fresh:
            raise NotConfigured("Fresh authenticated Meta call required: set MODEL_API_KEY and MOCK=0")
        if task not in _MOCKS:
            raise NotConfigured(f"No Meta key (MOCK) and no offline stand-in for task '{task}'")
        out = _MOCKS[task](messages)
        msg = json.loads(out) if out.strip().startswith("{\"tool_calls\"") else {"content": out}
        res = {"content": msg.get("content"), "tool_calls": msg.get("tool_calls"), "mode": "offline stand-in (not Meta)",
               "model": "none"}
        _write_cache(k, {"text": res["content"], "tool_calls": res["tool_calls"], "mode": res["mode"], "model": "none"})
        return res
    pin, pout, exact = _price(role)
    prompt_chars = sum(len(json.dumps(_without_media(m.get("content", "")))) for m in messages) + len(json.dumps(tools or []))
    prompt_chars += 8000 * json.dumps(messages).count('"image_url":')     # a picture costs tokens too, far fewer than its text form
    est = (prompt_chars / 4) * pin / 1e6 + max_completion_tokens * pout / 1e6
    rid = _reserve(est, task)
    body = {"model": model, "messages": messages, "max_completion_tokens": max_completion_tokens}
    for name, v in (("tools", tools), ("tool_choice", tool_choice), ("response_format", response_format),
                    ("reasoning_effort", reasoning_effort), ("temperature", temperature)):
        if v is not None:
            body[name] = v
    t0 = time.time()
    try:
        resp = _post(f"{base_url()}/chat/completions", body)
    except Exception:
        _settle(rid, est, f'{role}:{task} uncertain failed request')
        raise
    msg = resp["choices"][0]["message"]
    usage = resp.get("usage") or {}
    cost = (usage.get("prompt_tokens", prompt_chars / 4) * pin + usage.get("completion_tokens", max_completion_tokens) * pout) / 1e6
    _settle(rid, max(cost,0), f"{role}:{task}{'' if exact else ' (upper-bound price)'}")
    receipt_file = receipt("chat", model, body, resp, usage, task, time.time() - t0)
    _write_cache(k, {"text": msg.get("content"), "tool_calls": msg.get("tool_calls"), "mode": "live", "model": model,
                     "usage": usage})
    return {"content": msg.get("content"), "tool_calls": msg.get("tool_calls"), "mode": "live", "model": model,
            "api_response_id": resp.get("id"), "receipt_path": str(receipt_file),
            "finish_reason": resp["choices"][0].get("finish_reason"), "usage": usage}


def chat(role: str, messages: list[dict], task: str, max_tokens: int = 2000, temperature: float = 0.7) -> str:
    """Backward-compatible text-only call used across Physica."""
    m = [dict(x) for x in messages]
    return complete(role, m, task, max_completion_tokens=max_tokens,
                    temperature=None if is_mock() else temperature)["content"] or ""


def upload_file(path: str | Path, purpose: str = "user_data") -> str:
    """Files API (multipart). Returns the file id."""
    p = Path(path)
    boundary = uuid.uuid4().hex
    mime = "video/mp4" if p.suffix.lower() == ".mp4" else ("video/quicktime" if p.suffix.lower() == ".mov" else "application/octet-stream")
    body = (f"--{boundary}\r\nContent-Disposition: form-data; name=\"purpose\"\r\n\r\n{purpose}\r\n"
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{p.name}\"\r\n"
            f"Content-Type: {mime}\r\n\r\n").encode() + p.read_bytes() + f"\r\n--{boundary}--\r\n".encode()
    return _post(f"{base_url()}/files", body, content_type=f"multipart/form-data; boundary={boundary}")["id"]


def _count_frames(path: str | Path) -> int:
    """SAM is billed per processed frame, so the hard stop must see the real clip length, not a default."""
    try:
        import cv2
        cap = cv2.VideoCapture(str(path))
        n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        cap.release()
    except Exception:
        n = 0
    if n <= 0:
        raise ValueError(f"cannot count the frames in {path}, so the SAM cost can't be bounded")
    return n


def sam_video(path: str | Path, concept: str, n_frames: int | None = None, task: str = "sam_track") -> dict:
    """SAM 3.1 tracks every instance of `concept` (a short noun phrase) through a video.
    Returns {'frames': {frame: [{'id', 'box': (x1,y1,x2,y2), 'score'}]}, 'mode', 'raw_text_chars'}."""
    if is_mock():
        raise NotConfigured("SAM needs a live Meta key (MOCK=0, MODEL_API_KEY); Physica falls back to motion grouping")
    from physica.meta.sam import parse_sam_text  # local import to keep this module light
    model = model_id("sam")
    frames = n_frames or _count_frames(path)
    est = max(frames, 50) * float(os.environ.get("PRICE_SAM_FRAME", UPPER_BOUND["sam_frame"]))
    rid = _reserve(est, task)
    try:
        fid = upload_file(path)
    except Exception:
        _settle(rid, 0, task + ' upload failure')
        raise
    body = {"model": model, "stream": True, "input": [{"type": "message", "role": "user", "content": [
        {"type": "input_text", "text": concept}, {"type": "input_video", "file_id": fid}]}],
        "metadata": {"propagation_direction": "both", "include_confidence": "true", "mask_encoding": "one_bit"}}
    t0 = time.time()
    req = urllib.request.Request(f"{base_url()}/responses", data=json.dumps(body).encode(), method="POST",
                                 headers={"Authorization": f"Bearer {api_key()}", "Content-Type": "application/json",
                                          "Accept": "text/event-stream"})
    text, events = [], 0
    try:
        with urllib.request.urlopen(req, timeout=600) as r:  # noqa: S310
            for raw in r:
                line = raw.decode(errors="replace").strip()
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]": break
                try: ev = json.loads(payload)
                except json.JSONDecodeError: continue
                events += 1
                if ev.get("type", "").endswith("output_text.delta"):
                    text.append(ev.get("delta", ""))
        full = "".join(text)
        parsed = parse_sam_text(full)
    except Exception:
        # A remote service may still bill a request even if the client fails;
        # conservatively retain the full reserved cost.
        _settle(rid, est, task + ' uncertain streaming failure')
        raise
    _settle(rid, est, task)
    receipt("sam", model, {**body, "input": "[video file_id " + fid + "]"},
            {"events": events, "frames": len(parsed), "first_lines": full[:600]}, None, task, time.time() - t0)
    return {"frames": parsed, "mode": "live", "model": model, "raw_text_chars": len(full)}


def sam_text(path: str | Path, prompt: str, metadata: dict | None = None, n_frames: int | None = None, task: str = "sam_points") -> dict:
    """SAM 3.1 with any prompt, including Muse's points, keeping the whole reply: the masks are the point of the call."""
    if is_mock():
        raise NotConfigured("SAM needs a live Meta key (MOCK=0, MODEL_API_KEY)")
    model = model_id("sam")
    frames = n_frames or _count_frames(path)
    est = max(frames, 50) * float(os.environ.get("PRICE_SAM_FRAME", UPPER_BOUND["sam_frame"]))
    rid = _reserve(est, task)
    try:
        fid = upload_file(path)
    except Exception:
        _settle(rid, 0, task + " upload failure")
        raise
    body = {"model": model, "stream": True, "input": [{"type": "message", "role": "user", "content": [
        {"type": "input_text", "text": prompt}, {"type": "input_video", "file_id": fid}]}], "metadata": {"include_confidence": "true", **(metadata or {})}}
    t0 = time.time()
    req = urllib.request.Request(f"{base_url()}/responses", data=json.dumps(body).encode(), method="POST",
                                 headers={"Authorization": f"Bearer {api_key()}", "Content-Type": "application/json", "Accept": "text/event-stream"})
    text, events = [], 0
    try:
        with urllib.request.urlopen(req, timeout=600) as r:  # noqa: S310
            for raw in r:
                line = raw.decode(errors="replace").strip()
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    break
                try:
                    ev = json.loads(payload)
                except json.JSONDecodeError:
                    continue
                events += 1
                if ev.get("type", "").endswith("output_text.delta"):
                    text.append(ev.get("delta", ""))
    except urllib.error.HTTPError as e:
        _settle(rid, 0, task + " refused")
        raise RuntimeError(f"Meta API {e.code}: {e.read().decode()[:500]}") from None
    except Exception:
        _settle(rid, est, task + " uncertain streaming failure")
        raise
    _settle(rid, est, task)
    full = "".join(text)
    file = receipt("sam", model, {**body, "input": "[video file_id " + fid + "] " + prompt}, {"events": events, "chars": len(full), "first_lines": full[:600]}, None, task, time.time() - t0)
    return {"text": full, "mode": "live", "model": model, "usd": round(est, 4), "frames_sent": frames, "receipt_path": str(file)}


def video_part(path: str | Path) -> dict:
    """Upload a film for Muse to watch. The Responses API takes it by file id."""
    return {"type": "input_video", "file_id": upload_file(path)}


def _flat_tool(t: dict) -> dict:
    f = t.get("function")
    return {"type": "function", **f} if f else t


def respond(role: str, input_items, task: str, *, tools: list[dict] | None = None, previous_response_id: str | None = None, schema: dict | None = None,
            max_output_tokens: int = 16000, effort: str | None = None, media_usd: float = 0.0, _again: bool = False) -> dict:
    """One turn on the Responses API, which keeps Muse's reasoning between tool calls and can watch video. Same hard stop and receipts
    as chat. The cost comes from the usage the API reports. A schema the endpoint refuses is dropped once, and the reply is read as plain JSON."""
    if role not in ("spark", "wonder"):
        raise ValueError(f"unknown chat role {role}")
    if is_mock():
        raise NotConfigured("Muse needs a live key for this (MOCK=0, MODEL_API_KEY)")
    model = model_id(role)
    pin, pout, exact = _price(role)
    chars = len(json.dumps(_without_media(input_items))) + len(json.dumps(tools or []))
    est = (chars / 4) * pin / 1e6 + max_output_tokens * pout / 1e6 + media_usd
    rid = _reserve(est, task)
    body = {"model": model, "input": input_items, "max_output_tokens": max_output_tokens}
    if tools:
        body["tools"] = [_flat_tool(t) for t in tools]
    if previous_response_id:
        body["previous_response_id"] = previous_response_id
    if effort:
        body["reasoning"] = {"effort": effort}
    if schema:
        body["text"] = {"format": {"type": "json_schema", "name": schema.get("title", "Answer"), "schema": schema, "strict": False}}
    t0 = time.time()
    try:
        try:
            resp = _post(f"{base_url()}/responses", body, timeout=600)
        except RuntimeError as e:
            if not schema or "Meta API 400" not in str(e):
                raise
            body.pop("text", None)
            resp = _post(f"{base_url()}/responses", body, timeout=600)
    except Exception:
        _settle(rid, est, f"{role}:{task} uncertain failed request")
        raise
    text, calls = [], []
    for item in resp.get("output") or []:
        if item.get("type") == "message":
            text += [c.get("text", "") for c in item.get("content") or [] if c.get("type") in ("output_text", "text")]
        elif item.get("type") == "function_call":
            calls.append({"id": item.get("call_id") or item.get("id"), "type": "function", "function": {"name": item.get("name"), "arguments": item.get("arguments") or "{}"}})
    usage = resp.get("usage") or {}
    cost = (usage["input_tokens"] * pin + usage["output_tokens"] * pout) / 1e6 if {"input_tokens", "output_tokens"} <= set(usage) else est
    _settle(rid, max(cost, 0), f"{role}:{task}{'' if exact else ' (upper-bound price)'}")
    file = receipt("responses", model, {**body, "input": _without_media(input_items)}, resp, usage, task, time.time() - t0)
    if not text and not calls and not _again:     # reasoning counts against the output limit, so a reply can run out before it says anything
        return respond(role, input_items, task, tools=tools, previous_response_id=previous_response_id, schema=schema, max_output_tokens=max(32000, max_output_tokens * 2), effort="low", media_usd=media_usd, _again=True)
    return {"empty_why": None if text or calls else f"status {resp.get('status')}, {resp.get('incomplete_details')}, output {[i.get('type') for i in resp.get('output') or []]}, {usage.get('output_tokens')} output tokens", "content": "".join(text) or None, "tool_calls": calls or None, "mode": "live", "model": model, "response_id": resp.get("id"), "status": resp.get("status"),
            "usage": usage, "usd": round(max(cost, 0), 5), "receipt_path": str(file)}


def freeze_for_replay() -> int:
    """Copy the local cache into replay/llm/ so the demo runs without an API key."""
    src = config.REPO_ROOT / ".cache" / "llm"
    dst = config.REPLAY_DIR / "llm"
    dst.mkdir(parents=True, exist_ok=True)
    n = 0
    for f in src.glob("*.json"):
        (dst / f.name).write_text(f.read_text())
        n += 1
    return n


def status() -> dict:
    return {"mode": mode(), "endpoint": base_url(), "key_present": bool(api_key()),
            "models": {r: model_id(r) for r in MODELS}, "spent_usd": round(_spend().total(), 4),
            "hard_stop_usd": budget_usd(), "receipts": len(list(RECEIPTS.glob("*.json"))) if RECEIPTS.exists() else 0}


def post_raw(path: str, body: dict, task: str, est_usd: float = 0.05, timeout: float = 120.0) -> dict:
    """For modules that build their own request bodies: same key, endpoint, hard stop and receipt as everything else."""
    if is_mock():
        raise NotConfigured("Live Meta call needs MOCK=0 and MODEL_API_KEY in your local environment")
    rid=_reserve(est_usd, task)
    t0 = time.time()
    try:
        resp = _post(f"{base_url()}/{path.lstrip('/')}", body, timeout=timeout)
    except Exception:
        _settle(rid, est_usd, f'{task} (uncertain failed request)')
        raise
    usage = resp.get("usage") if isinstance(resp, dict) else None
    _settle(rid, est_usd, f"{task} (flat estimate)")
    receipt(path.strip("/"), str(body.get("model")), body, resp, usage, task, time.time() - t0)
    return resp
