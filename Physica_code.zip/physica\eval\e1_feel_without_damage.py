"""E1: feel propeller damage with NO damage training (PADRE, real flights).

Physica: self-model learned from the healthy calibration half only.
Baselines: (a) random forest trained on rotor-A damage + healthy calibration (needs failure data);
           (b) plain spectrogram + threshold (no self-model): band power vs healthy statistics.
Test: single-rotor damage on rotors B, C, D (never used for training anywhere) + held-out healthy.
"""
from __future__ import annotations

import numpy as np
from sklearn.ensemble import RandomForestClassifier

from common import SEED, SINGLE, CFG, binom_ci, cluster_boot_ci, healthy_split, padre_features, save_result
from physica.data import padre
from physica.feel.selfmodel import OperatingPointSelfModel


def main():
    split = healthy_split()
    h = padre_features("0000")
    cal, ho = np.array(split["calib"]), np.array(split["heldout"])

    # --- Physica: self-model from healthy only
    sm = OperatingPointSelfModel(unit_names=list("ABCD")).fit(h["op"][cal], h["lvl"][cal])
    thr = sm.calibrate_threshold(h["op"][cal], h["lvl"][cal], CFG.q, CFG.margin)
    phys = lambda d: sm.z(d["op"], d["lvl"]).max(axis=1) > thr

    # --- Baseline (b): plain spectrogram + threshold (no self-model)
    m_band = (h["f"] >= CFG.band[0]) & (h["f"] <= CFG.band[1])
    def bandpow(d):
        return 10 * np.log10(d["psd"][:, :, m_band].sum(axis=2) + 1e-30)
    bp = bandpow(h)
    mu, sd = bp[cal].mean(axis=0), bp[cal].std(axis=0, ddof=1)
    zc = ((bp[cal] - mu) / sd).max(axis=1)
    thr_b = float(np.quantile(zc, CFG.q) + CFG.margin)
    spec = lambda d: (((bandpow(d) - mu) / sd).max(axis=1) > thr_b)

    # --- Baseline (a): RF trained on real rotor-A damage
    feats = lambda d: d["bins"].reshape(len(d["bins"]), -1)
    XA = np.vstack([feats(h)[cal]] + [feats(padre_features(c)) for c in SINGLE["A"]])
    yA = np.r_[np.zeros(len(cal)), np.ones(sum(len(padre_features(c)["op"]) for c in SINGLE["A"]))]
    rf = RandomForestClassifier(n_estimators=300, random_state=SEED).fit(XA, yA)
    rfp = lambda d: rf.predict(feats(d)).astype(bool)

    methods = {"physica_selfmodel_no_damage_data": phys, "spectrogram_threshold_no_selfmodel": spec,
               "random_forest_trained_on_rotorA_damage": rfp}
    hd = {"op": h["op"][ho], "lvl": h["lvl"][ho], "psd": h["psd"][ho], "bins": h["bins"][ho]}
    out = {"split": split, "threshold_z": thr, "methods": {}}
    for name, fn in methods.items():
        fa = fn(hd).astype(float)
        per_file, groups = {}, []
        for r in "BCD":
            for c in SINGLE[r]:
                det = fn(padre_features(c)).astype(float)
                per_file[c] = {"rotor": r, "fault": padre.fault_map(c)[r], "detect": float(det.mean()), "n": len(det)}
                groups.append(det)
        allw = np.concatenate(groups)
        out["methods"][name] = {
            "detect_rate_BCD": float(allw.mean()), "detect_ci95_cluster_by_flight": cluster_boot_ci(groups),
            "false_alarm_rate_heldout_healthy": float(fa.mean()), "false_alarm_ci95_exact": binom_ci(int(fa.sum()), len(fa)),
            "n_damage_windows": int(len(allw)), "n_heldout_healthy_windows": int(len(fa)),
            "uses_damage_data": name.startswith("random_forest"), "per_file": per_file}
    # Physica also on rotor A (it never used any damage data, so A is fair game for it)
    gA = [phys(padre_features(c)).astype(float) for c in SINGLE["A"]]
    out["methods"]["physica_selfmodel_no_damage_data"]["detect_rate_A"] = float(np.concatenate(gA).mean())
    p = save_result("E1_feel_without_damage", out)
    for k, v in out["methods"].items():
        print(f"{k:42s} detect(BCD)={v['detect_rate_BCD']:.3f} CI{np.round(v['detect_ci95_cluster_by_flight'],3)} "
              f"falseAlarm={v['false_alarm_rate_heldout_healthy']:.3f} CI{np.round(v['false_alarm_ci95_exact'],3)}")
    print("saved", p)


if __name__ == "__main__":
    main()
