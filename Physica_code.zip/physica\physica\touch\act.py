"""From felt body to machine code: imagine the consequence of every candidate action, keep the best, write it in
the machine's language, and promise the felt result before acting.

Two kinds of action:
  - shape_motion: a machine that MOVES this object (robot, printer gantry, drone arm) should command its moves so
    the object's own modes are not excited (input shaping). Felt consequence: remaining ringing, computed by
    running the shaped and unshaped commands through the felt body.
  - counter_tap: after a touch, where, when and how hard should a robot tap to stop the ringing fastest? The AI
    tries thousands of taps in its head (each one is a few multiplications per mode) and feels each result.
"""
from __future__ import annotations

import numpy as np


def mode_response(freq, zeta, u, fs):
    """Displacement of one unit-mass mode driven by acceleration command u (base excitation)."""
    w = 2 * np.pi * freq
    wd = w * np.sqrt(1 - zeta ** 2)
    a, dt = np.exp(-zeta * w / fs), 1 / fs
    # exact discrete impulse-invariant recursion for x'' + 2 zeta w x' + w^2 x = -u
    c1, c2 = 2 * a * np.cos(wd * dt), -a ** 2
    b = -dt ** 2
    x = np.zeros(len(u))
    for t in range(2, len(u)):
        x[t] = c1 * x[t - 1] + c2 * x[t - 2] + b * u[t - 1]
    return x


def zv(freq, zeta):
    K = np.exp(-zeta * np.pi / np.sqrt(1 - zeta ** 2))
    return np.array([1, K]) / (1 + K), np.array([0.0, 0.5 / (freq * np.sqrt(1 - zeta ** 2))])


def shape(u, fs, shapers):
    out = u.copy()
    for A, T in shapers:
        y = np.zeros(len(out) + int(np.ceil(T[-1] * fs)) + 2)
        for a, t in zip(A, T):
            i = int(round(t * fs))
            y[i:i + len(out)] += a * out
        out = y[: len(out)]
    return out


def shape_motion(modes: list[dict], fs: float = 1000.0, move_s: float = 0.25, settle_s: float = 2.0) -> dict:
    """modes: [{'freq_hz', 'damping'}]. A fast point-to-point move (bang-bang acceleration) with and without input
    shaping, felt through the object's own modes. Returns the shaper and the felt remaining ringing."""
    n = int((move_s + settle_s) * fs)
    u = np.zeros(n)
    h = int(move_s * fs / 2)
    u[:h], u[h:2 * h] = 1.0, -1.0
    shapers = [zv(m["freq_hz"], m["damping"]) for m in modes]
    us = shape(u, fs, shapers)
    after = slice(2 * h + int(np.ceil(sum(T[-1] for _, T in shapers) * fs)), n)
    felt = {}
    for name, cmd in (("unshaped", u), ("shaped", us)):
        tot = sum(np.sqrt(np.mean(mode_response(m["freq_hz"], m["damping"], cmd, fs)[after] ** 2)) for m in modes)
        felt[name] = tot
    delay = float(sum(T[-1] for _, T in shapers))
    return {"shapers": [{"freq_hz": m["freq_hz"], "damping": m["damping"], "amplitudes": A.tolist(), "times_s": T.tolist()}
                        for m, (A, T) in zip(modes, shapers)],
            "felt_ringing_left": float(felt["shaped"] / felt["unshaped"]), "added_delay_s": delay}


def counter_tap(freqs, zetas, shapes_at, z0, horizon_s: float = 2.0, max_wait_s: float = 0.6, step_s: float = 0.002) -> dict:
    """Imagine a tap at every place and moment and feel the ringing each one leaves; keep the best.
    freqs, zetas: modes. shapes_at: (K, X) unit-RMS mode shapes at the candidate tap points. z0: complex modal
    displacement state right after the touch (mode k moves as 2 Re(z_k exp(s_k t))). A tap of impulse F/m at x
    adds phi_k(x) F / (2i omega_dk) to z_k. For each place and moment, the best strength has a closed form
    (the felt ringing is quadratic in F), so each imagined tap costs a few multiplications per mode."""
    f, zt = np.asarray(freqs, float), np.asarray(zetas, float)
    s = -zt * 2 * np.pi * f + 1j * 2 * np.pi * f * np.sqrt(1 - zt ** 2)
    c = (1 - np.exp(2 * s.real * horizon_s)) / (-2 * s.real)          # energy weight per mode over the horizon
    kick = shapes_at / (2j * s.imag[:, None])                          # (K, X): modal amplitude per unit tap
    waits = np.arange(0, max_wait_s, step_s)
    best, tried = None, 0
    for w in waits:
        zw = z0 * np.exp(s * w)
        num = -np.real((c[:, None] * np.conj(kick) * zw[:, None]).sum(0))
        den = (c[:, None] * np.abs(kick) ** 2).sum(0)
        F = np.where(den > 1e-12 * den.max(), num / np.maximum(den, 1e-300), 0.0)  # best strength (0 at the clamp)
        E = (c[:, None] * np.abs(zw[:, None] + kick * F[None, :]) ** 2).sum(0)
        tried += len(F)
        j = int(np.argmin(E))
        if best is None or E[j] < best["energy"]:
            best = {"energy": float(E[j]), "wait_s": float(w), "point": j, "impulse_per_mass": float(F[j]),
                    "untouched_energy": float((c * np.abs(zw) ** 2).sum())}
    best["ringing_left"] = float(np.sqrt(best["energy"] / best["untouched_energy"]))
    best["tried"] = tried
    return best
