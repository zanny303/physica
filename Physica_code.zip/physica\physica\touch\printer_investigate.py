"""Muse runs the investigation. It can see and reason but it can't feel, so it calls Physica as its sense.

One run covers what Muse can do before a person has to act. It looks at the films, feels the machine through tools, proposes causes,
and asks Physica to design a test. Then it stops and tells the person what to do. After the person runs the test, a second run reads
the result, explains it, and proposes what to test next. Muse moves nothing. Every number comes from a tool, Spark can
challenge its ideas, and any number it writes that wasn't measured is flagged. It never sees the truth of a blind trial.
"""
from __future__ import annotations

import json
from typing import Callable

from physica.touch import printer_cause as C
from physica.touch import printer_muse as M

TASK = "physica_printer_investigation"


def _tool(name: str, description: str, props: dict | None = None) -> dict:
    props = {"why": {"type": "string", "description": "one short plain sentence: why you're doing this"}, **(props or {})}
    return {"type": "function", "function": {"name": name, "description": description, "parameters": {
        "type": "object", "properties": props, "required": list(props), "additionalProperties": False}}}


TOOLS = [
    _tool("say_what_you_see", "State what you can and can't tell from looking at the photos alone, before using any sense.", {"seen": {"type": "string"}}),
    _tool("feel_the_machine", "Physica's sense: the head's tone in the healthy films and in the changed film, with its limits."),
    _tool("feel_the_parts", "Physica's sense on each part SAM separated: how much each part moves at the head's tone."),
    _tool("segment_and_feel", "Choose a part yourself. Point at it on the image, on a 0 to 1000 grid with (0,0) at the top left. SAM pins it through the film, and Physica reads the motion of only those pixels.", {
        "part": {"type": "string"}, "x": {"type": "integer"}, "y": {"type": "integer"}}),
    _tool("look_closer", "See one frame of the film at a time you choose, in seconds of real time.", {"seconds": {"type": "number"}}),
    _tool("add_cause", "Propose one cause to test. It becomes a sealed forecast.", {
        "name": {"type": "string"}, "story": {"type": "string"},
        "mass_share": {"type": "number", "description": "0.05 to 0.95: how much of the tone's fall comes from mass, with the rest from lost stiffness"},
        "responds_to_weight": {"type": "boolean", "description": "false only if this tone doesn't come from the head's mass on its belts"}}),
    _tool("design_experiment", "Ask Physica for the known weight that best separates every cause. Seals the forecasts. A person will fasten the weight and film."),
    _tool("read_experiment", "The result of the experiment, once a person has run it."),
    _tool("finish", "End this stage.", {"explanation": {"type": "string", "description": "what you now believe and how sure you are, using only numbers from the tools"},
                                        "for_the_person": {"type": "string", "description": "exactly what the person should do next"}}),
]

SYSTEM = """You are Muse, investigating a real 3D printer whose vibration tone has changed. You can see and reason, but you can't feel. \
Physica gives you that sense through tools. The tone follows f = sqrt(k/m)/(2 pi), for stiffness k and moving mass m. Physica already compares \
two causes, all from more mass and all from less stiffness. A person does anything physical, and you can't move the machine.
Work in order. First say_what_you_see. Then feel the machine, and the parts if available. If you've been given the film, use segment_and_feel on any part you want measured, and look_closer on any moment you want to see. You decide what gets measured. Before an experiment: add up to 3 causes that \
go beyond those two, call design_experiment, then finish and tell the person exactly what to do. After an experiment: read_experiment, say what \
it supports or rules out, add causes only if something is still open, then finish.
Only state numbers that a tool gave you, exactly as given. A forecast that fits is support, not proof. If you can't tell, say so. Say why in each call, in one short plain sentence for a general audience."""


class Case:
    """What Muse's tools can reach. Files are saved by the caller, so the existing plan-test and test steps keep working."""
    tools, system = TOOLS, SYSTEM

    def stage(self) -> str:
        return "The experiment has been run. Read the result." if self.result else "Nothing has been tested yet."

    def __init__(self, report: dict, model: dict | None, masses: list[float], parts: dict | None = None, result: dict | None = None, round_no: int = 1,
                 save: Callable[[str, dict], None] = lambda name, data: None, film=None):
        self.report, self.model, self.masses, self.parts, self.result = report, model, masses, parts, result
        self.round, self.save, self.film = round_no, save, film
        self.images: list[tuple[str, str]] = []
        self.chose: list[dict] = []
        self.rivals: list[dict] = []
        self.plan: dict | None = None
        self.dropped: list[dict] = []
        self.done: dict | None = None
        self.seen = ""

    def call(self, name: str, a: dict) -> dict:
        if name == "say_what_you_see":
            self.seen = str(a.get("seen", ""))[:500]
            return {"noted": True}
        if name == "feel_the_machine":
            return {"measured": M._context(self.report), "healthy": self.report.get("baseline"), "note": "From pixels in phone films, not a contact sensor"}
        if name == "feel_the_parts":
            return {"parts": self.parts["parts"], "tone_hz": self.parts.get("tone_hz"), "limit": self.parts.get("limit")} if self.parts else {"unavailable": "SAM hasn't separated the parts for this printer"}
        if name == "segment_and_feel":
            if self.film is None:
                return {"unavailable": "no film for this stage"}
            part = str(a.get("part", ""))[:60] or "part"
            try:
                self.film.pin({part: (int(min(max(a.get("x", 0), 0), 1000)), int(min(max(a.get("y", 0), 0), 1000)))})
                reader = getattr(self, "part_reader", None)      # a film with stops is read just after each stop
                got = reader(part) if reader else self.film.feel(part)
            except Exception as e:     # a failed look is a result too. Muse is told, and the investigation carries on
                return {"failed": str(e)[:200], "part": part}
            self.chose.append({k: got.get(k) for k in ("part", "tone_hz", "felt", "snr", "area_pct", "ringing_px", "stops") if k in got})
            return {k: got[k] for k in ("part", "felt", "tone_hz", "snr", "reason", "area_pct", "frames_tracked", "ringing_px", "stops", "note") if k in got}
        if name == "look_closer":
            if self.film is None:
                return {"unavailable": "no film for this stage"}
            t = float(a.get("seconds", 0) or 0)
            self.images.append((f"The frame at {t:g} s:", self.film.still(t)))
            return {"shown": t}
        if name == "add_cause":
            got = M.clean([a])
            if not got:
                return {"refused": "not testable: give mass_share from 0.05 to 0.95, or responds_to_weight false"}
            if got[0]["name"].lower() not in {r["name"].lower() for r in self.rivals} and len(self.rivals) < 3:
                self.rivals.append(got[0])
            return {"added": got[0]["name"], "causes_so_far": [r["name"] for r in self.rivals]}
        if name == "design_experiment":
            return self._design()
        if name == "read_experiment":
            if not self.result:
                return {"not_run_yet": True}
            keep = ("verdict", "reason", "added_g", "tone_with_weight_hz", "films", "rivals", "top_rival", "mass_change_percent", "stiffness_change_percent", "change_g", "change_percent")
            return {k: self.result[k] for k in keep if k in self.result}
        if name == "finish":
            self.done = {"explanation": str(a.get("explanation", ""))[:1200], "for_the_person": str(a.get("for_the_person", ""))[:500]}
            return {"ended": True}
        return {"error": f"no tool named {name}"}

    def _design(self) -> dict:
        if not self.model or not self.model.get("usable"):
            return {"refused": "the printer hasn't been calibrated with a known weight yet"}
        tone = (self.report.get("change") or {}).get("tone_now_hz")
        if tone is None:
            return {"refused": "no measured tone"}
        if self.rivals:
            try:
                review, _ = M._ask("spark", M.CHALLENGER, json.dumps({"measured": M._context(self.report), "ideas": self.rivals}, default=float), "physica_printer_challenge", M.CHALLENGE)
                drop = {str(r.get("name", "")).lower(): str(r.get("reason", ""))[:300] for r in review.get("reviews", []) if r.get("keep") is False}
                self.dropped += [{**r, "challenge": drop[r["name"].lower()]} for r in self.rivals if r["name"].lower() in drop]
                self.rivals = [r for r in self.rivals if r["name"].lower() not in drop]
            except Exception as e:     # a failed challenge doesn't stop the test. The ideas go ahead, and the record says so
                self.dropped.append({"name": "(challenge failed)", "challenge": str(e)[:200]})
        self.plan = C.plan_test(self.model, tone, self.masses, extra_rivals=self.rivals)
        self.save("plan", self.plan)
        self.save("causes", {"rivals": self.rivals, "dropped_by_spark": self.dropped, "round": self.round, "seen_in_photos": self.seen, "status": "IDEAS_NOT_PROOF"})
        g = self.plan.get("chosen_g")
        if not g:
            return {"refused": "none of the available weights separates the causes", "weights_tried": self.masses}
        t = self.plan["by_weight_g"][f"{g:g}"]
        return {"fasten_grams": g, "would_use_without_your_causes": self.plan.get("chosen_g_without_muse"), "removed_by_spark": [d["name"] for d in self.dropped], "sealed": self.plan["sealed"]["anchor"],
                "forecasts_hz": {"more_mass": t["more_mass_hz"], "less_stiffness": t["less_stiffness_hz"], **{n: v["forecast_hz"] for n, v in self.plan["muse_forecasts_by_weight_g"][f"{g:g}"].items()}}}


def _say(name: str, a: dict, out: dict) -> str:
    """One line a viewer can follow."""
    if name == "say_what_you_see":
        return f"Looking: {a.get('seen', '')}"
    if name == "feel_the_machine" and "head_tone_hz" in out:
        return f"Felt the machine: {out['head_tone_hz']} Hz at the head. If that's the flaw, ripples sit {out['ripple_spacing_if_this_tone_mm']} mm apart."
    if name == "feel_the_machine":
        m = out.get("measured") or {}
        return f"Felt the machine: tone {m.get('tone_baseline_hz')} Hz healthy, {m.get('tone_now_hz')} Hz now."
    if name == "feel_the_parts":
        p = out.get("parts")
        return "Felt each part: " + ", ".join(f"{k} {v.get('reading', '?')}" for k, v in p.items()) if p else "No separated parts yet."
    if name == "segment_and_feel":
        if out.get("ringing_px") is not None:
            return f"Chose to measure {out['part']}: {out['ringing_px']} px of motion at the head's tone of {out.get('tone_hz')} Hz."
        if out.get("felt"):
            return f"Chose to measure {out['part']}: {out['tone_hz']} Hz."
        return f"Chose to measure {out.get('part', a.get('part'))}: can't tell. {out.get('reason') or out.get('failed') or out.get('unavailable') or ''}".strip()
    if name == "look_closer":
        return f"Looked closer at {out['shown']:g} s." if "shown" in out else ""
    if name == "add_cause":
        return f"Proposed: {out['added']}. {a.get('story', '')}" if "added" in out else f"Couldn't test that idea: {out.get('refused')}"
    if name == "seal_the_tests":
        if "fasten_grams" not in out:
            return f"Couldn't seal the tests: {out.get('refused')}"
        return f"Physica sealed {out['sealed']}: ripples {out['ripple_spacing_mm']} mm apart if it's ringing, and the tone below {out['if_it_falls_below_hz']} Hz with {out['fasten_grams']:g} g on, if it comes from the head."
    if name == "read_the_tests":
        c = out.get("causes")
        return "Read the results: " + ", ".join(f"{k}: {v}" for k, v in c.items()) + "." if c else "No results yet."
    if name == "set_goal":
        return f"Set the goal: remove {100 * out['goal_set']:.0f}% of the ringing. {a.get('reason', '')}" if "goal_set" in out else f"Couldn't set that goal: {out.get('refused')}"
    if name == "design_experiment":
        if "fasten_grams" not in out:
            return f"Couldn't design a test: {out.get('refused')}"
        was = out.get("would_use_without_your_causes")
        note = f" Without Muse's causes it would use {was:g} g." if was != out["fasten_grams"] else ""
        return f"Physica sealed forecasts {out['sealed']}: fasten {out['fasten_grams']:g} g.{note}" + (f" Spark removed: {', '.join(out['removed_by_spark'])}." if out["removed_by_spark"] else "")
    if name == "read_experiment":
        return "No result yet." if out.get("not_run_yet") else f"Read the result: {out.get('verdict')}, {out.get('tone_with_weight_hz')} Hz with {out.get('added_g')} g on."
    return ""


class _Chat:
    """The conversation as Chat Completions: stills only. Used when there's no film, or if the Responses path is refused."""
    video_used = False

    def __init__(self, case, stage: str, photos):
        self.tools = case.tools
        self.msgs = [{"role": "system", "content": case.system}, {"role": "user", "content": M._parts(f"{stage} Here are the photos.", photos or [])}]
        if not photos:
            self.msgs[1]["content"] = f"{stage} No photos are available this time, so say that when you say what you see."

    def turn(self) -> dict:
        from physica.frontier.meta_council_v026 import _verified
        from physica.llm import meta_client as mc
        r = mc.complete("wonder", self.msgs, TASK, tools=self.tools, tool_choice="auto", max_completion_tokens=16000, require_fresh=True)
        r["proof"] = _verified(r, expected_role="wonder", task=TASK).get("receipt_sha256")
        if r.get("tool_calls"):
            self.msgs.append({"role": "assistant", "content": r.get("content") or "", "tool_calls": r["tool_calls"]})
        return r

    def nudge(self, text: str) -> None:
        self.msgs.append({"role": "user", "content": text})

    def results(self, outs: list[tuple[str, str]], images: list[tuple[str, str]]) -> None:
        self.msgs += [{"role": "tool", "tool_call_id": cid, "content": body} for cid, body in outs]
        if images:
            self.msgs.append({"role": "user", "content": M._parts("Here's what you asked to see.", images)})


class _Responses:
    """The same investigation on the Responses API, which Meta recommends for this work. Muse keeps its reasoning across tools, and watches the film."""
    def __init__(self, case, stage: str, photos, film_path):
        from physica.llm import meta_client as mc
        from physica.meta.scout import muse_clip
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as d:
            video = mc.video_part(muse_clip(film_path, Path(d) / "watch.mp4"))
        self.video_used, self.tools = True, case.tools
        content = [{"type": "input_text", "text": f"{case.system}\n\n{stage} You have the film of this machine, and photos."}, video]
        for label, url in photos or []:
            content += [{"type": "input_text", "text": label}, {"type": "input_image", "image_url": url}]
        self.next = [{"role": "user", "content": content}]
        self.prev = None

    def turn(self) -> dict:
        from physica.llm import meta_client as mc
        import hashlib
        from pathlib import Path
        r = mc.respond("wonder", self.next, TASK, tools=self.tools, previous_response_id=self.prev, effort="high", media_usd=0.10 if self.prev is None else 0.0)
        r["proof"] = hashlib.sha256(Path(r["receipt_path"]).read_bytes()).hexdigest()
        self.prev, self.next = r.get("response_id"), []
        return r

    def nudge(self, text: str) -> None:
        self.next.append({"role": "user", "content": [{"type": "input_text", "text": text}]})

    def results(self, outs: list[tuple[str, str]], images: list[tuple[str, str]]) -> None:
        self.next += [{"type": "function_call_output", "call_id": cid, "output": body} for cid, body in outs]
        if images:
            content = [{"type": "input_text", "text": "Here's what you asked to see."}]
            for label, url in images:
                content += [{"type": "input_text", "text": label}, {"type": "input_image", "image_url": url}]
            self.next.append({"role": "user", "content": content})


def investigate(case: Case, photos: list[tuple[str, str]] | None = None, on_step: Callable[[str], None] = print, most_steps: int = 14, film_path=None) -> dict:
    stage = case.stage()
    talk = _Chat(case, stage, photos)
    fell_back = None
    if film_path:
        try:
            talk = _Responses(case, stage, photos, film_path)
        except Exception as e:     # stills still work, and the record says Muse didn't watch
            fell_back = str(e)[:300]
            on_step(f"Muse couldn't be given the film, so it gets photos only: {fell_back}")
    steps, receipts, evidence, empties = [], [], [], 0
    for _ in range(most_steps):
        try:
            r = talk.turn()
        except RuntimeError as e:
            if not isinstance(talk, _Responses) or talk.prev is not None or "Meta API" not in str(e):
                raise
            fell_back = str(e)[:300]
            on_step(f"The film path was refused, so Muse continues with photos only: {fell_back}")
            talk = _Chat(case, stage, photos)
            r = talk.turn()
        receipts.append(r.get("proof"))
        calls = r.get("tool_calls") or []
        if not calls:
            empties += 1
            if empties > 2:
                break
            talk.nudge("Continue by calling a tool. When you've finished this stage, call finish.")
            continue
        outs = []
        for c in calls:
            name = c["function"]["name"]
            try:
                a = json.loads(c["function"].get("arguments") or "{}")
            except json.JSONDecodeError:
                a = {}
            out = case.call(name, a)
            evidence.append(out)
            line = _say(name, a, out)
            why = str(a.get("why", ""))[:200]
            steps.append({"tool": name, "why": why, "said": line})
            if why and name != "finish":
                on_step(f"Muse: {why}")
            if line:
                on_step(f"  {line}")
            outs.append((c.get("id", name), json.dumps(out, default=float)[:20000]))
        talk.results(outs, case.images)
        case.images = []
        if case.done:
            break
    done = case.done or {"explanation": "", "for_the_person": ""}
    used: dict[str, int] = {}
    for s in steps:
        used[s["tool"]] = used.get(s["tool"], 0) + 1
    return {"round": case.round, "steps": steps, **done, "muse_goal": getattr(case, "set_goal", None), "finished": bool(case.done), "rivals": case.rivals, "dropped_by_spark": case.dropped, "seen_in_photos": case.seen,
            "numbers_not_measured": M.check_numbers(done["explanation"], {"tools": evidence}), "experiment_read": bool(case.result), "chosen_g": (case.plan or {}).get("chosen_g"),
            "muse_watched_film": talk.video_used, "film_refused": fell_back, "tools_called": used, "muse_chose_to_measure": case.chose,
            "receipts_sha256": receipts, "status": "IDEAS_NOT_PROOF"}
