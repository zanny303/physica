# Physica v0.8.3 — Cloud Training, Meta-to-Machine Drafts and Discover Demo

This is an integration and experimentation release built **on top of the user-supplied v0.8.2 ZIP**; it is not a claim of physical AI foundation-model training.

## Added

- `physica/remote_bench/train.py`: externally sourced MAT/CSV vibration + current importer, 12 numerical features/channel, grouped train/test splits by physical `body_id`, three classifier ablations, safe numerical weight exports, duplicate-file checks, explicit simulated/real provenance.
- `physica/remote_bench/next_sensation.py`: near-future vibration prediction using previous vibration and/or current, with full-body holdout, same split across four methods and a persistence baseline. Motor current is NOT treated as a randomized physical action.
- `physica/remote_bench/index_external.py`: build Paderborn-style manifest from explicitly verified bearing metadata and inspected MAT field paths (never infer damage labels from filenames).
- `physica/remote_bench/synthetic_pilot.py`: generate tiny labeled synthetic recordings solely to exercise training end to end.
- `physica/remote_bench/machine_drafts.py`: uses an approved Muse-suggested action ID and independently measured numeric resonance/damping to emit non-executable, review-only printer or drone drafts through existing translators. Refuses uncalibrated/synthetic/unverified evidence.
- `physica/remote_bench/cli.py`: training, future-signal modeling, offline draft code generation, and an opt-in real Meta Spark/Wonder reasoning path with no model numerical authority or actuation.
- `physica/remote_bench/showcase.py`: interactive-layout, static, offline Discover exhibit with visibly labelled simulated metrics.
- `examples/cloud_v083/PHYSICA_REMOTE_TRAINING.ipynb`: starter Colab notebook. Dataset must be separately acquired under its license.
- `docs/V083_CLOUD_META_TRAINING_AND_THREE_DEMOS.md`: links to official remote datasets and labs, exact commands, evidence standards, and 3-minute demo storyboard.
- `tests/test_remote_bench_v083.py`: 12 new regression tests.

## Actually executed and validated

- Local synthetic pilot generated 40 recordings from 20 distinct simulated body IDs.
- Logistic regression classifiers were fitted and exported for vibration-only, current-only and both; body-level holdout used; the pilot deliberately separates classes easily and should **not** be cited as model performance.
- Three small linear near-future predictors were trained and exported on the same body-level holdout, plus persistence scored.
- No Paderborn, Physics-IQ, DROID or LabsLand data were downloaded or executed by this environment. These sources require separate data access.
- No Meta Model API call or pretrained Muse/V-JEPA weight training was performed. Live API path requires private credentials and explicit opt-in.
- No machine configuration was deployed; templates are drafts that require independent calibration, firmware checks, supervised review and rollback.

## Main research hypothesis, unchanged

Machine A can learn the causal consequence of an intervention through one set of physical sensors and teach machine B to anticipate it through a different set. The cloud baselines provide useful external observational evaluations but do not independently establish that claim. The next proof requires real intervention-grounded physical data.
