"""Target-directed safe experiment design under a calibrated linear-in-features model.

A-optimal Bayesian design is established prior art. The proposed *use* is to
choose source/target experiments for a receiving machine's anticipated action
conditions, maximizing reducible uncertainty at fixed experiment budget.
Does not actuate equipment. Candidate states/actions must be externally feasible.
"""
import numpy as np
from physica.causal_memory.core import features
from .transfer import SourcePrior,_design

def _precision(rows,prior,noise_sd):
    X,_=_design(rows)
    cov=np.asarray(prior.variance,float)
    return X.T@X/noise_sd**2+np.diag(1/cov)

def rank_probes(local_rows,prior,candidate_conditions,target_conditions,noise_sd=.02,budget=4,force_limit=1.,state_limit=1.):
    if not candidate_conditions or not target_conditions or budget<1 or budget>len(candidate_conditions):
        raise ValueError('invalid experiment candidates/budget')
    def validated(conditions):
        x=[]
        for row in conditions:
            state=np.asarray(row['state'],float);force=float(row['action'])
            if state.shape!=(2,) or not np.isfinite(state).all() or not np.isfinite(force):
                raise ValueError('invalid candidate')
            if abs(force)>force_limit or np.max(np.abs(state))>state_limit:
                raise ValueError('outside approved experiment constraints')
            x.append(features(state,force))
        return np.stack(x)
    candidates=validated(candidate_conditions)
    target_features=validated(target_conditions)
    Q=target_features.T@target_features/len(target_features)
    precision=_precision(local_rows,prior,noise_sd)
    selected=[];gains=[]
    for _ in range(budget):
        covariance=np.linalg.inv(precision)
        options=[]
        for idx,x in enumerate(candidates):
            if idx in selected:continue
            denom=noise_sd**2+x@covariance@x
            numerator=x@covariance@Q@covariance@x
            gain=max(0.,float(numerator/denom))
            options.append((gain,idx))
        # deterministic tie break, independent of target responses
        gain,idx=max(options,key=lambda item:(item[0],-item[1]))
        selected.append(idx);gains.append(gain)
        x=candidates[idx];precision+=np.outer(x,x)/noise_sd**2
    return {'selected_indices':selected,'predicted_uncertainty_reduction':gains,
            'total_predicted_reduction':float(sum(gains)),
            'algorithm':'target-directed Bayesian A-optimal design; non-actuating',
            'sensor_results_seen_during_selection':False,'estimated_targets_only':True}
