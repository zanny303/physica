"""Physically calibrated V-JEPA/world-model latent readout, fail-closed OOD.

Does NOT run or bundle V-JEPA weights; accepts REAL exported embeddings and
independently observed SI targets. Never treat a latent norm as force in N.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np


def _mat(values,name,*,minimum_rows=3):
    x=np.asarray(values,dtype=float)
    if x.ndim!=2 or x.shape[0]<minimum_rows or x.shape[1]<1 or not np.all(np.isfinite(x)):
        raise ValueError(f'{name} requires finite rows x features matrix (minimum rows validated by caller)')
    return x

def _target(y,n,name):
    y=np.asarray(y,dtype=float)
    if y.shape!=(n,) or not np.all(np.isfinite(y)):
        raise ValueError(f'{name} requires {n} finite target measurements')
    return y

@dataclass
class CalibratedReadout:
    model_id:str
    observable:str
    unit:str
    feature_mean:list[float]
    feature_scale:list[float]
    coefficients:list[float]
    intercept:float
    residual_quantile:float
    novelty_threshold:float
    alpha:float
    training_ids:list[str]
    calibration_ids:list[str]

    def predict(self,features,*,body_ids=None):
        X=_mat(features,'test world embeddings',minimum_rows=1)
        if X.shape[1]!=len(self.feature_mean):raise ValueError('embedding dimension has changed')
        if body_ids is not None:
            if len(body_ids)!=len(X):raise ValueError('one body ID per example required')
            if set(body_ids)&(set(self.training_ids)|set(self.calibration_ids)):
                raise ValueError('test body leakage: test embeddings must be disjoint')
        m=np.asarray(self.feature_mean);s=np.asarray(self.feature_scale)
        normalized=(X-m)/s
        novelty=np.linalg.norm(normalized,axis=1)/np.sqrt(X.shape[1])
        output=normalized@np.asarray(self.coefficients)+self.intercept
        return [{'status':'calibrated_unverified_world_forecast' if novelty[i]<=self.novelty_threshold else 'abstain_latent_out_of_domain',
                 'observable':self.observable,'unit':self.unit,
                 'mean':float(output[i]) if novelty[i]<=self.novelty_threshold else None,
                 'interval':([float(output[i]-self.residual_quantile),float(output[i]+self.residual_quantile)]
                             if novelty[i]<=self.novelty_threshold else None),
                 'novelty_score':float(novelty[i]),'model_id':self.model_id,
                 'conditions':'split-conformal marginal calibration only if calibration/test exchangeable',
                 'not_hardware_actuation_permission':True} for i in range(len(X))]


def fit_readout(train_embeddings,train_y,cal_embeddings,cal_y,*,
                train_body_ids,cal_body_ids,model_id,observable,unit,alpha=.1,ridge=.1):
    """Enforce disjoint body-level train/calibration partitions and split CP.

    Gives *marginal* scalar coverage under exchangeability. No causal or OOD
    guarantee; abstention threshold only a calibrated novelty heuristic.
    """
    X=_mat(train_embeddings,'training embeddings');V=_mat(cal_embeddings,'calibration embeddings')
    if V.shape[1]!=X.shape[1] or len(V)<8:raise ValueError('need >=8 matching calibration embeddings')
    y=_target(train_y,len(X),'training physical label');yc=_target(cal_y,len(V),'calibration physical label')
    if len(train_body_ids)!=len(X) or len(cal_body_ids)!=len(V) or (set(train_body_ids)&set(cal_body_ids)):
        raise ValueError('body-disjoint training and calibration necessary')
    if not model_id or not observable or not unit:raise ValueError('need explicit model and calibrated physical target')
    if not np.isfinite(alpha) or not 0<alpha<1 or not np.isfinite(ridge) or ridge<=0:
        raise ValueError('invalid conformal alpha or regularization')
    mean=X.mean(axis=0);std=np.maximum(X.std(axis=0),1e-8)
    Z=(X-mean)/std;T=(V-mean)/std
    intercept=float(y.mean());beta=np.linalg.solve(Z.T@Z+ridge*np.eye(Z.shape[1]),Z.T@(y-intercept))
    errors=np.abs(yc-(T@beta+intercept));n=len(errors)
    rank=int(np.ceil((n+1)*(1-alpha)))
    q=float(np.sort(errors)[min(rank,n)-1]) if rank<=n else float('inf')
    if not np.isfinite(q):raise ValueError('calibration too small for finite alpha interval')
    novelty=np.linalg.norm(T,axis=1)/np.sqrt(T.shape[1])
    # high quantile + small slack; not a distribution-free OOD detector
    threshold=float(np.max(novelty)*1.05+1e-6)
    return CalibratedReadout(model_id,observable,unit,mean.tolist(),std.tolist(),
        beta.tolist(),intercept,q,threshold,alpha,list(train_body_ids),list(cal_body_ids))


def temporal_features(videos):
    """Convert prerecorded video-embedding time series to causal-window features.

    Input: (N trajectories, T frames, D features), requiring 4+ frames.
    Training/validation boundaries MUST precede extraction: only past frames
    in each window are used; we never use a future post-action outcome as input.
    Uses mean, last, slope (last-first), standard deviation. These are generic
    engineered features, not a world model forward pass or V-JEPA inference.
    """
    x=np.asarray(videos,dtype=float)
    if x.ndim!=3 or min(x.shape)<1 or x.shape[1]<4 or not np.all(np.isfinite(x)):
        raise ValueError('temporal readout expects finite (N,T>=4,D) exported video embeddings')
    return np.concatenate([x.mean(axis=1),x[:,-1,:],x[:,-1,:]-x[:,0,:],x.std(axis=1)],axis=1)


def fit_temporal_readout(train_sequences,train_targets,cal_sequences,cal_targets,**kwargs):
    """Body-disjoint split-conformal readout of time-window embeddings in SI units.

    A trained readout does not establish that the underlying embeddings were
    actually produced by Meta; provenance must be supplied externally.
    """
    return fit_readout(temporal_features(train_sequences),train_targets,
                       temporal_features(cal_sequences),cal_targets,**kwargs)
