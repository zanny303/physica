"""Re-time signals to the machine's own clock (SPEC 3, step 3): order analysis."""
from __future__ import annotations

import numpy as np


def angle_from_speed(speed_hz: np.ndarray, fs: float) -> np.ndarray:
    """Shaft angle (rad) by integrating instantaneous rotation speed (rev/s)."""
    return 2 * np.pi * np.cumsum(np.asarray(speed_hz, float)) / fs


def order_amplitude(x: np.ndarray, fs: float, speed_hz: np.ndarray, order: float = 1.0) -> float:
    """Amplitude of the given order by synchronous demodulation (works with slowly varying speed)."""
    x = np.asarray(x, float) - np.mean(x)
    theta = angle_from_speed(speed_hz, fs)
    return float(2 * np.abs(np.mean(x * np.exp(-1j * order * theta))))


def angle_resample(x: np.ndarray, fs: float, speed_hz: np.ndarray, samples_per_rev: int = 64) -> np.ndarray:
    """Resample x at uniform shaft angle. Returns (n_revs*samples_per_rev,) samples."""
    theta = angle_from_speed(speed_hz, fs)
    revs = theta / (2 * np.pi)
    grid = np.arange(0, revs[-1], 1.0 / samples_per_rev)
    return np.interp(grid, revs, np.asarray(x, float))


def order_spectrum(x: np.ndarray, fs: float, speed_hz: np.ndarray, samples_per_rev: int = 64, max_order: float = 10.0):
    xa = angle_resample(x, fs, speed_hz, samples_per_rev)
    xa = xa - xa.mean()
    n = len(xa)
    spec = np.abs(np.fft.rfft(xa * np.hanning(n))) * 2 / (n / 2)
    orders = np.fft.rfftfreq(n, d=1.0 / samples_per_rev)
    m = orders <= max_order
    return orders[m], spec[m]
