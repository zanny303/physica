from physica.app.server import main

main()
