"""E14 - Jaw-droppers, checked where the truth is known (LABELLED SIMULATION: rendered phone videos).
  A. A camera that weighs things: random ruler, coin and object; grams and place from three videos.
  B. Tune a 3D printer by filming it: random printer mode; clock from the G-code; M593 from pixels; promise
     checked by filming again with the shaper on (and with a deliberately wrong one).
Real results need real phone videos (see README 'Film it yourself')."""
from __future__ import annotations

import json
import sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))
from physica.touch import printer_video as PV  # noqa: E402
from physica.touch import weigh  # noqa: E402


def weigh_trial(seed):
    from sim_ruler import render
    rng = np.random.default_rng(1000 + seed)
    ruler_g, f1 = 49.0, rng.uniform(9, 16)
    coin_g, xc = rng.choice([5.0, 5.67]), rng.uniform(0.6, 0.95)
    obj_g, xo = rng.uniform(5, 100), rng.uniform(0.3, 0.97)
    kw = dict(f1_empty=f1, zeta=rng.uniform(0.005, 0.02), tip_px=rng.uniform(8, 20))
    Ve, _ = render(0.0, seed=seed * 3, **kw)
    Vc, _ = render(coin_g / ruler_g, x=xc, seed=seed * 3 + 1, **kw)
    Vo, _ = render(obj_g / ruler_g, x=xo, seed=seed * 3 + 2, **kw)
    try:
        r = weigh.weigh_videos(Ve, Vc, Vo, 240.0, coin_g=float(coin_g))
    except Exception as e:  # noqa: BLE001
        return {"seed": seed, "error": str(e)}
    o = r["object"]
    return {"seed": seed, "true_g": obj_g, "felt_g": o["grams"], "g90": o["grams_90"], "true_place": xo,
            "seen_place": o["place_seen"], "felt_place": o["place"], "ruler_g": r["coin"]["ruler_g"]}


def printer_trial(seed):
    from sim_printer import render
    rng = np.random.default_rng(2000 + seed)
    f, z = rng.uniform(30, 70), rng.uniform(0.03, 0.1)
    V, info = render(f=f, zeta=z, seed=seed * 3)
    r = PV.tune(V)
    if "error" in r:
        return {"seed": seed, "error": r["error"]}
    fz = (r["felt"]["freq_hz"], max(r["felt"]["damping"], 0.01))
    Va, ia = render(f=f, zeta=z, shaper=fz, seed=seed * 3 + 1)
    Vw, iw = render(f=f, zeta=z, shaper=(fz[0] * 1.5, 0.03), seed=seed * 3 + 2)
    ca, cw = PV.check(r, Va), PV.check(r, Vw)
    base = info["ring_in_pauses_mm"]
    return {"seed": seed, "true_hz": f, "felt_hz": r["felt"]["freq_hz"], "true_zeta": z, "felt_zeta": r["felt"]["damping"],
            "fps_felt": r["clock"]["fps"], "right": {"true_drop": 1 - ia["ring_in_pauses_mm"] / base, "felt_drop": ca["ringing_drop_fraction"], "verdict": ca["judgement"]["verdict"]},
            "wrong": {"true_drop": 1 - iw["ring_in_pauses_mm"] / base, "felt_drop": cw["ringing_drop_fraction"], "verdict": cw["judgement"]["verdict"]}}


def main(n_w=12, n_p=6):
    with Pool(2) as pool:
        W = pool.map(weigh_trial, range(n_w))
        Pr = pool.map(printer_trial, range(n_p))
    ok = [w for w in W if "error" not in w]
    err = np.array([w["felt_g"] / w["true_g"] - 1 for w in ok])
    cover = np.mean([w["g90"][0] <= w["true_g"] <= w["g90"][1] for w in ok])
    seen = [w for w in ok if w["seen_place"] is not None]
    corrected = sum(abs(w["felt_place"] - w["true_place"]) < abs(w["seen_place"] - w["true_place"]) - 0.01 for w in seen)
    worse = sum(abs(w["felt_place"] - w["true_place"]) > abs(w["seen_place"] - w["true_place"]) + 0.01 for w in seen)
    pok = [p for p in Pr if "error" not in p]
    res = {"LABEL": "SIMULATION: rendered phone videos with known truth",
           "A_weigh": {"trials": n_w, "ran": len(ok), "abs_error_median_pct": 100 * float(np.median(np.abs(err))),
                       "within_10pct": float(np.mean(np.abs(err) < 0.10)), "within_20pct": float(np.mean(np.abs(err) < 0.20)),
                       "range_90_holds_truth": float(cover), "touch_moved_place_closer": int(corrected),
                       "touch_moved_place_further": int(worse), "trials_detail": W},
           "B_printer": {"trials": n_p, "ran": len(pok),
                         "fps_error_pct_max": 100 * float(max(abs(p["fps_felt"] / 240 - 1) for p in pok)),
                         "freq_error_pct_median": 100 * float(np.median([abs(p["felt_hz"] / p["true_hz"] - 1) for p in pok])),
                         "damping_felt_over_true_median": float(np.median([p["felt_zeta"] / p["true_zeta"] for p in pok])),
                         "right_shaper_true_drop_median": float(np.median([p["right"]["true_drop"] for p in pok])),
                         "right_shaper_kept": int(sum(p["right"]["verdict"] == "kept" for p in pok)),
                         "wrong_shaper_true_drop_median": float(np.median([p["wrong"]["true_drop"] for p in pok])),
                         "wrong_shaper_rolled_back": int(sum(p["wrong"]["verdict"] != "kept" for p in pok)),
                         "trials_detail": Pr}}
    (ROOT / "eval/results/E14_jawdroppers.json").write_text(json.dumps(res, indent=1, default=float))
    print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk != "trials_detail"} if isinstance(v, dict) else v
                      for k, v in res.items()}, indent=1, default=float))


if __name__ == "__main__":
    main()
