# Physica v0.24 — A physics-grounded curious world model

**Research prototype, November 2, 2026. This is a testable proposal—not proof of a scientific breakthrough, a conscious machine, an authenticated Meta experiment, or a real physical experiment.**

## 1. The question

Can an action-conditioned multisensory world model (1) detect a mechanism missing from its physical prior, (2) extract a falsifiable compact mathematical explanation that was not pre-entered verbatim, (3) acquire a targeted new measurement, and (4) predict the full future *real* sensory response before observing it—more accurately and with fewer experiments than strong baselines?

**The proposed scientific invention is a closed-loop combination, not the individual mechanisms.** Neural residual models, uncertainty-aware sensing, symbolic discovery, active experimental design, and LLM-based scientific agents all have substantial prior art.

## 2. Deep research: what is still missing

1. **Prediction is not explanation.** DiscoverPhysics (Wiemann et al., 2026) finds that accurate unseen trajectories do not necessarily yield correct hidden physical laws, particularly with latent mechanisms. Physica must independently score predictive RMSE, causal mechanism recovery, and explanatory correctness. https://arxiv.org/abs/2605.26087
2. **A neural residual is uninterpretable and out-of-distribution brittle.** Mechanistic world models (Posner, Lei, Schölkopf, 2026) frame reusable mechanisms rather than mere forecasts as the objective. https://arxiv.org/abs/2607.12474
3. **Fixed symbolic dictionaries leak the answer.** v0.23's impressive symbolic result includes the simulator's exact `sin(3.7x+1.15v)` term. ADAM-SINDy (2026) explicitly optimizes nonlinear equation parameters rather than requiring known frequencies. Physica now searches continuous frequency and direction parameters without providing the exact pair. https://doi.org/10.1103/dwkk-5g2h
4. **Neural-to-equation distillation is already researched.** Neural symbolic regression research (Nature Computational Science, 2025/2026) uses neural networks to help recover compact mathematical structure. This v0.24 prototype should not claim neural-guided symbolic identification is wholly new. https://www.nature.com/articles/s43588-025-00893-8
5. **Curiosity needs epistemic value, not raw surprise.** Active inference research (Friston et al., Nature Communications, 2026) considers obtaining observations that distinguish world-model structures. Model disagreement and D-optimal information gain are standard ingredients that require matched-budget comparisons. https://www.nature.com/articles/s41467-026-77209-5
6. **An LLM scientific council is not novel by itself.** LLM-AutoSciLab (NeurIPS 2026) couples LLM hypotheses, active experiments and evidence-guided refinement. Physica must test its Meta-on advantage over systems such as this, rather than relying on number of Council roles. https://scientific-discovery.github.io/llm-autoscilab-project/
7. **Multimodal world models face missing information and unreliable sensors.** A 2026 world-model survey emphasizes uncertainty, state abstraction, temporal structure, missing modalities and decision coupling. Physica needs calibrated observations, reliability models and abstention. https://link.springer.com/article/10.1007/s44163-026-02122-1
8. **Meta's actual affordances**: Muse Wonder (`muse-wonder-1.0`) is available through Model API; strict structured outputs are supported with JSON Schema on chat completions, with a strict *nonrecursive* subset. The new adapter uses a strict flat envelope and then locally validates a bounded mathematical expression, without executing generated Python. Official docs: https://dev.meta.ai/docs/structured-output and https://dev.meta.ai/docs/coding-agents

## 3. Core hypothesis: prediction plus causal curiosity

The intended eventual model is a **belief-state world model** with an observation encoder `q_phi(z_t | y_t^1,...,y_t^M, modality masks, calibration)` and modality-specific probabilistic decoders. The hidden physical state `z_t` contains inferred position, velocity, load, friction or other task-dependent quantities. Modalities are actual camera/IMU/electrical/acoustic/thermal signals only when sensors really exist. The future state follows:

`dz/dt = f_calibrated_physics(z, action; theta) + r_neural(z, action; psi) + h_hypothesis(z, action; eta)`

where `r_neural` is a regularized neural residual learner and `h_hypothesis` is an interpretable candidate. The distribution of disagreement across learned world models, *after accounting for sensor noise*, helps select measurements. Physics imposes units, allowed state/action ranges and conservation constraints where established. The objective is to explain **persistent predictive residuals**, not maximize surprising signals indiscriminately.

The proposed research loss includes:

- action-conditioned sensory negative log-likelihood on observed modalities only;
- physical consistency and stability constraints using measured calibration;
- short- and long-horizon prediction loss evaluated on separate episodes;
- sparsity/complexity penalty for proposed mechanisms;
- invariance under changes of sensor type and machine geometry, tested with independent targets;
- calibration of aleatoric and epistemic uncertainties, including explicit abstention.

**What v0.24 presently implements:** the first measurable slice: physical-state observations `[x,v,u,a]`, a small neural residual ensemble, neural-guided parameterized symbolic search, validation-based refusal/selection, two safe candidate-probe policies, and a calibrated redundant-sensor fusion/surprise interface. It does **not** yet implement the full end-to-end learned multimodal encoder and decoder or differentiation through a neural ODE. The `x,v,u,a` inputs are engineering observables, not raw camera/audio/video.

## 4. The actually implemented v0.24 algorithm

**A. Feel a physical prediction error.** Given a calibrated prediction `y_hat` and independently observed `y`, compute `innovation=y-y_hat` and standardized sensory error `innovation / sqrt(sigma_sensor²+sigma_model²)` in `frontier/sensory_belief.py`. Inconsistent redundant sensors force abstention, and virtual sensors are never upgraded to measurements.

**B. Learn the physical residual.** Fit an ensemble of independently initialized tanh MLPs on *training episodes only* to the difference between measured acceleration and a **known/calibrated** physical baseline. No future test observations are permitted.

**C. Extract a mathematical candidate.** The neural ensemble distills a structural training target; an affine sine argument `sin(a*x+b*v)` is searched over a broad grid then optimized as a continuous parameter. Both sine/cosine coefficients are fitted against observations. Other bounded generic algebraic/tanh families are also considered. The v0.23 hard-coded exact `3.7, 1.15` pair is **not passed to the search**. This is a bounded search space, not open-ended discovery of all physical laws.

**D. Allow Meta to expand the hypothesis space.** Muse Wonder can nominate a bounded AST expression (variables, +, multiply, sin/cos/tanh, abs, square, cube; depth/node limits), subject to a strict outer JSON schema, independent measured-channel checking, and local numerical compilation. It never returns executable equations or actuator commands. A validation trial can accept or reject the candidate; actual physical test data must remain unseen until forecast commitment. For claims of Meta improvement, compare authenticated Meta-on vs. source-blind and random-proposal controls with matched compute/API/exposure budgets.

**E. Choose what to experience next.** Neural ensemble disagreement is one baseline policy. If a sine candidate is identifiable, the mechanism-directed policy approximates D-optimal parameter information gain on bounded candidate experiments. The selected experiments are recommendations, **not hardware actions**. No unknown outcome is sampled until the policy is frozen.

**F. Commit, then reveal.** `frontier/field_discovery.py` accepts independently *declared* calibration provenance, disjoint train/validation episodes and a plan of future controls. It commits a full numerical trajectory using its own predicted states, then (in a separate CLI invocation) reads the future timestamped CSV and grades it. Reused split files, changed controls, wrong initial conditions, corrupted receipts or mismatched sampling times are refused. Local SHA-256 receipts do not prove independent chronology, a real calibration or correct provenance.

## 5. New controlled-simulation results (not physics breakthroughs)

36 paired synthetic cases, 12 seeds and three hidden families: parameterized periodic effect, cubic stiffness and velocity friction. Three test episodes are seed-disjoint from training/validation. The random baseline uses a different seeded random choice for every seed and the same feasible probe envelope as the other policies. Measurement noise is synthetic. All methods receive the same *training and validation observations* within each experiment-policy comparison.

| Trial budget / experiment planner | Validation-selected mean one-step test RMSE (m/s²) |
|---|---:|
| No additional experiment | 0.018024 |
| One random in-support experiment | 0.017710 |
| One ensemble-curiosity experiment | 0.016867 |
| One mechanism-directed experiment | 0.016874 |

As an additional stronger conventional baseline on the exact same 36 mechanism-directed cases, validation-tuned **RBF kernel ridge** achieved mean RMSE **0.083735 m/s²**, versus **0.016874 m/s²** for Physica; the Physica candidate won 34/36 cases. This comparison remains favorable by construction to compact symbolic representations of the chosen synthetic mechanisms; it does not establish superiority over optimized symbolic regression, Gaussian-process discovery, or complex real physics.

Within the mechanism-directed trial, the mean test errors were: calibrated-known-physics-only **0.304372**, generic-symbolic **0.098839**, neural-ensemble **0.090157**, neural-guided discovery candidate **0.016874** (m/s²).

**Key caveat**: These favorable synthetic mechanisms were designed to be representable by the algorithm's prior families; cubic and friction feature shapes are not completely unknown. Improvement over random probing is **not statistically established**: mechanism-directed wins on 20/36 paired cases, loses on 14 and ties on 2. Grouped by 12 simulation seeds, a bootstrap 95% interval for random-minus-mechanism error is roughly **[-0.00182, +0.00358] m/s²** and includes zero. A baseline more expressive than a small ridge/MLP may erase the advantage. This experiment does not test cross-embodiment transfer, authenticated Meta calls or hardware.

**Negative controls matter**: on five synthetic `time_modulated` seeds, missing temporal context causes mean neural RMSE of ~0.398, compared with ~0.276 for known-physics-only. The engine flags large unexplained residuals instead of declaring the fitted equation a verified law. The `hidden_memory` scenario also violates the model's Markov assumption and can generate spurious candidate terms. Honest failures are evidence about necessary sensors and model structure.

**Full prospective *simulation* replay** (not an independent hardware test) commits a 90-step trajectory and later scores a separate simulated outcome: x RMSE **0.003954 m**, velocity RMSE **0.005343 m/s**, acceleration RMSE **0.013631 m/s²**. This demonstrates software behavior, not physical validation.

## 6. Run the code

```powershell
python -m pip install -e ".[dev]"
python -m physica.studio --open-browser
```

Open `http://127.0.0.1:8765/curiosity` for the interactive curiosity/research lab. It runs the real local Python benchmark (generated physics), not a prerecorded graphic.

```powershell
python -m physica.frontier.curious_discovery --seeds 12 --experiment-policy mechanism --out demo/v024_mechanism.json
python -m physica.frontier.curious_discovery --seeds 12 --experiment-policy random --out demo/v024_random.json
python -m physica.frontier.curious_discovery --seeds 12 --experiment-policy none --out demo/v024_none.json
```

Offline **synthetic integration test** (does NOT constitute prospective real evidence):

```powershell
python examples/BUILD_V024_SYNTHETIC_FIELD_DEMO.py demo/v024_field
python -m physica.frontier.field_discovery commit --manifest demo/v024_field/manifest.json --plan demo/v024_field/plan.json --out demo/v024_field/forecast.json
python -m physica.frontier.field_discovery reveal --commit demo/v024_field/forecast.json --observations demo/v024_field/future_SIMULATED.csv --out demo/v024_field/score.json
```

For a **real trial** replace **all** simulated evidence and the calibration with true instrumented recordings. The calibration JSON must contain `physics_baseline` with independently measured `stiffness_s2`, `damping_s1`, and `control_gain`; use the correct mass/force normalization for `u_m_s2`. Every training/validation CSV needs `x_m,v_m_s,u_m_s2,acc_m_s2` columns. The **future test** CSV must add `time_s` as the leading column, using elapsed time from trial start. Record the verified starting state and actual future controls; they must agree with the plan. Do not use this code to command any machine.

For an authenticated paid Meta **hypothesis proposal only**, configure `MODEL_API_KEY` locally and `MOCK=0` (never submit a key into chat), then run:

```powershell
python -m physica.frontier.mechanism_dsl --context examples/frontier_v023_context.json --allow-billed-meta --out demo/v024_meta_hypothesis.json
```

The context must be an honest summary of observed channels, ranges and unexplained residuals. The produced JSON is not a discovery until it beats baselines on independent validation and a genuine prospective test. Supply it with `field_discovery commit --meta-proposal <path>` to evaluate whether it adds a novel predictive term.

## 7. Real experiment that would genuinely advance the claim

Use two physically different damped oscillators or low-risk, low-force mechanisms. Calibrate sensor positions using a stationary scale, timestamps against the same clock, applied force/mass and acceleration against an independent device. Pre-register the unseen target and train/validation/test episodes, reserve an untouched test intervention, and externally timestamp the signed forecast before applying it. Run:

1. Known-physics-only, ARX, strong state-space/Bayesian identification, PySINDy with optimized nonlinear parameters, neural residual, and Physica neural-guided discovery.
2. The same system with randomly selected versus D-optimal/active design versus Physica active proposals, **equal number and duration of physical trials**.
3. Meta-off, authenticated Meta-propose, and randomly selected structurally valid proposal ablations (same sensor data and discovery budgets).
4. Cross-sensor generalization: learn with camera+encoder on A; predict B using a *different calibrated* sensor configuration and a small fixed target calibration budget.
5. Shift/generalization: change stiffness, damping, mass or operating temperature; measure negative transfer and refusal rate.
6. Predeclare RMSE, long-horizon trajectory error, mechanism support/recovery, actual physical goal success, experiment count, calibration error and safety incidents. Publish every failure.

**Research-level success requires** meaningful improvement over strong baselines on unfamiliar real systems with held-out intervention evidence and robust statistical uncertainty. A pretty interface, language-model agreement and high simulator accuracy do not meet that criterion.
