# Physica v0.31.1 — Submission Stability Patch

This patch makes the **existing** v0.31 project more honest and resilient; it does not implement additional real-world discovery or physically verify Meta model capabilities.

## Resolved

1. **Live Muse failure diagnostics.** A failed v0.27 scientific council no longer emits only `RuntimeError` and an ambiguous 0-call count. Its sealed status now contains sanitized error class, category, helpful detail, and a specific private-key-safe `live-smoke` next action. The number of provider requests remains **unknown** after a transport/API failure because a remote request may have been received and billed even if the application did not obtain a success receipt. Missing `--allow-billed-meta` still raises `PermissionError` before attempting any call. An authenticated call was **not** run by this patch.
2. **Printer video comparisons.** Previously each baseline pause could be measured at a different modal frequency while the after video used a single frequency. All baseline pauses now use one median reference frequency, and the after video measures at that same baseline frequency. Exploratory window-resampling uncertainty distinguishes a detected reduction from an ambiguous before/after difference. The CLI no longer interprets an unqualified improvement *point estimate* as a verified physical fix. Pixel-space signal magnitudes remain susceptible to camera motion, image crop, lighting and texture differences; without a calibrated displacement reference they are not physical millimetres or force.
3. **One submission story.** `DEMO.md`, the README first screen, and Studio's home hero now align on: **Feel a printer's unexpected physical change → Muse proposes and criticizes → review a safe test → predict before seeing its result → measure whether the goal improved**. Archived F1/turbine cases demonstrate additional domains; Sentinel demonstrates the business pain point (unplanned industrial downtime) but the bundled early-warning evaluation is synthetic. The fully integrated reoptimization example remains a *synthetic beam*, not a general physical printer control loop.

## Required external testing before submission

1. On your own Windows PC, configure `MODEL_API_KEY` and `MOCK=0` privately. Check supported model IDs. Run `python -m physica.frontier.meta_ready_v026 doctor`, then the optional, billed `live-smoke` for Spark and Wonder separately. Test a short SAM video via the documented existing pipeline if your API account supports it. Never paste credentials into logs.
2. Film an approved printer vibration sequence with a stationary camera, consistent lighting/crop, and unchanged program. Collect genuine before/after evidence. Inspect the exploratory uncertainty and accept `CAN'T TELL` if data are weak. A point estimate of reduced pixel motion does **not** demonstrate improved print quality or measured downtime saved.
3. Record independent Meta-on / Meta-off comparisons on the *same* physical training and blind evaluation experiments. Show failed proposals and trial outcomes, not only successes.
4. Verify the organizer's current rules and exact deadline at the original submission portal.

## Local tests

- 107 selected tests passed with one intentionally deselected computationally expensive camera-weighing test. Includes new API diagnostics, printer signal-consistency, Muse Council, Feeling Engine, Sentinel, Outcome Mode and Studio tests.
- No authenticated Meta calls or real printer recordings were used in these tests.
- This patch is **not** certification of industrial safety or a scientific breakthrough.

## Commands

```powershell
python -m pip install -e ".[dev]"
python -m pytest -q tests/test_submission_stability_v032.py
python -m physica.frontier.meta_ready_v026 doctor
python -m physica.frontier.meta_ready_v026 live-smoke --role spark --allow-billed-meta
python -m physica.frontier.meta_ready_v026 live-smoke --role wonder --allow-billed-meta
python -m physica.studio --open-browser
```

The live-smoke commands require privately configured credentials and may incur API charges. Run them only when ready.
