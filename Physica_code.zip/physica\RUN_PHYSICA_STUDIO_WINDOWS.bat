@echo off
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
if exist "..\.venv\Scripts\python.exe" (
  set "RUNPY=..\.venv\Scripts\python.exe"
) else if exist ".venv\Scripts\python.exe" (
  set "RUNPY=.venv\Scripts\python.exe"
) else (
  set "RUNPY=py -3.12"
)
echo Launching Physica Studio...
%RUNPY% -m physica.studio --open-browser
if errorlevel 1 (
  echo.
  echo If Physica is not installed, install it in your virtual environment first:
  echo   python -m pip install -e ".[dev,video]"
  pause
)
