"""PEL v3: a versioned physical *claim* with units, conditions and provenance.

A record is hashed for tamper evidence; a hash is NOT a digital signature,
external timestamp, verified experiment, or proof of causality.
"""
from __future__ import annotations
import hashlib,json,math
from pydantic import BaseModel,Field,ConfigDict,model_validator
from typing import Literal
import numpy as np
from scipy.interpolate import CubicSpline
from .signals import MechanicalContext,_UNITS


def _json(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def _digest(obj):return hashlib.sha256(_json(obj).encode()).hexdigest()


class PhysicalWord(BaseModel):
    model_config=ConfigDict(extra='forbid')
    physical_event: str
    causal_hypothesis: str
    claim_status: Literal['hypothesis_only','verified_local_intervention']
    action_family: str
    boundary_class: str
    source_body_id: str
    natural_frequency_hz: float=Field(gt=0)
    damping_ratio: float=Field(ge=0,lt=1)
    stiffness_N_per_m: float=Field(gt=0)
    step_force_N: float=Field(gt=0)
    normalized_time: list[float]=Field(min_length=8)
    normalized_response: list[float]=Field(min_length=8)
    normalized_sigma: list[float]=Field(min_length=8)
    source_modalities: list[str]=Field(min_length=1)
    raw_sensor_hashes: list[str]
    calibration_id: str
    provenance: Literal['simulation','real_sensor','signed_replay']
    context_source: str
    transfer_domain: list[str]=Field(min_length=2)
    unobservable: list[str]=Field(default_factory=list)
    may_actuate: Literal[False]=False
    @model_validator(mode='after')
    def validate_physics(self):
        arrays=[np.asarray(a,dtype=float) for a in
                (self.normalized_time,self.normalized_response,self.normalized_sigma)]
        if any(not np.all(np.isfinite(a)) for a in arrays):raise ValueError('nonfinite physical words')
        if len({len(a) for a in arrays})!=1 or np.any(np.diff(arrays[0])<=0):
            raise ValueError('aligned increasing response timeline required')
        if np.any(arrays[2]<0):raise ValueError('negative uncertainty')
        if any(len(h)!=64 or any(c not in '0123456789abcdef' for c in h) for h in self.raw_sensor_hashes):
            raise ValueError('evidence hashes must be raw SHA256')
        if any(not math.isfinite(x) for x in (self.natural_frequency_hz,self.damping_ratio,
                                                self.stiffness_N_per_m,self.step_force_N)):
            raise ValueError('nonfinite body parameters')
        if not self.calibration_id or not self.context_source:raise ValueError('provenance required')
        return self


class ExperienceEnvelope(BaseModel):
    model_config=ConfigDict(extra='forbid')
    schema_id:Literal['physica.pel/3.0']='physica.pel/3.0'
    word:PhysicalWord
    word_sha256:str
    signature_ed25519: str|None=None
    signature_note:str='SHA256 is NOT Ed25519; optional external signing required'


def experience_record(token,*,context_source='independent_fixture_manifest'):
    m=token['mechanics'];p=token['physical_words']
    word=PhysicalWord(physical_event=token['event_type'],causal_hypothesis=token['causal_hypothesis'],
       claim_status=token['claim_status'],action_family=token['action_family'],
       boundary_class=token['boundary'],source_body_id=token['calibrated_body'],
       natural_frequency_hz=m['natural_frequency_hz'],damping_ratio=m['damping_ratio'],
       stiffness_N_per_m=m['stiffness_N_per_m'],step_force_N=m['step_force_N'],
       normalized_time=p['normalized_time'],normalized_response=p['normalized_displacement'],
       normalized_sigma=p['normalized_uncertainty'],source_modalities=token['modalities'],
       raw_sensor_hashes=token['sensor_evidence_sha256'],calibration_id=token['context_calibration'],
       provenance=token['provenance'],context_source=context_source,
       transfer_domain=['compatible_boundary','step_excitation','calibrated_modal_family'],
       unobservable=['material_composition','destructive_failure_load'])
    payload=word.model_dump(mode='json')
    env=ExperienceEnvelope(word=word,word_sha256=_digest(payload))
    return env.model_dump(mode='json')


def verify_record(envelope):
    try:
        obj=ExperienceEnvelope.model_validate(envelope)
        return obj.word_sha256==_digest(obj.word.model_dump(mode='json'))
    except (TypeError,ValueError):return False


def unsupported_translation(reason,*,source=None,target=None):
    return {'status':'cannot_translate','reason':reason,'source':source,'target':target,
            'hardware_actuation_allowed':False,
            'note':'UNKNOWN is preferable to an unsupported cross-sensory prediction'}


def translate(envelope,target:MechanicalContext,target_times_s,*,target_modality,
              target_observable,verification_required=True,max_modal_damping_difference=.025):
    """Transport dimensionless experience to different body and sensor.

    Requires target frequency/stiffness/force calibration. No trained cross-modal
    generative mapping is implied; only a calibrated oscillator observation
    operator. A->B 'zero-shot' refers to unobserved target RESPONSE, not
    an uncalibrated target. Never generates actuator commands.
    """
    if not verify_record(envelope):return unsupported_translation('invalid/tampered physical word')
    src=ExperienceEnvelope.model_validate(envelope).word
    if src.claim_status!='verified_local_intervention':
        return unsupported_translation('source has unverified causal hypothesis; cannot teach')
    if src.boundary_class!=target.boundary_class:
        return unsupported_translation('boundary_condition_mismatch',source=src.boundary_class,target=target.boundary_class)
    if src.action_family!=target.action_family:
        return unsupported_translation('action_family_mismatch')
    if abs(src.damping_ratio-target.damping_ratio)>max_modal_damping_difference:
        return unsupported_translation('damping_out_of_transfer_domain')
    if target_observable not in ('displacement','velocity','acceleration'):
        return unsupported_translation('no calibrated mechanical observation operator for '+str(target_observable))
    allowed={'vision':{'displacement','velocity'},'hearing':{'velocity','acceleration'},
             'touch':{'displacement','velocity','acceleration'},
             'proprioception':{'displacement','velocity','acceleration'}}
    if target_observable not in allowed.get(target_modality,set()):
        return unsupported_translation('incompatible target sensing modality')
    t=np.asarray(target_times_s,dtype=float);src_t=np.asarray(src.normalized_time)
    if t.ndim!=1 or len(t)<8 or not np.all(np.isfinite(t)) or np.any(np.diff(t)<=0) or t[0]<0:
        return unsupported_translation('invalid target time grid')
    tau=t*target.fundamental_hz
    if tau[0]<src_t[0]-1e-10 or tau[-1]>src_t[-1]+1e-10:
        return unsupported_translation('cannot extrapolate outside source response timeline')
    # First and second derivatives of a splined dimensionless step response.
    # Differentiation amplifies source noise; uncertainty for derivatives is NOT
    # calibrated here, so such forecasts must NOT claim confidence coverage.
    spline=CubicSpline(src_t,np.asarray(src.normalized_response),bc_type='natural')
    s=target.applied_force_n/target.stiffness_n_m
    order={'displacement':0,'velocity':1,'acceleration':2}[target_observable]
    y=s*(target.fundamental_hz**order)*spline(tau,nu=order)
    sigma=None
    if order==0:
        sigma=(np.interp(tau,src_t,src.normalized_sigma)*s).tolist()
    return {'status':'unverified_cross_sensory_forecast',
            'source_body':src.source_body_id,'target_body':target.body_id,
            'source_modalities':src.source_modalities,'target_modality':target_modality,
            'target_observable':target_observable,'target_unit':_UNITS[target_observable],
            'time_s':t.tolist(),'predicted_values':y.tolist(),
            'estimated_sensor_sigma':sigma,
            'uncertainty_status':'propagated_source_filter_only_NOT_COVERAGE' if order==0 else 'UNCALIBRATED_DERIVATIVE',
            'source_sha256':envelope['word_sha256'],
            'requires_local_verification':verification_required,
            'hardware_actuation_allowed':False,
            'limits':['single oscillator linear family','independently calibrated target body required',
                      'no claim of causal generalization under hidden dynamics shift',
                      'splines can amplify noise at boundaries']}


def json_schema():return ExperienceEnvelope.model_json_schema()
