# Physica v0.21.2 — Evidence-Linked Digital Twin

- From uploaded video, timed CSV, or calibrated tracking JSON, create an inspectable **observational twin**. Detect unidentifiable evidence and abstain rather than fabricate hidden physics.
- Fit an explicitly conditional 1-D second-order model when observations support it; compare against a held-out constant-acceleration baseline.
- Introduce Studio `/twin`, with editable parameter sliders, conditional interventions, comparative trajectories, visible provenance, and drag-to-explore 2D mechanism diagram. **No 3D geometry/forces/failure threshold claims.**
- Add opt-in validated Muse Spark *candidate* annotations, never taken as measured physical truth; no paid calls without session consent and API key.
- Integrate SAM 3.1 official parser from CLI with stable unique track selection and conservative shared-budget reservation. Requires independent metric calibration and stationary reference.
- Add runnable synthetic video and CSV evidence and fail-closed Twin tests.
- Add `physica.mace.causal_fork_v021`: unknown-physics → selected hypothetical experiment → complete frozen forecast receipt → simulated A/B/C different sensor packages with fair target-only comparison. No demonstrated transfer advantage.
- Retain all prior Physica engines. No hardware actuation added.
