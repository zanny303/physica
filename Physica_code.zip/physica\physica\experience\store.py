"""Physical episodes are not the old Body Bank cards; this store supplements them.

The source episode JSON is preserved exactly and verified via its corresponding
Ed25519 signed sealed/revealed evidence before being used as transferable data.
"""
from __future__ import annotations

import json
from pathlib import Path
from .schema import PhysicalEpisode
from .seal import verify_seal, verify_reveal, seal, write_json
from .transfer import search_bank


def add(store: str|Path, record:dict) -> Path:
    if record.get("protocol")=="physica.reveal/v1":
        if not verify_reveal(record):raise ValueError("untrusted or tampered reveal")
        ep=PhysicalEpisode.model_validate(record["episode"])
        if ep.consequence.outcome!="verified":
            raise ValueError("only verified consequences can teach other machines")
    elif record.get("protocol")=="physica.seal/v1":
        if not verify_seal(record):raise ValueError("invalid sealed prediction")
        ep=PhysicalEpisode.model_validate(record["prediction"])
    else:
        raise ValueError("store needs a signed seal/reveal record")
    root=Path(store)
    root.mkdir(parents=True,exist_ok=True)
    # ids used only for display, never trusted as paths
    import hashlib
    name=hashlib.sha256(ep.episode_id.encode()).hexdigest()[:20]+".json"
    dest=root/name
    if dest.exists() and json.loads(dest.read_text())!=record:
        raise FileExistsError("record ID already exists with different content")
    write_json(dest,record)
    return dest


def load(store:str|Path, *, verified_only:bool=True) -> list[PhysicalEpisode]:
    root=Path(store)
    eps=[]
    for path in sorted(root.glob("*.json")) if root.exists() else []:
        try:
            r=json.loads(path.read_text())
            if r.get("protocol")=="physica.reveal/v1" and verify_reveal(r):
                ep=PhysicalEpisode.model_validate(r["episode"])
                if ep.consequence.outcome=="verified":eps.append(ep)
            elif not verified_only and verify_seal(r):
                eps.append(PhysicalEpisode.model_validate(r["prediction"]))
        except (ValueError,KeyError,TypeError):
            pass
    return eps


def query(store:str|Path, target:PhysicalEpisode) -> list[dict]:
    return search_bank(target,load(store))
