"""Translate a felt vibration mode into ArduPilot harmonic-notch settings, and replay-check it.

Parameter names follow the ArduPilot docs page 'Managing Gyro Noise with the Dynamic Harmonic Notch
Filters' (INS_HNTCH_*). VERIFY values against the current docs for your firmware before flying.
INS_HNTCH_HMNCS is a bitmask (1 = fundamental, 2 = 2nd harmonic, 4 = 3rd ...).
INS_HNTCH_MODE: 0 fixed, 1 throttle, 2 RPM sensor, 3 ESC telemetry, 4 in-flight FFT.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
from scipy.signal import filtfilt, iirnotch, welch


def notch_params(freq_hz: float, bandwidth_hz: float | None = None, harmonics: int = 1, mode: int = 0,
                 ref: float | None = None, attenuation_db: float = 40.0) -> dict:
    """ArduPilot recommends a bandwidth of about half the centre frequency for motor noise."""
    bw = bandwidth_hz if bandwidth_hz else freq_hz / 2.0
    p = {
        "INS_HNTCH_ENABLE": 1,
        "INS_HNTCH_MODE": int(mode),
        "INS_HNTCH_FREQ": round(float(freq_hz), 1),
        "INS_HNTCH_BW": round(float(bw), 1),
        "INS_HNTCH_ATT": round(float(attenuation_db), 1),
        "INS_HNTCH_HMNCS": int(sum(1 << k for k in range(max(1, harmonics)))),
    }
    if mode == 1:
        if ref is None:
            raise ValueError("throttle mode needs INS_HNTCH_REF (hover throttle, 0..1)")
        p["INS_HNTCH_REF"] = round(float(ref), 3)
    return p


def write_param_file(params: dict, path: str | Path, header: list[str] | None = None) -> Path:
    """Mission Planner style 'NAME,VALUE' lines; comment lines start with '#'."""
    lines = [f"# {h}" for h in (header or [])] + [f"{k},{v}" for k, v in params.items()]
    Path(path).write_text("\n".join(lines) + "\n")
    return Path(path)


def replay_notch(x: np.ndarray, fs: float, freq_hz: float, bandwidth_hz: float, harmonics: int = 1,
                 spectra: bool = False, check_hz: float | None = None, check_bw_hz: float | None = None) -> dict:
    """Apply the equivalent notch to recorded data and measure what it removes.

    x: (N, axes). Returns in-band power reduction (dB) and out-of-band change (dB, should be ~0).
    check_hz/check_bw_hz: the band where the shake was felt, if different from where the notch was placed.
    """
    x = np.asarray(x, float)
    x = x - x.mean(axis=0)
    y = x.copy()
    for h in range(1, harmonics + 1):
        f0 = freq_hz * h
        if f0 >= fs / 2 * 0.98:
            break
        b, a = iirnotch(f0, Q=f0 / bandwidth_hz, fs=fs)
        y = filtfilt(b, a, y, axis=0)
    f, px = welch(x, fs=fs, nperseg=1024, axis=0)
    _, py = welch(y, fs=fs, nperseg=1024, axis=0)
    px, py = px.sum(axis=1), py.sum(axis=1)
    # measure where the shake was FELT (defaults to the notch itself); a mis-set notch then shows up as a failure
    ch, cbw = (check_hz or freq_hz), (check_bw_hz or bandwidth_hz)
    inb = np.abs(f - ch) <= cbw / 2
    outb = ~inb & (f > 5)
    db = lambda p, m: 10 * np.log10(p[m].sum() + 1e-30)
    out = {"in_band_reduction_db": float(db(px, inb) - db(py, inb)),
           "out_of_band_change_db": float(db(py, outb) - db(px, outb)),
           "total_vibration_reduction_db": float(db(px, f > 5) - db(py, f > 5))}
    out["abs_out_of_band_change_db"] = abs(out["out_of_band_change_db"])
    if spectra:  # what the controller feels before/after, in dB, for the re-feel chart
        keep = f > 5
        out["spectra"] = {"f_hz": f[keep].round(2).tolist(),
                          "before_db": (10 * np.log10(px[keep] + 1e-30)).round(2).tolist(),
                          "after_db": (10 * np.log10(py[keep] + 1e-30)).round(2).tolist(),
                          "band_hz": [freq_hz - bandwidth_hz / 2, freq_hz + bandwidth_hz / 2]}
    return out
