"""Prospective field protocol for independently calibrated NATIVE sensor units.

Source can have microphone Pa, camera displacement m and accelerometer voltage
provided each sensor has an independently identified observation operator.
No original measurement is silently re-labelled as velocity. Seals prediction
BEFORE reading the receiving machine's main outcome CSV. A low-force target
probe, when supplied, must be independently timestamped outside this code.
"""
from __future__ import annotations
from pathlib import Path
from dataclasses import asdict
import hashlib,json
import numpy as np
from .observation import CalibratedSensor, SensorTrace, shared_state_filter
from .signals import MechanicalContext
from .field import (_read_json,_write,read_timeseries,read_times_only,
                    signed_envelope,verify_signed)
from .fusion import physical_tokens
from .language import experience_record
from .cirte import transfer_validity,predict_target_sense


def calibrated_sensor(path):
    data=_read_json(path)
    sensor=CalibratedSensor(**data)
    sha=hashlib.sha256(Path(path).read_bytes()).hexdigest()
    return sensor,sha


def source_from_native_manifest(manifest_path,out):
    s=_read_json(manifest_path);ctx=MechanicalContext(**s['body_context'])
    att=s.get('source_attestation',{})
    if not att.get('supervisor_acknowledgement') or not att.get('attestation_file'):
        raise ValueError('source experience requires a distinct intervention attestation file')
    att_hash=hashlib.sha256(Path(att['attestation_file']).read_bytes()).hexdigest()
    traces=[];raw_hashes=[att_hash];sensor_hashes=[]
    for channel in s['channels']:
        observer,cal_hash=calibrated_sensor(channel['sensor_calibration_json'])
        t,v,h=read_timeseries(channel['recording_csv'])
        if ctx.provenance!='simulation' and observer.calibration_origin=='simulation':
            raise ValueError('real source cannot use simulated observer calibration')
        traces.append(SensorTrace(observer,tuple(t),tuple(v),h,ctx.provenance))
        sensor_hashes.append(cal_hash);raw_hashes.extend([h,cal_hash])
    if len(traces)<1:raise ValueError('at least one calibrated source sensor')
    est=shared_state_filter(traces,mass_kg=ctx.mass_kg,
          stiffness_n_m=ctx.stiffness_n_m,damping_ratio=ctx.damping_ratio,
          external_force_n=ctx.applied_force_n)
    if est['status']!='conditional_state_estimate':
        raise ValueError('calibrated source sensor conflict: '+est['status'])
    # A signed source record is a locally attested physical hypothesis, not
    # scientifically established causality.
    payload_est={'displacement_m':est['displacement_m'],
                 'time_s':est['times_s'],
                 'displacement_sigma_m':est['displacement_sigma_m'],
                 'sensor_ids':est['sensor_ids'],
                 'modality_list':sorted({x.sensor.modality for x in traces})}
    token=physical_tokens(ctx,payload_est,
           cause=s['causal_hypothesis'],action_id=s['action_id'],
           source_sha256s=raw_hashes,provenance=ctx.provenance,checked_outcome=True)
    envelope=experience_record(token,context_source='native_sensor_calibration_and_external_attestation')
    data=signed_envelope({'pel':envelope,'body_context':asdict(ctx),
              'independent_sensor_calibration_sha256s':sensor_hashes,
              'source_attestation_sha256':att_hash,
              'sensor_inference_status':est['status'],
              'origin':ctx.provenance,
              'limitation':'local attestation is not independently witnessed causality'})
    _write(out,data)
    return {'status':'signed_native_sensor_source','out':str(out),'sha256':data['sha256'],
            'native_units':[t.sensor.output_unit for t in traces]}


def prepare_native(source_path,target_body_json,target_sensor_calibration_json,target_times_csv,
                   gate_probe_json,out):
    signed=_read_json(source_path)
    if not verify_signed(signed):raise ValueError('tampered source experience signature')
    ctx=MechanicalContext(**_read_json(target_body_json))
    sensor,sensor_hash=calibrated_sensor(target_sensor_calibration_json)
    if ctx.provenance!='simulation' and sensor.calibration_origin=='simulation':
        raise ValueError('real target cannot use simulated observation calibration')
    times,grid_hash=read_times_only(target_times_csv)
    probe=_read_json(gate_probe_json)
    if probe.get('source') not in ('independent_low_force_measurement','simulated_low_force_measurement'):
        raise ValueError('probe source must be independently declared')
    if ctx.provenance=='real_sensor' and probe['source']!='independent_low_force_measurement':
        raise ValueError('real target cannot use simulated domain-shift probe')
    # For REAL hardware, never trust a JSON-supplied error: recompute it from
    # the raw, separate low-force recording. The file is read during prepare,
    # while the MAIN target outcome remains unknown.
    if ctx.provenance!='simulation':
        raw_path=probe.get('recording_csv')
        if not raw_path or 'probe_force_n' not in probe:
            raise ValueError('real low-force gate needs independent raw recording_csv and probe_force_n')
        from .probe_evidence import recompute_probe
        computed=recompute_probe(signed['payload']['pel'],ctx,sensor,raw_path,
                                  probe_force_n=float(probe['probe_force_n']))
        if ('probe_raw_sha256' in probe and probe['probe_raw_sha256']!=computed['probe_raw_sha256']):
            raise ValueError('claimed probe raw hash differs from actual recording')
        probe=computed
    if len(probe.get('probe_raw_sha256',''))!=64:
        raise ValueError('low-force probe requires independent raw evidence hash')
    probe_hash=hashlib.sha256(Path(gate_probe_json).read_bytes()).hexdigest()
    gate=transfer_validity(signed['payload']['pel'],ctx,sensor,
             probe_normalized_error=probe.get('normalized_response_error'),
             probe_sigma=probe.get('normalized_response_sigma'),
             target_calibration_verified=True,
             probe_evidence_sha256=probe['probe_raw_sha256'],probe_origin=probe['source'])
    if gate['status']!='transfer':raise ValueError('CIRTE refused unverified target transfer: '+gate['reason'])
    pred=predict_target_sense(signed['payload']['pel'],ctx,sensor,times,transfer_decision=gate)
    if pred['status']!='conditional_sensor_prediction':
        raise ValueError('native target prediction refused: '+pred.get('reason','unspecified'))
    payload={'protocol':'physica.cirte-field/0.5',
             'source_signed_sha256':signed['sha256'],
             'target_body':asdict(ctx),'target_sensor':asdict(sensor),
             'target_sensor_calibration_sha256':sensor_hash,
             'target_grid_sha256':grid_hash,'low_force_probe_sha256':probe_hash,
             'recomputed_probe_evidence':probe if ctx.provenance!='simulation' else {'note':'synthetic declared probe only'},
             'transfer_gate':gate,'prediction':pred,
             'prediction_stage':'BEFORE_TARGET_MAIN_RESPONSE',
             'no_target_response_loaded':True,'hardware_actuation_allowed':False}
    seal=signed_envelope(payload);_write(out,seal)
    return {'status':'native_sensor_prediction_signed','out':str(out),'sha256':seal['sha256']}


def check_native(signed_prediction_path,main_observation_csv,out):
    signed=_read_json(signed_prediction_path)
    if not verify_signed(signed):raise ValueError('prediction signature invalid')
    payload=signed['payload']
    if payload.get('protocol')!='physica.cirte-field/0.5':
        raise ValueError('not a CIRTE native physical prediction')
    times,measured,h=read_timeseries(main_observation_csv)
    predicted=payload['prediction'];t=np.asarray(predicted['time_s'])
    if len(times)!=len(t) or not np.allclose(times,t,rtol=0,atol=1e-9):
        raise ValueError('time grid differs from prospectively signed prediction')
    y=np.asarray(predicted['expected_values'],dtype=float)
    err=measured-y
    uncertainty=float(payload['target_sensor']['noise_std'])
    report={'protocol':'physica.cirte-field-reveal/0.5',
            'original_prediction_sha256':signed['sha256'],
            'observation_raw_sha256':h,'target_observed_unit':predicted['observable_unit'],
            'time_s':times.tolist(),'observed_values':measured.tolist(),
            'conditional_prediction_rmse_native':float(np.sqrt(np.mean(err**2))),
            'standardized_observation_rmse':float(np.sqrt(np.mean((err/uncertainty)**2))),
            'target_body':payload['target_body'],
            'target_sensor':payload['target_sensor'],
            'prediction':predicted,
            'witness_statement':'local filesystem signature is NOT independent timestamping',
            'status':'POST_OBSERVATION_CANDIDATE_EVIDENCE',
            'hardware_actuation_allowed':False}
    result=signed_envelope(report);_write(out,result)
    return {'status':'native_observation_signed','out':str(out),
            'prediction_rmse_native':report['conditional_prediction_rmse_native'],
            'sha256':result['sha256']}


def learn_next_native(reveal_path, raw_csv, out, *,action_id,causal_hypothesis):
    reveal=_read_json(reveal_path)
    if not verify_signed(reveal):raise ValueError('invalid signed reveal')
    p=reveal['payload']
    if p.get('protocol')!='physica.cirte-field-reveal/0.5':
        raise ValueError('only verified native-sensor reveals can teach the next body')
    t,y,h=read_timeseries(raw_csv)
    if h!=p['observation_raw_sha256']:raise ValueError('revealed raw sensor evidence changed')
    ctx=MechanicalContext(**p['target_body']);sensor=CalibratedSensor(**p['target_sensor'])
    trace=SensorTrace(sensor,tuple(t),tuple(y),h,ctx.provenance)
    est=shared_state_filter([trace],mass_kg=ctx.mass_kg,
          stiffness_n_m=ctx.stiffness_n_m,damping_ratio=ctx.damping_ratio,
          external_force_n=ctx.applied_force_n)
    if est['status']!='conditional_state_estimate':
        raise ValueError('unidentifiable next source: '+est['status'])
    payload_est={'displacement_m':est['displacement_m'], 'time_s':est['times_s'],
                 'displacement_sigma_m':est['displacement_sigma_m'],
                 'sensor_ids':est['sensor_ids'],'modality_list':[sensor.modality]}
    token=physical_tokens(ctx,payload_est,cause=causal_hypothesis,action_id=action_id,
          source_sha256s=[reveal['sha256'],h],provenance=ctx.provenance,
          checked_outcome=True)
    env=experience_record(token,context_source='signed_native_sensory_reveal_after_predicted_intervention')
    record=signed_envelope({'pel':env,'parent_reveal_sha256':reveal['sha256'],
        'body_context':asdict(ctx),
        'note':'Candidate transfer after a signed local observation; not verified universal law'})
    _write(out,record)
    return {'status':'new_signed_native_source','out':str(out),'sha256':record['sha256']}
