# v0.6 — Predictive Physical Feeling

Built on the complete v0.5.2 repository. Preserves Lab/Discover/Lens, CIRTE, CRATE, CSG, Touch Transform, Body Bank, and existing Meta integrations.

## New modules

- `physica/feeling/core.py`: action-conditioned dynamical simulation, independent sensor observations, sensory innovations, two-training/heldout intervention fitting, signed physical lessons, target transfer gates, secured low-force probe and sealed target forecasts/reveals.
- `physica/feeling/stream.py`: incremental three-state EKF for prediction, noise-aware sensor surprise, provisional contact adaptation, no actuation.
- `physica/feeling/counterfactual.py`: risk-bounded imagined sensory consequences and safe *recommendation-only* action choices.
- `physica/feeling/context.py`: limits Muse suggestions to an allowed physical mechanism dictionary; each proposed hypothesis must be tested on held-out actions.
- `physica/feeling/meta_bridge.py`: tracked moving part + fixed reference to separately calibrated camera observations; never treats pixels as force.
- `physica/feeling/cli.py`, `demo.py`, `benchmark.py`: CLI and synthetic A→B→C, field-stage request/observation files, 20-seed baseline/shift results, interactive HTML demo.
- `tests/test_predictive_feeling_v060.py`: adversarial inputs and end-to-end tests.

## Evidence and limits

The new demo and benchmark are simulation-only. The online estimator is not a robot, live Meta API use is not verified, V-JEPA model weights are not executed, and physical chemical sensing is not demonstrated. See `docs/V060_PREDICTIVE_FEELING_RESEARCH.md`. Research novelty has not been independently established.
