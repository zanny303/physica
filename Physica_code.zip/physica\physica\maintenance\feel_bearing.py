"""Machine downtime on real bearings that really failed: does a vibration sense warn earlier than a plain alarm?

Rules fixed before any test bearing was scored:
  Every bearing learns its own normal from its first 10 minutes. Nothing is shared but one alarm threshold.
  The threshold comes only from the challenge's 6 learning bearings: the highest score seen in the first half of their lives.
  The 11 test bearings are the challenge's own test set. An alarm needs 3 snapshots in a row above the threshold.
The sense: how far all nine vibration bands sit above this bearing's own normal, added up over time (CUSUM, Page 1954).
It was chosen on the learning bearings alone, after a first multi-band version lost to the plain alarm on the test set.
That first version is kept here as "first_try", so the loss stays on record.
A warning in a lab run is not prevented downtime, and these bearings were driven hard to fail within hours.
"""
from __future__ import annotations

import numpy as np

LEARNING = ("Bearing1_1", "Bearing1_2", "Bearing2_1", "Bearing2_2", "Bearing3_1", "Bearing3_2")
BASE_MIN = 10.0
IN_A_ROW = 3


def _z(y: np.ndarray, base: np.ndarray) -> np.ndarray:
    med = np.median(base, 0)
    mad = 1.4826 * np.median(np.abs(base - med), 0)
    return (y - med) / np.maximum(mad, 1e-6)


def _ewma(x: np.ndarray, decay: float = 0.35) -> np.ndarray:
    out, s = np.empty(len(x)), 0.0
    for i, v in enumerate(x):
        s = decay * v + (1 - decay) * s
        out[i] = s
    return out


def _cusum(x: np.ndarray, k: float = 3.0) -> np.ndarray:
    out, s = np.empty(len(x)), 0.0
    for i, v in enumerate(x):
        s = max(0.0, s + v - k)
        out[i] = s
    return out


def timed(rows: np.ndarray) -> np.ndarray:
    """The rig records one snapshot every 10 s. Its clock column jumps in places, so the count is the clock."""
    r = rows.copy()
    r[:, 0] = np.arange(len(r)) * 10.0
    return r


def scores(rows: np.ndarray) -> dict:
    """rows: time_s, rms, peak, kurtosis, nine log band powers. Scores rise when the bearing leaves its own normal."""
    t = rows[:, 0]
    base = rows[t <= BASE_MIN * 60]
    plain = _z(np.log(rows[:, [1]]), np.log(base[:, [1]]))[:, 0]
    bands = _z(rows[:, 4:], base[:, 4:])
    return {"plain": _ewma(plain), "feel": _cusum(np.clip(bands.mean(1), -20, None)), "first_try": _ewma(bands.max(1))}


def first_alarm(score: np.ndarray, threshold: float, t: np.ndarray) -> int | None:
    start = int(np.searchsorted(t, BASE_MIN * 60))
    run = 0
    for i in range(start, len(score)):
        run = run + 1 if score[i] > threshold else 0
        if run >= IN_A_ROW:
            return i
    return None


def evaluate(data: dict) -> dict:
    data = {k: timed(v) for k, v in data.items()}
    thresholds = {}
    for m in ("plain", "feel", "first_try"):
        seen = []
        for name in LEARNING:
            r = data[name]
            s = scores(r)[m]
            seen.append(s[(r[:, 0] > BASE_MIN * 60) & (r[:, 0] <= r[-1, 0] / 2)].max())
        thresholds[m] = float(max(seen))
    units = []
    for name in sorted(set(data) - set(LEARNING)):
        r = data[name]
        t = r[:, 0]
        s = scores(r)
        row = {"bearing": name, "life_min": round(float(t[-1] / 60), 1), "end_peak_g": round(float(r[-1, 2]), 1)}
        hit = np.nonzero(np.convolve(r[:, 2] > 10.0, np.ones(IN_A_ROW), "valid") >= IN_A_ROW)[0]
        fixed = int(hit[0] + IN_A_ROW - 1) if len(hit) else None
        for m, idx in (("plain", first_alarm(s["plain"], thresholds["plain"], t)),
                       ("feel", first_alarm(s["feel"], thresholds["feel"], t)),
                       ("first_try", first_alarm(s["first_try"], thresholds["first_try"], t)), ("fixed_10g", fixed)):
            row[m] = None if idx is None else {"at_min": round(float(t[idx] / 60), 1), "warning_min": round(float((t[-1] - t[idx]) / 60), 1),
                                               "life_used": round(float(t[idx] / t[-1]), 3)}
        units.append(row)
    def summary(m):
        got = [u[m] for u in units if u[m]]
        return {"alarmed": len(got), "of": len(units), "median_warning_min": round(float(np.median([g["warning_min"] for g in got])), 1) if got else None,
                "alarmed_in_first_half_of_life": sum(g["life_used"] < .5 for g in got)}
    earlier = sum(1 for u in units if u["feel"] and (not u["plain"] or u["feel"]["warning_min"] > u["plain"]["warning_min"]))
    later = sum(1 for u in units if u["plain"] and (not u["feel"] or u["plain"]["warning_min"] > u["feel"]["warning_min"]))
    return {"thresholds": thresholds, "units": units, "summary": {m: summary(m) for m in ("feel", "plain", "first_try", "fixed_10g")},
            "feel_earlier_than_plain": earlier, "plain_earlier_than_feel": later}
