"""Action-conditioned predictive physical feeling (engineering, not subjective)."""
from .core import (Body, Sense, Interaction, simulate, predict_senses, compare_feeling,
                   fit_physical_feeling, sign_lesson, verify_lesson, transfer_check,
                   signed_forecast, verify_forecast, verify_consequence, verify_reveal)
