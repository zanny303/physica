"""Makes the whole film: the same commands anyone could type, one after another. The key comes from your terminal, and is scrubbed from anything shown."""
from __future__ import annotations

import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

from physica.llm import meta_client as mc

ROOT = Path(__file__).resolve().parents[2]
CLIPS = ROOT / "demo_clips"
SCRIPT = ROOT / "docs" / "SCRIPT.md"
_NAME = re.compile(r"[0-9a-zA-Z_]{1,60}\.mp4")
STEPS = (("check", "Check Muse and SAM are reachable", ["-m", "physica.cli", "meta", "preflight"], True),
         ("films", "Muse and SAM on the three real films", ["-m", "physica.cli", "meta", "cases", "--allow-billed-meta"], True),
         ("write", "Muse writes the machine files, and code checks them", ["-m", "physica.cli", "speak", "--allow-billed-meta"], True),
         ("goal", "Muse reads a typed change, and writes its file", ["-m", "physica.outcome.goalbox"], True),
         ("reads", "Muse reads downtime, turbine and F1, and decides", ["-m", "physica.outcome.muse_reads"], True),
         ("clips", "Make every clip and the whole film", ["-m", "physica.film", "pack"], False),
         ("proof", "Save the results and receipts for judges", ["-m", "physica.cli", "evidence", "--name", "cables"], True))
_lock = threading.Lock()
_state: dict = {"running": False, "finished": False, "steps": [], "live": False}


def _clean(line: str) -> str:
    key = mc.api_key()
    line = line.rstrip()
    if key and key in line:
        line = line.replace(key, "[key hidden]")
    return re.sub(r"\b(sk|LLM|meta|key)[-_][A-Za-z0-9_-]{20,}\b", "[key hidden]", line)[:600]


def _outcome(step_id: str, code: int, lines: list[str]) -> str:
    text = "\n".join(lines)
    if code:
        return "failed"
    if step_id == "check" and ("NOT READY" in text or "FAIL " in text):
        return "partly"
    if step_id == "films" and "This one failed" in text:
        return "partly"
    if step_id == "write" and "Not passed" in text:
        return "partly"
    if step_id == "clips" and "Couldn't make" in text:
        return "partly"
    return "passed"


def _run(steps: list[dict]) -> None:
    env = {**os.environ, "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8"}
    for s in steps:
        if s["status"] == "skipped":
            continue
        s["status"], t0 = "running", time.time()
        try:
            p = subprocess.Popen([sys.executable, *s["args"]], cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
            for line in p.stdout:
                line = _clean(line)
                if line.strip():
                    s["lines"].append(line)
                    del s["lines"][:-200]
            code = p.wait()
        except Exception as e:     # one step failing must not stop the ones after it
            s["lines"].append(f"This step couldn't run: {str(e)[:300]}")
            code = 1
        s["status"], s["seconds"] = _outcome(s["id"], code, s["lines"]), round(time.time() - t0)
    _state.update(running=False, finished=True)


def start(only: str | None = None) -> dict:
    """Without a key, the Muse steps are skipped and say so, and the clips are made from what's saved."""
    with _lock:
        if _state["running"]:
            raise ValueError("It's already running")
        live = not mc.is_mock()
        steps = []
        for sid, title, args, billed in STEPS:
            skip = (billed and not live) or (only is not None and sid != only)
            steps.append({"id": sid, "title": title, "args": args, "status": "skipped" if skip else "waiting", "lines": [], "seconds": None})
        _state.update(running=True, finished=False, steps=steps, live=live)
    threading.Thread(target=_run, args=(steps,), daemon=True).start()
    return status()


def _says() -> dict:
    out = {}
    if SCRIPT.exists():
        for line in SCRIPT.read_text(encoding="utf-8").splitlines():
            cells = [c.strip() for c in line.split("|")]
            if len(cells) >= 4:
                for name in re.findall(r"`([0-9a-zA-Z_]+)`", cells[2]):
                    out[name] = {"when": cells[1], "say": cells[3]}
    return out


def clips() -> list[dict]:
    if not CLIPS.exists():
        return []
    says = _says()
    return [{"name": p.name, "mb": round(p.stat().st_size / 1e6, 1), **says.get(p.stem, {})} for p in sorted(CLIPS.glob("*.mp4")) if _NAME.fullmatch(p.name)]


def clip_file(name: str) -> Path | None:
    p = CLIPS / name
    return p if _NAME.fullmatch(name or "") and p.exists() else None


def status() -> dict:
    return {"running": _state["running"], "finished": _state["finished"], "live_now": not mc.is_mock(), "ran_live": _state["live"], "steps": [{k: s[k] for k in ("id", "title", "status", "lines", "seconds")} for s in _state["steps"]], "clips": clips(), "folder": str(CLIPS)}


def main() -> None:
    """python -m physica.cli make-film"""
    live = not mc.is_mock()
    print("Muse is connected." if live else "No key in this window, so the Muse steps are skipped. To include them, set MODEL_API_KEY and MOCK=0, then run this again.")
    env = {**os.environ, "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8"}
    rows = []
    for sid, title, args, billed in STEPS:
        print(f"\n=== {title}", flush=True)
        if billed and not live:
            rows.append((title, "skipped"))
            print("Skipped: no key")
            continue
        p = subprocess.Popen([sys.executable, *args], cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        lines = []
        for line in p.stdout:
            line = _clean(line)
            lines.append(line)
            print(line, flush=True)
        rows.append((title, _outcome(sid, p.wait(), lines)))
    print("\n=== Summary")
    for title, state in rows:
        print(f"{state.upper():8} {title}")
    print(f"\nYour film: {CLIPS / '00_whole_film.mp4'}")
    print("If any line above says FAILED or PARTLY, copy that step's output and send it to get it fixed. Don't send your key.")
