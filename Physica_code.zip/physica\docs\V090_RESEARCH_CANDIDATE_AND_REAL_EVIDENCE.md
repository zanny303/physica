# Physica v0.9 research candidate — reproduce and pursue real proof

## What has actually been built

- A source-population prior using independent body IDs and controlled interventions.
- Selective physical experience transfer: only observed target-local and separate target-probe data, then prospective sensory prediction.
- A target-directed, budget-limited experiment planner selecting future actions using uncertainty, never test responses.
- Chronologically validated latent vs ARX forecasting, with no guarantee the latent method wins.
- SHA-256 forecast integrity and independent reveal function, but not a trusted external timestamp.
- Strict-schema optional Meta scientific suggestion requests, hypotheses only, never motor commands.
- A unified simulated A acoustic/contact → B camera/inertial workflow.

## Run on Windows (PowerShell) or macOS/Linux

```bash
python -m pip install -e ".[dev]"
python -m pytest -q tests/test_research_v09.py tests/test_active_probe_v09.py tests/test_experience_v09.py
python -m physica.research_v09.run --seeds 18 --trials 24 --out demo/research_v09/benchmarks.json
python -m physica.research_v09.experience --out demo/research_v09/experience.json
python -m physica.studio.server
```

On an actual user-supplied time series (timestamps/action/2+ sense_ columns), run:

```bash
python -m physica.research_v09.run --seeds 3 --trials 9 --real-csv "my_real_measurements.csv" --out demo/research_v09/real_candidate_report.json
```

This *only* measures model prediction on the supplied data. Recording provenance and intervention control remain unverified until independently checked. Observational action columns are not proof of causality.

## Meta offline and optional live (never in default Studio)

```bash
python -m physica.research_v09.meta_bridge --context examples/research_v09/meta_context.json --out demo/research_v09/meta_dry_run.json --dry-run
# ONLY if you have your own credential and approve potential charges:
python -m physica.research_v09.meta_bridge --context examples/research_v09/meta_context.json --out demo/research_v09/meta_authenticated.json --allow-billed-meta
```

Never put a key in a ZIP, chat message or output JSON. The context file is illustrative, not a real scene. For a scientific demonstration, use a user-approved, independently documented context with raw video hashes and *training* measurements only; keep held-out outcomes invisible to Muse. The model nominates a candidate; the existing `physica.grammar.mechanism_lab` independently evaluates physical evidence. Official docs: https://dev.meta.ai/docs/protocols/responses ; https://dev.meta.ai/docs/structured-output ; https://dev.meta.ai/docs/sam/client-libraries

## Moody / real hardware experiment

Use staff-approved low-force clamped strips with measured geometry, calibrated sensors and strictly controlled actions. For source A collect two or more independent sensor channels and calibrated acceleration or force; separately calibrate B's camera/IMU observation map. Disclose all calibration probes. Freeze B's predictions and a trusted witness/timestamp **before** collecting B's held-out sensor outcome. Collect all trial failures and compare with local-only fit and conventional ARX/SINDy/physics identification under matched target intervention budgets, disclosing prior source training costs.

The v0.9 simulator accepts measured 2-D state and acceleration for the core causal learner. A true raw video/audio-to-physical-state pipeline still requires live calibrated source sensors and independently verified Meta tracking. This is NOT a zero-calibration, five-sense autonomous engine.

## Research publication path

- Pre-register targets, competing models and thresholds.
- Independently test across mechanics families, bodies, sensors, lighting, sample rates, audio dropouts, and action-distribution shifts.
- Measure future sensor prediction, target trial count to reach accuracy, accuracy at selective coverage, mismatch/failure detection and cost.
- Include Bayesian hierarchy, tuned local system ID, ARX, SINDy, existing cross-embodiment/active-design techniques, plus Meta on/off ablation.
- Claim mechanism discovery only where new proposed mechanisms predict *new interventions*, not when a dictionary term was fit retrospectively.
