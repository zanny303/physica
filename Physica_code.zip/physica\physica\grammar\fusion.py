"""Mechanistic multisensor causal inference (CSG v0.4.2).

Independent calibrated sensors observe different linear functionals of the SAME
mechanical state. A discrete Kalman filter combines observations, scores rival
physical hypotheses and emits normalized, sensor-independent physical tokens.
This is a physically interpretable baseline, not a newly discovered transform.
"""
from __future__ import annotations
from dataclasses import asdict,replace
from math import isfinite,log,pi
import numpy as np
from scipy.linalg import expm
from .signals import Channel,MechanicalContext,align,validate_channels,finite_array


def _dynamics(ctx,dt):
    if dt<=0 or not isfinite(dt):raise ValueError('invalid time step')
    w=2*pi*ctx.fundamental_hz
    A=np.array([[0.,1.],[-w*w,-2*ctx.damping_ratio*w]])
    B=np.array([0.,1./ctx.mass_kg])
    T=expm(A*dt)
    U=np.linalg.solve(A,(T-np.eye(2))@B)
    return T,U


def _observable(c:Channel,ctx:MechanicalContext):
    w=2*pi*ctx.fundamental_hz
    mapping={'displacement':np.array([1.,0.]),
             'velocity':np.array([0.,1.]),
             'acceleration':np.array([-w*w,-2*ctx.damping_ratio*w])}
    if c.observable not in mapping:
        raise ValueError('force is an ACTION and chemistry needs its own model; cannot use as state displacement')
    # Direct accel observation includes known applied forcing F/m; it is not a
    # zero-input modal acceleration. Explicitly include it in measurement offset.
    offset=ctx.applied_force_n/ctx.mass_kg if c.observable=='acceleration' else 0.
    return mapping[c.observable],offset


def predict_sensor(state,channel:Channel,ctx:MechanicalContext):
    """Project a latent [x,v] trajectory into another calibrated sensor type.

    Output is in canonical SI physical units, NOT raw microphone voltage.
    No conversion without an explicit valid observation operator.
    """
    X=np.asarray(state,dtype=float)
    if X.ndim!=2 or X.shape[1]!=2 or not np.all(np.isfinite(X)):
        raise ValueError('requires finite (n,2) displacement/velocity states')
    H,b=_observable(channel,ctx)
    return (X@H+b).tolist()


def infer_state(channels,ctx:MechanicalContext, *, grid_s=None, process_sigma_m=.00002,
                initial_position_sigma_m=.0001, initial_velocity_sigma_m_s=.01):
    """Gaussian filter under a specific oscillator hypothesis.

    The score is a conditional likelihood dependent on calibration, model and
    noise assumptions, NOT a verified probability of real structural damage.
    """
    cs=validate_channels(channels,ctx)
    if not all(c.observable in ('displacement','velocity','acceleration') for c in cs):
        raise ValueError('only calibrated mechanical observations accepted by this model')
    if any(not isfinite(v) or v<=0 for v in (process_sigma_m,initial_position_sigma_m,initial_velocity_sigma_m_s)):
        raise ValueError('finite positive filter uncertainties required')
    t,observed=align(cs,grid_s=grid_s)
    x=np.zeros(2)
    P=np.diag([initial_position_sigma_m**2,initial_velocity_sigma_m_s**2])
    states=[];covs=[];innovations=[];loglike=0.
    for j in range(len(t)):
        if j:
            T,U=_dynamics(ctx,float(t[j]-t[j-1]))
            x=T@x+U*ctx.applied_force_n
            # Bounded but non-zero model error (per time interval); meters^2 etc.
            q=process_sigma_m**2
            Q=np.diag([q,(process_sigma_m/(t[j]-t[j-1]))**2])
            P=T@P@T.T+Q
        for c in cs:
            H,b=_observable(c,ctx)
            measured=float(observed[c.sensor_id][j]);r=measured-(H@x+b)
            S=float(H@P@H+c.sigma**2)
            if not isfinite(S) or S<=0:raise ValueError('invalid innovation uncertainty')
            loglike+=-.5*(log(2*pi*S)+r*r/S)
            surprise=float(r/np.sqrt(S))
            # If a channel contradicts the local linear dynamics by >5 sigma,
            # do not force the fitted state toward it. Retain the surprise in
            # the likelihood AND evidence as a possible unmodelled event.
            # This is an explicit heuristic, not a calibrated OOD threshold.
            accepted=abs(surprise)<=5.0
            if accepted:
                gain=P@H/S
                x=x+gain*r
                I=np.eye(2);M=I-np.outer(gain,H)
                P=M@P@M.T+np.outer(gain,gain)*c.sigma**2
                P=(P+P.T)*.5
            innovations.append({'sensor_id':c.sensor_id,'sample':j,
                                'standardized_innovation':surprise,
                                'used_in_filter_update':accepted})
        states.append(x.copy());covs.append(P.copy())
    states=np.asarray(states)
    covs=np.asarray(covs)
    return {'status':'conditional_state_estimate','time_s':t.tolist(),
            'displacement_m':states[:,0].tolist(),'velocity_m_s':states[:,1].tolist(),
            'displacement_sigma_m':np.sqrt(np.maximum(covs[:,0,0],0)).tolist(),
            'log_likelihood':float(loglike),
            'normalized_innovations':innovations,'state':states,
            'model_body':ctx.body_id,'sensor_ids':[c.sensor_id for c in cs],
            'modality_list':sorted(set(c.modality for c in cs)),
            'limitations':['linear second-order model plus sensor innovation diagnostics','known constant step force',
                           'independently calibrated observation operators',
                           'time-alignment required; Kalman noise assumptions']}


def rank_hypotheses(channels,candidates,*,priors=None):
    if not candidates or len(set(candidates))!=len(candidates):
        raise ValueError('distinct hypotheses required')
    if priors is None:priors={n:1/len(candidates) for n in candidates}
    if set(priors)!=set(candidates) or any(not isfinite(v) or v<=0 for v in priors.values()):
        raise ValueError('positive finite prior for each hypothesis required')
    # Every candidate must concern same object and action but can have different
    # causal mechanisms and dynamics. No candidate is assumed ground truth.
    c0=next(iter(candidates.values()))
    if any(c.body_id!=c0.body_id or c.action_family!=c0.action_family or c.applied_force_n!=c0.applied_force_n
           for c in candidates.values()):
        raise ValueError('candidate causes must share measured body/action')
    scores={n:infer_state(channels,c)['log_likelihood']+np.log(priors[n])
            for n,c in candidates.items()}
    shift=max(scores.values());exps={n:np.exp(v-shift) for n,v in scores.items()}
    z=sum(exps.values())
    return {'status':'conditional_hypothesis_ranking',
            'posterior_under_assumptions':{n:float(exps[n]/z) for n in candidates},
            'log_scores':{n:float(v) for n,v in scores.items()},
            'assumptions':['candidate set not complete','known calibrated force',
                           'likelihood depends on sensor noise and linear dynamics',
                           'not independently identified without controlled intervention'],
            'chosen':max(exps,key=exps.get)}


def physical_tokens(ctx,estimate,*,cause,action_id,source_sha256s,provenance,
                    checked_outcome=False):
    """Mechanism-focused event words, not free-text descriptions or embeddings.

    Only records physical quantities with supported units. This does NOT mark a
    causal claim as verified merely because the likelihood prefers it.
    """
    x=finite_array(estimate['displacement_m'],'physical displacement',minimum=8)
    t=finite_array(estimate['time_s'],'time',minimum=8)
    sigma=finite_array(estimate['displacement_sigma_m'],'uncertainty',minimum=8)
    if len(t)!=len(x) or len(sigma)!=len(x):raise ValueError('trajectory dimensions mismatch')
    if provenance not in ('simulation','real_sensor','signed_replay'):raise ValueError('provenance')
    return {'event_type':'intervention_response','causal_hypothesis':cause,
            'claim_status':'verified_local_intervention' if checked_outcome else 'hypothesis_only',
            'action_id':action_id,'boundary':ctx.boundary_class,'action_family':ctx.action_family,
            'calibrated_body':ctx.body_id,'context_calibration':ctx.calibration_id,
            'mechanics':{'natural_frequency_hz':ctx.fundamental_hz,
                         'damping_ratio':ctx.damping_ratio,
                         'stiffness_N_per_m':ctx.stiffness_n_m,
                         'step_force_N':ctx.applied_force_n},
            'physical_words':{'normalized_time':(t*ctx.fundamental_hz).tolist(),
                              'normalized_displacement':(x*ctx.stiffness_n_m/ctx.applied_force_n).tolist(),
                              'normalized_uncertainty':(sigma*ctx.stiffness_n_m/ctx.applied_force_n).tolist()},
            'sensor_evidence_sha256':list(source_sha256s),
            'sensors':estimate['sensor_ids'],'modalities':estimate['modality_list'],
            'provenance':provenance,
            'limitations':['only measured mode family','step-driven linear approximation',
                           'local verification required on new body'],
            'hardware_actuation_allowed':False}
