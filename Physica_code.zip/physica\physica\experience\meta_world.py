"""Strict Meta integration boundary for the v0.3 physical research loop.

The HTTP gateway is configurable and does not pretend model calls were made.
For a learned-world forecast, model embeddings must be independently mapped
and calibrated to *physical scalar observables* before use in dual_world.
SAM segmentation by itself is not a physical displacement calibration.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json
import os
import urllib.request
from .dual_world import CalibratedForecast


class ModelUnavailable(RuntimeError):
    pass


@dataclass(frozen=True)
class MetaGateway:
    base_url: str
    api_key: str
    model_id: str
    endpoint: str = "/responses"

    @classmethod
    def from_env(cls, *, role: str = "MUSE"):
        from physica.llm import meta_client as mc
        base=mc.base_url()
        key=mc.api_key() or ""
        model=os.getenv(f"MODEL_{role.upper()}", "")
        endpoint=os.getenv("META_RESPONSES_PATH","/responses")
        if not (base and key and model):
            raise ModelUnavailable(f"Set MODEL_API_KEY (and optionally MODEL_{role.upper()}) to call Meta")
        if not base.startswith("https://"):
            raise ModelUnavailable("live Meta requests require HTTPS")
        if not endpoint.startswith('/') or '://' in endpoint or '..' in endpoint:
            raise ModelUnavailable("invalid responses endpoint")
        return cls(base,key,model,endpoint)

    def call(self, input_payload, *, timeout=60.0) -> dict:
        if not (self.base_url.startswith('https://') and self.api_key and self.model_id):
            raise ModelUnavailable("invalid/absent live Meta credentials")
        if not (1 <= timeout <= 300):raise ValueError("timeout must be 1..300 seconds")
        body={"model":self.model_id,"input":input_payload}
        try:
            from physica.llm import meta_client as mc
            result=mc.post_raw(self.endpoint,body,task="experience_meta_world",timeout=timeout)
        except Exception as e:
            raise ModelUnavailable(f"Meta request failed: {type(e).__name__}: {e}") from e
        if not isinstance(result,dict) or result.get('error'):
            raise ModelUnavailable("Meta returned an error or malformed result")
        return {"mode":"live_http","model_id":self.model_id,
                "result":result,"note":"model response only; physical verification is separate"}


def status() -> dict:
    """No implicit mock == live. Check environment without leaking secrets."""
    return {
        "muse_responses_configured":all(os.getenv(k) for k in
                                        ("META_API_BASE_URL","META_API_KEY","MODEL_WONDER")),
        "sam31_tracking":"adapter requires compatible API contract, raw video, user calibration",
        "v_jepa_2":"external local-model pipeline/validated forecast artifact required; no bundled weights",
        "live_calls_performed":False,
        "next_step":"Use MetaGateway.from_env(role='WONDER') after confirming current official API compatibility",
        "note":"No offline mock is described as genuine model inference"}


def load_calibrated_visual_forecast(path: str|Path) -> CalibratedForecast:
    """Accept *physically calibrated* numeric prediction exported by a visual model.

    Expected JSON keys: observable, unit, mean, sigma, model_id, origin,
    calibration_evidence. Calibration evidence must point to held-out measured
    calibration data; an uncalibrated latent embedding is rejected.
    """
    raw=json.loads(Path(path).read_text())
    allowed={"observable","unit","mean","sigma","model_id","origin","calibration_evidence"}
    if set(raw)-allowed:raise ValueError("unexpected visual forecast keys")
    forecast=CalibratedForecast(**raw)
    if not forecast.calibrated:raise ValueError("calibrate latent/optical forecasts to physical units first")
    return forecast


def extract_text(result:dict) -> str:
    """Read a Responses-style output without inventing a response on error."""
    if isinstance(result.get("output_text"),str):
        return result["output_text"]
    fragments=[]
    for node in result.get("output",[]):
        for part in node.get("content",[]):
            raw=part.get("text")
            if isinstance(raw,str):fragments.append(raw)
    if fragments:return "\n".join(fragments)
    raise ModelUnavailable("Model reply contains no text output; experiment not approved")
