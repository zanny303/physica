"""Physica Causal Sensory Grammar research prototype (CSG/PΕL 3.0).

The grammar is an interoperable, evidence-grounded *hypothesis* about interactions,
not a universal representation or a substitute for real sensing.
"""
from .signals import Channel, MechanicalContext, align, validate_channels
from .fusion import infer_state, rank_hypotheses, physical_tokens, predict_sensor
from .language import experience_record, verify_record, translate, unsupported_translation
__all__ = ['Channel','MechanicalContext','align','validate_channels','infer_state',
           'rank_hypotheses','physical_tokens','predict_sensor','experience_record',
           'verify_record','translate','unsupported_translation']
