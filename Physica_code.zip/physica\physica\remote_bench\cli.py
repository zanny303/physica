"""Cloud training, Meta scientific reasoning and draft code-generation entrypoint."""
from __future__ import annotations
import argparse,json
from pathlib import Path
from .train import train_manifest
from .synthetic_pilot import run
from .machine_drafts import draft,save_draft


def main():
    parser=argparse.ArgumentParser(prog='python -m physica.remote_bench.cli')
    sub=parser.add_subparsers(dest='cmd',required=True)
    pilot=sub.add_parser('pilot',help='train on locally generated SYNTHETIC signals only')
    pilot.add_argument('--out',required=True)
    train=sub.add_parser('train',help='train on source recordings supplied through JSON manifest')
    train.add_argument('manifest');train.add_argument('--out',required=True);train.add_argument('--seed',type=int,default=21)
    nxt=sub.add_parser('train-next',help='train cross-sensor near-future physical-signal prediction')
    nxt.add_argument('manifest');nxt.add_argument('--out',required=True)
    gen=sub.add_parser('machine-draft',help='generate NOT EXECUTED machine code from verified measured evidence')
    gen.add_argument('evidence');gen.add_argument('--muse-reply',help='JSON of stored Muse reply; not numerical authority')
    gen.add_argument('--target',choices=['marlin_input_shaper','klipper_input_shaper','ardupilot_harmonic_notch'])
    gen.add_argument('--out',required=True)
    live=sub.add_parser('live-muse-draft',help='explicit billable Muse scientific advisor then validated draft')
    live.add_argument('evidence');live.add_argument('--allow-billed-meta',action='store_true');live.add_argument('--out',required=True)
    args=parser.parse_args()
    if args.cmd=='pilot':r=run(args.out)
    elif args.cmd=='train':r=train_manifest(args.manifest,args.out,args.seed)
    elif args.cmd=='train-next':
        from .next_sensation import train_next
        r=train_next(args.manifest,args.out)
    elif args.cmd=='machine-draft':
        evidence=json.loads(Path(args.evidence).read_text());reply=json.loads(Path(args.muse_reply).read_text()) if args.muse_reply else {}
        r=draft(evidence,reply,approved_target=args.target);save_draft(r,args.out)
    elif args.cmd=='live-muse-draft':
        if not args.allow_billed_meta:raise PermissionError('explicit --allow-billed-meta required')
        from physica.experience.meta_live import muse_scientist
        e=json.loads(Path(args.evidence).read_text())
        allowed=e.get('approved_draft_targets',[])
        facts={'resonance_frequency_hz':e.get('resonance_frequency_hz'),
               'damping_ratio':e.get('damping_ratio'),
               'calibration_provenance':e.get('calibration_provenance','UNKNOWN'),
               'approved_actions':allowed,
               'assignment':'Review physical evidence and choose only an approved draft type. No autonomous actuation.'}
        spark=muse_scientist(facts,allowed,role='spark')
        wonder=muse_scientist({**facts,'spark_context':spark['reply']},allowed,role='wonder')
        # Wonder's suggestion is NOT a hardware permission. draft() rechecks the whitelist and units.
        r=draft(e,wonder['reply'])
        r['meta_model_ids']=[spark['model_id'],wonder['model_id']]
        r['live_meta_responses_created']=True
        r['authenticated_execution_not_independent_physics_validation']=True
        save_draft(r,args.out)
        (Path(args.out)/'muse_scientist.json').write_text(json.dumps({'spark':spark,'wonder':wonder},indent=2)+'\n')
    print(json.dumps(r,indent=2))
if __name__=='__main__':main()
