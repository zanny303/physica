"""Reproducible SYNTHETIC-only negative/positive control for v0.25.

The simulator's hidden law and the human-authored hypothesis are deliberately
separate from the candidate validation implementation. No model API call occurs.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np

from .discovery_milestone_v025 import source_discover,plan_probe,target_commit,target_reveal,digest


def _run(seed:int,kind:str,n:int=95, *,initial=None,bias=0.,params=None,controls=None)->np.ndarray:
    rng=np.random.default_rng(seed)
    if params is None:params={'stiffness_s2':1.8,'damping_s1':.32,'control_gain':1.0,'effect_gain':.65}
    if initial is None:x,v=rng.uniform(-.7,.7),rng.uniform(-.35,.35)
    else:x,v=initial
    phase=rng.uniform(0,6.28)
    data=np.empty((n,5))
    dt=.025
    for t in range(n):
        u=float(controls[t]) if controls is not None else float(bias+.36*np.sin(.091*t+phase)+.26*np.cos(.047*t+phase*.4))
        physics=-params['stiffness_s2']*x-params['damping_s1']*v+params['control_gain']*u
        # Synthetic-only hidden law. The source-blind v0.24 library cannot express sin(x + u) exactly.
        unexplained=params['effect_gain']*.65*np.sin(3.7*x+2.2*u)+.045*v*abs(v)
        acc=float(physics+unexplained)
        data[t]=[t*dt,x,v,u,acc+rng.normal(0,.007)]
        v+=dt*acc;x+=dt*v
        if max(abs(x),abs(v))>4:raise ValueError('Synthetic fixture escaped its envelope')
    return data


def _sensor_csv(path,records,*,with_time=False):
    path.parent.mkdir(parents=True,exist_ok=True)
    cols=['x_m','v_m_s','u_m_s2','acc_m_s2']
    if with_time:cols=['time_s',*cols];values=records
    else:values=records[:,1:]
    np.savetxt(path,values,delimiter=',',header=','.join(cols),comments='',fmt='%.9f')


def _fixture(root:Path,identity:str,params:dict,seed:int,ntrain:int=4,nval:int=2):
    root.mkdir(parents=True,exist_ok=True)
    (root/'calibration.json').write_text(json.dumps({'method':'simulated controlled fixture, no real hardware',
       'operator':'PHYSICA SYNTHETIC TEST','date_utc':'2026-11-02T00:00:00Z',
       'instrument':'simulator v0.25','units':'SI',
       'physics_baseline':{k:params[k] for k in ('stiffness_s2','damping_s1','control_gain')}},indent=2))
    train=[];val=[]
    for i in range(ntrain+nval):
        basename=f'{"train" if i<ntrain else "val"}_{i:02d}.csv'
        _sensor_csv(root/basename,_run(seed+i,identity,params=params,bias=(-.25,.1,.25)[i%3]))
        (train if i<ntrain else val).append(basename)
    manifest={'fixture_id':identity,'calibration_file':'calibration.json','episodes':{'train':train,'validation':val}}
    (root/'manifest.json').write_text(json.dumps(manifest,indent=2))
    return root/'manifest.json'


def human_fixture_proposal()->dict:
    # Not derived from Muse. Must never be presented as an authenticated response.
    return {'name':'offline_probe_control_modulated_restoring_force',
        'expression':{'op':'sin','arg':{'op':'add','args':[
           {'op':'mul','args':[{'op':'const','value':2.6},{'op':'x'}]},
           {'op':'mul','args':[{'op':'const','value':1.2},{'op':'u'}]}]}},
        'hypothesis':'An unmodeled bounded periodic acceleration depends jointly on displacement and applied control.',
        'falsification_test':'Change the control amplitude in a low-force experiment while holding similar starting states.',
        'measured_channels':['x_m','u_m_s2','acc_m_s2']}


def synthetic_demo(out:Path,seed:int=7):
    out.mkdir(parents=True,exist_ok=True)
    source_par={'stiffness_s2':1.8,'damping_s1':.32,'control_gain':1.0,'effect_gain':.96}
    target_par={'stiffness_s2':2.06,'damping_s1':.43,'control_gain':.91,'effect_gain':.72}
    source_manifest=_fixture(out/'source_machine_A','A_SYNTHETIC',source_par,1000+seed*100)
    target_manifest=_fixture(out/'target_machine_B','B_SYNTHETIC',target_par,4000+seed*100,ntrain=2,nval=2)
    proposal_file=out/'HUMAN_AUTHORED_HYPOTHESIS_NOT_META.json'
    proposal_file.write_text(json.dumps(human_fixture_proposal(),indent=2))
    receipt=source_discover(source_manifest,out/'source_discovery.json',candidate_file=proposal_file)
    if not receipt['source_candidate_accepted_for_transfer']:
        return {'stage':'SYNTHETIC_NEGATIVE_RESULT_SOURCE_CANDIDATE_REJECTED','source':receipt['selection_comparison'],
                'meta_executed':False}
    probe=plan_probe(out/'source_discovery.json',target_manifest,out/'probe_commit.json',max_distance=5.)
    # The probe is ACTUALLY generated only AFTER its selection was committed.
    z=probe['chosen_initial_conditions']
    probedata=_run(7000+seed,'B_SYNTHETIC',params=target_par,
                   initial=(z['x0_m'],z['v0_m_s']),controls=probe['probe_plan']['controls_m_s2'])
    probe_file=out/'target_machine_B'/'measured_probe_after_plan.csv'
    _sensor_csv(probe_file,probedata,with_time=True)
    manifest=json.loads(target_manifest.read_text())
    manifest['episodes']['train'].append(probe_file.name)
    target_manifest.write_text(json.dumps(manifest,indent=2))
    # Planned controls, not an observed future path.
    count=95
    controls=(.3*np.sin(np.arange(count)*.081)+.25*np.cos(np.arange(count)*.044)).tolist()
    plan={'fixture_id':'B_SYNTHETIC','dt_s':.025,'x0_m':.38,'v0_m_s':-.21,'controls_m_s2':controls}
    plan_file=out/'FUTURE_PLAN_BEFORE_TARGET_TEST.json'
    plan_file.write_text(json.dumps(plan,indent=2))
    target=target_commit(out/'source_discovery.json',target_manifest,plan_file,
                        out/'sealed_future_target_forecasts.json',probe_receipt=out/'probe_commit.json',
                        probe_recording=probe_file)
    # TEST simulation is constructed only after target_commit returns; never used to select an equation.
    test=_run(9000+seed,'B_SYNTHETIC',n=count,params=target_par,
              initial=(plan['x0_m'],plan['v0_m_s']),controls=controls)
    observed_file=out/'target_machine_B'/'future_test_generated_after_commit.csv'
    _sensor_csv(observed_file,test,with_time=True)
    result=target_reveal(out/'sealed_future_target_forecasts.json',observed_file,out/'target_reveal.json')
    summary={'version':'0.25','stage':'SYNTHETIC_RESEARCH_REPLAY_COMPLETE',
       'meta_executed':False,'meta_provenance':'HUMAN_AUTHORED_FIXTURE_NOT_MUSE',
       'source_candidate_passed':True,'source_validation':receipt['selection_comparison'],
       'probe_selection':probe['chosen_initial_conditions'],
       'target_selected_by_validation':target['selected_without_test_data'],
       'target_validation_rmse':target['validation_rmse_m_s2'],
       'target_heldout_metrics':result['held_out_metrics'],
       'meta_structure_won_heldout':result['meta_structure_beats_all_ablations'],
       'source_commit_hash':receipt['sha256'],
       'target_forecast_commit_hash':target['sha256'],
       'real_physical_experiment_proven':False,
       'note':'The unknown law is in the simulation and the off-line hypothesis was manually supplied. No discovery novelty claim.'}
    (out/'RESULTS_SYNTHETIC_NOT_META.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
    return summary


def synthetic_benchmark(out:Path,seeds:int=12):
    """Only SYNTHETIC target experiments; aggregate all successes and failures."""
    if not 2<=seeds<=30:raise ValueError('Specify 2..30 independently seeded fixtures')
    out.mkdir(parents=True,exist_ok=True)
    results=[]
    for s in range(seeds):
        r=synthetic_demo(out/f'seed_{s:02d}',seed=s+3)
        if r['stage']=='SYNTHETIC_RESEARCH_REPLAY_COMPLETE':
            m=r['target_heldout_metrics']
            results.append({'seed':s,'status':r['stage'],'meta_won':r['meta_structure_won_heldout'],
             'errors_position_m':{k:v['x_rmse_m'] for k,v in m.items()},
             'errors_acceleration_m_s2':{k:v['acc_rmse_m_s2'] for k,v in m.items()}})
        else:
            results.append({'seed':s,'status':r['stage'],'meta_won':False})
    complete=[r for r in results if 'errors_position_m' in r]
    methods=('target_only_generic','target_only_neural','source_blind_transfer','source_meta_structure_transfer')
    means={method:float(np.mean([r['errors_position_m'][method] for r in complete])) if complete else None for method in methods}
    gains=[]
    for r in complete:
        base=min(r['errors_position_m'][m] for m in methods if m!='source_meta_structure_transfer')
        gains.append(base-r['errors_position_m']['source_meta_structure_transfer'])
    # Descriptive, not a discovery-significance test; bootstrap seed-level paired improvement.
    rng=np.random.default_rng(867)
    ci=[float(v) for v in np.quantile([np.mean(rng.choice(gains,size=len(gains),replace=True))
                  for _ in range(1000)],[.025,.975])] if len(gains)>1 else None
    report={'version':'0.25','stage':'SYNTHETIC_ONLY_MECHANISM_TRANSFER_BENCHMARK',
        'hypothesis_origin':'HUMAN_AUTHORED_STRUCTURAL_FIXTURE_NOT_META',
        'meta_calls_executed':0,'real_machine_experiments':0,
        'n_seeds_requested':seeds,'complete_runs':len(complete),
        'candidate_wins_all_comparators':sum(bool(r['meta_won']) for r in results),
        'mean_position_rmse_m':means,
        'mean_paired_advantage_over_best_comparator_m':float(np.mean(gains)) if gains else None,
        'bootstrap_95_interval_m':ci,
        'comparator_budget':'All target-only and cross-machine comparators see identical target probe/training/validation evidence',
        'limitations':['Synthetic mechanism family matches the hand-authored proposed expression',
          'There is no real Meta hypothesis in this offline test',
          'The simulator is not a second independent physical machine',
          'Probe policy is heuristic and not proven better than random'],
        'per_seed':results}
    (out/'SYNTHETIC_BENCHMARK.json').write_text(json.dumps(report,indent=2,allow_nan=False))
    return report
