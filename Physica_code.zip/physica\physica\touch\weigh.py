"""A camera that weighs things: film a clamped ruler ringing, and feel how heavy the object on it is, and where.

Physics: putting mass m at position x on a clamped ruler lowers each natural frequency by an amount set by m and by
how much that mode moves at x. The Touch Transform reads the ruler's modes from pixels; beam physics (finite
elements) turns the frequency drops into a mass and a position.

Everything uses frequency RATIOS against the same ruler filmed empty, so the camera's exact frame rate cancels out
(phone slow-motion files often store the wrong rate). One coin of known mass sets the scale in grams, or the user
can give the ruler's own mass.

Three recordings, same phone position, same ruler, same clamp:
  empty   - the ruler alone, flicked once
  coin    - a coin (known grams) taped at a known spot (or found in the image)
  object  - the thing to weigh, taped anywhere on the ruler
Self-check: with two modes, each mode gives its own answer for the mass; if they disagree, the AI says so.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import brentq

from physica.touch import beam
from physica.touch.transform import TouchTransform


# ---------------- video -> ruler modes ----------------
def flow_motion(V: np.ndarray, width: int = 320, step: int = 4, keep: int = 1500) -> dict:
    """Vertical optical-flow speed (pixels/frame) on a grid of the pixels that move most. Handles large motion."""
    import cv2

    T, H, W = V.shape
    s = width / W if W > width else 1.0
    small = [cv2.resize((v * 255).astype(np.uint8), (int(W * s), int(H * s)), interpolation=cv2.INTER_AREA) for v in V]
    h, w = small[0].shape
    ys, xs = np.mgrid[0:h:step, 0:w:step]
    sig = np.zeros((T - 1, ys.size), np.float32)
    for t in range(T - 1):
        fl = cv2.calcOpticalFlowFarneback(small[t], small[t + 1], None, 0.5, 3, 15, 3, 5, 1.2, 0)
        sig[t] = fl[ys, xs, 1].ravel()
    var = sig.var(0)
    sel = np.argsort(-var)[:keep]
    return {"signals": sig[:, sel] - sig[:, sel].mean(0), "rows": ys.ravel()[sel] / s, "cols": xs.ravel()[sel] / s,
            "scale": s, "shape": (H, W)}


def decay_window(sig: np.ndarray, fs: float, min_s: float = 1.0) -> slice:
    """The free ringing after the strongest flick (skip the flick itself)."""
    e = (sig ** 2).sum(1)
    w = max(int(0.02 * fs), 1)
    e = np.convolve(e, np.ones(w) / w, "same")
    i = int(np.argmax(e)) + int(0.08 * fs)
    j = len(e)
    later = np.where(e[i + int(0.3 * fs):] > 0.8 * e[i])[0]  # another flick: stop before it
    if len(later):
        j = i + int(0.3 * fs) + int(later[0]) - int(0.05 * fs)
    if (j - i) / fs < min_s:
        i, j = 0, len(e)
    return slice(i, j)


RATIO_2 = (4.0, 8.0)  # a clamped ruler's 2nd bending mode sits ~6.3x above the 1st (6.27 for a uniform beam)


def _not_echo(m, f1):
    """Optical flow of a big swing adds copies of the first mode at 2x, 3x, 4x; a ruler's bending modes are not at
    whole multiples of the first, so those are sensing echoes, not the ruler."""
    r = m.freq_hz / f1
    return not any(abs(r - k) < 0.03 * k for k in (2, 3, 4, 5))


def _ruler_pick(modes):
    """Physics knows what a clamped ruler can do: mode 1 is the strongest low mode; mode 2 is the strongest mode
    4-8x higher. Anything else (sensing echoes at 2x, 3x; the table; the phone) is ignored."""
    if not modes:
        return []
    low = sorted(modes, key=lambda m: m.freq_hz)
    first = max(low[:3], key=lambda m: m.energy)
    second = [m for m in modes if RATIO_2[0] * first.freq_hz <= m.freq_hz <= RATIO_2[1] * first.freq_hz
              and _not_echo(m, first.freq_hz)]
    return [first] + ([max(second, key=lambda m: m.energy)] if second else [])


def _ruler_pick_loaded(modes, empty_hz):
    """With a mass on, each mode drops but stays above the empty ruler's next-lower mode (interlacing):
    mode 1 in (0, f1_empty], mode 2 in [f1_empty, f2_empty]."""
    out = []
    edges = [0.0] + list(empty_hz)
    for k in range(len(empty_hz)):
        c = [m for m in modes if edges[k] * 1.0 < m.freq_hz <= edges[k + 1] * 1.01 and (k == 0 or _not_echo(m, out[0].freq_hz))]
        if not c:
            break
        out.append(max(c, key=lambda m: m.energy))
    return out


def ruler_modes(V: np.ndarray, fps: float, band: tuple | None = None, empty_hz: list | None = None) -> dict:
    mo = flow_motion(V)
    win = decay_window(mo["signals"], fps)
    Y = mo["signals"][win]
    band = band or (1.0, 0.45 * fps)
    kw = dict(n_modes=6, band=band, order=24, space_rank=3, measure="velocity", max_damping=0.1)
    tt = TouchTransform(fps, **kw).fit(Y)
    halves = [TouchTransform(fps, **kw).fit(Y[h]) for h in (slice(0, len(Y) // 2), slice(len(Y) // 2, len(Y)))]
    modes = []
    for m in (_ruler_pick_loaded(tt.modes, empty_hz) if empty_hz else _ruler_pick(tt.modes)):
        hf = []
        for h in halves:
            q = min(h.modes, key=lambda q: abs(q.freq_hz - m.freq_hz)) if h.modes else None
            hf.append(q.freq_hz if q is not None and abs(q.freq_hz - m.freq_hz) < 0.05 * m.freq_hz else None)
        spread = abs(hf[0] - hf[1]) / m.freq_hz if None not in hf else 0.02
        modes.append({"freq_hz": m.freq_hz, "damping": m.damping, "rel_sd": max(spread / 2, 0.01), "shape": m.shape})
    cands = sorted({round(m.freq_hz, 4): m for m in tt.modes}.values(), key=lambda m: m.freq_hz)
    return {"modes": modes, "candidates": [{"freq_hz": m.freq_hz, "energy": m.energy} for m in cands], "motion": mo,
            "window_s": [win.start / fps, win.stop / fps]}


def second_mode_by_physics(rm: dict, empty_hz: list, x_seen: float | None, tol: float = 0.1) -> list:
    """With a mass on, where must mode 2 be? Sight says where the mass sits, the drop of mode 1 says how heavy:
    physics then predicts mode 2. Take the felt candidate nearest that prediction (within tol), else keep mode 1 only."""
    modes = rm["modes"]
    if not modes or x_seen is None or len(empty_hz) < 2:
        return modes[:1]
    body = body_scale(list(empty_hz)[:2])
    mu1 = mass_fraction([modes[0]["freq_hz"] * empty_hz[0] / (body["hz_per_unit"] * beam.cantilever_freqs(n=1, tip_mass=body["tip_mass"])[0])], body, x_seen)[0]
    if not np.isfinite(mu1):
        return modes[:1]
    ratio = beam.cantilever_freqs([(x_seen, mu1)], n=2, tip_mass=body["tip_mass"])[1] / beam.cantilever_freqs(n=2, tip_mass=body["tip_mass"])[1]
    want = empty_hz[1] * ratio
    near = [c for c in rm["candidates"] if abs(c["freq_hz"] / want - 1) < tol and c["freq_hz"] > modes[0]["freq_hz"] * 1.5]
    if not near:
        return modes[:1]
    best = min(near, key=lambda c: abs(c["freq_hz"] / want - 1))
    return [modes[0], {"freq_hz": best["freq_hz"], "damping": None, "rel_sd": 0.01, "predicted_hz": want}]


def ruler_axis(rm: dict) -> dict:
    """Where the ruler is in the image: its line, its clamp end (motion fades to zero) and its free tip (moves most),
    read from where the lowest mode moves."""
    mo, m1 = rm["motion"], np.abs(rm["modes"][0]["shape"])
    w = m1 / m1.max()
    P = np.stack([mo["cols"], mo["rows"]], 1)
    c = (P * w[:, None]).sum(0) / w.sum()
    U, S, Vt = np.linalg.svd((P - c) * np.sqrt(w)[:, None], full_matrices=False)
    d = Vt[0]
    s = (P - c) @ d
    tip_side = np.sign(np.sum(s * w ** 4))
    s = s * tip_side
    d = d * tip_side
    # envelope of motion along the ruler (strongest pixel per slice), so still background can't drag the fit
    edges = np.linspace(s.min(), s.max(), 61)
    mid = (edges[:-1] + edges[1:]) / 2
    env = np.array([w[(s >= a) & (s < b)].max() if np.any((s >= a) & (s < b)) else 0.0 for a, b in zip(edges[:-1], edges[1:])])
    tip = float(mid[np.where(env > 0.5 * env.max())[0][-1]])
    # clamp: where the textbook first-mode shape, stretched from there to the tip, best fits the envelope
    xi, S1, _ = beam.mode_shapes(n=1, points=401)
    psi = np.abs(S1[0]) / np.abs(S1[0]).max()
    best = None
    span = tip - s.min()
    for s0 in np.linspace(tip - 1.5 * span, tip - 0.1 * span, 400):
        u = (mid - s0) / (tip - s0)
        model = np.where((u >= 0) & (u <= 1), np.interp(np.clip(u, 0, 1), xi, psi), np.where(u > 1, np.nan, 0.0))
        ok = ~np.isnan(model)
        err = float(np.sum((env[ok] / env.max() - model[ok]) ** 2))
        if best is None or err < best[0]:
            best = (err, s0)
    clamp = float(best[1])
    return {"center": c.tolist(), "dir": d.tolist(), "clamp_s": clamp, "tip_s": tip, "length_px": tip - clamp}


def position_in_image(V_empty: np.ndarray, V_obj: np.ndarray, axis: dict) -> float | None:
    """Where the object sits along the ruler (0 = clamp, 1 = tip): the biggest thing that differs between the two
    videos' median images (the ringing ruler blurs the same way in both). Needs the phone not to move between
    recordings; returns None if no clear object is found."""
    import cv2

    a, b = np.median(V_empty, 0), np.median(V_obj, 0)
    diff = np.abs(b - a)
    thr = max(0.12, float(np.quantile(diff, 0.999)) * 0.5)
    mask = (diff >= thr).astype(np.uint8)
    n, lab, stats, cents = cv2.connectedComponentsWithStats(mask, 8)
    if n < 2:
        return None
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    if stats[k, cv2.CC_STAT_AREA] < 12:
        return None
    s = (cents[k] - np.array(axis["center"])) @ np.array(axis["dir"])
    return float(np.clip((s - axis["clamp_s"]) / axis["length_px"], 0.02, 1.0))


# ---------------- frequencies -> mass ----------------
def body_scale(empty_hz: list[float]) -> dict:
    """Hz per dimensionless unit, and an end mass that absorbs a not-quite-rigid clamp (two or more modes)."""
    if len(empty_hz) >= 2:
        return beam.fit_body(empty_hz)
    return {"hz_per_unit": empty_hz[0] / beam.cantilever_freqs(n=1)[0], "tip_mass": 0.0, "residual_pct": [0.0]}


def mass_fraction(with_hz: list[float], body: dict, x: float) -> list[float]:
    """For each mode: the point mass (fraction of the ruler's mass) at x that lowers that mode to the felt value."""
    c, tip = body["hz_per_unit"], body["tip_mass"]
    out = []
    for k, f in enumerate(with_hz):
        g = lambda mu: np.log(c * beam.cantilever_freqs([(x, mu)], n=k + 1, tip_mass=tip)[k]) - np.log(f)
        lo, hi = 1e-5, 50.0
        if g(lo) <= 0:
            out.append(0.0)
        elif g(hi) > 0:
            out.append(np.inf)
        else:
            out.append(float(brentq(g, lo, hi, xtol=1e-6)))
    return out


def weigh_fused(empty_hz, obj_hz, ruler_g: float, x_seen: float | None, rel_sd=0.005,
                ruler_g_range: list | None = None) -> dict:
    """Grams and place, from sight (image place) and touch (every felt mode's drop) together."""
    r = fuse(empty_hz, obj_hz, x_seen, rel_sd=rel_sd)
    lo, hi = r["mu_90"]
    rg_lo, rg_hi = (ruler_g_range or [ruler_g, ruler_g])
    return {"grams": r["mu"] * ruler_g, "grams_90": [lo * min(rg_lo, rg_hi), hi * max(rg_lo, rg_hi)],
            "place": r["place"], "place_90": r["place_90"], "place_seen": x_seen, "fit_pct": r["fit_pct"],
            "mass_vs_ruler": r["mu"]}


def weigh(empty_hz: list[float], obj_hz: list[float], ruler_g: float, x: float | None = None,
          rel_sd: float = 0.005) -> dict:
    """Mass (grams) and place of an object on the ruler. If x is None, both are felt from the frequencies (needs
    two modes); otherwise x (0 = clamp, 1 = tip) comes from the image."""
    body = body_scale(empty_hz)
    n = min(len(empty_hz), len(obj_hz))
    obj_hz = list(obj_hz)[:n]
    if x is None:
        if n < 2:
            raise ValueError("finding the place from frequencies needs two modes; give the place from the image")
        r = beam.feel_mass_change(obj_hz, list(empty_hz)[:n], rel_sd=rel_sd)
        x, mu, x90 = r["position"], r["mass_fraction"], r["position_90"]
        per_mode = mass_fraction(obj_hz, body, x)
    else:
        x90 = None
        per_mode = mass_fraction(obj_hz, body, x)
        sens = sensitivity(x, n, body)
        use = [k for k in range(n) if sens[k] >= 0.15 * max(sens) and np.isfinite(per_mode[k]) and per_mode[k] > 0]
        w = {k: sens[k] for k in use}  # a mode that barely moves at x says little about the mass there
        mu = float(np.exp(sum(np.log(per_mode[k]) * w[k] for k in use) / sum(w.values()))) if use else 0.0
    # range from frequency uncertainty: redo with the lowest mode nudged by +-2 sd
    f1 = obj_hz[0]
    lo_mu = mass_fraction([f1 * (1 + 2 * rel_sd)], body, x)[0]
    hi_mu = mass_fraction([f1 * (1 - 2 * rel_sd)], body, x)[0]
    grams = mu * ruler_g
    agree = None
    sens = sensitivity(x, n, body)
    informative = [per_mode[k] for k in range(n) if sens[k] >= 0.15 * max(sens) and np.isfinite(per_mode[k]) and per_mode[k] > 0]
    if len(informative) >= 2:
        agree = float(max(informative) / min(informative))
    return {"grams": float(grams), "grams_range": [float(lo_mu * ruler_g), float(hi_mu * ruler_g)], "place": float(x),
            "place_90": x90, "per_mode_grams": [float(m * ruler_g) for m in per_mode],
            "modes_agree_ratio": agree, "trust": "good" if (agree is None or agree < 1.25) else "modes disagree: check clamp and tape",
            "mass_vs_ruler": float(mu)}


def sensitivity(x: float, n: int, body: dict) -> list[float]:
    """How much each mode moves at place x (squared unit-RMS shape): how much a mass there can shift it."""
    xi, S, _ = beam.mode_shapes(n=n, tip_mass=body.get("tip_mass", 0.0), points=401)
    return [float(np.interp(x, xi, S[k]) ** 2) for k in range(n)]


_TABLE: dict = {}


def _table(tip: float, n: int):
    """Felt-frequency table of the ruler with a point mass at every place x and every size mu (cached)."""
    key = (round(tip, 4), n)
    if key not in _TABLE:
        xs = np.linspace(0.02, 1.0, 99)
        mus = np.geomspace(0.003, 20.0, 90)
        F = np.array([[beam.cantilever_freqs([(x, mu)], n_el=40, n=n, tip_mass=tip) for mu in mus] for x in xs])
        F0 = beam.cantilever_freqs(n_el=40, n=n, tip_mass=tip)
        _TABLE[key] = (xs, mus, F / F0)  # frequency ratios loaded/empty
    return _TABLE[key]


def fuse(empty_hz, with_hz, x_seen: float | None, x_sd: float = 0.04, rel_sd=0.005) -> dict:
    """Sight and touch together: the image says roughly where the mass is (prior on x); every felt mode's drop
    says how heavy and where. Posterior over (place, mass fraction), so the range includes place uncertainty."""
    n = min(len(empty_hz), len(with_hz))
    body = body_scale(list(empty_hz)[:max(n, 1)])
    xs, mus, R = _table(body["tip_mass"], n)
    obs = np.log(np.asarray(with_hz[:n]) / np.asarray(empty_hz[:n]))
    sd = np.broadcast_to(np.asarray(rel_sd, float), (n,)) * np.sqrt(2)  # both recordings carry error
    ll = -0.5 * (((np.log(R) - obs) / sd) ** 2).sum(-1)
    if x_seen is not None:
        ll = ll - 0.5 * ((xs[:, None] - x_seen) / x_sd) ** 2
    P = np.exp(ll - ll.max())
    P /= P.sum()
    pm = P.sum(0)
    cdf = np.cumsum(pm)
    q = lambda a: float(mus[min(np.searchsorted(cdf, a), len(mus) - 1)])
    px = P.sum(1)
    cx = np.cumsum(px)
    qx = lambda a: float(xs[min(np.searchsorted(cx, a), len(xs) - 1)])
    i, j = np.unravel_index(np.argmax(P), P.shape)
    return {"mu": float(np.exp((P * np.log(mus)[None, :]).sum())), "mu_90": [q(0.05), q(0.95)], "mu_map": float(mus[j]),
            "place": float((P * xs[:, None]).sum()), "place_90": [qx(0.05), qx(0.95)], "body": body,
            "fit_pct": [float(100 * (np.exp(v) - 1)) for v in (np.log(R[i, j]) - obs)]}


def ruler_mass_fused(empty_hz, coin_hz, coin_g: float, x_seen: float | None, rel_sd=0.005, x_sd: float = 0.04) -> dict:
    """Calibrate the ruler's own mass from one coin, with sight and touch together."""
    r = fuse(empty_hz, coin_hz, x_seen, x_sd=x_sd, rel_sd=rel_sd)
    return {"ruler_g": coin_g / r["mu"], "ruler_g_90": [coin_g / r["mu_90"][1], coin_g / r["mu_90"][0]],
            "coin_place": r["place"], "fit_pct": r["fit_pct"]}


def ruler_mass_from_coin(empty_hz, coin_hz, coin_g: float, x_coin: float, rel_sd: float = 0.005) -> dict:
    """Calibrate: the ruler's own mass in grams from one coin of known mass at a known place."""
    body = body_scale(empty_hz)
    n = min(len(empty_hz), len(coin_hz))
    mus = mass_fraction(list(coin_hz)[:n], body, x_coin)
    sens = sensitivity(x_coin, n, body)
    use = [k for k in range(n) if sens[k] >= 0.15 * max(sens) and np.isfinite(mus[k]) and mus[k] > 0]
    mu = float(np.exp(sum(np.log(mus[k]) * sens[k] for k in use) / sum(sens[k] for k in use)))
    lo = mass_fraction([coin_hz[0] * (1 - 2 * rel_sd)], body, x_coin)[0]
    hi = mass_fraction([coin_hz[0] * (1 + 2 * rel_sd)], body, x_coin)[0]
    return {"ruler_g": float(coin_g / mu), "ruler_g_range": [float(coin_g / lo), float(coin_g / hi) if hi > 0 else float("inf")],
            "per_mode_ruler_g": [float(coin_g / m) if m > 0 else float("inf") for m in mus], "body": body}


def weigh_videos(V_empty, V_coin, V_obj, fps: float, coin_g: float, coin_place: float | None = None,
                 ruler_g: float | None = None) -> dict:
    """The whole trick: three videos in, grams and place out, with ranges and the checks that back them."""
    re = ruler_modes(V_empty, fps)
    if not re["modes"]:
        raise ValueError("no ringing found in the empty-ruler video: flick it harder, film closer, use slow motion")
    fe = [m["freq_hz"] for m in re["modes"]]
    sd_e = [m["rel_sd"] for m in re["modes"]]
    axis = ruler_axis(re)
    out = {"empty_hz": fe, "ruler_axis": axis, "physics_check": None}
    if len(fe) >= 2:
        out["physics_check"] = {"ratio_2_to_1": fe[1] / fe[0], "uniform_clamped_ruler": 6.267,
                                "say": "clamp is solid" if abs(fe[1] / fe[0] - 6.267) < 0.6 else "clamp may be loose: press the ruler down harder"}
    if ruler_g is None:
        rc = ruler_modes(V_coin, fps, empty_hz=fe)
        xc = coin_place if coin_place is not None else position_in_image(V_empty, V_coin, axis)
        rc["modes"] = second_mode_by_physics(rc, fe, xc)
        fc = [m["freq_hz"] for m in rc["modes"]]
        cal = ruler_mass_fused(fe, fc, coin_g, xc, rel_sd=np.maximum(sd_e[:len(fc)], [m["rel_sd"] for m in rc["modes"]]))
        ruler_g, rg90 = cal["ruler_g"], cal["ruler_g_90"]
        out["coin"] = {"hz": fc, "place_seen": xc, **cal}
    else:
        rg90 = [ruler_g, ruler_g]
    ro = ruler_modes(V_obj, fps, empty_hz=fe)
    xo = position_in_image(V_empty, V_obj, axis)
    if not ro["modes"]:
        raise ValueError("no ringing found in the object video: flick it the same way, film the same way")
    ro["modes"] = second_mode_by_physics(ro, fe, xo)
    fo = [m["freq_hz"] for m in ro["modes"]]
    w = weigh_fused(fe, fo, ruler_g, xo, rel_sd=np.maximum(sd_e[:len(fo)], [m["rel_sd"] for m in ro["modes"]]), ruler_g_range=rg90)
    out["object"] = {"hz": fo, **w}
    out["say"] = (f"About {w['grams']:.0f} g (90% range {w['grams_90'][0]:.0f}-{w['grams_90'][1]:.0f} g), "
                  f"{100 * w['place']:.0f}% of the way from the clamp to the tip"
                  + (f" (the image said {100 * xo:.0f}%; the vibration moved it)" if xo is not None and abs(xo - w["place"]) > 0.04 else "")
                  + ". Advice, not a certified scale.")
    return out
