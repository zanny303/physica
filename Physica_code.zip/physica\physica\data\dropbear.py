"""Loaders for the DROPBEAR testbed datasets (University of South Carolina ARTS-Lab / High-Rate SHM Working Group,
CC BY-SA 4.0). A steel cantilever with a roller support that a linear actuator slides along it; the roller position
is measured by a linear transducer and is used ONLY to score Physica, never to feel.

Dataset-2 (2019): 352.5 mm beam, one accelerometer at the tip, 25.6 kHz, 44 s, pin location in metres.
Dataset-8 (2022): 501 mm beam, two accelerometers + two strain gauges, 5 kHz, many 12 s trials; pin location as
the transducer voltage (0-5 V over a 225 mm stroke per the sensor's listing, so 45 mm/V; offset unknown).
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from physica.cause.fe import Beam

MM_PER_VOLT_D8 = 225.0 / 5.0


def beam_d2() -> Beam:
    # dimensions and sensor mass as published in the dataset file itself
    return Beam(0.3525, 0.0508, 0.00635, "steel", tip_mass_kg=0.055, name="DROPBEAR-2019 (A): 352 mm, tip accelerometer")


def beam_d8() -> Beam:
    # dimensions from the dataset README; sensor masses are not published, so none are assumed
    return Beam(0.501, 0.051, 0.00666, "steel", tip_mass_kg=0.0, name="DROPBEAR-2022 (B): 501 mm, low-g accelerometer")


def load_d2(path: str | Path) -> dict:
    d = json.loads(Path(path).read_text())
    a = np.asarray(d["acceleration_data"], float)
    tp, p = np.asarray(d["measured_pin_location_tt"], float), np.asarray(d["measured_pin_location"], float)
    ok = np.isfinite(p)
    out = {"acc": a, "fs": 25600.0, "pin_t": tp[ok], "pin_mm": p[ok] * 1e3}
    if "estimated_pin_location" in d:  # the dataset authors' own real-time model updating, for comparison
        out["published"] = {"t": np.asarray(d["time_cycle_end"], float),
                            "pin_mm": np.asarray(d["estimated_pin_location"], float) * 1e3,
                            "freq_hz": np.asarray(d["measured_frequency"], float)}
    return out


def load_d8(path: str | Path) -> dict:
    lines = Path(path).read_text(errors="replace").splitlines()
    hdr, start = None, 0
    for i, line in enumerate(lines):
        if line.startswith("Low G Accel"):
            hdr, start = line.split("\t"), i + 3
            break
    if hdr is None:
        raise ValueError(f"not a DROPBEAR-8 trial: {path}")
    rows = [line.split("\t")[:len(hdr)] for line in lines[start:] if line.strip() and line[0] in "-0123456789"]
    D = np.array(rows, float)
    fs = 1.0 / float(np.median(np.diff(D[:, hdr.index("Time")])))
    ch = {h: D[:, j] for j, h in enumerate(hdr) if h not in ("Time",)}
    return {"channels": ch, "fs": fs, "pin_v": ch.pop("PinLoc"), "name": str(path)}
