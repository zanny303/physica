"""Physica experimental neural-guided causal discovery (v0.24).

A research candidate, not a claim of new physics or physical consciousness.
Key separations: measured observations vs neural inference vs candidate equations;
train/validation/prospective test episodes; permitted, bounded *review-only* probes.

No hidden simulator constants are passed to the identification functions.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import minimize
from sklearn.linear_model import Ridge
from sklearn.neural_network import MLPRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

DT = .025
ALLOWED_MECHANISMS = ("sin_affine", "cubic_stiffness", "velocity_friction", "quadratic_drag", "bilinear")
BENCHMARK_ONLY_UNMODELED = ("time_modulated", "hidden_memory")


def known_acceleration(x: np.ndarray, v: np.ndarray, u: np.ndarray) -> np.ndarray:
    return -1.8*x - .32*v + u


def hidden_simulator(x: float, v: float, mechanism: str, strength: float = 1.) -> float:
    """Benchmark ONLY. The learner never accesses this function or its parameters."""
    if mechanism == 'sin_affine':
        return strength*(.58*np.sin(3.7*x+1.15*v)+.27*v*abs(v))
    if mechanism == 'cubic_stiffness':
        return -strength*.95*x*x*x
    if mechanism == 'velocity_friction':
        return -strength*.48*np.tanh(v/.095)
    if mechanism == 'quadratic_drag':
        return -strength*.78*v*abs(v)
    if mechanism == 'bilinear':
        return strength*.70*x*v
    raise ValueError('Unknown simulator scenario')


def simulate(seed: int, mechanism: str, *, n: int = 95, initial: tuple[float,float] | None = None,
             control_bias: float = 0., noise: float = .012, strength: float = 1.) -> np.ndarray:
    """Simulated controlled experiment; last column is a noisy acceleration measurement.

    Columns: x [m], v [m/s], command u [m/s²], measured acceleration [m/s²].
    Raw unobserved true acceleration is intentionally not returned.
    """
    rng = np.random.default_rng(seed)
    if initial is None:
        x = float(rng.uniform(-.85,.85)); v=float(rng.uniform(-.5,.5))
    else:
        x,v = map(float,initial)
    records = np.empty((n,4),dtype=float)
    hidden_memory = 0.0
    phase = rng.uniform(0,6.28)
    for t in range(n):
        u = float(control_bias+.35*np.sin(t*.061+phase)+.22*np.cos(t*.037+phase*.3))
        if mechanism=='time_modulated':
            unknown = strength*.55*np.sin(3.1*x+.7*v)*np.cos(.10*t)
        elif mechanism=='hidden_memory':
            hidden_memory = .97*hidden_memory+.03*v
            unknown = strength*.85*hidden_memory
        else:
            unknown = hidden_simulator(x,v,mechanism,strength)
        acc = float(known_acceleration(x,v,u) + unknown)
        records[t] = (x,v,u,acc+rng.normal(0,noise))
        v += DT*acc; x += DT*v
        if max(abs(x),abs(v)) > 6:
            raise ValueError('Simulator escaped safe envelope')
    return records


def check_rows(data: np.ndarray, *, min_rows: int = 18) -> np.ndarray:
    data = np.asarray(data, dtype=float)
    if data.ndim != 2 or data.shape[1] != 4 or len(data)<min_rows or not np.isfinite(data).all():
        raise ValueError('Require finite N x 4 [x_m, v_m_s, u_m_s2, measured_acc_m_s2] array')
    if np.any(np.abs(data[:,0])>5) or np.any(np.abs(data[:,1])>5) or np.any(np.abs(data[:,2])>4):
        raise ValueError('Evidence outside declared conservative operating envelope')
    return data


def residual(data: np.ndarray) -> np.ndarray:
    data = check_rows(data)
    x,v,u = data[:,:3].T
    return data[:,3]-known_acceleration(x,v,u)


def generic_basis(data: np.ndarray) -> np.ndarray:
    """The generic base library contains no unknown sine frequency or phase."""
    x,v,u=data[:,:3].T
    return np.column_stack((x,v,u,x*v,v*np.abs(v),x*x*x))


def added_basis(data: np.ndarray, mechanism: str, param: tuple[float,float]|None=None) -> np.ndarray:
    x,v,u=data[:,:3].T
    if mechanism=='sin_affine':
        if param is None:raise ValueError('sin_affine requires fitted frequencies')
        a,b=param
        theta=a*x+b*v
        return np.column_stack((np.sin(theta),np.cos(theta)))
    if mechanism=='cubic_stiffness':return (x*x*x)[:,None]
    if mechanism=='velocity_friction':return np.tanh(v/.11)[:,None]
    if mechanism=='quadratic_drag':return (v*np.abs(v))[:,None]
    if mechanism=='bilinear':return (x*v)[:,None]
    raise ValueError('Unknown or unapproved mechanism family')


def fit_linear(train: np.ndarray, *, term: str | None = None, params:tuple[float,float] | None = None,
               alpha: float = .04) -> dict[str,Any]:
    data=check_rows(train)
    base=generic_basis(data)
    # Base has ordinary polynomial/drag candidates but not a parameterized hidden oscillation.
    X=np.column_stack((np.ones(len(data)),base))
    if term: X=np.column_stack((X,added_basis(data,term,params)))
    y=residual(data)
    # Explicit stable ridge solve: do not penalize the intercept.
    reg=np.eye(X.shape[1])*alpha;reg[0,0]=0
    coef=np.linalg.solve(X.T@X+reg,X.T@y)
    return {'kind':'symbolic','term':term,'params':params,'coefficients':coef.tolist(),'alpha':alpha}


def predict_linear(model:dict[str,Any], rows:np.ndarray) -> np.ndarray:
    rows=check_rows(rows,min_rows=1)
    base=generic_basis(rows)
    X=np.column_stack((np.ones(len(rows)),base))
    if model['term']:
        X=np.column_stack((X,added_basis(rows,model['term'],model['params'])))
    x,v,u=rows[:,:3].T
    return known_acceleration(x,v,u)+X@np.asarray(model['coefficients'])


def fit_neural_ensemble(train:np.ndarray, seeds=(11,23,37), max_iter=220) -> list[Any]:
    train=check_rows(train)
    models=[]
    for seed in seeds:
        model=make_pipeline(StandardScaler(), MLPRegressor(hidden_layer_sizes=(28,24),
               activation='tanh',solver='adam',alpha=.035,learning_rate_init=.003,
               max_iter=max_iter,random_state=seed))
        model.fit(train[:,:3],residual(train))
        models.append(model)
    return models


def neural_forecasts(models:list[Any], data:np.ndarray) -> np.ndarray:
    data=check_rows(data,min_rows=1)
    x,v,u=data[:,:3].T
    baseline=known_acceleration(x,v,u)
    return np.array([baseline+m.predict(data[:,:3]) for m in models])


def error(actual:np.ndarray, predicted:np.ndarray) -> float:
    if not np.isfinite(predicted).all():return float('inf')
    return float(np.sqrt(np.mean((np.asarray(actual)-np.asarray(predicted))**2)))


def neural_guided_symbolic_search(train:np.ndarray, val:np.ndarray, teacher:list[Any],
                                  *, enabled_terms:tuple[str,...] = ALLOWED_MECHANISMS,
                                  max_candidates:int=4, sensor_noise_floor:float=.012) -> dict[str,Any]:
    """Search a novel continuous-frequency sine, optionally guided by trained neural residuals.

    The NN guides the shape search but NEVER supplies accepted physical evidence.
    Coefficients are refit against measured training outcomes; validation decides.
    No access to the actual hidden equation or withheld test episodes.
    """
    train=check_rows(train); val=check_rows(val)
    if not set(enabled_terms) <= set(ALLOWED_MECHANISMS):raise ValueError('Unapproved mechanism family')
    target=residual(train); neural_mean=neural_forecasts(teacher,train).mean(axis=0)-known_acceleration(*train[:,:3].T)
    baseline=fit_linear(train)
    base_val=error(val[:,3],predict_linear(baseline,val))
    records=[{'term':'none','val_rmse':base_val,'model':baseline,'search_origin':'generic_baseline'}]
    best_sine=None
    if 'sin_affine' in enabled_terms:
        # Frequency/direction search; note that 3.7 and 1.15 are NOT given as candidates.
        # Distill a neural prediction only for ranking structural candidates.
        x,v=train[:,0],train[:,1]
        base=generic_basis(train)
        X0=np.column_stack((np.ones(len(train)),base))
        teacher_target=.5*target+.5*neural_mean
        best=[]
        for a in np.linspace(.65,7.8,13):
            for b in np.linspace(-3.0,3.0,13):
                theta=a*x+b*v
                F=np.column_stack((X0,np.sin(theta),np.cos(theta)))
                coeff=np.linalg.lstsq(F,teacher_target,rcond=None)[0]
                mse=float(np.mean((F@coeff-teacher_target)**2))
                best.append((mse,a,b))
        best.sort(key=lambda row:row[0])
        for _,a,b in best[:max_candidates]:
            def obj(ab):
                freq_a,freq_b=ab
                if not (.20<=freq_a<=9 and -4<=freq_b<=4):return 1e4
                F=np.column_stack((X0,np.sin(freq_a*x+freq_b*v),np.cos(freq_a*x+freq_b*v)))
                c=np.linalg.lstsq(F,teacher_target,rcond=None)[0]
                return float(np.mean((F@c-teacher_target)**2))
            opt=minimize(obj,[a,b],method='Nelder-Mead',options={'maxiter':100,'xatol':.02,'fatol':1e-7})
            params=tuple(float(v) for v in opt.x)
            if not (.2<=params[0]<=9 and -4<=params[1]<=4):continue
            candidate=fit_linear(train,term='sin_affine',params=params)
            score=error(val[:,3],predict_linear(candidate,val))
            if best_sine is None or score<best_sine[0]:best_sine=(score,candidate)
        if best_sine is not None:
            records.append({'term':'sin_affine','val_rmse':best_sine[0], 'model':best_sine[1],
                            'search_origin':'neural_guided_frequency_search_not_preseeded'})
    # All other families are bounded known candidate classes (no claim of novelty).
    for term in enabled_terms:
        if term=='sin_affine':continue
        candidate=fit_linear(train,term=term)
        score=error(val[:,3],predict_linear(candidate,val))
        records.append({'term':term,'val_rmse':score,'model':candidate,'search_origin':'known_generic_family'})
    # Gate against nontrivial overfit: require at least 2% independent validation improvement.
    acceptable=[r for r in records[1:] if r['val_rmse']<base_val*.98]
    chosen=min(acceptable,key=lambda r:r['val_rmse']) if acceptable else records[0]
    unresolved = float(chosen['val_rmse']) > max(.06,4*float(sensor_noise_floor))
    return {'chosen':chosen,'candidates':[{k:v for k,v in r.items() if k!='model'} for r in records],
            'baseline_validation_rmse':base_val,
            'unexplained_residual':unresolved,'transfer_authorized':False,
            'evidence_status':'UNEXPLAINED_REQUIRES_MORE_EVIDENCE' if unresolved else 'VALIDATION_ONLY_NOT_REAL_WORLD_DISCOVERY'}


def choose_safe_probe(models:list[Any], candidates:list[dict[str,float]],train:np.ndarray,
                      *, policy:str='curious',max_distance:float=2.5,random_seed:int=91) -> dict[str,float]:
    """Choose one *review-only* controlled initial state/control from a preapproved set.

    Curiosity is epistemic ensemble disagreement, not large irreversible actions.
    Reject out-of-support probes; no physical hardware commands.
    """
    train=check_rows(train)
    if not candidates:raise ValueError('No approved probes')
    scaler=np.std(train[:,:3],axis=0).clip(min=.12)
    mu=np.mean(train[:,:3],axis=0)
    scores=[]
    for item in candidates:
        row=np.array([float(item['x0']),float(item['v0']),float(item['u_bias'])])
        if not np.isfinite(row).all() or abs(row[0])>.95 or abs(row[1])>.55 or abs(row[2])>.6:
            continue
        distance=float(np.linalg.norm((row-mu)/scaler))
        if distance>max_distance:continue
        probe=np.column_stack((row.reshape(1,3),np.zeros((1,1))))
        forecasts=neural_forecasts(models,probe)[:,0]
        spread=float(np.std(forecasts))
        surprise=float(np.abs(np.mean(forecasts)-known_acceleration(*row)))
        score=spread+.20*surprise-.025*distance
        scores.append((score,item))
    if not scores:raise ValueError('All candidate probes unsafe or outside observed training support')
    if policy=='curious':return dict(max(scores,key=lambda t:t[0])[1])
    if policy=='random':return dict(scores[np.random.default_rng(random_seed).integers(len(scores))][1])
    raise ValueError('Unknown probe policy')


def proposal_from_meta_json(raw:dict[str,Any]) -> dict[str,Any]:
    """Strictly bounded, auditable candidate registry. Never executes generated text."""
    if not isinstance(raw,dict) or set(raw)!={'family','reason','test','measured_channels'}:
        raise ValueError('Meta hypothesis schema mismatch')
    if raw['family'] not in ALLOWED_MECHANISMS:raise ValueError('Unapproved physical mechanism')
    if not isinstance(raw['reason'],str) or not isinstance(raw['test'],str):raise ValueError('Invalid hypothesis text')
    if len(raw['reason'])>1200 or len(raw['test'])>1200:raise ValueError('Oversized hypothesis')
    if not isinstance(raw['measured_channels'],list) or any(c not in ('x_m','v_m_s','u_m_s2','acc_m_s2') for c in raw['measured_channels']):
        raise ValueError('Invented sensor channels')
    return {'family':raw['family'],'status':'UNVERIFIED_MODEL_PROPOSAL','reason':raw['reason'],
            'test':raw['test'],'measured_channels':raw['measured_channels']}


def benchmark(*, seeds:int=4, mechanisms:tuple[str,...]=('sin_affine','cubic_stiffness','velocity_friction'),
              out:str|None=None, use_curious:bool=True, probe_policy:str|None=None) -> dict[str,Any]:
    if not 1<=seeds<=36:raise ValueError('seeds must be 1..36')
    policy = probe_policy if probe_policy is not None else ('curious' if use_curious else 'none')
    if policy not in ('curious','mechanism','random','none'):raise ValueError('Unknown experiment policy')
    results=[]
    for mech in mechanisms:
        if mech not in (*ALLOWED_MECHANISMS,*BENCHMARK_ONLY_UNMODELED):raise ValueError('Invalid benchmark mechanism')
        for seed in range(seeds):
            base=seed*1000 + 27
            tr=[simulate(base+i,mech,n=95) for i in range(5)]
            training=np.concatenate(tr)
            valid=np.concatenate([simulate(base+100+i,mech,n=95) for i in range(2)])
            test=np.concatenate([simulate(base+500+i,mech,n=95) for i in range(3)])
            models=fit_neural_ensemble(training)
            candidates=[{'x0':float(x),'v0':float(v),'u_bias':float(u)}
                       for x in (-.7,-.3,.3,.7) for v in (-.35,0,.35) for u in (-.3,.3)]
            chosen_probe=None
            if policy!='none':
                try:
                    chosen_probe=(choose_mechanism_probe(models,candidates,training,valid) if policy=='mechanism'
                                  else choose_safe_probe(models,candidates,training,policy=policy,random_seed=base))
                    # New experiment only. Explicitly no test access in the selection.
                    extra=simulate(base+200,mech,n=95,
                                   initial=(chosen_probe['x0'],chosen_probe['v0']),control_bias=chosen_probe['u_bias'])
                    training=np.concatenate((training,extra))
                    models=fit_neural_ensemble(training)
                except ValueError:pass  # Policy abstains from unsafe/OOD probes.
            search=neural_guided_symbolic_search(training,valid,models)
            numerical=search['chosen']['model']
            neural_pred=neural_forecasts(models,test).mean(axis=0)
            plain=fit_linear(training)
            methods={'physics':known_acceleration(*test[:,:3].T),
                     'generic_symbolic':predict_linear(plain,test),
                     'neural_ensemble':neural_pred,
                     'discovery_selected':predict_linear(numerical,test)}
            # Selection must be validation only; permit NN if validation wins by 2%.
            neural_val=error(valid[:,3],neural_forecasts(models,valid).mean(axis=0))
            symbolic_val=search['chosen']['val_rmse']
            selected='neural_ensemble' if neural_val<symbolic_val*.98 else 'discovery_selected'
            result={'mechanism':mech,'seed':seed,'selected_method':selected,
                    'chosen_symbolic_term':search['chosen']['term'],
                    'prospective_test_rmse':{k:error(test[:,3],p) for k,p in methods.items()},
                    'selected_test_rmse':error(test[:,3],methods[selected]),
                    'validation_rmse':{'neural':neural_val,'symbolic':symbolic_val},
                    'unexplained_residual_flag':search['unexplained_residual'],
                    'probe':chosen_probe,
                    'source':'synthetic_hidden_mechanism_no_ground_truth_given_to_learner'}
            results.append(result)
    summary={method:float(np.mean([r['prospective_test_rmse'][method] for r in results]))
             for method in ('physics','generic_symbolic','neural_ensemble','discovery_selected')}
    report={'version':'0.24','origin':'SYNTHETIC_MEASUREMENTS_ONLY','seeds':seeds,'mechanisms':list(mechanisms),
        'sample_count':len(results),'mean_prospective_rmse':summary,
        'mean_validation_selected_rmse':float(np.mean([r['selected_test_rmse'] for r in results])),
        'discovered_sine_cases':sum(r['chosen_symbolic_term']=='sin_affine' for r in results),
        'meta_used':False,'real_sensor_validation':False,'autonomous_actuation':False,
        'experiment_policy':policy,
        'method':'Neural ensemble + neural-guided nonlinear equation search + independent validation gate + optional curiosity-selected probe',
        'per_case':results}
    if out:
        path=Path(out);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(report,indent=2,allow_nan=False))
    return report


def main():
    parser=argparse.ArgumentParser(description='Physica v0.24 experimental curiosity-driven discovery; simulation only')
    parser.add_argument('--seeds',type=int,default=4)
    parser.add_argument('--out',default='demo/curious_discovery_v024.json')
    parser.add_argument('--without-curiosity',action='store_true')
    parser.add_argument('--experiment-policy',choices=('curious','mechanism','random','none'))
    a=parser.parse_args();result=benchmark(seeds=a.seeds,out=a.out,use_curious=not a.without_curiosity,probe_policy=a.experiment_policy)
    print(json.dumps({'report':a.out,'mean_test_rmse':result['mean_prospective_rmse'],
          'selected':result['mean_validation_selected_rmse'],'mechanisms':result['mechanisms']}))


# Additional optional experiment planner. Scientific novelty is NOT asserted:
# approximate D-optimal design is an established method.
def choose_mechanism_probe(models:list[Any],candidates:list[dict[str,float]],train:np.ndarray,
                           val:np.ndarray, *, max_distance:float=2.5)->dict[str,float]:
    """Target uncertainty reduction in learned sin-affine parameters when identifiable.

    Uses only training+validation and frozen model forecasts; does not simulate
    candidate outcomes with the hidden ground-truth law. If an interpretable
    mechanism cannot be identified, reverts to bounded ensemble curiosity.
    """
    train=check_rows(train);val=check_rows(val)
    discovered=neural_guided_symbolic_search(train,val,models)
    model=discovered['chosen']['model']
    if model.get('term')!='sin_affine':
        return choose_safe_probe(models,candidates,train,max_distance=max_distance)
    a,b=model['params']
    cs,cc=model['coefficients'][-2:]
    phi=a*train[:,0]+b*train[:,1]
    jac=(cs*np.cos(phi)-cc*np.sin(phi))[:,None]*train[:,:2]
    fisher=jac.T@jac/.012**2+np.eye(2)*.05
    det0=float(np.linalg.slogdet(fisher)[1])
    mu=np.mean(train[:,:3],axis=0);scales=np.std(train[:,:3],axis=0).clip(min=.12)
    scores=[]
    for candidate in candidates:
        x0,v0,u_bias=float(candidate['x0']),float(candidate['v0']),float(candidate['u_bias'])
        row=np.array([x0,v0,u_bias]);dist=np.linalg.norm((row-mu)/scales)
        if abs(x0)>.95 or abs(v0)>.55 or abs(u_bias)>.6 or dist>max_distance:continue
        x,v=x0,v0
        derivatives=[]
        # Deterministic nominal action plan, independent of future measurements.
        for t in range(80):
            u=float(u_bias+.35*np.sin(t*.061)+.22*np.cos(t*.037))
            test=np.array([[x,v,u,0.]])
            acc=float(predict_linear(model,test)[0])
            if not np.isfinite(acc) or abs(acc)>15 or abs(x)>5 or abs(v)>5:break
            angle=a*x+b*v
            g=cs*np.cos(angle)-cc*np.sin(angle)
            derivatives.append([g*x,g*v])
            v+=DT*acc;x+=DT*v
        if len(derivatives)<40:continue
        j=np.array(derivatives)
        utility=float(np.linalg.slogdet(fisher+j.T@j/.012**2)[1]-det0)
        scores.append((utility-.03*dist,candidate))
    if not scores:raise ValueError('No safe informative candidate for learned mechanism')
    return dict(max(scores,key=lambda kv:kv[0])[1])

if __name__=="__main__":
    main()
