"""General evidence-driven inquiry for printer, turbine and F1.

One *process* across different physical systems, not one universal dynamical law.
The numerical planner consumes hypotheses supplied with predictive distributions;
it does not invent them. Human or Muse proposals remain unverified until tested.
"""
from __future__ import annotations
import math
from dataclasses import asdict
from typing import Mapping
import numpy as np

from .schema import FeltExperience, EvidenceError
from .uncertainty_v029 import NormalResidualEnvelope

DOMAIN_MEASUREMENTS = {
    'printer': [
        {'id':'repeat_standardized_move', 'kind':'controlled_observation',
         'instruction':'Repeat the same safe approved motion with camera stationary; compare ringing at the same frequency',
         'requires_review':True},
        {'id':'independent_acceleration', 'kind':'additional_sensor',
         'instruction':'If available, record calibrated acceleration and synchronize it with the video and G-code',
         'requires_review':True},
    ],
    'turbine': [
        {'id':'independent_blade_inspection', 'kind':'qualified_inspection',
         'instruction':'Have qualified personnel inspect the parked blade and review SCADA alarms and maintenance records',
         'requires_review':True},
        {'id':'additional_passive_measurements','kind':'passive_observation',
         'instruction':'Acquire independent passive vibration, temperature and operating-condition records under approved procedures',
         'requires_review':True},
    ],
    'f1': [
        {'id':'matched_lap_telemetry','kind':'controlled_observation',
         'instruction':'Compare matched telemetry with tyre, fuel, conditions and driver inputs controlled as much as practical',
         'requires_review':True},
        {'id':'independent_aero_measurement','kind':'additional_sensor',
         'instruction':'Request independently measured tyre/vehicle and aerodynamic data to distinguish drag, grip and load effects',
         'requires_review':True},
    ],
}


def choose_probe(candidates: list[dict], *, probability: list[float] | None = None,
                 samples: int = 1200, seed: int = 0) -> dict:
    """Approximate expected hypothesis information gain of safe observation proposals.

    Each candidate has predictions from the SAME distinct hypotheses:
    `means` (one scalar per H), `sigma` calibrated likelihood spread, `cost`,
    `risk`, `approved` and `action` metadata. This is a model-dependent
    computational ranking, NOT a physically verified intervention value.
    """
    if not candidates: return {'status':'ABSTAIN_NO_CANDIDATES','selected':None,'scores':[]}
    n = len(candidates[0].get('means',[]))
    if n<2: return {'status':'ABSTAIN_INSUFFICIENT_RIVAL_HYPOTHESES','selected':None,'scores':[]}
    priors=np.asarray(probability if probability is not None else [1/n]*n,dtype=float)
    if len(priors)!=n or not np.all(np.isfinite(priors)) or np.any(priors<0) or priors.sum()<=0:
        raise EvidenceError('Invalid hypothesis prior')
    priors=priors/priors.sum()
    rng=np.random.default_rng(seed)
    out=[]
    for i,c in enumerate(candidates):
        if not c.get('approved') or c.get('actuates_hardware'):
            out.append({'id':c.get('id',str(i)), 'status':'REFUSED_UNAPPROVED_OR_ACTUATION'});continue
        means=np.asarray(c.get('means',[]),dtype=float)
        sigma=c.get('sigma')
        discrepancy=c.get('model_discrepancy_sigma', 0.)
        cost=c.get('cost',0.)
        risk=c.get('risk',0.)
        if (len(means)!=n or not np.all(np.isfinite(means)) or
            not isinstance(sigma,(int,float)) or not math.isfinite(sigma) or sigma<=0 or
            not isinstance(discrepancy,(int,float)) or not math.isfinite(discrepancy) or discrepancy<0 or
            not all(isinstance(x,(int,float)) and math.isfinite(x) and x>=0 for x in (cost,risk))):
            out.append({'id':c.get('id',str(i)),'status':'REFUSED_UNCALIBRATED_LIKELIHOOD'});continue
        # Inflate predicted likelihood uncertainty using externally estimated model
        # discrepancy. Unsupported rival models should NOT be treated as precise.
        sigma=math.hypot(sigma, discrepancy)
        # Draw y from the hypothesized mixture; approximate posterior H|y.
        h=rng.choice(n,size=samples,p=priors)
        y=rng.normal(means[h],sigma,size=samples)
        loglik=-0.5*((y[:,None]-means[None,:])/sigma)**2+np.log(np.maximum(priors[None,:],1e-300))
        loglik-=loglik.max(axis=1,keepdims=True)
        weights=np.exp(loglik); weights/=weights.sum(axis=1,keepdims=True)
        prior_entropy=-float(np.sum(priors*np.log(np.maximum(priors,1e-300))))
        posterior_entropy=-np.sum(weights*np.log(np.maximum(weights,1e-300)),axis=1).mean()
        info_gain=max(0.,float(prior_entropy-posterior_entropy))
        score=info_gain-.05*float(cost)-.1*float(risk)
        out.append({'id':c.get('id',str(i)), 'status':'CANDIDATE_REVIEW_ONLY',
             'expected_information_gain_nats':round(info_gain,6),
             'score':round(score,6),'risk':risk,'cost':cost,
             'requires_human_approval':True,
             'effective_sigma':round(float(sigma),6),
             'model_discrepancy_included':bool(discrepancy)})
    choices=[x for x in out if x['status']=='CANDIDATE_REVIEW_ONLY']
    best=max(choices,key=lambda x:x['score']) if choices else None
    return {'status':'RANKED_FOR_HUMAN_REVIEW' if best else 'ABSTAIN_NO_SAFE_CALIBRATED_PROBE',
            'selected': best['id'] if best else None,'scores':out,
            'predictions_are_proposals_not_measured_experiment_results':True,
            'no_hardware_execution':True}


def investigate(experience: FeltExperience, *, candidate_probes: list[dict] | None = None,
                hypotheses: list[dict] | None = None, trigger_z: float = 3.0,
                normal_envelopes: dict[str, NormalResidualEnvelope] | None = None,
                operating_context: dict[str, float] | None = None) -> dict:
    if not (1 <= trigger_z <= 12):raise EvidenceError('Invalid discovery threshold')
    signals=[c.innovation() for c in experience.comparisons]
    credible=[x for x in signals if x['calibrated']]
    # Evaluate against prediction + observation noise, never a bare model residual.
    surprise=max((x['standardized_surprise_z'] for x in credible),default=None)
    status=('changed' if surprise is not None and surprise>=trigger_z else
            'no_detected_change' if surprise is not None else 'cant_tell')
    calibration_decisions=[]
    if normal_envelopes is not None:
        # In evidence-first mode every comparison needs a matching independently
        # calibrated normal envelope. Missing or out-of-envelope evidence abstains.
        for signal in signals:
            envelope=normal_envelopes.get(signal['quantity'])
            if envelope and (envelope.calibration_run_sha256 == experience.provenance.get('raw_recording_sha256')):
                decision={'status':'ABSTAIN_CALIBRATION_DATA_REUSE','threshold':None}
            else:
                decision=(envelope.evaluate(signal,operating_context=operating_context)
                          if envelope else {'status':'ABSTAIN_MISSING_NORMAL_ENVELOPE'})
            calibration_decisions.append({'quantity':signal['quantity'], **decision})
        if not calibration_decisions or any(x['status'].startswith('ABSTAIN') for x in calibration_decisions):
            status='cant_tell'
            surprise=None
        else:
            status=('changed' if any(x['status']=='ANOMALY_CANDIDATE' for x in calibration_decisions)
                    else 'no_detected_change')
    # Conservatively surface anomaly suspicion, but do not recast an uncalibrated
    # classification as an independently measured z-score.
    suspected=experience.domain_verdict in {'suspected_structural_damage','possible_ice',
      'ringing_not_reduced'}
    if status=='cant_tell' and suspected:status='suspected_change_needs_verification'
    if experience.domain=='turbine':
        action='STOP_OR_KEEP_OUT_OF_SERVICE_PENDING_QUALIFIED_SITE_DECISION'
    else:
        action='REVIEW_ONLY_NO_AUTOMATIC_MACHINE_CONTROL'
    plans=DOMAIN_MEASUREMENTS[experience.domain]
    selected=choose_probe(candidate_probes or []) if candidate_probes else {
        'status':'ABSTAIN_NO_CALIBRATED_RIVAL_PREDICTIONS', 'selected':None,
        'scores':[],'no_hardware_execution':True}
    allowed_hypotheses=[]
    for h in hypotheses or []:
        if isinstance(h,dict) and h.get('name') and h.get('claim'):
            allowed_hypotheses.append({'name':str(h['name'])[:128],
                                       'claim':str(h['claim'])[:500],
                                       'status':'UNVERIFIED_CANDIDATE'})
    return {
        'schema':'physica.felt_investigation.v028',
        'domain':experience.domain, 'system_id':experience.system_id,
        'evidence_split':experience.evidence_split,
        'dataset_origin':experience.dataset_origin,
        'physical_feeling_definition':'predicted_vs_observed_sensor_response_not_subjective_awareness',
        'felt_experience':experience.as_dict(),
        'sensory_innovations':signals,
        'evidence_status':status,
        'max_calibrated_surprise_z':surprise,
        'normal_envelope_decisions':calibration_decisions,
        'formal_false_alarm_guarantee_claimed':False,
        'legacy_domain_verdict_not_proof':experience.domain_verdict,
        'science_stage':'INVESTIGATE_UNEXPLAINED_CHANGE' if status in ('changed','suspected_change_needs_verification')
                         else 'MEASURE_MORE' if status=='cant_tell' else 'MONITOR_BASELINE',
        'candidate_mechanisms':allowed_hypotheses,
        'next_evidence_options':plans,
        'target_specific_probe_ranking':selected,
        'safety_instruction':action,
        'mechanism_discovered':False,
        'physical_outcome_verified':False,
        'cross_machine_transfer_verified':False,
        'meta_provenance':'NOT_CALLED',
        'no_automatic_hardware_actuation':True,
    }
