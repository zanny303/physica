"""Tune a 3D printer by filming it: no sensor on the printer.

1. Physica writes an excitation G-code: sharp moves with pauses; every stop makes the print head ring.
2. You film the print head with a phone in slow motion (on a stand, not in your hand).
3. The printer's own commands are the clock: the G-code fixes how long each move-and-pause cycle takes, so the
   video's true frame rate is read from the video itself (phone slow-motion files often store the wrong rate).
4. In every pause the Touch Transform feels the ringing from pixels: frequency and damping, with a spread across
   pauses. Physica writes Marlin M593 and Klipper [input_shaper], and promises how much ringing will be left.
5. You turn the shaper on, film the same G-code again, and Physica re-feels: kept if the ringing dropped as
   promised, rolled back if not.
"""
from __future__ import annotations

import numpy as np

from physica.act import contract
from physica.experiment import printer as P
from physica.touch import video
from physica.touch.transform import TouchTransform
from physica.translate import gcode

EXCITE = dict(travel=20.0, feed=12000, accel=3000, pause_ms=700, repeats=10)


def move_time(travel: float, feed: float, accel: float) -> float:
    """Trapezoid (or triangle) move time for a firmware with constant acceleration."""
    v = feed / 60.0
    d_acc = v * v / accel
    if d_acc >= travel:
        return 2 * np.sqrt(travel / accel)
    return 2 * v / accel + (travel - d_acc) / v


def cycle_s(p: dict = EXCITE) -> float:
    return 2 * (move_time(p["travel"], p["feed"], p["accel"]) + p["pause_ms"] / 1000.0)


def griffin_header(sliced_gcode: str) -> list[str]:
    """Newer Ultimakers need a header naming the machine. Copy it from a file Cura sliced for that exact printer, with
    temperatures set to zero, because this test motion prints nothing and needs no heat."""
    lines = sliced_gcode.splitlines()
    try:
        start, end = lines.index(";START_OF_HEADER"), lines.index(";END_OF_HEADER")
    except ValueError:
        raise ValueError("that file has no Griffin header: slice any small object in Cura for your exact printer, and save it to a file") from None
    out = []
    for ln in lines[start:end + 1]:
        out.append(ln.split(":")[0] + ":0" if "TEMPERATURE" in ln and ln.startswith(";") and ":" in ln else ln)
    return out


def excite_gcode(axis: str = "X", p: dict = EXCITE, header: list[str] | None = None) -> str:
    code = P.excite_gcode(axis, travel=p["travel"], feed=int(p["feed"]), accel=int(p["accel"]), repeats=p["repeats"],
                          pause_ms=p["pause_ms"]).splitlines()
    head = ["; Physica test motion, for filming. No print, no heat, nothing on the bed. Phone on a tripod, in slow motion.",
            "; Start filming BEFORE you run this. Review it first and stay with the printer. Advice, not a safety certification."]
    body = [ln for ln in code if not ln.startswith(";")]
    if header:      # these printers run their own homing and ending routines around every file
        # Griffin takes M204 S for printing moves and T for travel, and these moves don't extrude, so set both.
        body = [f"M204 S{int(p['accel'])} T{int(p['accel'])}" if ln.startswith("M204") else ln for ln in body if ln not in ("G28", "M84")]
        return "\n".join(header + head + body) + "\n"
    return "\n".join(head + body) + "\n"


def frame_energy(V: np.ndarray) -> np.ndarray:
    from scipy.ndimage import median_filter

    d = np.abs(np.diff(V, axis=0)).mean((1, 2))
    # Compressed video has a one-frame spike at every keyframe. Left in, those spikes set the motion threshold and fake
    # a rhythm for the clock, so remove them. A real move lasts many frames and survives this.
    return median_filter(np.concatenate([[d[0]], d]), size=5, mode="nearest")


def video_clock(V: np.ndarray, p: dict = EXCITE) -> dict:
    """Frames per real second, from the G-code's own rhythm (autocorrelation of frame-to-frame change)."""
    e = frame_energy(V)
    e = e - e.mean()
    ac = np.correlate(e, e, "full")[len(e) - 1:]
    if not np.isfinite(ac[0]) or ac[0] <= 1e-14:
        raise ValueError('No detectable motion rhythm; cannot calibrate printer video clock')
    ac /= ac[0]
    lo = 10
    k = lo + int(np.argmax(ac[lo:len(e) // 2]))
    # sub-frame peak (parabola through the three samples around the peak)
    if 1 <= k < len(ac) - 1:
        a, b, c = ac[k - 1], ac[k], ac[k + 1]
        k = k + 0.5 * (a - c) / (a - 2 * b + c + 1e-12)
    # moving left and moving right look the same in frame-to-frame change, so the rhythm the video shows is one
    # move plus one pause: half of the G-code's back-and-forth cycle
    half = cycle_s(p) / 2
    return {"fps": float(k / half), "period_frames": float(k), "seconds_per_period": half}


def _drop_short_runs(mask: np.ndarray, shortest: int) -> np.ndarray:
    """Clear every run of True shorter than `shortest` samples."""
    out = mask.copy()
    edges = np.flatnonzero(np.diff(np.concatenate([[0], mask.astype(np.int8), [0]])))
    for start, end in zip(edges[::2], edges[1::2]):
        if end - start < shortest:
            out[start:end] = False
    return out


def pauses(V: np.ndarray, fps: float, p: dict = EXCITE, ring_s: float = 0.35) -> list[slice]:
    """Windows just after each stop: the head is still except for its ringing."""
    e = frame_energy(V)
    w = max(int(0.01 * fps), 1)
    e = np.convolve(e, np.ones(w) / w, "same")
    moving = e > (np.quantile(e, 0.5) + 0.25 * (e.max() - np.quantile(e, 0.5)))
    # Compressed phone video flickers: keyframes look like one-frame moves, and moves break up into pieces. A real move
    # lasts a known time, so fill gaps and drop runs much shorter than it. Otherwise noise counts as extra "stops".
    shortest = max(int(0.4 * move_time(p["travel"], p["feed"], p["accel"]) * fps), 2)
    moving = _drop_short_runs(~_drop_short_runs(~moving, shortest), shortest)
    stops = [i for i in range(1, len(moving)) if moving[i - 1] and not moving[i]]
    out = []
    for s in stops:
        a, b = s + max(int(0.004 * fps), 1), s + int(ring_s * fps)
        if b < len(V):
            out.append(slice(a, b))
    return out


def ringing_amp(Y: np.ndarray, fps: float, f: float, first_s: float = 0.2) -> float:
    """Ringing at frequency f only (band-limited around it), in the first moments after a stop: camera noise and
    slow drift fall outside the band, so 'no ringing' really reads near zero."""
    from scipy.signal import butter, sosfiltfilt

    u, sv, vt = np.linalg.svd(Y - Y.mean(0), full_matrices=False)
    x = u[:, 0] * sv[0] / np.sqrt(Y.shape[1])
    lo, hi = 0.8 * f / (fps / 2), min(1.2 * f / (fps / 2), 0.99)
    sos = butter(2, [lo, hi], btype="band", output="sos")
    xb = sosfiltfilt(sos, x, padlen=min(len(x) - 1, 3 * max(len(sos) * 2, 1)))
    n = max(int(first_s * fps), 4)
    return float(np.sqrt(np.mean(xb[:n] ** 2)))


def feel_ringing(V: np.ndarray, fps: float, p: dict = EXCITE, band=(10.0, None), at_hz: float | None = None) -> dict:
    """Frequency and damping of the print head's ringing, felt in every pause. With at_hz, also how strongly it
    rings at that frequency (used to compare before and after a fix at the same frequency)."""
    est, amps, motion_windows = [], [], []
    for w in pauses(V, fps, p):
        seg = V[w]
        mo = video.motion(seg, wavelength=6, sigma=2.5, step=2, keep=0.15, direction="horizontal")
        Y = mo["signals"]
        if Y.shape[0] < 20:
            continue
        motion_windows.append(Y)
        tt = TouchTransform(fps, n_modes=1, band=(band[0], band[1] or 0.45 * fps), order=8, space_rank=4,
                            max_damping=0.3).fit(Y)
        if tt.modes:
            m = tt.modes[0]
            est.append((m.freq_hz, m.damping))
            amps.append(ringing_amp(Y, fps, at_hz or m.freq_hz))
        elif at_hz:
            amps.append(ringing_amp(Y, fps, at_hz))
    if not amps:
        return {"windows": 0}
    # All video windows must be measured at the SAME reference frequency.
    # Previously, baseline used each window's local peak but the after video
    # used a fixed before-frequency. Their amplitude ratio was not comparable.
    if at_hz is None and est:
        reference_hz = float(np.median([a for a, _ in est]))
        amps = [ringing_amp(y, fps, reference_hz) for y in motion_windows]
    out = {"windows": len(amps), "ringing_px": float(np.median(amps)),
           "ringing_amplitude_reference_hz": float(at_hz if at_hz is not None else reference_hz),
           "window_amplitudes_px": [float(v) for v in amps]}
    if est:
        f, z = (np.array(v) for v in zip(*est))
        out.update(freq_hz=float(np.median(f)), freq_iqr=[float(np.quantile(f, 0.25)), float(np.quantile(f, 0.75))],
                   damping=float(np.median(z)))
    return out


def tune(V: np.ndarray, axis: str = "X", p: dict = EXCITE, fps_hint: float | None = None) -> dict:
    clock = video_clock(V, p)
    fps = clock["fps"]
    r = feel_ringing(V, fps, p)
    if not r.get("windows") or "freq_hz" not in r:
        return {"clock": clock, "error": "no ringing found in the pauses: film closer, on a stand, in slow motion"}
    f, z = r["freq_hz"], float(np.clip(r["damping"], 0.01, 0.3))
    left = P.zv_residual(f, z, f, z)
    lines = gcode.marlin_m593(f, z, axes=axis.upper())
    out = {"clock": clock, "fps_hint": fps_hint, "felt": r, "marlin": lines,
           "klipper": f"[input_shaper]\nshaper_freq_{axis.lower()}: {f:.1f}\nshaper_type_{axis.lower()}: zv\n",
           "predicted_ringing_left": left}
    out["promise"] = contract.promise(" ".join(lines), f"With the shaper on, ringing on {axis.upper()} after each stop "
                                      f"drops by at least half (Physica predicts {100 * (1 - left):.0f}% if the mode is as felt).",
                                      [{"metric": "ringing_drop_fraction", "op": ">=", "value": 0.5, "say": "ringing drops >= 50%"}])
    return out


def check(before: dict, V_after: np.ndarray, p: dict = EXCITE) -> dict:
    """Re-measure rather than trust an assumed after-video frame clock.

    Uses window-to-window bootstrap intervals for exploratory relative ringing
    change. Optical noise and shared scene effects may still dominate; results
    remain advisory and are not calibrated displacement or verified print quality.
    """
    before_fps=float(before['clock']['fps'])
    if p["accel"] != EXCITE["accel"]:   # gentler moves blur the rhythm the clock reads, and it's the same phone and setting
        after_clock = {"fps": before_fps, "from": "the before film, same camera setting"}
    else:
        try:
            after_clock = video_clock(V_after, p)
        except (ValueError, IndexError, ZeroDivisionError):
            return {"status": "CANT_TELL", "reason": "No measurable reference motion in after video"}
    after_fps=float(after_clock['fps'])
    if not np.isfinite(after_fps) or abs(after_fps-before_fps)/max(before_fps,1e-9)>0.15:
        return {"status":"CANT_TELL","reason":"Before/after video clock differs; reshoot identical G-code",
                "after_clock":after_clock}
    r=feel_ringing(V_after,after_fps,p,at_hz=before['felt']['freq_hz'])
    a=float(r.get('ringing_px',float('nan')))
    b=float(before['felt'].get('ringing_px',float('nan')))
    if not np.isfinite(a) or not np.isfinite(b) or b<=1e-12:
        return {"status":"CANT_TELL","reason":"Insufficient before/after ringing energy",
                "after":r,"after_clock":after_clock}
    drop=1-a/b
    result={"after":r,"after_clock":after_clock,"ringing_drop_fraction":float(drop),
            "judgement":contract.judge(before['promise'],{"ringing_drop_fraction":drop}),
            "status":"BEFORE_AFTER_MEASURED_REVIEW_ONLY",
            "measurement_interpretation":"POINT_ESTIMATE_ONLY",
            "compare_frequency_hz":float(before['felt']['freq_hz']),
            "important_limit":"Video pixel features need matched crop, lighting, video timing and camera fixation; not a direct quality or force measurement"}
    bb=np.asarray(before['felt'].get('window_amplitudes_px',[]),float)
    aa=np.asarray(r.get('window_amplitudes_px',[]),float)
    if len(bb)>=4 and len(aa)>=4 and np.isfinite(bb).all() and np.isfinite(aa).all() and min(bb)>0:
        rng=np.random.default_rng(1128)
        samples=[]
        for _ in range(1000):
            bmed=float(np.median(rng.choice(bb,len(bb),replace=True)))
            amed=float(np.median(rng.choice(aa,len(aa),replace=True)))
            if bmed>1e-12:samples.append(1-amed/bmed)
        if samples:
            result['ringing_drop_interval_95_exploratory']=[float(x) for x in np.quantile(samples,[.025,.975])]
            result['uncertainty_limit']='Within-video windows are correlated; interval is exploratory, not guaranteed coverage'
            lo,hi=result['ringing_drop_interval_95_exploratory']
            result['measurement_interpretation']=('CHANGE_DETECTED_REDUCTION' if lo>0 else
                'CHANGE_DETECTED_INCREASE' if hi<0 else 'CHANGE_NOT_ESTABLISHED')
            # A point estimate alone does not warrant a promise-kept claim.
            if lo <= 0:
                result['scientific_verdict']='EVIDENCE_INSUFFICIENT_FOR_IMPROVEMENT'
            elif lo < 0.5:
                result['scientific_verdict']='REDUCTION_DETECTED_BUT_50_PERCENT_GOAL_UNCERTAIN'
            else:
                result['scientific_verdict']='EXPLORATORY_INTERVAL_SUPPORTS_TARGET'
    if result['measurement_interpretation']=='POINT_ESTIMATE_ONLY':
        result['scientific_verdict']='EVIDENCE_INSUFFICIENT_FOR_IMPROVEMENT'
    return result
