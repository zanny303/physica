"""Bounded, non-executable mechanism proposals for Meta-assisted equation discovery.

Features are dimensionless because x, v and u are normalized using declared SI
reference scales. The learned output coefficient has units of acceleration.
An LLM-proposed expression is ALWAYS an unverified candidate basis, never evidence.
"""
from __future__ import annotations
import json
import numpy as np

VAR_CHANNELS={'x':'x_m','v':'v_m_s','u':'u_m_s2'}
MAX_NODES=31
MAX_DEPTH=6
SCALES={'x':1.0,'v':1.0,'u':1.0}  # physical SI reference units


def validate(expr:dict, *, _depth:int=0, _budget:list[int]|None=None) -> dict:
    if _budget is None:
        _budget=[MAX_NODES]
    _budget[0]-=1
    if _budget[0]<0 or _depth>MAX_DEPTH or not isinstance(expr,dict):
        raise ValueError('Expression complexity or type invalid')
    op=expr.get('op')
    if op in VAR_CHANNELS:
        if set(expr)!={'op'}:raise ValueError('Invalid variable leaf')
    elif op=='const':
        if set(expr)!={'op','value'} or isinstance(expr['value'],bool) or not isinstance(expr['value'],(int,float)) or not np.isfinite(expr['value']) or abs(expr['value'])>8:
            raise ValueError('Invalid physical constant')
    elif op in ('sin','cos','tanh','abs','neg','square','cube'):
        if set(expr)!={'op','arg'}:raise ValueError('Invalid unary expression')
        validate(expr['arg'],_depth=_depth+1,_budget=_budget)
    elif op in ('add','mul'):
        if set(expr)!={'op','args'} or not isinstance(expr['args'],list) or len(expr['args'])!=2:
            raise ValueError('Binary expression requires two arguments')
        for child in expr['args']:validate(child,_depth=_depth+1,_budget=_budget)
    else:
        raise ValueError('Disallowed operation; no generated code execution')
    return expr


def feature(rows:np.ndarray, expr:dict) -> np.ndarray:
    validate(expr)
    rows=np.asarray(rows,dtype=float)
    if rows.ndim != 2 or rows.shape[1]<3 or not np.isfinite(rows[:,:3]).all():raise ValueError('Malformed measured sensor rows')
    def eval_node(node):
        op=node['op']
        if op in VAR_CHANNELS:return rows[:,{'x':0,'v':1,'u':2}[op]]/SCALES[op]
        if op=='const':return np.full(len(rows),float(node['value']))
        if op in ('add','mul'):
            a,b=map(eval_node,node['args'])
            return a+b if op=='add' else a*b
        x=eval_node(node['arg'])
        if op=='sin':return np.sin(x)
        if op=='cos':return np.cos(x)
        if op=='tanh':return np.tanh(x)
        if op=='abs':return np.abs(x)
        if op=='neg':return -x
        if op=='square':return x*x
        if op=='cube':return x*x*x
        raise ValueError('Unreachable invalid operation')
    result=eval_node(expr)
    if result.shape!=(len(rows),) or not np.isfinite(result).all() or np.max(np.abs(result))>1e5:
        raise ValueError('Invalid physical feature values')
    return result


def validate_meta_mechanism(proposal:dict) -> dict:
    required={'name','expression','hypothesis','falsification_test','measured_channels'}
    if not isinstance(proposal,dict) or set(proposal)!=required:
        raise ValueError('Meta mechanism must have exact schema')
    if any(not isinstance(proposal[k],str) or not proposal[k].strip() or len(proposal[k])>500
           for k in ('name','hypothesis','falsification_test')):
        raise ValueError('Invalid proposal narrative')
    channels=proposal['measured_channels']
    if not isinstance(channels,list) or any(c not in (*VAR_CHANNELS.values(),'acc_m_s2') for c in channels):
        raise ValueError('Unsupported or invented measurements')
    validate(proposal['expression'])
    return dict(proposal,status='PROPOSED_NOT_VERIFIED',can_execute_hardware=False)


def meta_response_schema()->dict:
    """Meta strict JSON-schema top-level; nested AST is safely parsed locally.

    Encoding the AST as a JSON string sidesteps unsupported recursive schemas
    without trusting the model's generated operators or depth.
    """
    props={'name':{'type':'string'},'hypothesis':{'type':'string'},
           'falsification_test':{'type':'string'},
           'measured_channels':{'type':'array','items':{'type':'string'}},
           'expression_json':{'type':'string'}}
    return {'type':'json_schema','json_schema':{'name':'PhysicaMechanismV024',
            'strict':True,'schema':{'type':'object','additionalProperties':False,
             'properties':props,'required':list(props)}}}


def fit_and_test_meta_candidate(train:np.ndarray,val:np.ndarray, proposal:dict, *, threshold:float=.98)->dict:
    from physica.frontier.curious_discovery import check_rows,generic_basis,residual,error,predict_linear,fit_linear,known_acceleration
    validate_meta_mechanism(proposal)
    train,val=check_rows(train),check_rows(val)
    phi_tr=feature(train,proposal['expression'])
    phi_val=feature(val,proposal['expression'])
    X=np.column_stack((np.ones(len(train)),generic_basis(train),phi_tr))
    y=residual(train); ridge=np.eye(X.shape[1])*.04;ridge[0,0]=0
    coef=np.linalg.solve(X.T@X+ridge,X.T@y)
    V=np.column_stack((np.ones(len(val)),generic_basis(val),phi_val))
    predicted=known_acceleration(*val[:,:3].T)+V@coef
    candidate_err=error(val[:,3],predicted)
    baseline=fit_linear(train)
    base_err=error(val[:,3],predict_linear(baseline,val))
    return {'status':'SUPPORTED_ON_VALIDATION_NOT_YET_PROSPECTIVELY_VERIFIED' if candidate_err<base_err*threshold else 'REJECTED_OR_UNINFORMATIVE',
            'candidate_validation_rmse':candidate_err,'baseline_validation_rmse':base_err,
            'improvement_fraction':1-candidate_err/base_err if base_err else 0.,
            'derived_acceleration_coefficient':float(coef[-1]),'proposal_name':proposal['name'],
            'meta_proposed_not_measured':True,'can_execute_hardware':False}


def live_nominate(evidence_summary:dict, *, allow_billed_meta:bool=False)->dict:
    import os
    if not allow_billed_meta:raise PermissionError('Explicit permission required before paid Meta calls')
    if os.getenv('MOCK','1')!='0' or not os.getenv('MODEL_API_KEY'):
        raise PermissionError('A real MODEL_API_KEY and MOCK=0 are required; mocks are not scientific evidence')
    from physica.llm.meta_client import complete
    schema_instruction='''Suggest ONE missing mathematical relationship using a tiny safe JSON AST with op types
    x,v,u,const,add,mul,sin,cos,tanh,abs,neg,square,cube. Use nested objects, e.g.
    {"op":"sin","arg":{"op":"add","args":[{"op":"mul","args":[{"op":"const","value":2.2},{"op":"x"}]},{"op":"v"}]}}.
    x [m],v [m/s],u [m/s²] are separately normalized to unit references and AST output is dimensionless.
    Output exact keys name, expression_json, hypothesis, falsification_test, measured_channels.
    expression_json is a STRING containing valid JSON of your bounded AST, not executable code.
    Only measured channels may be cited. All proposals are UNVERIFIED and require independent experiments.'''
    result=complete('wonder',[{'role':'system','content':schema_instruction},
          {'role':'user','content':json.dumps(evidence_summary,allow_nan=False,sort_keys=True)}],
          'physica_v024_scientific_ast',response_format=meta_response_schema(),max_completion_tokens=900)
    if result.get('mode') not in ('live','replay of live'):
        raise RuntimeError('No authenticated Meta proposal was executed')
    payload=json.loads(result['content'])
    if not isinstance(payload,dict) or 'expression_json' not in payload:
        raise ValueError('Meta response lacks required encoded safe mathematical AST')
    payload['expression']=json.loads(payload.pop('expression_json'))
    proposal=validate_meta_mechanism(payload)
    return {'status':'LIVE_META_UNVERIFIED_HYPOTHESIS','proposal':proposal,'mode':result['mode'],
            'model':result.get('model'),'hardware_controls':'PROHIBITED'}


def main():
    from pathlib import Path
    import argparse
    p=argparse.ArgumentParser(description='Live Meta mechanisms stay unverified until validated numerically')
    p.add_argument('--context',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--allow-billed-meta',action='store_true')
    a=p.parse_args()
    context=json.loads(Path(a.context).read_text(encoding='utf8'))
    result=live_nominate(context,allow_billed_meta=a.allow_billed_meta)
    out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    # The local field pipeline consumes an exact proposal with NO provenance claims.
    proposal=dict(result['proposal']);proposal.pop('status',None);proposal.pop('can_execute_hardware',None)
    out.write_text(json.dumps(proposal,indent=2,allow_nan=False))
    out.with_suffix('.meta_receipt.json').write_text(json.dumps({k:v for k,v in result.items() if k!='proposal'},indent=2))
    print(json.dumps({'status':result['status'],'out':str(out),'model':result['model']}))

if __name__=='__main__':main()
