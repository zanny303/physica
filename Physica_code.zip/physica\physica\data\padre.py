"""Loader for PADRE (Propeller Anomaly Data REpository), Parrot Bebop 2 raw IMU data.

Source: https://github.com/AeroLabPUT/UAV_measurement_data  (see DATA.md)

Format (from the dataset's Raw_data/Readme.txt):
  file  Bebop2_16g_1kdps_raw_ABCD.csv, one digit per rotor A,B,C,D:
        0 no fault, 1 chipped edge, 2 bent tip, 3 cut off tip, 4 bent tip + cut off tip
  line  96 hex chars = 48 bytes = 24 big-endian int16 registers:
        for arm A, B, C, D: acc_x, acc_y, acc_z, gyro_x, gyro_y, gyro_z
  rate  500 samples per second; ranges +/-16 g and +/-1000 deg/s (from the file name)
Rotor layout from the README diagram:   C   A   (front)
                                          \\ /
                                          / \\
                                         D   B   (rear)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from physica import config

FS = 500.0
ROTORS = "ABCD"
# x: +right / -left, y: +front / -rear
LAYOUT = {"A": (1, 1), "B": (1, -1), "C": (-1, 1), "D": (-1, -1)}
FAULT_TYPES = {0: "ok", 1: "chipped edge", 2: "bent tip", 3: "cut-off tip", 4: "bent tip + cut-off tip"}
ACC_LSB = 16 * 9.80665 / 32768.0  # m/s^2 per count (+/-16 g, 16 bit)
GYRO_LSB = 1000.0 / 32768.0  # deg/s per count (+/-1000 dps, 16 bit)


@dataclass
class Recording:
    code: str
    acc: np.ndarray  # (N, 4, 3) m/s^2, arms A..D
    gyro: np.ndarray  # (N, 4, 3) deg/s
    fs: float = FS
    meta: dict = field(default_factory=dict)

    @property
    def duration_s(self) -> float:
        return self.acc.shape[0] / self.fs

    def faults(self) -> dict[str, str]:
        return fault_map(self.code)


def raw_dir(root: Path | None = None) -> Path:
    root = Path(root) if root else config.padre_dir()
    return root / "Parrot_Bebop_2" / "Raw_data"


def available_codes(root: Path | None = None) -> list[str]:
    return sorted(p.stem.split("_")[-1] for p in raw_dir(root).glob("Bebop2_16g_1kdps_raw_*.csv"))


def fault_map(code: str) -> dict[str, str]:
    if len(code) != 4 or not code.isdigit():
        raise ValueError(f"bad PADRE code {code!r}")
    return {r: FAULT_TYPES[int(c)] for r, c in zip(ROTORS, code)}


def damaged_rotors(code: str) -> list[str]:
    return [r for r, c in zip(ROTORS, code) if c != "0"]


def parse_lines(lines) -> np.ndarray:
    """Parse hex lines into an (N, 24) int16 array. Lines that are not 96 hex chars are skipped."""
    rows = []
    for line in lines:
        s = line.strip()
        if len(s) == 96:
            rows.append(bytes.fromhex(s))
    if not rows:
        return np.zeros((0, 24), dtype=np.int16)
    return np.frombuffer(b"".join(rows), dtype=">i2").reshape(-1, 24).astype(np.int16)


def load(code: str, root: Path | None = None, use_cache: bool = True) -> Recording:
    cache = config.REPO_ROOT / ".cache" / "padre" / f"{code}.npy"
    if use_cache and cache.exists():
        raw = np.load(cache)
    else:
        path = raw_dir(root) / f"Bebop2_16g_1kdps_raw_{code}.csv"
        with open(path) as f:
            raw = parse_lines(f)
        if use_cache:
            cache.parent.mkdir(parents=True, exist_ok=True)
            np.save(cache, raw)
    regs = raw.astype(float).reshape(-1, 4, 6)
    return Recording(code=code, acc=regs[:, :, :3] * ACC_LSB, gyro=regs[:, :, 3:] * GYRO_LSB,
                     meta={"source": "PADRE Parrot Bebop 2", "faults": fault_map(code)})


def windows(n_samples: int, fs: float = FS, seconds: float = 5.0) -> list[tuple[int, int]]:
    w = int(round(seconds * fs))
    return [(s, s + w) for s in range(0, n_samples - w + 1, w)]
