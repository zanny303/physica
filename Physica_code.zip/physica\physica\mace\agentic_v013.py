"""Physica v0.13: bounded agentic mechanism search + prospective transfer.

Scientific scope: controlled numerical experiments with explicit source/target
state calibration. Search is over finite interpretable equations, not unrestricted
scientific discovery. Target test outcomes are not read until a forecast receipt
has been signed and written. Local signatures do not prove external chronology.
"""
from __future__ import annotations
import argparse
import hashlib
import html
import json
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
from .mechanisms import BASE, CANDIDATES, design, fit, score, predict, validate_term
from .unknown_physics import generate, residual_diagnostics, _episodes
from .simulation import roll, plan, forecast_without_truth
from physica.library.sign import sign, verify

THERMAL = CANDIDATES[2]
KNOWN = BASE + [THERMAL]


def _validate_episodes(train, val, test=None):
    if not train or not val: raise ValueError('training and validation episodes required')
    packs = [train, val] + ([test] if test is not None else [])
    ids = [set(r['episode_id'] for r in rows) for rows in packs]
    if any(ids[i] & ids[j] for i in range(len(ids)) for j in range(i+1,len(ids))):
        raise ValueError('overlapping train/validation/test episodes')
    if len(ids[1]) < 2: raise ValueError('two independent validation episodes required')
    if any(r.get('intervention_type') != 'controlled' for rows in packs for r in rows):
        raise ValueError('controlled interventions required')
    if len({r['body_id'] for rows in packs for r in rows})!=1:
        raise ValueError('fit and validate source body separately')


def phase_candidates(rows, *, max_terms=110):
    """Predeclared phase frequency grid; NEVER inspects validation outcomes.

    This extends the polynomial grammar but is still a finite search over sine
    bases. Frequencies are candidate hypotheses, not assumed discovered laws.
    """
    if not rows: raise ValueError('training evidence required')
    common=set.intersection(*(set(r) for r in rows))
    terms = []
    if 'x' in common:
        for wx in (1.,2.,3.,4.,5.,6.):
            for wv in (0.,.5,1.,1.5,2.):
                factors=[{'field':'x','transform':'linear'}]
                weights=[wx]
                if wv and 'v' in common:
                    factors.append({'field':'v','transform':'linear'});weights.append(wv)
                suffix=str(wx).replace('.','_')+'_'+str(wv).replace('.','_')
                terms.append(validate_term({'id':'sinephase_'+suffix,'factors':factors,
                             'basis':'sin_linear_combination','phase_weights':weights}))
    poly=generate(rows,max_candidates=80)
    return (poly+terms)[:max_terms]


def _collinearity_ok(rows, terms, tolerance=.02):
    mat=design(rows,terms)
    if np.linalg.matrix_rank(mat) < mat.shape[1]: return False
    last=mat[:,-1]; prior=mat[:,:-1]
    projection=prior @ np.linalg.lstsq(prior,last,rcond=None)[0]
    return float(np.linalg.norm(last-projection)/max(np.linalg.norm(last),1e-12)) >= tolerance


def _gains(val,reference,candidate):
    episodes = _episodes(val)
    values=[]
    for group in episodes.values():
        old=score(group,reference);new=score(group,candidate)
        values.append({'episode':group[0]['episode_id'], 'reference_rmse':old,
                       'candidate_rmse':new, 'relative_gain':(old-new)/max(old,1e-9)})
    return values


def search(train, validation, *, extra_candidates=None, max_candidates=110, min_gain=.12, noise_sd=None):
    """Fit on train, select on >=2 validation episodes, leave TEST unopened.

    Expanded sin-phase frequencies are generated without looking at validation
    values, but *selected* against validation. Multiple-comparison selection bias
    is possible; a never-before-used intervention is required for strong claims.
    """
    _validate_episodes(train,validation)
    terms=KNOWN
    reference=fit(train,terms)
    reference_err=score(validation,reference)
    pool=phase_candidates(train,max_terms=max_candidates)
    if extra_candidates:
        pool.extend(validate_term(t) for t in extra_candidates)
    seen=set(t['id'] for t in terms); candidates=[]
    for t in pool:
        if t['id'] in seen:continue
        seen.add(t['id']);candidates.append(t)
    results=[];eligible=[]
    available=set.intersection(*(set(r) for r in train+validation))
    for term in candidates:
        if any(f['field'] not in available for f in term['factors']):continue
        try:
            if not _collinearity_ok(train,terms+[term]):continue
            candidate=fit(train,terms+[term]); val_err=score(validation,candidate)
            gains=_gains(validation,reference,candidate)
            gain=(reference_err-val_err)/max(reference_err,1e-10)
            ok=bool(gain>=min_gain and all(g['relative_gain']>=.04 for g in gains))
            if noise_sd is not None and val_err>4*noise_sd:ok=False
            item={'term':term,'validation_rmse':val_err,'relative_gain':gain,
                  'per_episode':gains,'eligible':ok}
            results.append(item)
            if ok:eligible.append((val_err,term,candidate,item))
        except (ValueError,np.linalg.LinAlgError,OverflowError,FloatingPointError):continue
    if eligible:
        _,winning,model,decision=min(eligible,key=lambda k:k[0])
        status='CANDIDATE_PREDICTIVELY_SUPPORTED_NEEDS_PROSPECTIVE_FALSIFICATION'
    else:
        winning=None;model=reference;decision=None
        status='UNKNOWN_OR_NO_VALIDATED_NEW_MECHANISM'
    return {'status':status,'selected_term':winning,'model':model,'baseline_model':reference,
            'validation_baseline_rmse':reference_err,'validation_selected_rmse':score(validation,model),
            'candidate_count':len(candidates),'candidate_tested_count':len(results),
            'nominees_ranked':sorted(results,key=lambda x:x['validation_rmse'])[:12],
            'selected_validation_episodes':decision['per_episode'] if decision else [],
            'meta_used':False,'test_outcomes_accessed':False,
            'discovery_caveat':'bounded grid search + held-out episodes, not unrestricted discovery'}


def target_select(source_model, local, probes, *, min_rollout_gain=.03):
    """Transfer structure, not trusted coefficients; refit on B's own small probe.

    Validation uses only prior target probe. Fair baseline additionally performs
    its own candidate search with precisely the same target data and dictionary.
    """
    if not local or not probes: raise ValueError('target local and probe measurements required')
    if {r['episode_id'] for r in local}&{r['episode_id'] for r in probes}:
        raise ValueError('target local and probe episodes overlap')
    bodies={r['body_id'] for r in local+probes}
    if len(bodies)!=1:raise ValueError('one target per adaptation')
    if len(probes)<12: raise ValueError('probe too short')
    classic=fit(local,KNOWN)
    source_term=source_model['terms'][-1] if len(source_model['terms'])>len(KNOWN) else None
    transfer=None
    if source_term:
        try:
            if _collinearity_ok(local,KNOWN+[source_term]): transfer=fit(local,KNOWN+[source_term])
        except (ValueError,np.linalg.LinAlgError):pass
    # Stronger benchmark: target-only source-blind search over full fixed+phase dictionary.
    # A single target probe must be split into two distinct episodes to avoid
    # granting source-free selection more observations than the source condition.
    # Instead choose target-only using one-step validation over the SAME probe.
    blind=search_target_only(local,probes)
    options=[('CLASSICAL_LOCAL',classic),('TARGET_ONLY_SEARCH',blind['model'])]
    if transfer: options.append(('SOURCE_STRUCTURE',transfer))
    probe_scores=[]
    # Source may be chosen only if better than the BEST source-blind baseline.
    for name,model in options:
        one=score(probes,model)
        rolled=[]
        for episode in _episodes(probes).values():
            p=_episode_plan(episode)
            try:
                forecast=forecast_without_truth(model,(episode[0]['x'],episode[0]['v']),p)
                true=np.array([r['x'] for r in episode[1:]])
                rmse=float(np.sqrt(np.mean((np.array([f['x'] for f in forecast])-true)**2)))
            except (ValueError,OverflowError,FloatingPointError):rmse=float('inf')
            rolled.append(rmse)
        probe_scores.append({'name':name,'one_step_rmse':one,'rollout_rmse':float(np.mean(rolled)) if all(np.isfinite(r) for r in rolled) else None})
    best_no_source=min([r for r in probe_scores if r['name']!='SOURCE_STRUCTURE'],key=lambda r:r['rollout_rmse'] if r['rollout_rmse'] is not None else float('inf'))
    src=next((r for r in probe_scores if r['name']=='SOURCE_STRUCTURE'),None)
    accepted=bool(src and src['rollout_rmse'] is not None and best_no_source['rollout_rmse'] is not None and src['rollout_rmse']<best_no_source['rollout_rmse']*(1-min_rollout_gain)
                  and src['one_step_rmse'] <= best_no_source['one_step_rmse']*1.08)
    choice='SOURCE_STRUCTURE' if accepted else best_no_source['name']
    models=dict(options)
    selected_structure=models[choice]['terms']
    # Same target data budget for local and transferred predictions; structure
    # chosen with target probe, then refit using local+probe before future reveal.
    chosen=fit(local+probes,selected_structure)
    target_only=fit(local+probes,models[best_no_source['name']]['terms'])
    return {'status':'TRANSFER_SUPPORTED_ON_TARGET_PROBE' if accepted else 'REFUSE_SOURCE_TRANSFER',
            'choice':choice,'accepted':accepted,'source_term':source_term,
            'probe_comparisons':probe_scores,'model':chosen,'target_only_model':target_only,
            'target_only_selection':blind['status'],
            'source_test_outcomes_used':False,'target_future_test_outcomes_used':False}


def search_target_only(local,probe,*, max_candidates=45):
    """Strong target-only structural search with same target probe budget."""
    base=fit(local,KNOWN)
    scored=[(score(probe,base),base,None)]
    for t in phase_candidates(local,max_terms=max_candidates):
        if t['id'] in {x['id'] for x in KNOWN}:continue
        try:
            if not _collinearity_ok(local,KNOWN+[t]):continue
            model=fit(local,KNOWN+[t]);err=score(probe,model)
            scored.append((err,model,t))
        except (ValueError,np.linalg.LinAlgError):pass
    val,model,term=min(scored,key=lambda x:x[0])
    return {'status':'SELECTED_ON_TARGET_PROBE','validation_rmse':val,'selected_term':term,'model':model}


def _episode_plan(rows):
    times=[float(r['t']) for r in rows]
    delta=float(np.median(np.diff(times)))
    if not .001 <= delta <= .25: raise ValueError('invalid probe sample period')
    if np.max(np.abs(np.diff(times)-delta))>max(1e-5,delta*.05):
        raise ValueError('probe is not regularly sampled')
    return {'dt':delta,'u':[r['u'] for r in rows[:-1]],
            'temperature_delta':[r['temperature_delta'] for r in rows[:-1]]}


def _forecast_metrics(forecast,truth,channel):
    expected=np.array([r[channel] for r in forecast[:-1]],float)
    if channel=='camera_m':observed=np.array([r['sensors']['camera_m'] for r in truth[1:]],float)
    else:observed=np.array([r['sensors']['audio_m_per_s'] for r in truth[1:]],float)
    return float(np.sqrt(np.mean((expected-observed)**2)))


def _write(root,name,payload):
    dest=root/name; dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(payload,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
    return dest


def run_simulation(root,seed=2026,*,mode='unfamiliar',source_extra=.4,target_extra=None):
    """Runs source search, stage target commitments, then creates target truth."""
    root=Path(root);root.mkdir(parents=True,exist_ok=True)
    a={'id':'A_audio_touch','thermal':.82,'extra':source_extra}
    train=roll(a,seed,'A_training',n=145,unmodelled=True)
    val=roll(a,seed+1,'A_validation_1',n=125,unmodelled=True)+roll(a,seed+2,'A_validation_2',n=125,unmodelled=True)
    discovery=search(train,val,noise_sd=None)
    _write(root,'01_source_discovery.json',{k:v for k,v in discovery.items() if k not in ('model','baseline_model')})
    selected=discovery['model'];record=[];frozen=[]
    for label,dseed,channel,extra in [('B_camera',seed+100,'camera_m',source_extra if target_extra is None else target_extra),
                                       ('C_audio',seed+200,'audio_m_per_s',source_extra*.9 if target_extra is None else target_extra)]:
        b={'id':label,'thermal':.84 if label.startswith('B') else .78,'extra':extra}
        local=roll(b,dseed-2,label+'_local',n=65,unmodelled=True)
        probe=roll(b,dseed-1,label+'_probe',n=70,unmodelled=True)
        decision=target_select(selected,local,probe)
        action=plan(dseed,110)
        forecast=forecast_without_truth(decision['model'],action['initial'],action)
        baseline=forecast_without_truth(decision['target_only_model'],action['initial'],action)
        payload={'schema':'physica.mace.v013.sealed_forecast','origin':'SYNTHETIC_ONLY',
                 'target_body':label,'source_body':a['id'],'modality':channel,
                 'choice':decision['choice'],'hypothesis':discovery['selected_term'],
                 'coefficients_fit_using_target_local_and_probe':True,
                 'actions':{'dt':action['dt'],'u':[float(x) for x in action['u']],
                            'temperature_delta':[float(x) for x in action['temperature_delta']]},
                 'initial_state':list(action['initial']),'forecast':forecast,
                 'no_target_future_truth_accessed':True,
                 'local_timestamp_utc_not_independent_attestation':datetime.now(timezone.utc).isoformat()}
        receipt={'payload':payload,'signature':sign(payload),'target_only_baseline_forecast':baseline,
                 'probe_comparisons':decision['probe_comparisons'],'transfer_status':decision['status']}
        frozen.append((label,dseed,b,receipt,channel))
        record.append({'body':label,'sensor_modality':channel,'transfer_choice':decision['choice'],
                       'transfer_accepted':decision['accepted'],
                       'probe_comparisons':decision['probe_comparisons']})
    # Separate non-actuating next-experiment recommendation. This *proposal*
    # is based only on source training and previous target probe evidence.
    from .experiments import rank as rank_probes
    target_queries=roll({'id':'future_target_query_ONLY_FOR_DESIGN','thermal':.8,'extra':0.},
                        seed+300,'design_query_SIMULATED',n=35,unmodelled=False)
    proposed=[{**r,'approved_reversible':True,'risk':.02,'cost':.02,
               'expected_goal_progress':.0} for r in train[:50]]
    proposal=rank_probes(proposed,[discovery['baseline_model'],discovery['model']],target_queries)
    _write(root,'02a_NEXT_EXPERIMENT_REVIEW_ONLY.json',{'origin':'SIMULATION','no_actuation':True,
        'selection_used_future_outcomes':False,'planner':{**proposal,'ranked':proposal['ranked'][:6]},
        'scientific_note':'Expected target benefit is a model-conditional approximation, not guaranteed causal gain'})
    _write(root,'02_forecasts_SEALED_BEFORE_SIMULATOR_REVEAL.json',[r[3] for r in frozen])
    outcomes=[]
    for label,dseed,b,receipt,channel in frozen:
        if not verify(receipt['payload'],receipt['signature']):raise RuntimeError('invalid signed forecast')
        truth=roll(b,dseed,label+'_future_TEST',n=110,unmodelled=True)
        error=_forecast_metrics(receipt['payload']['forecast'],truth,channel)
        control=_forecast_metrics(receipt['target_only_baseline_forecast'],truth,channel)
        outcomes.append({'target':label,'sensor':channel,'rmse_selected':error,'rmse_target_only':control,
                         'relative_advantage':(control-error)/max(control,1e-12),
                         'signed_prediction_verified':True,'truth_created_after_signed_forecast_file':True,
                         'real_hardware_experiment':False,
                         'series_expected':[r[channel] for r in receipt['payload']['forecast'][::3]],
                         'series_observed':[r['sensors'][channel] for r in truth[1::3]]})
    report={'schema':'physica.mace.v013','origin':'SYNTHETIC_SIMULATOR_NOT_REAL_LAW_DISCOVERY',
            'mode':mode,'source_status':discovery['status'],'selected_mechanism':discovery['selected_term'],
            'source_search_test_not_seen':discovery['test_outcomes_accessed'] is False,
            'source_candidate_count':discovery['candidate_count'],
            'targets':outcomes,'target_decisions':record,
            'real_meta_calls':0,'real_experiments':0,'independent_timestamps':False,
            'research_limitations':['finite phase/polynomial grammar','source/target share simulator dynamics',
                 'source and target have calibrated position/velocity measurements',
                 'known action sequence, local signed chronology only',
                 'source-selected structure not independently established physical law']}
    _write(root,'03_after_reveal_RESULTS.json',report)
    _write(root,'RESULT.json',report)
    create_exhibit(root/'DISCOVERY_THEATER.html',report)
    return report


def create_exhibit(file,report):
    safe=json.dumps({'outcomes':report['targets']},ensure_ascii=True).replace('<','\\u003c')
    items=''.join('<article class="target"><h3>'+html.escape(o['target'])+'</h3><div class="metric">'+
         ('%.5f'%o['rmse_selected'])+'</div><p>Prospective '+html.escape(o['sensor'])+' RMSE · target only '+
         ('%.5f'%o['rmse_target_only'])+'</p><p>'+('Transfer helped' if o['relative_advantage']>0 else 'No transfer advantage')+'</p></article>'
         for o in report['targets'])
    body=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>PHYSICA / Discovery Theater v0.13</title><style>
    *{{box-sizing:border-box}}body{{margin:0;background:#07111c;color:#e4f8ff;font:16px/1.6 Segoe UI,system-ui,sans-serif}}
    main{{max-width:1200px;margin:auto;padding:38px 24px}}.eyebrow{{color:#77ddc5;letter-spacing:.25em;font-size:12px;font-weight:900}}
    h1{{font-size:clamp(36px,6vw,74px);letter-spacing:-.06em;line-height:1;margin:20px 0}}
    em{{font-style:normal;color:#76e7d0}}p{{color:#aec0ce}}.hero{{padding:50px 35px;border:1px solid #265f6e;border-radius:24px;background:radial-gradient(ellipse at 95% 10%,#164c54,#091a29 60%)}}
    .flag{{display:inline-block;padding:6px 13px;background:#453720;color:#ffd68b;border:1px solid #8e6b37;border-radius:99px;font-size:12px}}
    .board{{display:grid;grid-template-columns:1fr 1fr;gap:15px;margin:24px 0}}.target{{border:1px solid #294654;border-radius:16px;padding:25px;background:#102338}}.metric{{font-size:40px;color:#8bffe4;font-weight:bold}}
    canvas{{width:100%;height:320px;background:#081829;border:1px solid #244451;border-radius:16px}}button{{padding:10px 17px;color:#bffdeb;background:#183a45;border:1px solid #448b82;border-radius:9px;cursor:pointer}}
    .note{{border-left:3px solid #d3a65a;padding:18px;background:#2b281e}}@media(max-width:700px){{.board{{grid-template-columns:1fr}}}}
    </style></head><body><main><div class="hero"><span class="eyebrow">PHYSICA / MACE DISCOVERY THEATER</span>
    <h1>What if AI could <em>feel</em><br>the unknown?</h1>
    <p>Measure → question the model → search candidate mechanisms → predict through another sensory body → open sealed results.</p>
    <div class="flag">SIMULATION · BOUNDED MATHEMATICAL SEARCH · NOT A NATURAL-LAW DISCOVERY</div>
    <p>Selected source hypothesis: <strong>{html.escape(str(report['selected_mechanism']['id'] if report['selected_mechanism'] else 'NONE'))}</strong> · {report['source_candidate_count']} searched structures</p></div>
    <div class="board">{items}</div><h2>Sealed future sensations vs later observations</h2>
    <div><button data-target="0">Machine B · camera</button> <button data-target="1">Machine C · audio</button></div><br>
    <canvas id="plot" width="1100" height="320" aria-label="Forecast comparison"></canvas><p id="legend"></p>
    <div class="note">Signing a local prediction does not independently prove chronology. Truth in this exhibit comes from a simulator generated AFTER commitment. Real-world validation and independent Meta inference remain pending.</div>
    </main><script>const D={safe};const el=document.getElementById('plot'),ctx=el.getContext('2d');
    function draw(idx){{const o=D.outcomes[idx],p=o.series_expected,q=o.series_observed,n=Math.min(p.length,q.length);
    const all=p.concat(q),min=Math.min(...all),max=Math.max(...all),span=Math.max(max-min,1e-4);ctx.clearRect(0,0,1100,320);
    ctx.fillStyle='#0a1b2a';ctx.fillRect(0,0,1100,320);ctx.strokeStyle='#234455';
    for(let i=0;i<=4;i++){{ctx.beginPath();ctx.moveTo(0,i*80);ctx.lineTo(1100,i*80);ctx.stroke()}}
    [[p,'#76e7d0'],[q,'#fbc784']].forEach(([a,color])=>{{ctx.strokeStyle=color;ctx.lineWidth=3;ctx.beginPath();for(let k=0;k<n;k++){{let x=20+1060*k/Math.max(1,n-1),y=285-245*(a[k]-min)/span;if(k===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)}}ctx.stroke()}});
    document.getElementById('legend').textContent=o.target+' | green = sealed prediction; gold = later generated observation. RMSE '+o.rmse_selected.toFixed(6)}}
    document.querySelectorAll('button[data-target]').forEach(b=>b.onclick=()=>draw(+b.dataset.target));draw(0);</script></body></html>'''
    Path(file).write_text(body,encoding='utf-8')


def main(argv=None):
    p=argparse.ArgumentParser(description='Physica v0.13 agentic causal experience evaluation')
    s=p.add_subparsers(dest='action',required=True)
    a=s.add_parser('demo');a.add_argument('--out',default='demo/v013');a.add_argument('--seed',type=int,default=2026)
    a=s.add_parser('benchmark');a.add_argument('--out',required=True);a.add_argument('--seeds',type=int,default=12)
    x=p.parse_args(argv)
    if x.action=='demo':
        report=run_simulation(x.out,seed=x.seed)
        print(json.dumps({'status':report['origin'],'selected':report['selected_mechanism'],
                          'theater':str(Path(x.out)/'DISCOVERY_THEATER.html'),
                          'target_advantages':[t['relative_advantage'] for t in report['targets']]},allow_nan=False))
    else:
        if not 1<=x.seeds<=60:raise ValueError('seeds must be 1..60')
        out=Path(x.out);out.mkdir(parents=True,exist_ok=True);values=[]
        for i in range(x.seeds):
            r=run_simulation(out/f'seed_{i:02}',seed=2026+i*71)
            values.append({'seed':i,'selected_term':r['selected_mechanism'],
                           'targets':[{k:t[k] for k in ('target','relative_advantage','rmse_selected','rmse_target_only')} for t in r['targets']]})
        gains=[t['relative_advantage'] for v in values for t in v['targets']]
        report={'origin':'SYNTHETIC_ONLY','seeds':x.seeds,'cases':len(gains),
                'transfer_wins':sum(x>0 for x in gains),'mean_relative_gain':float(np.mean(gains)),
                'per_seed':values,'not_real_world_evidence':True}
        _write(out,'BENCHMARK.json',report)
        print(json.dumps({k:v for k,v in report.items() if k!='per_seed'},allow_nan=False))
if __name__=='__main__':main()
