# Physica v0.11 — Reliable Causal Feeling & Meta Scientist

## What this release changes

This release repairs the v0.10 benchmark failure, implements a target-dependent experiment objective, adds controlled missing-sense selection, and adds one CLI for real-data + Meta-mechanism scientific evaluation. It builds on the complete v0.10 application; older modules are retained.

**Important distinction:** These features create a *research candidate and experimental harness*, not proof of consciousness, a new natural law, all five human senses, genuine autonomous physical discovery, commercial appliance diagnosis, or real-world superiority. All demonstrations bundled with this release are simulations unless explicitly marked as supplied field evidence. Paid, authenticated Meta execution and physical instrument validation have not been performed in this release environment.

### Corrected failure: unstable latent predictions

v0.10 crashed when the PCA/Ridge latent rollout diverged. `physica.mace.guarded_feeling` now trains ARX and PCA latent predictors on a **training episode**, chooses among them and persistence on a separate **validation episode**, freezes the choice, and only then scores a third **test episode**. Unsafe/nonfinite rollouts are recorded as `ABSTAIN_UNSTABLE_TEST_ROLLOUT` instead of crashing research runs. The model selector frequently chooses a conventional baseline; do not claim learned-latent superiority just because the system ran.

### New target-directed experiment design

`mace/experiments.py` now computes a **candidate-dependent** expected reduction in target prediction variance:

\[
\Delta\mathrm{Var}_B(a)=\frac{1}{|Q_B|}\sum_{q\in Q_B}\frac{(\phi_q^\top \Sigma \phi_a)^2}{\sigma^2+\phi_a^\top \Sigma\phi_a}
\]

for each model's Gaussian approximate coefficient posterior, given feature vectors \(\phi\), covariance \(\Sigma\), and measurement noise variance \(\sigma^2\). It combines the target-specific term with an approximate inter-model information term, human-approved risk/cost, and a small goal-priority term. It never reads a future result while ranking. **Limitations:** fitted mechanism family, covariance calibration, model correctness, and target-query distribution are assumptions; the objective is not a universal causal value-of-information proof. The separate `target-probe-benchmark` is designed to test this approximation against equal-budget random probes in simulation.

### Missing, virtual, and beyond-human senses

`mace/active_sensing.py` ranks a missing camera, calibrated velocity proxy or position encoder according to the requested physical state and independent calibration. It does not invent measurement values. The existing sensor registry retains motor current, thermal, magnetic, ultrasound, radar, chemical and hyperspectral modalities, but those require real instruments, units and independent calibration. A camera cannot measure chemistry; a microphone is not a force sensor.

### Real data / Meta scientific learning path

`mace/field_investigation.py` connects these modules:

1. Import three *distinct* train/validation/test controlled-action CSV episodes with verified file hashes, units and self-declared independent calibration.
2. Fit a fixed physics baseline on training data. Send **training aggregates and baseline validation error only** to Muse Spark/Wonder when explicitly authorized. Never send the held-out test.
3. Parse a strict Meta schema into a restricted mathematical feature grammar; unknown measurements cause abstention.
4. Fit the candidate's numerical parameters from physical data; evaluate hypotheses against the separate validation episode and then the final held-out test.
5. Rank safe, non-actuating next experiments for the predeclared target observations.
6. Optionally provide evidence-limited washing-machine, robot-arm or 3D-printer guidance. No repair commands or machine actuation are issued.

**Meta roles:** Spark/Wonder may select new *testable features*, and SAM may supply pixel tracking. Physical data alone determines fitted coefficients, validation and acceptance. Meta does **not** directly set model coefficients, certify sensors or authorize unsafe motor commands. A single observed held-out improvement is not enough to establish scientific novelty, robust causality or Meta's contribution; replicate independent tasks and compare fixed-dictionary models under matched proposal and experiment budgets.

### SAM → calibrated motion bridge

`mace/vision_bridge.py` reuses `grammar/meta_sam_official.py` and the official `meta_sam_parser`. For a real video, it requests the target and stationary reference in separate noun-phrase prompts, checks the same raw-video hash and tracks, and converts their relative horizontal motion to metres using an **externally verified** pixels-per-metre scale and frame rate. It refuses excessive camera drift, missing frames, invalid or mock track origins, or absent calibration. It **does not** derive force, mass, acceleration, a physical mechanism or an action automatically. For rigorous experiments, compare optical displacement against another independent instrument.

### Data needed at Moody (or an independent laboratory)

Construct a low-energy, reversible beam test with three independently logged interventions on A. Record timestamps, displacement, velocity, applied force (or separately calibrated input acceleration), external temperature if relevant, and acceleration independently; supply the same clock and SI units. Do not attempt nonlinear force discovery from camera video alone if acceleration, force or calibration are not reliable. Acquire a second physical body B for prospective transfer, with a separate probe and a committed pre-experiment prediction. Record negative trials. A locally signed prediction proves integrity, not independently witnessed chronology.

## Quick start (Python 3.12+)

From inside the extracted `physica` directory:

```bash
python -m pip install -e ".[dev]"
python -m pytest -q tests/test_mace_v011.py tests/test_mace_v010.py
python -m physica.mace.cli benchmark --seeds 36 --out demo/v011/mace_36
python -m physica.mace.cli target-probe-benchmark --seeds 24 --trials 100 --out demo/v011/target_probe.json
python -m physica.mace.cli sense-plan --input examples/mace_v011/sense_plan_example.json --out demo/v011/sensor_recommendations.json
python -m physica.studio --open-browser
```

Windows PowerShell can use the virtual-environment Python in place of `python`, e.g. `..\.venv\Scripts\python.exe`.

### Controlled physical data (no Meta bill)

Copy `examples/mace_v010/controlled_recordings_MANIFEST_TEMPLATE.json`, fill the real file hashes, body IDs, episode IDs, training/validation/test split and calibration disclosures, and put the associated CSVs beside it. Each CSV requires `t,x,v,u,acceleration,temperature_delta`, in seconds, metres, metres/sec, metres/sec², metres/sec², kelvin difference respectively. The field origin and independent calibration fields are **claims supplied by the experimenter**, not third-party attestations.

```bash
python -m physica.mace.cli field-investigate --manifest YOUR_MANIFEST.json --out field_investigation.json --device washing_machine
```

If you have a reviewed, offline candidate record (see `examples/mace_v010/offline_human_nominated_term.json`), add `--nomination YOUR_CANDIDATE.json`. These candidate labels cannot be presented as live Muse outputs.

### Authenticated Muse (requires owner's key, network, possible billing)

Set `MODEL_API_KEY` locally in your own environment (never paste it into ChatGPT). Meta's documented Chat Completions structured response API is used. Explicit opt-in:

```bash
python -m physica.mace.cli field-investigate --manifest YOUR_MANIFEST.json --live-meta --allow-billed-meta --out meta_field_result.json
```

No model execution has been verified in this environment. Keep raw Model API responses and metadata for independent ablation and science review.

### Authenticated SAM (requires video, key, optional package, possible billing)

```bash
python -m pip install -e ".[meta]"
python -m physica.mace.cli sam-video --video YOUR_VIDEO.mp4 --target 'moving ruler' --reference 'stationary clamp' --fps 240 --pixels-per-metre 700 --independent-calibration-verified --stationary-reference-verified --allow-billed-meta --out sam_video_displacement.json
```

The calibration values above are **examples**, not actual calibration data. Replace them with independent measurements; do not assert verification unless it has occurred. This command sends user media to Meta's service by explicit choice.

## Experimental comparisons needed to substantiate the breakthrough

- Prediction error on unseen real machine B after equal-budget local probes, not just conditional acceleration on A.
- Number of approved experiments to reach predeclared error, accounting for *all* source experiments and Meta proposal cost.
- Meta-on vs Meta-off fixed-dictionary candidate nomination under the same budgets, with an actual authenticated response.
- Classical state-space/ARX and PySINDy/SINDy alternatives, appropriate to identifiable measured variables.
- Domain shifts, camera motion, missing sensors, bad force calibration, incorrect Muse nominations and abstention rates.
- Prospective independent chronology and reproducible raw evidence manifests with held-out tests.

A model choosing an already known candidate in a matching synthetic simulator is *not* discovery of a new physical law.

## Documentation consulted

- Meta Model API overview: https://dev.meta.ai/docs/overview
- Meta structured output (Chat Completions uses `response_format`, Responses uses `text.format`): https://dev.meta.ai/docs/cookbook/structured-output
- SAM 3.1 client libraries and `meta_sam_parser`: https://dev.meta.ai/docs/sam/client-libraries
- Official SAM Python video cookbook: https://github.com/meta-models/meta-model-cookbook/tree/main/07_sam/01_api_basics
- PySINDy identification library: https://pysindy.readthedocs.io/en/stable/index.html

## What remains unverified/unbuilt

- Paid authenticated Muse responses on real experimental context.
- Paid SAM tracking on real Moody video and independent optical calibration.
- Real prospective A→B→C hardware verification and an independent timestamp/witness.
- Evaluation on public real Paderborn recordings in this build.
- End-to-end native Meta glasses SDK app; Lens is a phone/browser prototype.
- Real chemical, thermal, magnetometer, RF, radar or tactile sensor acquisition outside the existing digital interfaces.
- Unrestricted open-world scientific discovery, universal five-sense intelligence or scientific priority over prior methods.

These cannot be converted into proven outcomes by more software changes alone.
