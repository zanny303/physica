# Physica v0.5.2 — Three Experiences Edition

Preserves Physica v0.5.1. Adds `physica/triad/`:

- `target_experiments.py`: target-risk-directed safe experiment ranking, analytic Gaussian posterior covariance update.
- `video.py`: local video optical-flow tracked region + fixed-reference option, forward-only model fitting, retrospective holdout forecast and signed-prefix two-step forecast.
- `evidence.py`: common SHA-256 evidence manifest and Ed25519 forecast/reveal links.
- `lens.py`: local browser upload, ROI selection and causal-limit-aware results, same video inference as Discover.
- `paderborn.py`: inspect/parse researcher-provided numeric MAT data, avoid guessing signal labels.
- `cli.py`: reproducible CLI, optional real billable Muse Spark/Wonder/SAM prefix calls.
- `examples/triad_v052/`: full synthetic video and target-directed experiment exhibit, local Lens preview.
- `tests/test_triad_v052.py`: new target selection, NaN refusal, signature tamper, video and holdout tests.

No actual outside dataset, hosted Meta API output, glasses SDK or real hardware validation is claimed. See `docs/V052_THREE_ACTS_RESEARCH.md`.
