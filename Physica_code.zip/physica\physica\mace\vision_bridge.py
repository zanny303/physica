"""Turn authenticated SAM pixel tracks into calibrated *video displacement observations*.

Only a tracked object and a separately tracked stationary reference are accepted.
Pixel observations cannot establish force, mass, acceleration or causality by themselves.
Camera frame rate and pixel-to-metre calibration are externally verified claims.
"""
from __future__ import annotations
import hashlib,math
from pathlib import Path
import numpy as np


def calibrated_displacement(sam_result, *, target_object_id, reference_object_id,
                            frames_per_second, pixels_per_metre,
                            calibration_verified=False, static_reference_verified=False,
                            max_reference_jitter_px=3., max_gap_frames=3):
    if not isinstance(sam_result,dict) or sam_result.get('mode')!='LIVE_META_API_OFFICIAL_PARSER':
        raise ValueError('authenticated SAM parser result required; mocked tracks are not real observations')
    if not isinstance(sam_result.get('video_sha256'),str) or len(sam_result['video_sha256'])!=64:
        raise ValueError('video hash required')
    if target_object_id==reference_object_id:raise ValueError('reference and target must differ')
    if calibration_verified is not True or static_reference_verified is not True:
        raise ValueError('independent length scale and verified stationary reference required')
    numbers=(frames_per_second,pixels_per_metre,max_reference_jitter_px)
    if any(type(x) not in (float,int) or not math.isfinite(x) for x in numbers):raise ValueError('nonfinite calibration')
    if not 1<=frames_per_second<=10000 or pixels_per_metre<=0 or max_reference_jitter_px<=0:
        raise ValueError('invalid camera calibration')
    records={str(target_object_id):{},str(reference_object_id):{}}
    for row in sam_result.get('boxes',[]):
        obj=str(row.get('object_id'))
        if obj not in records:continue
        f=row.get('frame');x=row.get('x_center_px')
        if type(f) is not int or f<0 or type(x) not in (int,float) or not math.isfinite(x):
            raise ValueError('malformed frame or track measurement')
        if f in records[obj]:raise ValueError('duplicate target/reference observation')
        records[obj][f]=float(x)
    common=sorted(set(records[str(target_object_id)])&set(records[str(reference_object_id)]))
    if len(common)<10:raise ValueError('too few synchronized tracked frames')
    if max(np.diff(common))>max_gap_frames:raise ValueError('unreliable discontinuous object track')
    refs=np.array([records[str(reference_object_id)][f] for f in common])
    # Reference position must remain within independently declared camera jitter.
    if np.max(np.abs(refs-np.median(refs)))>max_reference_jitter_px:
        raise ValueError('camera/reference drift exceeds calibration: abstain')
    targets=np.array([records[str(target_object_id)][f] for f in common])
    relative=(targets-refs)
    baseline=relative[0]
    t=np.asarray(common,float)/frames_per_second
    x=(relative-baseline)/pixels_per_metre
    return {'status':'SAM_TRACKS_TO_CALIBRATED_VIDEO_DISPLACEMENT',
            'meta_model':sam_result.get('model_id'),'live_response_claim':True,
            'raw_video_sha256':sam_result['video_sha256'],
            'frame_rate_independently_verified':True,'scale_independently_verified':True,
            'reference_stationary_claim_externally_verified':True,
            'reference_max_jitter_px':float(np.max(np.abs(refs-np.median(refs)))),
            'samples':[{'t_s':float(tt),'displacement_m':float(xx)} for tt,xx in zip(t,x)],
            'not_measured':['force_N','mass_kg','stiffness_N_per_m','acceleration_m_per_s2'],
            'warning':'calibrated video displacement only; no automatic causal or control claims'}


def _select_single_stable_track(boxes, label):
    """Select a single well-covered SAM object, never merge multiple detections.

    A near-tie between tracks is ambiguous and requires an object box/point
    prompt; it must not silently become an average or duplicated observation.
    """
    by_id={}
    for r in boxes:
        if isinstance(r.get('frame'),int):
            by_id.setdefault(r.get('object_id'),[]).append(r)
    if not by_id:raise ValueError(f'SAM did not find a track for {label}')
    def ranking(rows):
        frames={r['frame'] for r in rows}
        confident=[float(r.get('confidence')) for r in rows if r.get('confidence') is not None]
        return (len(frames),float(np.median(confident)) if confident else .5)
    ordered=sorted(by_id.items(),key=lambda pair:ranking(pair[1]),reverse=True)
    if len(ordered)>1:
        top=ranking(ordered[0][1]);runner=ranking(ordered[1][1])
        if runner[0]>=top[0]*.95 and abs(top[1]-runner[1])<.12:
            raise ValueError(f'Multiple indistinguishable {label} objects: use a SAM box/point prompt instead')
    selected=ordered[0][1]
    if len({r['frame'] for r in selected})<10:
        raise ValueError(f'Insufficient distinct SAM frames for {label}')
    return selected


def run_video(video_path,*,concept_target,concept_reference,frames_per_second,pixels_per_metre,
              calibration_verified=False,static_reference_verified=False,allow_billed=False):
    if not allow_billed:raise PermissionError('explicit permission required for billed Meta video calls')
    import os,time
    from physica.grammar.meta_sam_official import sam_video_official
    from physica.llm import meta_client
    if os.environ.get('MOCK')!='0' or not meta_client.api_key():
        raise PermissionError('Real SAM needs MOCK=0, MODEL_API_KEY and explicit billed authorization')
    try:
        import cv2
    except ImportError as e:
        raise RuntimeError('Video frame preflight requires pip install -e ".[video]"') from e
    cap=cv2.VideoCapture(str(video_path))
    try: frames=int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) if cap.isOpened() else 0
    finally:cap.release()
    if not 10<=frames<=900:
        raise ValueError('SAM requires 10–900 valid video frames to bound authorization and spending')
    # Conservative, configurable cost reservation BEFORE either paid call;
    # the official parser currently does not reserve on its own. Upper bound
    # intentionally exceeds published frame cost to avoid accidental overrun.
    estimated_total=2*max(50,frames)*float(os.environ.get('PRICE_SAM_FRAME', '.01'))
    start=time.time()
    rid=meta_client._reserve(estimated_total,'twin_sam_two_concepts')
    try:
        target=sam_video_official(video_path,concept=concept_target)
        reference=sam_video_official(video_path,concept=concept_reference)
    except Exception:
        # A partially completed call may be billed; conservatively charge
        # the estimated maximum until reconciled against provider billing.
        meta_client._settle(rid,estimated_total,'twin_sam_two_concepts uncertain remote failure')
        raise
    meta_client._settle(rid,estimated_total,'twin_sam_two_concepts conservative estimate')
    meta_client.receipt('sam','sam-3.1',
        {'target_prompt':concept_target,'reference_prompt':concept_reference,
         'video_sha256':target.get('video_sha256'),'frame_count_declared':frames,
         'estimated_max_usd_conservative':estimated_total},
        {'target_records':len(target['boxes']),'reference_records':len(reference['boxes']),
         'target_parser_diagnostics':target.get('parser_diagnostics'),
         'reference_parser_diagnostics':reference.get('parser_diagnostics')},
        {'cost_estimate_not_provider_usage':estimated_total},'twin_sam_two_concepts',time.time()-start)
    if target['video_sha256']!=reference['video_sha256']:raise RuntimeError('video integrity mismatch')
    # Label source-specific object tracks before merging for the calibrated bridge.
    target_boxes=[{**row,'object_id':'target'} for row in _select_single_stable_track(target['boxes'],'target')]
    reference_boxes=[{**row,'object_id':'reference'} for row in _select_single_stable_track(reference['boxes'],'reference')]
    combined={'mode':'LIVE_META_API_OFFICIAL_PARSER','model_id':'sam-3.1',
              'video_sha256':target['video_sha256'],'boxes':target_boxes+reference_boxes}
    return calibrated_displacement(combined,target_object_id='target',reference_object_id='reference',
           frames_per_second=frames_per_second,pixels_per_metre=pixels_per_metre,
           calibration_verified=calibration_verified,static_reference_verified=static_reference_verified)
