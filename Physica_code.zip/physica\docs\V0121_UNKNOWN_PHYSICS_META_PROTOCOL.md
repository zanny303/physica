# Physica v0.12.1 — When Physica meets unknown physics

**Release status:** code and simulated numerical experiments verified; authentic Meta inference **NOT** run by this release; no new real hardware results; not established scientific discovery.

## The actual five-step decision chain

1. **Measure:** An independently calibrated, controlled-action recording supplies `t, x, v, u, acceleration` in declared SI units, with optional *actually measured* `temperature_delta`, `current`, `magnetic` and `ultrasound` channels. Real sensor data comes from SHA-256 validated CSVs. A source-declared `independent_calibration: true` is **not** an external witness of calibration.
2. **Notice:** Baseline mechanics and bounded candidate equations are fitted only to the training episode. At least **two separate validation episodes** must support any new term. Physica examines unexplained residual error and temporal structure on those validation episodes. Systematic failure yields `UNKNOWN_OR_MISSPECIFIED_MECHANISM_SUSPECTED`, not the name of a confirmed cause. Camera drift, clock error and correlated sensor noise can also cause this alert.
3. **Ask Meta:** Only for suspicious unexplained behavior, a safe structured request can go to **Muse Wonder** (or Spark). It receives measured-channel names and aggregated *training/validation* diagnostics, **not** the held-out test trajectory. It may propose a bounded additional mathematical basis, ask for an **independently measured** missing sensor, or abstain. No arbitrary Python, executable expressions, automatic hardware control, or invented measurements are allowed.
4. **Challenge:** The machine's numerical engine estimates each proposed term's coefficients from the recorded **training** interventions, compares it with the best standard-grammar surrogate on two **validation** interventions, and measures residual uncertainty and correlation. A candidate that predicts better can be queued for a new prospective falsification test; it is **not** pronounced a newly discovered physical law. A separate held-out test is evaluated only after model selection. Negative results are retained.
5. **Learn carefully:** Only after a new, supervised physical experiment establishes evidence can a causal lesson be considered for conditional cross-machine transfer. Transfer requires target calibration, compatibility, own local probe and independent chronology; none of that is automatically verified by this algorithm.

### Why Meta matters and what it cannot do

Meta is not just writing explanations after the physics engine finishes: if an existing grammar fails, Muse can nominate **which additional mechanism family gets fitted and tested**. The real experiments—not Muse's output—determine the resulting numerical parameters and whether the candidate is useful. Its hypotheses are unverified regardless of model confidence. For genuine Meta value, compare a **live authenticated Muse nomination** with **no-Meta**, **random nomination**, and **same-data all-feature regression** under identical measurement budgets. The provided fixture below is **human-authored with knowledge of the simulator equation** and must not be shown as a genuine Muse discovery.

A candidate `sin_linear_combination` is supported as a bounded, dimensionless sinusoidal basis with at most two measured channels and bounded phase weights; every structural proposal is validated against a strict grammar. Those weights are a proposed structural frequency and not verified physical constants. Meta cannot invent a new sensor stream or direct a machine to actuate.

## Reproduce the synthetic investigation (no API, no charges)

From the extracted `physica` folder:

```powershell
python -m pip install -e ".[dev]"
python -m physica.mace.cli unknown-investigate --seed 2026 --out demo/unknown_no_meta.json
python -m physica.mace.cli unknown-investigate --seed 2026 --nomination examples/mace_v0121/author_hypothesis_SIMULATED.json --out demo/unknown_offline_with_proposal.json
python -m pytest -q tests/test_mace_v0121.py
python -m physica.studio --open-browser
```

The no-Meta report produces a request preview but does **not** contact Meta. The second report tests a human-written proposal equal to the simulator's known missing structural term. Do **not** report the latter as a discovery or as a live Meta-on ablation.

## Use your own controlled, calibrated real files

1. Record at least **four disjoint controlled interventions** on a single source body: one train, two validation, one entirely untouched test. More independent training and test experiments are strongly recommended. Each episode is one CSV with >=12 rows.
2. Mandatory CSV headers: `t,x,v,u,acceleration`. `t` is seconds, `x` metres, `v` m/s, `u` calibrated input acceleration m/s², `acceleration` measured m/s². You may add `temperature_delta` K, `current` A, `magnetic` uT, `ultrasound` Hz if physically recorded. No field is invented or replaced with zeros when absent. **Do not use a microphone waveform as physical acceleration** without independent calibration.
3. Build a manifest like `examples/mace_v0121/manifest_TEMPLATE.json`, declaring hashes of the exact CSV bytes, unique episode IDs, split, body, instrument calibration declaration and provenance origin. Maintain original sensor files and chronological evidence separately.
4. Use a previously calibrated acceleration noise standard deviation where available; estimate this **before** inspecting test outcomes.
5. Evaluate the unknown trigger without Meta, then optional live hypothesis nomination:

```powershell
python -m physica.mace.cli unknown-investigate --manifest path/to/manifest.json --measurement-noise-sd 0.02 --out demo/unknown_field_no_meta.json
# Require explicit user approval and an independently configured key. Billed call.
$env:MODEL_API_KEY = '<your private key in your local terminal only>'
python -m physica.mace.cli unknown-investigate --manifest path/to/manifest.json --measurement-noise-sd 0.02 --live-meta --model muse-wonder-1.0 --allow-billed-meta --out demo/unknown_field_live_meta.json
```

If the system flags an unknown source, Muse should respond with one of:
- `propose`: bounded hypothesis; separately fit and test against existing explanations;
- `request_sensor`: record another calibrated channel or seek another approved, non-destructive experiment;
- `abstain`: model makes no credible claim.

No API key or billable Meta response is used in the packaged offline results. A live request may fail due to authentication, quota, API changes, safety filtering, malformed output or model error. Check the actual request/response traces and make Meta-on versus Meta-off comparisons *after* authentication.

## Moody Makerspace and demo integrity

Use safe, staff-approved low-force apparatus. Don't induce deliberate destructive failures or actuate machinery automatically. A metal or plastic cantilever rig with a rigid clamp, independent displacement measurement and optionally an accelerometer is suitable for trying the first controlled prediction. A camera alone does not measure applied force or friction uniquely. A trustworthy physical-demonstration claim must use a forecast committed before the unseen experiment, distinct experimental episodes, measured instrument noise, an independently witnessed timestamp when possible and all unsuccessful trials.

### What this release does NOT prove

- That its sinusoidal proposal is a genuinely new law—it is in a declared bounded grammar.
- That Muse will independently nominate the right mechanism in the field—the authenticated call has not happened in this development environment.
- That a predictor's lower RMSE proves it inferred the true cause.
- That the five senses work on real hardware.
- That a signed file automatically proves physical chronology or measurement accuracy.
- That cross-machine feeling transfer wins against SINDy, ARX, strong physics models or other few-shot transfer methods.

**Nearest research milestone:** Collect real experiments with a hidden, intentionally benign mechanism shift. Show that real Meta hypotheses—not authored fixtures—improve correctly validated intervention predictions compared with fixed-grammar and appropriate system-identification baselines, and that any claimed lesson transfers prospectively to a second body.

Official integration references (checked November 2026):
- https://dev.meta.ai/docs/cookbook/quickstart-chat-completions
- https://dev.meta.ai/docs/cookbook/structured-output
- https://dev.meta.ai/docs/sam/client-libraries
- https://dev.meta.ai/docs/models
