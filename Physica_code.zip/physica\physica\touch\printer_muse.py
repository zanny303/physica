"""Muse in the investigation: it looks at the printer, proposes causes, gets challenged, and learns from the result.

  Wonder sees the measured numbers and photos from the films, and proposes causes Physica's built-in test doesn't cover.
  Spark challenges each one. It can only remove an idea that contradicts the measurements.
  Physica turns what's left into sealed forecasts, and the films decide.
  Wonder then sees the result, updates its explanation, and proposes what to test next.

Muse sees and reasons. Physica feels and measures. Muse never sees the truth of a blind trial, and it can't write a number into
the record: its proposals are limited to a share of mass or stiffness, and any number in its explanations is checked.
Hypothesis-guided experiments are the pattern reported by LLM-AutoSciLab (arXiv:2605.24043). Keeping numbers out of the model's
hands follows evidence-constrained reports like ViLM. Rating photos of prints follows LLM-3D Print (arXiv:2408.14307).
"""
from __future__ import annotations

import base64
import json
import re
from pathlib import Path

import numpy as np

RIVAL = {"type": "object", "additionalProperties": False, "required": ["name", "story", "mass_share", "responds_to_weight"],
         "properties": {"name": {"type": "string"}, "story": {"type": "string"}, "mass_share": {"type": "number"}, "responds_to_weight": {"type": "boolean"}}}


def _schema(name: str, props: dict) -> dict:
    return {"type": "json_schema", "json_schema": {"name": name, "strict": True, "schema": {
        "type": "object", "additionalProperties": False, "required": list(props), "properties": props}}}


SCHEMA = _schema("PhysicaPrinterRivals", {"seen_in_photos": {"type": "string"}, "rivals": {"type": "array", "items": RIVAL}})
CHALLENGE = _schema("PhysicaPrinterChallenge", {"reviews": {"type": "array", "items": {"type": "object", "additionalProperties": False,
                    "required": ["name", "keep", "reason"], "properties": {"name": {"type": "string"}, "keep": {"type": "boolean"}, "reason": {"type": "string"}}}}})
UPDATE = _schema("PhysicaPrinterUpdate", {"explanation": {"type": "string"}, "rivals": {"type": "array", "items": RIVAL}, "next_test": {"type": "string"}})
JUDGE = _schema("PhysicaPartJudge", {"less_ringing": {"type": "string", "enum": ["X", "Y", "can't tell"]}, "x_rating": {"type": "number"}, "y_rating": {"type": "number"}, "reason": {"type": "string"}})

_FIELDS = """For each cause give:
- name: a few words
- story: one sentence of what physically happened
- mass_share: 0 to 1, how much of the tone's fall comes from added mass, with the rest from lost stiffness. Use a value strictly between 0 and 1
- responds_to_weight: false only if this tone doesn't come from the head's mass on its belts, so a weight on the head would barely change it"""

SYSTEM = f"""You are a physical scientist investigating a 3D printer. A phone film measured the print head's vibration tone, and it \
has changed. The tone follows f = sqrt(k/m)/(2 pi), for stiffness k and moving mass m. Physica already tests two causes: all from \
more mass, and all from less stiffness.
You may also get photos from the healthy film and the changed film. Physica can't see, so say plainly in seen_in_photos what differs, \
or that you can't see a difference. Don't guess beyond what's visible.
Propose up to 3 other specific physical causes worth testing, such as a real mix of mass and stiffness, or something other than the \
head's mass and belts.
{_FIELDS}
Use only the numbers given. Don't claim a cause is true: the next experiment will test it. Reply with the JSON the schema asks for."""

CHALLENGER = """You are a skeptical physicist reviewing proposed causes for a change in a 3D printer's vibration tone, before an \
experiment tests them. Remove an idea only if it contradicts the measurements or basic physics. Don't remove it for being unlikely: \
the experiment will decide. Give one review per idea, using its exact name. Reply with the JSON the schema asks for."""

UPDATER = f"""You are a physical scientist investigating a 3D printer. An experiment has just run: forecasts for each cause were \
sealed, a known weight was added, and the tone was measured. Explain in plain words what the result means for each cause, without \
overstating it. A forecast that fits is support, not proof. Use only the numbers given, exactly as given. Then propose up to 2 causes still \
worth testing, and say what test would separate them next. If none is left, return an empty list and say so.
{_FIELDS}
Reply with the JSON the schema asks for."""

JUDGER = """You are inspecting photos of two 3D printed walls, X and Y, from the same model, for ringing: faint repeating ripples \
just after a corner. Rate each from 0 (heavy ringing) to 10 (none). Judge only what you can see, and say "can't tell" if the photos don't \
show it. Reply with the JSON the schema asks for."""


def clean(raw: list, most: int = 3) -> list[dict]:
    """Only proposals the experiment can test. A share of exactly 0 or 1 repeats what Physica already tests."""
    out, seen = [], set()
    for r in raw or []:
        if not isinstance(r, dict):
            continue
        name = " ".join(str(r.get("name", "")).split())[:48]
        key = name.lower()
        share = r.get("mass_share")
        responds = r.get("responds_to_weight", True) is not False
        if not name or key in seen or key in ("more_mass", "less_stiffness"):
            continue
        if responds and (not isinstance(share, (int, float)) or isinstance(share, bool) or not 0.05 <= share <= 0.95):
            continue
        seen.add(key)
        out.append({"name": name, "story": str(r.get("story", ""))[:300], "mass_share": round(float(share), 3) if responds else None, "responds_to_weight": responds})
        if len(out) == most:
            break
    return out


def photo(path: str | Path, longest: int = 1024) -> str:
    """A still as a data URL. For a film, the frame from the middle."""
    import cv2
    p = Path(path)
    if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp"):
        frame = cv2.imread(str(p))
    else:
        cap = cv2.VideoCapture(str(p))
        cap.set(cv2.CAP_PROP_POS_FRAMES, max(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) // 2, 0))
        ok, frame = cap.read()
        cap.release()
        if not ok:
            frame = None
    if frame is None:
        raise ValueError(f"can't read a picture from {path}")
    scale = longest / max(frame.shape[:2])
    if scale < 1:
        frame = cv2.resize(frame, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 88])
    return "data:image/jpeg;base64," + base64.b64encode(buf.tobytes()).decode()


def _parts(text: str, photos: list[tuple[str, str]]) -> str | list:
    if not photos:
        return text
    out: list[dict] = [{"type": "text", "text": text}]
    for label, url in photos:
        out += [{"type": "text", "text": label}, {"type": "image_url", "image_url": {"url": url}}]
    return out


def _ask(role: str, system: str, content, task: str, schema: dict, tries: int = 2) -> tuple[dict, dict]:
    """A fresh, receipted call. An empty or broken reply is asked once more. Muse thinks before it answers, so replies can be cut off."""
    from physica.frontier.meta_council_v026 import _verified
    from physica.llm import meta_client as mc
    last = "no reply"
    for _ in range(tries):
        r = mc.complete(role, [{"role": "system", "content": system}, {"role": "user", "content": content}], task, response_format=schema,
                        max_completion_tokens=16000, require_fresh=True)
        proof = _verified(r, expected_role=role, task=task)
        try:
            if r.get("content"):
                return json.loads(r["content"]), proof
            last = f"no answer (finish_reason: {r.get('finish_reason')})"
        except ValueError as e:
            last = f"unreadable answer: {e}"
    raise RuntimeError(f"Muse gave {last}, twice. Run it again")


def _context(report: dict, parts: dict | None = None) -> dict:
    change = report.get("change") or report
    ctx = {k: change.get(k) for k in ("verdict", "tone_now_hz", "tone_baseline_hz", "reason", "consistent_with_unverified") if change.get(k) is not None}
    if parts:
        ctx["motion_by_part_from_SAM"] = parts.get("parts")
    return ctx


def propose(report: dict, films: tuple[str | None, str | None] = (None, None), parts: dict | None = None, challenge: bool = True) -> dict:
    """Wonder proposes from numbers and photos, then Spark challenges."""
    ctx = _context(report, parts)
    photos = []
    for label, film in (("Photo from a healthy film:", films[0]), ("Photo from the changed film:", films[1])):
        if film and Path(film).exists():
            photos.append((label, photo(film)))
    got, proof = _ask("wonder", SYSTEM, _parts(json.dumps(ctx, default=float), photos), "physica_printer_rivals", SCHEMA)
    raw = got.get("rivals", [])
    rivals = clean(raw)
    reviews, dropped, receipts = [], [], [proof.get("receipt_sha256")]
    if challenge and rivals:
        try:
            review, p2 = _ask("spark", CHALLENGER, json.dumps({"measured": ctx, "ideas": rivals}, default=float), "physica_printer_challenge", CHALLENGE)
            receipts.append(p2.get("receipt_sha256"))
            reviews = review.get("reviews", [])
            drop = {str(r.get("name", "")).lower(): str(r.get("reason", ""))[:300] for r in reviews if r.get("keep") is False}
            dropped = [{**r, "challenge": drop[r["name"].lower()]} for r in rivals if r["name"].lower() in drop]
            rivals = [r for r in rivals if r["name"].lower() not in drop]
        except Exception as e:      # a failed challenge must not stop the experiment. It's recorded, and the ideas go to the test
            reviews = [{"name": "(challenge failed)", "keep": True, "reason": str(e)[:200]}]
    return {"rivals": rivals, "dropped_by_spark": dropped, "reviews": reviews, "proposed": len(raw), "seen_in_photos": str(got.get("seen_in_photos", ""))[:500],
            "photos_sent": len(photos), "receipts_sha256": receipts, "round": 1, "status": "IDEAS_NOT_PROOF"}


def _numbers(value) -> list[float]:
    if isinstance(value, bool):
        return []
    if isinstance(value, (int, float)):
        return [float(value)]
    if isinstance(value, dict):
        return [n for v in value.values() for n in _numbers(v)]
    if isinstance(value, (list, tuple)):
        return [n for v in value for n in _numbers(v)]
    if isinstance(value, str):
        return [float(x) for x in re.findall(r"-?\d+(?:\.\d+)?", value)]
    return []


def check_numbers(text: str, evidence: dict) -> list[float]:
    """Numbers in Muse's words that don't match anything measured. Small counts and percentages of a whole are allowed through only if measured."""
    known = [abs(n) for n in _numbers(evidence)]
    out = []
    for n in re.findall(r"(?<![\w.])-?\d+(?:\.\d+)?", text):
        v = abs(float(n))
        if v in (0, 1, 2, 3, 100):
            continue
        if not any(abs(v - k) <= max(0.02 * k, 0.051) for k in known):
            out.append(float(n))
    return out


def update(report: dict, plan: dict, result: dict, round_no: int = 1) -> dict:
    """Wonder sees the result and revises. Any number it adds that wasn't measured is flagged in the record."""
    evidence = {"measured": _context(report), "tested_ideas": plan.get("muse_rivals"), "weight_added_g": result.get("added_g"),
                "tone_with_weight_hz": result.get("tone_with_weight_hz"), "physica_verdict": result.get("verdict"),
                "physica_reason": result.get("reason"), "forecasts": result.get("rivals")}
    got, proof = _ask("wonder", UPDATER, json.dumps(evidence, default=float), "physica_printer_update", UPDATE)
    text = str(got.get("explanation", ""))[:1200]
    return {"explanation": text, "next_test": str(got.get("next_test", ""))[:400], "rivals": clean(got.get("rivals"), 2), "numbers_not_measured": check_numbers(text, evidence),
            "receipt_sha256": proof.get("receipt_sha256"), "round": round_no + 1, "status": "IDEAS_NOT_PROOF"}


def blind_order(n: int, seed: int) -> list[bool]:
    """For each pair: True means the fixed part is shown as X. Fixed by a seed before any call."""
    return [bool(x) for x in np.random.default_rng(seed).integers(0, 2, n)]


def judge_parts(pairs: list[tuple[str, str]], seed: int) -> dict:
    """Muse judges printed parts without knowing which is which. pairs: (before photo, after photo)."""
    rows = []
    order = blind_order(len(pairs), seed)
    for (before, after), after_is_x in zip(pairs, order):
        x, y = (after, before) if after_is_x else (before, after)
        got, proof = _ask("spark", JUDGER, _parts("Compare these two walls.", [("Wall X:", photo(x)), ("Wall Y:", photo(y))]), "physica_part_judge", JUDGE)
        pick = got.get("less_ringing")
        right = None if pick not in ("X", "Y") else (pick == "X") == after_is_x
        rows.append({"after_shown_as": "X" if after_is_x else "Y", "picked": pick, "picked_the_fixed_part": right, "x_rating": got.get("x_rating"), "y_rating": got.get("y_rating"),
                     "reason": str(got.get("reason", ""))[:300], "receipt_sha256": proof.get("receipt_sha256")})
    return {"pairs": len(rows), "picked_fixed": sum(r["picked_the_fixed_part"] is True for r in rows), "picked_unfixed": sum(r["picked_the_fixed_part"] is False for r in rows),
            "cant_tell": sum(r["picked_the_fixed_part"] is None for r in rows), "rows": rows, "seed": seed}
