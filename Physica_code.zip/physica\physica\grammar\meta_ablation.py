"""STRICT OFFLINE holdout evaluation of ACTUAL externally supplied model outputs.

Cannot automatically call a model or fabricate benefit: paired input/output
records must be independently collected, body-disjoint, same experiment budget,
with immutable evaluation evidence. Comparisons are labelled observational.
"""
import json
import hashlib
from pathlib import Path
import numpy as np


def paired_real_ablation(baseline,meta_on,*,minimum_bodies=3):
    if not baseline or not meta_on:raise ValueError('paired observations required')
    a={r['task_id']:r for r in baseline};b={r['task_id']:r for r in meta_on}
    if len(a)!=len(baseline) or len(b)!=len(meta_on) or set(a)!=set(b):
        raise ValueError('matched unique task IDs required')
    errors={'baseline':[],'meta_on':[]};bodies=set();tasks=[]
    for task in sorted(a):
        x,y=a[task],b[task]
        if x['body_id']!=y['body_id'] or x['independent_truth_sha256']!=y['independent_truth_sha256']:
            raise ValueError('both systems must be evaluated on SAME held-out physical truth')
        if x['experiment_budget']!=y['experiment_budget']:
            raise ValueError('equal intervention budgets required')
        if x.get('calibration_reference_sha256')==x['independent_truth_sha256']:
            raise ValueError('leakage: used calibration truth for final evaluation')
        if y.get('calibration_reference_sha256')==y['independent_truth_sha256']:
            raise ValueError('leakage: meta cross-check used as evaluation ground truth')
        if not y.get('actual_api_response_sha256') or y.get('model_id')=='mock':
            raise ValueError('real model ablation requires recorded authenticated model output')
        for key in ('truth','predicted'):
            if len(x[key])<5 or len(y[key])<5:raise ValueError('need actual held-out traces')
        actual=np.asarray(x['truth'],dtype=float); meta_truth=np.asarray(y['truth'],dtype=float)
        baseline_pred=np.asarray(x['predicted'],dtype=float);meta_pred=np.asarray(y['predicted'],dtype=float)
        if (actual.shape!=baseline_pred.shape or actual.shape!=meta_truth.shape or actual.shape!=meta_pred.shape
            or not all(np.all(np.isfinite(v)) for v in (actual,meta_truth,baseline_pred,meta_pred)) or
            not np.allclose(actual,meta_truth,rtol=0,atol=0)):
            raise ValueError('evaluation targets must match exactly and be finite')
        bodies.add(x['body_id'])
        errors['baseline'].append(float(np.sqrt(np.mean((baseline_pred-actual)**2))))
        errors['meta_on'].append(float(np.sqrt(np.mean((meta_pred-actual)**2))))
        tasks.append(task)
    if len(bodies)<minimum_bodies:raise ValueError('insufficient distinct held-out real bodies')
    improvement=np.asarray(errors['baseline'])-np.asarray(errors['meta_on'])
    return {'status':'observational_meta_ablation_evaluated_not_causal_proof',
        'tasks':tasks,'heldout_bodies':len(bodies),
        'mean_rmse_no_meta':float(np.mean(errors['baseline'])),
        'mean_rmse_with_meta':float(np.mean(errors['meta_on'])),
        'paired_mean_improvement':float(improvement.mean()),
        'meta_better_tasks':int((improvement>0).sum()),
        'caveats':['requires externally collected authenticated responses',
                   'matched observational comparison is not randomized causal evidence',
                   'honest independent heldout truth must not be used for calibration',
                   'must report failed/no-result runs and model API usage']}


def evaluate_files(baseline_path,meta_path,out):
    baseline=json.loads(Path(baseline_path).read_text());meta=json.loads(Path(meta_path).read_text())
    result=paired_real_ablation(baseline['records'],meta['records'])
    Path(out).write_text(json.dumps(result,indent=2)+'\n')
    return result
