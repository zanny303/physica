# Real use cases: what Physica maps, how it acts, what it teaches

## The one problem underneath many industries

Machines and structures are covered in sensors, but a sensor reading changing is not an answer. When a wind
turbine blade, a bridge, a robot arm or a drone vibrates differently, the operator needs to know **why**: damage,
ice, a heavy load, a repair, or just the weather. Today that question is answered by sending people to look, or not
answered at all, because alarms that cry wolf every winter get switched off. The scale of what rides on it:

| Where | What is at stake | Source |
|---|---|---|
| Bridges (US) | 623,218 bridges; 6.8% rated poor; $191.3B of rehabilitation needs; average age about 47 years | [ASCE 2025 Report Card](https://infrastructurereportcard.org/wp-content/uploads/2025/03/Bridges.pdf) |
| Wind turbine blades | about 700,000 blades in operation, about 3,800 blade failures a year, incidents in the order of $1M each (GCube, 2014) | [NS Energy](https://www.nsenergybusiness.com/?p=159246) |
| Wind in cold climates | average production loss in cold weather of 3.9% (about 959 GWh, $113M a year in Canada); ice can be thrown about 225 m | [North American Clean Energy, citing NRCan 2017](https://nacleanenergy.com/articles/29770/monitoring-wind-in-cold-climates) |
| Industry | unplanned downtime estimated at $1.4T a year for the world's largest companies | [Siemens, True Cost of Downtime 2024](https://assets.new.siemens.com/siemens/assets/api/uuid:1b43afb5-2d07-47f7-9eb7-893fe7d0bc59/TCOD-2024_original.pdf) |

The research community names the same bottleneck: separating environmental and operational effects from damage
"remains one of the main challenges to adopt SHM technologies", and is hardest on wind turbines
([EOVmitigation, SMART 2023](https://github.com/josepfontm/EOVmitigation)).

## What Physica does about it, proven on real data

Every row is a real recording from a real machine or structure, scored against ground truth Physica never used.

### 1. Wind farms: ice, crack, or just cold? (E20, real blade)

- **Data:** ETH Zürich's benchmark blade of a Windspot 3.5 kW turbine (1.75 m, 5 kg) in a climate chamber from −15
  to +40 °C, with eight accelerometers. Truth: added masses of 44/88/132 g standing in for ice; cuts growing at
  17/30/50% span to 15 cm each ([Ou et al. 2021](https://doi.org/10.1002/stc.2660)).
- **Maps:** temperature alone moves the blade's tones by 5–9% across the range. Physica learns a per-mode
  temperature law from healthy operation, plus **one deliberate experiment** (a known 44 g mass taped on). It never sees
  ice or cracks. On a separate test campaign: **6% false alarms on the healthy blade vs 69%** for a temperature-blind
  alarm; cracks of 10 cm or more in total found 99% of the time in any weather (the smallest, 5 cm, only 33%); ice
  weighed from vibration at **87 g for a true 88 g** (124 g for 132 g); a 44 g mass mostly goes unnoticed.
- **Acts:** ice → pause and heat, with a sealed promise that the blade will feel healthy again once the ice is gone;
  crack, structural change or can't-tell → stop, lock the rotor blade-down, and fly an inspection drone down the blade
  (an ArduPilot mission that refuses to fly above 120 m or within 10 m of the blade).
- **Re-feels:** every true ice call kept its promise after heating. Four crack groups looked like ice; heating does not
  mend a crack, so their promises broke and Physica stopped instead of restarting. **Zero cracked blades restarted.**
- **Teaches:** one signed card (temperature law, noise, mass fingerprint, rules) that a sister turbine of the same
  model starts from. Learned in the warm months only, it fails in the cold (100% false alarms below 10 °C): a turbine
  has to see a winter, and Physica says so.
- **Honest limits:** one blade, in a lab, shaken by a shaker; the second "turbine" is a separate test campaign on the
  same blade. The pattern thresholds were set while looking at the first campaign. Commercial blade monitors (for
  example [Weidmüller BLADEcontrol](https://resourcecenter.weidmuller.com/wp-content/uploads/2023/06/2550440000_MB_BLADECONTROL_EN_web.pdf))
  already use blade frequencies to detect ice and damage; their methods are not public. Physica's contribution is
  the explainable cause reasoning, the promise-checked actions and the transferable card, in one loop an AI agent can run.

### 2. Smart structures: find the hidden cause, then move it (E16, E22, two real beams)

- **Maps:** a support slides along a steel beam, hidden. Physica rules out mass, cracks and temperature by physics and
  tracks the support at 2.40 mm median error (the dataset authors' published method: 3.37 mm).
- **Acts (manipulates):** a motor next to the beam runs near its tone. Physica tells the beam's own actuator where to move
  the support to stay at least 15% away, and seals the tone it expects. Graded on moments in the real recording when the
  support actually sat there: 2 of 3 checkable promises held (57.0 Hz felt vs 57.6 expected; 63.6 vs 63.5; one broke,
  84.4 vs 80.6).
- **Teaches:** the explanation goes to a second, different beam with no position sensor: r = 0.83 with zero labels;
  7.1 mm with one label vs 25.7 mm learning from scratch.

### 3. Bridges: winter, or a real change? (E21, KW51 railway bridge, run locally)

A steel railway bridge in Leuven, monitored for 15 months and strengthened mid-way. Physica learns each mode's
temperature law (with the freezing jump) from the months before the works and judges every day: weather only, or
changed, and in which direction (tones up can only mean added stiffness or removed mass; tones down, lost stiffness
or added mass). The data (13 MB, CC BY 4.0) is on Zenodo, which this build environment cannot reach; the pipeline is
tested on a labelled synthetic file in the same format, and prior work has already shown temperature compensation on
this bridge, so this is a reproduction target, not a new claim.

### 4. Drones: the inspection drone checks itself (E1, E9, real flights)

The drone that flies to the blade first feels its own propellers: 76% of damage windows felt with no damage data and
0/17 false alarms on a Parrot Bebop 2; the skill carried to a different drone (3DR Solo): 100% felt, 0/17 false
alarms, 8/8 flights.

## What this unlocks

- **Monitoring that doesn't cry wolf.** The single biggest reason vibration monitoring gets ignored is the weather.
  Taking it out per mode, per asset, from healthy operation alone, turns a 69% false-alarm rate into 6% on a real blade.
- **Actions that check themselves.** Every action carries a sealed prediction of what the machine will feel next. When
  the prediction breaks, the system knows it was wrong before anyone restarts anything. That is what kept every cracked
  blade from restarting, even when the first guess said ice.
- **Fleets that learn from one example.** One deliberate experiment (a known mass) or one confirmed event becomes a
  signed card the next turbine, beam or drone starts from, with the conditions it holds under written on it.
- **AI agents that can be trusted with physical systems.** Meta models (or anyone's) can propose causes, senses and
  actions; Physica accepts only what holds up on measurements they never saw, and seals every promise first.

## What comes next (not yet proven)

- A real cold-climate wind farm's SCADA and blade accelerometers (the same pipeline, real ice and real repairs).
- KW51 and the Z24 bridge end to end on real data, and carrying a bridge's temperature card to another bridge.
- Robot arms: telling a collision from a heavier payload from joint friction using the controller's own torque model
  (voraus-AD dataset, CC BY-NC-SA; pipeline in `eval/e10_robot_touch.py`).
- A field test: a turbine or footbridge with accelerometers and a drone, with sealed predictions published before
  each event.
