"""From a felt verdict to machine actions for a wind turbine and its inspection drone, each with a sealed promise.

Turbine commands are written in a small, explicit schema (physica.turbine_command.v1: pause, stop, heat_blades,
resume) that a site adapter maps onto the farm's SCADA (IEC 61400-25 / OPC UA). Physica never sends them itself.
The inspection mission is an ArduPilot / QGroundControl waypoint file (QGC WPL 110, standard MAVLink command IDs)
that flies the drone along the parked blade at a safe stand-off, photographing it. A safety check refuses missions
that would fly above 120 m or closer to the blade than the stand-off.
"""
from __future__ import annotations

import math

from physica import seal as _seal

MAV = {"TAKEOFF": 22, "WAYPOINT": 16, "LOITER_TIME": 19, "RTL": 20, "LAND": 21, "ROI": 195, "CAMERA": 203,
       "ROI_NONE": 197}


def commands(verdict: dict, turbine_id: str) -> dict:
    v = verdict["verdict"]
    if v == "weather only":
        ops = []
    elif v == "ice":
        ops = [{"op": "pause", "reason": "ice-like change"}, {"op": "heat_blades", "until": "sealed promise holds"},
               {"op": "resume", "only_if": "sealed promise holds; otherwise stop and inspect"}]
    else:
        ops = [{"op": "stop", "reason": v}, {"op": "lock_rotor", "blade_down": True},
               {"op": "dispatch_inspection", "mission": "inspection.waypoints"}]
    return {"schema": "physica.turbine_command.v1", "turbine": turbine_id, "verdict": v, "commands": ops,
            "note": "Map to your SCADA with a site adapter. Advice, not a safety certification."}


def ice_promise(verdict: dict, judge_threshold: float) -> dict:
    """Before heating: 'once the ice is gone, every tone will be back on this blade's temperature law'."""
    return _seal.seal({"claim": "after de-icing, the blade feels like its healthy self at this temperature",
                       "test": "change score <= threshold", "threshold": judge_threshold,
                       "felt_before": verdict["residual_pct"], "temp_c": verdict["temp_c"]},
                      "what the blade will feel after heating")


def grade_ice_promise(promise: dict, after: dict) -> dict:
    """after: the judge() result for a group felt after heating."""
    def grade(pred, meas):
        held = meas["change_score"] <= pred["threshold"]
        return {"held": held, "verdict": "promise held: it was ice, safe to resume" if held else
                "promise BROKEN: heating did not bring it back, so it was not ice. Stop and inspect."}
    return _seal.reveal(promise, {"change_score": after["change_score"]}, grade)


def inspection_mission(lat: float, lon: float, heading_deg: float, hub_height_m: float, blade_length_m: float,
                       hub_radius_m: float = 1.5, standoff_m: float = 12.0, step_m: float = 2.0,
                       span: tuple[float, float] = (0.0, 1.0)) -> str:
    """Fly down the parked blade (pointing straight down, rotor facing heading_deg) at stand-off, photographing.

    Launch and landing are at the stand-off point, never at the tower base: the drone climbs, inspects and comes
    down in one column `standoff_m` in front of the rotor. (v0.16 ended with RTL; flown on the real ArduPilot code
    in SITL, RTL brought the drone home to the tower base, straight down past the blade tip. Fixed in v0.17.)
    """
    top = hub_height_m - hub_radius_m - span[0] * blade_length_m
    bottom = hub_height_m - hub_radius_m - span[1] * blade_length_m
    if hub_height_m > 120:
        raise ValueError("refused: mission would fly above 120 m")
    if standoff_m < 10:
        raise ValueError("refused: stand-off under 10 m from the blade")
    if bottom < 5:
        bottom = 5.0
    # point in front of the rotor plane, standoff metres along the heading
    dn = standoff_m * math.cos(math.radians(heading_deg))
    de = standoff_m * math.sin(math.radians(heading_deg))
    plat = lat + dn / 111_320.0
    plon = lon + de / (111_320.0 * math.cos(math.radians(lat)))
    rows = [(0, 1, 0, 16, 0, 0, 0, 0, plat, plon, 0, 1)]  # home = launch point, at stand-off
    i = 1

    def add(cmd, p1, la, lo, alt, frame=3):
        nonlocal i
        rows.append((i, 0, frame, cmd, p1, 0, 0, 0, la, lo, alt, 1))
        i += 1

    add(MAV["TAKEOFF"], 0, plat, plon, min(top, 10.0))
    add(MAV["ROI"], 0, lat, lon, (top + bottom) / 2)
    alt = top
    while alt >= bottom - 1e-6:
        add(MAV["WAYPOINT"], 2, plat, plon, round(alt, 1))  # hold 2 s
        add(MAV["CAMERA"], 0, 0, 0, 0, frame=2)
        alt -= step_m
    add(MAV["ROI_NONE"], 0, 0, 0, 0, frame=2)
    add(MAV["LAND"], 0, plat, plon, 0)  # straight down in the same column, not RTL to a home near the tower
    lines = ["QGC WPL 110"] + ["\t".join(str(round(v, 7) if isinstance(v, float) else v) for v in r) for r in rows]
    return "\n".join(lines) + "\n"
