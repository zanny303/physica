"""Felt body -> a checkable digital twin for simulators and robot training (closing the sim-to-real gap).

The twin is the body's own modes: continuous-time poles (pitch and fade), unit-RMS shapes over the sensed points,
how hard it was shaken when felt, and where it came from. It is small (a few numbers per mode), runs anywhere
(`simulate` is a dozen lines of numpy; the same math is in the demo page's JavaScript), and is CHECKED: given a
real touch it never saw, the twin feels the first 50 ms and must predict the next seconds (R^2 reported).
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from physica.touch.transform import TouchTransform


def export(tt: TouchTransform, provenance: dict | None = None, max_points: int = 200) -> dict:
    modes = []
    amp = getattr(tt, "amp", np.zeros(len(tt.modes)))
    for m, a in zip(tt.modes, amp):
        s = np.log(m.pole) * tt.fs
        step = max(1, len(m.shape) // max_points)
        modes.append({"freq_hz": m.freq_hz, "damping": m.damping, "sigma": float(s.real), "omega_d": float(s.imag),
                      "shape": m.shape[::step].round(5).tolist(), "shape_step": step, "amp_when_felt": float(a)})
    return {"format": "physica.modal_twin/1", "fs": tt.fs, "measure": tt.measure, "channels": int(tt.P), "modes": modes,
            "provenance": provenance or {}, "use": "simulate(twin, taps) or predict_after(twin, Y, i)"}


def save(twin: dict, path: str | Path) -> Path:
    path = Path(path)
    path.write_text(json.dumps(twin, indent=1))
    return path


def simulate(twin: dict, taps: list[tuple[float, int, float]], seconds: float, fs: float | None = None) -> np.ndarray:
    """Displacement-like response (n, points) to taps [(time s, point index, impulse/mass)]."""
    fs = fs or twin["fs"]
    t = np.arange(int(seconds * fs)) / fs
    S = np.array([m["shape"] for m in twin["modes"]])
    out = np.zeros((len(t), S.shape[1]))
    for t0, p, F in taps:
        tau = np.clip(t - t0, 0, None)
        on = t >= t0
        for k, m in enumerate(twin["modes"]):
            q = S[k, p] * F / m["omega_d"] * np.exp(m["sigma"] * tau) * np.sin(m["omega_d"] * tau) * on
            out += q[:, None] * S[k][None, :]
    return out


def predict_after(twin: dict, Y: np.ndarray, i: int, feel_s: float = 0.05, skip_s: float = 0.01,
                  horizon_s: float = 2.0, channel: int = 0) -> dict:
    """The check: feel `feel_s` after a real touch at sample i, then predict `horizon_s` with the twin alone."""
    fs = twin["fs"]
    Y = np.asarray(Y, float)
    Y = Y[:, None] if Y.ndim == 1 else Y
    a0, a1 = i + int(skip_s * fs), i + int((skip_s + feel_s) * fs)
    tt_ = (np.arange(a0, a1) - a0) / fs
    cols = []
    for m in twin["modes"]:
        e = np.exp(m["sigma"] * tt_)
        cols += [e * np.cos(m["omega_d"] * tt_), e * np.sin(m["omega_d"] * tt_)]
    B = np.stack(cols, 1)
    y = Y[a0:a1, channel] - np.median(Y[:max(i, 1), channel])
    coef = np.linalg.lstsq(B, y, rcond=None)[0]
    n = int(horizon_s * fs)
    t2 = (np.arange(a1, a1 + n) - a0) / fs
    pred = np.zeros(n)
    for k, m in enumerate(twin["modes"]):
        e = np.exp(m["sigma"] * t2)
        pred += coef[2 * k] * e * np.cos(m["omega_d"] * t2) + coef[2 * k + 1] * e * np.sin(m["omega_d"] * t2)
    real = Y[a1:a1 + n, channel] - np.median(Y[:max(i, 1), channel])
    pred = pred[: len(real)]
    r2 = 1 - np.sum((real - pred) ** 2) / np.sum((real - real.mean()) ** 2)
    return {"r2": float(r2), "corr": float(np.corrcoef(real, pred)[0, 1]), "felt_s": feel_s, "predicted_s": len(real) / fs,
            "real": real, "pred": pred}
