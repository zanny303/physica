"""Synthetic *method check*, NOT real-world sensor validation.

Heavy-tailed normal noise and changed operating envelope. Compares simplistic
fixed-z trigger with held-out calibration and measured context. Every seed is
an independent trial with its own calibration; test samples are never reused.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
from physica.unified.uncertainty_v029 import NormalResidualEnvelope


def run(trials=300,seed=2026):
    rng=np.random.default_rng(seed)
    def draw(n):
        return np.abs(rng.normal(size=n)*np.where(rng.random(n)<.18,6.,1.))
    fixed=[]; calibrated=[]; refused=[]; changed=[]
    for k in range(trials):
        train=draw(79)  # 79 calibration runs, never future tests
        env=NormalResidualEnvelope('acc','m/s^2',tuple(map(float,train)), 'a'*64,
               alpha=.1,context_bounds={'rpm':(200.,800.)})
        z=float(draw(1)[0])
        normal={'quantity':'acc','unit':'m/s^2','calibrated':True,'standardized_surprise_z':z}
        fixed.append(z>3)
        decision=env.evaluate(normal,operating_context={'rpm':500})
        calibrated.append(decision['status']=='ANOMALY_CANDIDATE')
        shifted=env.evaluate(normal,operating_context={'rpm':1000})
        refused.append(shifted['status']=='ABSTAIN_OPERATING_DISTRIBUTION_SHIFT')
        altered={'quantity':'acc','unit':'m/s^2','calibrated':True,'standardized_surprise_z':z+6}
        changed.append(env.evaluate(altered,operating_context={'rpm':500})['status']=='ANOMALY_CANDIDATE')
    return {'kind':'SIMULATED_HEAVY_TAIL_NO_REAL_HARDWARE', 'seed':seed,'independent_trials':trials,
            'nominal_alert_fraction':.1,
            'naive_fixed_z_3_normal_alert_fraction':float(np.mean(fixed)),
            'heldout_normal_envelope_alert_fraction':float(np.mean(calibrated)),
            'changed_signal_detection_fraction':float(np.mean(changed)),
            'out_of_range_operating_context_refusal_fraction':float(np.mean(refused)),
            'notes':['Distribution is constructed; low error here is not real calibration',
                     'A false alarm bound assumes exchangeable independent normal calibration and future observations',
                     'Calibrated candidate detection does not certify safety or identify a mechanism']}


def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--trials',type=int,default=300)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args(argv)
    if a.trials<30 or a.trials>10000:p.error('trials must be 30–10000')
    r=run(a.trials)
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(r,indent=2))
    print(json.dumps(r,indent=2))


if __name__=='__main__':main()
