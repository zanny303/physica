# Physica v0.34: film day runbook

Everything below runs on your own computer. Your API key stays there. Nothing here moves a machine: you load the G-code and change the settings yourself, under supervision.

Evidence so far: the printer steps are tested on **simulated** video only, and the Muse steps against a **local stand-in**, not Meta. Until you run them, there are no real printer results and no Muse scores to claim.

## 1. Check the live API (do this first)

```powershell
$env:MODEL_API_KEY = "YOUR_PRIVATE_KEY"
$env:MOCK = "0"
$env:PHYSICA_BUDGET_USD = "15"
python -m physica.frontier.meta_ready_v026 live-smoke --role spark --allow-billed-meta
python -m physica.frontier.meta_ready_v026 live-smoke --role wonder --allow-billed-meta
python -m physica.cli meta doctor
```

`meta doctor` includes the SAM check. Each live call leaves a receipt in `meta_receipts/`. Keep those for the submission.

## 2. Muse with and without senses

```powershell
python -m physica.cli meta senses                       # free preview: no Muse calls
python -m physica.cli meta senses --allow-billed-meta   # 72 live calls on real blade cases
```

If an API error stops the run, fix it and add `--resume`, which keeps the answers you already paid for. Results go to `eval/results/E28_muse_senses.json`.

**How it's scored:** 36 real blade groups, 12 each of healthy, ice and crack, chosen before any answer. Muse sees the same physics background and raw measurements both times, and the second call adds what Physica felt. It doesn't see Physica's verdict unless you pass `--include-verdict`. Report all three arms, whichever way the result goes.

Physica alone scores 23 of 36 on this sample, mostly because it calls only some of the ice cases ice. On all 195 groups it takes the right action 152 times. Muse with senses can beat that, match it, or lose to it.

For a single on-camera question with a real tool call:

```powershell
python -m physica.cli meta ask "Blade group blade_group_001: is this ice, a crack, or just the cold? Use feel_blade."
```

## 3. Film the printer

**Setup, the same for every film:**
- Put the phone on a tripod, not in your hand, and don't touch it between films.
- Use your phone's slow-motion mode, at the highest frame rate it offers.
- Stick a high-contrast mark on the print head. Fine texture helps.
- Point the camera so the moving axis runs **left to right in the frame**. The motion reader only looks horizontally.
- Keep the lighting steady. Don't let the phone refocus or change exposure, if it lets you lock them.

**Make the test motion:**

```powershell
python -m physica.cli printer-video excite --axis X | Out-File -Encoding ascii excite.gcode
```

Review it before running it, with the printer empty and supervised. It runs at 200 mm/s and 3000 mm/s², so check that's safe for your machine. It moves around X = 110 mm, so change that if your bed differs. Film every run from before the first move to after the last stop.

**Crop:** long slow-motion clips are large, so crop to the print head with one of these on the first film. Later films reuse the same crop automatically.
- `--sam "print head"` lets live SAM 3.1 find it. It sends a short clip of about 450 frames around the motion (billed per frame). Check the printed crop against your film. If SAM misses, use `--roi`.
- `--roi x1,y1,x2,y2` crops by hand, in pixels. Leave room for the head's full travel.

### Blind test

```powershell
python -m physica.cli printer-video baseline h1.mp4 h2.mp4 h3.mp4 h4.mp4 --name printer --sam "print head"
```

More films give tighter limits (4–5 is better than 3). If the films disagree by more than 2%, it refuses and tells you to improve the setup.

Then, for each trial, a friend either changes something safely (a known weight on the head, a slightly looser belt) or changes nothing, and doesn't tell you which:

```powershell
python -m physica.cli printer-video compare trial1.mp4 --name printer
python -m physica.cli printer-video reveal --name printer --trial 1 --truth changed
python -m physica.cli printer-video score --name printer
```

`compare` seals its answer before the reveal. `score` lists every trial, so film the misses and the "can't tell" answers too. The tone alone can't tell a heavier head from a looser belt. Only say what changed after a measurement separates them.

**Ask Muse why:** `compare` prints the exact command. It sends only the numbers from that film, and saves the answer to `printer_inquiry.json` for the report.

### Find the cause (the core of the demo)

A lower tone can mean more mass or less stiffness. A known weight separates them, because each cause predicts a different tone once it's on.

**Do this once on the healthy printer, before the blind trials.** You need a known weight that's weighed on a kitchen scale and securely fastened, with nothing loose on a moving head. About 100 g is a good start, and your machine's limits come first.

```powershell
python -m physica.cli printer-video calibrate w1.mp4 w2.mp4 w3.mp4 --name printer --added-g 100 --head-g 350
```

`--head-g` is the print head's weight on a scale, if you can get it (only `teach` needs it). The first thing to look for here is whether the tone falls as expected. If it says this isn't a moving-mass mode, try the other axis or a heavier weight. Effective mass won't exactly match the scale, because belts and pulleys also move.

**After a `compare` trial says "changed":**

```powershell
python -m physica.cli printer-video plan-test --name printer --trial 1 --masses 20,50,100,200
# fasten the chosen weight on top of whatever is already there, then film 3 times
python -m physica.cli printer-video test t1.mp4 t2.mp4 t3.mp4 --name printer --trial 1 --added-g 100
python -m physica.cli printer-video reveal --name printer --trial 1 --truth changed --truth-cause mass --truth-g 60
```

`plan-test` seals both forecasts before the weight goes on, and refuses if none of your weights can settle it. `test` answers mass changed (with grams), stiffness changed (with percent), both, neither, or can't tell. If you get a lot of can't tell, film the baseline and known weight 5 times each and use a heavier weight, within your machine's limits. Check the grams against the kitchen scale on camera.

### Predict a new load before filming it

```powershell
python -m physica.cli printer-video predict --name printer --trial 1 --added-g 60
# fasten that load, film it
python -m physica.cli printer-video grade-predict p1.mp4 --name printer --pred 1
```

Leave out `--trial` to predict from the healthy printer. The result is scored against assuming the tone doesn't change.

### Teach a second printer

```powershell
python -m physica.cli printer-video teach --name printer --out lesson.json
# on printer B: baseline first, then
python -m physica.cli printer-video predict --name printerB --card lesson.json --head-g 300 --added-g 60
python -m physica.cli printer-video grade-predict b1.mp4 --name printerB --pred 1
```

Printer B needs its own baseline, but no known-weight films yet. The result is scored against using B's full head weight with no lesson. Afterward, run `calibrate` on B to check the lesson against B's own measurement. A difference only counts if it holds across several loads, and similar printers are the fair test. Report it even if the lesson doesn't help.

### The report

```powershell
python -m physica.cli printer-video report --name printer --inquiry printer_inquiry.json --out printer_report.html
```

Open it in a browser for the video. It lists every trial and miss. Add `--simulated` if any films are simulated.

### The fix

```powershell
python -m physica.cli printer-video tune before.mp4 --name fix --sam "print head"
# apply the printed M593 or [input_shaper] setting yourself
python -m physica.cli printer-video check after.mp4 --name fix
```

`check` saves its result and prints the command that passes it to Muse. Then print the same part before and after, and show both. A lower pixel reading isn't proof of a better print, so the part itself is your evidence.

**If the video stays noisy:** tape the phone to the moving part and use the accelerometer path, `physica printer excite|solve|check`. You lose the "camera only" claim, but the data is cleaner.

## 4. The other machines

These need no new code, and all of them are in the Studio home page or the commands below.

| Use case | Evidence | How to show it |
|---|---|---|
| Turbine blade | Real lab data. Reproduced from public data, and the saved results ship with this release | Studio → Use cases; `physica meta senses`; `physica outcome "..." --machine turbine` needs the blade data |
| Formula 1 | Real telemetry, saved results and `eval/results/f1/ghost_lap.mp4` | Studio → Race engineer. To rerun: `eval/e24_f1_feel_and_advise.py` (DATA.md) |
| Robot arm | Real recordings, but **no saved result yet** | Download the voraus-AD file (1.1 GB, non-commercial licence, DATA.md), set `PHYSICA_VORAUS_FILE`, run `python eval/e10_robot_touch.py`, and use whatever it reports |
| Steel beam | Real data, saved results | Studio → Accurate and Teaches |
| Drone | Real flights, saved results; inspection mission flown in simulation | Studio → Say the outcome; `eval/results/outcome/sitl_track.png` |
| Guitar video | Real high-speed footage, saved result | `physica auto guitar.mp4 --fps 600` with the clip from DATA.md |
| Fan | Simulated clips only | `physica balance`, or film your own and use that result |

## 5. The world model

```powershell
python -m physica.worldmodel demo                                    # free: finds a hidden law in simulation
python -m physica.worldmodel muse-test                               # free preview
python -m physica.worldmodel muse-test --allow-billed-meta           # 27 live calls: does Muse add anything?
```

Results and limits are in [V034_WORLD_MODEL.md](V034_WORLD_MODEL.md).

## 6. What you can and can't say

| Claim | Status |
|---|---|
| False alarms 6% vs 69% on a real lab blade | Reproduced from the public data in this release's checks |
| Ice 87 g for a true 88 g | True for that case. Also 124 g for 132 g, while the 44 g mass read 81 g and mostly went unnoticed. Show the set, not just the best one |
| Only 9 of 36 ice groups called ice | Say this if you lead with ice. Many others were still stopped and inspected, but 10 passed as weather |
| Printer change detection works | Simulated so far. Your blind-test score is the real result |
| Physica weighs a hidden change, or finds a loose belt | Simulated so far. Real results come from your `test` and `reveal` runs |
| Discovered a new law | No. This is known physics applied to a machine, with rival causes tested by experiment |
| World model discovers laws | Only in simulation so far. On real F1 data, the cars agree on a curve that isn't the textbook law, prediction is a tie, and a lesson only helps a little at very few samples |
| Fully autonomous | No. A person fastens the weight, runs the G-code and applies the setting |
| Muse is better with senses | Unknown until step 2 runs |
| Avoided real downtime | Not established. The blade results are from a lab replay |
