# Physica v0.5.1 — Deep research, Meta integration, and breakthrough-evidence protocol

**Research status:** runnable software, synthetic evaluations, authenticated Meta calls **not executed**, physical hardware **not validated**. The words *candidate*, *conditional*, *unverified*, and *simulation* have their literal meanings. No model or mechanism controls hardware.

## 1. The central scientific thesis

> Physical knowledge is not a video label, a sensor embedding, or a raw waveform. It is an **intervention-conditioned, falsifiable relationship between a physical state, a cause, an action, the observable consequences, and its applicability conditions**. Another machine should receive this relationship despite having different sensors.

A strongly testable contribution is a **selective cross-sensor mechanism transport loop**, combining a learned physical response with three-valued transfer validity and scientific falsification. This integration is a proposed research contribution, *not an established first-of-its-kind algorithm*. A high-scoring hackathon submission must prove it in reality.

### What v0.5 already had

- Independently calibrated sensor observation operators `[x,velocity] → measured native units`.
- CRATE and CIRTE transport, local probes, A→B→C signed field protocol.
- Safe Monte Carlo expected information gain, an unknown-mechanism detector, a partially connected Meta pipeline.

### What v0.5.1 now implements

1. **Signed transfer authorization** bound to source SHA-256, target context, observation calibration, probe metrics/evidence, and numeric transfer policy. Direct `predict_target_sense()` verifies signature and *recomputes* validity. A forged `{"status":"transfer"}` cannot bypass compatibility.
2. **Real probe verification from raw sensor CSV**, not a reported `normalized_response_error` in JSON. The field preparation routine recomputes expected low-force response and compares the independent measured sensor output in its own native units. The main target response remains unread until the later check.
3. **Two-dimensional sensor validity** with checked displacement AND velocity ranges, before assimilation and after accepted updates. This prevents a velocity-sensitive microphone calibration from silently operating beyond its tested domain.
4. **Mechanistic residual search** (`grammar/mechanism_lab.py`): fits bounded candidate force terms to calibrated `(x, v, a, force)` and assesses them on intervention-disjoint held-out experiments. Families include cubic stiffness, quadratic drag, Coulomb friction, and position–velocity coupling. A new term remains a candidate until an independent prospective intervention confirms it. This is inspired by established sparse dynamics identification, not a new physical law.
5. **Muse → physical-model nomination** (`grammar/meta_mechanism.py`): Spark interprets grounded context; Wonder names supported candidate families. Only the independent physical data fit coefficients. Unsupported names abstain. Model hypotheses cannot authorize motor commands.
6. **Official SAM 3.1 parser adapter** (`grammar/meta_sam_official.py`) using `meta_sam_parser.parse_responses_stream`, `video_segmentation_format`, and Meta's streamed Responses protocol, including explicit `response.content_part.done` text-lane handling. No regex over the specialized mask stream is treated as scientific evidence. Existing `sam_video()` now delegates to this adapter. Tracks are pixels only until independently calibrated/cross-checked.
7. **Strict Muse JSON schema** via Responses `text.format`, as documented by Meta. Billed API calls require a local `MODEL_API_KEY` and explicit approval.
8. **Reproducible open-world simulation and isolated Meta-candidate ablation**, with the fixture *clearly labelled* as authored candidate text, not authenticated Meta output.

## 2. Why Meta is necessary to the proposed system

- **Muse Spark 1.3**: watches the actual rig to identify boundary fixture, moving parts, scene changes, confounders, sensor visibility. Its concrete output is a structured, provenance-linked *scene/context hypothesis*—never invented stiffness or force.
- **SAM 3.1**: segments and tracks the actual object at the part level. The proposed scientific contribution requires tracking the *correct* subpart: a wrong tracked region can make a physical hypothesis unidentifiable. Use official parser and external camera calibration; reject motion under camera drift or weak cross-check. Use geometry as a sensor only after verification.
- **Muse Wonder 1.0**: names previously omitted *testable* mechanism candidates, suggests reversible probes and distinguishing observations. The numeric planner ranks them by EIG and risk. Wonder is most valuable when an essential physical hypothesis is absent from a fixed candidate library.
- **V-JEPA 2 / 2-AC**: separate local research model for prediction/visual latent representation, not a hosted `MODEL_API_KEY` physical force sensor. The existing independent held-out readout maps embeddings to physical measurements; do not claim calibrated latent-to-force prediction before fitting/evaluating on real data.
- **Muse Voice Transcribe**: intended for speech instructions, not a substitute for acoustic emission FFT or calibrated microphone pressure. **Muse Image**: optional presentation tool, not scientific evidence. **Muse Glimmer**: optional low-latency on-device descriptions, not required for a real-time safety controller.

### What to measure in a proper Meta ablation

On *identical* tasks/held-out physical bodies and identical intervention budgets compare:

A. Physical state estimation only, no Meta.
B. + SAM tracked-and-calibrated moving part.
C. + Spark scene context (additional real fixture/confounder recognition).
D. + Wonder's new mechanism nomination (must beat a predeclared fixed dictionary under equal candidate/compute budget).
E. + independently executed V-JEPA embeddings (only after held-out physical calibration).

Metrics: mechanism detection precision/recall, next-action information gain, # supervised target interventions to reach a fixed error, accuracy–coverage and refusal reliability, independent target prediction RMSE, latency, API cost. Keep model calls, raw media, raw sensor files, and independent results together with SHA-256 manifests.

**Do not claim an improvement from a mock Muse reply.** The offline example deliberately shows *how* correct candidate nomination can help. Whether live Muse actually nominates the correct candidate is an unperformed experiment.

## 3. How the new mechanism-search code works

Known force balance under a calibrated second-order model:

`r(t) = mass*a(t) + damping*v(t) + stiffness*x(t) - applied_force(t)`.

If a mechanism is missing, fit a candidate from physical basis functions, for example `r ≈ theta*x^3`. Candidate families are whitelisted so a model cannot inject executable Python. Fit `theta` on two **training interventions** and test its residual error on one **disjoint validation intervention**. A threshold decides whether it is a candidate worth a *prospective* test. No true causality or model completeness is inferred from a retrospective curve fit.

Input must have externally calibrated displacement **m**, velocity **m/s**, acceleration **m/s²**, and applied force **N**, aligned to a common clock. Do not treat a microphone as an acceleration sensor without a reference calibration. Differentiating noisy video can amplify error; prefer actual inertial measurements or uncertainty-propagating smoothing.

**Prior art:** This is related to SINDy, hybrid physical residual modeling and constrained causal system identification. The novel hypothesis is not the polynomial fitting; it is whether a **Meta-proposed context-dependent mechanism can be validated through an intervention, encoded in PEL, and selectively transferred between genuinely different machines/senses with fewer target trials**. That remains to be proven.

## 4. New commands and offline demos

```
pip install -e ".[dev,meta]"  # 'meta' requires internet; tests work offline with [dev]
python examples/v051_research/BUILD_DEMO.py examples/v051_research/demo
python -m physica.cli grammar cirte-mechanism \
    examples/v051_research/demo/interventions_SIMULATED.json \
    --out examples/v051_research/demo/verified_from_cli.json
# On your OWN machine, set MODEL_API_KEY privately and supply genuine test videos:
python -m physica.cli grammar cirte-meta-mechanism-live \
    YOUR_INDEPENDENT_INTERVENTIONS.json YOUR_RIG_VIDEO.mp4 \
    --out YOUR_RESEARCH_OUTPUT.json --allow-billed-meta
```

Open `examples/v051_research/demo/research_lab.html` in a browser. Native A→B→C example from v0.5 is still at `examples/cirte_v05/native_demo/experience_lab.html` (synthetic).

The live command calls real Spark and Wonder if you give it credentials, but **the code has not been exercised against an authenticated API in this environment**. SAM may be invoked from the existing `meta-csg-live` command with the official parser. Its live behavior also requires validation after setup.

## 5. A feasible three-machine physical study (not performed here)

Use three different reversible bending objects with strongly repeatable clamped boundary conditions. Photograph fixture and use camera calibration targets. Record microphone/accelerometer with a synchronized clock. Measure the force using an instrumented load cell; no uncalibrated tap amplitude. Prepare a signed A source word, then use a separate, **predeclared low-force raw CSV** for B to verify transfer applicability. Seal B's main-experiment prediction before measuring B; only then run human-supervised B experiment and archive its raw sensor output. Repeat for C after learning from B. Include deliberately incompatible fourth configuration.

To test *mechanism discovery*, choose benign, controlled perturbations (e.g. a small removable mass versus changed clamp tightness at a safe preset), not uncontrolled structural damage. Select the mechanism family before the target holdout is revealed. Keep a negative result when Meta proposes the wrong cause.

**Measurement/provenance discipline:** trusted independent timestamp or witness; preregistered interventions; unrelated human controls; heldout parts and action amplitudes; confidence intervals and total sample counts; sensor clock drift diagnostics; blind ablation trials. A signing key in the same computer proves integrity but is not an independent witness of chronological order.

## 6. Gaps software cannot close by itself

| Missing requirement | Honest status / needed evidence |
|---|---|
| Real Muse Spark/Wonder + SAM execution | Compatible adapters written, unauthenticated here. Run with owner's own key and record authenticated results. |
| V-JEPA 2 weight execution | Existing calibrated readout is not actual encoder inference. Use official `facebookresearch/vjepa2` on available GPUs and export frozen features; holdout calibration required. |
| Causal discovery outside known dictionary | v0.5.1 tests candidate basis terms on heldout synthetic interventions. No proof for mechanisms outside feature dictionary. |
| Real cross-sensory A→B→C physical demonstration | No real sensor files or witnessed trials available to this session. |
| Five senses | Acoustic/visual/mechanical pathways partially operational in software; smell/taste typed dynamics only, not hardware chemistry identification. |
| Live Meta ablation | No measurements of live model added value. Offline authored fixture is NOT a valid Meta-on comparison. |
| Independently established breakthrough | Existing research covers core pieces. Requires repeated real-world advantages against appropriate SINDy, physics-only, cross-sensor and transfer baselines. |

## 7. Research bibliography / primary documentation checked October 30, 2026

- Official Meta Model API overview: https://dev.meta.ai/docs/overview
- Meta Responses API and structured outputs: https://dev.meta.ai/docs/protocols/responses ; https://dev.meta.ai/docs/structured-output
- Official SAM 3.1 parser: https://dev.meta.ai/docs/sam/client-libraries
- Official SAM Python video cookbook (important stream/text-lane handling): https://github.com/meta-models/meta-model-cookbook/tree/main/07_sam/01_api_basics
- Meta V-JEPA 2 official repository (separately deployed): https://github.com/facebookresearch/vjepa2
- Brunton, Proctor & Kutz, *Discovering governing equations from data by sparse identification of nonlinear dynamical systems*, PNAS (2016): https://doi.org/10.1073/pnas.1517384113
- Higuera et al., *TacX: Multisensory Touch Representations* (CoRL 2025): https://proceedings.mlr.press/v305/higuera25a.html

## 8. What a hackathon score of 9/10 would require

The pasted audit's **6.3/10** is a qualitative estimate, not a measured judge score. Software-only changes can improve code correctness and technical ambition but **cannot credibly replace live Meta-on/Meta-off evidence or an independently measured physical transfer**. Do not claim 9/10 today. A high-8 to 9 quality *conditional* submission would need: successful real sealed A→B prediction, a real Meta-call trace linked to source videos and hypotheses, a heldout Meta-off ablation showing genuine benefit, convincing user-facing 3-minute video, reproducible code, and transparent failure rates. These are milestones, not achievements.

**Suggested submission one-sentence thesis:**

> Physica lets one machine turn a physical encounter into a falsifiable causal lesson that another machine can test, even when their senses and bodies differ. Meta's models supply scene understanding and candidate missing mechanisms; calibrated physics and real experiments decide what survives.
