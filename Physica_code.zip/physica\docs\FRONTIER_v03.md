# Physica v0.3 — Dual-World Causal Residuals + Transferable Experience

## The thesis

**One machine experiences a physical consequence, encodes the causal response as
unit-bearing physical language, and a calibrated compatible machine uses it to
predict a consequence before its own first local test.** A transfer *forecast*
is not an accepted transfer *fact*: each receiving machine must verify locally.

This is an experimental research prototype. The new demo is purely **synthetic**.
Hardware experiments and live Meta-model calls have not been performed here.
No statements of original mathematical discovery or guaranteed hackathon success
are warranted by these results.

## What was implemented in v0.3

- `physica/experience/dual_world.py`: Gaussian predictive disagreement in common
  units, calibrated uncertainty gate, safe action ranking from EIG, risk/cost and
  bounded disagreement. Post-observation Gaussian negative-log-likelihood scores.
- `physica/experience/transport.py`: dimensionless, hashed causal response token,
  boundary/action/modal compatibility and measured-body rescaling; no extrapolation
  and explicit local response verification.
- `physica/experience/frontier_demo.py`: reproducible A→B step-response simulation;
  signed A observation, pre-observation signed B forecast, B reveal, body-C refusal.
- `physica/experience/frontier_ui.py`: interactive offline presentation page.
- `physica/experience/meta_world.py`: configurable Meta Responses API gateway,
  explicit runtime status and calibrated model-artifact ingestion. **No model
  weights or live calls bundled; SAM/V-JEPA integration remains future work.**
- `tests/test_frontier.py`: tests for units, calibration, safety, tampering,
  rescaling, verification and synthetic ablation.
- Original Feel / Touch Transform, Body Map, Body Bank, sensor ingest, printer and
  camera-scale code remains in the repository.

## How to run

```bash
python -m pip install -e '.[dev]'
python -m physica.cli experience frontier-demo --out demo_frontier
python -m physica.cli experience frontier-ablation --out ablation_frontier --seeds 30
python -m physica.cli experience meta-status
pytest -q tests/test_frontier.py tests/test_experience.py
```

Open `demo_frontier/physica_v03_experience_lab.html`. The numbered JSON files
separate prior commitments and later results. Ed25519 signatures give
integrity, not independently trustworthy timestamps. Witness/timestamp the
commitment externally for credible live demonstration.

## What "feeling" means here

An operational cycle, **not** subjective consciousness: calibrated sensor
signal → modal body model → causal prediction → uncertainty/safety check →
committed forecast → external physical action → measured consequence →
innovation/surprise → updated physical episode → transfer to another calibrated
body → receiving-machine local verification. The prototype has verified this
protocol on a synthetic step response only; a machine has not literally felt
pain or experienced a break in the new demo.

## Why the demo is staged this way

**Hero proof (target real hardware):** Machine A and B are two accessible,
low-voltage, guarded mechanical test strips with known forcing, tip displacement,
modal frequencies and stiffness. A observes one safe step; the portable token
contains *dimensionless response*, not its own actuator commands. B supplies
its own calibration. Physica predicts B, commits to a signed number, then B
performs a safe test. Third strip with incompatible boundary is refused.

**Three-minute film:** 0–12 s sealed B result; 12–35 s physical-language thesis;
35–75 s A→B and verified observation; 75–100 s incompatible-C refusal;
100–125 s real Muse/SAM/world-model involvement **only if genuinely live**;
125–150 s validated existing camera-scale and printer applications if live
results are available; 150–175 s single dual-world formula and held-out
measurements; 175–180 s tagline. Do not show simulator outcomes as hardware.

## Experimental gates before a scientific novelty claim

1. Collect calibrated, blinded, repeated source/target trials across several
   body geometries and boundary conditions; distinguish real from simulated.
2. Pre-register target predictions and obtain independent timestamps before
   physically intervening.
3. Evaluate **no transfer**, raw-copy, nearest neighbour, previous PACER prior,
   matched system-ID, and Koopman/shared-latent baseline under equal data budgets.
4. Compare transfer RMSE, 95% interval coverage, false accepts, unsafe actions,
   performance under shifted sensors/loads, and cost / sample efficiency.
5. Evaluate real Meta models through ablations: with and without SAM 3.1 tracks,
   learned visual prior (e.g. V-JEPA 2), and Muse experiment proposal; preserve
   raw model IDs, hashes, calibration data, response metadata, and API version.

The implemented synthetic baseline is naive raw-value reuse. It is intentionally
weak and **not** adequate proof of superiority to existing physics algorithms.

## Optional two-phase real-sensor CSV protocol (new)

This is the path to the real-world proof. No real input dataset has been
collected or validated by the author of this update. A user must provide a
signed **real_sensor** source reveal that contains `observation_sha256`
matching the exact source CSV bytes, plus independently measured physical
calibrations of both bodies (`BodyCalibration` JSON dictionaries). Source and
B response CSVs require columns `time_s,displacement_m` in seconds and metres.
The target *schedule* CSV requires `time_s` only (no B observation yet).

First, before running a test on B:

```bash
python -m physica.cli experience frontier-prepare \
  source_reveal.json source_A.csv calibration_A.json calibration_B.json \
  target_schedule.csv --out prepared_B
```

Publish or externally timestamp the `prepared_B/target_commitment.json` SHA256
before measuring B. Then run the safe, human-authorised physical experiment,
record B's displacement, and check the sealed forecast:

```bash
python -m physica.cli experience frontier-check \
  prepared_B observed_B.csv --out B_final_verification.json
```

`frontier-prepare` **never reads B observations**, and `frontier-check` refuses
altered signed predictions or a modified full forecast. Every action is
sensor-only; the app does not move hardware. If source records are simulation,
uncalibrated, missing a matching raw CSV hash, or action/boundary-incompatible,
it refuses to call them real transfer. The heuristic predicted sigma is *not*
a calibrated interval; collect a held-out uncertainty calibration set before
claiming confidence coverage. See `physica/experience/field_protocol.py`.
