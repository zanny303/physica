"""A twin you can push, built from one tripod film of something that rings, like a clamped ruler.

It measures the tone, how fast it dies away, and how far each pixel swings. One weighed coin at the tip calibrates it. It can then say what a coin anywhere along
the ruler does to the tone, and that forecast is sealed before the real coin goes on. The one-mode law is standard: f = f0 / sqrt(1 + a m phi(s)^2).

The shape, the tone and the decay are measured. A push in the browser has no real force behind it, so its size means nothing. Tone and decay are the claim.
"""
from __future__ import annotations

import base64
from pathlib import Path

import numpy as np

from physica import seal as _seal
from physica.meta import scout as SC
from physica.touch import video


def _tail(V: np.ndarray, fps: float, skip_s: float = 0.15) -> np.ndarray:
    """After the flick: skip the hand and the biggest swings, which add false harmonics, and keep the ring-down."""
    e = np.abs(np.diff(V, axis=0)).mean((1, 2))
    w = max(int(fps * 0.02), 1)
    e = np.convolve(e, np.ones(w) / w, "same")
    start = int(np.argmax(e)) + int(skip_s * fps)
    return V[start:] if len(V) - start >= max(int(2 * fps), 64) else V


def _harmonic_check(y: np.ndarray, fps: float, hz: float) -> float:
    """A big swing makes false tones at multiples of the true one. If a clear peak sits at a half or a third, that's the real tone."""
    from scipy.signal import welch
    f, p = welch(y, fs=fps, nperseg=min(len(y), 1024), detrend="linear")

    def near(x):
        i = np.argmin(np.abs(f - x))
        return float(p[max(i - 2, 0):i + 3].max())
    here = near(hz)
    for k in (3, 2):
        low = hz / k
        if low >= 2 * (f[1] - f[0]) and near(low) > 0.2 * here and near(low) > 20 * np.median(p):
            return low
    return hz


def _decay(y: np.ndarray, fps: float, hz: float) -> float | None:
    """Damping ratio, from how fast the tone's envelope falls."""
    from scipy.signal import butter, hilbert, sosfiltfilt
    band = [max(0.8 * hz, 0.5) / (fps / 2), min(1.2 * hz, 0.45 * fps) / (fps / 2)]
    if not 0 < band[0] < band[1] < 1 or len(y) < 40:
        return None
    env = np.abs(hilbert(sosfiltfilt(butter(2, band, "band", output="sos"), y)))
    t = np.arange(len(env)) / fps
    i0 = int(np.argmax(env))
    good = np.where(env[i0:] > 0.1 * env[i0])[0]
    if len(good) < 8:
        return None
    n = good[-1] + 1
    slope = np.polyfit(t[i0:i0 + n], np.log(env[i0:i0 + n] + 1e-12), 1)[0]
    return round(float(max(-slope, 0) / (2 * np.pi * hz)), 5)


def _calm_start(y: np.ndarray, fps: float, hz: float, level: float = 0.3) -> int:
    """The first frame after which the swing stays below this share of its largest. Zero if that leaves too little to read."""
    from scipy.signal import butter, hilbert, sosfiltfilt
    band = [max(0.8 * hz, 0.5) / (fps / 2), min(1.2 * hz, 0.45 * fps) / (fps / 2)]
    if not 0 < band[0] < band[1] < 1 or len(y) < 40:
        return 0
    env = np.abs(hilbert(sosfiltfilt(butter(2, band, "band", output="sos"), y)))
    above = np.where(env > level * env.max())[0]
    start = int(above[-1]) + 1 if len(above) else 0
    return start if len(y) - start >= max(int(8 * fps / hz), 64) else 0


def read_mode(path: str | Path, fps: float, box=None, pixels: np.ndarray | None = None, long_side: int = 320, most_frames: int = 1500) -> dict:
    """The tone, the decay and the swing of each pixel. Says it can't tell, rather than guess, if no tone stands clear."""
    V0, k = SC.load_region(path, box, most_frames=most_frames, long_side=long_side)
    V = _tail(V0, fps)
    got = SC.read_tone(V, fps, pixels)
    if not got.get("felt"):
        return {"status": "CANT_TELL", "reason": got.get("reason", "no clear tone"), "tone_read": got}
    M = video.motion(V, wavelength=6, sigma=2.5, step=2, keep=0.5, direction=got["direction"])
    Y = SC._without_keyframes(M["signals"].astype(np.float64))
    rows, cols = M["rows"], M["cols"]
    if pixels is not None:
        inside = pixels[rows, cols]
        Y, rows, cols = Y[:, inside], rows[inside], cols[inside]
    U, sv, _ = np.linalg.svd(Y[:, np.linspace(0, Y.shape[1] - 1, min(Y.shape[1], 1500)).astype(int)], full_matrices=False)
    main = U[:, 0] * sv[0]
    hz = _harmonic_check(main, fps, got["tone_hz"])
    damping = _decay(main, fps, hz)
    # The shape comes from the quiet part of the ring-down: big swings go past what phase can follow, which flattens the free end.
    # Compression can wipe out the smallest swings, so if too few pixels still follow the tone, it steps back toward the larger ones.
    choice = None
    for level in (0.3, 0.6, 1.0):
        calm = _calm_start(main, fps, hz, level) if level < 1 else 0
        M = video.motion(V[calm:], wavelength=6, sigma=2.5, step=2, keep=0.5, direction=got["direction"])
        Yc, rc, cc = SC._without_keyframes(M["signals"].astype(np.float64)), M["rows"], M["cols"]
        if pixels is not None:
            inside = pixels[rc, cc]
            Yc, rc, cc = Yc[:, inside], rc[inside], cc[inside]
        t = np.arange(len(Yc)) / fps
        win = np.hanning(len(t))
        swing = (Yc * (np.exp(-2j * np.pi * hz * t) * win)[:, None]).sum(0) * 2 / max(win.sum(), 1e-9)
        ref = np.angle((swing ** 2).sum()) / 2
        phi = (swing * np.exp(-1j * ref)).real
        fit = np.abs(swing)
        # Only pixels that really follow the tone count: compared with their own level at frequencies where nothing is ringing.
        off = np.mean([np.abs((Yc * (np.exp(-2j * np.pi * hz * m * t) * win)[:, None]).sum(0)) for m in (0.71, 1.37, 1.63)], axis=0) * 2 / max(win.sum(), 1e-9)
        keep = fit > 4 * off
        choice = (rc, cc, phi, fit, keep)
        if keep.sum() >= max(200, 0.05 * len(keep)):
            break
    rows, cols, phi, fit, keep = choice
    if keep.sum() < 20:
        keep = fit > 0.05 * np.quantile(fit, 0.98)
    shape = _shape_along_axis(rows[keep], cols[keep], phi[keep] * (1 if np.median(phi[keep]) >= 0 else -1))
    return {"status": "MEASURED", "tone_hz": round(float(hz), 3), "snr": got["snr"], "direction": got["direction"], "damping": damping, "scale": k, "shape": shape, "fps": fps, "pixels": int(keep.sum()),
            "field": _body_field(shape, V.shape[1:]) if shape and (shape.get("fit_vs_points") or 0) >= 0.8 else _field(rows[keep], cols[keep], phi[keep], V.shape[1:]), "frames_read": int(len(V)), "swing_px": round(float(np.quantile(fit[keep], 0.98)) / max(k, 1e-6), 3)}


def _shape_along_axis(rows: np.ndarray, cols: np.ndarray, amp: np.ndarray, bins: int = 24) -> dict | None:
    """How far each point along the body swings, from the fixed end (s=0) to the free end (s=1). Fitted with a clamp's zero slope at s=0."""
    if len(amp) < 20:
        return None
    pts = np.stack([cols, rows], 1).astype(float)
    centre = pts.mean(0)
    _, _, vt = np.linalg.svd(pts - centre, full_matrices=False)
    along = (pts - centre) @ vt[0]
    edges = np.linspace(along.min(), along.max(), bins + 1)
    idx = np.clip(np.searchsorted(edges, along) - 1, 0, bins - 1)
    level = np.array([np.median(amp[idx == i]) if (idx == i).sum() >= 3 else np.nan for i in range(bins)])
    mid = (edges[:-1] + edges[1:]) / 2
    ok = np.isfinite(level)
    if ok.sum() < 6:
        return None
    x, y = mid[ok], level[ok]
    flip = bool(y[:3].mean() > y[-3:].mean())      # the large end is the free end
    if flip:
        x = -x
        order = np.argsort(x)
        x, y = x[order], y[order]
    # Where the clamp sits comes from the swing itself: the fixed end that makes the curve best match a clamped beam of the same length.
    best = None
    for x0 in np.linspace(x[0] - 0.3 * (x[-1] - x[0]), x[0] + 0.5 * (x[-1] - x[0]), 41):
        on = x >= x0
        if on.sum() < 6:
            continue
        s_try = (x[on] - x0) / max(x[-1] - x0, 1e-9)
        b = _beam(s_try)
        gain = float((b @ y[on]) / max(b @ b, 1e-12))
        err = float(((gain * b - y[on]) ** 2).sum() + (y[~on] ** 2).sum())
        if best is None or err < best[0]:
            best = (err, x0, on)
    _, x0, on = best
    x, y = x[on], y[on]
    s = (x - x0) / max(x[-1] - x0, 1e-9)
    A = np.stack([s ** 2, s ** 3, s ** 4], 1)
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    top = float(coef.sum())
    if top <= 0:
        return None
    coef = coef / top
    beam = _beam(s)
    model = A @ coef
    across = (pts - centre) @ vt[1]
    geometry = {"centre": [float(v) for v in centre], "along": [float(v) for v in vt[0]], "across": [float(v) for v in vt[1]], "flip": flip, "x0": float(x0), "x_end": float(x[-1]), "half_width": float(np.quantile(np.abs(across), 0.98))}
    return {"geometry": geometry, "coef": [round(float(c), 4) for c in coef], "s": [round(float(v), 3) for v in s], "phi": [round(float(v) / top, 4) for v in y], "fit_vs_points": round(float(np.corrcoef(model, y)[0, 1]), 3) if len(y) > 2 else None,
            "vs_textbook_beam": round(float(np.corrcoef(model, beam)[0, 1]), 3)}


def _beam(s: np.ndarray) -> np.ndarray:
    """The first bending mode of a clamped beam, from any textbook."""
    b = 1.8751
    sigma = (np.cosh(b) + np.cos(b)) / (np.sinh(b) + np.sin(b))
    y = np.cosh(b * s) - np.cos(b * s) - sigma * (np.sinh(b * s) - np.sin(b * s))
    tip = np.cosh(b) - np.cos(b) - sigma * (np.sinh(b) - np.sin(b))
    return y / tip


def _body_field(shape: dict, hw, width: int = 96) -> dict:
    """The swing as a smooth grid, from the fitted shape: every point of the body moves together, so it bends without tearing."""
    from scipy.ndimage import gaussian_filter
    h, w = hw
    g = shape["geometry"]
    gw, gh = width, max(int(round(width * h / w)), 8)
    yy, xx = np.mgrid[0:gh, 0:gw]
    px, py = (xx + .5) * w / gw - g["centre"][0], (yy + .5) * h / gh - g["centre"][1]
    along = px * g["along"][0] + py * g["along"][1]
    across = px * g["across"][0] + py * g["across"][1]
    x = -along if g["flip"] else along
    s_ = (x - g["x0"]) / max(g["x_end"] - g["x0"], 1e-9)
    c = shape["coef"]
    grid = np.clip(c[0] * s_ ** 2 + c[1] * s_ ** 3 + c[2] * s_ ** 4, 0, 1) * (s_ >= 0)
    soft = (np.abs(across) <= g["half_width"] * 1.5) & (s_ <= 1.06)
    grid = gaussian_filter(grid * soft, 0.8)
    grid = grid / max(float(grid.max()), 1e-9)
    return {"w": gw, "h": gh, "data": [round(float(v), 3) for v in grid.ravel()], "from": "fitted shape"}


def phi_at(shape: dict, s: float) -> float:
    c = shape["coef"]
    return float(c[0] * s ** 2 + c[1] * s ** 3 + c[2] * s ** 4)


def _field(rows, cols, phi, hw, width: int = 96) -> dict:
    """The swing of each part of the picture, smoothed into a small grid the browser can use to bend the real frame."""
    from scipy.ndimage import gaussian_filter
    h, w = hw
    gw, gh = width, max(int(round(width * h / w)), 8)
    num, den = np.zeros((gh, gw)), np.zeros((gh, gw))
    gy, gx = np.clip((rows * gh / h).astype(int), 0, gh - 1), np.clip((cols * gw / w).astype(int), 0, gw - 1)
    np.add.at(num, (gy, gx), phi)
    np.add.at(den, (gy, gx), 1.0)
    sm = gaussian_filter(num, 1.2) / (gaussian_filter(den, 1.2) + 1e-6)
    sm[gaussian_filter(den, 1.2) < 0.02] = 0
    top = max(float(np.quantile(np.abs(sm), 0.995)), 1e-9)
    return {"w": gw, "h": gh, "data": [round(float(v), 3) for v in np.clip(sm / top, -1, 1).ravel()]}


def frame_url(path: str | Path, box=None, longest: int = 640) -> str:
    import cv2
    _, f = SC.still(path)
    if box is not None:
        f = f[box[1]:box[3], box[0]:box[2]]
    k = longest / max(f.shape[:2])
    if k < 1:
        f = cv2.resize(f, None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
    return "data:image/jpeg;base64," + base64.b64encode(cv2.imencode(".jpg", f, [int(cv2.IMWRITE_JPEG_QUALITY), 85])[1].tobytes()).decode()


def learn(films: list[str], fps: float, box=None) -> dict:
    """Several empty flicks. Their spread tells us how far a forecast can be trusted."""
    reads = [read_mode(f, fps, box) for f in films]
    good = [r for r in reads if r["status"] == "MEASURED"]
    if not good:
        return {"status": "CANT_TELL", "reason": reads[0].get("reason"), "reads": reads}
    tones = [r["tone_hz"] for r in good]
    best = max(good, key=lambda r: r["snr"])
    return {"status": "MEASURED", "tones_hz": tones, "tone_hz": round(float(np.median(tones)), 3), "spread_pct": round(100 * float(np.ptp(tones)) / float(np.median(tones)), 2), "damping": best["damping"], "shape": best["shape"],
            "field": best["field"], "direction": best["direction"], "swing_px": best["swing_px"], "fps": fps, "film": str(films[0]), "box": box, "films": [str(f) for f in films], "missed": len(reads) - len(good)}


def calibrate(twin: dict, film: str, coin_g: float, at: float = 1.0) -> dict:
    """One weighed coin. How much a gram at this spot lowers the tone gives the mass the ruler effectively moves."""
    r = read_mode(film, twin["fps"], twin.get("box"))
    if r["status"] != "MEASURED":
        return {"status": "CANT_TELL", "reason": r.get("reason")}
    if r["tone_hz"] >= twin["tone_hz"]:
        return {"status": "CANT_TELL", "reason": f"the coin should lower the tone, but it read {r['tone_hz']} Hz against {twin['tone_hz']} Hz. Film again"}
    a = ((twin["tone_hz"] / r["tone_hz"]) ** 2 - 1) / (coin_g * max(phi_at(twin["shape"], at), 1e-6) ** 2)
    return {"status": "MEASURED", "tone_with_coin_hz": r["tone_hz"], "per_gram": round(float(a), 6), "modal_mass_g": round(1 / float(a), 2), "coin_g": coin_g, "at": at, "drop_pct": round(100 * (1 - r["tone_hz"] / twin["tone_hz"]), 2)}


def forecast(twin: dict, grams: float, at: float) -> float:
    return float(twin["tone_hz"] / np.sqrt(1 + twin["calibration"]["per_gram"] * grams * phi_at(twin["shape"], at) ** 2))


def seal_forecast(twin: dict, grams: float, at: float) -> dict:
    """Written down before the coin goes on. The range comes from how much the same ruler moved between empty flicks."""
    f = forecast(twin, grams, at)
    margin = max(twin["spread_pct"] / 100, 0.002) * twin["tone_hz"]
    return _seal.seal({"grams": grams, "at": at, "forecast_hz": round(f, 3), "range_hz": [round(f - margin, 3), round(f + margin, 3)], "do_nothing_hz": twin["tone_hz"]}, "the tone with this coin at this spot, before it goes on")


def grade(twin: dict, sealed: dict, film: str) -> dict:
    if not _seal.intact(sealed):
        return {"status": "INVALID", "reason": "the seal was edited"}
    r = read_mode(film, twin["fps"], twin.get("box"))
    if r["status"] != "MEASURED":
        return {"status": "CANT_TELL", "reason": r.get("reason")}
    p = sealed["payload"]["prediction"]
    shift = abs(r["tone_hz"] - twin["tone_hz"])
    err = abs(r["tone_hz"] - p["forecast_hz"])
    return {"status": "MEASURED", "forecast_hz": p["forecast_hz"], "measured_hz": r["tone_hz"], "held": bool(p["range_hz"][0] <= r["tone_hz"] <= p["range_hz"][1]), "error_pct_of_tone": round(100 * err / r["tone_hz"], 2), "do_nothing_pct_of_tone": round(100 * shift / r["tone_hz"], 2),
            "error_pct_of_shift": round(100 * err / shift, 1) if shift > 0 else None, "at": p["at"], "grams": p["grams"]}


def weigh(twin: dict, film: str, at: float = 1.0) -> dict:
    """An object it hasn't felt. The tone says how many grams. A kitchen scale then says if that's right."""
    r = read_mode(film, twin["fps"], twin.get("box"))
    if r["status"] != "MEASURED":
        return {"status": "CANT_TELL", "reason": r.get("reason")}
    phi = max(phi_at(twin["shape"], at), 1e-6)
    grams = ((twin["tone_hz"] / r["tone_hz"]) ** 2 - 1) / (twin["calibration"]["per_gram"] * phi ** 2)
    per_hz = 2 * twin["tone_hz"] ** 2 / r["tone_hz"] ** 3 / (twin["calibration"]["per_gram"] * phi ** 2)
    margin = max(twin["spread_pct"] / 100, 0.002) * twin["tone_hz"] * per_hz
    return {"status": "MEASURED", "tone_hz": r["tone_hz"], "grams": round(float(grams), 1), "range_g": [round(float(grams - margin), 1), round(float(grams + margin), 1)], "at": at}
