# Physica v0.8.4: One-place local Studio

## Quickest start on Windows Terminal

From the extracted `physica` folder containing `pyproject.toml`, with the Python 3.12 virtual environment you already created in the outer `physicanew` folder:

```powershell
..\.venv\Scripts\python.exe -m pip install -e ".[dev,video]"
..\.venv\Scripts\python.exe -m physica.studio --open-browser
```

Or, after installation, double-click `RUN_PHYSICA_STUDIO_WINDOWS.bat`. If port 8765 is already in use by a separately launched Lens server, stop that earlier process with Ctrl+C first.

The interface is at **http://127.0.0.1:8765**. Press **Ctrl+C** in Terminal to stop the app. All workflows save files beneath `demo/studio` relative to the extracted project. Python jobs explicitly use UTF-8 to avoid the `cp1252` error previously encountered on Windows.

## Pages

- **Overview** — one-click buttons for a simulated A → B → C feeling demo, synthetic cloud training and Lens.
- **Lab & Feeling** — synthetic feeling demo, prospective signed prediction before outcome generation, cross-machine benchmarks and sensor reliability.
- **Discover & Training** — synthetic pilot, future-sensation regressor, user-supplied recordings (.csv/.mat) and a `manifest.json` with the documented `physica.remote.signals.v1` schema. Body identity is the grouped split unit. No real data is bundled or downloaded. Training results from user data remain user-declared evidence, not witnessed experiments.
- **Lens** — original local browser video ingestion, bounding-box ROI selection and withheld-frame forecast. Units are pixels unless separately calibrated. Retrospective holdouts are **not** prospective real-world experiments.
- **Transfer & PEL** — illustrative target-directed experiment selection; explains cross-embodiment signed lesson and supervised machine-draft mechanisms.
- **Feel Check** — original real-recording drone Feel Check app using the saved *replay results*, rather than live flights.
- **Meta & System** — an offline API readiness checker, selected regression tests, docs and Meta science / coding workflow explanation. No paid Meta calls are initiated by Studio.

## Safety and claims

- All tasks have a fixed command allowlist; users cannot supply arbitrary commands or code to the app.
- No remote-network binding, production deployments, actuator control, autopilot flashing, or automatic machine-configuration application.
- No Meta API keys stored or sent by Studio. The existing CLI supports separate deliberate paid calls if the user configures that independently.
- Real dataset uploads stay on localhost and the local filesystem. The uploader caps each file at 100 MB, only permits .mat/.csv/.json, and refuses silent overwrites.
- Signatures prove local record integrity and source but not truth, independent timing or calibration.
- Synthetic model evaluation and saved replay are **not** proof of a new scientifically validated feeling algorithm.
- The original CLI modules for other specialized functions remain installed and available; not every research experiment is rewritten into an interactive GUI.

## Real sensor manifest (example structure)

This illustrates **format only**, not a dataset. Make at least eight independently recorded rows, three distinct healthy body IDs and three damaged body IDs, with calibration and labels checked against the data provider.

```json
{
  "schema": "physica.remote.signals.v1",
  "origin": "external_recorded",
  "source": "your verified data source",
  "recordings": [
    {"path": "B001_recording.csv", "body_id": "B001", "label": 0,
     "sample_rate_hz": 2048,
     "channels": {"vibration": "vibration", "current": "current"},
     "units": "source-verified units"}
  ]
}
```

For `.mat`, `channels` values are numeric field paths rather than CSV header names. `manifest.json` and the files it names must be uploaded into the same Studio dataset directory. The sample manifest above is intentionally **not sufficient to train**.
