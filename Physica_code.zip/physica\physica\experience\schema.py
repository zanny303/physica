"""Typed, unit-bearing, portable physical experience language: physica.episode/v1.

Schema is intentionally conservative: unknown measurement uncertainty, calibration,
excitation, and verification must be marked unknown, not quietly invented.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
import math


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


class Quantity(Strict):
    value: float
    unit: str = Field(min_length=1)
    sigma: float | None = Field(default=None, ge=0)
    calibration_id: str | None = None

    @field_validator("value", "sigma")
    @classmethod
    def finite(cls, value):
        if value is not None and not math.isfinite(value):
            raise ValueError("quantities must be finite")
        return value


class Sensor(Strict):
    sensor_id: str
    modality: Literal["video", "acceleration", "velocity", "displacement", "force", "audio", "other"]
    sampling_rate_hz: Quantity | None = None
    calibrated: bool = False
    calibration_id: str | None = None
    frame: str = "unspecified"
    sensor_to_body_transform: list[list[float]] | None = None
    note: str | None = None

    @model_validator(mode="after")
    def check_calibration(self):
        if self.calibrated and not self.calibration_id:
            raise ValueError("calibrated sensors require a calibration_id")
        if self.sampling_rate_hz and (self.sampling_rate_hz.unit != "Hz" or self.sampling_rate_hz.value <= 0):
            raise ValueError("sampling rate must be positive Hz")
        return self


class ModalWord(Strict):
    mode_id: str
    frequency: Quantity
    damping_ratio: Quantity
    excitation_level: Quantity | None = None
    shape: list[float] | None = None
    shape_frame: str = "unspecified"
    confidence: float | None = Field(default=None, ge=0, le=1)

    @model_validator(mode="after")
    def check_units(self):
        if self.frequency.unit != "Hz" or self.frequency.value <= 0:
            raise ValueError("frequency must be positive Hz")
        if self.damping_ratio.unit != "1" or not (0 <= self.damping_ratio.value < 1):
            raise ValueError("damping ratio must be in [0,1) and dimensionless")
        if self.excitation_level and self.excitation_level.value < 0:
            raise ValueError("negative excitation level")
        if self.shape is not None and (not self.shape or not all(math.isfinite(x) for x in self.shape)):
            raise ValueError("shape must contain finite values")
        return self


class Action(Strict):
    action_id: str
    action_type: str
    parameters: dict[str, Quantity] = Field(default_factory=dict)
    requested_by: str = "human"
    safety_approved: bool = False
    risk_score: float = Field(default=0, ge=0, le=1)
    irreversible: bool = False


class Hypothesis(Strict):
    hypothesis_id: str
    posterior: float = Field(ge=0, le=1)
    identifiable: bool = False
    assumptions: list[str] = Field(default_factory=list)


class Consequence(Strict):
    observable: str
    predicted: Quantity | None = None
    observed: Quantity | None = None
    severity: float | None = Field(default=None, ge=0, le=1)
    reversible: bool | None = None
    outcome: Literal["pending", "verified", "contradicted", "inconclusive"] = "pending"
    note: str | None = None

    @model_validator(mode="after")
    def compare_units(self):
        if self.predicted and self.observed and self.predicted.unit != self.observed.unit:
            raise ValueError("prediction and observation must have identical units")
        if self.outcome != "pending" and not self.observed:
            raise ValueError("observed quantity required for a concluded outcome")
        return self


class Provenance(Strict):
    origin: Literal["simulation", "real_sensor", "derived", "manual"]
    raw_sha256: str | None = None
    source_uri: str | None = None
    license: str | None = None
    code_version: str = "0.2.0"
    model_ids: list[str] = Field(default_factory=list)
    evidence_note: str = ""

    @field_validator("raw_sha256")
    @classmethod
    def check_hash(cls, v):
        if v is not None and (len(v) != 64 or any(c not in "0123456789abcdef" for c in v)):
            raise ValueError("raw_sha256 must be 64 lower-case hex chars")
        return v


class PhysicalEpisode(Strict):
    schema_id: Literal["physica.episode/v1"] = "physica.episode/v1"
    episode_id: str = Field(min_length=1)
    body_id: str = Field(min_length=1)
    machine_id: str = Field(min_length=1)
    body_class: str = "unknown"
    boundary_class: str = "unknown"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    sensors: list[Sensor] = Field(default_factory=list)
    action: Action
    modal_words: list[ModalWord] = Field(default_factory=list)
    hypotheses: list[Hypothesis] = Field(default_factory=list)
    consequence: Consequence
    provenance: Provenance
    parent_sha256: str | None = None
    annotations: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def probabilities(self):
        if self.hypotheses and not math.isclose(sum(h.posterior for h in self.hypotheses), 1, abs_tol=1e-4):
            raise ValueError("hypothesis posteriors must sum to 1")
        return self
