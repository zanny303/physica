"""Reproducible scientific exhibit. Simulated action interventions; no live Meta call."""
from __future__ import annotations
from datetime import datetime,timezone
import hashlib,json
from pathlib import Path
import numpy as np
from .mechanisms import BASE,CANDIDATES,compare,fit,score
from .simulation import roll,plan,forecast_without_truth
from .transfer import adapt
from .experiments import rank
from .sensors import virtual_sense
from physica.library.sign import sign,verify


def _write(out,name,payload):
    (out/name).write_text(json.dumps(payload,indent=2,allow_nan=False,ensure_ascii=False)+'\n',encoding='utf-8')

def prospective_demo(output,seed=2026,include_candidate=True,nomination=None):
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    A={'id':'A_sound_touch','thermal':.82};B={'id':'B_camera','thermal':.87};C={'id':'C_imu','thermal':.85}
    train=roll(A,seed,'A_train');valid=roll(A,seed+1,'A_validation')
    candidate=nomination or CANDIDATES[2]
    no_meta=compare(train,valid,CANDIDATES[:2],improvement=.08)
    proposed=compare(train,valid,[candidate] if include_candidate else CANDIDATES[:2],improvement=.08)
    source=proposed['model']
    # Frozen choice on a disjoint source validation episode; prospective test is
    # generated only AFTER the selected predictor has been committed.
    from .guarded_feeling import select, evaluate_test
    feeling_choice=select(train,valid)
    latent_metrics={'trained_on':'SOURCE_MACHINE_A_MULTISENSORY_SIGNALS',
                    'selection':'INDEPENDENT_A_VALIDATION_EPISODE',
                    'selected_predictor':feeling_choice.get('selected'),
                    'validation':{k:{key:val for key,val in m.items() if key!='model'}
                                  for k,m in feeling_choice['validation'].items()},
                    'test_seen':False,
                    'caveat':'ARX, PCA latent and persistence are compared on prior validation; not a new foundation world model'}
    _write(out,'00_learned_multisensory_state.json',{'metrics':latent_metrics,
        'models_frozen_after_validation':True})
    # Independent third source episode, NEVER used for training/model selection.
    source_test=roll(A,seed+2,'A_test_after_model_choice')
    latent_metrics['independent_test']=evaluate_test(feeling_choice,source_test)
    B_local=roll(B,seed+11,'B_local',n=38);B_probe=roll(B,seed+12,'B_probe',n=38)
    b_adapt=adapt(source,B_local,B_probe)
    C_local=roll(C,seed+21,'C_local',n=38);C_probe=roll(C,seed+22,'C_probe',n=38)
    c_adapt=adapt(source,C_local,C_probe)
    # Plan known before any held-out target test outcomes are generated.
    plan_b=plan(seed+100,n=100);plan_c=plan(seed+101,n=100)
    signed=[]
    for body,chosen,condition in ((B,b_adapt,plan_b),(C,c_adapt,plan_c)):
        if chosen['choice']=='REFUSE_MECHANISM_MISMATCH':
            signed.append({'body_id':body['id'],'status':'ABSTAIN_MECHANISM_MISMATCH'});continue
        forecast=forecast_without_truth(chosen['model'],condition['initial'],condition)
        payload={'body_id':body['id'],'origin':'SIMULATION','transfer_choice':chosen['choice'],
            'forecast':forecast,'sensor_types':['camera_m','audio_m_per_s'],
            'planned_actions_sha256':hashlib.sha256(np.asarray(condition['u']).tobytes()).hexdigest(),
            'evidence_frozen_before_target_test':True,'issued_by':'local_Physica_not_external_witness',
            'created_at_local_utc':datetime.now(timezone.utc).isoformat()}
        signed.append({'body_id':body['id'],'status':'LOCAL_COMMIT_BEFORE_SIMULATOR_OUTCOME',
                       'payload':payload,'signature':sign(payload)})
    _write(out,'01_model_comparison.json',{'known_candidate_library_no_muse':{k:v for k,v in no_meta.items() if k!='model'},
        'PROPOSED_CANDIDATE_UNVERIFIED_BY_ITSELF':{k:v for k,v in proposed.items() if k!='model'},
        'origin':'SYNTHETIC_ONLY','real_meta_calls':0})
    _write(out,'02_target_probes.json',{'B':{k:v for k,v in b_adapt.items() if k not in ('model','target_only_model')},
                                      'C':{k:v for k,v in c_adapt.items() if k not in ('model','target_only_model')}})
    _write(out,'03_sealed_predictions.json',signed)
    # Target test outcomes are created only after signed predictions exist on disk.
    results=[]
    for body,ad,commit,s in zip((B,C),(b_adapt,c_adapt),signed,(seed+100,seed+101)):
        if 'signature' not in commit:continue
        if not verify(commit['payload'],commit['signature']):raise RuntimeError('signature invalid')
        test=roll(body,s,f'{body["id"]}_sealed_test',n=100)
        yp=np.asarray([r['sensors']['camera_m'] for r in test]);ypa=np.asarray([r['sensors']['audio_m_per_s'] for r in test])
        # Published forecast has one-step offset. Compare t=dt..n*dt against simulator x at next step.
        forecast=commit['payload']['forecast']
        err=float(np.sqrt(np.mean((np.asarray([p['camera_m'] for p in forecast[:-1]])-yp[1:])**2)))
        local=forecast_without_truth(ad['target_only_model'],plan(s,100)['initial'],plan(s,100))
        local_err=float(np.sqrt(np.mean((np.asarray([p['camera_m'] for p in local[:-1]])-yp[1:])**2)))
        results.append({'body':body['id'],'transfer_choice':ad['choice'],'future_camera_rmse_m':err,
                        'target_only_future_camera_rmse_m_same_local_probe_budget':local_err,
                        'forecast_signature_verifies':True,'holdout_truth_generated_after_prediction':True})
    _write(out,'04_revealed_scored_SIMULATION.json',{'results':results,'origin':'SIMULATED_ONLY'})
    # Information-seeking candidate experiment plans without actuation or truth access.
    near=train[:25]
    model1=fit(train,BASE)
    model2=fit(train,BASE+[candidate])
    probes=[{**r,'approved_reversible':True,'risk':.02,'cost':.02,'expected_goal_progress':.1} for r in near]
    planner=rank(probes,[model1,model2],valid[:25])
    _write(out,'05_non_actuating_experiments.json',planner)
    report={'schema':'physica.mace.research.v1','origin':'SIMULATED_ONLY','model':'bounded candidate mechanism search; controlled action-conditioned regression',
            'meta_live_executed':False,'meta_condition_note':('user-supplied nomination requires independent validation' if nomination else 'illustrative candidate authored in source code; NOT generated by Muse'),
            'learned_multisensory_model':latent_metrics,
            'A_missing_mechanism_selected':proposed['selected'],'A_base_validation_rmse':proposed['baseline_validation_rmse'],
            'A_with_candidate_validation_rmse':proposed['selected_validation_rmse'],
            'without_illustrative_candidate_validation_rmse':no_meta['selected_validation_rmse'],
            'targets':results,'experiment_planner_status':planner['status'],
            'fixed_simulator_mechanism_caveat':'Evidence is limited to simulator family and a human-supplied candidate feature',
            'real_experiments':0,'independent_chronology':False}
    _write(out,'RESULT.json',report)
    from .showcase import save as save_showcase
    save_showcase(report,out/'experience_lab.html')
    return report

def run_benchmark(out,seeds=8):
    if seeds<1 or seeds>100:raise ValueError('invalid seed count')
    records=[]
    for s in range(seeds):
        p=Path(out)/f'run_{s:02}';rep=prospective_demo(p,seed=3400+s*131)
        records.append({'seed':s,'A_candidate':rep['A_missing_mechanism_selected'],
                        'A_baseline':rep['A_base_validation_rmse'],'A_proposed':rep['A_with_candidate_validation_rmse'],
                        'targets':rep['targets']})
    targets=[t for r in records for t in r['targets']]
    summary={'origin':'SIMULATED_ONLY','seeds':seeds,'mechanism_selected_fraction':sum(bool(r['A_candidate']) for r in records)/seeds,
        'mean_transfer_rmse_m':float(np.mean([t['future_camera_rmse_m'] for t in targets])) if targets else None,
        'mean_target_only_rmse_m':float(np.mean([t['target_only_future_camera_rmse_m_same_local_probe_budget'] for t in targets])) if targets else None,
        'transfer_win_fraction':sum(t['future_camera_rmse_m']<t['target_only_future_camera_rmse_m_same_local_probe_budget'] for t in targets)/len(targets) if targets else None,
        'accepted_cases':len(targets),'total_cases':seeds*2,'per_seed':records,
        'not_evidence_of_meta_improvement':True}
    _write(Path(out),'BENCHMARK.json',summary);return summary
