"""The final cut, joined from clips already made. It calls no model. python -m physica.film.final [--no-guitar] [--no-older-results]"""
from __future__ import annotations

import argparse
import json
import tempfile
from pathlib import Path

from physica.film import story as T
from physica.outcome import muse_reads as M


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-guitar", action="store_true")
    ap.add_argument("--no-older-results", action="store_true", help="leave out downtime, turbine, F1, Muse's decisions on them, and the results card")
    ap.add_argument("--folder", default="demo_clips")
    a = ap.parse_args()
    out = Path(a.folder)
    order = list(T.ORDER)
    drop = set()
    if a.no_guitar:
        drop |= {"04_guitar_masks.mp4", "05_guitar_feel.mp4"}
    if a.no_older_results:
        drop |= {"06_use_downtime.mp4", "07_use_turbine_and_drone.mp4", "08b_muse_decides.mp4", "10_results_card.mp4"}
    if "08b_muse_decides.mp4" not in drop and M.OUT.exists():
        saved = json.loads(M.OUT.read_text())
        saved["cases"].pop("f1", None)
        with tempfile.TemporaryDirectory() as d:
            real = M.OUT
            M.OUT = Path(d) / "reads.json"
            M.OUT.write_text(json.dumps(saved))
            try:
                T.muse_decides(out / "08b_muse_decides.mp4")
            finally:
                M.OUT = real
    if a.no_guitar:
        T.credits_clip(out / "12_credits.mp4", skip=("Guitar",))
    keep = [n for n in order if n not in drop]
    film = T.whole_film(out, T.within_limit(out, keep))
    i = T.film_info(film)
    print(f"Your film: {film}\nLength: {int(i['frames'] / i['fps'] // 60)}:{int(i['frames'] / i['fps'] % 60):02d}")
    print("Clips: " + ", ".join(n for n in keep if (out / n).exists()))
    if a.no_guitar:
        print("Before you publish, delete clips\\guitar.mp4, so the film isn't in your public repo.")


if __name__ == "__main__":
    main()
