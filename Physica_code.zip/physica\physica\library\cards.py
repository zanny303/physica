"""Knowledge record: signed cards stored as folders (SPEC section 7).

cards/<id>/card.json    the claim and its metadata
cards/<id>/model.json   the model (if any)
cards/<id>/evidence/    plots, metrics, split hashes
cards/<id>/signature.sig  Ed25519 over card.json + digests of model and evidence files
"""
from __future__ import annotations

import datetime as dt
import json
import re
import shutil
import subprocess
from pathlib import Path

from physica import config
from physica.library import sign as S

CARD_TYPES = {"proof", "sense", "fault", "skill", "experiment", "negative"}


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:48]


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def new_card(type: str, claim: str, machine: dict, units: str = "", sensors: list | None = None,
             context: dict | None = None, proven_range: dict | None = None, metrics: dict | None = None,
             parent: str | None = None, changed: list | None = None, tags: list | None = None) -> dict:
    if type not in CARD_TYPES:
        raise ValueError(f"type must be one of {CARD_TYPES}")
    base = _slug(f"{type}-{machine.get('type', '')}-{machine.get('id', '')}-{claim[:24]}")
    return {
        "id": f"{base}-{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d%H%M%S%f')[:-3]}",
        "type": type, "claim": claim, "units": units, "machine": machine, "sensors": sensors or [],
        "context": context or {}, "proven_range": proven_range or {}, "metrics": metrics or {},
        "lineage": {"parent": parent, "changed": changed or []}, "track_record": [],
        "tags": tags or [], "created": now(), "author": "physica", "version": 1,
        "note": "A signature proves origin and integrity, not truth. Truth comes from the proof and arrival checks.",
    }


def card_dir(card_id: str, root: Path | None = None) -> Path:
    return (root or config.CARDS_DIR) / card_id


def _payload(d: Path) -> dict:
    card = json.loads((d / "card.json").read_text())
    files = [p for p in d.rglob("*") if p.is_file() and p.name not in ("card.json", "signature.sig")]
    return {"card": card, "files": {str(p.relative_to(d)): S.digest_files([p])[p.name] for p in sorted(files)}}


def save(card: dict, model: dict | None = None, evidence: dict[str, Path | str | bytes] | None = None,
         root: Path | None = None, git_commit: bool = False) -> Path:
    d = card_dir(card["id"], root)
    d.mkdir(parents=True, exist_ok=True)
    (d / "card.json").write_text(json.dumps(card, indent=1, sort_keys=True))
    if model is not None:
        (d / "model.json").write_text(json.dumps(model, indent=1, sort_keys=True))
    for name, src in (evidence or {}).items():
        dst = d / "evidence" / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        if isinstance(src, (bytes, bytearray)):
            dst.write_bytes(src)
        elif isinstance(src, Path):
            shutil.copyfile(src, dst)
        else:
            dst.write_text(str(src))
    (d / "signature.sig").write_text(S.sign(_payload(d)))
    if git_commit:
        subprocess.run(["git", "add", str(d)], cwd=config.REPO_ROOT, check=False)
        subprocess.run(["git", "commit", "-q", "-m", f"card: {card['id']}"], cwd=config.REPO_ROOT, check=False)
    return d


def load(card_id_or_dir: str | Path, root: Path | None = None, require_valid: bool = True) -> tuple[dict, dict | None]:
    d = Path(card_id_or_dir)
    if not d.exists():
        d = card_dir(str(card_id_or_dir), root)
    ok, why = verify(d)
    if require_valid and not ok:
        raise PermissionError(f"refusing card {d.name}: {why}")
    card = json.loads((d / "card.json").read_text())
    model = json.loads((d / "model.json").read_text()) if (d / "model.json").exists() else None
    return card, model


def verify(d: Path) -> tuple[bool, str]:
    sig = d / "signature.sig"
    if not sig.exists():
        return False, "unsigned"
    if not S.verify(_payload(d), sig.read_text().strip()):
        return False, "signature does not match (tampered or wrong key)"
    return True, "ok"


def add_track_record(card_id: str, check: str, passed: bool, detail: dict | None = None, root: Path | None = None) -> dict:
    d = card_dir(card_id, root)
    card, model = load(d)
    card["track_record"].append({"date": now(), "check": check, "pass": bool(passed), **(detail or {})})
    (d / "card.json").write_text(json.dumps(card, indent=1, sort_keys=True))
    (d / "signature.sig").write_text(S.sign(_payload(d)))
    return card


def new_version(parent: dict, changed: list[str], **updates) -> dict:
    c = json.loads(json.dumps(parent))
    c.update(updates)
    c["version"] = parent.get("version", 1) + 1
    c["lineage"] = {"parent": parent["id"], "changed": changed}
    c["track_record"] = []
    c["created"] = now()
    c["id"] = re.sub(r"-\d{17}$", "", parent["id"]) + "-v" + str(c["version"]) + "-" + \
        dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d%H%M%S%f")[:-3]
    return c


def all_cards(root: Path | None = None, only_valid: bool = True) -> list[dict]:
    out = []
    r = root or config.CARDS_DIR
    if not r.exists():
        return out
    for d in sorted(p for p in r.iterdir() if (p / "card.json").exists()):
        ok, _ = verify(d)
        if ok or not only_valid:
            c = json.loads((d / "card.json").read_text())
            c["_valid"] = ok
            out.append(c)
    return out


def recall(query: str = "", type: str | None = None, machine_type: str | None = None, root: Path | None = None,
           tag: str | None = None, exclude_tag: str | None = None) -> list[dict]:
    q = query.lower().split()
    res = []
    for c in all_cards(root):
        if type and c["type"] != type:
            continue
        if machine_type and c["machine"].get("type") != machine_type:
            continue
        if tag and tag not in c.get("tags", []):
            continue
        if exclude_tag and exclude_tag in c.get("tags", []):
            continue
        text = json.dumps(c).lower()
        if all(w in text for w in q):
            res.append(c)
    return res


def library_counts(root: Path | None = None) -> dict:
    cs = all_cards(root)
    machines = {(c["machine"].get("type"), c["machine"].get("id")) for c in cs}
    units = {(c["machine"].get("id"), c["machine"].get("unit")) for c in cs if c["machine"].get("unit")}
    return {"cards": len(cs), "machines": len(machines), "units": len(units),
            "by_type": {t: sum(c["type"] == t for c in cs) for t in sorted(CARD_TYPES)}}
