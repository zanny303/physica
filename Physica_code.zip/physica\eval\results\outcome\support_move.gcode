; Physica plan, sealed promise 4dac731484064c65
MANUAL_STEPPER STEPPER=support ENABLE=1
MANUAL_STEPPER STEPPER=support SET_POSITION=84.500
MANUAL_STEPPER STEPPER=support MOVE=79.800 SPEED=5 ACCEL=50
G4 P1500
; now listen: the promise says where the tone will be
