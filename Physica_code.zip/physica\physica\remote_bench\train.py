"""Physica Cloud/Remote: grouped, leak-resistant baseline training on measured signals.

Trains *small classical classifiers*, not Muse/V-JEPA/foundation models. Paderborn
recordings are externally supplied, never bundled. Bearing ID is the splitting
unit; all recordings from one bearing must stay in one partition.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.io import loadmat
from scipy.stats import kurtosis
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, balanced_accuracy_score, confusion_matrix

CHANNELS = ('vibration', 'current')
FEATURE_NAMES = ('log_rms', 'log_mad', 'crest', 'kurtosis', 'zero_cross', 'centroid',
                 'peak_frequency', 'band_0', 'band_1', 'band_2', 'band_3', 'band_4')


def _finite_vector(x):
    x = np.asarray(x, dtype=float).reshape(-1)
    if x.size < 128 or not np.all(np.isfinite(x)):
        raise ValueError('each recorded signal requires >=128 finite samples')
    if np.ptp(x) <= 1e-12:
        raise ValueError('constant sensor signal: no physical information')
    return x


def signal_features(x, sample_rate_hz):
    x = _finite_vector(x)
    fs = float(sample_rate_hz)
    if not np.isfinite(fs) or fs <= 0:
        raise ValueError('verified finite positive sampling rate required')
    x = x - np.median(x)
    rms = float(np.sqrt(np.mean(x*x))) + 1e-12
    mad = float(np.median(np.abs(x))) + 1e-12
    n = x.size
    spectrum = np.abs(np.fft.rfft(x*np.hanning(n)))**2
    f = np.fft.rfftfreq(n, d=1/fs)
    spectrum[0] = 0
    total = spectrum.sum()+1e-15
    bands = [float(spectrum[(f >= fs*(lo/2)) & (f < fs*(hi/2))].sum()/total)
             for lo,hi in zip(np.linspace(0,1,7)[:-2], np.linspace(0,1,7)[1:-1])]
    # Avoid unstable large moments on short recordings.
    k = float(np.clip(kurtosis(x, fisher=False, bias=False), 0, 100))
    result = [float(np.log(rms)),float(np.log(mad)),float(np.max(np.abs(x))/rms),k,
              float(np.mean(x[:-1]*x[1:]<0)),float((f*spectrum).sum()/total/(fs/2)),
              float(f[np.argmax(spectrum)]/(fs/2))] + bands
    if len(result) != len(FEATURE_NAMES): raise AssertionError('feature configuration drift')
    if not np.all(np.isfinite(result)): raise ValueError('non-finite signal features')
    return np.array(result,dtype=float)


def _load_mat_field(path, field):
    mat = loadmat(path, squeeze_me=True, struct_as_record=False)
    import re
    parts=re.findall(r'[^.\[\]]+|\[\d+\]', field)
    if not parts or parts[0] not in mat:raise ValueError(f'MAT field {field} not present; inspect field paths first')
    x=mat[parts[0]]
    for p in parts[1:]:
        x = x[int(p[1:-1])] if p.startswith('[') else getattr(x,p)
    return x


def _read_channels(row, root):
    path=(root/row['path']).resolve()
    if not path.is_file() or not path.is_relative_to(root.resolve()):
        raise ValueError('file missing or outside configured dataset root')
    fs=float(row['sample_rate_hz'])
    if not np.isfinite(fs) or fs<=0:raise ValueError('sampling rate missing')
    fields = row['channels']
    if set(fields)!=set(CHANNELS):raise ValueError('both vibration and motor-current required for matched ablation')
    if path.suffix.lower()=='.mat':
        arrays={name:_load_mat_field(path,field) for name,field in fields.items()}
    elif path.suffix.lower()=='.csv':
        import csv
        with path.open(newline='') as f:
            records=list(csv.DictReader(f))
        arrays={name:np.array([float(rec[field]) for rec in records],float) for name,field in fields.items()}
    else:raise ValueError('supported source formats: .mat, .csv')
    lengths=[np.asarray(v).size for v in arrays.values()]
    if len(set(lengths))>1:raise ValueError('cross-sensor lengths differ: explicit synchronization needed')
    features={k:signal_features(v,fs) for k,v in arrays.items()}
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    return features,digest


def read_manifest(manifest_path):
    path=Path(manifest_path).resolve()
    obj=json.loads(path.read_text())
    if obj.get('schema')!='physica.remote.signals.v1':raise ValueError('invalid manifest schema')
    if obj.get('origin') not in ('external_recorded','SIMULATED_TRAINING_PILOT'):
        raise ValueError('recording origin must be explicit')
    rows=obj.get('recordings',[])
    if len(rows)<8:raise ValueError('insufficient independently grouped training recordings')
    groups={}
    feats=[];labels=[];ids=[];hashes=[]
    for row in rows:
        group=str(row['body_id']);label=int(row['label'])
        if label not in (0,1):raise ValueError('labels must be 0/1')
        if group in groups and groups[group]!=label:raise ValueError('one body has conflicting ground truth labels')
        groups[group]=label
        fs, digest=_read_channels(row,path.parent)
        feats.append(np.concatenate([fs[c] for c in CHANNELS]));labels.append(label);ids.append(group);hashes.append(digest)
    if len(hashes)!=len(set(hashes)):
        raise ValueError('duplicate file contents: potential recording-level leakage')
    return obj,np.vstack(feats),np.array(labels),np.array(ids),hashes


def grouped_split(labels,groups,seed):
    rng=np.random.default_rng(seed)
    unique=np.unique(groups)
    train=set(); test=set()
    for label in (0,1):
        matches=[g for g in unique if np.unique(labels[groups==g]).tolist()==[label]]
        if len(matches)<3:raise ValueError('need at least three distinct physical bodies per class')
        rng.shuffle(matches)
        n=max(1,int(np.ceil(.3*len(matches))))
        test.update(matches[:n]);train.update(matches[n:])
    a=np.array([g in train for g in groups]);b=np.array([g in test for g in groups])
    if np.any(a & b) or not np.any(a) or not np.any(b):raise AssertionError('split leakage')
    return a,b,sorted(train),sorted(test)


def _model_train(x_train,y_train,x_test,y_test,indices):
    scaler=StandardScaler().fit(x_train[:,indices])
    x=scaler.transform(x_train[:,indices]);xt=scaler.transform(x_test[:,indices])
    classifier=LogisticRegression(max_iter=2000,class_weight='balanced',random_state=123).fit(x,y_train)
    p=classifier.predict_proba(xt)[:,1]
    return {'balanced_accuracy':float(balanced_accuracy_score(y_test,p>=.5)),
            'roc_auc':float(roc_auc_score(y_test,p)),
            'confusion_matrix':confusion_matrix(y_test,p>=.5,labels=[0,1]).tolist(),
            'n_features':len(indices),'n_train':len(x_train),'n_test':len(x_test)},\
           {'coef':classifier.coef_.reshape(-1),'intercept':classifier.intercept_,
            'mean':scaler.mean_,'scale':scaler.scale_, 'indices':np.array(indices)}


def train_manifest(manifest,output_dir,seed=21):
    obj,X,y,groups,hashes=read_manifest(manifest)
    a,b,train_ids,test_ids=grouped_split(y,groups,seed)
    output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    result={ 'schema':'physica.remote.grouped_benchmark.v1',
        'origin':obj['origin'],'source_manifest_sha256':hashlib.sha256(Path(manifest).read_bytes()).hexdigest(),
        'trained_model':'logistic_regression_on_recorded_spectral_features',
        'claim_scope':'recorded-signal discrimination, NOT causal intervention or feeling proof',
        'split_method':'disjoint physical body_id (NOT windows or recording IDs)',
        'train_body_ids':train_ids,'test_body_ids':test_ids,'trained_on_actual_external_data':obj['origin']=='external_recorded',
        'sample_rate_and_units_are_source_declared_not_independently_certified':True,
        'baselines':{},'usage':'Held-out body classification; compare sensor ablations only, not physical cause attribution'}
    for name,ids in [('vibration',list(range(len(FEATURE_NAMES)))),
                     ('current',list(range(len(FEATURE_NAMES),2*len(FEATURE_NAMES)))),
                     ('fusion',list(range(2*len(FEATURE_NAMES))))]:
        report,weight=_model_train(X[a],y[a],X[b],y[b],ids)
        result['baselines'][name]=report
        np.savez_compressed(output_dir/f'{name}_weights.npz',**weight)
    (output_dir/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def predict(weights_path, features):
    # Supports safe, purely numeric NPZ; does NOT unpickle arbitrary executables.
    with np.load(weights_path,allow_pickle=False) as w:
        x=np.asarray(features,float)[w['indices']];logit=float(((x-w['mean'])/w['scale'])@w['coef'] + w['intercept'][0]);return float(1/(1+np.exp(-np.clip(logit,-60,60))))


def main():
    parser=argparse.ArgumentParser(description='Grouped real-signal training (no data bundled)')
    parser.add_argument('manifest');parser.add_argument('--out',required=True);parser.add_argument('--seed',type=int,default=21)
    a=parser.parse_args();r=train_manifest(a.manifest,a.out,a.seed)
    print(json.dumps({k:r[k] for k in ('origin','trained_on_actual_external_data','train_body_ids','test_body_ids','baselines')},indent=2))
if __name__=='__main__':main()
