"""Shared evaluation helpers: fixed splits, bootstrap CIs, cached PADRE features."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from physica import config  # noqa: E402
from physica.data import padre  # noqa: E402
from physica.feel.feel_transform import FeelConfig, windows  # noqa: E402
from physica.feel.spectra import band_peak, window_psd  # noqa: E402

SEED = 20261030
CFG = FeelConfig()
SINGLE = {"A": ["1000", "2000", "3000", "4000"], "B": ["0100", "0200", "0300", "0400"],
          "C": ["0010", "0020", "0030", "0040"], "D": ["0001", "0002", "0003", "0004"]}
EDGES = np.linspace(0, 250, 26)


def save_result(name: str, obj: dict) -> Path:
    config.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    p = config.RESULTS_DIR / f"{name}.json"
    p.write_text(json.dumps(obj, indent=1, default=float))
    return p


def boot_ci(x, n: int = 1000, seed: int = SEED, stat=np.mean) -> list[float]:
    x = np.asarray(x, float)
    if len(x) == 0:
        return [float("nan"), float("nan")]
    rng = np.random.default_rng(seed)
    b = [stat(x[rng.integers(0, len(x), len(x))]) for _ in range(n)]
    return [float(np.quantile(b, 0.025)), float(np.quantile(b, 0.975))]


def binom_ci(k: int, n: int, alpha: float = 0.05) -> list[float]:
    """Exact (Clopper-Pearson) interval for a proportion; honest when counts are small (e.g. 0/17)."""
    from scipy.stats import beta
    lo = 0.0 if k == 0 else float(beta.ppf(alpha / 2, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(1 - alpha / 2, k + 1, n - k))
    return [lo, hi]


def cluster_boot_ci(groups: list[np.ndarray], n: int = 1000, seed: int = SEED) -> list[float]:
    """Resample whole files (windows inside one flight are not independent)."""
    rng = np.random.default_rng(seed)
    b = []
    for _ in range(n):
        pick = [groups[i] for i in rng.integers(0, len(groups), len(groups))]
        b.append(np.mean(np.concatenate(pick)))
    return [float(np.quantile(b, 0.025)), float(np.quantile(b, 0.975))]


def padre_features(code: str) -> dict:
    """Per-window features for one flight, cached: op (peak Hz), lvl (log power), bins (log PSD in 25 bins)."""
    cache = ROOT / ".cache" / "features" / f"{code}.npz"
    if cache.exists():
        d = np.load(cache)
        return {k: d[k] for k in d.files}
    rec = padre.load(code)
    wins = windows(rec.acc.shape[0], padre.FS, CFG.win_s)
    f, psd = window_psd(rec.acc, padre.FS, wins, CFG.nperseg)
    op, lvl = band_peak(psd, f, CFG.band)
    bins = np.stack([np.log10(psd[:, :, (f >= lo) & (f < hi)].mean(axis=2) + 1e-12)
                     for lo, hi in zip(EDGES[:-1], EDGES[1:])], axis=2)  # (n_win, 4, 25)
    cache.parent.mkdir(parents=True, exist_ok=True)
    np.savez(cache, op=op, lvl=lvl, bins=bins, f=f, psd=psd)
    return {"op": op, "lvl": lvl, "bins": bins, "f": f, "psd": psd}


def healthy_split() -> dict:
    h = padre_features("0000")
    n = len(h["op"])
    idx = np.arange(n)
    split = {"calib": idx[: n // 2].tolist(), "heldout": idx[n // 2:].tolist(), "window_s": CFG.win_s,
             "note": "PADRE 0000: first half of 5 s windows = calibration (arrival), second half = held-out healthy"}
    p = config.EVAL_DIR / "splits.json"
    p.write_text(json.dumps({"padre_healthy_0000": split}, indent=1))
    return split
