"""Real WAV ingestion without pretending an unknown microphone is a force sensor.

Reports calibrated *timing and spectral features* from raw PCM. Without an
independent transfer function, cannot infer physical displacement or force.
"""
from __future__ import annotations
from pathlib import Path
from scipy.io import wavfile
from scipy.signal import welch, correlate
import hashlib
import numpy as np


def inspect_wav(path,*,min_duration_s=.05):
    raw=Path(path).read_bytes()
    rate,samples=wavfile.read(path)
    if rate<=0 or samples.ndim not in (1,2):raise ValueError('unsupported WAV structure')
    if samples.ndim==2:samples=samples.astype(float).mean(axis=1)
    if np.issubdtype(samples.dtype,np.integer):
        peak=max(abs(np.iinfo(samples.dtype).min),np.iinfo(samples.dtype).max)
        x=samples.astype(float)/peak
    else:x=samples.astype(float)
    if not np.all(np.isfinite(x)) or len(x)<rate*min_duration_s or np.max(np.abs(x))>1.05:
        raise ValueError('invalid WAV amplitude, nonfinite samples or too short')
    clipping=float(np.mean(np.abs(x)>=.995))
    nperseg=min(len(x),max(64,int(rate*.125)))
    freqs,power=welch(x,fs=rate,nperseg=nperseg)
    dominant=float(freqs[np.argmax(power[1:])+1]) if len(freqs)>1 else 0.
    return {'status':'acoustic_features_not_mechanical_measurement',
        'sample_rate_hz':int(rate),'duration_s':float(len(x)/rate),
        'rms_normalized':float(np.sqrt(np.mean(x*x))),'peak_normalized':float(np.max(np.abs(x))),
        'clipped_fraction':clipping,'dominant_frequency_hz':dominant,
        'frequency_bins_hz':freqs.tolist(),'power_spectrum':power.tolist(),
        'raw_sha256':hashlib.sha256(raw).hexdigest(),
        'warning':'Microphone amplitude is not physical force/displacement without independently calibrated transfer function'}

def event_lag(reference_times,reference_values,audio_times,audio_values,*,maximum_lag_s=.5):
    """Estimate an event-marker clock offset; does not calibrate physical amplitude."""
    t=np.asarray(reference_times,dtype=float);a=np.asarray(reference_values,dtype=float)
    ta=np.asarray(audio_times,dtype=float);b=np.asarray(audio_values,dtype=float)
    for x,name in ((t,'reference timestamps'),(ta,'audio timestamps'),(a,'reference'),(b,'audio')):
        if x.ndim!=1 or len(x)<16 or not np.all(np.isfinite(x)):raise ValueError(name+' invalid')
    if len(t)!=len(a) or len(ta)!=len(b) or not all(np.all(np.diff(x)>0) for x in (t,ta)):
        raise ValueError('finite monotonic clocks and samples required')
    if not np.isfinite(maximum_lag_s) or maximum_lag_s<=0:raise ValueError('lag bound invalid')
    dt=max(np.median(np.diff(t)),np.median(np.diff(ta)))
    grid=np.arange(max(t[0],ta[0]),min(t[-1],ta[-1]),dt)
    if len(grid)<16:raise ValueError('insufficient overlapping events')
    x=np.interp(grid,t,a);y=np.interp(grid,ta,b)
    x=np.abs(np.gradient(x));y=np.abs(np.gradient(y))
    x=(x-x.mean())/(x.std()+1e-12);y=(y-y.mean())/(y.std()+1e-12)
    cc=correlate(y,x,mode='full',method='fft')
    lags=np.arange(-len(x)+1,len(x))*dt
    cc[np.abs(lags)>maximum_lag_s]=-np.inf
    i=int(np.argmax(cc));quality=float(cc[i]/len(x))
    if quality<.2:raise ValueError('shared marker event too weak; clock cannot be aligned')
    return {'audio_minus_reference_lag_s':float(lags[i]),'alignment_correlation':quality,
            'requires_independent_event_marker':True,'not_a_physical_amplitude_calibration':True}
