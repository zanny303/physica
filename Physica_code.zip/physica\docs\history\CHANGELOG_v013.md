# Physica v0.13.0 — Agentic Discovery Research Candidate

- Added `agentic_v013`: automatic bounded sine-phase physical hypothesis generation, two independent source validation episodes, test lockbox withheld until sealed B/C target forecasts, matching data-budget target-only structural comparator and refusal path; an experiment planner and an interactive Discovery Theater.
- Added `meta_cycle_v013`: explicit billed Muse Spark/Wonder iterative hypothesis nomination with restricted syntax and numerical validation; no live calls in release.
- Added `prospective_field_v013`: independent prepare and reveal CLI with Ed25519 signed predictions, raw measured CSV SHA-256, time alignment and refusal on tampering; no hardware actuation.
- Changed v0.12.1 `open_world_meta` selection to close the lockbox until final scoring; added test-gated `open_lockbox` option in `unknown_physics`.
- Added live local browser microphone RMS alongside existing optical-motion energy; both uncalibrated, browser local.
- Added new Studio activities, landing-page launch and optional two-round paid Meta scientist test; preserved all old modules, routes and demos.
- Added documentation, critical caveats, tests and research source links.
- **Not performed:** external real-data training, authenticated Meta inference, native glasses app, hardware A→B→C validation, or unbounded autonomous law invention.
