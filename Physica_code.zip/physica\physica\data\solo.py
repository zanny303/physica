"""PADRE 3DR Solo flights: a second, bigger quadcopter (different motors, propellers and rotor speeds).

Uses Range_data CSVs (physical units: accelerometer in g, gyro in deg/s), 500 Hz, 86016 samples (172 s), 4 IMUs
on arms A-D, same layout and file-code convention as the Bebop 2 files (one digit per rotor A B C D, 0 = no fault).
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from physica import config
from physica.data.padre import Recording

FS = 500.0
G = 9.80665
CODES = ["0000", "0001", "0010", "0200", "0201", "0210", "2000", "2001", "2010"]


def range_dir(root: Path | None = None) -> Path:
    base = Path(root) if root else config.padre_dir()
    if base is None:
        raise RuntimeError("Set PHYSICA_PADRE_DIR to the UAV_measurement_data folder (see DATA.md)")
    return base / "3DR_Solo" / "Range_data"


def load(code: str, root: Path | None = None) -> Recording:
    cache = config.REPO_ROOT / ".cache" / "solo" / f"{code}.npy"
    if cache.exists():
        acc = np.load(cache)
    else:
        import pandas as pd

        d = pd.read_csv(range_dir(root) / f"Solo_ACCEL_16g_GYRO_2kdps_range_{code}.csv", dtype="float32")
        acc = np.stack([d[[f"{a}_a{c}" for c in "XYZ"]].to_numpy() for a in "ABCD"], axis=1) * G  # m/s^2
        cache.parent.mkdir(parents=True, exist_ok=True)
        np.save(cache, acc)
    return Recording(code=code, acc=acc, gyro=None, fs=FS)


def damaged_rotors(code: str) -> list[str]:
    return [r for r, c in zip("ABCD", code) if c != "0"]
