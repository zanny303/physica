# Physica v0.34.3: adaptive causal world model

**New (opt-in, in `physica/worldmodel/`)**: Bayesian discovery with a neural check, experiment design, a goal planner that works under doubt, checked transfer, and a test of whether Muse helps. Results and limits are in `docs/V034_WORLD_MODEL.md`. In short: strong on simulated machines. On real F1 data the cars agree on a curve that isn't the textbook law, prediction is a tie, and a lesson only helps a little at very few samples.

**New for the printer**: finds several resonances, shows which one responds to a known weight, and follows a chosen one with `--mode-hz`.

**Fixed**: sealed cause forecasts now commit to the model, its uncertainty, the starting tone and the predictions. Changing any of them after sealing makes the test not count. Verdicts use the sealed numbers, and the rule for choosing a weight is now stated.

**Tested**: no live Meta call and no real printer film were used in this release.

**Added in v0.34.1**: evidence pooled across many machines, measured population priors, a search for products of simple shapes, and a harder experiment test. A rival whose extra term has no real effect no longer counts as a different explanation.

**Fixed in v0.34.3**
- The planner no longer drops an explanation for being rare. Every explanation it holds is checked, and it reports expected success alongside the worst case. If any explanation would break a physical limit, or the plan leaves the measured range under any of them, it says investigate.
- `verified` is now enforced. An explanation moves from Proposed to Validated to Verified only with the matching evidence, and `verify` refuses data already used for fitting or choosing.
- A lesson says `LESSON_APPLIES` only if the source verified it and it predicted separate data from the new machine. Otherwise it stays a starting guess or fails.
- Cost: on the planning benchmark the world model now says act in 17 of 30 runs, down from always. All 17 worked. Run anyway, its plans worked 29 of 30 times, down from 30.
- Printer commands are unchanged.

**Fixed in v0.34.2**
- An explanation the source never settled can no longer pass on as a lesson.
- Printed periodic equations keep their phase.
- Rivals count as the same answer only if they match across the range where the answer will be used.
- Every live explanation always gets a planning draw, the result is graded on a separate larger set, and a plan that fails under one explanation or leaves the measured range means investigate.
- A named explanation must also hold on untouched data in the benchmark, via `final_check`.
- `population_prior` accepts fits or models, and checks the terms match.
