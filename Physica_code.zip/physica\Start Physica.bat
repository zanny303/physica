@echo off
title Physica
cd /d "%~dp0"
set PY=python
if exist ".venv\Scripts\python.exe" set PY=.venv\Scripts\python.exe
if exist "venv\Scripts\python.exe" set PY=venv\Scripts\python.exe
%PY% --version >nul 2>nul
if errorlevel 1 (
  echo Python wasn't found. Install Python 3.12 or newer from python.org, tick "Add Python to PATH", then double-click this file again.
  pause
  exit /b 1
)
if not exist ".physica_installed" (
  echo First run: installing what Physica needs. This takes a few minutes.
  %PY% -m pip install -e .
  if errorlevel 1 (
    echo The install failed. Copy the text above and send it to get it fixed.
    pause
    exit /b 1
  )
  echo done> ".physica_installed"
)
echo.
echo Physica is opening in your browser. Keep this window open while you use it.
echo.
%PY% -m physica.studio --open-browser
echo.
echo Physica stopped. If there's an error above, copy it and send it to get it fixed.
pause
