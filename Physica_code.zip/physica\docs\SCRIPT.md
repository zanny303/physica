# The film (about 2:58)

`python -m physica.cli make-film` makes every clip in `demo_clips`, numbered in film order, and `00_whole_film` joins them. Credit both films on screen. Muse's words are never scripted: the screen shows what it really said. `00_whole_film` leaves out `10_results_card` if the film would run past 2:58. `05b_guitar_twin` is a spare: the string's twin, with a tightened string forecast.

| When | On screen | You say |
|---|---|---|
| 0:00-0:08 | `01_opening` | Nothing. Music, typed on the beat |
| 0:08-0:16 | `02_tacoma_read` | "1940. A bridge twists itself apart on camera. From this old film alone, it feels the twist: 17 cycles a minute." |
| 0:16-0:28 | `03_tacoma_reveal` | "A published count of this video says 18. But a stopwatch on the day said 12, because the film plays fast." If Muse proposed it live: "Muse suspects the film runs at the wrong speed, and the math gives [C]." |
| 0:28-0:44 | `03b_muse_live` | "Give Muse a film it has never seen. It says what it sees and points at the parts, and SAM pins what it pointed at. Then Muse writes the machine's file." Only say what the clip shows |
| 0:44-0:50 | `04_guitar_masks` if it exists | "Each string, pinned by SAM." |
| 0:50-1:07 | `05_guitar_feel` (has its own sound) | "A silent film. The strings look still. But the motion is in the pixels. This string, 81 hertz: you're hearing it, from the pixels. This one, 109. Tuning says 82 and 110." |
| 1:07-1:18 | `05c_beam_twin` | "Now a digital twin. A real beam, hit once, filmed at 10,000 frames a second. From only the first 30 milliseconds, it builds a twin and forecasts what comes next. Then the real motion follows it." |
| 1:18-1:41 | `06_use_downtime` | "Unplanned downtime costs the biggest companies 1.4 trillion dollars a year. Here's a real bearing, running until it dies. The warning came 135 minutes before the end. Across 11 bearings, it warned on 10." |
| 1:41-2:05 | `07_use_turbine_and_drone` | "Cold makes a healthy turbine blade look broken. An old alarm went off 33 times in 48 checks. With feel, 3. A hidden mass gets weighed from vibration. Then nobody climbs: it writes the drone's inspection mission, flown here on ArduPilot's real flight code in its simulator." |
| next | `08b_muse_decides` | "On every real machine, Muse reads what was felt, and decides what to do next." |
| next | `09_machine_files` | If it says "by Muse": "This is the language between the physical world, AI and machines. What was felt goes to Muse as plain numbers. Muse writes the machine's own file: G-code, PLC logic, a drone mission. Code checks it, and failures go back to Muse. A person reviews it." If it says "by code": "What was felt becomes a real machine file: G-code, PLC logic, a drone mission. Each one checked, and a person reviews it." |
| 2:36-2:45 | `09b_type_a_change` | "Or just type a change. It tries every place the support could go, seals each forecast, and tests it on real moments it hasn't seen. Then it writes the file." |
| optional | `10_results_card` | "A hidden support in a steel beam, to 2.4 millimetres. Propeller damage on real flights. All from feel." |
| 2:45-2:51 | `11_ending` | Nothing. Music out |
