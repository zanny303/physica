"""PACER: Physical Active Causal Experience Representation.

Analytical 1D Gaussian likelihoods plus numerical-quadrature expected information
 gain, a separate identifiability guard, and a risk/irreversibility gate. A
 combination of established methods; not a new mathematical transform.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping
import math
import numpy as np


@dataclass(frozen=True)
class Experiment:
    action_id: str
    means: Mapping[str, float]  # predicted measured observable for each hypothesis
    sigma: float             # observation stddev, same units as means
    unit: str = "1"
    risk: float = 0.0
    cost: float = 0.0
    irreversible: bool = False
    safety_approved: bool = True
    note: str = ""

    def __post_init__(self):
        if self.sigma <= 0 or not math.isfinite(self.sigma):
            raise ValueError("positive finite sigma required")
        if not (0 <= self.risk <= 1) or self.cost < 0:
            raise ValueError("invalid risk/cost")
        if any(not math.isfinite(v) for v in self.means.values()):
            raise ValueError("nonfinite action models")


def normalize(prior: Mapping[str, float]) -> dict[str, float]:
    if not prior or any(not math.isfinite(p) or p < 0 for p in prior.values()):
        raise ValueError("prior must contain finite, nonnegative masses")
    tot = sum(prior.values())
    if tot <= 0: raise ValueError("prior has zero mass")
    return {k: v/tot for k, v in prior.items()}


def update(prior: Mapping[str, float], exp: Experiment, observation: float) -> dict[str, float]:
    """Posterior update for actual *observed* value. No LLM-generated measurements."""
    p = normalize(prior)
    if set(p) != set(exp.means): raise ValueError("different hypothesis IDs")
    if not math.isfinite(observation): raise ValueError("observation must be finite")
    scores = {k: math.log(max(v, 1e-300)) - 0.5*((observation-exp.means[k])/exp.sigma)**2 for k,v in p.items()}
    hi = max(scores.values())
    return normalize({k: math.exp(v-hi) for k,v in scores.items()})


def entropy(prior: Mapping[str, float]) -> float:
    return -sum(p*math.log(p) for p in normalize(prior).values() if p > 0)


def expected_information_gain(prior: Mapping[str, float], exp: Experiment, points: int = 1001) -> float:
    """Deterministic quadrature of H(H) - E_y[H(H|y,a)] for a 1D Gaussian mixture."""
    if points < 50: raise ValueError("points >= 50")
    p = normalize(prior)
    if set(p) != set(exp.means): raise ValueError("different hypothesis IDs")
    mu = np.array([exp.means[k] for k in p])
    weights = np.array(list(p.values()))
    x = np.linspace(float(mu.min()-9*exp.sigma),float(mu.max()+9*exp.sigma),points)
    pdf = np.exp(-0.5*((x[:,None]-mu[None,:])/exp.sigma)**2)/(exp.sigma*math.sqrt(2*math.pi))
    terms = pdf*weights[None,:]
    predictive = np.sum(terms,axis=1)
    post = terms/np.maximum(predictive[:,None],1e-300)
    ent = -np.sum(np.where(post>0,post*np.log(np.maximum(post,1e-300)),0.0),axis=1)
    return max(0.0,float(entropy(p) - np.trapezoid(ent*predictive,x)))


def identifiability(prior: Mapping[str,float], observations: list[Experiment], threshold_sigma: float = 1.0,
                    posterior_threshold: float = 0.90) -> dict:
    """Returns 'non_identifiable' if plausible causes cannot be separated under tried actions.

    A large posterior alone is not sufficient: two observationally equivalent
    hypotheses cannot be distinguished, regardless of numeric posterior.
    """
    p = normalize(prior)
    plausible = [k for k,v in p.items() if v > 0.025]
    if len(plausible) <= 1:
        return {"status":"identified", "reason":"only one hypothesis has appreciable posterior"}
    if not observations:
        return {"status":"non_identifiable", "reason":"no interventions/observations supplied"}
    separation = {}
    for i,h in enumerate(plausible):
        for g in plausible[i+1:]:
            if any(h not in e.means or g not in e.means for e in observations):
                raise ValueError("missing hypothesis prediction")
            dist = math.sqrt(sum(((e.means[h]-e.means[g])/e.sigma)**2 for e in observations))
            separation[f"{h}|{g}"] = float(dist)
    closest = min(separation.values(),default=0.0)
    best = max(p.values())
    if closest < threshold_sigma:
        status, why = "non_identifiable", "at least two plausible causes predict near-identical observations"
    elif best < posterior_threshold:
        status, why = "uncertain", "some causes are distinguishable but posterior remains diffuse"
    else:
        status, why = "identified", "evidence separates plausible causes and posterior passed threshold"
    return {"status":status,"reason":why,"minimum_pairwise_sigma":closest,"posterior_max":best,
            "separation":separation}


def choose_experiment(prior: Mapping[str,float], actions: list[Experiment], *, max_risk: float = 0.20,
                      risk_weight: float = 0.1, cost_weight: float = 0.03,
                      irreversible_penalty: float = 1.5) -> dict:
    rows=[]
    for a in actions:
        if not a.safety_approved or a.risk>max_risk or a.irreversible:
            rows.append({"action_id":a.action_id,"status":"rejected_safety"})
            continue
        eig=expected_information_gain(prior,a)
        utility=eig-risk_weight*a.risk-cost_weight*a.cost-irreversible_penalty*float(a.irreversible)
        rows.append({"action_id":a.action_id,"status":"eligible","eig_nats":eig,"utility":utility})
    good=[r for r in rows if r["status"]=="eligible"]
    best=max(good,key=lambda r:r["utility"]) if good else None
    return {"chosen":best["action_id"] if best else None,"ranking":sorted(rows,key=lambda r:r.get("utility",-math.inf),reverse=True),
            "decision":"experiment" if best else "stop_no_safe_experiment"}


def modal_innovations(z: np.ndarray, poles: np.ndarray) -> np.ndarray:
    """E[t,k]=Z[t,k]-pole[k]*Z[t-1,k], first row zero (Touch Transform primitive)."""
    z=np.asarray(z)
    poles=np.asarray(poles)
    if z.ndim!=2 or poles.shape!=(z.shape[1],): raise ValueError("requires [time,modes] and [modes] poles")
    out=np.zeros_like(z,dtype=np.result_type(z,poles,float))
    out[1:]=z[1:]-z[:-1]*poles
    return out


def physical_twin_response(mass_kg: float, stiffness_n_m: float, damping_ratio: float, force_n: float) -> dict:
    """Small-amplitude single-degree-of-freedom analytical prior, NOT universal breakage prediction."""
    if mass_kg<=0 or stiffness_n_m<=0 or not(0<=damping_ratio<1): raise ValueError("invalid mechanical parameters")
    return {"frequency_hz":math.sqrt(stiffness_n_m/mass_kg)/(2*math.pi),
            "static_deflection_m":force_n/stiffness_n_m,"damping_ratio":damping_ratio}
