# Physica v0.28 — Unified Feeling Evidence & Scientific Inquiry

New: `physica.unified` schema, printer/turbine/F1 adapters, conservative cross-domain inquiry engine, approved-probe information-gain planner, live cross-domain Wonder/Spark/Wonder council, strict real-data CSV bridge, read-only `/feel` Studio workbench and 19 new regression checks.

Fixed: legacy v0.27 Muse prompt no longer seeds an example resembling the hidden law; malformed structured output can be retried once; broken live discovery responses now produce an abstention. Printer before/after video check recalibrates the time base and can provide exploratory window-bootstrap error bars.

Still unverified: live authenticated Meta inference on user account, real physical discovery and cross-machine transfer; full legacy repository suite. Nothing in this update permits actuation of printers, aircraft, race cars or industrial turbines.
