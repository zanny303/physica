"""Budget-matched offline simulation of target-directed probe selection.
Design reads only candidate conditions, never held-out acceleration labels.
"""
import argparse,json
from pathlib import Path
import numpy as np
from physica.causal_memory.benchmark import rows
from physica.causal_memory.core import features
from .benchmark import BASE
from .transfer import build_source_prior,_posterior
from .active_probe import rank_probes

def evaluate(seed=250,n_targets=18,budget=5):
    rng=np.random.default_rng(seed)
    sources={f'S{i}':rows(rng,BASE+rng.normal(0,[.008,.008,.008,.12,.01],5),48,f'S{i}') for i in range(10)}
    prior=build_source_prior(sources)
    entries=[]
    for index in range(n_targets):
        coef=BASE+rng.normal(0,[.008,.008,.008,.2,.01],5)
        local=rows(rng,coef,9,f'T{index}')
        pool=[{'state':rng.uniform(-.7,.7,2).tolist(),'action':float(rng.uniform(-1,1))} for i in range(45)]
        future_tasks=[{'state':rng.uniform(-.7,.7,2).tolist(),'action':float(rng.uniform(-1,1))} for i in range(80)]
        design=rank_probes(local,prior,pool,future_tasks,budget=budget)
        # Generate all candidate labels ONCE but conceal them from selector.
        # Two independent training methods receive exactly the same budget.
        response=np.array([features(c['state'],c['action'])@coef+rng.normal(0,.02) for c in pool])
        random_idx=rng.choice(len(pool),budget,replace=False).tolist()
        def fit(idxs):
            prob=[{'state':pool[i]['state'],'action':pool[i]['action'],
                   'acceleration':float(response[i]),'intervention_type':'controlled','body_id':f'T{index}'} for i in idxs]
            return _posterior(local+prob,prior,noise_sd=.02)
        chosen=fit(design['selected_indices']);random=fit(random_idx)
        truth=np.array([features(c['state'],c['action'])@coef for c in future_tasks])
        X=np.stack([features(c['state'],c['action']) for c in future_tasks])
        scores={'selected':float(np.sqrt(np.mean((X@chosen-truth)**2))),
                'random':float(np.sqrt(np.mean((X@random-truth)**2)))}
        entries.append({'target':f'T{index}','scores':scores,'selected_indices':design['selected_indices'],
                       'random_indices':random_idx,'target_tests_seen_during_selection':False})
    return {'origin':'SIMULATED','seed':seed,'targets':n_targets,'source_experiments':len(sources)*48,
            'target_local_experiments':9,'target_probe_budget':budget,
            'mean_rmse':{k:float(np.mean([x['scores'][k] for x in entries])) for k in ('selected','random')},
            'design_wins':int(sum(e['scores']['selected']<e['scores']['random'] for e in entries)),
            'method':'established Bayesian A-optimal target-probe selection, with hierarchical prior',
            'limit':'A synthetic oracle supplies candidate states and a matched mechanics family. Not an autonomous physical experiment.',
            'entries':entries}

def main():
    a=argparse.ArgumentParser();a.add_argument('--out',required=True);a.add_argument('--seed',type=int,default=250);a.add_argument('--targets',type=int,default=18)
    args=a.parse_args();r=evaluate(args.seed,args.targets);p=Path(args.out);p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='entries'},indent=2))
if __name__=='__main__':main()
