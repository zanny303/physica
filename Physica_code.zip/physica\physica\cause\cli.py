"""physica cause: find what changed a body and where, plan the experiment that settles it, carry the explanation.

  physica cause track  FILE --length-mm 352.5 --width-mm 50.8 --thickness-mm 6.35 [--tip-g 55] [--channel NAME]
  physica cause plan   --length-mm 250 --width-mm 25 --thickness-mm 1 --video before.mp4 --coin-g 5 --out seal.json
  physica cause reveal seal.json --video after.mp4          (or --felt f1,f2,f3 instead of a video)
  physica cause apply  CARD.json FILE --length-mm 501 --width-mm 51 --thickness-mm 6.66
  physica cause teach  CARD.json --to http://other-machine:8765
FILE: a CSV/TXT/NPY table (time column first) or a video (the main motion is used).
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from physica import seal as _seal
from physica.cause import discover as D
from physica.cause import intervene as I
from physica.cause import transfer as X
from physica.cause.fe import Beam
from physica.cause.track import track_tone


def _beam(a) -> Beam:
    b = Beam(a.length_mm / 1e3, a.width_mm / 1e3, a.thickness_mm / 1e3, a.material, tip_mass_kg=a.tip_g / 1e3,
             name=Path(getattr(a, "file", "body") or "body").stem)
    if getattr(a, "bare_hz", None):
        b = b.calibrated(a.bare_hz)
    return b


def _signal(path: str, channel: str | None, fps: float | None):
    p = Path(path)
    if p.suffix.lower() == ".json" and "DROPBEAR" in p.name.upper():
        from physica.data import dropbear
        d = dropbear.load_d2(p)
        return d["acc"], d["fs"]
    if p.suffix.lower() == ".txt" and p.read_text(errors="replace")[:4000].find("Low G Accel") >= 0:
        from physica.data import dropbear
        d = dropbear.load_d8(p)
        return d["channels"][channel or "Low G Accel"], d["fs"]
    from physica.sense import load_source
    src = load_source(p, fps)
    Y = np.asarray(src["Y"], float)
    Y = Y[:, None] if Y.ndim == 1 else Y
    if Y.shape[1] == 1:
        return Y[:, 0], src["fs"]
    Yc = Y - Y.mean(0)
    u, s, vt = np.linalg.svd(Yc[:: max(len(Yc) // 4000, 1)], full_matrices=False)
    return Yc @ vt[0], src["fs"]


def _felt(args, n: int = 3) -> list[float]:
    """Tones from --felt, or felt from a video/recording with Physica's own sense."""
    if getattr(args, "felt", None):
        return [float(v) for v in args.felt.split(",")]
    if not getattr(args, "video", None):
        raise SystemExit("give --felt f1,f2,f3 or --video FILE")
    from physica.sense import sense
    out = sense(args.video, fps=args.fps, n_modes=n + 1, watch=False)
    tones = sorted(m["freq_hz"] for b in out.get("bodies", []) for m in (b.get("modes") or []))
    print("felt from", args.video, "->", ", ".join(f"{t:.2f}" for t in tones[:n]), "Hz")
    if len(tones) < n:
        raise SystemExit(f"only {len(tones)} tones felt; film closer, faster, or flick harder")
    return tones[:n]


def _add_beam(ap):
    ap.add_argument("--length-mm", type=float, required=True, help="free length from the clamp")
    ap.add_argument("--width-mm", type=float, required=True)
    ap.add_argument("--thickness-mm", type=float, required=True)
    ap.add_argument("--material", default="steel", choices=["steel", "aluminium", "aluminum", "wood", "plastic"])
    ap.add_argument("--tip-g", type=float, default=0.0, help="mass of a sensor stuck on the tip")
    ap.add_argument("--bare-hz", type=float, help="first tone of the intact body, measured (sets its stiffness)")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="physica cause", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("track")
    t.add_argument("file")
    _add_beam(t)
    t.add_argument("--channel")
    t.add_argument("--fps", type=float)
    t.add_argument("--live", action="store_true", help="answer as if live (0.2 s decision lag)")
    t.add_argument("--out")
    p = sub.add_parser("plan")
    _add_beam(p)
    p.add_argument("--felt", help="first three tones in Hz, comma separated")
    p.add_argument("--video", help="or: a slow-motion video of the flicked body (phone 240 fps is ideal)")
    p.add_argument("--fps", type=float, help="the video's real capture rate if the file says otherwise")
    p.add_argument("--coin-g", type=float, default=5.0)
    p.add_argument("--out", default="sealed_promise.json")
    r = sub.add_parser("reveal")
    r.add_argument("seal")
    r.add_argument("--felt")
    r.add_argument("--video")
    r.add_argument("--fps", type=float)
    a = sub.add_parser("apply")
    a.add_argument("card")
    a.add_argument("file")
    _add_beam(a)
    a.add_argument("--channel")
    a.add_argument("--fps", type=float)
    tc = sub.add_parser("teach")
    tc.add_argument("card")
    tc.add_argument("--to", required=True, help="the other machine's Physica Studio, e.g. http://192.168.1.20:8765")
    args = ap.parse_args(argv)

    if args.cmd == "track":
        b = _beam(args)
        x, fs = _signal(args.file, args.channel, args.fps)
        bare = b.bare(1)[0]
        T, f1 = track_tone(x, fs, (0.5 * bare, 3 * bare), lag_s=0.2 if args.live else None)
        res = D.discover(b, f1)
        print(res["verdict"]["say"])
        for row in res["rivals"]:
            print(f"  {row['rival']:8s} {row['status']:9s} reach {row['reach_hz'][0]:.1f}-{row['reach_hz'][1]:.1f} Hz,"
                  f" felt outside {row['felt_outside_pct']:.0f}%, explains {row['explained_pct']:.0f}%")
        w = res.get("where_mm")
        if w is not None and np.isfinite(w).any():
            q = np.nanpercentile(w, [5, 50, 95])
            print(f"  where (mm from the clamp): 5% {q[0]:.0f} | median {q[1]:.0f} | 95% {q[2]:.0f}")
        if args.out:
            Path(args.out).write_text(json.dumps({**{k: v for k, v in res.items() if not k.startswith("where")},
                                                  "t": T.tolist(), "tone_hz": f1.tolist(),
                                                  "where_mm": None if w is None else np.asarray(w).tolist()}, default=float))
            print("saved", args.out)
    elif args.cmd == "plan":
        b = _beam(args)
        felt = _felt(args)
        inv = I.Investigation(b, args.coin_g / 1e3 / b.mass_kg)
        inv.observe(felt)
        iv, menu = inv.next_experiment(np.random.default_rng(0))
        s = inv.promise(iv)
        _seal.save(s, args.out)
        bl = inv.belief()
        print(f"Belief: {bl['cause']} (confidence {bl['confidence']:.2f})" + (
            f" around {bl['place'] * b.length * 1e3:.0f} mm from the clamp" if bl["place"] is not None else ""))
        for m in menu[:4]:
            print(f"  {m['gain_bits']:.2f} bits  {m['do']}")
        print(f"Do next: {iv.say(b)}")
        print(f"Sealed {args.out} (anchor {s['anchor']}): expect " + ", ".join(
            f"{k} {lo:.1f}-{hi:.1f}" for k, (lo, hi) in s["payload"]["prediction"]["intervals"].items()))
    elif args.cmd == "reveal":
        s = json.loads(Path(args.seal).read_text())
        felt = _felt(args)
        rv = _seal.reveal(s, {f"tone{k + 1}_hz": v for k, v in enumerate(felt)}, _seal.interval_grade)
        print(rv["verdict"])
        for k, row in rv.get("rows", {}).items():
            print(f"  {k}: {row['lo']:.2f}-{row['hi']:.2f}, felt {row['measured']:.2f} {'inside' if row['inside'] else 'OUTSIDE'}")
    elif args.cmd == "apply":
        card = json.loads(Path(args.card).read_text())
        b = _beam(args)
        x, fs = _signal(args.file, args.channel, args.fps)
        out = X.apply_card(card, b, x, fs)
        w = out["where_mm"]
        q = np.nanpercentile(w, [5, 50, 95])
        print(f"Using {card['payload']['cause']} from {card['payload']['source_body']['name']}")
        print(f"  where (mm from the clamp): 5% {q[0]:.0f} | median {q[1]:.0f} | 95% {q[2]:.0f};"
              f" inside the source's experience {100 * np.nanmean(out['inside_experience']):.0f}% of the time")
    elif args.cmd == "teach":
        import urllib.request

        card = json.loads(Path(args.card).read_text())
        env = X.envelope(card)
        req = urllib.request.Request(args.to.rstrip("/") + "/api/receive-card", data=json.dumps(env).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=30) as resp:  # noqa: S310 (address given by the user)
            print(json.dumps(json.loads(resp.read().decode()), indent=1))


if __name__ == "__main__":
    main()
