# Physica v0.8 — Prospective Feeling: reproducible software proof

**Read this before using any result in a hackathon.** Every bundled measurement in this directory is **simulated**. Nothing here represents a performed physical experiment, a live Meta call, a claim of consciousness, or a certified safety controller.

## What changed compared with v0.7

- `physica/feeling/prospective_v08.py` generates a **complete future** state/sensory trajectory using only a calibrated initial state, target body, approved future force waveform, and a signed source mechanism. The target's future displacement, velocity and acceleration are **not inputs**. A separately signed low-force probe gates the transfer. A SHA-256 digest and Ed25519 signature protect the forecast's integrity; an independent observer/time source is still necessary to establish chronology.
- `physica/feeling/sensor_isolation_v08.py` identifies a conflicting channel **only** when a unique, redundant, independently calibrated subset supports the alternative. With two disagreeing sensors it abstains instead of claiming to know which one is faulty.
- `physica/feeling/v08_benchmark.py` benchmarks full **unobserved target future-motion forecasts** against no-correction physics and local-only nonlinear parameter fitting from the **same target probe**. Source transfer incurs **three additional source experiments** (two fitting, one validation); cost not hidden.
- `v08_cli.py` exposes independent forecast, reveal, sensor-isolation, and benchmark commands. It refuses extra fields in forecast requests (especially held-out outcomes).

## Reproduce locally

Python 3.12+ and project dependencies (`pip install -e '.[dev]'`) required.

```bash
python -m physica.feeling.v08_cli benchmark --seed 2026 --trials 12 \
  --out examples/v08_prospective/benchmark_SIMULATED.json
python examples/v08_prospective/BUILD_EXAMPLE.py examples/v08_prospective/demo
python -m physica.feeling.v08_cli forecast \
  examples/v08_prospective/demo/source_lesson_SIMULATED.json \
  examples/v08_prospective/demo/B_forecast_request_NO_OUTCOME.json \
  examples/v08_prospective/demo/B_low_force_probe_certificate_SIMULATED.json \
  --out examples/v08_prospective/demo/B_forecast_SEALED.json
python -m physica.feeling.v08_cli reveal \
  examples/v08_prospective/demo/B_forecast_SEALED.json \
  examples/v08_prospective/demo/B_reveal_HIDDEN_UNTIL_FORECAST.json \
  --out examples/v08_prospective/demo/B_scored_reveal.json
python examples/v08_prospective/BUILD_EXHIBIT.py examples/v08_prospective
pytest -q tests/test_feeling_v080.py tests/test_feeling_v070.py tests/test_predictive_feeling_v060.py
```

The HTML exhibit can be opened offline: `examples/v08_prospective/research_exhibit_SIMULATION.html`.

## Honest results (seed=2026, n=12 synthetic target bodies)

- No nonlinear model: **0.72665 mm** mean target-camera RMSE.
- Conventional local parameter fit, same target probe: **0.01881 mm**.
- Source mechanism transfer, target probe used for compatibility: **0.02823 mm** (12/12 accepted).
- **New hierarchical source + local-probe adaptation: 0.01463 mm** (12/12 accepted).

**Local-only fitting beats raw source-only transport, while the hierarchical source-plus-probe method beats local-only in this model-matched synthetic family.** The hierarchical prior uses a *predeclared for the subsequent test* between-machine coefficient scale of 0.02, which was an exploratory engineering choice and is not field calibrated. On **240 fresh synthetic targets across seeds 2034–2053**, source + probe achieved **0.01852 mm** versus **0.02310 mm** for local-only (about **19.8% lower RMSE**). These are model-conditional results, not proof of general advantage or scientific novelty.

## Moody Makerspace experimental conversion

For an independently approved safe rig with a rigid clamp, lightweight cantilevers, low-force intervention, and independent measurements:

1. Determine each body mass, stiffness and damping using independent measurements; estimate uncertainty. Instrument the initial state and intervention force (do **not** treat a hand tap as a measured force waveform).
2. Record camera and independent static reference with scale and frame timestamps. If using microphone, independently calibrate its acoustic observation operator and clock; frequency peak alone is not a Pa-to-velocity conversion. If no force sensor is available, run a narrower frequency-only study and **do not use the mechanism-discovery acceleration claim**.
3. Collect separate source interventions to fit and validate; archive all raw files, calibration data, hashes, and failures. Collect **one predeclared low-force** target probe for compatibility.
4. Define the main target action and sensor list **before** executing it. Make the forecast with **no target outcomes or measured target trajectory** in the request. Have a human witness/time-stamp forecast commitment externally.
5. Run the target trial supervised, with approved reversible forces. Reveal and score without changing the prediction. Compare with local-only fitting from the same probe and a physics-only model. Repeat on unseen configurations.
6. Run the existing Meta live adapters separately, with owner-provided credentials and explicit billing authorization; archive real model responses. Test SAM-vs-manual tracking and Muse-vs-fixed-dictionary on the **same** held-out tasks.

**No numeric safety controller:** The new modules never command hardware. Software gates are not approval to operate tools or machines; follow makerspace staff instructions.

## Three-demo architecture

- **LAB**: prospective, witnessed camera/acoustic/force sensing on actual equipment.
- **DISCOVER**: held-out real-world video/datasets with observable outcome ground truth and named limits on identifiability.
- **LENS**: a phone/web interface that calls the *same* model and translates only supported physical claims into user-supervised tests. A glasses simulator is a UI mock, not proof of camera data streaming from real glasses.

## Research questions / needed breakthroughs

1. In which physical regimes does cross-machine knowledge actually reduce **target** calibration experiments compared to a strong target-only system ID baseline? Count **source** interventions transparently.
2. Can real, calibrated visual and acoustic sensors improve combined prediction under bias, missing data, clock drift, and nonlinear contact? Validate error-versus-coverage curves.
3. Can authenticated Meta models improve causal-mechanism candidate discovery or sensor selection on independent real videos, in controlled **Meta-on/off ablations**?
4. Can CIRTE select the next **safe** experiment to maximize performance on a *different* machine rather than only the observed source machine? Compare to classical optimal experimental design.

A promising algorithm is not automatically a scientific discovery or hackathon winner. Publish failures and negative baselines.

## Parameter-shift stress and conservative fallback

The `SHIFT_STRESS.py` example tests target nonlinear coefficients **0.22, 0.30, 0.40, 0.50 and 0.80** rather than only small source-like deviations. A low-force probe alone accepts some substantial shifts (0.30–0.50). A new **source–target disagreement check** therefore rejects the source prior when the target's own coefficient is too inconsistent, reverting to local-only fitting rather than forcing an unreliable transfer. The 0.80 case fails the probe entirely. This is model-conditional selective transfer; it is **not an empirically calibrated industrial safety gate**. Run `python examples/v08_prospective/SHIFT_STRESS.py` to reproduce the limitations and fallback decisions.
