# Physica v0.10 MACE — Reproducible Research & Field Guide

## Precisely what is delivered

**Physica Multisensory Active Causal Experience (MACE)** is an evidence-gated research workflow, not a proven universal intelligence or newly discovered law. It integrates the preceding project components with a restricted form of programmatic scientific hypothesis generation.

1. **Learned shared sensory state**: `physica.latent_experience.model` learns a PCA/SVD latent state and action-conditioned ridge dynamics from A's calibrated numeric camera/audio/IMU signals. The new MACE demo trains and evaluates this existing learner on a disjoint A episode. This is **not raw-video-to-general-world-model training**.
2. **Causal response model**: MACE separately fits an action-conditioned acceleration regression from known action, measured position, velocity and available environmental variables. Only recordings with explicitly logged controlled interventions qualify. Measurements are calibrated numeric fields; passive motor current correlations are not equivalent to interventions.
3. **Bounded mechanism discovery**: A linear baseline is compared with user-proposed or **optionally Muse-proposed** restricted feature terms. Candidate must predict an independent episode better by a preregistered threshold. Terms are physically typed by inputs/units, although this code does **not** automatically prove dimensionally consistent causal relationships.
4. **Meta as core hypothesis proposer**: Muse Spark/Wonder may nominate new field/transform combinations not in the limited static candidate set, plus missing measurements and falsifying tests. The proposed term is machine-readable and enters the numerical model-selection algorithm, **not just an explanation panel**. It cannot set learned coefficients, alter measurements, run arbitrary generated code or authorize hardware.
5. **Active physical investigation**: `mace.experiments.rank` scores approved reversible tests using rival-model prediction disagreement, a target-value proxy, desired-goal proxy, cost and risk. Does not actuate hardware. Its heuristic is not a validated optimal experimental-design theorem.
6. **Transfer**: Machine A's candidate model is offered to Machine B/C with distinct local training/probe/test episodes. Probes determine source prior reuse; prospective forecasts are signed before SIMULATED held-out outcomes are generated. It can refuse transfer and report losses.
7. **MACE Lens consumer investigation**: Washing-machine, robotic-arm and 3D-printer modes offer competing explanations and safe follow-ups. The video-based Lens module remains available at the same Studio URL, and relevant contexts can include conservative MACE recommendations. It **cannot diagnose internal failure from a camera alone**.
8. **Machine-only senses**: a registry supports thermal, motor-current, magnetic, ultrasonic, radar, chemical, hyperspectral, tactile and IMU *numerical* inputs under explicit calibration. Virtual estimates are labeled virtual, never measured. No fabricated missing data.
9. **Reviewed machine drafts**: `mace.codegen.from_signed_trace` requires a signed receipt **plus raw CSV**, recomputes the dominant acceleration frequency and checks the hash and claimed result before creating Marlin/Klipper review-only instructions. A signature proves integrity, not honest physical origin. Never executes or flashes code.
10. **Real CSV science route**: typed, time-monotonic controlled-action recordings and raw SHA256 manifest. Distinct episode IDs are required for train, validation and blind test. `field-evaluate` trains parameters from the real supplied fields; it does **not** prove the user-supplied origin labels independently.

## Start locally with Windows Terminal

The ZIP retains the `physica/` top folder. Run from the directory that contains `pyproject.toml`:

```powershell
cd C:\Users\budhw\Downloads\physicanew\physica
$env:PYTHONUTF8 = "1"
..\.venv\Scripts\python.exe -m pip install -e ".[dev,video]"
..\.venv\Scripts\python.exe -m physica.studio --open-browser
```

Open `http://127.0.0.1:8765` and click **MACE Investigation**. Lab, Discover, Lens and earlier Physica modules remain available.

To reproduce without Studio:

```powershell
..\.venv\Scripts\python.exe -m physica.mace.cli demo --out demo\mace
# Open demo\mace\experience_lab.html in your browser.
..\.venv\Scripts\python.exe -m physica.mace.cli benchmark --seeds 8 --out demo\mace_benchmark
..\.venv\Scripts\python.exe -m pytest -q tests\test_mace_v010.py
```

The exhibit labels all simulated results. A real result requires real data and independent controls.

## 1. True Meta integration, rather than a descriptive sidecar

The Meta Model API official structured-output tutorial documents JSON schema on `https://api.meta.ai/v1` with `MODEL_API_KEY`; the current model catalog lists Muse Spark 1.3, Muse Wonder and hosted SAM. See <https://dev.meta.ai/docs/cookbook/structured-output> and <https://dev.meta.ai/docs/models>.

MACE uses a strict schema to make Muse propose a *numerically executable restricted feature structure*, e.g. a product of measured temperature change and nonlinear velocity:

```json
{
 "id":"temperature_slip",
 "factors":[{"field":"temperature_delta","transform":"linear"},{"field":"v","transform":"tanh"}],
 "reason":"Possible temperature-dependent resistance",
 "measurement_needed":"Measure thermometer signal independent of camera motion",
 "falsifying_test":"Repeat approved load protocol at a different temperature and compare held-out response",
 "unknown_or_abstain":false
}
```

**An API reply is not a discovery.** Physica validates the input field names/transforms, requires independently measured numeric inputs, fits parameters only from logged interventions, and tests candidate performance on disjoint episodes. If the candidate fails, its use is refused. Arbitrary Python is never executed. A model can suggest an experiment, but an independent safety/provenance check determines whether the experiment may even be considered.

Preview the actual JSON schema request without billing:

```powershell
..\.venv\Scripts\python.exe -m physica.mace.cli meta-preview --context examples\mace_v010\meta_training_context.json --out demo\meta_preview.json
```

Optional **real, billed** request on **your machine** after `MODEL_API_KEY` is configured:

```powershell
$env:MODEL_API_KEY = "YOUR_META_API_KEY"
..\.venv\Scripts\python.exe -m physica.mace.cli meta-nominate --context examples\mace_v010\meta_training_context.json --model muse-spark-1.3 --allow-billed-meta --out demo\actual_muse_nomination.json
..\.venv\Scripts\python.exe -m physica.mace.cli demo --nomination demo\actual_muse_nomination.json --out demo\mace_meta_condition
```

The second command numerically tests the **recorded** candidate. The first command alone does not prove it helped. Repeat with Wonder for a matched hypothesis-generation comparison. Keep the test episodes sealed, do not send private hardware recordings, and record the actual response ID. Supported model availability, quotas and JSON schema details may change; consult the official docs and run the API doctor. No actual authenticated API calls were performed while building this release.

**SAM 3.1** can supply segmentation through the existing `physica/grammar/meta_sam_official.py` and `physica/triad/cli.py` adapters; its pixel motion requires a stationary reference and independently measured scale. **V-JEPA 2** is a separate pretrained visual world-model research path: actual weights must be downloaded and executed, and their output cannot be represented as calibrated SI forces. Neither is simulated as a live result here.

### Should Muse change neural weights?

Muse can nominate and rank model structure; **numerical training changes physical model parameters** when verified evidence supports them. LoRA/SFT on a smaller multimodal reasoning model is possible later with enough **human-reviewed real intervention/hypothesis/outcome** examples and sufficient compute; this release exports one-case JSONL with `meta-export-training` but does not fine-tune Spark Open or other large models. A general-purpose LLM's textual agreement is not a validation metric.

## 2. Real external training versus causal intervention

**Paderborn** at <https://mb.uni-paderborn.de/en/kat/research/bearing-datacenter/data-sets-and-download> provides synchronous motor-current and vibration measurements under four regimes; original files are roughly 150–180 MB *per bearing* archived, and the dataset has a CC BY-NC 4.0 license requiring attribution. The prior `remote_bench` trainer and `examples/cloud_v083/PHYSICA_REMOTE_TRAINING.ipynb` accept appropriate downloaded MAT/CSV files. Use distinct **bearing IDs**, not overlapping windows, across splits.

**Physics-IQ Verified** <https://huggingface.co/datasets/Anates-Labs-Research/Physics-IQ-Verified> supports blinded recorded-video evaluation. The included `triad` video forecasts only *withheld frames*, without claiming access to unmeasured forces.

**LabsLand** <https://labsland.com/en/> may expose controlled remote lab experiments; access and scientific data export vary by lab. The MACE real field path is appropriate **only if the intervention schedule and calibrated consequences are available**, not for an unlabelled passive recording.

**DROID** <https://droid-dataset.github.io/> contains recorded robot manipulation and actions; heavy storage and careful synchronization are required. Observation/action logs do not automatically guarantee interventions free of confounding.

This build environment could access public dataset *documentation* but not download real physical recordings via its container network. Consequently, **the newly trained model weights included in the MACE demo come from synthetic data only**. Existing prior-source real drone analyses remain in the older project, but are not evidence for this new algorithm.

### Real controlled-action input

Put `train.csv`, `validation.csv`, `test.csv`, and `manifest.json` in one directory. Required CSV columns:

```
t,x,v,u,acceleration,temperature_delta
0.00,0.001,0.005,0.1,-0.02,3.4
...
```

`t` seconds, `x` meters, `v` meters per second, `u` applied **controlled** acceleration command in m/s², `acceleration` **independently measured** in m/s², `temperature_delta` kelvin from an independent reference. Do not fabricate these channels by differentiating one noisy video and calling it independent; provide uncertainty and calibration notes externally. Each file needs >=12 monotonically increasing sample records and its SHA256 in `physica.mace.controlled.v1` manifest. Split episodes must not overlap.

```powershell
..\.venv\Scripts\python.exe -m physica.mace.cli field-evaluate --manifest "C:\PhysicaData\controlled\manifest.json" --out demo\real_mace.json
```

If this passes it verifies *file integrity and numerical pipeline execution*, not experimental honesty. Have an external witness preserve a pre-intervention prediction and timestamped raw data if claiming prospective chronology. Test on other distinct bodies before claiming cross-machine generalization.

## 3. Active scientific discovery objective

For a candidate safe action/context \(a\), the research heuristic is

\[
U(a) = \mathrm{Var}_H[\hat y(a)]\,\big(1+V_{\mathrm{target}}\big)+0.05\,G(a)-\lambda R(a)-\mu C(a),
\]

where rival models' disagreement is a proxy for diagnostic value, \(V_{\mathrm{target}}\) weights relevance to future machines, \(G\) represents user-stated goal progress, and \(R,C\) are bounded risk/cost. **This is a proposed operational heuristic, not a theorem or physical law.** Only `approved_reversible=true`, calibrated, bounded actions can be considered. No code sends a command to hardware.

The mechanism loss is a regularized action-conditioned regression on measured acceleration:

\[
\hat a_t = \sum_i w_i \phi_i(x_t,v_t,u_t,c_t), \quad
\hat w = \arg\min_w\|\Phi w-a\|_2^2+\lambda\|w\|_2^2.
\]

A candidate term is acceptable only after a separate validation episode improves upon the baseline. Target transfer is conditional on short local and rollout probes. A candidate validated on source machine A might still generalize poorly to target B—MACE reports that negative result and retains target-only as a fair equal-data-budget comparator.

This design incorporates existing methods: Bayesian design / model disagreement, SINDy-like restricted feature libraries, regularized identification, predictive coding, transfer learning and sensor fusion. **No element is claimed to establish a new mathematical field.**

## 4. Lens as a practical troubleshooting system

Open **Lens** in Studio and either upload an MP4 in the existing video panel or use the new **Investigate** section. The latter supports `washing_machine`, `robot_arm`, and `3d_printer`, listing possible causes, gaps in evidence, safe next observations and stop/escalation conditions. For before/after outcomes use:

```powershell
..\.venv\Scripts\python.exe -m physica.mace.cli diagnose --input examples\mace_v010\diagnose_washer.json --out demo\washer_guidance.json
```

The diagnosis path does **not** currently implement automatic fault-specific Bayesian posteriors from raw household videos; it is conservative evidence-limited guidance. Hidden internal faults, electrical hazards, gas leaks, medical risks, critical machinery and hazardous repair procedures require professionals. A useful real product must use known equipment models, calibrated measurements, appropriate manuals and safety policies.

## 5. Beyond human senses, and virtual sensing

`physica/mace/sensors.py` registers calibrated position, velocity, tactile force, IMU acceleration, current, temperature, magnetic field, ultrasound, radar Doppler, chemical concentration and hyperspectral reflectance with explicit units and hardware requirements. A finite numeric *virtual estimate* includes uncertainty and `VIRTUAL_ESTIMATE_NOT_MEASURED`. No physical sensor data are generated from missing modalities. The simple calibrated position/velocity fusion is a linear observation estimator with consistency checks **only when independently calibrated redundant measurements are available**. Exactly one position and one velocity channel cannot reveal disagreement; it is not a universal model of all modalities.

**Meta Wearables Device Access Toolkit 1.0** publicly documents camera, microphone/audio and IMU/motion access through compatible iOS/Android apps: <https://developers.meta.com/wearables/device-access-toolkit/>. A real glasses product needs an approved native companion app, device permissions, hardware, secure local streaming and privacy controls. This ZIP includes a **browser Lens prototype and an integration specification, not a native device SDK integration**.

## 6. Proposed research experiments, ablations and novelty gates

Pre-register problems and blind outcomes. Compare at identical action budgets and with independent test bodies:

- Classical system identification / SINDy with the same calibrated variables.
- Learned latent world model / ARX baseline without source prior.
- Physica selective transfer v0.9 without Muse.
- Physica + actual authenticated Muse Spark candidate generation.
- Physica + actual authenticated Muse Wonder candidate generation.
- Physica + Muse + sensory availability/experiment planning; SAM and optionally deployed V-JEPA readouts evaluated separately.

Metrics: unseen-body future-sensor RMSE, testable mechanism identification and false-discovery rate, number of safe experiments to reach an accuracy target, conditional coverage, abstention under domain shift, and the marginal value of each additional sensor. Avoid tuning on the test set; reject no-data performance claims. An accepted hypothesis must survive held-out experiments, not merely receive an agreeable explanation. Do not invent effect sizes or independent Meta results.

Potential novelty: **a transferable experimentally tested causal mechanism from one set of physical senses to another under unfamiliar dynamics**, with fewer safe experiments and lower false-discovery rate than strong baselines. Literature in multimodal world models and cross-embodiment causal transfer makes the basic combination insufficient to claim priority.

## 7. Next steps required for external verification

1. Run real grouped Paderborn training in the included cloud notebook, respecting data licensing. This tests sensing only.
2. Collect *controlled* logged actions and synchronized camera, audio/IMU/force and thermometer data; independently calibrate them and preserve raw hashes.
3. Run Muse authenticated structured nominations on *training-only aggregate contexts*, then accept candidates only through physically independent validation.
4. Have Machine B predict before action, collect later observations, score with target-only and SINDy baselines, and give C the signed, conditional lesson.
5. Demonstrate a household/robot problem with verified before-and-after response and reviewed machine instructions where appropriate.
6. Implement native iOS/Android glasses integration, real V-JEPA inference and optional fine-tuning only after an independently validated dataset and supported hardware/compute exist.

**Release integrity ≠ scientific validation. This document deliberately separates implemented code, optional connected tools and future physical work.**

### Recorded first-run evidence (synthetic only)

`examples/mace_v010/MACE_SYNTHETIC_12_SEED_BENCHMARK.json` contains the raw aggregate and per-case statistics. With 12 seeds, transfer scored a roughly **9.1% lower mean future-camera RMSE** than target-only fitting, but **won only 9 of 24 targets**. This mixed result is crucial; a mean improvement in a favorable synthetic family does not imply reliable causal transfer to unfamiliar real machines. `OFFLINE_MACE_EXPERIENCE_LAB.html` is a portable example of the analysis UI.
