"""Physica 0.27: evidence-gated, unified predictive-feeling discovery lifecycle.

Observations/physical models are scientific input; neural models and Muse are
hypothesis engines, not measurement authorities. No physical actuation, no
cached model output claimed as live, no future outcome access at commitment.

The workflow is deliberately split into stages because a real experiment must
occur BETWEEN planning, committing, and revealing. `synthetic-demo` uses an
explicitly labelled simulator to exercise the complete lifecycle locally.
"""
from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

import numpy as np

from .discovery_milestone_v025 import (
    digest, read_sealed, save_sealed, source_discover, plan_probe,
    target_commit, target_reveal, source_evidence,
)
from .curious_discovery import fit_neural_ensemble, neural_forecasts
from .field_discovery import (
    file_hash, load_csv, load_manifest, physical_baseline, read_plan,
    pure_ast_model,
)
from .sensory_belief import SensorReading, fuse_measurements, physical_surprise

VERSION = "0.27"


def _write_json(path: Path, value: dict) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf8")
    return path


def _sensor_sigma(manifest_path: Path, manifest: dict) -> float | None:
    calib = json.loads((manifest_path.resolve().parent / manifest["calibration_file"]).read_text(encoding="utf8"))
    value = calib.get("sensor_sigma_acc_m_s2")
    if type(value) not in (float, int) or not math.isfinite(value) or not 0 < value <= 5:
        return None
    return float(value)


def feel_source(manifest_path: Path, out: Path, *, trigger_z: float = 3.0,
                fraction_min: float = .08) -> dict:
    """Measure surprise on a source TRAIN episode excluded from any baseline fit.

    Uses the independently specified physical baseline and separately declared
    acceleration sensor noise. These are one-step action-conditioned predictions
    using measured x,v,u, NOT a sealed future trajectory. Source VALIDATION
    is never loaded here and remains held out for mechanism acceptance.
    """
    if not 2 <= trigger_z <= 12 or not 0 < fraction_min <= 1:
        raise ValueError("Invalid predeclared surprise threshold")
    manifest, files = load_manifest(manifest_path)
    sigma = _sensor_sigma(manifest_path, manifest)
    evidence = files["train"][-1]
    rows = load_csv(evidence)
    base = physical_baseline(rows, manifest["_physical_baseline"])
    residual = rows[:, 3] - base
    # Fit the neural residual predictor on EARLIER source TRAIN episodes only.
    # It never sees the chronological trigger episode until AFTER this diagnostic.
    previous = np.concatenate([load_csv(path) for path in files["train"][:-1]])
    from .field_discovery import to_reference_physics
    from .curious_discovery import known_acceleration
    training_ref = to_reference_physics(previous, manifest["_physical_baseline"])
    trigger_ref = to_reference_physics(rows, manifest["_physical_baseline"])
    neural = fit_neural_ensemble(training_ref, seeds=(23, 41), max_iter=100)
    forecasts_ref = neural_forecasts(neural, trigger_ref)
    nn_pred = forecasts_ref.mean(axis=0) - known_acceleration(*rows[:, :3].T) + base
    nn_disagreement = np.std(forecasts_ref, axis=0)
    nn_rmse = float(np.sqrt(np.mean((nn_pred - rows[:, 3]) ** 2)))
    doc = {
        "version": VERSION, "stage": "SOURCE_CALIBRATED_FEELING_GATE",
        "source_id": manifest["fixture_id"],
        "sensation": "one_step_acceleration_innovation_not_subjective_experience",
        "source_train_episode_sha256": file_hash(evidence),
        "source_training_sha256": [file_hash(p) for p in files["train"]],
        "source_calibration_sha256": manifest["_calibration_hash"],
        "source_validation_outcomes_read_for_surprise": False,
        "measurement_provenance": manifest["_calibration_kind"],
        "trigger_threshold_z": trigger_z,
        "trigger_min_fraction": fraction_min,
        "sample_count": int(len(rows)),
        "sensor_noise_sigma_m_s2": sigma,
        "physical_baseline_rmse_m_s2": float(np.sqrt(np.mean(residual**2))),
        "neural_holdout_rmse_m_s2": nn_rmse,
        "neural_ensemble_disagreement_mean_m_s2": float(np.mean(nn_disagreement)),
        "neural_training_episode_count": len(files["train"]) - 1,
        "neural_did_not_train_on_trigger_episode": True,
        "neural_ensemble_variation_is_not_calibrated_uncertainty": True,
        "mean_signed_innovation_m_s2": float(np.mean(residual)),
        "discovery_triggered": False,
        "hardware_actuation": "PROHIBITED",
    }
    if sigma is None:
        doc.update(status="CALIBRATION_NOISE_UNKNOWN_ABSTAIN",
                   next_step="Add independently justified sensor_sigma_acc_m_s2 to the calibration JSON")
        return save_sealed(out, doc)
    # The model is deterministic here; reference sigma is a declared sensor
    # calibration value. In a deployment, include a nonzero world-model sigma.
    z = residual / sigma
    abnormal = np.abs(z) > trigger_z
    sample = int(np.argmax(np.abs(z)))
    observed = fuse_measurements([SensorReading(
        quantity="acceleration", value=float(rows[sample, 3]),
        sigma=sigma, unit="m/s^2", origin="source_train_measurement",
        calibration_sha256=manifest["_calibration_hash"],
        independent_group=f"{manifest['fixture_id']}_accelerometer",
    )])
    surprise = physical_surprise(
        {"quantity": "acceleration", "value": float(base[sample]), "unit": "m/s^2"},
        observed, sigma_model=0.0,
    )
    fraction = float(np.mean(abnormal))
    trigger = bool(fraction >= fraction_min and doc["physical_baseline_rmse_m_s2"] > trigger_z * sigma)
    doc.update(status="UNEXPLAINED_MEASURED_RESPONSE" if trigger else "NO_SIGNIFICANT_NEW_RESPONSE",
               discovery_triggered=trigger,
               above_threshold_fraction=fraction,
               max_absolute_surprise_z=float(np.max(np.abs(z))),
               representative_sensation=surprise,
               trigger_interpretation=("UNEXPLAINED_FOR_PHYSICS_AND_NEURAL" if nn_rmse > trigger_z*sigma else
                   "NEURAL_PREDICTS_EFFECT_BUT_PHYSICS_LACKS_MECHANISM"),
               threshold_is_model_adequacy_test_not_proof_of_new_causal_mechanism=True)
    return save_sealed(out, doc)


def _public_live_error(exc: Exception) -> dict:
    """Diagnostic for a failed *local* paid call, without logging credentials.

    This is not proof that zero requests reached the provider. Failed requests
    may still be billable; inspect the local spending ledger and API dashboard.
    """
    raw = str(exc)[:1800]
    raw = re.sub(r"(?i)(bearer\s+)[^\s,;]+", r"\1[REDACTED]", raw)
    raw = re.sub(r"(?i)((?:api[_ -]?key|token|authorization|secret|password)\s*[:=]\s*)[^\s,;]+", r"\1[REDACTED]", raw)
    raw = re.sub(r"\b(?:sk-[A-Za-z0-9_-]{8,}|[A-Za-z0-9_-]{48,})\b", "[REDACTED]", raw)
    lower = raw.lower()
    if '401' in lower or '403' in lower or 'not configured' in lower or 'model_api_key' in lower:
        category = 'AUTHENTICATION_OR_PERMISSION'
    elif '404' in lower or 'model' in lower and ('not found' in lower or 'unknown' in lower):
        category = 'MODEL_UNAVAILABLE_OR_ENDPOINT'
    elif '429' in lower or 'rate limit' in lower or 'budget' in lower:
        category = 'RATE_LIMIT_OR_BUDGET'
    elif 'timeout' in lower or 'timed out' in lower:
        category = 'NETWORK_TIMEOUT'
    elif isinstance(exc, (ValueError, TypeError, KeyError)) or 'schema' in lower or 'json' in lower:
        category = 'RESPONSE_OR_HYPOTHESIS_INVALID'
    else:
        category = 'PROVIDER_OR_CLIENT_FAILURE'
    return {'error_category': category, 'error_type': type(exc).__name__,
            'error_detail_sanitized': raw[:360] or '(no error message)',
            'meta_calls_confirmed_successful': 'UNKNOWN_INSPECT_RECEIPTS',
            'meta_requests_attempted': 'UNKNOWN_CHECK_RECEIPTS_AND_BILLING',
            'provider_billable_requests_may_have_occurred': True,
            'next_action': ('Run python -m physica.frontier.meta_ready_v026 live-smoke '
                            '--role wonder --allow-billed-meta; inspect local receipts '
                            'and your Meta account without sharing the API key')}


def begin_investigation(source_manifest: Path, target_manifest: Path, out: Path,
                        *, offline_hypothesis: Path | None = None,
                        live_meta: bool = False, allow_billed_meta: bool = False,
                        trigger_z: float = 3., max_distance: float = 5.) -> dict:
    """Sense → trigger scientific curiosity → discover → design a target probe.

    No target probe or future test data are read. Muse requires separate explicit
    authorization. With offline_hypothesis, output always declares no live Muse.
    """
    if live_meta and offline_hypothesis is not None:
        raise ValueError("Offline and live provenance cannot be mixed")
    if not live_meta and offline_hypothesis is None:
        raise ValueError("Specify a labelled --offline-hypothesis or --live-meta")
    if live_meta and not allow_billed_meta:
        raise PermissionError('Explicit --allow-billed-meta required before calling live Muse')
    out.mkdir(parents=True, exist_ok=True)
    sensed = feel_source(source_manifest, out / "01_SOURCE_FEELING.json", trigger_z=trigger_z)
    if not sensed["discovery_triggered"]:
        return save_sealed(out / "00_LOOP_STATUS.json", {
            "version": VERSION, "stage": "INVESTIGATION_ABSTAINED",
            "sensation_receipt_sha256": file_hash(out / "01_SOURCE_FEELING.json"),
            "reason": sensed["status"], "meta_calls": 0,
            "source_discovery_started": False, "hardware_actuation": "PROHIBITED",
        })
    try:
        discovery = source_discover(
            source_manifest, out / "02_SOURCE_DISCOVERY.json",
            candidate_file=offline_hypothesis, live_meta=live_meta,
            allow_billed_meta=allow_billed_meta, sensory_trigger=sensed,
        )
    except (ValueError, TypeError, KeyError, RuntimeError, OSError) as exc:
        # External model responses may be empty, truncated, invalid or untrusted.
        # They must not crash a field investigation or be replaced silently by
        # the correct simulated equation. A failed paid call remains in its own
        # audit/receipt ledger; no science claim is created.
        if not live_meta:
            raise
        return save_sealed(out / "00_LOOP_STATUS.json", {
            "version": VERSION, "stage": "META_DISCOVERY_FAILED_ABSTAIN",
            "sensation_receipt_sha256": file_hash(out / "01_SOURCE_FEELING.json"),
            "source_discovery_started": True,
            **_public_live_error(exc),
            "hypothesis_validated": False,
            "hardware_actuation": "PROHIBITED",
        })
    if not discovery["source_candidate_accepted_for_transfer"]:
        return save_sealed(out / "00_LOOP_STATUS.json", {
            "version": VERSION, "stage": "PROPOSED_MECHANISM_REJECTED",
            "sensation_receipt_sha256": file_hash(out / "01_SOURCE_FEELING.json"),
            "discovery_receipt_sha256": file_hash(out / "02_SOURCE_DISCOVERY.json"),
            "source_meta_provenance": discovery["candidate_source_provenance"],
            "next_action": "Do not transfer; request independent tests or another calibrated sensor",
            "hardware_actuation": "PROHIBITED",
        })
    probe = plan_probe(out / "02_SOURCE_DISCOVERY.json", target_manifest,
                       out / "03_TARGET_PROBE_PLAN.json", max_distance=max_distance)
    return save_sealed(out / "00_LOOP_STATUS.json", {
        "version": VERSION, "stage": "FEEL_DISCOVER_AND_TARGET_PROBE_PLANNED",
        "source_fixture": discovery["source_machine_id"],
        "target_fixture": probe["target_machine_id"],
        "source_meta_provenance": discovery["candidate_source_provenance"],
        "source_sensory_surprise_shown_to_meta": "SOURCE_TRAIN_ONLY_NO_FUTURE",
        "sensation_receipt_sha256": file_hash(out / "01_SOURCE_FEELING.json"),
        "discovery_receipt_sha256": file_hash(out / "02_SOURCE_DISCOVERY.json"),
        "probe_plan_sha256": file_hash(out / "03_TARGET_PROBE_PLAN.json"),
        "needs_real_target_probe_before_next_stage": True,
        "hardware_actuation": "PROHIBITED",
    })


def commit_experience(loop_dir: Path, target_manifest: Path, probe_csv: Path,
                      future_plan: Path, *, out: Path | None = None) -> dict:
    """Learn from a newly measured target probe; freeze unseen future forecasts."""
    status = read_sealed(loop_dir / "00_LOOP_STATUS.json")
    if status["stage"] != "FEEL_DISCOVER_AND_TARGET_PROBE_PLANNED":
        raise ValueError("No validated mechanism and committed probe plan")
    if file_hash(loop_dir / "03_TARGET_PROBE_PLAN.json") != status["probe_plan_sha256"]:
        raise ValueError("Probe plan was modified after investigation")
    path = out or loop_dir / "04_TARGET_FORECAST_COMMIT.json"
    return target_commit(loop_dir / "02_SOURCE_DISCOVERY.json", target_manifest,
                         future_plan, path,
                         probe_receipt=loop_dir / "03_TARGET_PROBE_PLAN.json",
                         probe_recording=probe_csv)


def reveal_experience(commit_file: Path, measured_future: Path, out: Path) -> dict:
    """Score new prospective observations and quantify unexpected sensation.

    The reveal is not a certificate of an external timestamp or calibration.
    """
    scored_path = out.parent / "_REVEAL_SCORES.json"
    scored = target_reveal(commit_file, measured_future, scored_path)
    committed = read_sealed(commit_file)
    selected = committed["selected_without_test_data"]
    metric = scored["held_out_metrics"][selected]
    competing = scored["held_out_metrics"]["source_meta_structure_transfer"]
    vals = [m["acc_rmse_m_s2"] for m in scored["held_out_metrics"].values()
            if m["acc_rmse_m_s2"] is not None]
    if metric["acc_rmse_m_s2"] is None:
        status = "MODEL_ABSTAINED"
    elif metric["acc_rmse_m_s2"] > 2 * max(float(committed["validation_rmse_m_s2"].get(selected, 0)), 0.008):
        status = "FUTURE_SENSORY_SURPRISE_REQUIRES_INVESTIGATION"
    else:
        status = "FUTURE_RESPONSE_CONSISTENT_WITH_VALIDATION"
    return save_sealed(out, {
        "version": VERSION, "stage": "FEELING_REVEALED_AND_EVALUATED",
        "forecast_receipt_sha256": file_hash(commit_file),
        "measured_future_sha256": file_hash(measured_future),
        "measured_origin": scored["measurement_origin"],
        "source_provenance": scored["meta_provenance"],
        "selected_model_before_future": selected,
        "sensory_result": status,
        "selected_acceleration_rmse_m_s2": metric["acc_rmse_m_s2"],
        "hypothesis_transfer_position_rmse_m": competing["x_rmse_m"],
        "best_non_hypothesis_position_rmse_m": min(
            m["x_rmse_m"] for name, m in scored["held_out_metrics"].items()
            if name != "source_meta_structure_transfer" and m["x_rmse_m"] is not None),
        "complete_ablation_scores": scored["held_out_metrics"],
        "candidate_structure_beats_all": scored["meta_structure_beats_all_ablations"],
        "claim_limit": "No real-world novelty follows from simulated replay or local hash sealing",
        "next_step": "After this outcome, adapt only for a DIFFERENT future episode; never re-score this outcome as held-out",
    })


def learn_experience(reveal_receipt: Path, target_manifest: Path,
                     measured_future: Path, out_dir: Path,
                     *, forecast_commit: Path | None = None) -> dict:
    """Record the observed outcome as new training evidence for future trials.

    Preserves the earlier test evaluation forever; the observed episode can
    influence later training only. This is actual offline numerical learning
    when target_commit is later called with the new manifest, not weight edits
    attributed to Muse.
    """
    scored = read_sealed(reveal_receipt)
    if scored["stage"] != "FEELING_REVEALED_AND_EVALUATED":
        raise ValueError("Experience has not been revealed and evaluated")
    if scored["measured_future_sha256"] != file_hash(measured_future):
        raise ValueError("Recorded sensory experience differs from scored outcome")
    target, files = load_manifest(target_manifest)
    if any(file_hash(p) == scored["measured_future_sha256"]
           for values in files.values() for p in values):
        raise ValueError("Future test already included in original training or validation")
    # New manifest lives in SAME folder as evidence; no relpaths leading out.
    root = target_manifest.resolve().parent
    try:
        relative = measured_future.resolve().relative_to(root).as_posix()
    except ValueError as exc:
        raise ValueError("Measured future must live inside target manifest directory") from exc
    data = json.loads(target_manifest.read_text(encoding="utf8"))
    data["episodes"]["train"].append(relative)
    # All original validation episodes are still immutable and disjoint.
    adapted = root / (target_manifest.stem + "_after_experience.json")
    if adapted.resolve() == target_manifest.resolve():
        raise ValueError("Cannot modify original manifest")
    _write_json(adapted, data)
    load_manifest(adapted)
    out_dir.mkdir(parents=True, exist_ok=True)
    transferable = None
    if forecast_commit is not None:
        commit = read_sealed(forecast_commit)
        if file_hash(forecast_commit) != scored["forecast_receipt_sha256"]:
            raise ValueError("Forecast receipt does not match this measured experience")
        earlier = commit["models"]["source_meta_structure_transfer"]
        adapted_manifest, _, updated_train, updated_validation, _ = source_evidence(adapted)
        updated = pure_ast_model(updated_train, earlier["expression"])
        # This is a portable, mathematically specified candidate lesson. It is
        # not pre-approved for an untested third system or real machine control.
        transferable = {
            "status": "CANDIDATE_LESSON_NOT_REVALIDATED_ON_A_NEW_MACHINE",
            "expression": updated["expression"],
            "updated_target_coefficients": updated["coefficients"],
            "calibration_sha256": adapted_manifest["_calibration_hash"],
            "training_episodes_after_experience": len(adapted_manifest["episodes"]["train"]),
            "validation_episodes_unchanged": len(adapted_manifest["episodes"]["validation"]),
            "sensor_units": {"x": "m", "v": "m/s", "u": "m/s^2", "acc": "m/s^2"},
            "source_provenance": commit["meta_provenance"],
            "cross_machine_use_requires_compatibility_and_local_validation": True,
            "post_update_model_not_validated_on_a_new_independent_future": True,
        }
    lesson = {
        "version": VERSION, "stage": "PHYSICAL_EXPERIENCE_MEMORY_RECORD",
        "source_machine": target["fixture_id"],
        "measurement_kind": scored["measured_origin"],
        "raw_experience_sha256": file_hash(measured_future),
        "prior_sealed_prediction_sha256": scored["forecast_receipt_sha256"],
        "reveal_receipt_sha256": file_hash(reveal_receipt),
        "selected_model": scored["selected_model_before_future"],
        "prediction_error_acc_m_s2": scored["selected_acceleration_rmse_m_s2"],
        "model_update": "ADD_MEASURED_EPISODE_FOR_NEXT_FIT_ONLY",
        "adapted_manifest": str(adapted),
        "adapted_manifest_sha256": file_hash(adapted),
        "transferable_candidate_lesson": transferable,
        "replay_of_same_test_is_not_an_independent_improvement": True,
        "externally_verified": False,
        "actuation": "PROHIBITED",
    }
    return save_sealed(out_dir / "05_EXPERIENCE_MEMORY.json", lesson)


def synthetic_demo(out: Path, *, seed: int = 7, wrong_hypothesis: bool = False,
                   live_meta: bool = False, allow_billed_meta: bool = False) -> dict:
    """Run all seven stages using ONLY a declared simulated physical world."""
    from .synthetic_milestone_v025 import _fixture, _run, _sensor_csv, human_fixture_proposal
    out.mkdir(parents=True, exist_ok=True)
    a = {"stiffness_s2": 1.8, "damping_s1": .32, "control_gain": 1., "effect_gain": .96}
    b = {"stiffness_s2": 2.06, "damping_s1": .43, "control_gain": .91, "effect_gain": .72}
    source = _fixture(out / "machine_A_SIMULATED", "MACHINE_A_SIMULATED", a, seed * 100 + 1000)
    target = _fixture(out / "machine_B_SIMULATED", "MACHINE_B_SIMULATED", b,
                      seed * 100 + 4000, ntrain=2, nval=2)
    for manifest_path in (source, target):
        manifest_data = json.loads(manifest_path.read_text(encoding="utf8"))
        calibration = manifest_path.parent / manifest_data["calibration_file"]
        payload = json.loads(calibration.read_text(encoding="utf8"))
        payload["sensor_sigma_acc_m_s2"] = .007
        _write_json(calibration, payload)
    if wrong_hypothesis and live_meta:
        raise ValueError("A manually wrong hypothesis cannot be mixed with authenticated Muse")
    if live_meta and not allow_billed_meta:
        raise PermissionError("Live Muse demo requires --allow-billed-meta")
    hypothesis_file = None
    if not live_meta:
        proposal = human_fixture_proposal()
        if wrong_hypothesis:
            proposal["expression"] = {"op": "cube", "arg": {"op": "x"}}
            proposal["name"] = "deliberately_wrong_mechanism"
        hypothesis_file = _write_json(out / "HUMAN_AUTHORED_NOT_MUSE.json", proposal)
    loop_dir = out / "EXPERIENCE_LOOP"
    began = begin_investigation(source, target, loop_dir,
         offline_hypothesis=hypothesis_file, live_meta=live_meta,
         allow_billed_meta=allow_billed_meta)
    if began["stage"] != "FEEL_DISCOVER_AND_TARGET_PROBE_PLANNED":
        source_receipt = loop_dir / "02_SOURCE_DISCOVERY.json"
        attempted = read_sealed(source_receipt) if source_receipt.is_file() else {}
        council = attempted.get("meta_council_provenance") or {}
        result = {"version": VERSION, "stage": "SIMULATED_LOOP_ABSTAINED",
                  "start_status": began["stage"],
                  "meta_calls": council.get("authenticated_live_calls", 0),
                  "hypothesis_source": attempted.get("candidate_source_provenance", "NO_HYPOTHESIS"),
                  "real_experiments": 0}
        if "error_category" in began:
            # A failed live call must be visible in the terminal, not only in the status file.
            for key in ("error_category", "error_detail_sanitized", "meta_requests_attempted", "next_action"):
                result[key] = began[key]
            result.pop("meta_calls")
        return _write_json(out / "RESULTS_SYNTHETIC.json", result) and result
    probe = read_sealed(loop_dir / "03_TARGET_PROBE_PLAN.json")["probe_plan"]
    raw_probe = _run(seed * 100 + 7000, "MACHINE_B_SIMULATED", params=b,
                     initial=(probe["x0_m"], probe["v0_m_s"]), controls=probe["controls_m_s2"])
    probe_file = target.parent / "probe_measured_after_plan.csv"
    _sensor_csv(probe_file, raw_probe, with_time=True)
    manifest = json.loads(target.read_text(encoding="utf8"))
    manifest["episodes"]["train"].append(probe_file.name)
    _write_json(target, manifest)
    controls = (.3 * np.sin(np.arange(95) * .081) + .25 * np.cos(np.arange(95) * .044)).tolist()
    plan = {"fixture_id": "MACHINE_B_SIMULATED", "dt_s": .025,
            "x0_m": .38, "v0_m_s": -.21, "controls_m_s2": controls}
    plan_file = _write_json(out / "FUTURE_PLAN.json", plan)
    commitment = commit_experience(loop_dir, target, probe_file, plan_file)
    # The unseen test outcome is generated only AFTER all models are sealed.
    outcome = _run(seed * 100 + 9000, "MACHINE_B_SIMULATED", params=b,
                   initial=(plan["x0_m"], plan["v0_m_s"]), controls=controls)
    observed = target.parent / "FUTURE_GENERATED_AFTER_COMMIT.csv"
    _sensor_csv(observed, outcome, with_time=True)
    revealed = reveal_experience(loop_dir / "04_TARGET_FORECAST_COMMIT.json", observed,
                                 loop_dir / "06_FUTURE_REVEAL.json")
    experience = learn_experience(loop_dir / "06_FUTURE_REVEAL.json", target, observed, loop_dir,
                                  forecast_commit=loop_dir / "04_TARGET_FORECAST_COMMIT.json")
    # A second, independent future trial demonstrates that learning influences
    # an actual next forecast, not the already revealed trial. The two models
    # have different data budgets: AFTER sees one additional measured episode.
    second_controls = (.22*np.sin(np.arange(95)*.11+.6) - .2*np.cos(np.arange(95)*.054)).tolist()
    second_plan = {"fixture_id": "MACHINE_B_SIMULATED", "dt_s": .025,
                   "x0_m": -.26, "v0_m_s": .18, "controls_m_s2": second_controls}
    second_plan_file = _write_json(out / "NEXT_FUTURE_PLAN.json", second_plan)
    second_dir = out / "NEXT_TRIAL_AFTER_EXPERIENCE"
    second_dir.mkdir(parents=True, exist_ok=True)
    before = target_commit(loop_dir / "02_SOURCE_DISCOVERY.json", target, second_plan_file,
                           second_dir / "before_learning_commit.json",
                           probe_receipt=loop_dir / "03_TARGET_PROBE_PLAN.json", probe_recording=probe_file)
    after = target_commit(loop_dir / "02_SOURCE_DISCOVERY.json", Path(experience["adapted_manifest"]),
                          second_plan_file, second_dir / "after_learning_commit.json",
                          probe_receipt=loop_dir / "03_TARGET_PROBE_PLAN.json", probe_recording=probe_file)
    # Reveal only after BOTH the before- and after-learning forecasts are sealed.
    second_actual = _run(seed * 100 + 11000, "MACHINE_B_SIMULATED", params=b,
                         initial=(second_plan["x0_m"], second_plan["v0_m_s"]), controls=second_controls)
    second_observed = target.parent / "NEXT_FUTURE_AFTER_BOTH_COMMITMENTS.csv"
    _sensor_csv(second_observed, second_actual, with_time=True)
    before_scored = reveal_experience(second_dir / "before_learning_commit.json", second_observed,
                                     second_dir / "before_reveal.json")
    after_scored = reveal_experience(second_dir / "after_learning_commit.json", second_observed,
                                    second_dir / "after_reveal.json")
    name = "source_meta_structure_transfer"
    before_rmse = before_scored["complete_ablation_scores"][name]["x_rmse_m"]
    after_rmse = after_scored["complete_ablation_scores"][name]["x_rmse_m"]
    result = {"version": VERSION, "stage": "SEVEN_STAGE_SYNTHETIC_EXPERIENCE_LOOP_COMPLETE",
              "source_kind": "SIMULATED_MACHINE_A", "target_kind": "SIMULATED_MACHINE_B",
              "hypothesis_source": began["source_meta_provenance"],
              "meta_calls": (read_sealed(loop_dir / "02_SOURCE_DISCOVERY.json").get("meta_council_provenance") or {}).get("authenticated_live_calls", 0),
              "real_experiments": 0,
              "sensory_surprise": read_sealed(loop_dir / "01_SOURCE_FEELING.json"),
              "source_validation": read_sealed(loop_dir / "02_SOURCE_DISCOVERY.json")["selection_comparison"],
              "probe": probe, "sealed_future_hash": commitment["sha256"],
              "future_sensory_result": revealed["sensory_result"],
              "future_model_errors": revealed["complete_ablation_scores"],
              "experience_memory_sha256": experience["sha256"],
              "machine_B_new_training_episode": file_hash(observed),
              "second_future_sealed_before_simulation": True,
              "next_trial_comparison": {
                  "before_learning_receipt_sha256": before["sha256"],
                  "after_learning_receipt_sha256": after["sha256"],
                  "before_learning_structure_position_rmse_m": before_rmse,
                  "after_learning_structure_position_rmse_m": after_rmse,
                  "improved_on_second_independent_trial": bool(after_rmse < before_rmse),
                  "extra_training_episode_after_learning": 1,
                  "not_a_matched_data_budget_comparison": True,
                  "second_trial_measurements_used_in_neither_commitment": True,
              },
              "real_world_breakthrough_established": False,
              "next_step": "Use adapted target manifest only for another separately committed future experiment"}
    _write_json(out / "RESULTS_SYNTHETIC.json", result)
    return result


def main() -> None:
    p = argparse.ArgumentParser(description="Physica 0.27 unified evidence-gated predictive feeling and causal discovery")
    sub = p.add_subparsers(dest="command", required=True)
    sense = sub.add_parser("feel")
    sense.add_argument("--manifest", required=True)
    sense.add_argument("--out", required=True)
    start = sub.add_parser("investigate")
    start.add_argument("--source-manifest", required=True)
    start.add_argument("--target-manifest", required=True)
    start.add_argument("--out", required=True)
    start.add_argument("--offline-hypothesis")
    start.add_argument("--live-meta", action="store_true")
    start.add_argument("--allow-billed-meta", action="store_true")
    commit = sub.add_parser("commit")
    commit.add_argument("--loop-dir", required=True)
    commit.add_argument("--target-manifest", required=True)
    commit.add_argument("--probe-csv", required=True)
    commit.add_argument("--future-plan", required=True)
    commit.add_argument("--out", required=True)
    reveal = sub.add_parser("reveal")
    reveal.add_argument("--commit", required=True)
    reveal.add_argument("--measurements", required=True)
    reveal.add_argument("--out", required=True)
    learn = sub.add_parser("learn")
    learn.add_argument("--reveal", required=True)
    learn.add_argument("--target-manifest", required=True)
    learn.add_argument("--measurements", required=True)
    learn.add_argument("--out", required=True)
    learn.add_argument("--forecast-commit")
    demo = sub.add_parser("synthetic-demo")
    demo.add_argument("--out", default="demo/v027_synthetic")
    demo.add_argument("--seed", type=int, default=7)
    demo.add_argument("--wrong-hypothesis", action="store_true")
    demo.add_argument("--live-meta", action="store_true")
    demo.add_argument("--allow-billed-meta", action="store_true")
    args = p.parse_args()
    if args.command == "feel":
        result = feel_source(Path(args.manifest), Path(args.out))
    elif args.command == "investigate":
        result = begin_investigation(Path(args.source_manifest), Path(args.target_manifest), Path(args.out),
                                     offline_hypothesis=Path(args.offline_hypothesis) if args.offline_hypothesis else None,
                                     live_meta=args.live_meta, allow_billed_meta=args.allow_billed_meta)
    elif args.command == "commit":
        result = commit_experience(Path(args.loop_dir), Path(args.target_manifest), Path(args.probe_csv),
                                   Path(args.future_plan), out=Path(args.out))
    elif args.command == "reveal":
        result = reveal_experience(Path(args.commit), Path(args.measurements), Path(args.out))
    elif args.command == "learn":
        result = learn_experience(Path(args.reveal), Path(args.target_manifest),
                                  Path(args.measurements), Path(args.out),
                                  forecast_commit=Path(args.forecast_commit) if args.forecast_commit else None)
    else:
        result = synthetic_demo(Path(args.out), seed=args.seed, wrong_hypothesis=args.wrong_hypothesis,
                                live_meta=args.live_meta, allow_billed_meta=args.allow_billed_meta)
    cli_summary={"stage": result["stage"], "version": VERSION,
                 "out": str(getattr(args, "out", ""))}
    if "error_category" in result:
        cli_summary.update(error_category=result["error_category"],
                           error_detail_sanitized=result["error_detail_sanitized"],
                           meta_requests_attempted=result["meta_requests_attempted"],
                           next_action=result["next_action"])
    else:
        cli_summary["meta_calls_executed"] = result.get("meta_calls", "SEE_RECEIPT")
    print(json.dumps(cli_summary,indent=2))


if __name__ == "__main__":
    main()
