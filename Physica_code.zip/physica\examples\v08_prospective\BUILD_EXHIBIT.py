"""Self-contained offline research exhibit from executed, synthetic signed forecast."""
from pathlib import Path
import json,html


def polyline(values, lo,hi, width=1050,height=245):
    span=max(hi-lo,1e-9)
    return ' '.join(f'{30+(width-60)*i/(len(values)-1):.2f},{20+(height-40)*(1-(float(v)-lo)/span):.2f}'
                    for i,v in enumerate(values))


def chart_svg(forecast,measured,name,color):
    a=forecast['payload']['predicted_sensor_values'][name]
    b=measured['observed_by_sensor'][name]
    lower=min(min(a),min(b));upper=max(max(a),max(b));pad=max((upper-lower)*.12,.001)
    lower-=pad;upper+=pad
    pred=polyline(a,lower,upper);actual=polyline(b,lower,upper)
    return f'''<svg viewBox="0 0 1050 245" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Future predicted and simulated measured {name}">
      <line x1="30" y1="225" x2="1020" y2="225" stroke="#66758c" opacity=".5"/>
      <line x1="30" y1="20" x2="30" y2="225" stroke="#66758c" opacity=".5"/>
      <polyline points="{pred}" fill="none" stroke="{color}" stroke-width="4" stroke-linecap="round"/>
      <polyline points="{actual}" fill="none" stroke="#f8fafc" stroke-width="1.7" stroke-dasharray="8 5" opacity=".95"/>
      <text x="40" y="16" fill="#abb9ce" font-size="13">{upper:.4f}</text><text x="40" y="242" fill="#abb9ce" font-size="13">{lower:.4f}</text>
    </svg>'''


def build(root):
    p=Path(root)
    benchmark=json.loads((p/'benchmark_SIMULATED.json').read_text())
    demo=p/'demo'
    forecast=json.loads((demo/'B_forecast_SEALED.json').read_text())
    observed=json.loads((demo/'B_reveal_HIDDEN_UNTIL_FORECAST.json').read_text())
    scored=json.loads((demo/'B_scored_reveal.json').read_text())
    means=benchmark['mean_camera_rmse_mm']
    cam=chart_svg(forecast,observed,'camera','#44d9aa')
    mic=chart_svg(forecast,observed,'microphone','#b0a7ff')
    cards=''.join(f'<div class="stat"><div class="tiny">{title}</div><div class="big">{means[key]:.4f}<span class="unit"> mm</span></div></div>' for title,key in [
        ('No nonlinear term','no_friction'),('Local-only identification','local_friction_equal_probe'),('Transferred source model','source_transfer_on_accepted_only'),('Source + target probe','source_plus_target_probe_on_accepted_only')])
    page=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Physica v0.8 — Prospective Feeling Lab</title>
<style>*{{box-sizing:border-box}}body{{margin:0;background:#0c1320;color:#eff4fb;font-family:Inter,system-ui,-apple-system,Arial,sans-serif}}main{{max-width:1160px;margin:auto;padding:48px 26px 90px}}h1{{font-size:clamp(35px,5vw,65px);letter-spacing:-.05em;margin:12px 0}}h2{{font-size:26px;letter-spacing:-.025em;margin:40px 0 10px}}p{{color:#b3bfd0;line-height:1.55}}.kicker{{color:#48d7b5;text-transform:uppercase;font-size:13px;font-weight:700;letter-spacing:.15em}}.pill{{display:inline-block;background:#183129;color:#77f3d0;border:1px solid #275b4b;border-radius:18px;padding:7px 12px;font-size:12px;font-weight:700;margin-right:8px}}.warn{{background:#342915;color:#ffe09b;border-color:#6b5327}}.deck{{font-size:20px;max-width:900px}}.panel{{background:#141f30;border:1px solid #2c3b50;border-radius:17px;padding:25px;margin:22px 0}}.stats{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}}.stat{{background:#18283b;border:1px solid #304059;border-radius:12px;padding:22px}}.tiny{{font-size:13px;color:#a9b7cc}}.big{{font-size:30px;font-weight:800;margin-top:8px;letter-spacing:-.03em}}.unit{{font-size:14px;font-weight:400;color:#b8c3d2}}.legend{{display:flex;gap:22px;align-items:center;font-size:13px;color:#a3b2ca;margin:10px 0 4px}}.line{{width:22px;height:4px;border-radius:3px;display:inline-block;margin-right:7px}}svg{{width:100%;height:auto}}.tag{{background:#24334a;border:1px solid #344962;padding:4px 10px;border-radius:8px;font-size:12px}}.callout{{border-left:3px solid #ffd78a;padding:1px 18px;background:#241f19}}.flow{{display:grid;grid-template-columns:repeat(5,1fr);gap:9px}}.stage{{background:#1b2c40;text-align:center;padding:18px 9px;border-radius:10px;font-weight:600;font-size:13px}}a{{color:#9bdafc}}.foot{{font-size:12px;color:#99a8bd}}@media(max-width:720px){{.stats{{grid-template-columns:1fr}}.flow{{grid-template-columns:1fr}}main{{padding:30px 15px}}}}</style></head>
<body><main><div class="kicker">PHYSICA / RESEARCH EXHIBIT / V0.8</div><h1>Predict what a machine<br>will <em>feel</em>.</h1><div><span class="pill warn">SYNTHETIC ONLY</span><span class="pill">SIGNED FORECAST CHECKED</span><span class="pill">NO HARDWARE ACTUATION</span></div><p class="deck">An action-conditioned future sensory forecast: the model sees the machine's initial state and planned force, seals what its camera and microphone should measure, then checks the withheld consequence.</p>
<div class="flow"><div class="stage">01 Source experiment</div><div class="stage">02 Target low-force probe</div><div class="stage">03 Forecast sealed</div><div class="stage">04 Outcome revealed</div><div class="stage">05 Honest baseline</div></div>
<h2>The sealed experiment</h2><div class="panel"><div class="tag">Synthetic B · Camera · mm</div>{cam}<div class="legend"><span><span class="line" style="background:#44d9aa"></span>Sealed prediction</span><span><span class="line" style="background:#f8fafc"></span>Simulated withheld outcome (dashed)</span></div><p>Camera RMSE after reveal: <b>{scored['sensor_metrics']['camera']['rmse_native_units']:.6f} mm</b> — this is model-consistent synthetic data, not a hardware accuracy result.</p></div>
<div class="panel"><div class="tag">Synthetic B · Acoustic proxy · Pa</div>{mic}<div class="legend"><span><span class="line" style="background:#b0a7ff"></span>Sealed prediction</span><span><span class="line" style="background:#f8fafc"></span>Simulated withheld outcome (dashed)</span></div><p>Microphone RMSE after reveal: <b>{scored['sensor_metrics']['microphone']['rmse_native_units']:.6f} Pa</b>. This acoustic observation is a calibrated synthetic proxy, not live microphone pressure.</p></div>
<h2>Strong-baseline evaluation</h2><p>12 separate simulated target machines. Lower RMSE is better. Each adapted method receives one low-force target probe. Source transfer also uses three source interventions; this extra data cost is disclosed.</p><div class="stats">{cards}</div><div class="panel callout"><p><strong>What the benchmark actually found:</strong> source-only transfer is worse than local identification here, while a signed-probe-gated source-plus-target posterior improves on both. This is simulated, model-conditional evidence, not a field breakthrough.</p></div>
<h2>How to reproduce</h2><div class="panel"><p><code>python -m physica.feeling.v08_cli benchmark --trials 12 --seed 2026 --out benchmark.json</code></p><p>See <code>examples/v08_prospective/README.md</code> for separate forecast and reveal commands, sensor-fault tests and the real-world evidence checklist.</p><div class="tiny">Forecast hash: <code>{html.escape(forecast['sha256'])}</code></div></div>
<h2>What has NOT been demonstrated</h2><p>No actual human or machine subjective feelings; no verified real tactile hardware; no independently witnessed timestamp; no live authenticated Meta call in these results; no proof of superior learning on real out-of-distribution machines.</p><p class="foot">Generated from reproducible Python benchmark and signed synthetic demonstration artifacts. The displayed line charts contain sampled simulated values, not video or real sensors.</p></main></body></html>'''
    out=p/'research_exhibit_SIMULATION.html';out.write_text(page)
    print(out)
    return out
if __name__=='__main__':
    import sys
    build(sys.argv[1] if len(sys.argv)>1 else 'examples/v08_prospective')
