"""Static, honest, offline panel for cloud signal training proof of concept."""
from pathlib import Path
import json,html


def build(report_dir,output):
    base=Path(report_dir)
    cls=json.loads((base/'trained_weights/report.json').read_text())
    pred=json.loads((base/'next_sensation_weights/next_sensation_report.json').read_text())
    if cls['origin']!='SIMULATED_TRAINING_PILOT' or pred['origin']!='SIMULATED_TRAINING_PILOT':
        raise ValueError('this illustrative panel only accepts clearly labelled synthetic proof data')
    bars=''
    for name,result in pred['metrics'].items():
        error=result['heldout_rmse_native_units'];width= min(100,100*error/.55)
        bars+=f'<div class="metric"><div class="line"><b>{html.escape(name.replace("_"," ").title())}</b><strong>{error:.4f}</strong></div><div class="track"><div class="fill" style="width:{width:.2f}%"></div></div></div>'
    cases=''.join(f'<div class="tag">{html.escape(x)}</div>' for x in pred['test_bodies'])
    page=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Physica Discover — Cloud Pilot</title>
<style>body{{background:#09111b;color:#eaf3ff;font:16px/1.5 system-ui,sans-serif;margin:0}}main{{max-width:990px;padding:36px 22px;margin:auto}}h1{{font-size:52px;letter-spacing:-2px;line-height:1.05;margin:12px 0}}h2{{margin:0 0 12px}}p{{color:#aabccf}}.label{{color:#79e7e5;letter-spacing:2.5px;font-size:12px;font-weight:800}}.hero{{padding:35px;background:linear-gradient(145deg,#1b3550,#0d1727);border:1px solid #38516e;border-radius:22px}}.flag{{display:inline-block;padding:8px 11px;margin-top:20px;border:1px solid #ffca74;color:#ffca74;border-radius:8px;font-size:12px;font-weight:bold;letter-spacing:.1em}}section{{padding:28px;margin-top:20px;border:1px solid #2a3d4e;border-radius:20px;background:#111f2d}}.cols{{display:grid;grid-template-columns:1fr 1fr;gap:20px}}.value{{font-size:32px;font-weight:800;color:#79e7e5}}small{{color:#a5bed3}}.line{{display:flex;justify-content:space-between;margin:15px 0 8px}}strong{{font-variant-numeric:tabular-nums}}.track{{height:14px;background:#20344a;border-radius:8px;overflow:hidden}}.fill{{height:100%;background:linear-gradient(90deg,#24a5bf,#8beaab);border-radius:8px}}.tag{{display:inline-block;border:1px solid #425d77;color:#accce0;padding:5px 10px;border-radius:12px;margin:3px;font-size:12px}}code{{color:#88e7d9}}.copy{{font-size:13px}}.foot{{margin-top:30px}}@media(max-width:700px){{h1{{font-size:34px}}.cols{{grid-template-columns:1fr}}}}</style></head><body><main>
<header class="hero"><div class="label">PHYSICA / ACT II / DISCOVER</div><h1>Can one machine<br><span style="color:#8deacb">learn from another?</span></h1><p>Train vibration, motor-current and cross-sensory models. Hide the entire physical machine from training, then test how well it predicts an unseen signal.</p><div class="flag">SYNTHETIC TRAINING PILOT — NOT REAL-DATA EVIDENCE</div></header>
<div class="cols"><section><h2>Distinct training bodies</h2><div class="value">{len(pred['train_bodies'])}</div><small>Disjoint physical IDs, not random time windows</small></section><section><h2>Unseen test bodies</h2><div class="value">{len(pred['test_bodies'])}</div><small>No data from these groups enters model fitting</small></section></div>
<section><div class="label">SENSORY FORECAST</div><h2>Can the model anticipate future vibration?</h2><p>Future signal RMSE in synthetic arbitrary sensor units. Lower is better. Vibration and current are observed signals; this does not establish causal action understanding.</p>{bars}<small>Forecast made from prior 64 time samples; target is vibration 12 samples into the future. Train groups and test groups are disjoint.</small></section>
<section><div class="label">UNSEEN MACHINE SPLIT</div><h2>Machine IDs hidden during training</h2>{cases}<p>After you download Paderborn's real recordings, re-run exactly the same grouped workflow; replace these illustrative numbers with held-out results from real data.</p></section>
<div class="cols"><section><div class="label">NEXT / META SCIENTIST</div><h2>Context → hypothesis → experiment</h2><p>Live Muse Spark can describe the scene and its confounders. Wonder proposes rival explanations and a whitelisted test. Physica checks that the physical evidence actually discriminates among them.</p><small>Live Meta calls not executed in this pilot.</small></section>
<section><div class="label">NEXT / MACHINE CODE</div><h2>Sense → reviewed configuration</h2><p>Muse proposes the type of fix. Independently measured resonance and damping determine the actual draft G-code, Klipper settings or ArduPilot parameters. Nothing is automatically actuated.</p><small>Requires verified independent calibration.</small></section></div>
<section><div class="label">THE BREAKTHROUGH TARGET</div><h2>Predict. Feel. Falsify. Teach.</h2><p>A true Physica advance would predict an unfamiliar action's consequences in different sensors, discover why its prediction failed, and transfer the corrected causal mechanism to another body with fewer experiments. This display demonstrates only the training pipeline.</p></section>
<p class="foot">Generated locally from the v0.8.3 simulation pilot. No external models or physical experiments were invoked.</p>
</main></body></html>'''
    out=Path(output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(page)
    return out
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('report_dir');p.add_argument('--out',required=True)
    a=p.parse_args();print(build(a.report_dir,a.out))
