"""What is changing this body, and where? Rival causes, ruled in or out by physics, then located.

Physica feels a body's tone drift. It does not know why. It holds rival explanations, each a physical change it
can simulate on its own beam model:

  support  - something holds the body at x (a roller, a finger, a bracket)   -> tones can only go UP
  mass     - something heavy sits at x (a coin, a tool, a part)                -> tones can only go DOWN
  crack    - the body is weakened near x (a crack, a loose joint)             -> tones can only go DOWN
  uniform  - the whole body got stiffer or softer (temperature, material)     -> all tones scale together; real
             materials change only a few percent

Step 1 (rule out): each rival can only reach a band of tones. If the body is felt far outside a rival's band,
that rival is ruled out before anything is fitted (Rayleigh's principle: adding mass or removing stiffness can
only lower natural frequencies; adding a constraint can only raise them).
Step 2 (fit): the survivors are fitted window by window (one hidden position per window, one strength shared by
the whole recording). The one that explains the most windows within the model's stated tolerance wins.
Step 3 (locate): the winner's hidden position per window, with the range of positions that explain it equally
well (an honest interval, not a point).
If nothing explains the tones, Physica says so and can ask a Meta model for a new rival (physica.cause.scientist).
"""
from __future__ import annotations

import numpy as np

from physica.cause.fe import Beam

XS = np.r_[np.linspace(0.01, 0.95, 189)]

RIVALS = {
    "support": {"what": "something holds the body here (a roller, a finger, a bracket)",
                "rule": "holding a body can only raise its tones", "strengths": [3e2, 1e3, 1e4, 1e5],
                "strength_name": "spring stiffness k L^3/EI"},
    "mass": {"what": "something heavy sits here (a coin, a tool, a part)",
             "rule": "adding mass can only lower tones", "strengths": list(np.geomspace(0.02, 4.0, 10)),
             "strength_name": "mass / body mass"},
    "crack": {"what": "the body is weakened here (a crack, a loose joint)",
              "rule": "weakening a body can only lower its tones", "strengths": [0.3, 0.5, 0.7, 0.9],
              "strength_name": "stiffness lost over 5% of the length"},
    "uniform": {"what": "the whole body got stiffer or softer (temperature, material)",
                "rule": "all tones scale together; real materials change only a few percent",
                "strengths": [None], "strength_name": "none"},
}


def curves(beam: Beam, rival: str, strength, n: int = 2, xs=XS) -> np.ndarray:
    """Tones (Hz) of the beam for the rival at each hidden position x/L, shape (len(xs), n)."""
    key = (rival, None if strength is None else float(strength), n, len(xs))
    if key in beam._cache:
        return beam._cache[key]
    if rival == "support":
        out = np.array([beam.freqs(n, springs=[(x, strength)]) for x in xs])
    elif rival == "mass":
        out = np.array([beam.freqs(n, masses=[(x, strength)]) for x in xs])
    elif rival == "crack":
        out = []
        for x in xs:
            ei = np.ones(beam.n_el)
            lo, hi = int(max(x - 0.025, 0) * beam.n_el), int(min(x + 0.025, 1) * beam.n_el) + 1
            ei[lo:hi] *= 1 - strength
            out.append(beam.freqs(n, ei=ei))
        out = np.array(out)
    else:
        out = np.repeat(beam.bare(n)[None], len(xs), 0)
    beam._cache[key] = out
    return out


def _score_rival(beam, rival, f1, f2, tol, plausible_uniform):
    best = None
    for s in RIVALS[rival]["strengths"]:
        C = curves(beam, rival, s, n=2)
        if rival == "uniform":
            scale = (f1 / C[0, 0]) ** 2  # EI multiplier needed per window
            r1 = np.where((scale > 1 - plausible_uniform) & (scale < 1 + plausible_uniform), 0.0,
                          np.log(np.clip(scale, 1e-9, None)) / 2)
            xi = np.full(len(f1), -1)
            r2 = np.log(f2 / (C[0, 1] * np.sqrt(np.clip(scale, 1e-9, None)))) if f2 is not None else None
        else:
            R1 = np.log(f1[:, None]) - np.log(C[None, :, 0])
            if f2 is not None:
                R2 = np.log(f2[:, None]) - np.log(C[None, :, 1])
                cost = np.minimum((R1 / tol) ** 2, 25) + np.where(np.isnan(R2), 0, np.minimum((R2 / (2 * tol)) ** 2, 25))
            else:
                cost = np.minimum((R1 / tol) ** 2, 25)
            xi = np.nanargmin(cost, 1)
            r1 = R1[np.arange(len(f1)), xi]
            r2 = R2[np.arange(len(f1)), xi] if f2 is not None else None
        c = np.minimum((r1 / tol) ** 2, 25)
        if r2 is not None:
            c = c + np.where(np.isnan(r2), 0, np.minimum((r2 / (2 * tol)) ** 2, 25))
        total = float(np.sum(c))
        if best is None or total < best["cost"]:
            reach = (float(C[:, 0].min()), float(C[:, 0].max()))
            if rival == "uniform":
                reach = (float(C[0, 0] * np.sqrt(1 - plausible_uniform)), float(C[0, 0] * np.sqrt(1 + plausible_uniform)))
            best = {"rival": rival, "strength": s, "cost": total, "xi": xi, "r1": r1,
                    "explained": float(np.mean(np.abs(r1) <= tol)), "reach_hz": reach}
    return best


def discover(beam: Beam, f1, f2=None, tol: float = 0.03, plausible_uniform: float = 0.10,
             rule_out_frac: float = 0.10) -> dict:
    """Which rival explains the felt tones f1 (and f2 where felt), and where is the hidden change in each window."""
    f1 = np.asarray(f1, float)
    ok = np.isfinite(f1)
    f1v = f1[ok]
    f2v = None if f2 is None else np.asarray(f2, float)[ok]
    bare = beam.bare(2)
    rows = []
    for rival in RIVALS:
        b = _score_rival(beam, rival, f1v, f2v, tol, plausible_uniform)
        lo, hi = b["reach_hz"]
        outside = float(np.mean((f1v < lo * (1 - tol)) | (f1v > hi * (1 + tol))))
        status = "ruled out" if outside > rule_out_frac else "possible"
        say = f"{RIVALS[rival]['rule']}: it can only make {lo:.1f}-{hi:.1f} Hz"
        if outside > rule_out_frac:
            say += f", but {100 * outside:.0f}% of the time the body was felt outside that."
        rows.append({"rival": rival, "what": RIVALS[rival]["what"], "rule": RIVALS[rival]["rule"],
                     "reach_hz": [round(lo, 2), round(hi, 2)], "felt_outside_pct": round(100 * outside, 1),
                     "explained_pct": round(100 * b["explained"], 1), "strength": b["strength"],
                     "strength_name": RIVALS[rival]["strength_name"], "status": status, "say": say,
                     "_best": b})
    alive = [r for r in rows if r["status"] == "possible"]
    pool = alive or rows
    win = max(pool, key=lambda r: (r["explained_pct"], -r["_best"]["cost"]))
    out = {"beam": beam.describe(), "felt": {"windows": int(ok.sum()), "tone_hz_5_95": [round(float(q), 2) for q in
                                                                                    np.percentile(f1v, [5, 95])],
                                         "bare_hz": round(float(bare[0]), 2)},
           "rivals": [{k: v for k, v in r.items() if k != "_best"} for r in rows]}
    if win["explained_pct"] < 50 or not alive:
        out["verdict"] = {"cause": None, "say": "None of my rivals explains these tones; I need a new idea "
                                                "(ask a scientist model, or measure another tone)."}
        return out
    b = win["_best"]
    where = np.full(len(f1), np.nan)
    lo_i, hi_i = np.full(len(f1), np.nan), np.full(len(f1), np.nan)
    if win["rival"] != "uniform":
        C = curves(beam, win["rival"], b["strength"], n=2)
        R = np.abs(np.log(f1v[:, None]) - np.log(C[None, :, 0]))
        near = R <= np.maximum(R.min(1, keepdims=True), tol / 3)
        idx = np.where(ok)[0]
        where[idx] = XS[b["xi"]] * beam.length * 1e3
        lo_i[idx] = np.array([XS[np.where(n)[0].min()] for n in near]) * beam.length * 1e3
        hi_i[idx] = np.array([XS[np.where(n)[0].max()] for n in near]) * beam.length * 1e3
    out["verdict"] = {"cause": win["rival"], "partial": win["explained_pct"] < 80, "what": win["what"], "strength": win["strength"],
                      "strength_name": win["strength_name"], "explained_pct": win["explained_pct"],
                      "ruled_out": [r["rival"] for r in rows if r["status"] == "ruled out"],
                      "say": _say(win, rows, beam)}
    out["where_mm"] = where
    out["where_lo_mm"], out["where_hi_mm"] = lo_i, hi_i
    return out


def _say(win, rows, beam):
    out = [r for r in rows if r["status"] == "ruled out"]
    s = (f"The bare {beam.length * 1e3:.0f} mm body would ring at {beam.bare(1)[0]:.1f} Hz. ")
    if out:
        s += "Ruled out: " + "; ".join(f"{r['rival']} ({r['rule']})" for r in out) + ". "
    s += (f"Cause: {win['what']}. It explains {win['explained_pct']:.0f}% of the felt moments within the model's "
          f"stated tolerance.")
    if win["explained_pct"] < 80:
        s += " That is not enough: something else may be going on."
    return s


def invert(beam: Beam, rival: str, strength, f1) -> np.ndarray:
    """Hidden position (mm from the clamp) that gives tone f1 under one rival (monotone part of its curve)."""
    C = curves(beam, rival, strength, n=1)[:, 0]
    f1 = np.asarray(f1, float)
    R = np.abs(np.log(f1[:, None]) - np.log(C[None, :]))
    x = XS[np.nanargmin(np.where(np.isnan(R), np.inf, R), 1)] * beam.length * 1e3
    return np.where(np.isfinite(f1), x, np.nan)
