"""Offline Physica v0.5 research demo; all result values sourced from files.

Never retrieves external resources or labels local simulation as live evidence.
"""
from __future__ import annotations
import json,sys
from pathlib import Path

PAGE=r'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Physica v0.5 | A language for physical consequence</title>
<style>
:root{color-scheme:dark;font-family:Inter,ui-sans-serif,system-ui,sans-serif;color:#dceaf4;background:#07101e}
*{box-sizing:border-box}body{margin:0;line-height:1.55}main{max-width:1200px;margin:auto;padding:26px 24px 80px}
.top{display:flex;align-items:center;justify-content:space-between;gap:12px;border-bottom:1px solid #233b50;padding:0 0 22px}
.brand{font-weight:750;letter-spacing:.12em;color:#c8fae8}.caps{font:700 11px/1.3 ui-monospace,SFMono-Regular,monospace;letter-spacing:.15em;color:#6ad3bc}
.warning{padding:12px 16px;background:#3b2830;border:1px solid #9b6161;color:#ffd1c4;border-radius:12px;font-weight:600}
h1{font-weight:740;line-height:1.09;font-size:clamp(32px,5vw,66px);letter-spacing:-.04em;max-width:860px;margin:30px 0 12px}
h2{font-size:22px;letter-spacing:-.02em;margin:24px 0 14px;color:#fff}
p{max-width:900px}.muted{color:#95a9bc}.green{color:#7ee4c8}.hero{padding-bottom:24px}.micro{font:12px ui-monospace,SFMono-Regular,monospace;color:#9fadc2}
.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.card{background:#112136;border:1px solid #294257;border-radius:16px;padding:20px;min-height:135px}.metric{font-size:38px;font-weight:720;letter-spacing:-.03em;color:#8df6d3}
.node{display:flex;justify-content:center;align-items:center;text-align:center;flex-direction:column}.node b{font-size:24px}.node small{color:#aec4d5}
.flow{display:flex;gap:10px;align-items:center;justify-content:space-between;margin:25px 0;flex-wrap:wrap}.flow>div{border:1px solid #355669;border-radius:14px;background:#10243a;padding:17px;min-width:170px;flex:1}.flow .arr{min-width:10px;font-size:26px;color:#80ceb7;flex:0}
button{background:#14283e;color:#cce9e5;border:1px solid #375369;border-radius:8px;padding:9px 15px;cursor:pointer;font:inherit}button[aria-pressed=true]{background:#136559;color:#fff;border-color:#4ec9aa}.pill{display:inline-block;border:1px solid #375369;border-radius:999px;padding:5px 10px;margin:4px}.refuse{color:#ffbc9e}.success{color:#83e6cc}
.value{font-weight:700;font-size:25px}.bar{height:15px;background:#233447;border-radius:20px;overflow:hidden;margin:10px 0}.bar>span{display:block;height:100%;background:linear-gradient(90deg,#319d92,#9ffde5)}
pre{white-space:pre-wrap;overflow-wrap:anywhere;border:1px solid #294257;background:#0c192b;border-radius:10px;padding:16px;max-height:270px;overflow:auto;color:#b2d3d6}
footer{color:#8297a8;margin-top:55px;border-top:1px solid #2a384a;padding-top:28px}@media(max-width:750px){.grid{grid-template-columns:1fr}.flow{display:block}.flow>div{margin:12px 0}.flow .arr{display:none}}
</style></head><body><main>
<div class="top"><div class="brand">PHYSICA <span class="caps">v0.5 · CIRTE</span></div><div class="micro">CAUSAL SENSORY EXPERIENCE TRANSFER</div></div>
<div class="hero"><div class="caps" style="padding-top:24px">INTERVENTION · EXPERIENCE · MEMORY · TRANSFER</div><h1>Machines should be able to teach each other what the physical world feels like.</h1><p class="muted">A microphone measures pressure. A camera sees displacement. Physica uses independently calibrated physics to predict the effect of an intervention across both—a measurable physical consequence, not a text caption.</p>
<div class="warning">SYNTHETIC RESEARCH DEMO — not an authenticated Meta call, actual vibration measurement, or independently witnessed hardware experiment.</div></div>
<div class="flow"><div class="node"><small>Machine A · Hearing</small><b>Pa → causal state</b><small>Sealed experiential memory</small></div><span class="arr">→</span><div class="node"><small>Machine B · Vision</small><b>Forecast → reality</b><small>Prediction locked before data</small></div><span class="arr">→</span><div class="node"><small>Machine C · Vision</small><b>New experience</b><small>From B's measured outcome</small></div></div>
<h2>Trust means knowing when not to transfer</h2><div class="grid">
<div class="card"><div class="caps">SOURCE-LIKE TARGETS</div><div class="metric" id="accepted">—</div><div class="muted">Conditional accepted forecasts / independently simulated targets</div></div>
<div class="card"><div class="caps">HIDDEN-DYNAMICS SHIFT</div><div class="metric refuse" id="refused">—</div><div class="muted">Refused after independently simulated low-force drift</div></div>
<div class="card"><div class="caps">UNKNOWN MECHANISM</div><div class="value refuse" id="unknown">—</div><div class="muted">No known explanation fits the held-out mismatch threshold</div></div></div>
<h2>Calibrated multisensory inference</h2><p class="muted">Mean displacement error on the synthetic oscillator, in micrometers. When the more accurate sensor is available, fusion should use its measured uncertainty—not average sensor trajectories blindly.</p><div class="grid" id="ablations"></div>
<h2>Experiment selection: what should Physica try first?</h2><p class="muted">Prospective expected information gain under a declared Gaussian hypothesis family, with safety, cost and transfer value. A numeric safe-selection score is not hardware permission.</p><div class="grid" id="actions"></div>
<h2>Signed prediction and reveal</h2><div class="grid"><div class="card"><div class="caps">B · PREDICTION HASH</div><pre id="bhash"></pre><div class="muted">Sealed before the simulated B outcome</div></div><div class="card"><div class="caps">B · OBSERVATION ERROR</div><div class="metric" id="berr"></div><div class="muted">In native camera displacement units</div></div><div class="card"><div class="caps">C · AFTER LEARNING</div><div class="metric" id="cerr"></div><div class="muted">Prediction from signed B candidate memory</div></div></div>
<h2>Meta's actual research responsibilities</h2><div class="grid"><div class="card"><div class="caps">MUSE SPARK</div><p>Recognize the scene, confounders, apparatus and missing observations. Ground physical candidate questions, not numeric force guesses.</p></div><div class="card"><div class="caps">SAM 3.1</div><p>Track each moving part; convert geometric tracks to calibrated measurements only with independent physical scale and synchronization.</p></div><div class="card"><div class="caps">MUSE WONDER / V-JEPA</div><p>Propose discriminating experiments; assess visual dynamics via separately calibrated embeddings. The physics/safety layer decides what is testable.</p></div></div>
<p class="warning">No live Muse, SAM, V-JEPA, chemical hardware, or true physical A→B→C result is demonstrated on this page. The Meta-on/off effect has NOT been experimentally measured.</p>
<h2>Evidence / assumptions</h2><p class="muted">Check the generated JSON files next to this HTML. All displayed values derive from that local evidence. Prior papers, identifiability requirements, failures, full code and external field protocol are in docs/V050_CIRTE_RESEARCH_AND_FIELD.md.</p><pre id="limits"></pre>
<footer>Physica v0.5 CIRTE · Reproducible offline engineering test · Research hypothesis, not a new law or certified control system.</footer></main>
<script>
'use strict';const B=BENCHMARK_JSON,N=NATIVE_JSON;
const source=B.transfer_selective_results.source_like,shift=B.transfer_selective_results.shifted;
document.querySelector('#accepted').textContent=`${source.accepted} / ${source.denominator_all_machines}`;
document.querySelector('#refused').textContent=`${shift.refused} / ${shift.denominator_all_machines}`;
document.querySelector('#unknown').textContent=B.unknown_mechanism_check.status==='unknown_mechanism_or_sensor_failure'?'UNKNOWN / ABSTAIN':B.unknown_mechanism_check.status;
const ab=B.sensor_ablation,labels={video_only:'Sight only',audio_only:'Hearing only',both:'Sight + hearing'};
let max=Math.max(...Object.values(ab).map(v=>v.rmse_m));
document.querySelector('#ablations').innerHTML=Object.entries(ab).map(([k,v])=>`<div class="card"><div class="caps">${labels[k]}</div><div class="metric">${(v.rmse_m*1e6).toFixed(2)} μm</div><div class="bar"><span style="width:${Math.max(1,100*v.rmse_m/max)}%"></span></div><div class="micro">${v.status}</div></div>`).join('');
document.querySelector('#actions').innerHTML=B.prospective_eig.ranking.map(v=>`<div class="card"><div class="caps">${v.action_id.replaceAll('_',' ')}</div><div class="value ${v.status==='eligible'?'success':'refuse'}">${v.status==='eligible'?'ELIGIBLE':'REFUSED'}</div><div class="muted">${v.expected_information_gain_nats===undefined?'No experiment allowed':`EIG: ${v.expected_information_gain_nats.toFixed(3)} nats`}</div></div>`).join('');
document.querySelector('#bhash').textContent=N.predictions.B.sha256;
document.querySelector('#berr').textContent=`${(N.reveals.B.prediction_rmse_native*1e6).toFixed(2)} μm`;
document.querySelector('#cerr').textContent=`${(N.reveals.C.prediction_rmse_native*1e6).toFixed(2)} μm`;
document.querySelector('#limits').textContent=JSON.stringify({seed:B.seed,provenance:B.provenance,limits:B.limits,meta_api_called:B.meta_api_called,vjepa_executed:B.vjepa_weights_executed,hardware_experiments:B.hardware_experiments},null,2);
</script></body></html>'''


def build(out):
    out=Path(out)
    b=json.loads((out.parent.parent/'cirte_v05_benchmark.json').read_text())
    n=json.loads((out/'RESULTS_SIMULATION_ONLY.json').read_text())
    html=PAGE.replace('BENCHMARK_JSON',json.dumps(b,separators=(',',':')))
    html=html.replace('NATIVE_JSON',json.dumps(n,separators=(',',':')))
    (out/'experience_lab.html').write_text(html)
    return str(out/'experience_lab.html')

if __name__=='__main__':print(build(sys.argv[1] if len(sys.argv)>1 else 'examples/cirte_v05/native_demo'))
