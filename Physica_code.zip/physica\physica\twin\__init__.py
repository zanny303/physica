"""Physica twins: historical modal-twin API plus evidence-linked Twin Studio.

This package deliberately preserves the public ``physica.twin.export/save/
simulate/predict_after`` interface used in previous releases.
"""
from .legacy import export, save, simulate, predict_after
from .engine import reconstruct, simulate_intervention, demo_twin
__all__=['export','save','simulate','predict_after','reconstruct','simulate_intervention','demo_twin']
