"""Loader for the Fraunhofer unbalance dataset (Fordatis; Mey et al., arXiv 2005.12742).

Files 0D..4D (development) and 0E..4E (evaluation), 4096 samples/s. Column names are read from the
CSV header and matched by pattern (speed: 'rpm'; vibration: 'vib'; motor command: 'v_in'/'volt'),
never assumed. If a column can't be matched, the loader stops and says so.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from physica import config

FS = 4096.0
LEVELS_GMM = {0: 0.0, 1: 3.281 * 14.0, 2: 3.281 * 18.5, 3: 3.281 * 23.0, 4: 6.614 * 23.0}


@dataclass
class Run:
    name: str  # e.g. '1D'
    level: int
    speed_hz: np.ndarray
    vib: np.ndarray  # (N, channels)
    command: np.ndarray | None
    columns: dict = field(default_factory=dict)
    fs: float = FS

    @property
    def mr_gmm(self) -> float:
        return LEVELS_GMM[self.level]


def match_columns(header: list[str]) -> dict:
    h = [c.strip() for c in header]
    low = [c.lower() for c in h]
    speed = [h[i] for i, c in enumerate(low) if "rpm" in c]
    vib = [h[i] for i, c in enumerate(low) if "vib" in c]
    cmd = [h[i] for i, c in enumerate(low) if "v_in" in c or "volt" in c]
    if len(speed) != 1 or not vib:
        raise ValueError(f"could not identify speed/vibration columns in header {h}; edit match_columns()")
    return {"speed_rpm": speed[0], "vibration": vib, "command": cmd[0] if cmd else None}


def load(name: str, root: Path | None = None, max_rows: int | None = None) -> Run:
    root = Path(root) if root else config.fraunhofer_dir()
    path = root / f"{name}.csv"
    cache = config.REPO_ROOT / ".cache" / "fraunhofer" / f"{name}_{max_rows or 'all'}.npz"
    with open(path, newline="") as f:
        header = next(csv.reader(f))
    cols = match_columns(header)
    if cache.exists():
        d = np.load(cache)
        speed, vib, cmd = d["speed"], d["vib"], (d["cmd"] if "cmd" in d.files else None)
    else:
        idx = {c: header.index(c) if c in header else [x.strip() for x in header].index(c) for c in
               [cols["speed_rpm"], *cols["vibration"]] + ([cols["command"]] if cols["command"] else [])}
        use = list(idx.values())
        try:  # pandas' C reader is much faster for the 26M-row files
            import pandas as pd

            data = pd.read_csv(path, usecols=use, nrows=max_rows, dtype="float32").to_numpy()
            data = data[:, np.argsort(np.argsort(use))]  # pandas returns columns in file order
        except ImportError:
            data = np.loadtxt(path, delimiter=",", skiprows=1, usecols=use, max_rows=max_rows, dtype=np.float32)
        order = list(idx.keys())
        speed = data[:, order.index(cols["speed_rpm"])] / 60.0
        vib = data[:, [order.index(c) for c in cols["vibration"]]]
        cmd = data[:, order.index(cols["command"])] if cols["command"] else None
        cache.parent.mkdir(parents=True, exist_ok=True)
        np.savez(cache, speed=speed, vib=vib, **({"cmd": cmd} if cmd is not None else {}))
    return Run(name=name, level=int(name[0]), speed_hz=speed, vib=vib, command=cmd, columns=cols)


def order1_windows(run: Run, win_s: float = 1.0, rel_band: float = 0.03, min_speed_hz: float = 5.0) -> dict:
    """Per window: mean speed (rev/s) and the 1x (once-per-turn) vibration amplitude per channel.

    Amplitude = largest spectral peak within ±rel_band of the shaft speed (Hann window, amplitude-corrected).
    """
    w = int(win_s * run.fs)
    n = len(run.speed_hz) // w
    hann = np.hanning(w)
    corr = 2.0 / hann.sum()
    f = np.fft.rfftfreq(w, 1 / run.fs)
    sp, amp = [], []
    for i in range(n):
        s = slice(i * w, (i + 1) * w)
        v = float(np.mean(run.speed_hz[s]))
        if v < min_speed_hz:
            continue
        X = np.abs(np.fft.rfft((run.vib[s] - run.vib[s].mean(axis=0)) * hann[:, None], axis=0)) * corr
        m = (f >= v * (1 - rel_band)) & (f <= v * (1 + rel_band))
        if not m.any():
            continue
        sp.append(v)
        amp.append(X[m].max(axis=0))
    amp = np.asarray(amp)
    return {"speed_hz": np.asarray(sp), "a1": amp, "a1_combined": np.sqrt((amp ** 2).sum(axis=1))}
