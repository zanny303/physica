# Physica v0.21 — Discovery Observatory and Frontier Research

**Release state:** working software research prototype. **No scientific breakthrough, guaranteed competition outcome, real physical discovery, or live Meta execution is claimed.**

## One-sentence proposition

Physica uses a goal- and evidence-conditioned loop to decide which physical mechanisms it should consider, which safe experiments might discriminate them, and whether a prior experience helps future predictions. Muse may **propose and criticize** explanations; independent numerical tests and separately collected measurements decide which explanations survive.

## What's implemented in v0.21

* `physica.mace.discovery_observatory`: fair source-blind vs nominated-mechanism benchmark on controlled **synthetic** episodes; proposed mechanisms restricted to safe declarative features, no executable model code.
* Live Meta nomination: up to **three** bounded Muse Spark / Muse Wonder nomination rounds (default two). Muse receives training/validation residual summaries, proposed measured fields, and its prior candidate evaluations—**never the test outcomes**.
* Independent Meta criticism: a distinct, strictly structured Muse request names confounders, unmeasured channels and falsifying tests. Criticism remains an **unverified proposal**, not proof. The interface requires explicit authorisation for billable calls and uses the repository's existing budget gateway.
* Physica chooses a low-amplitude **candidate** experiment by model disagreement and a goal/cost proxy. It **abstains** if numerical models agree or rollouts are unstable. The chosen candidate is never automatically sent to machinery.
* A future action sequence, both fitted models, and their future-sensation forecasts are locked into a SHA-256 content digest **before** independent simulated test episodes are generated. The digest is not third-party timestamp attestation.
* The **Discovery Observatory** Studio experience has a locally executable Python-backed investigation, real chart data, experiment history, evidence provenance and explicit `SIMULATED` labels. The offline Studio task never uses the Meta key.
* More conservative specialized input routing: malformed turbine `.npz` and false F1 raw-file signatures produce typed rejection rather than uncontrolled exceptions.

## Independent checks (new release)

* Offline no-Meta control and human-authored nominee evaluated on **24 synthetic seeds**.
* Source-blind mean acceleration lockbox RMSE: **0.00990424** (simulator acceleration units).
* Candidate-augmented mean acceleration lockbox RMSE: **0.00990424**.
* Candidate wins: **0/24**, ties: **24/24**, losses: **0/24**.
* This is a **negative** novelty/Meta-advantage result, not a feature failure. The source-blind numerical grammar already contains the simulator's correct periodic term, so a human nomination adds no predictive advantage.
* One 2026-seed prospective camera-position comparison: baseline/augmented RMSE **0.00188927 m**; independent simulated source test episode after forecast commitment.
* Multi-round live-Meta, structured critic, lockbox, and router safety are covered by new tests. **Authenticated calls were mocked** in tests; no real Meta API key was supplied.

## Meta architecture: meaningful roles, not theater

1. **Muse Spark / Muse Wonder (perception & hypothesis)** — provide context and propose a bounded structural term, request a missing sensor, or abstain. The model never supplies a trusted coefficient or blindly rewrites weights.
2. **Muse adversarial critic** — challenge the proposed mechanism, identify omitted-variable bias and ask for new measurements. Its output is displayed as unverified advice and may block a claim of completion.
3. **Physica mathematical evidence engine** — fit parameters only from approved training episodes, select from two *disjoint* validation episodes, compare to a source-blind model-search baseline with the same observation budget, and freeze prospective predictions.
4. **Experiment planner** — select low-force hypothetical probes using model-conditional disagreement; if nothing can be distinguished, abstain. Real actuation requires independently enforced device-specific safety limits and human approval.
5. **SAM 3.1** — supports the existing tracked-video perception path; **physical units require independent camera calibration and a stationary reference**. No active hosted SAM call is performed in the new Observatory task.
6. **Future transfer** — carry physical mechanisms with calibration and applicability boundaries to Machine B; verify with a few target probes against local-only and conventional system-identification alternatives. This remains a research objective, not proven in the v0.21 Observatory experiment.

### Why this architecture is preferable to unrestricted weight editing

A language model's proposal must remain a *testable prior/candidate*. Otherwise a plausible verbal explanation silently becomes an apparently measured law. Numeric parameter fitting and acceptance must stay evidence-gated. If the model proposes an unmeasured field, the correct action is **request the sensor** rather than hallucinate its value.

## Deep research review: what to add next

Reviewed current official Meta Model API / SAM / V-JEPA documentation and the May 2026 DiscoverPhysics benchmark. Sources below are external research/documentation, not results verified on Physica.

### 1. DiscoverPhysics-style unfamiliar laws — **highest scientific priority**

DiscoverPhysics evaluates agents across **22 deliberately altered-physics worlds**. Its authors report that the best tested frontier agents succeed in only about half the worlds, and good trajectory prediction can coexist with poor conceptual explanations.

**Physica experiment:** assign unfamiliar simulated worlds, time- and energy-constrained experiments, with frozen ground-truth mechanisms unknown to the agent. Score mechanism correctness separately from predictive accuracy, plus experiments spent, calibration and false-discovery rate. Compare fixed grammar, PySINDy/SINDy, Meta-only, Meta+MACE, and outcome-directed active design. Do not tune on the benchmark test worlds.

### 2. Multimodal unknown-variable identifiability — **high scientific priority**

Measure when electrical current, sound, vision, IMU or thermal signals can truly identify an unobserved mechanical state, rather than merely correlate with it. Build **sensor deletion**, domain shift, sensor bias, camera drift and identical-observation/different-mechanism cases. Refuse if two mechanisms remain observationally equivalent; explicitly request the needed modality.

**Target:** comparable task success using fewer calibrated sensors **at a controlled rate of false confident claims**. Meta could propose a missing modality; compare against Bayes value-of-information and ordinary active sensing.

### 3. Outcome-conditioned interventions — **high product + algorithm value**

Move beyond passive inference. Condition safe experiment choice on a measurable physical goal (e.g. settle within tolerance, reduce vibration subject to energy cost), rather than maximize uncertainty reduction alone. Benchmark Bayesian experimental design, dual control, robust model-predictive control, target-aware transfer and random experimental budgets. Require actual after-measurements and count total cost including unsuccessful trials.

### 4. Pretrained visual world features: V-JEPA 2 — **powerful but computationally heavier**

Meta's V-JEPA 2-AC uses a pretrained visual world model plus a comparatively small amount of robot data for action-conditioned planning in unfamiliar lab environments. This overlaps with Physica's visual-prediction pitch. Use it as a **strong pretrained feature baseline or complementary representation**, not proof that raw video yields calibrated forces or hidden internal defects.

**Research question:** does adding verified physical interventions to V-JEPA features reduce physical experiment cost across new embodiments compared to V-JEPA and system ID alone?

### 5. Meta importance ablations — **critical for the hackathon**

Run the *same* trials in five pre-registered arms:

| Arm | Proposal | Experiment choice | Physical estimation |
|---|---|---|---|
| Classical | finite grammar / PySINDy | Bayesian or random | system identification |
| Physica-MACE | fixed model search | Physica active design | Physica numeric model |
| Meta-only | Muse candidates | Muse candidate plan | standalone baseline |
| Meta+Physica | Muse structural proposals | numerical safe planning | Physica evidence gate |
| Meta+critic+Physica | Muse proposes; Muse challenges | critic informs safe measurement requests | independent physical validation |

The goal is not to show *any* working model, but to quantify how much **real Meta-generated hypotheses** improve new physical-task success compared with the best source-blind model under the same data budget and model-search time.

### 6. Stronger falsification and prospective receipts

* Completely separate train, mechanism-selection validation, calibration and unseen test sessions; use different physical devices if claiming cross-machine transfer.
* Measure action commands and actual physical response through separate devices, with time-aligned sensors and calibration photographs/procedures.
* Submit forecast hashes to a separate witness service **before** collection; local SHA-256 alone cannot verify chronology.
* Register hypotheses, budgets and exclusion rules before examining outcomes. Include failed runs and confidence intervals by held-out body, not only pooled individual samples.
* For consequential devices (turbines, drones, rotors), advisory-only mode and professional safety review; never infer certified safety from simulator accuracy.

### 7. Consumer experience (Physica Lens)

Use SAM + Muse for user-visible hypotheses with **measured evidence, uncertainty, alternatives, and a safe next check**. Record the before-and-after physical response. Start with low-risk applications such as a loose shelf or printer ringing rather than safety-critical blade or rotor control. The new Observatory visual language can be adapted to a consumer evidence card, but it is **not yet a native Meta glasses app**.

## Prioritization if the competition is imminent

1. Fix any live-product crashes, then record one **real prospective physical measurement** with independent calibration and a source-blind baseline.
2. Run **authenticated Muse calls** and save official receipts; compare Meta-on and Meta-off on matched trials. Never label a human-authored fixture as Muse.
3. Reproduce the real physical result with independent trials; test signed forecast before new data collection.
4. Present the Observatory UI + actual evidence trail, but ensure all synthetic examples remain visibly tagged.
5. Only add V-JEPA 2, native glasses and large-scale fine-tuning if the above has been independently achieved.

## Run

From the `physica/` root (Python 3.12+):

```powershell
python -m pip install -e ".[dev]"
python -m physica.studio --open-browser
```

Open `http://127.0.0.1:8765/observatory` and select **Run the investigation**. This uses only synthetic data and a human-authored hypothesis. No Meta API key is needed, and no billable call occurs from this page.

```powershell
# Offline fixture; creates an auditable JSON experiment report
python -m physica.mace.discovery_observatory --mode human_fixture --out demo/discovery_offline.json

# Matched no-Meta control
python -m physica.mace.discovery_observatory --mode no_meta --out demo/discovery_no_meta.json

# Optional billable Meta: bounded proposal rounds + independent critic
$env:MODEL_API_KEY = "<your private key>"
python -m physica.mace.discovery_observatory --mode live_meta --model muse-spark-1.3 --meta-rounds 2 --allow-billed-meta --out demo/discovery_meta.json
```

The live CLI **does not automatically execute hardware**. It can incur charges. If the provider rate limits, rejects a schema, or the response fails validation, the command may fail rather than inventing a model result. Confirm the key is authorized for the selected Meta models.

## Verified sources and links

1. Meta Model API, **Structured output**, https://dev.meta.ai/docs/structured-output — bounded strict schema and JSON response contract.
2. Meta Model API, **Tool / function calling**, https://dev.meta.ai/docs/cookbook/tool-function-calling — how model decisions can call registered tools without arbitrary execution.
3. Meta, **SAM 3.1**, https://ai.meta.com/blog/segment-anything-model-3/ — improved multi-object video segmentation/tracking; pixels are not calibrated meters.
4. Meta, **V-JEPA 2**, https://ai.meta.com/research/publications/v-jepa-2-self-supervised-video-models-enable-understanding-prediction-and-planning/ — pretrained world model and action-conditioned robot planning.
5. Wiemann et al. (May 2026), **DiscoverPhysics**, https://arxiv.org/abs/2605.26087 — altered-world active scientific discovery; held-out prediction differs from correct explanation.
6. Meta Model API, **Pricing and limits**, https://dev.meta.ai/docs/pricing-rate-limits — real hosted costs and model availability; local budget safeguards do not guarantee a provider-enforced hard cap.

**Research verdict:** the major opportunity is not "put a chatbot next to physics" but *measurably better experimental discoveries, under honest baselines, because Meta generates and criticizes hypotheses that the preexisting numerical search would not have found*. That remains an experiment to conduct—not an achievement certified by v0.21.
