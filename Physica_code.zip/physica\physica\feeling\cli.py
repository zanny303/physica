"""Physica v0.6 predictive feeling CLI. No hardware actuation."""
import argparse,json
from pathlib import Path
from .core import (parse_body,parse_senses,parse_trial,verify_lesson,prepare_low_force_probe,
  check_low_force_probe,signed_forecast,verify_consequence,verify_forecast,transfer_check,
  fit_physical_feeling,sign_lesson)
from .demo import create_demo

def _read(path):return json.loads(Path(path).read_text())
def _write(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,indent=2)+'\n');print(p)

def main(argv=None):
    p=argparse.ArgumentParser(description='Physica action-conditioned predictive physical feeling')
    sub=p.add_subparsers(dest='cmd',required=True)
    dm=sub.add_parser('demo',help='Reproducible SYNTHETIC A→B→C exhibit')
    dm.add_argument('--out',default='demo/feeling_v06');dm.add_argument('--seed',type=int,default=2026)
    meta=sub.add_parser('meta-feel',help='REAL billable Spark/Wonder + optional calibrated SAM context')
    meta.add_argument('video');meta.add_argument('--out',required=True)
    meta.add_argument('--allow-billed-meta',action='store_true')
    meta.add_argument('--sam-concept');meta.add_argument('--moving-id',type=int)
    meta.add_argument('--reference-id',type=int);meta.add_argument('--meters-per-pixel',type=float)
    meta.add_argument('--fps',type=float);meta.add_argument('--sensor-noise-m',type=float)
    meta.add_argument('--calibration-id')
    bm=sub.add_parser('benchmark',help='SIMULATED per-seed baselines and hidden-shift refusal')
    bm.add_argument('--out',default='demo/feeling_v06_benchmark.json');bm.add_argument('--trials',type=int,default=20)
    bm.add_argument('--seed',type=int,default=2026)
    learn=sub.add_parser('learn',help='Train on source interventions; validate on distinct heldout actions')
    learn.add_argument('training_interactions');learn.add_argument('heldout_interactions')
    learn.add_argument('--out',required=True)
    learn.add_argument('--meta-context',help='optional saved live Meta candidate record; heldout sensing still decides')
    pr=sub.add_parser('prepare-probe',help='Seal low-force forecast from only source lesson + target calibration')
    pr.add_argument('lesson');pr.add_argument('target_request');pr.add_argument('--out',required=True)
    ck=sub.add_parser('check-probe',help='Verify later raw target measurements against sealed probe')
    ck.add_argument('lesson');ck.add_argument('forecast');ck.add_argument('measured_trial');ck.add_argument('--out',required=True)
    pre=sub.add_parser('prepare',help='Seal main target forecast after signed low-force probe')
    pre.add_argument('lesson');pre.add_argument('target_request');pre.add_argument('checked_probe');pre.add_argument('--out',required=True)
    vr=sub.add_parser('check',help='Check target measurements uploaded only after forecast sealed')
    vr.add_argument('forecast');vr.add_argument('measured_trial');vr.add_argument('--out',required=True)
    a=p.parse_args(argv)
    if a.cmd=='demo':
        result=create_demo(a.out,a.seed);print('synthetic A→B→C:',result['B_result'],result['C_result']);return result
    if a.cmd=='meta-feel':
        from .meta_bridge import live_meta_feeling_analysis
        result=live_meta_feeling_analysis(a.video,allow_billing=a.allow_billed_meta,
            sam_concept=a.sam_concept,moving_object_id=a.moving_id,
            reference_object_id=a.reference_id,meters_per_pixel=a.meters_per_pixel,
            frames_per_second=a.fps,displacement_noise_std_m=a.sensor_noise_m,
            calibration_id=a.calibration_id)
        _write(a.out,result);return result
    if a.cmd=='benchmark':
        from .benchmark import save_benchmark
        result=save_benchmark(a.out,a.trials,a.seed)
        print(json.dumps({k:v for k,v in result.items() if k not in ('rows','limitations')},indent=2));return result
    if a.cmd=='learn':
        train=[parse_trial(t) for t in _read(a.training_interactions)]
        heldout=[parse_trial(t) for t in _read(a.heldout_interactions)]
        if a.meta_context:
            from .context import evaluate_contextual_hypothesis
            ctx=_read(a.meta_context)
            # Meta's physical candidate is not a force measurement; the source
            # interventions and independent validation still establish fit.
            result=evaluate_contextual_hypothesis(train,heldout,ctx.get('candidate_mechanisms',ctx))
        else:
            result=fit_physical_feeling(train,heldout)
        if result['status']!='SUPPORTED_HELDOUT':
            _write(a.out,{'status':'REFUSE_TO_TEACH','diagnostic':result});return result
        lesson=sign_lesson(result,train[0].body,evidence_digests=[t.evidence_sha256 for t in train+heldout])
        _write(a.out,lesson);return lesson
    if a.cmd in ('prepare','prepare-probe'):
        lesson=_read(a.lesson);req=_read(a.target_request)
        if not verify_lesson(lesson):raise ValueError('source experience signature invalid')
        body=parse_body(req['body']);senses=parse_senses(req['senses']);times=req['time_s'];force=req['force_n'];initial=req['initial_state']
        result=(prepare_low_force_probe(lesson,body,senses,times,force,initial) if a.cmd=='prepare-probe'
                else signed_forecast(lesson,body,senses,times,force,initial,probe=_read(a.checked_probe)))
        _write(a.out,result);return result
    if a.cmd=='check-probe':
        from .core import check_low_force_probe
        result=check_low_force_probe(_read(a.lesson),_read(a.forecast),parse_trial(_read(a.measured_trial)))
        _write(a.out,result);return result
    if a.cmd=='check':
        forecast=_read(a.forecast)
        if not verify_forecast(forecast):raise ValueError('invalid committed prediction')
        result=verify_consequence(forecast,parse_trial(_read(a.measured_trial)))
        _write(a.out,result);return result

if __name__=='__main__':main()
