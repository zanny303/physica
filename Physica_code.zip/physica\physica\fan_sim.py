"""SIMULATED fan clips (for tests and the offline demo only): a textured hub that wobbles once per turn."""
import sys

import cv2
import numpy as np

def clip(path, imb, fps=120, secs=3, f0=12.0, W=160, H=120):
    rng=np.random.default_rng(0); tex=(rng.random((H*2,W*2))*255).astype(np.uint8); tex=cv2.GaussianBlur(tex,(7,7),2)
    vw=cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (W,H), False)
    for k in range(int(fps*secs)):
        t=k/fps; z=imb*np.exp(1j*2*np.pi*f0*t)
        dx,dy=1.2*z.real,1.2*z.imag
        M=np.float32([[1,0,W/2+dx],[0,1,H/2+dy]])
        fr=cv2.warpAffine(tex,M,(W,H),borderMode=cv2.BORDER_REFLECT)
        fr=np.clip(fr.astype(float)+rng.normal(0,2,fr.shape),0,255).astype(np.uint8)
        vw.write(fr)
    vw.release()
A0 = 1.0 * np.exp(1j * np.radians(200))  # the fan's own imbalance (unknown to Physica)
T = 0.6  # wobble one 1 g coin adds at a blade tip


def four_clips(out, a0=A0, t=T):
    paths = []
    for name, ang in [("as_is", None), ("coin_b1", 0), ("coin_b2", 120), ("coin_b3", 240)]:
        z = a0 if ang is None else a0 + t * np.exp(1j * np.radians(ang))
        clip(f"{out}/{name}.mp4", z)
        paths.append(f"{out}/{name}.mp4")
    return paths


def after_clip(out, grams, angle_deg, a0=A0, t=T):
    clip(f"{out}/after_fix.mp4", a0 + t * grams * np.exp(1j * np.radians(angle_deg)))
    return f"{out}/after_fix.mp4"


if __name__ == "__main__":
    print(four_clips(sys.argv[1]))
