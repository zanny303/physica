"""The film's own pieces: the typed opening on the printer's stops, the ribbon and banner on any clip, the twin beside the real thing, the seal, the results card, and the ending.
Numbers come from saved results. Anything without a saved result stays out, and nothing here writes Muse's words for it."""
from __future__ import annotations

import json
import re
import math
import subprocess
import wave
from pathlib import Path

import numpy as np

from physica.film import style as S
from physica.meta.scout import ffmpeg, film_info

RIBBON = (("WATCH", (179, 157, 255)), ("PIN", (124, 196, 255)), ("FEEL", (79, 227, 193)), ("GRADE", (242, 184, 75)))
STEP = {"MUSE": "WATCH", "SAM": "PIN", "PHYSICA": "FEEL", "REALITY": "GRADE"}
HOOK = ("Muse can see.", "Muse can reason.", "What happens when it can feel?")
ENDING = ("Muse can see.", "Muse can reason.", "Now it can feel.", "Physica · built with Muse and SAM 3.1")


def _font(size: int, bold: bool = True):
    from matplotlib import font_manager
    from PIL import ImageFont
    return ImageFont.truetype(font_manager.findfont(font_manager.FontProperties(family="DejaVu Sans", weight="bold" if bold else "normal")), size)


class _Out:
    """Frames in, H.264 out, with the source's sound if it has any."""
    def __init__(self, path, w: int, h: int, fps: float, sound=None):
        args = [ffmpeg(), "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", f"{fps:g}", "-i", "-"]
        if sound:
            args += ["-i", str(sound), "-map", "0:v", "-map", "1:a?", "-shortest"]
        args += ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "19", "-preset", "veryfast", str(path)]
        self.p = subprocess.Popen(args, stdin=subprocess.PIPE)

    def write(self, rgb: np.ndarray) -> None:
        self.p.stdin.write(rgb.astype(np.uint8).tobytes())

    def close(self) -> None:
        self.p.stdin.close()
        if self.p.wait():
            raise RuntimeError("the video couldn't be written")


def _frames(path, every: int = 1):
    import cv2
    cap = cv2.VideoCapture(str(path))
    i = 0
    while True:
        ok, f = cap.read()
        if not ok:
            break
        if i % every == 0:
            yield i, cv2.cvtColor(f, cv2.COLOR_BGR2RGB)
        i += 1
    cap.release()


def _fit(rgb: np.ndarray, w: int = 1920, h: int = 1080) -> np.ndarray:
    """Letterboxed, so the whole of the real frame stays visible."""
    import cv2
    k = min(w / rgb.shape[1], h / rgb.shape[0])
    im = cv2.resize(rgb, (int(rgb.shape[1] * k), int(rgb.shape[0] * k)), interpolation=cv2.INTER_AREA if k < 1 else cv2.INTER_LINEAR)
    out = np.full((h, w, 3), (11, 17, 24), np.uint8)
    y, x = (h - im.shape[0]) // 2, (w - im.shape[1]) // 2
    out[y:y + im.shape[0], x:x + im.shape[1]] = im
    return out


def _chrome(rgb: np.ndarray, banner: str | None = None, active: str | None = None, text: str | None = None, ribbon: bool = True) -> np.ndarray:
    """The provenance label never leaves the screen, and the ribbon says which step this is."""
    from PIL import Image, ImageDraw
    img = Image.fromarray(rgb)
    d = ImageDraw.Draw(img, "RGBA")
    W, H = img.size
    if banner:
        f = _font(26)
        x0, _, x1, y1 = d.textbbox((0, 0), banner, font=f)
        d.rounded_rectangle((W - x1 - 58, 26, W - 26, 26 + y1 + 22), 10, fill=(35, 28, 13, 235), outline=(242, 184, 75, 255), width=2)
        d.text((W - x1 - 42, 34), banner, font=f, fill=(242, 184, 75, 255))
    if ribbon:
        f, x = _font(28), 36
        step = STEP.get((active or "").upper(), (active or "").upper())
        for name, col in RIBBON:
            on = active is None or step == name
            word = name
            w = d.textbbox((0, 0), word, font=f)[2]
            d.rounded_rectangle((x, H - 78, x + w + 32, H - 26), 10, fill=(16, 26, 36, 235 if on else 120), outline=col + ((255,) if on else (70,)), width=3 if on else 1)
            d.text((x + 16, H - 70), word, font=f, fill=col + ((255,) if on else (90,)))
            x += w + 56
    if text:
        f = _font(40)
        lines, cur = [], ""
        for word in text.split():
            if d.textbbox((0, 0), cur + " " + word, font=f)[2] > W - 200:
                lines.append(cur)
                cur = word
            else:
                cur = (cur + " " + word).strip()
        lines.append(cur)
        y = H - 110 - 54 * len(lines)
        for ln in lines:
            w = d.textbbox((0, 0), ln, font=f)[2]
            d.rectangle(((W - w) / 2 - 16, y - 4, (W + w) / 2 + 16, y + 50), fill=(0, 0, 0, 170))
            d.text(((W - w) / 2, y), ln, font=f, fill=(238, 245, 251, 255))
            y += 54
    return np.asarray(img.convert("RGB"))


def stops(path, fps: float, smallest_s: float = 0.2) -> list[float]:
    """When the machine comes to rest, in seconds. Lines of the opening land on these."""
    import cv2
    last, energy = None, []
    for _, f in _frames(path):
        g = cv2.resize(cv2.cvtColor(f, cv2.COLOR_RGB2GRAY), (160, 90), interpolation=cv2.INTER_AREA).astype(np.float32)
        energy.append(0.0 if last is None else float(np.abs(g - last).mean()))
        last = g
    e = np.convolve(np.asarray(energy), np.ones(5) / 5, "same")
    moving = e > (np.median(e) + 0.5 * (np.quantile(e, 0.95) - np.median(e)))
    out, n = [], len(moving)
    i = 0
    while i < n - 1:
        if moving[i] and not moving[i + 1]:
            t = (i + 1) / fps
            if not out or t - out[-1] >= smallest_s:
                out.append(round(t, 3))
        i += 1
    return out


def opening(film, out: str | Path, fps: float, lines=HOOK, seconds: float = 15.0, play_fps: int = 30) -> str:
    """The typed opening, on the real test motion. Each line lands on one of the printer's real stops."""
    from PIL import Image, ImageDraw
    info = film_info(film)
    real = stops(film, fps)
    if len(real) >= len(lines):
        gaps = np.linspace(0, len(real) - 1, len(lines)).astype(int) if len(real) > 2 * len(lines) else np.arange(len(lines))
        when = [real[i] for i in gaps]
    else:      # no clear stops, as on a still cable: an even beat instead
        when = [0.4 + 1.5 * i for i in range(len(lines))]
    typing = len(lines[-1]) * 0.03
    if when[-1] + typing > seconds - 1.5:      # the last line is the point of the opening, so it always finishes and holds
        step = (seconds - 1.5 - typing - 0.4) / max(len(lines) - 1, 1)
        when = [0.4 + step * i for i in range(len(lines))]
    speed = 1.0
    vw = _Out(out, 1920, 1080, play_fps, film)
    stride = fps / play_fps
    f_big = _font(84)
    n = 0
    for i, f in _frames(film):
        if i < n * stride:
            continue
        t = n / play_fps * speed
        if t > seconds:
            break
        n += 1
        base = _fit(f)
        img = Image.fromarray((base * 0.72).astype(np.uint8))
        d = ImageDraw.Draw(img)
        y = 170
        for ln, at in zip(lines, when):
            if t < at:
                continue
            shown = ln[: int((t - at) / 0.03) + 1]
            d.text((96, y), shown, font=f_big, fill=(79, 227, 193) if ln == lines[-1] else (238, 245, 251))
            y += 112
        vw.write(_chrome(np.asarray(img), "REAL FILM", ribbon=False))
    vw.close()
    return str(out)


def overlay(clip, out: str | Path, banner: str, active: str | None = None, text: str | None = None, fps: float | None = None) -> str:
    """Puts the banner and the ribbon on any real clip."""
    info = film_info(clip)
    vw = _Out(out, 1920, 1080, fps or info["fps"], clip)
    for _, f in _frames(clip):
        vw.write(_chrome(_fit(f), banner, active, text))
    vw.close()
    return str(out)


def twin_beside_real(twin_file, real_film, sealed: dict, grade: dict, out: str | Path, play_fps: int = 30, seconds: float = 8.0, gain: float = 3.0) -> str:
    """Left, the twin's sealed forecast, ringing on the empty film's own frame. Right, the real coin on film, at the same slowed speed. The numbers are the claim."""
    import cv2
    tw = json.loads(Path(twin_file).read_text())
    fps = float(tw["fps"])
    _, first = next(_frames(tw["film"]))
    h, w = first.shape[:2]
    f = tw["field"]
    G = cv2.resize(np.asarray(f["data"], np.float32).reshape(f["h"], f["w"]), (w, h), interpolation=cv2.INTER_CUBIC)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    hz, z = float(sealed["payload"]["prediction"]["forecast_hz"]), float(tw["damping"] or 0.02)
    slow = play_fps / fps
    swing = 0.06 * min(h, w) * gain / 3
    vw = _Out(out, 1920, 1080, play_fps)
    real = _frames(real_film)
    every = max(int(round(fps / (play_fps / slow))), 1)
    for n in range(int(seconds * play_fps)):
        tau = n / play_fps * slow
        q = swing * math.exp(-z * 2 * math.pi * hz * tau) * math.cos(2 * math.pi * hz * tau)
        mx, my = (xx, yy - q * G) if tw["direction"] == "vertical" else (xx - q * G, yy)
        left = cv2.remap(first, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        try:
            for _ in range(every):
                _, r = next(real)
        except StopIteration:
            pass
        canvas = np.full((1080, 1920, 3), (11, 17, 24), np.uint8)
        canvas[210:210 + 540, 0:960] = _fit(left, 960, 540)
        canvas[210:210 + 540, 960:1920] = _fit(r, 960, 540)
        frame = _chrome(canvas, "LEFT: TWIN FORECAST · RIGHT: REAL FILM", "REALITY")
        from PIL import Image, ImageDraw
        img = Image.fromarray(frame)
        d = ImageDraw.Draw(img)
        d.text((60, 110), f"Sealed {sealed['anchor']}: {hz} Hz", font=_font(44), fill=(79, 227, 193))
        d.text((1020, 110), f"Measured: {grade['measured_hz']} Hz", font=_font(44), fill=(242, 184, 75))
        d.text((60, 790), f"Off by {grade['error_pct_of_shift']}% of the shift. Doing nothing was off by {grade['do_nothing_pct_of_tone']}% of the tone, and this by {grade['error_pct_of_tone']}%.", font=_font(32, False), fill=(138, 160, 180))
        vw.write(np.asarray(img))
    vw.close()
    return str(out)


def seal_clip(out: str | Path, anchor: str, line: str, seconds: float = 4.0) -> str:
    def draw(fig, t):
        S.label(fig, "SEALED BEFORE THE RESULT EXISTS")
        fig.text(.5, .62, line, color=S.FG, fontsize=40, ha="center", fontweight="bold", wrap=True, alpha=S.fade(t, 0))
        fig.text(.5, .44, "SEALED " + anchor[: int(max(t - .8, 0) / .06)], color=S.TEAL, fontsize=44, ha="center", family="monospace", fontweight="bold")
        fig.text(.5, .3, "It can't change its answer now.", color=S.DIM, fontsize=28, ha="center", alpha=S.fade(t, 2.2))
    return S.render(out, draw, seconds)


def card(out: str | Path, seconds: float = 7.0) -> str:
    """One card of real results, each row tagged with what kind of data it is."""
    from physica.studio.demo import recordings
    rows = recordings()

    def draw(fig, t):
        S.headline(fig, "The same feel, on real machines", S.fade(t, 0))
        S.label(fig, "REAL DATA · SIMULATED MISSION MARKED")
        for i, r in enumerate(rows):
            y = .78 - i * .205
            a = S.fade(t, .3 + i * .55)
            fig.text(.04, y, r["big"], color=S.TEAL, fontsize=34, fontweight="bold", va="center", alpha=a)
            fig.text(.31, y + .03, _wrap(r["line"], 96), color=S.FG, fontsize=18, va="center", alpha=a)
            fig.text(.31, y - .05, _wrap(r["limit"], 112), color=S.DIM, fontsize=14, va="center", alpha=a)
    return S.render(out, draw, seconds)


def _wrap(text: str, width: int) -> str:
    import textwrap
    return "\n".join(textwrap.wrap(text, width))


def table(out: str | Path, seconds: float = 10.0) -> str:
    """Is Muse needed? The table, and the blade tie. Only from saved results."""
    from physica.studio.demo import data
    d = data()
    if not d.get("needed"):
        raise ValueError("no saved with-and-without run yet. Run: python -m physica.cli cables test final.mp4 --allow-billed-meta")
    n = d["needed"]

    def draw(fig, t):
        S.headline(fig, f"Is Muse needed? {n['machines']} machines it had never seen", S.fade(t, 0))
        S.label(fig, "LIVE META CALLS · RECEIPTS SAVED")
        head = ("", "Tone right", "Right part", "Median error", "Words typed")
        xs = (.04, .55, .68, .81, .94)
        for x, h in zip(xs, head):
            fig.text(x, .82, h, color=S.DIM, fontsize=20, ha="left" if x == xs[0] else "center")
        for i, r in enumerate(n["summary"].values()):
            y, a = .74 - i * .085, S.fade(t, .4 + i * .4)
            cells = (r["name"], f"{r['tone_right']}/{r['machines']}", "–" if r["right_part"] is None else f"{r['right_part']}/{r['parts_scored']}", "–" if r["median_error_pct"] is None else f"{r['median_error_pct']}%", str(r["typed_words"]))
            full = "Muse, SAM and Physica" in r["name"]
            for x, c in zip(xs, cells):
                fig.text(x, y, c, color=S.TEAL if full else S.FG, fontsize=23, ha="left" if x == xs[0] else "center", fontweight="bold" if full else "normal", alpha=a)
        if d.get("blade"):
            blade = "  ·  ".join(f"{x['name']} {x['right']}/{d['blade']['cases']}" for x in d["blade"]["arms"])
            fig.text(.04, .13, "On real blade tests, with no new sense, Muse tied:", color=S.FG, fontsize=21, alpha=S.fade(t, 4))
            fig.text(.04, .08, blade, color=S.AMBER, fontsize=19, alpha=S.fade(t, 4))
    return S.render(out, draw, seconds)


def tacoma_reveal(out: str | Path, case: dict, seconds: float = 12.0) -> str:
    """What Muse really said about the film, the arithmetic, then the stopwatch. If Muse proposed no correction, the published explanation is shown, credited."""
    import textwrap
    r = case["reading"]
    why = (case.get("muse_on_film_speed") or {}).get("why")
    corrected = case.get("corrected_cpm")
    speed = case.get("muse_on_film_speed") or {}

    def draw(fig, t):
        S.label(fig, "REAL 1940 FILM · LIVE MUSE" if why else "REAL 1940 FILM · PUBLISHED ANALYSIS")
        fig.text(.06, .82, f"Felt from the film as it plays: {r['cpm']} cycles per minute", color=S.TEAL, fontsize=34, fontweight="bold", alpha=S.fade(t, 0))
        fig.text(.06, .73, f"Published count of the same video: {case['published_playback_cpm']:g}", color=S.FG, fontsize=28, alpha=S.fade(t, 1))
        if corrected:
            fig.text(.06, .62, "Muse: " + "\n".join(textwrap.wrap(str(why), 92)), color=(.70, .62, 1.0), fontsize=25, va="top", alpha=S.fade(t, 2.5))
            fig.text(.06, .36, f"Code: {r['cpm']} x {speed['shot_fps']:g} / {speed['treated_as_fps']:g} = {corrected}", color=S.FG, fontsize=36, fontweight="bold", alpha=S.fade(t, 5.5))
        else:
            if why:
                fig.text(.06, .62, "Muse: " + "\n".join(textwrap.wrap(str(why), 92)), color=(.70, .62, 1.0), fontsize=25, va="top", alpha=S.fade(t, 2.5))
            fig.text(.06, .36 if why else .55, "Published analysis: the video plays 50% fast, because a 16 fps film was converted as if 24 fps", color=S.FG, fontsize=25, alpha=S.fade(t, 5.5 if why else 3))
        fig.text(.06, .2 if (why or corrected) else .34, f"The stopwatch, 1940: {case['published_true_cpm']:g} cycles per minute", color=S.AMBER, fontsize=44, fontweight="bold", alpha=S.fade(t, 8 if (why or corrected) else 5.5))
        fig.text(.06, .1, "\n".join(textwrap.wrap(f"Film: {case['credit']}.", 135)[:2]), color=S.DIM, fontsize=16, va="top", alpha=S.fade(t, 8.5))
    return S.render(out, draw, seconds)


def ending(out: str | Path, lines=ENDING, seconds: float = 5.0) -> str:
    def draw(fig, t):
        for i, ln in enumerate(lines):
            at = i * 1.2
            shown = ln[: int(max(t - at, 0) / .035)]
            fig.text(.08, .66 - i * .16, shown, color=S.TEAL if i == len(lines) - 1 else S.FG, fontsize=62 if i < len(lines) - 1 else 44, fontweight="bold", va="center")
    return S.render(out, draw, seconds)


def hear(out: str | Path, hz: float, damping: float, times: float = 16.0, seconds: float = 4.0, rate: int = 44100) -> dict:
    """A measured tone you can hear: the same decay, with the pitch raised and labelled as raised. Not a recording of the machine."""
    pitch = hz * times
    t = np.arange(int(seconds * rate)) / rate
    y = np.exp(-damping * 2 * np.pi * hz * t) * np.sin(2 * np.pi * pitch * t)
    with wave.open(str(out), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes((y * 26000).astype(np.int16).tobytes())
    return {"file": str(out), "pitch_hz": round(pitch, 1), "raised_times": times}


def feel_film(film, out: str | Path, fps: float, session: dict, play_fps: int = 30, seconds: float = 12.0) -> str:
    """The film at slow speed, with each cable's own measured motion drawn live beside its name. The lines are real readings, shown slowed."""
    import cv2

    from physica.meta import scout as SC
    from physica.touch import cables as C
    from PIL import Image, ImageDraw
    boxes, dirs = {k: tuple(v) for k, v in session["boxes"].items()}, session.get("directions", {})
    traces = {}
    for name, box in boxes.items():
        V, _ = SC.load_region(film, box, most_frames=2048, long_side=192)
        y = C.main_signal(V, dirs.get(name, "horizontal"))
        traces[name] = y / max(float(np.quantile(np.abs(y), .995)), 1e-9)
    info = film_info(film)
    vw = _Out(out, 1920, 1080, play_fps)
    stride = max(int(round(fps / (play_fps * 8))), 1)
    colours = [c for *_, c in RIBBON][:4] + [(255, 157, 179), (120, 220, 255)]
    n_show = int(seconds * play_fps)
    n = 0
    for i, f in _frames(film, stride):
        if n >= n_show:
            break
        n += 1
        k = min(1920 / info["w"], 1080 / info["h"])
        x0, y0 = (1920 - info["w"] * k) / 2, (1080 - info["h"] * k) / 2
        img = Image.fromarray(_chrome(_fit(f), "REAL FILM · SHOWN 8X SLOWER", "PHYSICA"))
        d = ImageDraw.Draw(img)
        for j, (name, box) in enumerate(boxes.items()):
            col = colours[j % len(colours)]
            d.rectangle((x0 + box[0] * k, y0 + box[1] * k, x0 + box[2] * k, y0 + box[3] * k), outline=col, width=2)
            d.text((x0 + box[0] * k, max(y0 + box[1] * k - 34, 4)), name, font=_font(24), fill=col)
            tr = traces[name]
            base = 150 + j * 74
            pts = [(40 + q * 2, base - 24 * float(tr[min(max(i - (200 - q) * 2, 0), len(tr) - 1)])) for q in range(200)]
            d.line(pts, fill=col, width=2)
        vw.write(np.asarray(img))
    vw.close()
    return str(out)


def reveal_clip(out: str | Path, graded: dict, seconds: float = 9.0) -> str:
    """Physica's sealed grams, then the scale, one cable at a time. Real results only."""
    rows = list(graded["cables"].items())

    def draw(fig, t):
        S.headline(fig, "Sealed first. Then the scale.", S.fade(t, 0))
        S.label(fig, "REAL FILM · KITCHEN SCALE")
        fig.text(.45, .78, "Felt, sealed", color=S.DIM, fontsize=24, ha="center")
        fig.text(.65, .78, "Scale", color=S.DIM, fontsize=24, ha="center")
        fig.text(.85, .78, "Off by", color=S.DIM, fontsize=24, ha="center")
        for i, (name, r) in enumerate(rows):
            y = .68 - i * .13
            fig.text(.05, y, name, color=S.FG, fontsize=30)
            fig.text(.45, y, f"{r.get('physica_g', chr(8211))} g" if "physica_g" in r else "can't tell", color=S.TEAL, fontsize=36, ha="center", fontweight="bold", alpha=S.fade(t, .4))
            at = 1.6 + i * 1.3
            fig.text(.65, y, f"{r['scale_g']:g} g", color=S.AMBER, fontsize=36, ha="center", fontweight="bold", alpha=S.fade(t, at))
            if "error_pct" in r:
                fig.text(.85, y, f"{r['error_pct']}%", color=S.FG, fontsize=30, ha="center", alpha=S.fade(t, at + .3))
        fig.text(.05, .07, f"Median error {graded['median_error_pct']}%. Sharing the total equally: {graded['equal_share_error_pct']}%.", color=S.DIM, fontsize=24, alpha=S.fade(t, 1.6 + len(rows) * 1.3))
    return S.render(out, draw, seconds)


def sway_clip(film, out: str | Path, reading: dict, corrected: dict | None = None, play_fps: int = 30) -> str:
    """The real film, with the roll Physica measured drawn live under it. The film's own speed is kept."""
    from PIL import Image, ImageDraw
    tr = np.asarray(reading["roll_trace"], float)
    tr = tr - np.polyval(np.polyfit(np.arange(len(tr)), tr, 2), np.arange(len(tr)))
    top = max(float(np.abs(tr).max()), 1e-6)
    vw = _Out(out, 1920, 1080, play_fps)
    for i, f in _frames(film):
        img = Image.fromarray(_chrome(_fit(f), "REAL FILM, 1940 · READ BY PHYSICA", "PHYSICA"))
        d = ImageDraw.Draw(img, "RGBA")
        d.rectangle((30, 840, 1890, 990), fill=(0, 0, 0, 170))
        pts = [(40 + 1840 * q / max(len(tr) - 1, 1), 938 - 46 * tr[q] / top) for q in range(min(i + 1, len(tr)))]
        if len(pts) > 1:
            d.line(pts, fill=(79, 227, 193, 255), width=4)
        d.text((46, 846), f"Twist measured from the film: {reading['cpm']} cycles per minute as it plays", font=_font(30), fill=(238, 245, 251, 255))
        vw.write(np.asarray(img.convert("RGB")))
    vw.close()
    return str(out)


def feel_strings(film, out: str | Path, strings: dict, fps: float = 600.0, gain: float = 30.0, width: float = 9.0, rate: int = 44100) -> str:
    """Feel you can see and hear, from one silent film. Each string's own tone is pulled out of the pixels: those pixels light up and their motion is enlarged, labelled as enlarged. The sound is that same pixel motion, at its real pitch. Nothing is drawn or synthesised from a formula."""
    from scipy.signal import resample
    frames = [f for _, f in _frames(film)]
    rgb = np.stack(frames).astype(np.float32)
    grey = rgb.mean(axis=3)
    T = grey.shape[0]
    spec = np.fft.rfft(grey, axis=0)
    hz = np.fft.rfftfreq(T, 1 / fps)
    colours = [np.array([255.0, 90.0, 70.0]), np.array([70.0, 210.0, 255.0])]
    parts = []
    for (name, s), col in zip(strings.items(), colours):
        keep = ((hz >= s["tone_hz"] - width) & (hz <= s["tone_hz"] + width)).reshape(-1, 1, 1)
        band = np.fft.irfft(spec * keep, n=T, axis=0).astype(np.float32)
        energy = np.sqrt((band ** 2).mean(axis=0))
        glow = np.clip(energy / max(float(np.percentile(energy, 99.7)), 1e-6), 0, 1)[..., None]
        idx = np.argsort(energy.ravel())[-400:]
        u, sv, _ = np.linalg.svd(band.reshape(T, -1)[:, idx], full_matrices=False)
        tone = u[:, 0] * sv[0]
        tone = tone / max(float(np.abs(tone).max()), 1e-9)
        sound = resample(tone, int(T / fps * rate))
        ramp = np.minimum(1, np.minimum(np.arange(sound.size), np.arange(sound.size)[::-1]) / (0.02 * rate))
        parts.append({"name": name, "s": s, "band": band, "glow": glow, "col": col, "sound": sound * ramp})
    shown = 30
    plain, each, end = 3 * shown, 5 * shown, 4 * shown
    wav = np.zeros(int((plain + each * len(parts) + end) / shown * rate))
    vw_path = Path(out).with_suffix(".sound.wav")
    for i, p in enumerate(parts):
        for at in (0.6, 2.8):
            start = int((plain / shown + i * each / shown + at) * rate)
            wav[start:start + p["sound"].size] += p["sound"]
    with wave.open(str(vw_path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes((np.clip(wav, -1, 1) * 26000).astype(np.int16).tobytes())
    vw = _Out(out, 1920, 1080, shown, vw_path)
    banner = "REAL 600 FPS FILM · WU ET AL., MIT"
    for n in range(plain):
        vw.write(_chrome(_fit(rgb[n % T].astype(np.uint8)), banner, "WATCH", "A silent film. The strings look still."))
    for p in parts:
        label = f"{p['name']}: {p['s']['tone_hz']} Hz. Motion enlarged {gain:g} times. Sound from the pixels, at real pitch."
        for n in range(each):
            k = n % T
            f = rgb[k] + gain * p["band"][k][..., None]
            f = f * (1 - 0.55 * p["glow"]) + p["col"] * 0.55 * p["glow"]
            vw.write(_chrome(_fit(np.clip(f, 0, 255).astype(np.uint8)), banner, "FEEL", label))
    words = "  ".join(f"{k}: {v['tone_hz']} Hz, tuning {v['tuning_hz']}." for k, v in strings.items())
    still = rgb[T // 2].copy()
    for p in parts:
        still = still * (1 - 0.6 * p["glow"]) + p["col"] * 0.6 * p["glow"]
    still = np.clip(still, 0, 255).astype(np.uint8)
    for _ in range(end):
        vw.write(_chrome(_fit(still), banner, "GRADE", words))
    vw.close()
    vw_path.unlink(missing_ok=True)
    return str(out)


def twin_clip(film, out: str | Path, strings: dict, fps: float = 600.0, gain: float = 30.0, seconds: float = 10.0, play_fps: int = 30) -> str:
    """The real film beside its twin, then the twin pushed where the film can't go: a tighter string. Every number comes from the film, and the forecast is graded on raw pixels it didn't learn from."""
    import cv2
    from physica.twin import strings as X
    tones = {k: v["tone_hz"] for k, v in strings.items()}
    name = next(iter(tones))
    t = X.read(film, fps, {name: tones[name]})[name]
    frames = np.stack([f for _, f in _frames(film)]).astype(np.float32)
    T, h, w = frames.shape[:3]
    grey = frames.mean(axis=3)
    spec = np.fft.rfft(grey, axis=0)
    hz = np.fft.rfftfreq(T, 1 / fps)
    keep = ((hz >= tones[name] - X.WIDTH_HZ) & (hz <= tones[name] + X.WIDTH_HZ)).reshape(-1, 1, 1)
    band = np.fft.irfft(spec * keep, n=T, axis=0).astype(np.float32)
    field = cv2.resize(np.array(t["field"]["data"], np.float32).reshape(t["field"]["h"], t["field"]["w"]), (w, h), interpolation=cv2.INTER_LINEAR)
    xx, yy = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    base = frames[T // 2].astype(np.uint8)
    decay = t["decay_per_s"]
    vw = _Out(out, 1920, 1080, play_fps)
    h0 = t["holdout"]
    side = int(seconds * .6 * play_fps)
    words = f"Left: the real film, enlarged. Right: the twin. Learned from {h0['learned_on_s']} s, it forecast the next {h0['predicted_s']} s of raw pixels: match {h0['match_r']}."

    def twin_frame(sec, tone):
        q = 2.5 * np.exp(-decay * sec) * np.cos(2 * np.pi * tone * sec)
        return cv2.remap(base, xx, (yy - q * field).astype(np.float32), cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    for n in range(side):
        k = n % T
        real = np.clip(frames[k] + gain * band[k][..., None], 0, 255).astype(np.uint8)
        vw.write(_chrome(_fit(np.hstack([real, twin_frame(k / fps, t["tone_hz"])])), "REAL FILM · ITS DIGITAL TWIN", "FEEL", words))
    tight = t["tone_hz"] * np.sqrt(1.1)
    for n in range(int(seconds * play_fps) - side):
        vw.write(_chrome(_fit(np.hstack([twin_frame(n / fps, t["tone_hz"]), twin_frame(n / fps, tight)])), "DIGITAL TWIN · FORECAST", "FEEL", f"Left: as filmed, {t['tone_hz']} Hz. Right: tightened 10%. The twin forecasts {tight:.1f} Hz."))
    vw.close()
    return str(out)


def beam_clip(film, out: str | Path, seconds: float = 11.0) -> str:
    """A real beam, hit once. It learns from the first moments, the forecast is drawn on, and the real motion follows it. Motion in the picture is enlarged from what was measured, and says so."""
    import cv2
    from physica.twin import strike as K
    r = K.read(film)
    tr, h = r["trace"], r["holdout"]
    real, guess, n1 = np.array(tr["real"]), np.array(tr["forecast"]), tr["learned_samples"]
    grey = K._grey(film)
    shape = cv2.resize(np.array(r["shape"], np.float32).reshape(1, -1), (grey.shape[2], 1))
    xx, yy = np.meshgrid(np.arange(grey.shape[2], dtype=np.float32), np.arange(grey.shape[1], dtype=np.float32))
    start = int(np.argmax(np.abs(np.gradient(grey.mean(axis=(1, 2))))))
    ms = np.arange(real.size) / tr["fps"] * 1000

    def draw(fig, t):
        n = min(real.size - 1, int(real.size * min(1, t / (seconds * .8))))
        frame = grey[min(grey.shape[0] - 1, n + 9)]
        warped = cv2.remap(frame, xx, yy - (real[n] * 8.0 * shape).astype(np.float32), cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        S.label(fig, "REAL FILM · 10,000 FPS · LADISK, PYIDI")
        S.headline(fig, "A real beam, hit once", 1)
        top = S.axes(fig, [.05, .68, .9, .18])
        top.imshow(warped, cmap="gray", aspect="auto", vmin=0, vmax=110)
        top.set_xticks([])
        top.set_yticks([])
        ax = S.axes(fig, [.07, .17, .88, .44])
        ax.axvspan(0, ms[n1], color=S.TEAL, alpha=.12)
        ax.plot(ms[:n + 1], real[:n + 1], color=S.FG, lw=2.2, label="real motion, raw pixels")
        if n >= n1:
            ax.plot(ms[n1:], guess[n1:], color=S.AMBER, lw=2.4, ls="--", label="the twin's forecast")
            ax.legend(loc="upper right", fontsize=20, facecolor=S.BG, edgecolor=S.BG, labelcolor=S.FG)
        ax.set_xlim(0, ms[-1])
        ax.set_ylim(real.min() * 1.15, real.max() * 1.15)
        ax.set_xlabel("milliseconds after the hit")
        ax.set_ylabel("pixels")
        ax.text(ms[n1] / 2, real.max() * .92, "it learned here", color=S.TEAL, fontsize=19, ha="center")
        fig.text(.07, .05, f"Forecast of the next {int(h['predicted_s'] * 1000)} ms: match {h['match_r']}, {h['closer_than_stopping_pct']}% closer than assuming it just stops. Picture motion enlarged 8 times.", color=S.FG, fontsize=20, alpha=S.fade(t, seconds * .8))
    return S.render(out, draw, seconds)


def muse_live(out: str | Path, cases: dict, written: dict, seconds: float = 16.0) -> str:
    """What Muse really said and did in the live run, word for word from the saved results. Fails if nothing live was saved, rather than writing Muse's words for it."""
    import textwrap
    slides = []
    tac, gui = cases.get("tacoma") or {}, cases.get("guitar") or {}
    if tac.get("muse_saw"):
        rows = [f"Muse watched the 1940 film: {tac['muse_saw'].get('machine')}. {tac['muse_saw'].get('seen')}"]
        why = (tac.get("muse_on_film_speed") or {}).get("why")
        if why:
            rows.append(f"Muse on the film's speed: {why}")
        slides.append(("MUSE WATCHES THE FILM", rows))
    if gui.get("muse_saw"):
        rows = [f"Muse watched the guitar: {gui['muse_saw'].get('machine')}. {gui['muse_saw'].get('seen')}"]
        for k, v in (gui.get("muse_found") or {}).items():
            rows.append(f"Muse pointed, SAM pinned, it felt: {k}: " + (f"{v.get('tone_hz')} Hz" if v.get("felt") else "can't tell"))
        slides.append(("MUSE POINTS, SAM PINS", rows))
    wrote = []
    for k, r in written.items():
        bad = [c["check"] for c in r["tries"][0]["checks"] if not c["ok"]]
        said = f"{r['language']}: " + (f"round 1 failed ({bad[0]}). Fixed by round {r['rounds']}." if bad and r["passed"] else "passed every check." if r["passed"] else f"not passed after {r['rounds']} rounds.")
        wrote.append(said)
    if wrote:
        slides.append(("MUSE WRITES THE MACHINE FILE, CODE CHECKS IT", wrote))
    if not slides:
        raise ValueError("nothing live has been saved yet")
    each = seconds / len(slides)

    def draw(fig, t):
        i = min(len(slides) - 1, int(t / each))
        local = t - i * each
        S.label(fig, "LIVE MUSE AND SAM · THEIR REAL OUTPUT")
        S.headline(fig, slides[i][0].capitalize(), 1)
        y = .78
        for k, row in enumerate(slides[i][1][:5]):
            lines = textwrap.wrap(str(row), 74)[:4]
            fig.text(.06, y, "\n".join(lines), color=(.78, .72, 1.0) if k == 0 else S.FG, fontsize=30, va="top", linespacing=1.3, alpha=S.fade(local, .2 + k * .9))
            y -= .075 * len(lines) + .05
    return S.render(out, draw, seconds)


def credits_clip(out: str | Path, seconds: float = 4.0, skip: tuple = ()) -> str:
    from physica.meta import cases as CS
    rows = [("Tacoma Narrows", CS.TACOMA["credit"]), ("Guitar", CS.GUITAR["credit"]), ("Beam", CS.BEAM["credit"])]
    rows = [r for r in rows if r[0] not in skip]

    def draw(fig, t):
        S.headline(fig, "Films by others, with thanks", 1)
        for i, (a, b) in enumerate(rows):
            fig.text(.06, .72 - i * .2, a, color=S.TEAL, fontsize=28, fontweight="bold", alpha=S.fade(t, 0))
            fig.text(.06, .66 - i * .2, _wrap(b, 110), color=S.FG, fontsize=21, va="top", alpha=S.fade(t, 0))
    return S.render(out, draw, seconds)


def within_limit(folder: str | Path, order: list[str], limit_s: float = 178.0, first_to_go: tuple[str, ...] = ("10_results_card.mp4",)) -> list[str]:
    """The film has a three-minute limit. If it runs over, the clips that repeat results go first."""
    folder = Path(folder)
    have = [n for n in order if (folder / n).exists()]

    def seconds(n):
        i = film_info(folder / n)
        return i["frames"] / i["fps"]
    total = sum(seconds(n) for n in have)
    for n in first_to_go:
        if total > limit_s and n in have:
            total -= seconds(n)
            have.remove(n)
    return have


def whole_film(folder: str | Path, order: list[str], out_name: str = "00_whole_film.mp4") -> str | None:
    """Every clip in film order, as one file, so nothing has to be stitched by hand. Clips without sound get silence."""
    import tempfile
    folder = Path(folder)
    have = [folder / n for n in order if (folder / n).exists()]
    if not have:
        return None
    with tempfile.TemporaryDirectory() as d:
        parts = []
        for i, clip in enumerate(have):
            probe = subprocess.run([ffmpeg(), "-i", str(clip)], capture_output=True, text=True, errors="replace").stderr
            part = Path(d) / f"{i:02d}.mp4"
            cmd = [ffmpeg(), "-y", "-v", "error", "-i", str(clip)]
            if "Audio:" not in probe:
                cmd += ["-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=44100", "-shortest", "-map", "0:v", "-map", "1:a"]
            else:
                cmd += ["-map", "0:v", "-map", "0:a"]
            cmd += ["-vf", "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,fps=30", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-ar", "44100", "-ac", "2", str(part)]
            subprocess.run(cmd, check=True)
            parts.append(part)
        listing = Path(d) / "list.txt"
        listing.write_text("".join(f"file '{p.as_posix()}'\n" for p in parts))
        subprocess.run([ffmpeg(), "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(listing), "-c", "copy", "-movflags", "+faststart", str(folder / out_name)], check=True)
    return str(folder / out_name)


def goal_clip(out: str | Path, seconds: float = 9.0) -> str:
    """Type a change: the sentence, the real tests, the file. From a saved live run if there is one, and otherwise run now by code, and labelled so."""
    from physica.outcome import goalbox as G
    r = json.loads(G.OUT.read_text()) if G.OUT.exists() else G.run(G.EXAMPLE, on_step=lambda s: None)
    if r.get("status") != "WRITTEN":
        raise ValueError(r.get("why") or "no file was written")
    e, f = r["experiments"], r["machine_file"]
    by = "BY MUSE" if str(f["written_by"]).startswith("Muse") else "BY CODE"

    def draw(fig, t):
        S.label(fig, f"REAL LAB BEAM · FILE {by} · A PERSON REVIEWS")
        S.headline(fig, "Type a change", 1)
        fig.text(.05, .84, _wrap("\u201c" + r["goal"] + "\u201d", 88), color=S.FG, fontsize=23, va="top", alpha=S.fade(t, .1))
        fig.text(.05, .68, f"{e['places_tried']} places tried. {e['places_clear']} looked clear. Each sealed, then tested on real moments:", color=S.DIM, fontsize=22, alpha=S.fade(t, 1.2))
        for i, x in enumerate(e["tests"][:4]):
            fig.text(.05, .61 - i * .065, f"{x['mm']} mm  forecast {x['forecast_hz']} Hz  {x['result']}", color=S.TEAL if x["held"] else S.RED, fontsize=22, family="monospace", alpha=S.fade(t, 2 + i * .6))
        lines = [ln for ln in f["file"].splitlines() if ln.strip() and not ln.startswith((";", "("))][:4]
        fig.text(.05, .3, f"Best: move {e['move_mm']} mm", color=S.TEAL, fontsize=30, fontweight="bold", alpha=S.fade(t, 5))
        fig.text(.05, .24, "\n".join(z.strip()[:70] for z in lines), color=(.78, .91, .87), fontsize=19, family="monospace", va="top", linespacing=1.4, alpha=S.fade(t, 5.5))
    return S.render(out, draw, seconds)


def muse_decides(out: str | Path, seconds: float = 12.0) -> str:
    """Muse's real words on the real use cases. Fails if there are none, and leaves out any reply that added numbers."""
    import textwrap
    from physica.outcome import muse_reads as M
    rows = [r for r in (json.loads(M.OUT.read_text()) if M.OUT.exists() else {"cases": {}})["cases"].values() if r.get("numbers_ok")]
    if not rows:
        raise ValueError("Muse hasn't read these live yet")
    rows = rows[:6]
    gap = .84 / max(len(rows), 3)

    def draw(fig, t):
        S.label(fig, "LIVE MUSE · ITS REAL WORDS")
        S.headline(fig, "Muse reads what was felt, and decides", 1)
        y = .84
        for i, r in enumerate(rows):
            a = S.fade(t, .3 + i * 1.3)
            fig.text(.05, y, r["title"], color=S.TEAL, fontsize=19, fontweight="bold", alpha=a)
            fig.text(.05, y - .032, "\n".join(textwrap.wrap(str(r["do_next"]), 118)[:2]), color=S.FG, fontsize=18, va="top", linespacing=1.25, alpha=a)
            y -= gap
    return S.render(out, draw, seconds)


def machine_files(out: str | Path, seconds: float = 11.0) -> str:
    """A sentence goes in and a real machine file comes out. If Muse wrote them live, these are its files and its real rounds. If not, the files code wrote, labelled so."""
    from physica import config
    from physica.outcome import speak as K
    res = config.REPO_ROOT / "eval" / "results"
    e23 = json.loads((res / "E23_program_by_outcome.json").read_text())
    folder = res / "outcome"
    pol = e23["A_beam"]["policies"]["physica"]
    fl = e23["C_drone"]["flight"]
    said = (json.loads(K.OUT.read_text()) if K.OUT.exists() else {}).get("machines", {})
    recs = K.records()
    code = {"beam": ((folder / "support_move.gcode").read_text(), f"Checked on real recordings: {pol['goals_met_by_status']['act'][0]} of {pol['goals_met_by_status']['act'][1]} moves met the goal"),
            "turbine": ((folder / "blade_guard.st").read_text(), "Compiled by " + e23["B_turbine"]["plc"]["compile"]["tool"].split(" (")[0] + ". For review, not certified"),
            "drone": ((folder / "blade_inspection.waypoints").read_text(), f"ArduPilot's simulator: {fl['waypoints_reached']} of {fl['waypoints']} waypoints, landed")}

    def lines(text, machine):
        text = re.sub(r"\(\*.*?\*\)", " ", text, flags=re.S)
        rows = [x for x in text.splitlines() if x.strip() and not x.startswith(";")]
        if machine == "turbine":
            rows = [x for x in rows if any(w in x for w in ("IF VERDICT", "ELSIF VERDICT", "HEATERS_ON := TRUE", "BRAKE := TRUE"))] or rows
        return rows[:4]
    rows = []
    short = {"beam": "G-code", "turbine": "PLC code", "drone": "Drone mission"}
    for k in ("beam", "turbine", "drone"):
        r = said.get(k)
        if r and r.get("passed"):
            last = r["tries"][-1]
            fixed = f"Round 1 failed {sum(not c['ok'] for c in r['tries'][0]['checks'])} checks. Muse fixed it. " if r["rounds"] > 1 else ""
            rows.append((recs[k]["goal"], short[k] + " · by Muse", lines(last["file"], k), f"{fixed}{len(last['checks'])} of {len(last['checks'])} checks passed"))
        else:
            rows.append((recs[k]["goal"], short[k] + " · by code", lines(code[k][0], k), code[k][1]))
    by_muse = any("by Muse" in r[1] for r in rows)

    def draw(fig, t):
        S.label(fig, ("BY MUSE · CHECKED BY CODE · A PERSON REVIEWS" if by_muse else "REAL FILES · A PERSON REVIEWS EACH ONE"))
        S.headline(fig, "Felt goes in. A machine file comes out.", S.fade(t, 0))
        for i, (goal, kind, text, check) in enumerate(rows):
            x, a = .03 + i * .325, S.fade(t, .4 + i * 1.3)
            fig.text(x, .82, _wrap(goal, 40), color=S.FG, fontsize=18, va="top", alpha=a)
            fig.text(x, .56, kind, color=S.TEAL, fontsize=21, fontweight="bold", alpha=a)
            fig.text(x, .5, "\n".join(" ".join(z.split())[:50] for z in text), color=(.78, .91, .87), fontsize=14, family="monospace", va="top", linespacing=1.5, alpha=a)
            fig.text(x, .24, _wrap(check, 40), color=S.AMBER, fontsize=18, va="top", alpha=S.fade(t, 1.2 + i * 1.3))
    return S.render(out, draw, seconds)


ORDER = ["01_opening.mp4", "02_tacoma_read.mp4", "03_tacoma_reveal.mp4", "03b_muse_live.mp4", "04_guitar_masks.mp4", "05_guitar_feel.mp4", "05c_beam_twin.mp4", "06_use_downtime.mp4", "07_use_turbine_and_drone.mp4", "08b_muse_decides.mp4", "09_machine_files.mp4", "09b_type_a_change.mp4", "10_results_card.mp4", "11_ending.mp4", "12_credits.mp4"]


def remake_opening(out_dir: str | Path = "demo_clips") -> str:
    """Only the opening and Muse's decisions, then the whole film joined again, in a couple of minutes."""
    from physica.meta import cases as CS
    opening(CS.CLIPS / CS.TACOMA["file"], Path(out_dir) / "01_opening.mp4", 30.0, seconds=8.0)
    try:
        muse_decides(Path(out_dir) / "08b_muse_decides.mp4")
    except ValueError as e:
        print(f"Left out 08b_muse_decides: {e}")
    return whole_film(out_dir, within_limit(out_dir, ORDER))


def pack(out_dir: str | Path = "demo_clips", on_step=print) -> dict:
    """Every clip the film can have right now, from saved results. A clip that can't be made is listed with the reason, never faked."""
    from physica.meta import cases as CS

    from . import downtime as DT, turbine as TB
    out = Path(out_dir)
    out.mkdir(exist_ok=True)
    saved = json.loads(CS.OUT.read_text()) if CS.OUT.exists() else {"cases": {}}
    tac, gui = saved["cases"].get("tacoma") or {}, saved["cases"].get("guitar") or {}
    tfilm, gfilm = CS.CLIPS / CS.TACOMA["file"], CS.CLIPS / CS.GUITAR["file"]
    made, missing = [], []

    def make(name, fn):
        try:
            fn(out / name)
            made.append(name)
            on_step(f"Made {name}")
        except Exception as e:
            missing.append((name, str(e)[:160]))
            on_step(f"Couldn't make {name}: {str(e)[:160]}")
    make("01_opening.mp4", lambda p: opening(tfilm, p, 30.0, seconds=8.0))
    make("02_tacoma_read.mp4", lambda p: sway_clip(tfilm, p, CS.read_sway(tfilm)))
    if tac.get("reading"):
        make("03_tacoma_reveal.mp4", lambda p: tacoma_reveal(p, tac))
    else:
        missing.append(("03_tacoma_reveal.mp4", "run: python -m physica.cli meta cases"))
    live_cases = {k: v for k, v in saved["cases"].items() if v.get("live_meta")}
    from physica.outcome import speak as K
    written = (json.loads(K.OUT.read_text()) if K.OUT.exists() else {}).get("machines", {})
    if live_cases or written:
        make("03b_muse_live.mp4", lambda p: muse_live(p, live_cases, written, seconds=14.0))
    else:
        missing.append(("03b_muse_live.mp4", "only exists after Muse has run live, so Muse's words are never made up"))
    masks = CS.CLIPS / "guitar_masks.mp4"
    if masks.exists():
        make("04_guitar_masks.mp4", lambda p: overlay(masks, p, "REAL 600 FPS FILM · SAM 3.1 MASKS", "SAM"))
    else:
        missing.append(("04_guitar_masks.mp4", "only exists after a live run where SAM pins the strings. Otherwise the film goes straight to the next clip"))
    if gui.get("strings"):
        make("05_guitar_feel.mp4", lambda p: feel_strings(gfilm, p, gui["strings"]))
    else:
        missing.append(("05_guitar_feel.mp4", "run: python -m physica.cli meta cases"))
    if gui.get("strings"):
        make("05b_guitar_twin.mp4", lambda p: twin_clip(gfilm, p, gui["strings"]))
    if (CS.CLIPS / CS.BEAM["file"]).exists():
        make("05c_beam_twin.mp4", lambda p: beam_clip(CS.CLIPS / CS.BEAM["file"], p))
    make("06_use_downtime.mp4", DT.render)
    make("07_use_turbine_and_drone.mp4", lambda p: TB.render(p, short=True))
    make(lambda p: F1.render(p, short=True))
    from physica.outcome import muse_reads as MR
    if MR.OUT.exists():
        make("08b_muse_decides.mp4", muse_decides)
    else:
        missing.append(("08b_muse_decides.mp4", "only exists after Muse reads the use cases live"))
    make("09_machine_files.mp4", lambda p: machine_files(p, seconds=9.0))
    make("09b_type_a_change.mp4", lambda p: goal_clip(p, seconds=8.0))
    make("10_results_card.mp4", lambda p: card(p, seconds=9.0))
    make("11_ending.mp4", lambda p: ending(p, seconds=6.5))
    make("12_credits.mp4", credits_clip)
    order = ORDER
    make("00_whole_film.mp4", lambda p: whole_film(out, within_limit(out, order)) or (_ for _ in ()).throw(ValueError("no clips to join")))
    return {"made": made, "missing": missing, "folder": str(out)}
