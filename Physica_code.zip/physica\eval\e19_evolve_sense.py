"""E19 - Many proposals, one strict judge: Meta models invent new senses; real ground truth decides.

Real data (DROPBEAR beams A and B, see E16). Proposers write `tone(W, fs)` programs; Physica's physics turns each
window's tone into the hidden support's position; the lab's position transducer scores it in millimetres.
The search only ever sees beam A's FIRST half. The champion is then judged on A's second half and on beam B
(another machine). It replaces Physica's own sense (ESPRIT poles + continuity tracker) only if it wins on both.
Proposer: live Muse Wonder with MOCK=0 and MODEL_API_KEY; otherwise an offline stand-in (textbook estimators,
labelled NOT Meta) - which shows the loop and the judge, not what Meta would invent.
"""
from __future__ import annotations

import glob
import json
import os
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica.cause import discover as D  # noqa: E402
from physica.cause.track import track_tone  # noqa: E402
from physica.data import dropbear  # noqa: E402
from physica.llm import meta_client as mc  # noqa: E402
from physica.meta import evolve_sense as EV  # noqa: E402

OUT = ROOT / "eval" / "results"


def main(generations: int = 4, n: int = 8, swarm: int = 1):
    A_beam, B_beam = dropbear.beam_d2(), dropbear.beam_d8()
    dA = dropbear.load_d2(os.environ["PHYSICA_DROPBEAR2"])
    bareA, bareB = A_beam.bare(1)[0], B_beam.bare(1)[0]
    bandA, bandB = (0.5 * bareA, 3 * bareA), (0.5 * bareB, 3 * bareB)
    WA, fsA, tA = EV.windows(dA["acc"], dA["fs"], bandA)
    truthA = np.interp(tA, dA["pin_t"], dA["pin_mm"])
    A = {"W": WA, "fs": fsA, "truth_mm": truthA, "band": bandA,
         "to_mm": lambda f: D.invert(A_beam, "support", 1e5, f)}
    # beam B: test trials judged; training trials only used to align the two coordinate frames (same rule for all)
    folder = os.environ["PHYSICA_DROPBEAR8"]
    files = sorted(glob.glob(os.path.join(folder, "Random Index Set Random Dwell", "set*", "trial data", "test*.txt")))
    train = [f for f in files if "/set0/" in f or "/set1/" in f][:12]
    test = [f for f in files if f not in train][:16]

    def stack(fs_list):
        Ws, Ts = [], []
        for f in fs_list:
            d = dropbear.load_d8(f)
            W, fsB, t = EV.windows(d["channels"]["Low G Accel"], d["fs"], bandB)
            Ws.append(W)
            Ts.append(np.interp(t, np.arange(len(d["pin_v"])) / d["fs"], d["pin_v"]) * dropbear.MM_PER_VOLT_D8)
        return np.vstack(Ws), fsB, np.concatenate(Ts)

    WBtr, fsB, YBtr = stack(train)
    WBte, _, YBte = stack(test)

    def b_to_mm_factory(code=None):
        def to_mm(f):
            return D.invert(B_beam, "support", 1e5, f)
        return to_mm

    def b_offset(code):
        j = EV.sandbox.run(code, "tone", {"W": WBtr, "fs": np.array(fsB)}, timeout=20)["out"]
        w = D.invert(B_beam, "support", 1e5, np.asarray(j, float))
        return float(np.nanmedian(YBtr - w))

    res = {"proposer": "LIVE " + mc.model_id("wonder") if not mc.is_mock() else "offline stand-in (textbook estimators, NOT Meta)",
           "data": "DROPBEAR A (search: first half only) and B (never seen)", "meta_status": mc.status()}
    # Physica's current sense on the same windows, same judge
    T, f1 = track_tone(dA["acc"], dA["fs"], bandA, lag_s=None)
    wA = D.invert(A_beam, "support", 1e5, f1)
    yA = np.interp(T, dA["pin_t"], dA["pin_mm"])
    half = np.arange(len(T)) >= len(T) // 2
    eA = np.abs(wA - yA)[half]
    eB, cB = [], None
    trW, trY = [], []
    for f in train:
        d = dropbear.load_d8(f)
        Tb, fb = track_tone(d["channels"]["Low G Accel"], d["fs"], bandB, lag_s=None)
        trW.append(D.invert(B_beam, "support", 1e5, fb))
        trY.append(np.interp(Tb, np.arange(len(d["pin_v"])) / d["fs"], d["pin_v"]) * dropbear.MM_PER_VOLT_D8)
    cB = float(np.nanmedian(np.concatenate(trY) - np.concatenate(trW)))
    for f in test:
        d = dropbear.load_d8(f)
        Tb, fb = track_tone(d["channels"]["Low G Accel"], d["fs"], bandB, lag_s=None)
        y = np.interp(Tb, np.arange(len(d["pin_v"])) / d["fs"], d["pin_v"]) * dropbear.MM_PER_VOLT_D8
        eB.append(np.abs(D.invert(B_beam, "support", 1e5, fb) + cB - y))
    eB = np.concatenate(eB)
    res["physica_current_sense"] = {"prove_A_mm": float(np.nanmedian(eA)), "travel_B_mm": float(np.nanmedian(eB))}
    # the search
    B = {"W": WBte, "fs": fsB, "truth_mm": YBte, "to_mm": None}
    out = EV.run(A, {**B, "to_mm": b_to_mm_factory()}, generations=generations, n=n, swarm=swarm)
    out["swarm"] = swarm
    if "champion" in out:
        c = out["champion"]
        off = b_offset(c["code"])
        j = EV.judge(c["code"], WBte, fsB, lambda f: D.invert(B_beam, "support", 1e5, f) + off, YBte)
        c["travel_B_mm"] = j.get("median_mm")
        cur = res["physica_current_sense"]
        c["replaces_physica_sense"] = bool(c["prove_A_mm"] is not None and c["travel_B_mm"] is not None and
                                           c["prove_A_mm"] < cur["prove_A_mm"] and c["travel_B_mm"] < cur["travel_B_mm"])
        out["verdict"] = ("The proposal beat Physica's own sense on BOTH unseen tests: adopt it." if c["replaces_physica_sense"]
                          else "The best proposal did not beat Physica's own sense on both unseen tests: rejected.")
    res["search"] = out
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "E19_evolve_sense.json").write_text(json.dumps(res, indent=1, default=float))
    print("proposer:", res["proposer"])
    print("Physica's current sense: prove A %.2f mm | travel B %.2f mm" % (res["physica_current_sense"]["prove_A_mm"], res["physica_current_sense"]["travel_B_mm"]))
    print("search:", out["proposals"], "proposals,", out["valid"], "ran;", [g["best_select_mm"] for g in out["generations"]])
    if "champion" in out:
        c = out["champion"]
        print("champion: select %.2f | prove A %.2f | travel B %s" % (c["select_mm"], c["prove_A_mm"], c["travel_B_mm"]))
        print(out["verdict"])


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--generations", type=int, default=4)
    ap.add_argument("--n", type=int, default=8, help="programs per proposer per generation")
    ap.add_argument("--swarm", type=int, default=1, help="parallel proposers per generation (live: each is a Meta call)")
    a = ap.parse_args()
    main(a.generations, a.n, a.swarm)
