"""E18 - When none of Physica's causes fits, ask Muse Spark for new ones, and believe only what survives
(LABELLED SIMULATION; scientist = live Muse Spark with MOCK=0 and MODEL_API_KEY, else a labelled offline stand-in).

Three bodies, tones felt over time (two tones, 0.4% noise, truth simulated on a finer model):
  1. loosening clamp  - a bolt backing out: not in Physica's built-in menu (mass, support, crack, uniform)
  2. sliding support  - in the menu: Physica should NOT need the scientist
  3. two things at once (a mass slides while the clamp loosens) - nothing proposed should survive
Each proposal is fitted on the first half and judged only on the second half, against every built-in rival.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica.cause.fe import Beam  # noqa: E402
from physica.llm import meta_client as mc  # noqa: E402
from physica.meta import scientist as S  # noqa: E402

OUT = ROOT / "eval" / "results"


def main():
    model = Beam(0.25, 0.025, 0.001, "steel", n_el=40, name="steel ruler, 250 mm overhang")
    truth = Beam(0.25, 0.025, 0.001, "steel", n_el=60)
    rng = np.random.default_rng(18)
    n = 160
    cases = {
        "loosening clamp": [truth.freqs(2, clamp_rot=k) for k in np.geomspace(2000, 0.6, n)],
        "sliding support": [truth.freqs(2, springs=[(x, 1e5)]) for x in np.linspace(0.2, 0.7, n)],
        "mass slides while the clamp loosens": [truth.freqs(2, clamp_rot=k, masses=[(x, 0.3)]) for k, x in
                                                zip(np.geomspace(500, 2, n), np.linspace(0.9, 0.3, n))],
    }
    res = {"LABEL": "SIMULATION; scientist mode: " + ("LIVE Muse Spark" if not mc.is_mock() else
                                                      "offline author-written stand-in (NOT Meta)"),
           "model_status": mc.status(), "cases": {}}
    for name, F in cases.items():
        F = np.array(F) * np.exp(rng.normal(0, 0.004, (n, 2)))
        r = S.investigate(model, F[:, 0], F[:, 1])
        for t in r.get("proposals_tested", []):
            t["strength_path"] = t["strength_path"][:12]
        res["cases"][name] = r
        print(f"{name}: built-in -> {r['built_in'].get('cause')} ({r['built_in'].get('explained_pct', 0):.0f}%);"
              f" asked scientist: {r['asked_scientist']}; {r.get('verdict', '')}")
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "E18_new_cause.json").write_text(json.dumps(res, indent=1, default=float))


if __name__ == "__main__":
    main()
