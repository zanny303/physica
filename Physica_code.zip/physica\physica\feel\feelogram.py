"""The feelogram: feelings over time, the touch version of a spectrogram."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np

from physica.feel.axes import AXES

# validated categorical slots (dataviz reference palette, light mode)
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
SURF, TXT, TXT2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"


@dataclass
class Feelogram:
    t: list[float]  # window centres (s)
    unit_names: list[str]
    z: list[list[float]]  # (n_windows, units): felt residual vs healthy self-model
    threshold: float
    axes: dict[str, list] = field(default_factory=dict)  # axis -> per-window values (None = not available)
    modes: list[list[dict]] = field(default_factory=list)
    verdict: dict = field(default_factory=dict)
    meta: dict = field(default_factory=dict)

    def felt(self) -> np.ndarray:
        return np.asarray(self.z).max(axis=1) > self.threshold

    def to_json(self) -> str:
        return json.dumps(asdict(self), default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o))

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json())

    def plot(self, path: str | Path | None = None, title: str | None = None):
        """The feelogram: rows = units, colour = how strongly each feels something it didn't cause."""
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        from matplotlib.colors import LinearSegmentedColormap

        z = np.asarray(self.z, float)
        t = np.asarray(self.t, float)
        dt = (t[1] - t[0]) if len(t) > 1 else 1.0
        outside = np.asarray(self.meta.get("outside_proven_range") or [False] * len(t), bool)
        plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": GRID,
                             "axes.labelcolor": TXT2, "xtick.color": TXT2, "ytick.color": TXT2,
                             "axes.facecolor": SURF, "figure.facecolor": SURF})
        fig, (a0, a1) = plt.subplots(2, 1, figsize=(10, 4.8), sharex=True, gridspec_kw={"height_ratios": [1.6, 1]})
        cmap = LinearSegmentedColormap.from_list("feel", ["#f4f7fb", "#bcd3f1", "#5b9be6", "#2a78d6", "#123f78"])
        vmax = max(10.0, self.threshold * 2.5)
        im = a0.imshow(np.clip(z.T, 0, vmax), aspect="auto", cmap=cmap, vmin=0, vmax=vmax, interpolation="nearest",
                       extent=[t[0] - dt / 2, t[-1] + dt / 2, len(self.unit_names) - 0.5, -0.5])
        for i in np.where(outside)[0]:
            a0.add_patch(plt.Rectangle((t[i] - dt / 2, -0.5), dt, len(self.unit_names), facecolor="#d9d8d3",
                                       edgecolor="none", alpha=0.9))
        a0.set_yticks(range(len(self.unit_names)))
        a0.set_yticklabels([f"arm {u}" for u in self.unit_names])
        cb = fig.colorbar(im, ax=a0, fraction=0.025, pad=0.01)
        cb.set_label("felt (z)", color=TXT2)
        cb.ax.axhline(self.threshold, color=TXT, lw=1)
        a0.set_title(title or "Feelogram", loc="left", color=TXT, fontsize=12)
        if outside.any():
            a0.text(1.0, 1.02, "grey = outside proven range (e.g. take-off)", transform=a0.transAxes, ha="right",
                    va="bottom", fontsize=8, color=TXT2)
        m = np.clip(z.max(axis=1), -2, None)
        a1.axhline(self.threshold, color=TXT2, lw=1, ls=(0, (3, 3)))
        a1.plot(t, m, color=SERIES[0], lw=2)
        felt = self.felt() & ~outside
        a1.scatter(t[felt], m[felt], s=22, color=SERIES[0], zorder=4)
        a1.text(t[-1] + dt / 2, self.threshold, " threshold", va="center", ha="left", fontsize=8, color=TXT2)
        a1.set_ylabel("strongest\nfeeling (z)")
        a1.set_xlabel("Time (s)")
        a1.grid(True, color=GRID, lw=0.6)
        for a in (a0, a1):
            for s_ in ("top", "right"):
                a.spines[s_].set_visible(False)
        fig.tight_layout()
        if path:
            fig.savefig(path, dpi=150, bbox_inches="tight")
            plt.close(fig)
        return fig
