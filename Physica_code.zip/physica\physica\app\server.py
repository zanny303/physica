"""Feel Check app: a zero-dependency local web app (Python standard library only).

  python -m physica.app            # live if PHYSICA_PADRE_DIR is set, otherwise replay mode
  python -m physica.app --replay   # force replay mode (judges: no data, no API key needed)

Replay mode serves results precomputed by `python -m physica.app.build_replay` from replay/.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from physica import config

STATIC = Path(__file__).parent / "static"
REPLAY = config.REPLAY_DIR

DEMO_SOURCES = [
    {"source": "padre:0000", "title": "Used drone #1", "subtitle": "Parrot Bebop 2, 172 s flight"},
    {"source": "padre:0100", "title": "Used drone #2", "subtitle": "Parrot Bebop 2, 172 s flight"},
    {"source": "padre:0001", "title": "Used drone #3", "subtitle": "Parrot Bebop 2, 172 s flight"},
    {"source": "padre:0010", "title": "Used drone #4", "subtitle": "Parrot Bebop 2, 172 s flight"},
    {"source": "padre:3000", "title": "Used drone #5", "subtitle": "Parrot Bebop 2, 172 s flight"},
]


def _code(source: str) -> str:
    if not isinstance(source,str) or not re.fullmatch(r"padre:[0-9]{4}", source):
        raise ValueError("Unsupported or malformed PADRE replay source")
    return source.split(":", 1)[1]


class Live:
    name = "live"

    def __init__(self):
        from physica.agents import tools as T
        from physica.agents import wonder_agent as W

        self.T, self.W = T, W

    def feel(self, source):
        r = self.T.feel(source)
        r["certificate"] = certificate(r)
        return r

    def ask(self, source):
        return self.W.ask("Is this drone safe to fly?", source)

    def translate(self, source, target):
        t = self.T.translate(source, target)
        if t.get("file") and Path(t["file"]).exists():
            t["file_text"] = Path(t["file"]).read_text()
            t["file"] = Path(t["file"]).name
        if t.get("judgement") and t["judgement"]["verdict"] in ("kept", "rolled back") and t.get("promise") \
                and not t.get("synthetic"):
            t["record"] = action_record(source, t)
        return t

    def discover(self):
        p = config.RESULTS_DIR / "discover_padre.json"
        if not p.exists():
            raise FileNotFoundError("Run: python eval/discover_padre.py")
        return json.loads(p.read_text())

    def evidence(self):
        from physica.app import evidence

        return evidence.build()

    def library(self):
        from physica.library import cards

        return {"counts": cards.library_counts(),
                "cards": [{k: c[k] for k in ("id", "type", "claim", "lineage", "track_record", "metrics")}
                          for c in cards.all_cards()]}

    def png(self, code):
        return config.REPO_ROOT / ".cache" / "feelograms" / f"{code}.png"


class Replay:
    name = "replay"

    @staticmethod
    def unavailable(source: str, *, artifact: str) -> dict:
        """Honest missing-evidence response, not fabricated drone measurements.

        The archive deliberately excludes third-party PADRE raw data and prebuilt
        replay artifacts. Render an evidence refusal rather than HTTP 422 or a
        fake healthy/damaged verdict. This is NOT a successful Feel Check.
        """
        return {
            "source": source,
            "status": "EVIDENCE_UNAVAILABLE",
            "verdict": {
                "status": "unavailable", "text": "Cannot assess this drone: replay evidence is not bundled.",
                "disclaimer": "No new measurement or fault verdict was computed. Download authorized PADRE data and build a genuine replay.",
                "felt_windows": None, "windows": None,
            },
            "evidence_origin": "NOT_EVALUATED", "artifact": artifact,
            "next_action": "See DATA.md; run python -m physica.app.build_replay with licensed raw PADRE data.",
            "no_safety_clearance": True,
        }

    def available(self, source: str) -> bool:
        """Require a parsable, correctly source-tagged archived result."""
        return self.feel(source).get('status') != 'EVIDENCE_UNAVAILABLE'

    def _j(self, *parts):
        p = REPLAY.joinpath(*parts).resolve()
        if not p.is_relative_to(REPLAY.resolve()):
            raise ValueError("Replay path outside evidence directory")
        if not p.exists():
            raise FileNotFoundError(f"replay file missing: {p.relative_to(config.REPO_ROOT)}. Run: python -m physica.app.build_replay")
        return json.loads(p.read_text())

    def feel(self, source):
        file = REPLAY / "feel" / f"{_code(source)}.json"
        if not file.is_file():
            return self.unavailable(source, artifact=f"replay/feel/{_code(source)}.json")
        try:
            result = json.loads(file.read_text(encoding="utf-8"))
            if not isinstance(result, dict) or not isinstance(result.get("verdict"), dict):
                raise ValueError("missing verdict")
            if result.get("source") != source:
                raise ValueError("source mismatch")
        except (OSError, ValueError) as exc:
            # Corrupt or forged replay files must never become trusted evidence.
            return self.unavailable(source, artifact="invalid replay evidence")
        return result

    def ask(self, source):
        return self._j("ask", f"{_code(source)}.json")

    def translate(self, source, target):
        if target not in ('ardupilot','marlin','plc','klipper','fan'):
            raise ValueError('Unsupported replay machine target')
        return self._j("translate", f"{_code(source)}_{target}.json" if target == "ardupilot" else f"{target}.json")

    def library(self):
        return self._j("library.json")

    def discover(self):
        return self._j("discover.json")

    def evidence(self):
        return self._j("evidence.json")

    def png(self, code):
        return REPLAY / "feel" / f"{code}.png"


def certificate(feel_result: dict) -> dict:
    """A signed Feel Certificate (experiment-record card) for this check."""
    from physica.library import cards

    v = feel_result["verdict"]
    c = cards.new_card("experiment", f"Feel Check of {feel_result['source']}: {v['text']}",
                       {"type": "quadcopter", "model": "Parrot Bebop 2", "id": "padre-bebop2"},
                       units="z vs healthy", parent=feel_result["card_used"], changed=["feel check"],
                       context={"source": feel_result["source"]},
                       metrics={"felt_fraction": v["felt_fraction"], "felt_windows": v["felt_windows"],
                                "windows": v["windows"], "threshold_z": feel_result["threshold_z"]},
                       tags=["feel certificate"])
    d = cards.save(c)
    return {"id": c["id"], "signature": (d / "signature.sig").read_text().strip(), "card": c,
            "note": "Signed by this Physica install. A signature proves origin and integrity, not truth."}


def action_record(source: str, t: dict) -> dict:
    """Remember what the action did: a signed experiment card that links the promise to what was felt after."""
    from physica.library import cards

    j = t["judgement"]
    c = cards.new_card("experiment", f"Action on {source}: {t['promise']['action']} -> {j['verdict']}",
                       {"type": "quadcopter", "model": "Parrot Bebop 2", "id": "padre-bebop2"} if t["target"] == "ardupilot"
                       else {"type": t["target"], "id": t["target"]},
                       units="dB" if t["target"] == "ardupilot" else "g*mm", parent=t.get("card"),
                       changed=["action: " + t["target"]], context={"source": source, "how_tested": t.get("how_tested")},
                       metrics={"promise": t["promise"], "judgement": j}, tags=["action record"])
    d = cards.save(c)
    return {"id": c["id"], "signature": (d / "signature.sig").read_text().strip()}


def make_handler(backend):
    class H(BaseHTTPRequestHandler):
        def _send(self, code, body, ctype="application/json"):
            data = body if isinstance(body, bytes) else json.dumps(body, default=str).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *a):  # quiet
            pass

        def do_GET(self):  # noqa: N802
            u = urllib.parse.urlparse(self.path)
            q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
            try:
                if u.path in ("/", "/index.html"):
                    return self._send(200, (STATIC / "index.html").read_bytes(), "text/html; charset=utf-8")
                if u.path == "/api/mode":
                    return self._send(200, {"mode": backend.name})
                if u.path == "/api/sources":
                    if isinstance(backend, Replay):
                        return self._send(200, [{**item, "replay_available": backend.available(item["source"])}
                                                for item in DEMO_SOURCES])
                    return self._send(200, DEMO_SOURCES)
                if u.path == "/api/feel":
                    return self._send(200, backend.feel(q["source"]))
                if u.path == "/api/ask":
                    return self._send(200, backend.ask(q["source"]))
                if u.path == "/api/translate":
                    return self._send(200, backend.translate(q["source"], q["target"]))
                if u.path == "/api/truth":
                    from physica.data.padre import fault_map
                    return self._send(200, {"source": q["source"], "faults": fault_map(_code(q["source"]))})
                if u.path == "/api/discover":
                    return self._send(200, backend.discover())
                if u.path == "/api/evidence":
                    return self._send(200, backend.evidence())
                if u.path == "/api/library":
                    return self._send(200, backend.library())
                if u.path.startswith("/feelogram/"):
                    p = backend.png(Path(u.path).stem)
                    return self._send(200, p.read_bytes(), "image/png")
                if u.path == "/api/file":
                    p = (config.REPO_ROOT / q["path"]).resolve()
                    if config.REPO_ROOT not in p.parents:
                        return self._send(403, {"error": "outside repo"})
                    return self._send(200, p.read_bytes(), "text/plain; charset=utf-8")
                return self._send(404, {"error": "not found"})
            except Exception as e:  # show the error in the UI instead of hanging
                return self._send(500, {"error": f"{type(e).__name__}: {e}"})

    return H


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--replay", action="store_true", help="serve precomputed results (no data or API key needed)")
    ap.add_argument("--port", type=int, default=8000)
    a = ap.parse_args(argv)
    live_ok = bool(os.environ.get("PHYSICA_PADRE_DIR")) and not a.replay
    backend = Live() if live_ok else Replay()
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), make_handler(backend))
    print(f"Feel Check ({backend.name} mode) at http://127.0.0.1:{a.port}")
    srv.serve_forever()


if __name__ == "__main__":
    main()
