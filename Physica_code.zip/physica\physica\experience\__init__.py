"""PACER physical experience layer (v0.2).

Works with Physica's original Feel Transform, Body Bank, twins, and Meta agents.
A physical episode is evidence plus uncertainty, not a guarantee of causality.
"""
from .schema import PhysicalEpisode, Quantity, ModalWord

__all__ = ["PhysicalEpisode", "Quantity", "ModalWord"]
