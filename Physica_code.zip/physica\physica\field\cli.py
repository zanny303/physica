"""Offline field evidence checks: python -m physica.field.cli ..."""
import argparse
import json
from pathlib import Path
from .readiness import validate_field_trial, meta_contract_preflight, score_sealed_real_trial, live_meta_smoke

def main(argv=None):
    p = argparse.ArgumentParser(prog='python -m physica.field.cli')
    sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('preflight',help='Strict real sensor CSV and evidence gate, no model execution')
    a.add_argument('metadata'); a.add_argument('sensor_csv'); a.add_argument('--video')
    a.add_argument('--out',required=True)
    s=sub.add_parser('score-sealed',help='Real CSV against signed future prediction after independent preflight')
    s.add_argument('metadata');s.add_argument('sensor_csv');s.add_argument('sealed_forecast')
    s.add_argument('--video');s.add_argument('--out',required=True)
    m=sub.add_parser('meta-doctor',help='Offline Meta API adapter/SDK readiness; no API calls')
    m.add_argument('--out',required=True)
    l=sub.add_parser('meta-live-smoke',help='Billable authenticated Meta structured-response smoke (NO scientific proof)')
    l.add_argument('--role',choices=['spark','wonder','both'],default='both')
    l.add_argument('--allow-billed-meta',action='store_true')
    l.add_argument('--out',required=True)
    args=p.parse_args(argv)
    if args.command=='preflight':
        report=validate_field_trial(args.metadata,args.sensor_csv,video_path=args.video)
    elif args.command=='score-sealed':
        report=score_sealed_real_trial(args.metadata,args.sensor_csv,args.sealed_forecast,video_path=args.video)
    elif args.command=='meta-doctor':
        report=meta_contract_preflight()
    else:
        report=live_meta_smoke(allow_billing=args.allow_billed_meta,role=args.role)
    Path(args.out).write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'status':report.get('status','OFFLINE_META_READINESS'),
                      'errors':report.get('errors',[]),'out':args.out},indent=2))
    return report

if __name__=='__main__': main()
