"""Strict physical sensors, time provenance, dimensional units and synchronization.

We deliberately do NOT infer force from pixels or displacement from microphone
spectra. A conversion requires an independent calibrated observation operator.
"""
from dataclasses import dataclass
from typing import Literal
import math
import numpy as np

Observable = Literal['displacement','velocity','acceleration','force',
                     'gas_concentration','ph','conductivity']
Modality = Literal['vision','hearing','touch','proprioception','smell','taste']
_UNITS={'displacement':'m','velocity':'m/s','acceleration':'m/s^2',
        'force':'N','gas_concentration':'mol/m^3','ph':'pH','conductivity':'S/m'}
_ALLOWED={'vision':{'displacement','velocity'},
          'hearing':{'velocity','acceleration'},
          'touch':{'displacement','velocity','acceleration','force'},
          'proprioception':{'displacement','velocity','acceleration','force'},
          'smell':{'gas_concentration'},'taste':{'ph','conductivity'}}


def finite_array(values, label, minimum=2):
    x=np.asarray(values,dtype=float)
    if x.ndim!=1 or x.size<minimum or not np.all(np.isfinite(x)):
        raise ValueError(f'{label} requires >= {minimum} finite scalar measurements')
    return x


@dataclass(frozen=True)
class Channel:
    sensor_id: str
    modality: Modality
    observable: Observable
    time_s: tuple[float,...]
    values: tuple[float,...]
    unit: str
    sigma: float
    calibration_id: str
    body_id: str
    # A sensor's physical output = gain * quantity (e.g., microphone Pa per m/s).
    # values are in observable's *canonical SI units* after an externally
    # established calibration; gain documents raw-to-physical conversion.
    raw_unit: str
    conversion_gain: float
    origin: str = 'real_sensor'
    source_sha256: str = ''

    def __post_init__(self):
        if not all((self.sensor_id,self.calibration_id,self.body_id,self.raw_unit)):
            raise ValueError('sensor identity, body and independent calibration required')
        if self.modality not in _ALLOWED or self.observable not in _ALLOWED[self.modality]:
            raise ValueError('unsupported modality/observable pair; do not invent a translation')
        if self.unit!=_UNITS[self.observable]:
            raise ValueError('canonical SI unit mismatch: expected '+_UNITS[self.observable])
        if any((not math.isfinite(v) or v<=0) for v in (self.sigma,self.conversion_gain)):
            raise ValueError('positive finite noise and conversion calibration required')
        t=finite_array(self.time_s,'time');v=finite_array(self.values,'measurement')
        if len(t)!=len(v) or t[0]<0 or np.any(np.diff(t)<=0):
            raise ValueError('measurements and timestamps must match, increase and be nonnegative')
        if self.origin not in ('simulation','real_sensor','signed_replay'):
            raise ValueError('explicit provenance needed')
        if self.origin in ('real_sensor','signed_replay'):
            if len(self.source_sha256)!=64 or any(c not in '0123456789abcdef' for c in self.source_sha256):
                raise ValueError('real/signed evidence requires raw recording SHA-256')


@dataclass(frozen=True)
class MechanicalContext:
    body_id: str
    boundary_class: str
    mass_kg: float
    fundamental_hz: float
    damping_ratio: float
    stiffness_n_m: float
    applied_force_n: float
    action_family: str
    calibration_id: str
    provenance: str = 'simulation'

    def __post_init__(self):
        if not all((self.body_id,self.boundary_class,self.action_family,self.calibration_id)):
            raise ValueError('missing physical context')
        for v in (self.mass_kg,self.fundamental_hz,self.stiffness_n_m,self.applied_force_n):
            if not math.isfinite(v) or v<=0:raise ValueError('invalid positive physical calibration')
        if not math.isfinite(self.damping_ratio) or not 0<=self.damping_ratio<1:
            raise ValueError('damping must be finite in [0,1)')
        # Mass and fundamental mode may be effective approximations, with a tolerance
        # for measurement uncertainty; a wildly inconsistent calibration is invalid.
        f_est=math.sqrt(self.stiffness_n_m/self.mass_kg)/(2*math.pi)
        if abs(f_est/self.fundamental_hz-1)>.08:
            raise ValueError('mass/stiffness/frequency not mutually consistent (8% tolerance)')


def validate_channels(channels,ctx=None):
    channels=list(channels)
    if not channels:raise ValueError('no sensors; cannot infer state')
    if len({c.sensor_id for c in channels})!=len(channels):
        raise ValueError('duplicate sensor identifiers')
    if len({c.body_id for c in channels})!=1:
        raise ValueError('different bodies cannot be fused as one')
    if ctx is not None and any(c.body_id!=ctx.body_id for c in channels):
        raise ValueError('channel/body context mismatch')
    if len({c.origin for c in channels})!=1:
        raise ValueError('cannot silently mix synthetic and real observations')
    return channels


def align(channels, *, grid_s=None, max_gap_factor=3.0):
    """Interpolate only within common time support; reject sparse/bad clocks.

    This aligns samples on an externally synchronized timeline. Unknown offsets
    or camera/audio clock drift must be corrected BEFORE calling this function.
    """
    cs=validate_channels(channels)
    low=max(float(c.time_s[0]) for c in cs)
    high=min(float(c.time_s[-1]) for c in cs)
    if high<=low:raise ValueError('no overlapping synchronized sensor timestamps')
    if grid_s is None:
        # Choose conservative coarsest cadence; sub-frame interpolation is not evidence.
        step=max(float(np.median(np.diff(c.time_s))) for c in cs)
        grid=np.arange(low,high+step*.2,step)
        grid=grid[grid<=high+1e-10]
    else:
        grid=finite_array(grid_s,'grid')
        if np.any(np.diff(grid)<=0) or grid[0]<low-1e-9 or grid[-1]>high+1e-9:
            raise ValueError('no extrapolation outside common timestamp support')
    if len(grid)<8:raise ValueError('>=8 synchronized samples required')
    result={}
    for c in cs:
        times=np.asarray(c.time_s)
        if np.max(np.diff(times))>max_gap_factor*np.median(np.diff(times)):
            raise ValueError('sensor dropout; refuse to interpolate long gap: '+c.sensor_id)
        result[c.sensor_id]=np.interp(grid,times,c.values)
    return grid,result


def chemical_observations(channels):
    """Typed chemistry observations; NOT automatically vibration-derived.

    Calibrated values are preserved. No claim that pH/conductivity alone identifies
    a compound, or that a single VOC sensor identifies a chemical species.
    """
    cs=validate_channels(channels)
    if any(c.modality not in ('smell','taste') for c in cs):
        raise ValueError('chemical report accepts chemical channels only')
    return {'status':'measured_not_chemically_identified',
            'measurements':[{'sensor_id':c.sensor_id,'modality':c.modality,
                             'observable':c.observable,'unit':c.unit,
                             'median':float(np.median(c.values)),
                             'uncertainty_sigma':c.sigma,
                             'calibration_id':c.calibration_id,'raw_sha256':c.source_sha256}
                            for c in cs],
            'limitations':['Sensor selectivity/cross-sensitivity and drift not independently tested',
                           'No compound identity inferred from pH, conductivity or VOC levels']}
