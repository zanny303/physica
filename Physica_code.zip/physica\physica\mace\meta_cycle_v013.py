"""Bounded authenticated Muse hypothesis loop using independent validation evidence.

No test outcomes enter prompts, candidate fitting, or acceptance. Only restricted
term structures can be proposed; evidence, not Muse, determines coefficients.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from .agentic_v013 import KNOWN, search, _write
from .mechanisms import fit,score
from .open_world_meta import live_nominate
from .unknown_physics import residual_diagnostics


def run(train,val,*,allow_billed=False,model='muse-wonder-1.0',rounds=2):
    if not allow_billed: raise PermissionError('explicit billed Meta consent required')
    if not 1<=rounds<=3: raise ValueError('only 1..3 bounded rounds permitted')
    baseline=search(train,val)
    before=baseline['validation_selected_rmse']
    accepted_candidates=[];attempts=[];evaluated=set()
    for i in range(rounds):
        current=search(train,val,extra_candidates=accepted_candidates)
        context={'task':'Propose one falsifiable physical mechanism that explains current residuals',
                 'physical_channels_available':sorted(set.intersection(*(set(r) for r in train+val)) &
                          {'x','v','u','temperature_delta','current','magnetic','ultrasound'}),
                 'current_validation_rmse':current['validation_selected_rmse'],
                 'source_episode_count':len({r['episode_id'] for r in train}),
                 'independent_validation_episode_count':len({r['episode_id'] for r in val}),
                 'validation_residual_diagnostics':residual_diagnostics(val,current['model']),
                 'already_evaluated_hypothesis_ids':sorted(evaluated),
                 'allowed_experiments':'safe reversible human-supervised measurements only',
                 'not_provided':'test observations, absolute hidden physics truth or actuator permissions'}
        reply=live_nominate(context,model=model,allow_billed=True)
        record={'round':i+1,'meta_status':reply['status'],
                'model_response_id':reply.get('model_response_id'),
                'request_sha256':reply.get('request_sha256'),
                'candidate':reply.get('candidate'),
                'meta_is_not_verification':True}
        candidate=reply.get('candidate')
        if candidate is None:
            attempts.append(record)
            if reply['status'] in ('META_REQUESTS_MISSING_EVIDENCE','META_ABSTAINED'):break
            continue
        if candidate['id'] in evaluated:
            record['status']='DUPLICATE_NOMINATION_REFUSED';attempts.append(record);continue
        evaluated.add(candidate['id'])
        experimental=search(train,val,extra_candidates=accepted_candidates+[candidate])
        record['new_validation_rmse']=experimental['validation_selected_rmse']
        record['hypothesis_selected']=bool(experimental['selected_term'] and experimental['selected_term']['id']==candidate['id'])
        record['status']='VALIDATION_SUPPORT_NOT_CAUSAL_PROOF' if record['hypothesis_selected'] else 'UNSUPPORTED_OR_OUTCOMPETED'
        attempts.append(record)
        if record['hypothesis_selected']:
            accepted_candidates.append(candidate)
            # Candidate selected on training/validation only; further prospective
            # experiments are needed for a causal-discovery claim.
    final=search(train,val,extra_candidates=accepted_candidates)
    return {'schema':'physica.mace.meta_cycle.v013','origin':'AUTHENTICATED_META_REQUIRES_EXTERNAL_ATTESTATION',
            'authenticated_calls_attempted':len(attempts),'model':model,
            'validation_no_meta_rmse':before,'validation_meta_nominated_rmse':final['validation_selected_rmse'],
            'selected_mechanism':final['selected_term'],'calls':attempts,
            'no_final_test_accessed':True,'does_not_execute_equations_or_actuate_hardware':True,
            'limitations':'Meta proposal selection is retrospective validation; an independent prospective trial is still required'}


def main(argv=None):
    import argparse
    from .simulation import roll
    p=argparse.ArgumentParser(description='Auth-only bounded Meta scientific nomination loop')
    p.add_argument('--out',required=True);p.add_argument('--rounds',type=int,default=2)
    p.add_argument('--model',choices=('muse-spark-1.3','muse-wonder-1.0'),default='muse-wonder-1.0')
    p.add_argument('--allow-billed-meta',action='store_true')
    args=p.parse_args(argv)
    # Don't generate/supply future test records in this command at all.
    a={'id':'A_audio_touch','thermal':.82,'extra':.4}
    train=roll(a,2026,'A_train',unmodelled=True)
    val=roll(a,2027,'A_valid_one',unmodelled=True)+roll(a,2028,'A_valid_two',unmodelled=True)
    result=run(train,val,allow_billed=args.allow_billed_meta,model=args.model,rounds=args.rounds)
    out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
    _write(out.parent,out.name,result);print(json.dumps({'out':str(out),'calls':result['authenticated_calls_attempted'],
         'selected':result['selected_mechanism']},allow_nan=False))
if __name__=='__main__':main()
