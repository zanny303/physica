"""The Touch Transform: split any motion signal into what the object IS and what TOUCHED it.

The FFT splits a sound into pitches. The Touch Transform splits motion (video pixels, accelerometers, microphones)
into two things:
  body    - the object's own modes: how it rings (frequency), how fast it stops (damping), what shape it moves in.
  touches - the pushes from the world that drove those modes: when, where, and how hard.

How (the 'you can't tickle yourself' trick, one mode at a time):
  1. Learn the body from the signal itself: delay-embed the channels, keep the strongest subspace, fit the
     one-step linear dynamics, and diagonalise them. Each mode k becomes one complex number mu_k per sample
     (its own ringing: z_k[t] = mu_k * z_k[t-1]).
  2. Analysis: put the signal into modal coordinates and predict each mode's own ringing one sample ahead. What
     the prediction misses, e_k[t] = z_k[t] - mu_k z_k[t-1], is by definition the push from the world.
  3. Synthesis (imagination): run it backwards. z_k[t] = mu_k z_k[t-1] + e_k[t]. Any imagined touch becomes the
     motion it would cause, everywhere, in O(modes x samples). The two directions are exact inverses within the
     modal subspace, like the FFT and its inverse.
  4. Where was it touched? For an impulse F at point x0, physics (reciprocity, uniform mass, unit-RMS real mode
     shapes) gives  2i * omega_dk * e_k = phi_k(x0) * F / m  for displacement signals. So the touch's modal
     fingerprint IS the mode-shape column at the touched point: matching it against every point gives a touch map.
  5. Did the world touch me, or did I change? A touch is a short burst of prediction error; a body change (mass
     lost, a crack, a loose bolt) makes the self-prediction stay wrong while the object keeps ringing.

Classic pieces this builds on: dynamic mode decomposition / eigensystem realisation (Juang & Pappa 1985; Schmid
2010), innovations in state estimation (Kalman), modal force identification in structural dynamics, Davis et al.'s
image-space modal bases (2015). What is put together here: one invertible analysis/synthesis pair that outputs
touches (time, place, strength) and the body together, from a single uncalibrated recording.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def hankel(Y: np.ndarray, d: int) -> np.ndarray:
    """Rows t = d-1..T-1: [y[t], y[t-1], ..., y[t-d+1]] (current sample first)."""
    T = len(Y)
    return np.hstack([Y[d - 1 - j: T - j] for j in range(d)])


@dataclass
class Mode:
    freq_hz: float
    damping: float
    pole: complex          # discrete-time, per sample
    shape: np.ndarray      # real, unit RMS over channels
    energy: float
    index: int             # position in the full state


class TouchTransform:
    def __init__(self, fs: float, n_modes: int = 4, band: tuple[float, float] = (1.0, np.inf), delays: int | None = None,
                 order: int | None = None, space_rank: int = 24, measure: str = "displacement",
                 max_damping: float = 0.2, merge: float = 0.03, stabilize: bool = True):
        self.fs, self.n_modes, self.band = fs, n_modes, band
        self.delays, self.order, self.space_rank = delays, order, space_rank
        self.measure, self.max_damping, self.merge, self.stabilize = measure, max_damping, merge, stabilize

    # ---------------- learn the body ----------------
    def _reduce(self, Y):
        Y = np.asarray(Y, float)
        if Y.ndim == 1:
            Y = Y[:, None]
        return (Y - self.mean) @ self.W

    def fit(self, Y: np.ndarray) -> "TouchTransform":
        Y = np.asarray(Y, float)
        Y = Y[:, None] if Y.ndim == 1 else Y
        self.P = Y.shape[1]
        self.mean = Y.mean(0)
        Yc = Y - self.mean
        if self.P > self.space_rank:
            _, _, Vt = np.linalg.svd(Yc, full_matrices=False)
            self.W = Vt[: self.space_rank].T
        else:
            self.W = np.eye(self.P)
        Yr = Yc @ self.W
        r = Yr.shape[1]
        n = self.order or max(2 * self.n_modes + 4, 8)
        d = self.delays or max(int(np.ceil(n / r)) + 2, 4)
        d = max(min(d, len(Yr) // (3 * r)), int(np.ceil(n / r)) + 1)  # keep the fit overdetermined (rows >> columns)
        self.d, self.n = d, n
        H = hankel(Yr, d)
        _, sv, Vt = np.linalg.svd(H, full_matrices=False)
        # stabilisation (as in operational modal analysis): a physical mode reappears, with the same frequency
        # and damping, when the model is made bigger; poles that come and go with model size are fitting artifacts
        others = []
        for m_ in (n + 4, n + 8, n + 12):
            if m_ <= min(Vt.shape[0], H.shape[0] - 2):
                Sm = H @ Vt[:m_].T
                lm = np.linalg.eigvals(np.linalg.lstsq(Sm[:-1], Sm[1:], rcond=None)[0]).astype(complex)
                sm = np.log(lm) * self.fs
                others.append((np.abs(sm.imag) / (2 * np.pi), -sm.real / np.maximum(np.abs(sm), 1e-12)))
        self.Vn = Vt[:n].T
        S = H @ self.Vn
        A = np.linalg.lstsq(S[:-1], S[1:], rcond=None)[0]
        lam, Q = np.linalg.eig(A)
        self.lam, self.Q, self.Qi = lam, Q, np.linalg.inv(Q)
        # complex output shapes of every state mode
        self.Psi = self.Qi @ self.Vn[:r].T @ self.W.T          # (n, P)
        Z = S @ Q
        s = np.log(lam.astype(complex)) * self.fs
        freq = np.abs(s.imag) / (2 * np.pi)
        zeta = -s.real / np.maximum(np.abs(s), 1e-12)
        energy = (np.abs(Z) ** 2).mean(0) * (np.abs(self.Psi) ** 2).sum(1)
        ok = (s.imag > 0) & (freq >= self.band[0]) & (freq <= self.band[1]) & (zeta > 0) & (zeta < self.max_damping)
        if others and self.stabilize:
            need = 1
            for i in np.where(ok)[0]:
                hits = sum(bool(np.any((np.abs(fo - freq[i]) < 0.01 * freq[i]) &
                                       (np.abs(zo - zeta[i]) < max(zeta[i], 0.005)))) for fo, zo in others)
                ok[i] = hits >= need
        def realshape(i):
            psi = self.Psi[i]
            v = np.real(psi * np.exp(-0.5j * np.angle(np.sum(psi ** 2))))
            return v / (np.linalg.norm(v) + 1e-30)

        def echo(i, j):  # same shape at an integer multiple of a stronger mode's frequency = a sensing echo
            if self.P < 8:  # with few sensors every mode looks alike: shape can't tell an echo from a mode
                return False
            ratio = freq[i] / freq[j]
            k = round(ratio)
            return k >= 2 and abs(ratio - k) < 0.04 * k and abs(realshape(i) @ realshape(j)) > 0.7

        idx = []
        for i in np.argsort(-energy):  # strongest first; one pole per physical mode (merge near-duplicates)
            if ok[i] and all(abs(freq[i] - freq[j]) > self.merge * freq[j] and not echo(i, j) for j in idx):
                idx.append(i)
            if len(idx) == self.n_modes:
                break
        idx = sorted(idx, key=lambda i: freq[i])
        self.modes = []
        self.c = np.ones(n, complex)  # per-mode complex scale so that shapes become real, unit RMS
        for i in idx:
            psi = self.Psi[i]
            th = 0.5 * np.angle(np.sum(psi ** 2))
            phi = np.real(psi * np.exp(-1j * th))
            rms = np.sqrt(np.mean(phi ** 2)) + 1e-30
            if phi[np.argmax(np.abs(phi))] < 0:
                th += np.pi
                phi = -phi
            self.c[i] = np.exp(1j * th) * rms
            self.modes.append(Mode(float(freq[i]), float(zeta[i]), complex(lam[i]), phi / rms, float(energy[i]), int(i)))
        self.sel = np.array([m.index for m in self.modes], int)
        self.s = s
        self._Yr_fit, self._d_fit = Yr, d
        # observer: reads the push the moment it arrives (steady-state Kalman filter on the learned body)
        from scipy.linalg import solve_discrete_are
        self.F, self.C = A.T, self.Vn[:r]
        Wres = S[1:] - S[:-1] @ A
        Vres = Yr[d - 1:] - S @ self.Vn[:r].T
        Qw = np.cov(Wres.T) + 1e-12 * np.eye(n)
        Rv = np.atleast_2d(np.cov(Vres.T)) + 1e-9 * np.eye(r) * max(np.var(Yr), 1e-30)
        Pp = solve_discrete_are(self.F.T, self.C.T, Qw, Rv)
        self.K = Pp @ self.C.T @ np.linalg.inv(self.C @ Pp @ self.C.T + Rv)
        # how hard each mode was shaken at the start of the learned data (words must say this: frequencies of real
        # objects shift with amplitude, so two recordings are only comparable if they were shaken alike)
        self.amp = np.zeros(len(self.modes))
        if self.modes:
            N = min(len(Yr), d - 1 + max(int(0.5 * self.fs), 8))
            try:
                a = self._state_fit(Yr, np.arange(d - 1, N), d - 1)
                self.amp = 2 * np.abs(a)
            except np.linalg.LinAlgError:
                pass
        del self._Yr_fit
        return self

    # ---------------- analysis ----------------
    def modal(self, Y: np.ndarray):
        """Complex modal coordinates Z (all states) and pushes E, row t = sample t. E[t] = Z[t] - mu * Z[t-1]."""
        Yr = self._reduce(Y)
        F, C, K = self.F, self.C, self.K
        S = np.zeros((len(Yr), self.n))
        x = np.zeros(self.n)
        for t in range(len(Yr)):
            xp = F @ x
            x = xp + K @ (Yr[t] - C @ xp)
            S[t] = x
        Z = S @ self.Q
        E = np.vstack([Z[:1], Z[1:] - Z[:-1] * self.lam])
        return Z, E

    def touch_vectors(self, E: np.ndarray) -> np.ndarray:
        """Per selected mode, the push in physical form: v_k = phi_k(x0) * F / m (real for an impulse)."""
        e = E[:, self.sel] * self.c[self.sel]
        sk = self.s[self.sel]
        wd = sk.imag
        v = 2j * wd * e
        if self.measure == "velocity":
            v = v / sk
        elif self.measure == "acceleration":
            v = v / sk ** 2
        return v

    def analyze(self, Y: np.ndarray, threshold: float = 8.0, min_gap_s: float = 0.25, baseline: slice | None = None) -> dict:
        Z, E = self.modal(Y)
        V = self.touch_vectors(E)
        g = (np.abs(V) ** 2).sum(1)
        base = g[baseline] if baseline is not None else g
        floor = np.median(base) + 1e-30
        # a touch is a push much bigger than what the body was just doing: compare with the previous 0.5 s
        w = max(int(0.5 * self.fs), 4)
        c = np.concatenate([[0.0], np.cumsum(g)])
        prev = np.array([(c[i] - c[max(i - w, 0)]) / max(i - max(i - w, 0), 1) for i in range(len(g))])
        z = g / np.maximum(prev, floor)
        t = np.arange(len(g)) / self.fs
        events, last = [], -np.inf
        for i in np.where(z > threshold ** 2)[0]:  # onset = first crossing after a quiet gap
            if t[i] - last >= min_gap_s:
                w = slice(i, min(i + max(2, int(0.05 * self.fs)), len(z)))
                events.append({"i": int(i), "t": float(t[i]), "z": float(z[w].max())})
            last = t[i]
        return {"Z": Z, "E": E, "V": V, "touch_energy": z, "t": t, "events": events}

    def event_impulse(self, V: np.ndarray, i: int, before: int = 2, after: int | None = None) -> np.ndarray:
        """Total modal push of one touch: innovations around sample i, carried back to i by each mode's own ringing."""
        after = after if after is not None else max(2, int(0.01 * self.fs))
        lam = self.lam[self.sel]
        acc = np.zeros(len(self.sel), complex)
        for j in range(max(i - before, 0), min(i + after + 1, len(V))):
            acc += V[j] * lam ** (i - j)
        return acc

    def _state_fit(self, Yr: np.ndarray, idx: np.ndarray, ref: int) -> np.ndarray:
        """Complex amplitudes a_k (unit-RMS real shapes) of the body's own modes that best explain samples idx,
        referenced to sample `ref`: y(p, t) = sum_k 2 Re(a_k mu_k^(t - ref)) phi_k(p)."""
        lam = self.lam[self.sel]
        Pr = np.stack([m.shape for m in self.modes]) @ self.W        # (K, r) shapes in the reduced space
        tau = (idx - ref)[:, None]
        L = lam[None, :] ** tau                                         # (n_t, K)
        cols = [2 * (L.real[:, k:k + 1] * Pr[k][None, :]) for k in range(len(lam))] + \
               [-2 * (L.imag[:, k:k + 1] * Pr[k][None, :]) for k in range(len(lam))]
        B = np.stack([c.ravel() for c in cols], 1)
        coef = np.linalg.lstsq(B, Yr[idx].ravel(), rcond=None)[0]
        K = len(lam)
        return coef[:K] + 1j * coef[K:]

    def push(self, Y: np.ndarray, i: int, pre_s: float = 0.1, post_s: float = 0.05, skip_s: float = 0.01) -> dict:
        """The touch at sample i = the jump it caused in the body's own modal state. Fit the modes just before and
        just after (skipping the touch itself), carry both to sample i, subtract. Returns the state after (for
        imagining what comes next) and v_k = phi_k(x0) F / m (for 'where was I touched')."""
        Yr = self._reduce(Y)
        n_pre, n_post, n_skip = max(int(pre_s * self.fs), 3), max(int(post_s * self.fs), 3), int(skip_s * self.fs)
        a_pre = self._state_fit(Yr, np.arange(max(i - n_pre, 0), max(i - 1, 1)), i) if i > 3 else 0
        a_post = self._state_fit(Yr, np.arange(i + n_skip, min(i + n_skip + n_post, len(Yr))), i)
        da = a_post - a_pre
        sk = self.s[self.sel]
        v = 2j * sk.imag * da
        if self.measure == "velocity":
            v = v / sk
        elif self.measure == "acceleration":
            v = v / sk ** 2
        return {"a_post": a_post, "a_pre": a_pre, "delta": da, "v": v}

    def free_run(self, a: np.ndarray, n: int, start: int = 0) -> np.ndarray:
        """Imagine what happens next with no further touches: (n, P) motion from modal state a at sample `start`."""
        lam = self.lam[self.sel]
        tau = np.arange(start, start + n)[:, None]
        q = 2 * np.real(a[None, :] * lam[None, :] ** tau)
        return q @ np.stack([m.shape for m in self.modes])

    def localize(self, v: np.ndarray) -> dict:
        """Where was it touched? Match the push's modal fingerprint against every point's mode shapes."""
        Phi = np.stack([m.shape for m in self.modes])          # (K, P)
        th = 0.5 * np.angle(np.sum(v ** 2))
        vr = np.real(v * np.exp(-1j * th))
        num = vr @ Phi
        score = num ** 2 / ((vr @ vr) * (Phi ** 2).sum(0) + 1e-30)
        x0 = int(np.argmax(score))
        strength = float(abs(num[x0]) / ((Phi[:, x0] ** 2).sum() + 1e-30))
        return {"point": x0, "score": score, "strength": strength, "fit": float(score[x0])}

    def one_step_error(self, Y: np.ndarray, warm: int = 0) -> float:
        """Mean squared surprise: how badly this body predicts each next sample (output space)."""
        Yr = self._reduce(Y)
        x, err = np.zeros(self.n), []
        for t in range(len(Yr)):
            xp = self.F @ x
            nu = Yr[t] - self.C @ xp
            x = xp + self.K @ nu
            if t >= warm:
                err.append(nu @ nu)
        return float(np.mean(err)) if err else np.nan

    def changed(self, Y: np.ndarray, t0: float, t1: float, factor: float = 3.0, top: int = 2) -> dict:
        """Did the world touch me, or did I change? Learn a fresh body from the first 60% of [t0, t1); on the last
        40% (seen by neither), compare how surprised the old body is with how surprised the fresh one is."""
        Y = np.asarray(Y)
        i0, i1 = int(t0 * self.fs), int(t1 * self.fs)
        cut = i0 + int(0.6 * (i1 - i0))
        new = TouchTransform(self.fs, n_modes=self.n_modes, band=self.band, delays=self.d, order=self.n,
                             space_rank=self.space_rank, measure=self.measure, max_damping=self.max_damping,
                             merge=self.merge, stabilize=self.stabilize).fit(Y[i0:cut])
        warm = int(0.15 * self.fs)
        test = Y[max(cut - warm, 0):i1]
        e_old, e_new = self.one_step_error(test, warm), new.one_step_error(test, warm)
        mine = sorted(self.modes, key=lambda m: -m.energy)[:top]
        shifts = [{"was_hz": m.freq_hz, "now_hz": min(new.modes, key=lambda q: abs(q.freq_hz - m.freq_hz)).freq_hz}
                  for m in mine]
        return {"body_changed": bool(e_old > factor * e_new), "surprise_ratio": e_old / max(e_new, 1e-30),
                "shifts": shifts, "new_body": new.fit(Y[i0:i1])}

    # ---------------- synthesis (imagination) ----------------
    def synthesize(self, E: np.ndarray, Z0: np.ndarray | None = None, modes_only: bool = False) -> np.ndarray:
        """Inverse transform: pushes -> motion on every channel. Exact inverse of `modal` within the subspace
        (states fitted as slightly growing are held at the edge of stability, so imagination can't run away)."""
        lam = self.lam / np.maximum(np.abs(self.lam) / 0.9999, 1.0)
        Z = np.zeros_like(E)
        z = np.zeros(self.n, complex) if Z0 is None else Z0
        for t in range(len(E)):
            z = z * lam + E[t]
            Z[t] = z
        if modes_only:
            keep = np.zeros(self.n, bool)
            keep[self.sel] = True
            keep |= np.isin(np.arange(self.n), [int(np.argmin(np.abs(self.lam - np.conj(self.lam[i])))) for i in self.sel])
            Z = Z * keep
        return np.real(Z @ self.Psi) + self.mean

    def imagine_touch(self, point: int, F_over_m: float, n: int, at: int = 0) -> np.ndarray:
        """Feel the consequence of a touch that never happened: impulse F/m at channel `point` -> (n, P) motion."""
        T = np.zeros(n)
        Y = np.zeros((n, self.P))
        t = np.arange(n - at) / self.fs
        for m in self.modes:
            s = np.log(m.pole) * self.fs
            wd = s.imag
            resp = m.shape[point] * F_over_m / wd * np.exp(s.real * t) * np.sin(wd * t)
            if self.measure == "velocity":
                resp = np.gradient(resp, 1 / self.fs)
            elif self.measure == "acceleration":
                resp = np.gradient(np.gradient(resp, 1 / self.fs), 1 / self.fs)
            Y[at:] += resp[:, None] * m.shape[None, :]
        return Y + 0 * T[:, None]

    # ---------------- words: what one machine can tell another ----------------
    def words(self) -> list[dict]:
        """What one machine can tell another about this body: each mode's pitch, how fast it fades, and how hard
        it was shaken when felt (in the units of the measurement)."""
        amp = getattr(self, "amp", np.zeros(len(self.modes)))
        return [{"word": "mode", "freq_hz": round(m.freq_hz, 4), "damping": round(m.damping, 5),
                 "ring_s": round(1 / (m.damping * 2 * np.pi * m.freq_hz), 4), "amp": float(a), "measure": self.measure}
                for m, a in zip(self.modes, amp)]


def feel_stream(Y: np.ndarray, body: "TouchTransform", start_s: float = 1.0, threshold: float = 15.0,
                relearn_s: float = 3.0, min_gap_s: float = 1.0, max_events: int = 20,
                same: float = 1.6, changed: float = 10.0) -> list[dict]:
    """Feel a whole recording like a body would. For each push: was I touched, or did I change?
    surprise = how much worse my current body predicts what follows than a fresh body learned from it.
      < same      -> touch (I'm still me)
      > changed   -> my body changed (adopt the new body). If an earlier push was only 'maybe', the change is
                     dated to that earlier push, and this push is a touch on the new body.
      in between  -> maybe changed: too little signal to be sure; wait for the next push to confirm.
    Thresholds were set on the ARTS beam recording and then frozen (see eval/e13_touch_transform.py)."""
    Y = np.asarray(Y)
    fs, out, t_from, pending = body.fs, [], start_s, None
    while len(out) < max_events:
        i0 = int(max(t_from - 1.0, 0) * fs)
        an = body.analyze(Y[i0:], threshold=threshold, min_gap_s=min_gap_s)
        ev = [e for e in an["events"] if e["t"] + i0 / fs >= t_from]
        if not ev:
            break
        t = ev[0]["t"] + i0 / fs
        t_next = ev[1]["t"] + i0 / fs - 0.05 if len(ev) > 1 else np.inf
        t_end = min(t + 0.3 + relearn_s, t_next, len(Y) / fs)
        if t_end - (t + 0.3) < 1.0:
            break
        c = body.changed(Y, t + 0.3, t_end)
        r = c["surprise_ratio"]
        rec = {"t": t, "push": float(np.sqrt(ev[0]["z"])), "surprise_ratio": r, "modes_hz": [m.freq_hz for m in body.modes]}
        if r < same:
            rec["kind"] = "touch"
        elif r > changed:
            body = c["new_body"]
            rec["new_modes_hz"] = [m.freq_hz for m in body.modes]
            if pending is not None:
                out[pending]["kind"] = "body changed (confirmed by the next push)"
                out[pending]["confirmed_at"] = t
                rec["kind"] = "touch (on the new body)"
                pending = None
            else:
                rec["kind"] = "body changed"
        else:
            rec["kind"] = "maybe changed (too little signal to be sure)"
            pending = len(out)
        out.append(rec)
        t_from = t + min_gap_s
    return out


def same_body(words_a: list[dict], words_b: list[dict], f_tol: float = 0.02, z_tol: float = 0.6) -> dict:
    """Two recordings (or two machines) feel the same body if every strong mode has a partner with matching
    frequency (within f_tol, relative) and damping (within z_tol, relative)."""
    pairs, unmatched = [], []
    for a in words_a:
        best = min(words_b, key=lambda b: abs(b["freq_hz"] - a["freq_hz"]) / a["freq_hz"]) if words_b else None
        if best and abs(best["freq_hz"] - a["freq_hz"]) / a["freq_hz"] <= f_tol and \
                abs(best["damping"] - a["damping"]) / max(a["damping"], 1e-6) <= z_tol:
            pairs.append((a["freq_hz"], best["freq_hz"]))
        else:
            unmatched.append(a["freq_hz"])
    return {"same": not unmatched, "matched": pairs, "unmatched": unmatched}


def compare_words(words_a: list[dict], words_b: list[dict], f_tol: float = 0.02, z_tol: float = 0.6,
                  amp_ratio: float = 3.0, partner: float = 0.12) -> dict:
    """Do two recordings (or two machines) feel the same body? Honest version:
      - only modes BOTH can feel are compared (a mode that faded in one recording is not evidence of a change);
      - a pair is only comparable if both were shaken alike (amplitudes within amp_ratio), because real objects
        ring at slightly different pitches when shaken harder;
      - verdict: 'same', 'different', or "can't compare" (nothing comparable)."""
    pairs, skipped, not_shared = [], [], []
    for a in words_a:
        b = min(words_b, key=lambda b: abs(np.log(b["freq_hz"] / a["freq_hz"]))) if words_b else None
        if b is None or abs(b["freq_hz"] / a["freq_hz"] - 1) > partner:
            not_shared.append(a["freq_hz"])
            continue
        ra = (max(a.get("amp", 1), 1e-30) / max(b.get("amp", 1), 1e-30))
        if a.get("amp") and b.get("amp") and max(ra, 1 / ra) > amp_ratio:
            skipped.append({"a_hz": a["freq_hz"], "b_hz": b["freq_hz"], "amp_ratio": float(max(ra, 1 / ra))})
            continue
        ok = abs(b["freq_hz"] / a["freq_hz"] - 1) <= f_tol and abs(b["damping"] - a["damping"]) / max(a["damping"], 1e-6) <= z_tol
        pairs.append({"a_hz": a["freq_hz"], "b_hz": b["freq_hz"], "shift_pct": 100 * (b["freq_hz"] / a["freq_hz"] - 1), "match": bool(ok)})
    if not pairs:
        verdict = "can't compare"
        say = ("They were shaken too differently to compare: feel them at similar strength." if skipped
               else "They share no modes at all.")
    elif all(p["match"] for p in pairs):
        verdict, say = "same", "Same body: every mode both can feel matches."
    else:
        verdict, say = "different", "Different body: " + ", ".join(f"{p['a_hz']:.2f} -> {p['b_hz']:.2f} Hz" for p in pairs if not p["match"])
    return {"verdict": verdict, "say": say, "compared": pairs, "shaken_differently": skipped, "only_in_a": not_shared}
