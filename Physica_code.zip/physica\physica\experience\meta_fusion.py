"""Live Meta fusion entry point: Spark context -> SAM optical evidence ->
Wonder constrained scientific review -> PACER/Dual World ranking.

Refuses to proceed on missing calibration or absent real API key; never
fabricates a model output, sensor datum, or V-JEPA scalar readout.
"""
from __future__ import annotations
import hashlib,json
from pathlib import Path
import numpy as np
from .meta_live import muse_scientist,sam_video,calibrated_track_displacement
from .dual_world import CalibratedForecast,rank_actions
from .pacer import Experiment,choose_experiment
from .field_protocol import read_csv
from .seal import write_json


def _hash(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(video_path, sensor_csv, dual_request_json, *, concept, bbox_track_id,
        meters_per_pixel, fps, output, max_cross_sensor_rmse_m=.0007,
        explicit_bill_permission=False):
    """Requires synchronized independent sensor signal to check optical units.

    Dual request may contain external V-JEPA calibrated forecasts, or be None;
    only actual model-sourced forecasts can be labelled as such. Missing a
    dual world model falls back to PACER single-model selection, with warning.
    """
    if not explicit_bill_permission:
        raise PermissionError('Live hosted API consumes money. Explicit --allow-billed-meta is required')
    if not all(np.isfinite(v) and v>0 for v in (meters_per_pixel,fps,max_cross_sensor_rmse_m)):
        raise ValueError('invalid independent camera calibration/sensor tolerance')
    t_sensor,y_sensor=read_csv(sensor_csv)
    calibrated_facts={
        'physical_sensor_csv_sha256':_hash(sensor_csv),
        'video_file_sha256':_hash(video_path),'measurement':'tip_displacement',
        'measurement_unit':'m','sensor_count':len(t_sensor),
        'calibration_m_per_pixel':meters_per_pixel,'fps':fps,
        'scientific_constraints':'camera in plane, stationary, no perspective drift; logged sensor data'}
    if not dual_request_json:raise ValueError('give an experiment request (with prior and actions)')
    request=json.loads(Path(dual_request_json).read_text())
    actions=[Experiment(**a) for a in request['actions']]
    allowed=[a.action_id for a in actions if a.safety_approved and not a.irreversible and a.risk<=.12]
    if not allowed:raise ValueError('no safe whitelisted experiment available')
    # Reject synthetic/invalid learned-model evidence BEFORE any potentially billed calls.
    paired={k:(CalibratedForecast(**v[0]),CalibratedForecast(**v[1])) for k,v in request.get('paired_forecasts',{}).items()}
    for pair in paired.values():
        if pair[1].origin not in ('model','replay') or pair[1].model_id in ('synthetic','mock'):
            raise ValueError('refuse ungrounded or synthetic V-JEPA evidence in live fusion')
        if not pair[1].calibrated or not pair[0].calibrated:
            raise ValueError('dual models must be calibrated against held-out measurements')
    # Spark contextualises media and measurements. It cannot write the measurements.
    spark=muse_scientist(calibrated_facts,allowed,role='spark',video_path=video_path)
    # SAM only receives a *concrete* user-supplied noun phrase. Never treat masks
    # as forces; track a part and transform measured pixels using external scale.
    segment=sam_video(video_path,concept=concept)
    optical=calibrated_track_displacement(segment['boxes'],object_id=bbox_track_id,
                                          meters_per_pixel=meters_per_pixel,frames_per_second=fps)
    tt=np.asarray(optical['time_s']);yy=np.asarray(optical['displacement_m'])
    # The time origin must match: compare shape after subtracting initial offset.
    if tt[0]<t_sensor[0]-1e-6 or tt[-1]>t_sensor[-1]+1e-6:
        raise ValueError('tracked video outside sensor time support; synchronize clocks first')
    sensor=np.interp(tt,t_sensor,y_sensor)
    err=float(np.sqrt(np.mean(((sensor-sensor[0])-yy)**2)))
    if err>max_cross_sensor_rmse_m:
        raise ValueError(f'optical & physical sensors disagree {err:g}m: reject evidence (check camera motion, scale, synchronization)')
    grounded={**calibrated_facts,'SAM_concept':concept,'SAM_model_id':'sam-3.1',
              'tracked_frames':len(tt),'optical_vs_sensor_rmse_m':err,
              'tracked_max_displacement_m':float(np.max(np.abs(yy))),
              'optical_measurement_origin':'SAM bbox centers + user-meter-per-pixel calibration'}
    wonder=muse_scientist(grounded,allowed,role='wonder',video_path=video_path)
    # Enforce data availability: no 'allow_partial' in dual-world evidence.
    if paired:
        ranking=rank_actions(request['prior'],actions,paired,max_risk=.12)
    else:
        ranking=choose_experiment(request['prior'],actions,max_risk=.12)
        ranking['mode']='PACER_PHYSICS_ONLY_NO_VJEPA'
    chosen=ranking.get('chosen')
    # If Muse's proposal is not the highest verified utility, it cannot win.
    result={'status':'LIVE_CONTEXT_PLUS_SENSOR_CROSSCHECK','spark':spark,'sam_tracking':{
            'source_video_sha256':segment['video_sha256'],'model_id':'sam-3.1','track_id':bbox_track_id,
            'geometry':optical,'sensor_crosscheck_rmse_m':err},
            'wonder':wonder,'physical_gate':ranking,
            'muse_suggestion_matches_physical_gate':wonder['reply'].get('suggested_action')==chosen,
            'selected_experiment':chosen,'hardware_actuation_performed':False,
            'source_sensor_sha256':_hash(sensor_csv),
            'disclaimer':'Numerical safety and forecasts require calibrated physics; the system never actuates automatically'}
    write_json(output,result)
    return result
