"""Reproducible v0.20 *SIMULATED* evidence-sufficiency demonstration.

Run: python eval/e27_evidence_first.py
No hardware, live Meta calls or real-data novelty claims.
"""
from __future__ import annotations
import json
import tempfile
from pathlib import Path

import numpy as np
from physica import auto, fan_sim
from physica.investigation import CandidateMeasurement, goal_directed_value_of_information
from physica.experiment import balance

ROOT=Path(__file__).resolve().parents[1]


def run():
    t=np.arange(4096)/512
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)
        np.savetxt(p/'tone.csv',np.c_[t,np.sin(2*np.pi*12*t)],delimiter=',')
        np.savetxt(p/'noise.csv',np.c_[t,np.random.default_rng(3).normal(size=len(t))],delimiter=',')
        (p/'text.csv').write_text('not numeric data')
        unknown={x:auto.run(p/(x+'.csv'),live=False) for x in ('tone','noise','text')}
        clips=fan_sim.four_clips(str(p))
        fix=auto.balance_from_videos(clips,1.)
        after=fan_sim.after_clip(str(p),fix['correction_g'],fix['correction_angle_deg'])
        checked=balance.check(fix,balance.consistent_video_signal(after))
    ranking=goal_directed_value_of_information([.25]*4,[
        CandidateMeasurement('irrelevant appearance detail',(0,3,0,3),.15),
        CandidateMeasurement('goal-relevant physical response',(0,0,3,3),.15),
    ], [[1,1,0,0],[0,0,1,1]],samples=5000)
    d={
        'provenance':'SIMULATION / GENERATED SIGNALS ONLY',
        'release':'0.20',
        'ambiguous_inputs':{k:{'template':v['identified']['template'],'status':v['status'],
                               'why':v['identified']['why'],
                               'next':v['investigation']['recommended_next_measurement']}
                            for k,v in unknown.items()},
        'lab_rotor':{'simulated_truth_hz':12,'estimated_hz':round(fix['once_per_turn_hz'],3),
                     'simulated_truth_correction_g':round(1./fan_sim.T,3),
                     'estimated_correction_g':round(fix['correction_g'],3),
                     'simulated_after_wobble_reduction_pct':round(checked['wobble_drop_fraction']*100,2),
                     'verdict':fix['verdict'],'advisory_only':True,
                     'safety':fix['safety']},
        'goal_directed_measurement':ranking,
        'limitations':['No real sensor dataset was newly trained',
                       'No authenticated Meta call was performed',
                       'Not a general machine diagnosis',
                       'Information acquisition uses supplied calibrated hypothetical likelihoods',
                       'No autonomous real machine actuation']}
    return d


def exhibit(d):
    payload=json.dumps(d,allow_nan=False)
    return r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Physica | Evidence-First Theater</title><style>
:root{color-scheme:dark;--bg:#071016;--card:#0d1c26;--line:#21414b;--green:#60f5cf;--txt:#e8f7fa;--dim:#9cb7bf;--warn:#ffc976}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at top right,#102939,var(--bg) 62%);color:var(--txt);font:15px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}main{max-width:1100px;margin:auto;padding:36px 25px 70px}
small,.note{color:var(--dim)}h1{font-size:clamp(34px,5vw,70px);line-height:1.05;letter-spacing:-.04em;margin:9px 0}h1 em{color:var(--green);font-style:normal}h2{font-size:22px;margin:6px 0 13px}.tag{font:700 11px ui-monospace,monospace;letter-spacing:.17em;color:var(--green)}
section{border:1px solid var(--line);border-radius:18px;padding:24px;margin:20px 0;background:rgba(13,28,38,.8)}.tabs{display:flex;gap:8px;flex-wrap:wrap}.tabs button{background:#122732;color:var(--txt);padding:12px 14px;border:1px solid var(--line);border-radius:10px;cursor:pointer}.tabs button.sel{background:#165d54;border-color:var(--green)}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:14px}.metric{padding:18px;background:#0c222a;border:1px solid #1b4b49;border-radius:12px}.big{font-size:40px;font-weight:850;letter-spacing:-.04em}.warn{color:var(--warn)}.bar{height:10px;border-radius:10px;background:#172d37;overflow:hidden;margin-top:12px}.fill{height:100%;background:var(--green);border-radius:10px}.muted{color:var(--dim)}canvas{width:100%;height:auto;max-height:220px;border:1px solid var(--line);border-radius:14px;background:#091721}pre{white-space:pre-wrap;overflow-wrap:anywhere;padding:14px;background:#0b2028;border-radius:10px;font-size:12px}
</style></head><body><main><div class="tag">Φ PHYSICA · v0.20 / VERIFIED SOFTWARE DEMO</div><h1>AI can see the world.<br><em>Can it know what it doesn't know?</em></h1><p>Give it an unfamiliar physical signal. Physica measures the evidence, tests what it can justify, and requests the right next measurement instead of inventing a machine.</p>
<div class="tabs"><button class="sel" data-tab="unknown">01 · Refuse a guess</button><button data-tab="rotor">02 · Feel a rotor</button><button data-tab="goal">03 · Ask the right question</button></div>
<section><div class="tag" id="kind"></div><h2 id="headline"></h2><p id="description" class="muted"></p><canvas id="wave" width="940" height="210"></canvas><div class="grid" style="margin-top:18px" id="metrics"></div><p class="note" id="footnote"></p></section>
<div class="tag">SCIENTIFIC EVIDENCE AND SAFETY</div><p>This exhibit uses <b>generated data</b> and <b>simulated hardware</b>; it is not a real sensor validation, live Meta inference, arbitrary diagnosis, or proven new mathematical law. The full Studio has an actual local video/CSV upload and optional authenticated Meta scientist path.</p>
<details><summary>See complete reproducible evidence JSON</summary><pre id="json"></pre></details>
</main><script>
const R=__PAYLOAD__;let tab='unknown';const $=s=>document.querySelector(s);
function wave(kind){let c=$('#wave'),g=c.getContext('2d'),w=c.width,h=c.height;g.clearRect(0,0,w,h);g.strokeStyle='#20414d';for(let i=1;i<5;i++){g.beginPath();g.moveTo(0,i*h/5);g.lineTo(w,i*h/5);g.stroke()}
 g.strokeStyle='#60f5cf';g.lineWidth=2;g.beginPath();for(let i=0;i<w;i++){let t=i/w*6,y=kind==='unknown'?Math.sin(t*12*2*Math.PI):kind==='rotor'?Math.sin(t*12*2*Math.PI)*(1-.37*t/6):kind==='goal'?Math.sin(t*7*2*Math.PI)*Math.exp(-t*.4):Math.random()-.5;let py=h/2-y*h*.34;i?g.lineTo(i,py):g.moveTo(i,py)}g.stroke();}
function metric(label,value,sub){return `<div class="metric"><div class="muted">${label}</div><div class="big">${value}</div><small>${sub||''}</small></div>`}
function view(next){tab=next;document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('sel',b.dataset.tab===tab));$('#kind').textContent='SIMULATED / REPRODUCIBLE';
 if(tab==='unknown'){const a=R.ambiguous_inputs.tone;$('#headline').textContent='12 Hz is a measurement. “Fan” is a guess.';$('#description').textContent=a.why+'. The algorithm abstains and requests independent context.';$('#metrics').innerHTML=metric('Measured tone','12 Hz','from synthetic waveform')+metric('Identity','UNKNOWN','noise and nonnumeric files are also refused')+metric('Next step','Tachometer','verify a true rotation rate if a rotor is confirmed');$('#footnote').textContent='No identity or physical correction is inferred from a pure tone.'}
 else if(tab==='rotor'){let a=R.lab_rotor;$('#headline').textContent='Four recordings. One consistent physical motion measurement.';$('#description').textContent='A generated rated-lab-rotor experiment; the video code measures optical-flow velocity the same way for every trial.';$('#metrics').innerHTML=metric('Estimated rotation',a.estimated_hz+' Hz','simulator truth 12.00 Hz')+metric('Estimated lab correction',a.estimated_correction_g+' g','simulator truth '+a.simulated_truth_correction_g+' g')+metric('Simulated wobble reduction',a.simulated_after_wobble_reduction_pct+'%','not measured on physical equipment');$('#footnote').textContent=a.safety}
 else {let r=R.goal_directed_measurement;$('#headline').textContent='More information is not always more useful information.';$('#description').textContent='A goal-directed measurement is ranked higher than a sensor that reveals irrelevant detail. The likelihoods and payoffs are explicitly supplied, never invented.';$('#metrics').innerHTML=r.map(x=>metric(x.name, x.expected_value_of_information.toFixed(3),'expected goal-value improvement')).join('');$('#footnote').textContent='Simulation with a known four-hypothesis likelihood, not a verified general-purpose scientific agent.'}
 wave(tab)}document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>view(b.dataset.tab));$('#json').textContent=JSON.stringify(R,null,2);view(tab);
</script></body></html>'''.replace('__PAYLOAD__',payload)


if __name__=='__main__':
    data=run()
    out=ROOT/'eval/results/E27_evidence_first.json';out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    page=ROOT/'examples/v020/EVIDENCE_THEATER.html';page.parent.mkdir(parents=True,exist_ok=True)
    page.write_text(exhibit(data),encoding='utf-8')
    print('Evidence',out,'Theater',page,'Rotor',data['lab_rotor'])
