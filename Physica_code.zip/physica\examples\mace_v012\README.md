# Physica v0.12 — Unfamiliar Mechanism Synthetic Lockbox

Open `evidence_lab.html` in a browser. This is an interactive presentation of saved, reproducible numerical code output, NOT a live physical experiment. Data is deliberately simulated from a known temperature-dependent force-law term. The learner is missing this term in its baseline, builds a restricted candidate dictionary, and chooses based on independent validation episodes before scoring a third lockbox episode. The saved output is not independent laboratory validation.

To regenerate:

```bash
python -m physica.mace.cli discover-unknown --seed 2026 --out examples/mace_v012/mace_unknown_discovery.json
```

The command regenerates its sibling HTML at `examples/mace_v012/mace_unknown_discovery.html`. See `docs/V012_DISCOVERY_AND_STUDIO.md` for the caveats, Meta configuration, and links to real-data methods.
