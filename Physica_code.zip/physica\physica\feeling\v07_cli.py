"""Physica v0.7 evidence commands. No hardware actuation or fabricated Meta calls."""
from __future__ import annotations
import argparse,json
from dataclasses import asdict
from pathlib import Path
import numpy as np
from .core import Body,Sense
from .reliable_fusion import TrustedFeelingFilter
from .v07_benchmarks import save
from .mechanism_transfer import (discover_and_sign,make_target_probe_certificate,predict_target_acceleration)


def _read(path):return json.loads(Path(path).read_text())

def _write(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,indent=2)+'\n')
    print('Wrote',p)


def main(argv=None):
    p=argparse.ArgumentParser(description='Physica v0.7 predictive physical feeling research')
    subs=p.add_subparsers(dest='cmd',required=True)
    b=subs.add_parser('benchmark',help='reproducible SYNTHETIC comparisons')
    b.add_argument('--out',default='demo/v07_research.json');b.add_argument('--trials',type=int,default=12)
    b.add_argument('--seed',type=int,default=2026)
    fu=subs.add_parser('fuse',help='consume calibrated, synchronized source sensor JSON')
    fu.add_argument('input');fu.add_argument('--out',required=True)
    ab=subs.add_parser('meta-ablation',help='compare saved Muse candidate names against full physics search with same data')
    ab.add_argument('input');ab.add_argument('saved_model_reply');ab.add_argument('--out',required=True)
    learn=subs.add_parser('discover-mechanism',help='discover mechanism from distinct x/v/a/force actions')
    learn.add_argument('input');learn.add_argument('--out',required=True)
    ck=subs.add_parser('probe-mechanism',help='certify low-force measured target probe')
    ck.add_argument('source');ck.add_argument('target_probe');ck.add_argument('--out',required=True)
    cp=subs.add_parser('forecast-mechanism',help='conditional forecast excluding withheld target acceleration')
    cp.add_argument('source');cp.add_argument('target_request');cp.add_argument('probe_certificate');cp.add_argument('--out',required=True)
    args=p.parse_args(argv)
    if args.cmd=='benchmark':
        r=save(args.out,args.trials,args.seed)
        print('Mean equal-probe RMSE:',r['same_budget_friction']['average_camera_rmse']);return r
    if args.cmd=='fuse':
        o=_read(args.input);body=Body(**o['body']);senses={k:Sense(**v) for k,v in o['senses'].items()}
        flt=TrustedFeelingFilter(body,senses,np.asarray(o['initial_state_m_m_s'],float),
             np.asarray(o['initial_covariance'],float),friction_ratio=float(o.get('friction_ratio',0.)))
        rows=[]
        for r in o['samples']:
            rows.append(flt.step(r['timestamp_s'],r['force_n'],r.get('sensors',{})))
        result={'schema':'physica.feeling.sensor-session.v07','provenance':body.provenance,
               'rows':rows,'no_actuation':True}
    if args.cmd=='meta-ablation':
        from .meta_ablation import compare_meta_candidates
        o=_read(args.input);body=Body(**o['body'])
        result=compare_meta_candidates(body,o['training'],o['heldout'],_read(args.saved_model_reply),
            displacement_reference_m=o['displacement_reference_m'])
    if args.cmd=='discover-mechanism':
        o=_read(args.input);body=Body(**o['body'])
        result=discover_and_sign(body,o['training'],o['heldout'],
             displacement_reference_m=o['displacement_reference_m'])
    if args.cmd in ('probe-mechanism','forecast-mechanism'):
        source=_read(args.source);o=_read(args.target_probe if args.cmd=='probe-mechanism' else args.target_request)
        target=Body(**o['target_body'])
        if args.cmd=='probe-mechanism':
            result=make_target_probe_certificate(source,target,o['observed_probe'],
                      displacement_reference_m=o['displacement_reference_m'],
                      measurement_noise_force_n=o['measurement_noise_force_n'])
        else:
            result=predict_target_acceleration(source,target,o['forecast_request'],
                displacement_reference_m=o['displacement_reference_m'],
                probe_certificate=_read(args.probe_certificate))
    _write(args.out,result)
    return result

if __name__=='__main__':main()
