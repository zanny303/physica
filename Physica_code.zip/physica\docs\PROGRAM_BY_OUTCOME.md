# Program machines by outcome, not by instruction

Today every machine is programmed by **instruction**: G-code says "move here", PLC logic says "if this then that",
a drone mission says "fly to these points". A person reads the sensors, decides what should happen, translates that
into the machine's language, and hopes the physics agrees. That is why a footbridge can sway, a turbine can restart
with a crack, and a printer rings at its own resonance: the instruction was right and the outcome was wrong.

Physica lets you program by **outcome**: you say the result you want, in plain words, and it writes the instructions.

```
"A pump beside this beam runs at 31 Hz.            goal ──► checkable spec        (Muse Spark live, or offline parser)
 Keep the beam's tone at least 5% away from it      spec ──► sensed map           (what each knob does, with error bars,
 and move the support as little as possible."                                     learned from the machine's own vibration)
                                                    map  ──► plan                 (only actions whose WHOLE error bar meets the goal)
                                                    plan ──► machine code         (G-code, PLC Structured Text, MAVLink, lab script)
                                                    code ──► the machine's own toolchain checks it (Klipper, matiec, ArduPilot)
                                                    plan ──► sealed promise       (Ed25519 + SHA-256 + UTC, before acting)
                                                    act  ──► reality grades the promise; the graded record teaches the next machine
```

Run it: `physica outcome "<what you want>"` (see `physica outcome --help`). Evidence: `eval/e23_program_by_outcome.py`
→ `eval/results/E23_program_by_outcome.json`, machine code in `eval/results/outcome/`.

## What is proven, and how

### A. A real structure retuned by goal (REAL DATA)

DROPBEAR Dataset-8 (University of South Carolina): a 501 mm steel cantilever whose roller support is moved by a linear
actuator. Physica's map (support position → first tone, with local 90% conformal error bars) is learned **only** from
the July 19, 2022 slow sweep. A point enters the map only when both accelerometers agree within 3%.

Goals: a pump at every speed from 25 to 42 Hz (0.5 Hz steps) × every position the actuator's index set commands =
840 goals. Each plan is graded on the **June 6, 2022** random-position trials (another day, other sequences): at the
position Physica chose, did the real beam ring outside the ±5% danger band, and inside the sealed interval?

| Planner | Moves that worked on every real recording | Average move |
|---|---|---|
| **Physica** (the whole error bar must clear the danger band) | **178 of 178** | 12.0 mm |
| Same planner without error bars (aim at the curve) | 108 of 145 | 8.7 mm |
| Always move to the far end | 840 of 840 | 43.8 mm |

- 10,546 real recordings at Physica's chosen positions: 100% outside the danger band. 660 goals were already met
  where the support sat; Physica said "stay", and every one of those was right on every recording.
- Sealed intervals held on 89.3% of recordings (90% claimed). v0.18 fixed the calibration to a proper split: the
  curve is fitted on one half of the sweep and never refit with the half that sets the error bar (v0.17 refit on both,
  which made its 92.6% look better than a split-conformal guarantee allows). The local window is a heuristic, so coverage
  is checked on another day rather than guaranteed.
- **Why the error bars matter:** aiming at the curve picks spots that look just safe; 37 of those 145 moves left the
  beam inside the danger band. Near the clamp the beam's tone flips between about 24 and 26 Hz (a support that seats
  two ways); Physica's error bar is ±1.4 Hz there and ±0.2 Hz elsewhere, because it learned that from the sweep.
- **Machine code, checked by the machine's own firmware:** the move is written as Klipper G-code with the positions
  the beam has felt written into the firmware's limits. Real Klipper (batch mode) planned 22 step commands that move
  exactly the 4.7 mm asked, and it **refused** a move outside the felt range ("Move out of range"): the refusal is
  enforced by the machine, not just by our code.

Honest notes: candidate positions are the actuator's preset positions (taken from where the June trials held the
support, never from their tones). DROPBEAR's actuator is driven by LabVIEW, so the G-code is for a G-code-driven stage
doing the same move. One beam, one lab. Klipper's batch mode runs the real host software but, as its documentation
says, is not the same as talking to a real controller board.

### B. A wind turbine's response, as PLC code the turbine enforces itself (REAL VERDICTS)

Goal: "keep producing through tonight's freeze; never restart a blade that might be cracked." **Physica refuses the
"never" as a promise**: its outcome contract reads the blade sense's measured misses (9 of 111 crack groups judged
"weather", 8 of them the smallest 5 cm crack) and says so, then offers review-only logic that states the risk
(`--accept-measured-risk`). Physica's blade verdicts
(E20, real ETH Zürich blade, second test campaign) become IEC 61131-3 Structured Text, the language turbine and factory
PLCs run (CODESYS, Beckhoff, Bachmann, Siemens, OpenPLC). The sealed de-icing promise is now logic in the PLC:
after heating, the turbine may resume only if Physica's change score has fallen to the sealed threshold; otherwise it
brakes, calls the drone, and only a human inspector can clear it.

- Compiled by **matiec** (the IEC 61131-3 compiler inside OpenPLC and Beremiz) and the generated C by **gcc**: passed.
- On the 195 real verdicts: 98 crack groups sent to the drone; the 4 cracks that looked like ice reach the
  "grade the promise" state, heating does not fix them, and the PLC brakes (E20: 0 cracked blades restarted).
- Known gap carried from E20: 9 crack groups (8 of them the smallest, 5 cm crack) were judged "weather only", so the
  PLC lets them run. The guard is only as good as the sense feeding it.

### C. The inspection drone, flown on the real autopilot code (and it caught our bug)

The blade-inspection mission (MAVLink, QGC WPL 110) was loaded by **pymavlink** and flown on the real **ArduPilot**
copter code in software-in-the-loop (real autopilot, simulated physics).

- v0.16's mission ended with RTL and put "home" at the tower base. Flown on ArduPilot, RTL brought the drone straight
  back to the tower and down past the blade tip: closest horizontal approach **0.0 m** above 15 m height. Our own
  checks (altitude limit, stand-off at the waypoints) had passed it.
- v0.17 launches and lands at the stand-off point, in one column in front of the rotor. Flown again: mission accepted,
  8/8 waypoints, highest 58.5 m, closest approach **12.0 m** (the stand-off), landed and disarmed.
  Track: `eval/results/outcome/sitl_track.png`.

This is the point of checking with the machine's own toolchain: our parser agreed with our generator; the autopilot
did not.

### D. A real remote robot (written, not yet run)

`eval/results/outcome/run_cloudpendulum.py` is the full loop for Chalmers' **CloudPendulum** (real motors and pendulums
you control over the internet with the `pycloudpendulum` client): a gentle probe at known gains → Physica fits the
joint's inertia and friction → picks impedance gains for "reach 1 rad within 0.6 s with under 5% overshoot", checked
at the corners of its uncertainty → seals settling time and overshoot → runs → grades. Tested only on a simulated joint
here (labelled in the tests). It needs a CloudPendulum account approved by Chalmers.

## Can it drive online remote labs and robots right now?

Not from this build machine: it can reach code hosts but not lab servers, and real remote labs require a human-approved
account. What exists and fits:

| Lab | What you control | Access | Fit |
|---|---|---|---|
| CloudPendulum (Chalmers) | real motor / pendulum / double pendulum cells, Python API, live video | account approved by an admin | ready: `run_cloudpendulum.py` |
| Practable (University of Edinburgh) | real spinning disks (motor control), pendulums, structures, in the browser | bookings by group | goal → controller gains → run → download CSV → grade |
| Your own machine | anything with G-code, a PLC or MAVLink | you | `physica outcome` writes and checks the code |

For the video, the strongest live moment is: apply for CloudPendulum today; if approved, run the probe and the chosen
gains on camera with the lab's live stream next to the sealed promise.

## "Like G-code or COBOL?"

Machines don't speak COBOL (banks do), but the idea is right: most of the physical world runs on languages few people
still write. PLC ladder and Structured Text are the COBOL of machines: they run factories, water plants and turbines,
and the people who write them are scarce. Physica writes:

| Language | Machines | Checked by |
|---|---|---|
| G-code (Klipper, GRBL, Marlin) | printers, CNC, linear stages, lab actuators | real Klipper (batch mode) |
| IEC 61131-3 Structured Text | turbines, factories, water plants (CODESYS, Beckhoff, Siemens, OpenPLC) | real matiec + gcc |
| MAVLink missions | ArduPilot / PX4 drones | pymavlink + real ArduPilot (SITL) |
| Lab client scripts | remote labs (CloudPendulum) | the lab, when you run it |
| `physica.turbine_command.v1` | SCADA via a site adapter | schema |

Next on the list, same pattern: Universal Robots URScript (checked in URSim), ROS 2 messages, Modbus/OPC UA writes.

## Where Meta's models sit

- **Muse Spark** reads the goal into the strict JSON spec (`response_format: json_schema`), marks what it couldn't
  read as `unclear` instead of guessing, and writes the operator briefing using only numbers from the plan
  (`physica outcome "..." --live`). It never picks the action: the engineer does, with physics and error bars.
- **SAM 3.1** can watch the machine carry it out: `physica cause plan/reveal --video` already reads the beam from
  video; wiring that into `physica outcome` grading is next.
- **Muse Wonder**'s agent already calls Physica's tools (v0.16); exposing plan → write → check → seal → grade to it as
  tools is next.

Without a key the offline parser is used and the output says so.

## Why it matters

Physical outcomes are bottlenecked on expert attention: someone must read the sensors, decide, write machine code and
check the result, for every machine, every time. That is why bridges are inspected every two years, why a 69%
false-alarm rate gets alarms ignored, and why F1-level engineering exists only in F1. Program-by-outcome collapses that
loop, and the sealed, graded promise is the unit test the physical world has never had. Every graded promise is a
record of action → consequence, checked by reality: exactly the dataset physical AI is missing.

## Limits

One beam, one blade, simulated drone physics, and a remote-lab run that hasn't happened. The beam map holds only
inside the positions it has felt (it refuses outside them, and so does the firmware). Error bars are calibrated on one
day and graded on another; a new machine needs its own sweep. Muse's spec reading has not yet been run live.

## Sources

- DROPBEAR Dataset-8: https://github.com/High-Rate-SHM-Working-Group/Dataset-8-DROPBEAR-Acceleration-vs-Roller-Displacement (CC BY-SA 4.0)
- Klipper: https://github.com/Klipper3d/klipper
- matiec IEC 61131-3 compiler: https://github.com/beremiz/matiec
- ArduPilot (SITL): https://github.com/ArduPilot/ardupilot
- CloudPendulum onboarding: https://cloudpendulum.m2.chalmers.se/onboarding/control-loop.html
- University of Edinburgh remote labs (Practable): https://eng.ed.ac.uk/about/facilities/remote-labs
