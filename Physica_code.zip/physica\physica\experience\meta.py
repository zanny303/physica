"""Constrained Muse scientific reviewer. Model never supplies facts or overrides PACER.

REAL calls require configured Meta Model API endpoint/model/price/key in .env.
MOCK is clearly labeled. SAM/V-JEPA live weights not bundled.
"""
from __future__ import annotations

import hashlib
import json
import os
from physica.llm import meta_client as mc


def _hash(x):return hashlib.sha256(json.dumps(x,sort_keys=True,default=str).encode()).hexdigest()


def review(facts:dict,allowed_actions:list[str],*,role:str="wonder") -> dict:
    if role not in ("wonder","spark"): raise ValueError("role must be wonder or spark")
    # Serialize verified numeric facts and gate valid action labels. No observed value invented.
    body={"facts":facts,"allowed_actions":list(allowed_actions),
          "instruction":"Review hypotheses, propose ONE safe next action from allowed_actions, and explain uncertainty. "
                        "Never invent measurements. Return JSON with keys explanation, proposed_action, caveat."}
    if mc.is_mock():
        answer={"explanation":"Offline deterministic explanation only; causal inference remains in PACER.",
                "proposed_action":allowed_actions[0] if allowed_actions else None,
                "caveat":"MOCK / NO LIVE META INFERENCE"}
        mode="mock"
        model="none"
    else:
        model=os.environ.get("MODEL_WONDER" if role=="wonder" else "MODEL_SPARK","")
        if not model:raise mc.NotConfigured("configure exact Meta model ID")
        msgs=[{"role":"system","content":"You are Muse, a physical-science hypothesis reviewer. "
                           "Return strict JSON only. Do not fabricate measurements or approve unlisted actions."},
              {"role":"user","content":json.dumps(body,sort_keys=True)}]
        # Default to a configurable modern Responses-shaped gateway.
        # Legacy chat-completions is opt-in and may not be supported by Meta.
        protocol=os.environ.get("META_API_PROTOCOL","responses")
        if protocol=="responses":
            from .meta_world import MetaGateway, extract_text
            gw=MetaGateway.from_env(role=role)
            live=gw.call(msgs)
            response=extract_text(live["result"])
        elif protocol=="chat_completions_legacy":
            response=mc.chat(role,msgs,task="pacer_review",max_tokens=500,temperature=0.1)
        else:
            raise mc.NotConfigured("META_API_PROTOCOL must be responses or chat_completions_legacy")
        try:answer=json.loads(response[response.index("{"):response.rindex("}")+1])
        except (ValueError,json.JSONDecodeError):
            answer={"explanation":response,"proposed_action":None,"caveat":"non-JSON output; action rejected"}
        mode="live";answer["proposed_action"]=answer.get("proposed_action") if answer.get("proposed_action") in allowed_actions else None
    answer={k:answer.get(k) for k in ("explanation","proposed_action","caveat")}
    return {"mode":mode,"role":role,"model_id":model,"request_sha256":_hash(body),
            "response_sha256":_hash(answer),"review":answer,
            "numeric_override_allowed":False}
