"""Research-only controlled ablation: physics, learned residual, symbolic and MLP.

Splits are independent intervention episodes. The residual MLP is not marketed
as a universal Neural ODE: integrating its learned derivative creates a hybrid
neural differential equation in discrete time. No hardware execution.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.linear_model import Ridge

DT=.025

def law(x,v,u,eta):
    known=-1.8*x-.32*v+u
    unknown=eta*(.58*np.sin(3.7*x+1.15*v)+.27*v*abs(v))
    return known,known+unknown

def make_episode(seed,eta,n=240):
    rng=np.random.default_rng(seed);x=float(rng.uniform(-.65,.65));v=float(rng.uniform(-.3,.3))
    arr=[]
    for t in range(n):
        u=float(.65*np.sin(t*DT*(.65+(seed%7)*.09))+.35*np.cos(t*DT*.47+seed)+rng.normal(0,.025))
        known,actual=law(x,v,u,eta);arr.append((x,v,u,known,actual))
        v+=actual*DT;x+=v*DT
        if abs(x)>8: raise ValueError('Simulation escaped operating range')
    return np.array(arr)

def features(a):return a[:,:3]
def symbolic(a):
    x,v,u=features(a).T
    return np.column_stack([x,v,u,x*x,v*v,x*v,np.sin(x),np.sin(3.7*x+1.15*v),v*np.abs(v)])

def fit_predict(train,eval_data,kind,seed):
    baseline=eval_data[:,3];resid=train[:,4]-train[:,3]
    if kind=='physics': return baseline
    if kind=='linear_residual':model=Ridge(alpha=.03);tx=features(train);vx=features(eval_data)
    elif kind=='symbolic_library':model=Ridge(alpha=.03);tx=symbolic(train);vx=symbolic(eval_data)
    elif kind=='neural_residual':
        # Normalize only using training episodes; standardization kept inside model pipeline.
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
        model=make_pipeline(StandardScaler(),MLPRegressor(hidden_layer_sizes=(24,24),alpha=.02,
            activation='tanh',learning_rate_init=.002,max_iter=260,random_state=seed,early_stopping=False))
        tx=features(train);vx=features(eval_data)
    else:raise ValueError('unknown candidate')
    model.fit(tx,resid)
    return baseline+model.predict(vx)

def evaluate(seeds=6, eta=1., ntrain=4):
    rows=[]; kinds=['physics','linear_residual','symbolic_library','neural_residual']
    for seed in range(seeds):
        tr=np.concatenate([make_episode(1000+seed*100+i,eta,200) for i in range(ntrain)])
        validation=make_episode(20000+seed,eta,170)
        test=make_episode(40000+seed,eta,180)
        val_scores={k:float(np.sqrt(np.mean((fit_predict(tr,validation,k,seed)-validation[:,4])**2))) for k in kinds}
        winner=min(val_scores,key=val_scores.get)
        test_scores={k:float(np.sqrt(np.mean((fit_predict(tr,test,k,seed)-test[:,4])**2))) for k in kinds}
        rows.append({'seed':seed,'validation_rmse':val_scores,'sealed_selection':winner,'test_rmse':test_scores})
    means={k:float(np.mean([r['test_rmse'][k] for r in rows])) for k in kinds}
    selected_mean=float(np.mean([r['test_rmse'][r['sealed_selection']] for r in rows]))
    return {'origin':'CONTROLLED_SYNTHETIC_SIMULATION','protocol':'validation model selection, untouched seed-disjoint test episode','seeds':seeds,
            'mean_test_rmse':means,'mean_test_rmse_validation_selected':selected_mean,
            'wins_over_physics':{k:int(sum(r['test_rmse'][k]<r['test_rmse']['physics'] for r in rows)) for k in kinds},
            'per_seed':rows,'recommendation':'Keep neural residual only if it beats strong symbolic and linear controls; no intrinsic novelty claimed.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--seeds',type=int,default=6);p.add_argument('--out',default='demo/frontier_hybrid.json');a=p.parse_args()
    if not 1<=a.seeds<=64:p.error('seeds must be 1..64')
    report=evaluate(a.seeds);o=Path(a.out);o.parent.mkdir(parents=True,exist_ok=True)
    o.write_text(json.dumps(report,indent=2));print(json.dumps({'out':str(o),'means':report['mean_test_rmse'],'selected':report['mean_test_rmse_validation_selected']}))
if __name__=='__main__':main()
