"""Unified `physica grammar` commands, offline and prospective real data."""
from __future__ import annotations
import argparse,json
from pathlib import Path
from .simulator import showcase,benchmark
from .language import json_schema
from .signals import MechanicalContext
from .field import source_from_manifest,prepare,check,learn_next
from .meta_context import model_status,live_muse_scientist,curate_context_reply


def main(args=None):
    p=argparse.ArgumentParser(prog='physica grammar')
    sub=p.add_subparsers(dest='step',required=True)
    a=sub.add_parser('demo',help='A->B->C cross-modal SYNTHETIC transfer, signed forecasts')
    a.add_argument('--out',default='csg_lab');a.add_argument('--seed',type=int,default=31)
    a.add_argument('--trials',type=int,default=12)
    a=sub.add_parser('benchmark',help='real baselines on synthetic family AND shifted dynamics')
    a.add_argument('--out',default='csg_benchmark.json');a.add_argument('--seed',type=int,default=31)
    a.add_argument('--trials',type=int,default=24)
    a=sub.add_parser('schema',help='PEL v3 JSON Schema');a.add_argument('--out',default='pel_v3.schema.json')
    sub.add_parser('meta-status',help='official-model readiness and live-validation caveats')
    a=sub.add_parser('source',help='ground A from physically calibrated CSV(s) + external local attestation')
    a.add_argument('source_manifest_json');a.add_argument('--out',required=True)
    a=sub.add_parser('prepare',help='commit A->B forecast BEFORE B is measured; target grid has times only')
    a.add_argument('signed_source_word');a.add_argument('target_body_json');a.add_argument('target_times_csv')
    a.add_argument('--modality',required=True);a.add_argument('--observable',required=True)
    a.add_argument('--out',required=True)
    a=sub.add_parser('check',help='verify signed B commitment, then open B response CSV')
    a.add_argument('signed_prediction');a.add_argument('observed_response_csv')
    a.add_argument('--si-per-raw-unit',type=float,required=True)
    a.add_argument('--si-sigma',type=float,required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('learn-next',help='B confirmed response -> signed B physical language word for C')
    a.add_argument('signed_B_reveal');a.add_argument('B_channel_spec_json')
    a.add_argument('--action-id',required=True);a.add_argument('--hypothesis',required=True)
    a.add_argument('--out',required=True)
    a=sub.add_parser('cirte-mechanism',help='discover heldout-tested residual physical mechanisms from calibrated x,v,a,F')
    a.add_argument('interventions_json');a.add_argument('--out',required=True)
    a=sub.add_parser('cirte-meta-mechanism-live',help='REAL billable Muse Spark+Wonder contextual discovery, with independent heldout test')
    a.add_argument('interventions_json');a.add_argument('video_path');a.add_argument('--out',required=True)
    a.add_argument('--allow-billed-meta',action='store_true')
    a=sub.add_parser('cirte-benchmark',help='v0.5 cross-sensory selective transfer and unknown-mechanism simulation')
    a.add_argument('--out',default='cirte_benchmark.json');a.add_argument('--seed',type=int,default=50);a.add_argument('--trials',type=int,default=24)
    a=sub.add_parser('cirte-source',help='A: native physical sensor CSV + independently calibrated observation operators')
    a.add_argument('manifest_json');a.add_argument('--out',required=True)
    a=sub.add_parser('cirte-prepare',help='A experience + B calibrated sensor/probe -> B forecast sealed BEFORE main CSV')
    a.add_argument('source_json');a.add_argument('body_json');a.add_argument('sensor_json');a.add_argument('time_grid_csv');a.add_argument('low_force_probe_json');a.add_argument('--out',required=True)
    a=sub.add_parser('cirte-check',help='B: verify sealed forecast then compare native-sensor response')
    a.add_argument('signed_prediction_json');a.add_argument('measured_native_csv');a.add_argument('--out',required=True)
    a=sub.add_parser('cirte-learn-next',help='B signed outcome -> new B PEL source for C')
    a.add_argument('signed_reveal_json');a.add_argument('measured_native_csv');a.add_argument('--action-id',required=True);a.add_argument('--hypothesis',required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('cirte-plan',help='v0.5 Bayesian EIG and grounded Meta hints; offline when no live flag')
    a.add_argument('request_json');a.add_argument('--meta-reply-json');a.add_argument('--out',required=True)
    a=sub.add_parser('cirte-meta-plan-live',help='actual paid Muse Spark+Wonder proposals; NO permission to actuate')
    a.add_argument('request_json');a.add_argument('video_path');a.add_argument('--out',required=True)
    a.add_argument('--allow-billed-meta',action='store_true')
    a=sub.add_parser('cirte-meta-ablation',help='evaluate user-supplied, actual authenticated held-out paired Meta outputs')
    a.add_argument('baseline_json');a.add_argument('meta_json');a.add_argument('--out',required=True)
    a=sub.add_parser('research-benchmark',help='v0.4.3 prospective identifiability + shift simulation');a.add_argument('--out',default='frontier_v043.json');a.add_argument('--seed',type=int,default=43);a.add_argument('--trials',type=int,default=32)
    a=sub.add_parser('audio-audit',help='measure WAV timing/spectrum; no uncalibrated force guesses');a.add_argument('wav');a.add_argument('--out',required=True)
    a=sub.add_parser('chemistry-audit',help='calibrated chemistry CSV response kinetics, not molecule ID');a.add_argument('chemical_manifest_json');a.add_argument('--out',required=True)
    a=sub.add_parser('discover',help='propose an identifiable supervised experiment from mechanism candidates')
    a.add_argument('mechanism_json');a.add_argument('--out',required=True)
    a=sub.add_parser('world-fit',help='fit held-out SI physical readout from exported latent .npz (not model inference)')
    a.add_argument('datasets_npz');a.add_argument('--model-id',required=True)
    a.add_argument('--observable',required=True);a.add_argument('--unit',required=True)
    a.add_argument('--out',required=True)
    a=sub.add_parser('world-predict',help='apply calibrated readout to disjoint latent embeddings')
    a.add_argument('calibration_json');a.add_argument('test_npz');a.add_argument('--out',required=True)
    a=sub.add_parser('meta-csg-live',help='LIVE Spark+SAM+Wonder; crosschecked SAM becomes a CSG sensor; seal B')
    a.add_argument('source_manifest_json');a.add_argument('source_video')
    a.add_argument('target_body_json');a.add_argument('target_times_csv')
    a.add_argument('--reference-csv',required=True)
    a.add_argument('--concept',required=True);a.add_argument('--track-id',type=int,default=0)
    a.add_argument('--meters-per-pixel',type=float,required=True);a.add_argument('--fps',type=float,required=True)
    a.add_argument('--crosscheck-rmse-m',type=float,required=True)
    a.add_argument('--camera-sigma-m',type=float,required=True)
    a.add_argument('--allowed',nargs='+',required=True);a.add_argument('--out',required=True)
    a.add_argument('--allow-billed-meta',action='store_true')
    a=sub.add_parser('meta-context-live',help='explicit live authenticated Muse scientific critique')
    a.add_argument('grounded_facts_json');a.add_argument('--video')
    a.add_argument('--role',choices=('spark','wonder'),default='wonder')
    a.add_argument('--allowed',nargs='*',default=[])
    a.add_argument('--candidates',nargs='*',default=[])
    a.add_argument('--out',required=True)
    opts=p.parse_args(args)
    if opts.step=='demo':
        result=showcase(opts.out,seed=opts.seed,n=opts.trials)
    elif opts.step=='benchmark':
        result=benchmark(opts.seed,opts.trials);Path(opts.out).write_text(json.dumps(result,indent=2)+'\n')
    elif opts.step=='schema':
        result=json_schema();Path(opts.out).write_text(json.dumps(result,indent=2)+'\n')
    elif opts.step=='meta-status':result=model_status()
    elif opts.step=='cirte-mechanism':
        from .mechanism_lab import discover_residual_mechanism
        req=json.loads(Path(opts.interventions_json).read_text())
        result=discover_residual_mechanism(req['train'],req['validation'],**req['physics'],
            candidates=req.get('allowed_mechanisms'))
        Path(opts.out).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    elif opts.step=='cirte-meta-mechanism-live':
        from .meta_mechanism import live_meta_mechanism
        req=json.loads(Path(opts.interventions_json).read_text())
        result=live_meta_mechanism(req['train'],req['validation'],req['physics'],
            video_path=opts.video_path,allow_billing=opts.allow_billed_meta)
        Path(opts.out).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    elif opts.step=='cirte-benchmark':
        from .cirte_benchmark import write
        result=write(opts.out,seed=opts.seed,n=opts.trials)
    elif opts.step=='cirte-source':
        from .cirte_field import source_from_native_manifest
        result=source_from_native_manifest(opts.manifest_json,opts.out)
    elif opts.step=='cirte-prepare':
        from .cirte_field import prepare_native
        result=prepare_native(opts.source_json,opts.body_json,opts.sensor_json,opts.time_grid_csv,opts.low_force_probe_json,opts.out)
    elif opts.step=='cirte-check':
        from .cirte_field import check_native
        result=check_native(opts.signed_prediction_json,opts.measured_native_csv,opts.out)
    elif opts.step=='cirte-learn-next':
        from .cirte_field import learn_next_native
        result=learn_next_native(opts.signed_reveal_json,opts.measured_native_csv,opts.out,
                                 action_id=opts.action_id,causal_hypothesis=opts.hypothesis)
    elif opts.step=='cirte-plan':
        from .meta_cirte import grounded_plan
        req=json.loads(Path(opts.request_json).read_text())
        hints=json.loads(Path(opts.meta_reply_json).read_text()) if opts.meta_reply_json else None
        result=grounded_plan(req,meta_reply=hints,meta_calibration_counts=req.get('independent_meta_calibration_counts'))
        Path(opts.out).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    elif opts.step=='cirte-meta-plan-live':
        from .meta_cirte import live_grounded_plan
        req=json.loads(Path(opts.request_json).read_text())
        result=live_grounded_plan(req,video_path=opts.video_path,allow_billing=opts.allow_billed_meta,
                  meta_calibration_counts=req.get('independent_meta_calibration_counts'))
        Path(opts.out).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    elif opts.step=='cirte-meta-ablation':
        from .meta_ablation import evaluate_files
        result=evaluate_files(opts.baseline_json,opts.meta_json,opts.out)
    elif opts.step=='research-benchmark':
        from .frontier_benchmark import write
        result=write(opts.out,seed=opts.seed,n=opts.trials)
    elif opts.step=='audio-audit':
        from .sensor_audio import inspect_wav
        result=inspect_wav(opts.wav);Path(opts.out).write_text(json.dumps(result,indent=2)+'\n')
    elif opts.step=='chemistry-audit':
        from .signals import Channel
        from .chemical import chemical_step_response
        from .field import read_timeseries
        spec=json.loads(Path(opts.chemical_manifest_json).read_text())
        channels=[]
        for ch in spec['channels']:
            t,raw,h=read_timeseries(ch['csv'])
            gain=float(ch['si_per_raw_unit'])
            if not __import__('math').isfinite(gain) or gain<=0:raise ValueError('invalid calibration')
            channels.append(Channel(sensor_id=ch['sensor_id'],modality=ch['modality'],
                observable=ch['observable'],time_s=tuple(t),values=tuple(raw*gain),
                unit=ch['canonical_unit'],sigma=float(ch['si_sigma']),
                calibration_id=ch['calibration_id'],body_id=spec['body_id'],
                raw_unit=ch['raw_unit'],conversion_gain=gain,
                origin=ch['origin'],source_sha256=h))
        result=chemical_step_response(channels,step_at_s=float(spec['step_at_s']),
            observable=spec['observable'])
        Path(opts.out).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    elif opts.step=='discover':
        from .discovery import SafeProbe,probe_options,calibrated_meta_prior
        spec=json.loads(Path(opts.mechanism_json).read_text())
        candidates={k:MechanicalContext(**v) for k,v in spec['hypotheses'].items()}
        probes=[SafeProbe(**p) for p in spec['probes']]
        priors=spec['priors']
        context=calibrated_meta_prior(priors,spec.get('meta_candidate_hints',[]),
            calibration_counts=spec.get('meta_heldout_calibration'))
        result=probe_options(context['prior'],candidates,probes,spec['times_s'],
            max_risk=float(spec.get('max_risk',.12)),max_force_n=spec.get('max_force_n'))
        result['context_weighting']=context
        Path(opts.out).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    elif opts.step=='world-fit':
        import numpy as np
        from dataclasses import asdict
        from .world_readout import fit_readout
        with np.load(opts.datasets_npz,allow_pickle=False) as data:
            model=fit_readout(data['train_x'],data['train_y'],data['cal_x'],data['cal_y'],
                train_body_ids=[str(x) for x in data['train_ids']],
                cal_body_ids=[str(x) for x in data['cal_ids']],
                model_id=opts.model_id,observable=opts.observable,unit=opts.unit)
        result=asdict(model)
        Path(opts.out).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    elif opts.step=='world-predict':
        import numpy as np
        from .world_readout import CalibratedReadout
        model=CalibratedReadout(**json.loads(Path(opts.calibration_json).read_text()))
        with np.load(opts.test_npz,allow_pickle=False) as data:
            result={'forecasts':model.predict(data['test_x'],body_ids=[str(x) for x in data['test_ids']]),
                    'warning':'Model embeddings must originate from independently run world model; no inference or hardware actuation here'}
        Path(opts.out).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    elif opts.step=='source':result=source_from_manifest(opts.source_manifest_json,opts.out)
    elif opts.step=='prepare':result=prepare(opts.signed_source_word,opts.target_body_json,
        opts.target_times_csv,opts.out,modality=opts.modality,observable=opts.observable)
    elif opts.step=='check':result=check(opts.signed_prediction,opts.observed_response_csv,opts.out,
        si_per_raw_unit=opts.si_per_raw_unit,si_sigma=opts.si_sigma)
    elif opts.step=='learn-next':result=learn_next(opts.signed_B_reveal,opts.B_channel_spec_json,
        opts.out,action_id=opts.action_id,causal_hypothesis=opts.hypothesis)
    elif opts.step=='meta-csg-live':
        from .meta_csg import run
        result=run(opts.source_manifest_json,opts.source_video,opts.target_body_json,
           opts.target_times_csv,out_dir=opts.out,concept=opts.concept,
           track_id=opts.track_id,meters_per_pixel=opts.meters_per_pixel,fps=opts.fps,
           reference_csv=opts.reference_csv,
           max_crosscheck_rmse_m=opts.crosscheck_rmse_m,
           camera_sigma_m=opts.camera_sigma_m,allowed_actions=opts.allowed,
           explicit_bill_permission=opts.allow_billed_meta)
    elif opts.step=='meta-context-live':
        facts=json.loads(Path(opts.grounded_facts_json).read_text())
        model=live_muse_scientist(facts,opts.allowed,video_path=opts.video,role=opts.role)
        import hashlib
        media_hash=hashlib.sha256(Path(opts.video).read_bytes()).hexdigest() if opts.video else hashlib.sha256(Path(opts.grounded_facts_json).read_bytes()).hexdigest()
        result={'model':model,'candidate_context':curate_context_reply(model['reply'],
             candidate_labels=opts.candidates,allowed_actions=opts.allowed,evidence_hash=media_hash)}
        Path(opts.out).write_text(json.dumps(result,indent=2)+'\n')
    else:raise AssertionError('unreachable')
    print(json.dumps(result,indent=2))
    return result


if __name__=='__main__':main()
