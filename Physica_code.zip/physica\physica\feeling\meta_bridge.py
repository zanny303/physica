"""Move real SAM pixels into a calibrated *candidate* physical measurement.

A visual segmentation is not a force measurement. Requires independently
measured pixel scale, synchronized clock, fixed-reference object tracking, and
independently established motion-noise floor; no uncalibrated numbers from Muse.
"""
from __future__ import annotations
import hashlib
import math
import numpy as np
from .core import Sense


def sam_tracks_to_calibrated_camera(sam_tracks,*,moving_object_id,reference_object_id,
                                    meters_per_pixel,frames_per_second,displacement_noise_std_m,
                                    calibration_id,recording_sha256):
    vals=(meters_per_pixel,frames_per_second,displacement_noise_std_m)
    if not all(math.isfinite(float(v)) and v>0 for v in vals):
        raise ValueError('non-finite or missing physical calibration')
    if not isinstance(calibration_id,str) or not calibration_id.strip():
        raise ValueError('independent calibration identifier required')
    if len(recording_sha256)!=64 or any(c not in '0123456789abcdef' for c in recording_sha256):
        raise ValueError('source video evidence digest required')
    traces={}
    for objid in (moving_object_id,reference_object_id):
        matches=[r for r in sam_tracks if r.get('object_id')==objid]
        if len(matches)<8 or len(set(int(r['frame']) for r in matches))!=len(matches):
            raise ValueError('incomplete or duplicated part/reference video tracks')
        tracks={int(r['frame']):float(r['y_center_px']) for r in matches}
        if not all(math.isfinite(v) for v in tracks.values()):raise ValueError('nonfinite tracking coordinate')
        traces[objid]=tracks
    if moving_object_id==reference_object_id:raise ValueError('moving and static reference cannot be same object')
    common=sorted(set(traces[moving_object_id])&set(traces[reference_object_id]))
    if len(common)<8:raise ValueError('insufficient synchronized tracks')
    rel=np.asarray([traces[moving_object_id][i]-traces[reference_object_id][i] for i in common])
    times=np.asarray(common,dtype=float)/frames_per_second
    displacement=(rel-rel[0])*meters_per_pixel
    # Not an independent velocity sensor: differentiated visual motion would
    # amplify tracking errors and must not be presented as separate evidence.
    sensor=Sense('sam_camera','sight','m',(1.,0.),0.,displacement_noise_std_m,
                 calibration_id,calibration_origin='independent_fixture')
    return {'schema':'physica.sam-calibrated-sensation.v1',
            'sensor':sensor,'times_s':times-times[0],
            'displacement_m':displacement,
            'video_sha256':recording_sha256,
            'origin':'SAM_boxes_plus_independent_camera_scale',
            'calibration_id':calibration_id,
            'independent_test_required':True,
            'limitation':'reference tracking does not correct depth/perspective distortion or unknown rolling shutter'}


def live_meta_feeling_analysis(video_path,*,allow_billing=False,sam_concept=None,
                               moving_object_id=None,reference_object_id=None,
                               meters_per_pixel=None,frames_per_second=None,
                               displacement_noise_std_m=None,calibration_id=None):
    """Real, paid Spark + Wonder + optional SAM candidate-sensing pipeline.

    Returns a scene-bound *candidate*, not an observed physical consequence.
    SAM geometry requires an independently measured fixed-reference scale;
    model-written numeric measurements are never trusted. The caller must
    still use held-out physical interventions and source-specific calibrations.
    """
    if not allow_billing:
        raise PermissionError('explicit --allow-billed-meta required; no mocked model output')
    # Fail *before billing* if requested SAM geometry lacks an independent
    # scale, clock and reference part.
    if sam_concept and any(x is None for x in (moving_object_id,reference_object_id,
             meters_per_pixel,frames_per_second,displacement_noise_std_m,calibration_id)):
        raise ValueError('SAM requires moving/reference IDs and independently calibrated geometry')
    from pathlib import Path
    from physica.experience.meta_live import muse_scientist
    from .context import contextual_hypotheses,REGISTRY
    path=Path(video_path)
    if not path.is_file():raise FileNotFoundError(path)
    scene_sha=hashlib.sha256(path.read_bytes()).hexdigest()
    # Video input is OBSERVED PRE-INTERVENTION context. Do not send any heldout
    # test outcomes or ground-truth physical values to the scientist.
    known={'scene_sha256':scene_sha,'allowed_physical_mechanisms':list(REGISTRY),
           'question':'Which physical contact interaction or boundary condition may matter?',
           'do_not_invent_calibration_or_numerical_physical_measurements':True,
           'no_authority_to_actuate':True,'heldout_experiment_outcomes_withheld':True}
    spark=muse_scientist(known,[],role='spark',video_path=str(path))
    wonder=muse_scientist({**known,'spark_scene_context':spark['reply']},[],role='wonder',video_path=str(path))
    proposals=contextual_hypotheses({**wonder['reply'],'scene_sha256':scene_sha,
                      'model_id':wonder['model_id']},scene_sha256=scene_sha)
    calibrated_geometry=None;sam_metadata=None
    if sam_concept:
        if any(x is None for x in (moving_object_id,reference_object_id,meters_per_pixel,
                   frames_per_second,displacement_noise_std_m,calibration_id)):
            raise ValueError('SAM sensing requires reference track and independent scale, fps, noise')
        from physica.grammar.meta_sam_official import sam_video_official
        sam=sam_video_official(path,concept=sam_concept)
        calibrated_geometry=sam_tracks_to_calibrated_camera(sam['boxes'],
             moving_object_id=moving_object_id,reference_object_id=reference_object_id,
             meters_per_pixel=meters_per_pixel,frames_per_second=frames_per_second,
             displacement_noise_std_m=displacement_noise_std_m,
             calibration_id=calibration_id,recording_sha256=scene_sha)
        # JSON serializable; no raw image/pixel transformations discarded.
        calibrated_geometry={**calibrated_geometry,
            'sensor':__import__('dataclasses').asdict(calibrated_geometry['sensor']),
            'times_s':calibrated_geometry['times_s'].tolist(),
            'displacement_m':calibrated_geometry['displacement_m'].tolist()}
        sam_metadata={'model_id':sam['model_id'],'video_sha256':sam['video_sha256'],
                      'parser_diagnostics':sam['parser_diagnostics']}
    return {'status':'LIVE_META_CONTEXT_NOT_PHYSICAL_VALIDATION',
            'source_scene_sha256':scene_sha,
            'spark_model_id':spark['model_id'],'wonder_model_id':wonder['model_id'],
            'spark_response':spark['reply'],'wonder_response':wonder['reply'],
            'candidate_mechanisms':proposals,'sam_metadata':sam_metadata,
            'calibrated_sam_sensation':calibrated_geometry,
            'requires_independent_intervention_validation':True,
            'hardware_actuation_allowed':False}
