# v0.12 — Discovery Observatory & Live Sensing

Built on uploaded Physica v0.11. All earlier modules and their non-performance disclaimers remain.

- Fixed `field-evaluate --nomination` argparse crash.
- Added `physica.mace.unknown_physics`: deterministic restricted feature grammar, strong no-lockbox-leakage condition, two validation episodes, identifiability checks, explicit abstention, and an all-feature ridge baseline tuned on the same evidence.
- Added `discover-unknown` CLI for synthetic reproducible showcase or source-controlled real CSV manifest. Writes an interactive lockbox waveform report for the synthetic path.
- Added a darker evidence observatory to the Studio opening screen, animated signals explicitly labelled illustration, and one-click genuine workflow launchers.
- Added browser-only live webcam ROI pixel-motion monitor with background comparison. Never labels these signals as force, temperature, mass, chemical exposure, diagnosis or calibrated displacement.
- Added a separate optional, explicit, one-shot billed live Muse request to Studio. It receives only aggregate **synthetic** source metrics, proposes a strictly validated term, and outputs a no-Meta vs Meta experiment. Authentication has not been executed in this environment.
- Added a supported `MACE v0.12 field discovery` task for user-supplied manifest, and preserved strict user approval for hardware / Meta usage.
- Tests: new dedicated v0.12 regression suite plus previous v0.11, MACE, Studio and feeling modules. Research effects are simulation and must not be presented as discoveries.

Read [`docs/V012_DISCOVERY_AND_STUDIO.md`](docs/V012_DISCOVERY_AND_STUDIO.md).
