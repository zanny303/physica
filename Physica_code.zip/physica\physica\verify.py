"""physica verify: a one-minute self-check a judge can run with no data, no key and no network.

Each line is a claim Physica's demo relies on, checked from scratch on this machine. The full test suite
(python -m pytest) and the eval scripts (eval/e*.py, real data) go further.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def _checks():
    from physica import seal
    from physica.cause import discover as D
    from physica.cause import intervene as I
    from physica.cause import transfer as X
    from physica.cause.fe import Beam, eig
    from physica.cause.track import track_tone

    def fe_textbook():
        lam = eig(60, 3)
        ok = abs(lam[0] - 1.8751 ** 2) / 1.8751 ** 2 < 1e-3 and abs(lam[1] / lam[0] - 6.267) < 0.01
        return ok, f"clamped beam eigenvalues {lam[0]:.4f}, ratio {lam[1] / lam[0]:.3f} (textbook 3.5160, 6.267)"

    def rayleigh():
        b = Beam(0.25, 0.025, 0.001)
        f0 = b.bare(1)[0]
        fm = b.freqs(1, masses=[(0.7, 0.2)])[0]
        fs = b.freqs(1, springs=[(0.5, 1e4)])[0]
        fc = b.freqs(1, clamp_rot=2.0)[0]
        return fm < f0 < fs and fc < f0, f"bare {f0:.2f} Hz; +mass {fm:.2f}; +support {fs:.2f}; loose clamp {fc:.2f}"

    def tracker():
        fs = 2000.0
        t = np.arange(0, 6, 1 / fs)
        f = 40 + 20 * (t > 3)
        ph = 2 * np.pi * np.cumsum(f) / fs
        x = np.sin(ph) * (0.6 + 0.4 * np.cos(2 * np.pi * 0.7 * t)) + np.random.default_rng(0).normal(0, 0.05, len(t))
        T, tone = track_tone(x, fs, (20, 120), lag_s=0.2)
        e = np.abs(tone - np.interp(T, t, f)) / np.interp(T, t, f)
        k = np.abs(T - 3) > 0.4
        return float(np.nanmedian(e[k])) < 0.01, f"median tone error {100 * np.nanmedian(e[k]):.2f}% across a 40->60 Hz jump"

    def cause():
        b = Beam(0.35, 0.05, 0.006, tip_mass_kg=0.05)
        xs = np.linspace(0.1, 0.45, 80)
        f1 = np.array([b.freqs(1, springs=[(x, 1e5)])[0] for x in xs]) * np.exp(np.random.default_rng(1).normal(0, 0.003, 80))
        r = D.discover(b, f1)
        err = np.nanmedian(np.abs(r["where_mm"] - xs * 350))
        return r["verdict"]["cause"] == "support" and err < 6, f"cause '{r['verdict']['cause']}', located within {err:.1f} mm median"

    def sealing():
        s = seal.seal({"intervals": {"tone1_hz": [10, 11]}}, "check")
        ok1 = seal.reveal(s, {"tone1_hz": 10.5}, seal.interval_grade)["held"]
        s["payload"]["prediction"]["intervals"]["tone1_hz"] = [0, 99]
        r = seal.reveal(s, {"tone1_hz": 50}, seal.interval_grade)
        return ok1 and r["verdict"].startswith("INVALID"), "an edited seal is refused: " + r["verdict"][:40]

    def cards():
        b = Beam(0.35, 0.05, 0.006, tip_mass_kg=0.05)
        xs = np.linspace(0.1, 0.45, 40)
        f1 = np.array([b.freqs(1, springs=[(x, 1e5)])[0] for x in xs])
        r = D.discover(b, f1)
        eb = X.calibrate_error(r["where_mm"], xs * 350, b.length)
        c = X.explanation_card(b, r, {"band_over_bare": [0.5, 3], "win_s": 0.3, "hop_s": 0.05}, eb,
                               {"tone_over_bare_5_95": [1.1, 2.0]}, {"dataset": "verify"})
        env = X.envelope(c)
        good = X.receive(env)["intact"]
        env["card"]["payload"]["cause"] = "mass"
        bad = X.receive(env)["intact"]
        return good and not bad, "explanation card verifies; an altered one is rejected"

    def experiment():
        b = Beam(0.25, 0.025, 0.001, n_el=30)
        inv = I.Investigation(b, 0.1, H=I.hypotheses(np.linspace(0.1, 0.9, 9), (0.1, 0.3), (0.4, 0.7)))
        truth = ("mass", 0.6, 0.3)
        inv.observe(I.tones(b, truth, None))
        iv, menu = inv.next_experiment(np.random.default_rng(0))
        s = inv.promise(iv)
        felt = I.tones(b, truth, None if iv.kind == "again" else iv)
        rv = seal.reveal(s, {f"tone{k + 1}_hz": v for k, v in enumerate(felt)}, seal.interval_grade)
        return rv["held"] and inv.belief()["cause"] == "mass", f"chose '{iv.say()}', promise {rv['verdict']}"

    def scientist():
        os.environ.setdefault("MOCK", "1")
        from physica.meta import scientist as S
        b = Beam(0.25, 0.025, 0.001, n_el=30)
        k = np.geomspace(2000, 0.6, 80)
        F = np.array([b.freqs(2, clamp_rot=kk) for kk in k])
        t = S.test(b, F[:, 0], F[:, 1], {"name": "loose clamp", "part": "clamp", "place": [0, 0], "strength": [0.3, 3000]})
        w = S.test(b, F[:, 0], F[:, 1], {"name": "warming", "part": "uniform", "place": [0, 0], "strength": [0.5, 1.0]})
        return t["explained_second_half_pct"] > 90 > w["explained_second_half_pct"], (
            f"held-out judge: loose clamp {t['explained_second_half_pct']:.0f}%, warming {w['explained_second_half_pct']:.0f}%")

    def meta_client():
        from physica.llm import meta_client as mc
        st = mc.status()
        return st["endpoint"].startswith("https://api.meta.ai") or bool(os.environ.get("MODEL_API_BASE")), (
            f"mode {st['mode']}, models {st['models']['spark']} / {st['models']['wonder']} / {st['models']['sam']}, hard stop ${st['hard_stop_usd']:.0f}")

    def sam_parser():
        from physica.meta.sam import object_boxes, parse_sam_text
        f = parse_sam_text("<0f>0<|box;x1=1;y1=2;x2=30;y2=40;w=320;h=240|><|mask;x=0;y=0;data=3,4,~ab|>,1<|box;x1=5;y1=5;x2=9;y2=9;w=320;h=240|><1f>0<|box;x1=2;y1=2;x2=31;y2=40;w=320;h=240|>")
        return len(f) == 2 and len(object_boxes(f)) == 2, "SAM 3.1 text records -> 2 frames, 2 objects"

    def mace_range():
        from physica.mace_x.benchmark import task
        from physica.mace_x.core import calibrated_rows, fit_target, predict
        t = task(1234)
        rows = calibrated_rows([t["reveal"](i) for i in range(4)], t["calibration"])
        p = predict(fit_target(rows, t["memory"], target_id=t["target_id"]), [dict(x=0.3, v=-0.2, u=0.5), dict(x=50, v=-40, u=30)])
        return bool(np.isfinite(p["mean"][0]) and np.isnan(p["mean"][1])), "MACE-X answers in range, refuses x=50 (source saw about +-1)"

    def live():
        from physica.studio.front import LiveSensor
        fs, n = 30.0, 180
        tt = np.arange(n) / fs
        x = np.exp(-0.2 * tt) * np.cos(2 * np.pi * 4.0 * tt) * (tt > 0.7)
        Y = np.outer(x, np.linspace(0.1, 1, 8) ** 2) * 5
        r = LiveSensor().analyze({"t": (tt * 1000).tolist(), "y": Y.tolist()})
        return abs(r.get("tone_hz", 0) - 4.0) < 0.1, f"webcam-rate sensing: {r.get('tone_hz')} Hz for a 4.00 Hz flick"

    return [("Beam physics matches the textbook", fe_textbook), ("One-way rules (Rayleigh) hold", rayleigh),
            ("Tone tracker follows a changing body", tracker), ("Finds the hidden cause and where it is", cause),
            ("Sealed predictions can't be edited", sealing), ("Explanations travel signed", cards),
            ("Chooses an experiment and keeps its promise", experiment), ("New causes judged on unseen data", scientist),
            ("One Meta client, verified model IDs", meta_client), ("SAM 3.1 output parser", sam_parser),
            ("MACE-X refuses to extrapolate", mace_range), ("Live webcam sensing", live)]


def results_summary():
    out = []
    p = ROOT / "eval" / "results"
    for name, f in (("E26 drop anything in", "E26_sense_anything.json"),
                    ("E25 deliberate to discover", "E25_deliberate_discover.json"),
                    ("E23 program by outcome (real beam + real toolchains)", "E23_program_by_outcome.json"),
                    ("E20 wind blade (real)", "E20_wind_blade.json"), ("E22 retune a beam (real check)", "E22_retune_beam.json"),
                    ("E16 real beams", "E16_hidden_cause.json"), ("E17 experiments (sim)", "E17_active_experiments.json"),
                    ("E18 new causes (sim)", "E18_new_cause.json"), ("E19 propose & judge", "E19_evolve_sense.json")):
        q = p / f
        if not q.exists():
            out.append(f"  {name}: not generated yet")
            continue
        d = json.loads(q.read_text())
        if f.startswith("E26"):
            g = d.get("guitar_check", {})
            fan = d.get("fan_SIMULATED", {})
            out.append(f"  {name}: " + ", ".join(f"{r['label'].split(' (')[0]} -> {r['identified']['template']}" for r in d["runs"]
                                               if "identified" in r)
                       + f"; guitar notes {g.get('notes_named')}; fan (sim) wobble drop "
                       f"{fan.get('check', {}).get('wobble_drop_fraction', 0):.0%}")
            continue
        if f.startswith("E24"):
            h, a = d["feel_check_held_out_laps"], d["advice_summary"]
            out.append(f"  {name}: held-out lap error {h['physica']['lap_time_error_s_median']} s (generic F1 car "
                       f"{h['generic_f1']['lap_time_error_s_median']} s); lap-time promises held in TUM "
                       f"{a['lap_time_promises_held']}/{a['test_cars_graded']}")
            continue
        if f.startswith("E25"):
            out.append(f"  {name}: {d['best_law_text']} -> unseen cars {d['test_accuracy']:.0%} ({d['proposer'][:40]})")
            continue
        if f.startswith("E23"):
            P, N = d["A_beam"]["policies"]["physica"], d["A_beam"]["policies"]["no_error_bar"]
            a, n = P["goals_met_by_status"].get("act", [0, 0]), N["goals_met_by_status"].get("act", [0, 0])
            tools = [d["A_beam"]["machine_code"]["klipper_plan"], d["B_turbine"]["plc"]["compile"], d["C_drone"]["flight"]]
            out.append(f"  {name}: moves that worked {a[0]}/{a[1]} (no error bars {n[0]}/{n[1]}); promises held "
                       f"{P['sealed_promises_held']:.0%}; Klipper/matiec/ArduPilot "
                       + "/".join("pass" if t.get("passed") else ("not run" if not t.get("ran") else "FAIL") for t in tools))
            continue
        if f.startswith("E20"):
            sc = d["score"]
            out.append(f"  {name}: false alarms {sc['healthy_false_alarm']:.0%} vs temperature-blind "
                       f"{d['baseline_temperature_blind']['healthy_false_alarm']:.0%}; ice {d['ice_grams'].get('B')} g for 88 g; "
                       f"cracked blades restarted {d['act_refeel']['restarted_with_a_crack']}")
            continue
        if f.startswith("E22"):
            out.append(f"  {name}: {d['held']} of {d['checked']} checkable action promises held")
            continue
        if f.startswith("E16"):
            c = d["A"]["comparison_same_recording"]
            out.append(f"  {name}: {c['physica_live']['median']:.2f} mm median vs published {c['published_model_updating_downey2020']['median']:.2f} mm; "
                       f"B zero-label r={d['B']['zero_labels_correlation']:.2f}")
        elif f.startswith("E17"):
            out.append(f"  {name}: right cause {', '.join(f'{k} {v['right_cause']:.0%}' for k, v in d['policies'].items())}")
        elif f.startswith("E18"):
            out.append(f"  {name}: " + "; ".join(f"{k}: {(v.get('verdict') or 'built-in')[:46]}" for k, v in d["cases"].items()))
        else:
            c = d["search"].get("champion") or {}
            out.append(f"  {name}: {d['search']['proposals']} proposals by {d['proposer'][:30]}; champion A {c.get('prove_A_mm', 0):.2f} / B {c.get('travel_B_mm') or 0:.2f} mm "
                       f"vs Physica {d['physica_current_sense']['prove_A_mm']:.2f} / {d['physica_current_sense']['travel_B_mm']:.2f}")
    return out


def main(argv=None):
    os.environ.setdefault("MOCK", "1")
    sys.path.insert(0, str(ROOT))
    t0 = time.time()
    fails = 0
    print("physica verify: claims checked from scratch on this machine\n")
    for name, fn in _checks():
        t = time.time()
        try:
            ok, detail = fn()
        except Exception as e:  # a crash is a failure, shown plainly
            ok, detail = False, f"{type(e).__name__}: {e}"
        fails += not ok
        print(f"  {'PASS' if ok else 'FAIL'}  {name:44s} {detail}  ({time.time() - t:.1f} s)")
    print("\nSaved results (eval/results, real data where marked):")
    print("\n".join(results_summary()))
    print(f"\n{'ALL PASS' if not fails else f'{fails} FAILED'} in {time.time() - t0:.0f} s. Advice, not a safety certification.")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
