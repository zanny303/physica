# Physica v0.4.2 — Causal Sensory Grammar (CSG)

**STATUS: implemented engineering/research prototype. NOT a proven new scientific algorithm, universal five-sense representation, autonomous robot, or hackathon winner.** This release extends, rather than replaces, Feel/Touch Transform, Body Map, Order Feel, PACER, CRATE, the signed Body Bank, real-beam data, the camera-scale experiment, printer tuner, drone examples, and existing field protocols.

## One-sentence thesis

A physical experience is not a word or a pixel embedding. It is a *conditional intervention→response relationship* with calibrated units, uncertainty, causal alternatives, and an explicit domain of validity. Physica seeks to carry that relationship between machines **and their different senses**.

A speaks through a microphone and accelerometer; B receives a predicted *visual displacement* on a differently calibrated structure; B tests the prediction; C receives a new physical lesson. The current offline demonstration simulates all three machines. The real experiment must still be done.

## What is new in the actual code

- `physica/grammar/signals.py`: six sensory types; strict canonical units, calibration IDs, raw recording hashes, monotonic timestamps, overlap checks and explicit UNKNOWN/refusal. Sight/hearing/touch/proprioception have supported mechanical observation operators. Smell and taste have typed chemical measurements but **no invented vibration→chemical translator**.
- `physica/grammar/fusion.py`: continuous-time mass-spring-damper model, discretized linear dynamics, sequential Kalman filtering of *calibrated* displacement/velocity/acceleration, unexpected-innovation diagnostics, alternative-hypothesis likelihood ranking and normalized physical event tokens. If a measurement conflicts by >5 standard deviations with the current linear model, it is withheld from the state update but **retained as a flagged discrepancy**. This heuristic has no measured real-world false-rejection rate.
- `physica/grammar/signal_lab.py`: STFT, time-localized Morlet wavelet energy/bursts and cross-channel coherence with explicit warnings that spectral features/correlation do not establish causation. All are **established methods**; not claimed as newly invented transforms.
- `physica/grammar/language.py`: versioned PEL 3.0 typed Pydantic JSON schema, canonical hash, evidence sources, modality lists, source body, boundary/action constraints, normalized time/response/uncertainty, refusals for incompatible bodies, missing calibration, unsupported modalities and extrapolation. Derivative-based velocity/acceleration forecasts are specifically marked uncalibrated, because differentiating a spline amplifies noise.
- `physica/grammar/meta_context.py`: Muse hypotheses are restricted to a whitelist and cannot modify physical measurements, update probabilities without calibration, authorize an actuator, or write measurements.
- `physica/grammar/meta_csg.py`: **optional live, billed** Spark→SAM→Wonder→CSG→PEL→signed-B bridge. It requires the owner to provide Meta credentials locally, an independently calibrated camera scale, a synchronized *independent displacement reference*, an explicit experiment manifest, a source attestation and an acceptable SAM/reference cross-check. Only then does SAM optical geometry become a numerical `vision` channel in CSG. This path has **not been live-tested without owner credentials/media**.
- `physica/grammar/field.py`: a real-file prospective path: signed A source → B times-only signed forecast → B separately acquired observation → signed reveal → B experience → prepare C. Source measurement timestamps and units must come from calibration; target B data is prohibited in `prepare` input.
- `physica/grammar/simulator.py`: a runnable **synthetic-only** A→B→C demo and baseline/stress benchmark. It signs local predictions before internally generating target outcomes. This chronology is **not independently witnessed** and offers no evidence of real-world success.
- `physica/grammar/cli.py`: complete CLI and JSON schema exporter.

### The mathematical mechanism

For a calibrated mechanical body, start with

`x'' + 2 ζ ω x' + ω² x = F / m + d(t)`

The current CSG Kalman filter **estimates [x,x'] under the approximation d=0**, while storing sensor innovations as *evidence* that the model might be wrong. Estimating a general unknown forcing `d(t)` consistently from all modalities remains future research, especially because forcing, changing stiffness and sensor drift can be non-identifiable. Do not interpret innovations alone as forces or damage.

Every calibrated sensor has a physical observation operator:

- vision: `y_v=x + ε_v` after SAM pixel tracking, independent scale, clock and camera-motion checks;
- hearing: `y_a=x' + ε_a` **only after independently calibrated acoustic-pressure→velocity transfer**. A generic microphone recording is **not** velocity;
- accelerometer: `y_i=−ω²x −2ζωx' + F/m + ε_i` in the modeled axis; this requires alignment, known force and sensor orientation;
- contact force: `F(t)` is the **input** to the twin, not another copy of displacement;
- smell: gas concentration in mol/m³ with calibration/drift limitations; chemistry dynamics are not oscillator dynamics;
- taste: pH/conductivity with unit- and chemistry-specific calibration; pH does not identify a solution.

The Bayesian conditional likelihood of each candidate mechanistic hypothesis is evaluated under these equations and **only among offered hypotheses**, with no guarantee the true mechanism is in the list. When models cannot be distinguished from available observations, Physica should request a new safe intervention instead of inventing confidence.

Normalize a measured response to create transportable event words:

`τ=f_source·t` and `q(τ)=k_source·x(t)/F_source`.

For a compatible target, the *candidate* outcome becomes

`x_target(t)=(F_target/k_target)q(f_target·t)`.

For another sensor, apply its calibrated measurement operator. These equations are grounded in conventional mechanics. **The proposed novel research direction is their integration with causal interventions, independently observed modalities, Meta scene constraints, learning across bodies, and principled abstention.** No novel theorem or peer-reviewed breakthrough is asserted.

## Executable entry points

From the extracted `physica/` directory:

```bash
python -m pip install -e '.[dev]'
python -m physica.cli grammar demo --out demo/csg --trials 12
# open demo/csg/experience_lab.html in a browser
python -m physica.cli grammar benchmark --out demo/csg_benchmark.json --trials 24
python -m physica.cli grammar schema --out docs/pel_v3.schema.json
python -m physica.cli grammar meta-status
python -m pytest -q tests/test_grammar_v042.py
```

### Prospective real-sensor workflow (the experiment you still need to run)

1. Build an isolated, low-force clamped-strip demonstration with physical force calibration, mass/stiffness and resonance measurements, microphone and/or IMU, and synchronized sampling clocks. Collect source A recordings and an independent human attestation of the controlled intervention. If audio is not pressure→velocity calibrated, store its native physical units and **do not use the mechanical `hearing/velocity` operator**.
2. Prepare `A_manifest.json` following `examples/csg_field_example/README.md`: body calibration, channel CSVs and unit conversion factors, sensor uncertainty, provenance, intervention ID, hypothesis and external attestation filename.
3. Convert A to a checked physical word: `python -m physica.cli grammar source A_manifest.json --out A_signed.json`.
4. Predefine B *without measuring its response*: independent B calibration JSON and a CSV containing **only** the `time_s` column. Execute `python -m physica.cli grammar prepare A_signed.json B_calibration.json B_times.csv --modality vision --observable displacement --out B_prediction_signed.json`. Immediately publish the hash with an independent timestamp or witness.
5. Collect B's response CSV (`time_s,value`), calibrated SI conversion, and run `python -m physica.cli grammar check B_prediction_signed.json B_observation.csv --si-per-raw-unit <calibrated gain> --si-sigma <independently measured sigma> --out B_reveal_signed.json`.
6. Convert B's *new, separately revealed* experience into a source word: `python -m physica.cli grammar learn-next B_reveal_signed.json B_sensor_config.json --action-id reversible_step_force --hypothesis mount_compliance --out B_signed_source.json`.
7. Use `grammar prepare B_signed_source.json C_calibration.json C_times.csv ...` to prospectively predict unseen C. Verify whether B taught C better than A-only, physics-only, nearest-source and local-only baselines.

**IMPORTANT:** The local attestation and signatures authenticate content of a lab record, NOT the real-world truth of the experiment or objective chronology. Publish original raw sensor/video files with hashes and a third-party witness/timestamp, plus *negative and failed trials*.

### Optional Meta integration (requires your own API key and permission)

```bash
pip install -e '.[meta]'
export MODEL_API_KEY='YOUR_KEY_ONLY_ON_YOUR_MACHINE'
python -m physica.cli grammar meta-csg-live A_manifest.json source.mp4 B_calibration.json B_times.csv \
  --reference-csv independent_source_displacement.csv \
  --concept 'metal strip' --track-id 0 --meters-per-pixel 0.00015 --fps 240 \
  --crosscheck-rmse-m 0.0002 --camera-sigma-m 0.00005 \
  --allowed safe_low_force_probe --out demo/live --allow-billed-meta
```

**The command line numbers above are illustrative placeholders**, not calibrated settings for your camera/sensor. Derive each value from your actual rig. `meta-csg-live` fails closed without a key, explicit paid-call authorization, source witness, and independent camera-vs-sensor agreement. It does not actuate hardware.

`meta-crate-prepare` in the existing v0.4.1 CLI remains available for the prior experiment pipeline. V-JEPA 2 requires its own downloaded weights/compute and independently learned readout in SI units; keep using `physica experience visual-fit/visual-forecast` with an honest model provenance. No project file claims Muse/SAM/V-JEPA has been executed live here.

## Mechanisms by sense and missing research

| Sense | Implemented physical relation | Absent hardware validation or unimplemented part |
|---|---|---|
| Sight | calibrated displacement/velocity | genuine live SAM mask accuracy, rolling shutter correction, stationary reference |
| Hearing | calibrated velocity/acceleration proxy | raw microphone spectral pressure→velocity calibration for unseen bodies, sound source separation |
| Touch | force as input, touch displacement/velocity/acceleration as separate observations | shear, pressure array, force/moment calibration, contact/slip mechanics |
| Proprioception | body acceleration/velocity/displacement | motor current, encoder offsets, nonrigid body dynamics |
| Smell | gas concentration typed data, unit and drift requirements | VOC species mixtures, diffusion/reaction models, hardware |
| Taste | pH/conductivity typed data | electrochemical kinetics, liquid mixtures, salinity/temperature compensation, hardware |

A complete, general six-sense robot is **not present**. The correct architectural approach is mechanism-specific physical operators feeding shared causal *relations*, with refusal when modalities cannot identify the same latent state.

## Physical experiment and identifiability checklist

- [ ] Independently calibrate force **and** sensor transfer functions, field of view, frame rate and in-plane geometry; photograph/ruler-check the scale.
- [ ] Synchronize camera/audio/IMU via an observable pulse; log timestamp drift; no silent interpolation over packet loss.
- [ ] Hold machine A/B/C out from source training, and ensure experiment labels are blind to algorithm outcomes.
- [ ] Choose the original test stimulus and mechanical context BEFORE collecting the response.
- [ ] Test nuisance factors: different attachment clamp, different ambient acoustics, camera shake, temperature, altered force waveform, unseen materials.
- [ ] Compare physics-only, nearest-source, CRATE, CSG, local-only system identification, and learned Koopman/dynamics transfer (where feasible).
- [ ] Compare **Meta on vs off**, specifically correct part localization, experiment count and causal hypothesis accuracy. A simulation with a scripted context is NOT Meta ablation evidence.
- [ ] Include negative examples and missing/contradictory sensor channels; report refusals and harmful false positives.
- [ ] Use split conformal calibration across **whole held-out machines**, not frames of the same machine; test empirical coverage after distribution shift.
- [ ] Precommit and publicly timestamp predictions; collect B only after commitment; no human edits to target labels before reveal.
- [ ] Replicate several independent hardware trials and publish source raw files + evidence hashes.

## Current synthetic evidence (not real research validation)

`examples/csg_showcase/benchmark.json` contains a seeded run of 24 synthetic source-like targets and 8 shifted-dynamics targets, with full baseline RMSE and sensor ablations. **The initial two-sensor fusion does not always beat hearing alone on displacement RMSE**, which is an explicit unresolved model-mismatch limitation. The training family intentionally shares a normalized residual shape; shifted-dynamics cases violate that assumption, often making a nearest-source baseline stronger. There are no claims of cross-embodiment universality, empirical Meta-model improvement or physical-world uncertainty coverage.

## Scientific originality boundary

Existing physical system identification, modal residuals, wavelets, cross-modal sensor representations, Bayesian model selection, causal experimental design, representation learning, and dimensionless transport overlap significant parts of this project. CSG is a proposed **system-level research composition**, not verified original math. Potentially publishable results require demonstrating *identifiable causal mechanism selection, sensor-to-sensor response forecasting, reliable abstention, and fewer target experiments* on independently held-out real systems against strong baselines. It must also be robust to the hidden dynamics failures revealed by v0.4.1 and this release.

Official Meta docs consulted October 2026:
- https://dev.meta.ai/docs/overview
- https://dev.meta.ai/docs/models
- https://dev.meta.ai/docs/media-segmentation
- https://dev.meta.ai/docs/sam/client-libraries
- https://dev.meta.ai/docs/cookbook/sam-api-basics

Meta platform model names and API pricing/availability may change. Do not infer that Muse Glimmer or V-JEPA are hosted directly on `api.meta.ai`: they are separate/open-weight deployment paths.
