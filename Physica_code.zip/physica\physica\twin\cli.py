"""Local Physica Twin command line; Meta SAM is always explicitly billable."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from .engine import reconstruct, demo_twin


def main(argv=None):
    ap=argparse.ArgumentParser(description='Build and export a conservative evidence-linked digital twin')
    ap.add_argument('input',nargs='?',type=Path,help='CSV, video or exported calibrated SAM tracking JSON')
    ap.add_argument('--out',type=Path,default=Path('demo/twin/PHYSICA_TWIN.json'))
    ap.add_argument('--pixels-per-metre',type=float)
    ap.add_argument('--fps',type=float)
    ap.add_argument('--roi',default='0.26,0.20,0.48,0.60')
    ap.add_argument('--synthetic-demo',action='store_true')
    ap.add_argument('--sam-target',help='short noun phrase for Meta SAM to track; billed separately')
    ap.add_argument('--sam-reference',help='short noun phrase for an independently stationary reference')
    ap.add_argument('--calibration-verified',action='store_true',help='human certifies checked length scale and timebase')
    ap.add_argument('--reference-stationary-verified',action='store_true')
    ap.add_argument('--allow-billed-meta',action='store_true')
    args=ap.parse_args(argv)
    sam_requested=bool(args.sam_target or args.sam_reference)
    if args.synthetic_demo:
        if args.input or sam_requested or args.allow_billed_meta:ap.error('synthetic demo cannot receive Meta or input')
        report=demo_twin()
    else:
        if not args.input or not args.input.is_file():ap.error('input file is required')
        if sam_requested:
            if not(args.sam_target and args.sam_reference and args.allow_billed_meta and args.calibration_verified and args.reference_stationary_verified and args.fps and args.pixels_per_metre):
                ap.error('SAM needs target and reference prompts, verified FPS and scale, both independent calibration acknowledgments, and --allow-billed-meta')
            if args.input.suffix.lower() not in ('.mp4','.mov'):
                ap.error('official SAM video API accepts MP4/MOV')
            from physica.mace.vision_bridge import run_video
            exported=run_video(args.input,concept_target=args.sam_target,concept_reference=args.sam_reference,
                  frames_per_second=args.fps,pixels_per_metre=args.pixels_per_metre,
                  calibration_verified=True,static_reference_verified=True,allow_billed=True)
            report=reconstruct(args.input.stem+'_SAM_TRACKS.json',json.dumps(exported).encode())
            report['meta']={'sam':'AUTHENTICATED_META_SAM_RESPONSE_CLAIM','muse':'NOT_CALLED',
                            'independent_reference_and_length_verified_by_operator':True,
                            'source_video_sha256':exported['raw_video_sha256']}
            report['evidence']['sam_track_export_sha256']=report['evidence']['sha256']
            report['evidence']['sha256']=exported['raw_video_sha256']
            report['evidence']['origin']='AUTHENTICATED_META_SAM_WITH_OPERATOR_CLAIMED_CALIBRATION'
        else:
            if args.allow_billed_meta:ap.error('Meta billing flag requires explicit --sam-target and --sam-reference')
            roi=[float(v) for v in args.roi.split(',')]
            report=reconstruct(args.input.name,args.input.read_bytes(),pixels_per_metre=args.pixels_per_metre,fps=args.fps,roi=roi)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'status':report['status'],'out':str(args.out),'model_fitted':report['model'] is not None,
      'meta':report['meta'],'limitations':report['limits'][:3]},indent=2))
    return 0

if __name__=='__main__':raise SystemExit(main())
