"""Learned cross-sensory embeddings and action-conditioned dynamics (research)."""
