"""Real footage from the internet, each with an answer already published or known. Physica's reading is sealed before it's compared.

The film's maker measured none of this for us, so these aren't our experiments. I looked at these clips while building the readers, so they're demonstrations on real footage, not blind tests.
"""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

import numpy as np

from physica import config, seal as _seal
from physica.llm import meta_client as mc
from physica.meta import scout as SC
from physica.touch import cables as C

OUT = config.REPO_ROOT / "eval" / "results" / "E35_real_footage.json"
CLIPS = config.REPO_ROOT / "clips"

GUITAR = {"key": "guitar", "file": "guitar.mp4", "title": "A guitar filmed at 600 frames per second", "fps": 600.0, "lowest_hz": 60.0,
          "boxes": {"low E string": (40, 34, 200, 50), "A string": (40, 60, 200, 70)}, "truth_hz": {"low E string": 82.41, "A string": 110.0},
          "truth_how": "Standard guitar tuning. The frame rate is the 600 fps given in Wu et al., Eulerian Video Magnification, SIGGRAPH 2012",
          "credit": "Wu et al., MIT, via github.com/jvgemert/pbMoMa. Research use with attribution. Check before showing publicly", "extra": "Name the individual strings that are vibrating. "}
TACOMA = {"key": "tacoma", "file": "tacoma_bridge.mp4", "title": "Tacoma Narrows Bridge, November 7, 1940", "credit": "Archive film, tagged public domain on Wikimedia Commons. This clip via github.com/ladisk/pyidi (MIT licence)",
          "published_playback_cpm": 18.0, "published_true_cpm": 12.0, "truth_how": "Farquharson's stopwatch, 12 cycles per minute. Olson, Wolf and Hook, Physics Today 2015: the video plays 50% fast, showing 18, because a 16 fps film was converted as if 24 fps"}

BEAM = {"key": "beam", "file": "beam_hit.mp4", "title": "A real beam, hit once, filmed at 10,000 frames a second", "fps": 10000.0, "credit": "Film from github.com/ladisk/pyidi, University of Ljubljana LADISK, Photron FASTCAM SA-Z (MIT licence)"}

FILM_SPEED = """Physica measured a twist in this old film at {cpm} cycles per minute of playback, at the frame rate of the file. It can't know how fast the original camera ran. Watch the film. Say whether it might play at a different speed from how it was shot, and why. \
If you think so, give the frame rate you believe it was shot at, and the rate it was treated as during conversion. Don't state a corrected number, because code will work it out. Reply as JSON: {{"plays_at_true_speed": <true or false>, "shot_fps": <number or null>, "treated_as_fps": <number or null>, "why": "<one or two sentences>"}}."""
ASK_TWIST = """Watch this film. How many cycles per minute is the main structure twisting, in real life? Give your best number. Reply as JSON: {{"cycles_per_minute": <number or null>, "why": "<one sentence>"}}."""
ASK_STRINGS = """Watch this film. It's slow motion. What's the vibration frequency in hertz of the low E string and the A string, measured from the film? Give your best numbers. Reply as JSON: {{"low_e_hz": <number or null>, "a_hz": <number or null>, "why": "<one sentence>"}}."""
EXPLAIN = """You watched a film of a real structure. Physica's measurement: {reading}. In two plain sentences for a general audience, say what's moving and what this number means. Use only the numbers given here, exactly. Reply as JSON: {{"say": "<two sentences>"}}."""


def read_sway(film: str | Path) -> dict:
    """A swing too big for phase reading. Two separate trackers: how the whole picture rolls from frame to frame, and the tilt of the skyline. They should agree."""
    import cv2
    cap = cv2.VideoCapture(str(film))
    frames = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY))
    fps = float(cap.get(cv2.CAP_PROP_FPS))
    cap.release()
    if len(frames) < 32:
        raise ValueError("too few frames to read a slow swing")
    roll, tilt = [0.0], []
    for a, b in zip(frames[:-1], frames[1:]):
        pa = cv2.goodFeaturesToTrack(a, 300, 0.01, 6)
        pb, st, _ = cv2.calcOpticalFlowPyrLK(a, b, pa, None)
        M, _ = cv2.estimateAffinePartial2D(pa[st == 1], pb[st == 1], method=cv2.RANSAC)
        roll.append(roll[-1] + (float(np.degrees(np.arctan2(M[1, 0], M[0, 0]))) if M is not None else 0.0))
    for g in frames:
        h, w = g.shape
        xs = np.arange(10, w - 10, 6)
        edge = [int(np.argmax(-np.diff(cv2.GaussianBlur(g[: h // 2, x].astype(np.float32), (1, 9), 0).ravel()))) for x in xs]
        tilt.append(float(np.polyfit(xs, edge, 1)[0]))
    t = np.arange(len(frames)) / fps

    def peak(y):
        z = np.asarray(y) - np.polyval(np.polyfit(t, y, 2), t)
        spec = np.abs(np.fft.rfft(z * np.hanning(len(z)), n=8192))
        fr = np.fft.rfftfreq(8192, 1 / fps)
        m = (fr >= 3 / t[-1] * 0.5) & (fr <= 2.0)
        return float(fr[m][int(np.argmax(spec[m]))])
    a, b = peak(roll), peak(tilt)
    return {"status": "MEASURED", "roll_cpm": round(a * 60, 1), "skyline_cpm": round(b * 60, 1), "cpm": round((a + b) * 30, 1), "cycles_in_clip": round((a + b) / 2 * t[-1], 1), "swing_deg": round(float(np.ptp(roll)) / 2, 1), "seconds": round(float(t[-1]), 2), "fps": fps,
            "roll_trace": [round(float(v), 2) for v in roll], "limit": "Only about two and a half cycles in this short clip, so the reading is rough"}


def _muse_says(prompt: str, film=None, role: str = "spark", task: str = "physica_case") -> dict:
    content = [{"type": "input_text", "text": prompt}]
    if film is not None:
        with tempfile.TemporaryDirectory() as d:
            content.append(mc.video_part(SC.muse_clip(film, Path(d) / "w.mp4")))
    r = mc.respond(role, [{"role": "user", "content": content}], task, media_usd=0.1 if film is not None else 0.0, effort="medium")
    return {**SC.parse_json(r["content"]), "usd": r["usd"]}


def _pct(a, b) -> float | None:
    return None if a is None else round(100 * abs(float(a) - b) / b, 1)


def tacoma(folder: Path, live: bool, on_step=print) -> dict:
    c = TACOMA
    film = folder / c["file"]
    got = read_sway(film)
    sealed = _seal.seal({k: got[k] for k in ("cpm", "roll_cpm", "skyline_cpm", "cycles_in_clip")}, "the twist in this film, in cycles per minute of playback, before the published number")
    on_step(f"Felt, two trackers: {got['roll_cpm']} and {got['skyline_cpm']} cycles per minute of playback, about {got['cycles_in_clip']} cycles seen. Sealed {sealed['anchor']}")
    out = {"key": c["key"], "title": c["title"], "credit": c["credit"], "truth_how": c["truth_how"], "reading": {k: v for k, v in got.items() if k != "roll_trace"}, "sealed": sealed,
           "published_playback_cpm": c["published_playback_cpm"], "published_true_cpm": c["published_true_cpm"], "error_vs_playback_pct": _pct(got["cpm"], c["published_playback_cpm"]), "roll_trace": got["roll_trace"]}
    if not live:
        return out
    seen = SC.watch(film, task="physica_case_tacoma")
    on_step(f"Muse watched: {seen['machine']}. {seen['seen']}")
    out["muse_saw"] = {k: seen.get(k) for k in ("machine", "seen", "possible_causes")}
    speed = _muse_says(FILM_SPEED.format(cpm=got["cpm"]), film, "wonder", "physica_case_film_speed")
    out["muse_on_film_speed"] = speed
    on_step(f"Muse on the film's speed: {speed.get('why')}")
    shot, treated = speed.get("shot_fps"), speed.get("treated_as_fps")
    if not speed.get("plays_at_true_speed") and shot and treated:
        corrected = round(got["cpm"] * float(shot) / float(treated), 1)
        sealed2 = _seal.seal({"corrected_cpm": corrected, "shot_fps": shot, "treated_as_fps": treated}, "the real twist, using Muse's reasoning about the film and Physica's measurement, before the published number")
        out.update(corrected_cpm=corrected, corrected_sealed=sealed2, error_vs_true_pct=_pct(corrected, c["published_true_cpm"]))
        on_step(f"Code: {got['cpm']} x {shot} / {treated} = {corrected} cycles per minute. Sealed {sealed2['anchor']}")
    else:
        out["corrected_cpm"] = None
        on_step("Muse didn't propose a correction, so the reading stands.")
    alone = _muse_says(ASK_TWIST, film, "spark", "physica_case_muse_alone")
    out["muse_alone"] = alone
    out["uncorrected_error_vs_true_pct"] = _pct(got["cpm"], c["published_true_cpm"])
    out["muse_alone_error_vs_true_pct"] = _pct(alone.get("cycles_per_minute"), c["published_true_cpm"])
    out["note"] = "This film is famous, so Muse may remember the answer rather than work it out. Treat its reasoning as knowledge plus measurement, not proof that it derived the result."
    return out


def guitar(folder: Path, live: bool, on_step=print) -> dict:
    c = GUITAR
    film = folder / c["file"]
    rows = {}
    for name, box in c["boxes"].items():
        V, _ = SC.load_region(film, box, most_frames=2048, long_side=400)
        rows[name] = C.read_cable(V, c["fps"], lowest_hz=c["lowest_hz"])
    V, _ = SC.load_region(film, None, most_frames=2048, long_side=432)
    whole = C.read_cable(V, c["fps"], lowest_hz=c["lowest_hz"])
    sealed = _seal.seal({"tones_hz": {k: r.get("tone_hz") for k, r in rows.items()}, "whole_frame_hz": whole.get("tone_hz")}, "each string's tone, before standard tuning is compared")
    table = {k: {"tone_hz": r.get("tone_hz"), "felt": r.get("felt"), "tuning_hz": c["truth_hz"][k], "error_pct": _pct(r.get("tone_hz"), c["truth_hz"][k]) if r.get("felt") else None} for k, r in rows.items()}
    for k, r in table.items():
        on_step(f"{k}: {r['tone_hz']} Hz. Standard tuning is {r['tuning_hz']} Hz, off by {r['error_pct']}%.")
    on_step(f"The whole frame gives one number for all the strings: {whole.get('tone_hz')} Hz. Sealed {sealed['anchor']}")
    out = {"key": c["key"], "title": c["title"], "credit": c["credit"], "truth_how": c["truth_how"], "strings": table, "whole_frame_hz": whole.get("tone_hz"), "sealed": sealed, "located_by": "boxes a person drew, for this reading"}
    if not live:
        return out
    F = SC.Film(film, c["fps"], CLIPS / "work")
    seen = SC.watch(film, extra=c["extra"], task="physica_case_guitar")
    on_step(f"Muse watched: {seen['machine']}. {seen['seen']}")
    names = [p["name"] for p in seen["parts"]]
    grid = SC.point(F.still(), names, task="physica_case_guitar_point") if names else {}
    grid = {n: grid[n] for n in names if n in grid}
    found = {}
    if grid:
        F.pin(grid)
        for n in grid:
            px = F.pixels_of(n)
            found[n] = C.read_cable(px[0], c["fps"], px[1], c["lowest_hz"]) if px else {"felt": False, "reason": "SAM didn't find it"}
            on_step(f"  Muse pointed, SAM pinned: {n}: " + (f"{found[n]['tone_hz']} Hz" if found[n].get("felt") else f"can't tell. {found[n].get('reason')}"))
        try:
            SC.masks_film(F, CLIPS / "guitar_masks.mp4")
        except Exception as e:
            on_step(f"Couldn't make the masks clip: {str(e)[:100]}")
    out.update(muse_saw={k: seen.get(k) for k in ("machine", "seen")}, muse_found={k: {x: v.get(x) for x in ("tone_hz", "felt", "reason")} for k, v in found.items()}, typed_words=0, overlay=SC.overlay(F) if grid else None)
    alone = _muse_says(ASK_STRINGS, film, "spark", "physica_case_muse_alone")
    out["muse_alone"] = alone
    out["muse_alone_error_pct"] = {"low E string": _pct(alone.get("low_e_hz"), 82.41), "A string": _pct(alone.get("a_hz"), 110.0)}
    return out


def beam(folder: Path, live: bool, on_step=print) -> dict:
    """A real beam, hit once. The twin learns from the first moments and forecasts the rest, graded on raw pixels."""
    from physica.twin import strike
    c = BEAM
    t = strike.read(folder / c["file"], c["fps"])
    h = t["holdout"]
    sealed = _seal.seal({"tone_hz": t["tone_hz"], "decay_per_s": t["decay_per_s"], **h}, "the struck beam's twin and how its forecast scored")
    on_step(f"Felt the hit: {t['tone_hz']} Hz, dying away at {t['decay_per_s']} per second. Biggest motion {t['biggest_motion_px']} pixels.")
    on_step(f"Learned from the first {h['learned_on_s']} s, it forecast the next {h['predicted_s']} s of raw pixels: match {h['match_r']}, and {h['closer_than_stopping_pct']}% closer than assuming the beam just stops. Sealed {sealed['anchor']}")
    out = {"key": c["key"], "title": c["title"], "credit": c["credit"], "tone_hz": t["tone_hz"], "decay_per_s": t["decay_per_s"], "holdout": h, "sealed": sealed}
    if live:
        try:
            seen = SC.watch(folder / c["file"], task="physica_case_beam")
            on_step(f"Muse watched: {seen['machine']}. {seen['seen']}")
            out["muse_saw"] = {k: seen.get(k) for k in ("machine", "seen")}
        except Exception as e:
            on_step(f"Muse couldn't read this narrow strip of film: {str(e)[:120]}")
    return out


def run(folder=CLIPS, live: bool = False, on_step=print, out: Path = OUT, only: str | None = None) -> dict:
    folder = Path(folder)
    res = json.loads(out.read_text()) if out.exists() else {"label": "REAL FOOTAGE FROM THE INTERNET", "note": "Real films with published or known answers. I looked at these clips while building the readers, so these are demonstrations, not blind tests.", "cases": {}}
    for key, fn, file in (("tacoma", tacoma, TACOMA["file"]), ("guitar", guitar, GUITAR["file"]), ("beam", beam, BEAM["file"])):
        if only and only != key:
            continue
        if not (folder / file).exists():
            on_step(f"\n{key}: {file} isn't in {folder}, so it's skipped")
            continue
        on_step(f"\n{key}:")
        try:
            res["cases"][key] = {**fn(folder, live, on_step), "live_meta": live}
        except Exception as e:     # one failed clip shouldn't stop the other, and the record says so
            on_step(f"  This one failed: {str(e)[:300]}")
            res["cases"].setdefault(key, {})["failed"] = str(e)[:300]
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(res, indent=1, default=float))
    return res
