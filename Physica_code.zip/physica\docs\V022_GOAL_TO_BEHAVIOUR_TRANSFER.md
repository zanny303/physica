# Physica v0.22 — Goal-directed physical skill transfer

## What is newly implemented

The previous A→B transfer focused on **predicting a target machine's physical response**.
This release adds a bounded **behavior contract**: given an acceptable source
mechanism, explicit sensor calibration, the target's approved adjustable
settings, and a measurable desired outcome, Physica evaluates all approved
settings and selects one that meets the **simulated** goal without violating
specified modeled limits. The target can have different sensor units than
Machine A. A SHA-256 commitment accompanies the candidate setting and modeled
result. All candidate settings and rejections are included.

This is *goal-conditioned intervention transfer* in a narrow, honest sense.
It is **not** general autonomous actuation, not evidence of model superiority,
and not physically certified advice. No new device executors were added:
behavior contracts cannot be run on a physical machine by this API.

## End-to-end demonstration

Open `http://127.0.0.1:8765/twin`, click **Load synthetic demo**, scroll to
**Teach another machine to act**, review the target unit calibration, goal,
and approved settings. With the target compatibility box **unchecked**, the
system requests independent target evidence and refuses to issue a setting.
If you have verified compatibility independently, checking the box evaluates
the target candidates in the *synthetic simulator*. It returns a `TARGET_EVIDENCE_REQUIRED`
review-only contract when no real target evidence is supplied. The interface
does not make any hardware calls.

CLI standalone deterministic demonstration:

```powershell
$env:PYTHONUTF8 = "1"
..\.venv\Scripts\python.exe -m physica.twin.goal_transfer --out demo\goal_transfer.json
```

Inspect the report: the default setting fails the modeled 200-tick terminal
threshold, while `moderate_damping` meets it in this scenario. The sensor
mapping uses **1,000 encoder ticks per normalized length unit**, which is
an *assumed calibration for simulation*, not inferred from video.

To use your own evidence, export a Twin JSON from Studio, and supply target and
goal JSON files:

```powershell
..\.venv\Scripts\python.exe -m physica.twin.goal_transfer --source source_twin.json --target target.json --goal goal.json --out demo\target_plan.json
```

Without `--accept-source-mechanism` the planner returns
`TARGET_VALIDATION_REQUIRED`. Passing that flag is a **declaration of external
compatibility evidence**, not something Physica can verify automatically.
The target contract includes a named machine, sensor scale, supported
operating limits, 1–32 approved setting choices with dimensionless stiffness
and damping ratios, and an optional `independent_evidence` declaration.
The supported objective is currently `settle_below`, targeting a final sensor
displacement within 0.2–5 seconds. This restriction is intentional.

## Non-negotiable scientific limits

- A source second-order fitted model is a conditional surrogate. Diverse
  controlled inputs do **not** by themselves prove its causal structure.
- Transfer assumes the target shares the same normalized dynamics; **source
  applicability to a different machine must be checked independently**.
- The predicted action is not G-code, PLC, drone commands, a printable
  configuration, or a real-world proof. An actuator adapter must independently
  compile, simulate, sandbox, authorize, execute, and observe it.
- A SHA-256 digest is a reproducibility check, not third-party time attestation.
- The toy simulator uses fixed-step integration and rejects unstable or
  out-of-range trajectories; it is not a certified physics or safety solver.
- No authenticated Muse call, SAM tracking, real robotic action, or new
  real-world A→B improvement is asserted by this release.
- The relevant baselines for future work are target-only model predictive
  control, hierarchical system ID, active experiment design, and no-transfer
  outcome search, with equal measurement and actuation budgets.

## Next research experiments

1. Calibrate source and target with independent instruments and safe
   operator-approved steps; compare the target dynamics on held-out tests.
2. Run target-only, source-transfer and hierarchical baselines on the same
   predeclared goal and test budget.
3. Seal the planned setting and predictive distribution before the authorized
   target run; measure the actual target behavior independently.
4. Add a device-specific **reviewed** executor that can reject unsupported
   states and convert validated outcome contracts into safe supported commands.
5. Integrate bounded Muse hypothesis and experiment proposals; measure their
   incremental value rather than assuming it.
