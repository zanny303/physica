"""Local safety gate on every action that changes a machine or writes machine settings.

With GLIMMER_BASE_URL/GLIMMER_MODEL set (Muse Glimmer served by you, e.g. vLLM on Modal with an
OpenAI-style API), Glimmer reviews the action. Hard rules always apply first and cannot be overridden.
"""
from __future__ import annotations

import json
import os
import urllib.request

HARD_LIMITS = {"freq_hz": (5.0, 1000.0)}


def _rules(action: dict) -> list[str]:
    reasons = []
    f = action.get("freq_hz")
    if f is not None and not (HARD_LIMITS["freq_hz"][0] <= f <= HARD_LIMITS["freq_hz"][1]):
        reasons.append(f"frequency {f:.1f} Hz outside hard limits {HARD_LIMITS['freq_hz']}")
    if not action.get("card"):
        reasons.append("no signed card backs this action")
    rng = action.get("proven_range_hz")
    if f is not None and rng and not (0.8 * rng[0] <= f <= 1.2 * rng[1]):
        reasons.append(f"{f:.1f} Hz is far outside the card's proven range {rng[0]:.0f}-{rng[1]:.0f} Hz")
    return reasons


def _ask_glimmer(action: dict) -> dict | None:
    base, model = os.environ.get("GLIMMER_BASE_URL"), os.environ.get("GLIMMER_MODEL")
    if not base or not model:
        return None
    prompt = ("You are a safety reviewer for machine settings. Reply with JSON {\"approve\": true|false, \"reason\": \"...\"}. "
              "Approve only if the action is backed by a signed card, stays within its proven range and only writes a "
              "settings file for a human to review. Action: " + json.dumps(action))
    body = {"model": model, "messages": [{"role": "user", "content": prompt}], "max_tokens": 200, "temperature": 0}
    req = urllib.request.Request(base.rstrip("/") + "/chat/completions", data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:  # noqa: S310
            text = json.loads(r.read())["choices"][0]["message"]["content"]
        j = json.loads(text[text.find("{"): text.rfind("}") + 1])
        return {"approved": bool(j.get("approve")), "reason": j.get("reason", ""), "by": f"glimmer:{model}"}
    except Exception as e:  # if Glimmer is unreachable, fall back to rules but say so
        return {"approved": None, "reason": f"Glimmer unreachable: {e}", "by": "glimmer"}


def review(action: dict) -> dict:
    broken = _rules(action)
    if broken:
        return {"approved": False, "reason": "; ".join(broken), "by": "hard rules"}
    g = _ask_glimmer(action)
    if g is None:
        return {"approved": True, "reason": "passes hard rules (Glimmer not configured; rules-only mode)", "by": "hard rules"}
    if g["approved"] is None:
        return {"approved": True, "reason": "passes hard rules; " + g["reason"], "by": "hard rules"}
    return g
