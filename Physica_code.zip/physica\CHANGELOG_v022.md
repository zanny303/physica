# v0.22 — Transfer outcomes, not just models

- Added `physica.twin.goal_transfer`, an explicit cross-sensor physical-skill
  planner that maps source mechanism hypotheses to a target outcome, evaluates
  approved settings, and returns a sealed review-only action contract.
- Added an interactive goal-to-behavior panel and authorized endpoint to Twin
  Studio; updated the homepage's Twin description.
- Explicit refusal modes for unmeasured control inputs, missing target
  validation, unknown goals, unsupported target settings, and operating-limit
  violations. Input JSON has strict field/type/finite-value validation.
- Added regression tests and evidence/transfer documentation.
- **No physical actuation**: the feature deliberately does not emit executable
  G-code, PLC or drone instructions from an unvalidated Twin.
