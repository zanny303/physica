"""The Body Bank: a signed, searchable record of how real things behave physically.

AlphaFold was possible because the Protein Data Bank had collected solved structures for decades. Physical AI has
no equivalent for how objects ring, fade, and respond to touch. Every `physica sense` run can add an entry:
  - the body's words (each mode's pitch, fade, and how hard it was shaken), its physical type, and its events,
  - where it came from (file name, licence, link), when, and a hash + Ed25519 signature
    (a signature proves origin and integrity, not truth).
`find` answers "what in the bank feels like this?" using the same honest comparison machines use with each other.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path

import numpy as np

from physica import config
from physica.touch.transform import compare_words

BANK = config.REPO_ROOT / "bank" / "bodies.jsonl"


def _canon(d: dict) -> bytes:
    return json.dumps(d, sort_keys=True, separators=(",", ":"), default=float).encode()


def entry_from_sheet(sheet: dict, name: str, provenance: dict) -> dict:
    bodies = [{"type": b["type"], "fit_pct": b.get("fit_pct"), "words": [{k: m[k] for k in ("freq_hz", "damping", "ring_s", "amp", "measure")}
                                                                         for m in b["modes"]]} for b in sheet["bodies"]]
    e = {"name": name, "source": sheet["source"], "kind": sheet["kind"], "bodies": bodies,
         "events": [{"t": round(x["t"], 3), "kind": x["kind"]} for x in sheet.get("events", [])],
         "changes": sheet.get("changes", []), "provenance": provenance,
         "added_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")}
    e["id"] = hashlib.sha256(_canon({k: e[k] for k in ("name", "source", "bodies")})).hexdigest()[:16]
    return e


def add(sheet: dict, name: str, provenance: dict, path: Path = BANK, sign: bool = True) -> dict:
    e = entry_from_sheet(sheet, name, provenance)
    if sign:
        from physica.library import sign as S

        e["signature"] = S.sign(e)
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = [r for r in entries(path) if r["id"] != e["id"]]
    rows.append(e)
    path.write_text("".join(json.dumps(r, default=float) + "\n" for r in rows))
    return e


def entries(path: Path = BANK) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(l) for l in path.read_text().splitlines() if l.strip()]


def verify(e: dict) -> bool:
    from physica.library import sign as S

    sig = e.get("signature")
    return bool(sig) and S.verify({k: v for k, v in e.items() if k != "signature"}, sig)


def find(words: list[dict], path: Path = BANK, k: int = 5) -> list[dict]:
    """Bodies in the bank that feel like these words, best first. Distance = mean log-frequency gap over modes
    both feel; the honest verdict (same / different / can't compare) is attached."""
    out = []
    for e in entries(path):
        for i, b in enumerate(e["bodies"]):
            c = compare_words(words, b["words"], partner=0.25, amp_ratio=np.inf)
            if not c["compared"]:
                continue
            d = float(np.mean([abs(np.log(p["b_hz"] / p["a_hz"])) for p in c["compared"]]))
            out.append({"name": e["name"], "body": i + 1, "type": b["type"], "distance_pct": 100 * d,
                        "shared_modes": len(c["compared"]), "verdict_same_shaking": compare_words(words, b["words"])["verdict"],
                        "id": e["id"]})
    out.sort(key=lambda r: (-r["shared_modes"], r["distance_pct"]))
    return out[:k]
