"""Offline research exhibit: deliberately omitted Duffing stiffness mechanism.

ALL DATA ARE SIMULATED. 'Meta-context on' is an authored candidate fixture,
NOT actual Muse inference. Do not use these figures to claim real performance.
"""
from pathlib import Path
import json,math
import numpy as np
from scipy.integrate import solve_ivp
from physica.grammar.mechanism_lab import discover_residual_mechanism
from physica.grammar.meta_mechanism import ground_meta_mechanism
from physica.grammar.field import signed_envelope,verify_signed

M=.15;K=15.;C=.22;ALPHA=45000.

def make_episode(amp,identifier,seed):
    t=np.linspace(0,2.0,200);rng=np.random.default_rng(seed)
    def f(tt):return float(amp if tt<.18 else 0.)
    def rhs(tt,z):
        x,v=z
        return [v,(f(tt)-K*x-C*v-ALPHA*x**3)/M]
    sol=solve_ivp(rhs,(0,2),[0,0],t_eval=t,rtol=1e-9,atol=1e-11,max_step=.003)
    x,v=sol.y;force=np.array([f(tt) for tt in t]);a=(force-K*x-C*v-ALPHA*x**3)/M
    # Synthetic calibrated accel noise (instrument not real!).
    a=a+rng.normal(0,.004,len(t))
    return {'intervention_id':identifier,'time_s':t.tolist(),
            'displacement_m':x.tolist(),'velocity_m_s':v.tolist(),
            'acceleration_m_s2':a.tolist(),'applied_force_n':force.tolist(),
            'origin':'SIMULATED_DUFFING_EXPERIMENT'}

def build(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    train=[make_episode(.40,'A_training',200),make_episode(.60,'B_training',201)]
    heldout=[make_episode(.50,'C_blind_synthetic',202)]
    physics={'mass_kg':M,'stiffness_n_m':K,'damping_n_s_m':C}
    spec={'origin':'SIMULATION_ONLY','train':train,'validation':heldout,'physics':physics,
          'allowed_mechanisms':['cubic_stiffness','quadratic_drag','coulomb_friction','position_velocity_coupling']}
    (out/'interventions_SIMULATED.json').write_text(json.dumps(spec,indent=2)+'\n')
    baseline=discover_residual_mechanism(train,heldout,**physics,candidates=['quadratic_drag','coulomb_friction'])
    full=discover_residual_mechanism(train,heldout,**physics)
    meta=ground_meta_mechanism(train,heldout,physics,
                spark_reply={'context':'SIMULATED authored text: mounting flexes at higher force'},
                wonder_reply={'hypotheses':[{'name':'cubic_stiffness','rationale':'fixed dictionary member; synthetic fixture'}]})
    # A candidate claim can be sent to another machine; it has no actuation
    # authority and its signer's key is local, not a scientific witness.
    candidate={'protocol':'physica.mechanism-candidate/v0.5.1','origin':'SIMULATION_ONLY',
          'mechanism':full['best_candidate'],'validated_intervention_ids':['C_blind_synthetic'],
          'transfer_status':'probe_first; no universal validity established',
          'physical_context':physics,'meta_call_performed':False,'physical_automation_authorized':False}
    signed=signed_envelope(candidate)
    assert verify_signed(signed)
    (out/'signed_mechanism_candidate_SIMULATED.json').write_text(json.dumps(signed,indent=2)+'\n')
    report={'origin':'SIMULATION_ONLY','actual_meta_calls':0,'real_hardware_experiments':0,
        'experimental_setup':'synthetic Duffing oscillator with independently held-out action amplitude',
        'physics_only_heldout_residual_rmse_n':full['known_physics_validation_force_rmse_n'],
        'blind_candidate':full['best_candidate'],
        'meta_off_restricted_dictionary':baseline['status'],
        'authored_meta_candidate_fixture':meta['status'],
        'meta_on_vs_off_not_measured':'author-chosen fixture, not evidence of Meta advantage',
        'source_like_transfer_benchmark':'See original v0.5 benchmark; no new physical experiment',
        'reader_warning':'Training, validation, labels and known mechanism family are simulated and favorable.'}
    (out/'RESEARCH_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
    plotdata=json.dumps({'x':heldout[0]['time_s'],
                         'displacement_mm':[1000*z for z in heldout[0]['displacement_m']],
                         'force_n':heldout[0]['applied_force_n']})
    html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Physica CIRTE 0.5.1 Research Lab</title><style>body{background:#0e1321;color:#e2e8f0;font:16px system-ui;max-width:960px;margin:30px auto;padding:20px}h1{color:#8ecaff}.tag{background:#392b28;color:#ffd2a5;border:1px solid #886949;padding:9px;border-radius:8px}.card{background:#172236;border:1px solid #334155;padding:20px;border-radius:12px;margin:14px 0}.metric{font-size:29px;font-weight:bold;color:#84dfb6}.cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px}svg{max-width:100%;height:auto}button{background:#235f92;color:white;border:0;border-radius:7px;padding:10px;cursor:pointer}pre{white-space:pre-wrap}</style></head><body><h1>Physica • CIRTE 0.5.1</h1><p class="tag"><strong>SYNTHETIC RESEARCH DEMO.</strong> No real Meta inference, no physical experiment, no scientifically proven breakthrough.</p><div class="cols"><div class="card"><h3>Unmodeled mechanism</h3><p class="metric">Cubic stiffness</p><p>Proposed physical force basis ∝ displacement³</p></div><div class="card"><h3>Meta contribution</h3><p class="metric">Unverified</p><p>Offline author-authored candidate only</p></div><div class="card"><h3>Hardware control</h3><p class="metric">Disabled</p><p>Requires human-approved independent safety checks</p></div></div><div class="card"><h2>Blind synthetic Machine C response</h2><svg viewBox="0 0 800 240" id="plot" role="img" aria-label="Synthetic response curve"></svg><p>Displacement in millimeters, 0–2 seconds. Simulated observation only.</p></div><div class="card"><h2>Why the mechanism matters</h2><p>A simple elastic model cannot fully explain the held-out response. An additional candidate term is tested against another synthetic intervention, not accepted based on language alone.</p><button id="toggle">Show measurement and trust boundaries</button><pre id="details" hidden>Source A/B measurements: simulated.\nSynthetic Machine C: independent simulated intervention amplitude.\nMuse: NOT CALLED; candidate fixture authored locally.\nSAM: NOT CALLED; official parser adapter available.\nSigned mechanism token: cryptographic integrity, not proof of physical truth.\nCausal novelty: not established; SINDy-style basis search has prior art.\nNo actuator commands are executed.</pre></div></body><script>const data=DATA;const arr=data.displacement_mm;const min=Math.min(...arr),max=Math.max(...arr);const svg=document.querySelector('#plot');const NS='http://www.w3.org/2000/svg';let poly=document.createElementNS(NS,'polyline');let points=arr.map((v,i)=>[(i/(arr.length-1)*760+20).toFixed(2), (210-175*(v-min)/(max-min||1)).toFixed(2)].join(',')).join(' ');poly.setAttribute('points',points);poly.setAttribute('stroke','#70d8bd');poly.setAttribute('stroke-width','2');poly.setAttribute('fill','none');svg.appendChild(poly);document.querySelector('#toggle').onclick=()=>document.querySelector('#details').hidden=!document.querySelector('#details').hidden;</script></html>'''.replace('DATA',plotdata)
    (out/'research_lab.html').write_text(html)
    return report
if __name__=='__main__':
    import sys
    print(json.dumps(build(Path(sys.argv[1] if len(sys.argv)>1 else 'examples/v051_research/demo')),indent=2))
