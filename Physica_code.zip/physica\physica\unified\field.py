"""Minimal calibrated source-recording bridge for the shared Physica inquiry.

Reads fixed-format sensor observations and frozen model forecasts. Predictive
claims require the operator to supply a forecast-commit receipt, but a local
hash alone does not establish independent chronology. No arbitrary columns,
Python execution, network calls, or hardware commands are accepted.
"""
from __future__ import annotations
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

from .schema import FeltChannel, FeltComparison, FeltExperience, EvidenceError
from .adapters import sha256_file


def _within(base: Path, relative: str) -> Path:
    p=(base/relative).resolve()
    if not p.is_relative_to(base.resolve()) or not p.is_file():
        raise EvidenceError('Input path missing or outside field experiment folder')
    return p


def _csv(path: Path, column: str) -> tuple[np.ndarray,np.ndarray]:
    with path.open(newline='',encoding='utf8') as fp:
        rows=list(csv.DictReader(fp))
    if not rows or len(rows)>200_000 or not all('time_s' in row and column in row for row in rows):
        raise EvidenceError('CSV requires time_s and '+column+'; 1–200000 samples')
    try:
        t=np.asarray([float(row['time_s']) for row in rows],dtype=float)
        y=np.asarray([float(row[column]) for row in rows],dtype=float)
    except (TypeError,ValueError):
        raise EvidenceError('Sensor CSV contains nonnumeric samples') from None
    if not np.all(np.isfinite(t)) or not np.all(np.isfinite(y)) or len(t)<4 or np.any(np.diff(t)<=0):
        raise EvidenceError('Nonfinite samples, insufficient evidence, or nonmonotonic time')
    return t,y


def from_field_manifest(path: Path) -> FeltExperience:
    source=json.loads(path.read_text(encoding='utf8'))
    if source.get('schema')!='physica.felt_field.v028':
        raise EvidenceError('Unsupported field schema')
    root=path.resolve().parent
    observed=_within(root,source['observations_csv'])
    forecast=_within(root,source['forecast_csv'])
    calibration=_within(root,source['calibration_file'])
    if observed==forecast or observed==calibration or forecast==calibration:
        raise EvidenceError('Forecast, observation and calibration must be separate files')
    cal=json.loads(calibration.read_text())
    if not cal.get('independent_calibration_note') or not cal.get('sensor_id'):
        raise EvidenceError('Independent calibration metadata is missing')
    sig=cal.get('sensor_sigma')
    model_sigma=source.get('model_sigma')
    if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and x>0 for x in (sig,model_sigma)):
        raise EvidenceError('Sensor and model uncertainty must both be positive and finite')
    tx,y=_csv(observed,'observed');tp,pred=_csv(forecast,'predicted')
    if len(tx)!=len(tp) or np.max(np.abs(tx-tp))>1e-7:
        raise EvidenceError('Forecast and recorded observation times differ')
    first_hash=sha256_file(forecast)
    sealed=source.get('forecast_commit')
    prospective=False
    if sealed:
        receipt=_within(root,sealed)
        c=json.loads(receipt.read_text())
        if c.get('forecast_sha256')!=first_hash or c.get('system_id')!=source['system_id']:
            raise EvidenceError('Sealed forecast differs from field experiment')
        prospective=True
    calibration_hash=sha256_file(calibration)
    quantity=source['quantity'];unit=source['unit']
    if not isinstance(quantity,str) or not quantity or not isinstance(unit,str) or not unit:
        raise EvidenceError('Missing quantity or unit')
    ref=str(observed)
    # Conservative uncertainty for the mean: use single-sample sigma rather
    # than pretending correlated samples are independent and dividing by sqrt(N).
    obs_mean=float(np.mean(y));pred_mean=float(np.mean(pred))
    ch=FeltChannel(quantity,obs_mean,unit,'measured',ref,calibration_hash,float(sig),
                   'Mean observation; temporal correlations not removed')
    comparison=FeltComparison(quantity,pred_mean,obs_mean,unit,str(forecast),ref,
         observed_sigma=float(sig),predicted_sigma=float(model_sigma),
         prospective=prospective,prediction_commit_sha256=first_hash if prospective else None,
         calibration_ref=calibration_hash)
    doc={
      'raw_recording_sha256':sha256_file(observed),'forecast_sha256':first_hash,
      'calibration_sha256':calibration_hash,
      'sample_count':len(y),'recording_duration_s':float(tx[-1]-tx[0]),
      'residual_rmse':float(np.sqrt(np.mean((pred-y)**2))),
      'residual_max_abs':float(np.max(np.abs(pred-y))),
      'mean_sigma_not_reduced_by_sqrt_n_due_to_correlations':True,
      'forecast_has_local_commit_receipt':bool(prospective),
      'independent_external_timestamp_verified':False,
      'no_claim_that_metadata_proves_calibration_quality':True,
    }
    return FeltExperience(source['domain'],source['system_id'],
        source.get('dataset_origin','unknown'),str(path),
        (ch,), (comparison,), domain_verdict='measured_model_residual',
        outcome_goal=source.get('outcome_goal','investigate unexpected response'),
        safety_class='industrial_advisory' if source['domain']=='turbine' else 'review_only',
        provenance=doc,
        notes=('Shared calibrated one-dimensional signal is not a universal dynamical model',
               'Signed local file hashes do not independently prove prediction timestamp'),
        evidence_split=source.get('evidence_split','unknown'))
