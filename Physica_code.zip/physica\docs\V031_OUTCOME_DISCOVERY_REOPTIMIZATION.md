# Physica v0.31 — Outcome-conditioned feeling, investigation and reoptimization

## What v0.31 changes

Physica's previous Program By Outcome solver could choose settings for supported machines, and its Feeling/Discovery systems could investigate unexpected sensor behavior. Those systems did **not** form one independently testable, end-to-end experiment. Version 0.31 connects them as a **staged, review-only protocol** for an instrumented beam.

**Goal → baseline outcome plan → unexpected measured sensation → committed probe design → separate fitting/validation evidence → revised physical model and optimized plan → committed forecast → *later* measured outcome → accept/reject the outcome**.

Other domains enter the **same evidence-driven inquiry layer** using `domain-inquiry`, while retaining their own dynamics and safety limits. This release does not make F1, wind turbines, printers or industrial bearings controllable by one universal new algorithm.

## Quick synthetic test (no API key or hardware)

From the extracted `physica` directory:

```powershell
python -m pip install -e ".[dev]"
python -m physica.outcome.closed_loop_v031 synthetic-demo --out demo/v031_synthetic
python -m physica.studio --open-browser
```

Open Studio → **Program By Outcome** and launch the new v0.31 synthetic task. Or run:

```powershell
physica outcome-loop synthetic-demo --out demo/v031_synthetic
```

Files, **all labeled SIMULATED**:

- `01_committed_experiments.json`: initial goal and plan, calibrated-surprise trigger, nine predeclared support-position tests, origin, and SHA256.
- `02_separate_probe_results_SIMULATED.csv`: five fitting and four separate validation observations.
- `02_calibration_SIMULATED.json`: reported sensor calibration provenance and observation uncertainty.
- `03_reoptimization_and_sealed_forecast.json`: validation score, accepted/rejected residual correction, new plan, next-outcome forecast and hash.
- `04_future_outcome_revealed_SIMULATED.json`: generated after the forecast.
- `05_verified_result_SIMULATED.json`: whether the prediction interval and user goal actually held.
- `REPORT_SIMULATED.json`: short end-to-end result.

The simulator deliberately contains an additional affine frequency offset and slope that the baseline model did not represent. The code is *not* provided a novel natural law; it is allowed to search an ordinary constant/slope residual family. Its adjustment is meaningful engineering adaptation, not proof of unbounded causal discovery or a scientific breakthrough.

## Staged real-world workflow: measured beam

**Use only an instructor-approved and supervised setup, not an unguarded industrial machine.** The code never applies settings or executes G-code. Before use, the operator must independently inspect instrument calibration, source data provenance, and safe actuator limits.

### A. Prepare the existing physical model

The existing `physica.outcome.worlds.beam.tone_points` loader extracts tone-versus-support measurements from DROPBEAR Dataset-8 experiments. If you have an existing verified tone-point cache (an `.npz` with a structured `points` array), export a v0.31 model:

```powershell
physica outcome-loop export-beam-model --tone-points-npz real/d8_points.npz --out real/beam_model.json
```

This provides a *previously fitted* model and a separate residual-calibration split. It does not independently verify that a downloaded file is original or that physical instruments were accurately calibrated.

Create an operator-reviewed `real/approved_positions.json`:

```json
{
  "machine_id": "BEAM-LAB-01",
  "approved_by": "Instructor-reviewed setup",
  "automatic_actuation": false,
  "support_positions_v": [0.10, 0.14, 0.18, 0.22, 0.26, 0.30, 0.34, 0.38, 0.42, 0.46, 0.50, 0.54, 0.58, 0.62, 0.66, 0.70, 0.74, 0.78, 0.82, 0.86, 0.90]
}
```

**Replace the example positions with positions the actual apparatus supports and a matching machine ID**. Positions outside the previously measured model's support range are rejected.

### B. Ask for an outcome and let new sensations trigger an investigation

An example `real/current_sensation.json`, created from a separately calibrated current-state observation:

```json
{
  "machine_id": "BEAM-LAB-01",
  "support_v": 0.70,
  "unit_support": "V",
  "unit_tone": "Hz",
  "observed_tone_hz": 29.7,
  "sensor_sigma_hz": 0.04,
  "sensor_id": "accel-01",
  "calibration_ref": "external calibration document identifier"
}
```

The numbers above are **illustrative, not real recordings**. A high residual standardized against reported sensor noise and the model's empirical error envelope triggers investigation. The threshold is a heuristic, **not** a p-value or fault diagnosis.

```powershell
physica outcome-loop start `
  --goal "Keep this beam away from the pump at 31 Hz by 5%, moving its support as little as possible" `
  --model real/beam_model.json `
  --approved-settings real/approved_positions.json `
  --machine-id BEAM-LAB-01 --current-support-v 0.70 `
  --sensation real/current_sensation.json `
  --out real/01_committed_plan.json
```

If the original physical model cannot find a feasible plan, investigation is proposed automatically even without a sensation. To investigate despite already having a nominally feasible plan, use `--investigate`; otherwise a low-surprise feasible plan remains review-only and no experiment is required.

### C. Record exactly the planned probes

The committed plan contains explicit `fit_01`, `validation_02` etc. IDs with support positions in volts. Supervised humans must collect the measurements; Physica does **not** run them.

Create `real/probes.csv`:

```csv
experiment_id,split,support_v,tone_hz,unit_support,unit_tone
fit_01,fit,0.10,24.0,V,Hz
validation_02,validation,0.14,24.4,V,Hz
```

The two rows above illustrate the **format only**; the real CSV must contain **all nine exact planned IDs and positions** and the actual measured tone from each. Never fabricate a row or move a recorded measurement into another split.

Create separate `real/calibration.json`:

```json
{
  "machine_id": "BEAM-LAB-01",
  "unit_tone": "Hz",
  "sensor_id": "accel-01",
  "measured_sigma_hz": 0.04,
  "calibration_method": "Independently recorded sensor reference procedure",
  "calibration_date_utc": "2026-11-02T00:00:00Z"
}
```

The calibration provenance is **metadata supplied by the operator**. It is not proof that an external standard was actually used. A qualified reviewer should corroborate this.

```powershell
physica outcome-loop learn --session real/01_committed_plan.json `
  --probes real/probes.csv --calibration real/calibration.json `
  --out real/02_reoptimized_forecast.json
```

### Optional live Muse structural nomination (your key stays private)

The new loop also exposes a **bounded, source-fit-only Muse Wonder role**. This is optional and billable; it is not needed for the offline or synthetic demonstration. Set `MODEL_API_KEY` locally and `MOCK=0`, then add `--live-meta --allow-billed-meta` to the `learn` command. Muse sees only the five fitting observations and may nominate a quadratic residual term (or abstain). Physica fits parameters itself and tests the proposed term on the four separate validation observations against the **source-blind affine model**. If Muse fails, is malformed or does not improve the validation error materially, Physica falls back to the source-blind method and records that result.

No live Meta invocation was made to create this release. A successful paid response is a hypothesis, **not independent physical discovery**. A Meta-on vs Meta-off improvement requires subsequently locked, unfamiliar physical outcomes and repeated comparisons.

The numerical model fits using the five `fit` experiments. The four `validation` experiments are used **to decide whether the candidate beats the baseline**, so they cannot be called an untouched final test. An improvement smaller than the minimum margin or the observation noise is rejected. The accepted correction is restricted to the measured probe domain and retains an empirical prediction-error allowance. It is not presented as formal conformal coverage under distribution shift.

### D. Supervised approved adjustment followed by a future test

Only after `learn` creates the forecast should an operator consider performing the planned action. The software never commands an actuator.

Write a *different*, later recorded `real/future_result.json` (actual values, not the illustration):

```json
{
  "experiment_id": "future_outcome_01",
  "machine_id": "BEAM-LAB-01",
  "support_v": 0.62,
  "unit_support": "V",
  "unit_tone": "Hz",
  "measured_tone_hz": 28.6,
  "calibration_sha256": "REPLACE_WITH_THE_HASH_FROM_02_REOPTIMIZED_FORECAST"
}
```

Use **exactly the support position in `forecast.action_support_v`** and the actual calibration hash from the learning report. Physica rejects mismatched machine, action, units and provenance.

```powershell
physica outcome-loop verify `
  --session real/02_reoptimized_forecast.json `
  --future-measurement real/future_result.json `
  --out real/03_verified_outcome.json
```

The result separately reports `measured_goal_met` and `forecast_interval_held`. A goal can succeed while Physica's predictive calibration fails. Nothing in this loop certifies safety or proves the downtime of a factory was prevented.

A **locally computed hash** is an integrity indicator, *not independent evidence of when the forecast existed*. For defensible research, timestamp/seal the future prediction through an external witness before experiment execution, and retain raw sensor files.

## Same physical inquiry, different applications

For separately recorded printer, F1, or turbine measurements, use the existing `physica.felt_field.v028` manifest containing calibrated observation and forecast CSV files:

```powershell
physica outcome-loop domain-inquiry `
  --field-manifest real/printer/manifest.json `
  --goal "Reduce ringing by 40 percent without reducing travel speed" `
  --out real/printer/outcome_inquiry.json
```

This produces a shared `FeltExperience` inquiry, uncertainty/refusal decisions and review-only next measurements. It **does not** silently apply the beam's polynomial residual model to a printer, racing car or turbine. For training-split evidence only, one may optionally add `--live-meta --allow-billed-meta` with a privately configured `MODEL_API_KEY` and `MOCK=0` to run the existing Wonder → Spark → Wonder research council. The model proposals remain **unverified** until actual domain-specific numerical tests are implemented.

The industrial Sentinel prototype still evaluates retrospective early warnings. It is not connected to automatic machine maintenance orders, factory operations, or a certified predictive-maintenance optimizer; the system must not issue turbine restart authorization.

## Security, ethics, uncertainty, limits

- Deny automatic actuation. Human approval and physical limits are inputs, not facts inferred from a model response.
- Data splits: original beam model fit/calibration, new probe fitting/validation, later outcome reveal. **Keep physical runs separated** to avoid temporal leakage.
- Do not give Muse validation/test observations. In cross-domain mode, the council refuses non-training evidence.
- The 0.31 residual search is a *restricted established engineering calibration approach*, not a newly invented scientific discovery method. Existing v0.27 discovery and v0.26 Muse workflows remain in the project for more general unknown-mechanism research.
- Archived dataset scores, simulated success, and provider model calls are **not** proof of preventing downtime, discovering new physical laws, or real machine safety.
- Real calibration, external timing, autonomous actuation, independent generalization, and algorithmic novelty must be established separately.
