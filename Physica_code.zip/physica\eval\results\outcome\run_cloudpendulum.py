"""Physica remote-lab run. Goal: Make the remote lab motor reach 1 rad within 0.6 s with less than 5% overshoot
Step 1 (probe) runs at gentle known gains; step 2 runs the gains Physica chose and records the result.
Usage:  python run_cloudpendulum.py <user_token> probe   ->  probe.json
        physica outcome "Make the remote lab motor reach 1 rad within 0.6 s with less than 5% overshoot" --machine pendulum --probe probe.json   (identifies, plans, seals, rewrites this file)
        python run_cloudpendulum.py <user_token> run     ->  result.json   (then: physica outcome grade result.json)
"""
import json, math, sys, time
from pycloudpendulum import Client

TARGET = 1.0
PROBE_KP, PROBE_KD = 0.2, 0.01
KP, KD = None, None  # filled after the probe by: physica outcome pendulum --probe probe.json
DT = 0.005


def run(token, kp, kd, out):
    c = Client()
    session, live = c.start_experiment(user_token=token, experiment_type="DoubleIntegrator",
                                       experiment_time=6.0, preparation_time=0.0, record=True)
    print("live video:", live)
    c.set_impedance_controller_params([kp], [kd], session)
    t0 = time.time(); rows = []
    c.set_position([TARGET], session)
    while time.time() - t0 < 6.0 - 0.5:
        rows.append([time.time() - t0, c.get_position(session)[0], c.get_velocity(session)[0]])
        time.sleep(DT)
    video = c.stop_experiment(session)
    json.dump({"kp": kp, "kd": kd, "target": TARGET, "t_pos_vel": rows, "video": video}, open(out, "w"))
    print("saved", out)


if __name__ == "__main__":
    token, step = sys.argv[1], sys.argv[2]
    if step == "probe":
        run(token, PROBE_KP, PROBE_KD, "probe.json")
    else:
        assert KP is not None, "run the probe and let Physica choose the gains first"
        run(token, KP, KD, "result.json")
