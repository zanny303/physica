"""Generate an expressly synthetic sealed prediction/reveal test fixture."""
from pathlib import Path
import json
import numpy as np
from dataclasses import asdict
from physica.feeling.core import Body, Sense
from physica.feeling.mechanism_transfer import discover_and_sign,make_target_probe_certificate
from physica.feeling.v08_benchmark import produce_episode
from physica.feeling.prospective_v08 import simulate_future


def dump(path,obj):
    path.write_text(json.dumps(obj,indent=2)+'\n')


def build(directory):
    out=Path(directory);out.mkdir(exist_ok=True,parents=True)
    source=Body('A_v08_demo',.12,22.,.13,.25,1.)
    target=Body('B_v08_demo',.14,24.,.15,.28,1.)
    train=[produce_episode(source,f'A_train_{i}',.22,.01,seed=30+i,amplitude=.07+.018*i) for i in range(2)]
    heldout=[produce_episode(source,'A_independent_validation',.22,.01,seed=35,amplitude=.095)]
    lesson=discover_and_sign(source,train,heldout,displacement_reference_m=.01)
    probe=produce_episode(target,'B_independent_low_force_probe',.22,.01,seed=45,amplitude=.027)
    cert=make_target_probe_certificate(lesson,target,probe,displacement_reference_m=.01)
    main=produce_episode(target,'B_main_outcome_hidden_until_reveal',.22,.01,seed=70,amplitude=.105,phase=.6)
    senses={'camera':Sense('camera','sight','mm',(1000.,0.),0.,.05,'synthetic_video_calibration'),
            'microphone':Sense('microphone','hearing','Pa',(0.,150.),0.,.05,'synthetic_acoustic_calibration')}
    request={'experiment_id':'B_main_outcome_hidden_until_reveal','target_body':asdict(target),
             'senses':{k:asdict(v) for k,v in senses.items()},'times_s':main['times_s'],
             'applied_force_n':main['true_applied_force_n'],
             'initial_state_m_m_s':main['initial_state_m_m_s'],
             'displacement_reference_m':.01}
    state=np.column_stack([main['displacement_m'],main['velocity_m_s']])
    measured={'experiment_id':request['experiment_id'],'measurement_origin':'SIMULATED',
              'observed_by_sensor':{k:(state@np.asarray(v.state_gains)+v.offset).tolist() for k,v in senses.items()}}
    dump(out/'source_lesson_SIMULATED.json',lesson)
    dump(out/'B_low_force_probe_certificate_SIMULATED.json',cert)
    dump(out/'B_forecast_request_NO_OUTCOME.json',request)
    dump(out/'B_reveal_HIDDEN_UNTIL_FORECAST.json',measured)
    dump(out/'demo_metadata.json',{'origin':'SIMULATED_ONLY','origin_warning':'NOT REAL MEASUREMENT',
        'source_training_interventions':2,'source_validation_interventions':1,
        'target_local_probes':1,'future_target_outcome_in_request':False,
        'demo_steps':['forecast before inspecting B_reveal','reveal with signed forecast'],
        'hardware_actuation_allowed':False})
    return out

if __name__=='__main__':
    import sys
    print(build(sys.argv[1] if len(sys.argv)>1 else 'examples/v08_prospective/demo'))
