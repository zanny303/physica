"""Back end for Studio's front door: the evidence the page shows, and live sensing from a webcam.

Live sensing: the browser reads a few edge positions inside a box the user draws around an object (e.g. a ruler
flicked over a desk edge) at camera rate, with each frame's own timestamp. Every second it sends the last few
seconds here. Physica resamples to an even clock, learns the body's modes (Touch Transform), says what kind of body
it behaves like, when it was touched, and, once it has a reference, which way its tone moved and what that rules out.
"""
from __future__ import annotations

import json
import threading
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
RES = ROOT / "eval" / "results"


def _load(name):
    p = RES / name
    try:
        return json.loads(p.read_text())
    except Exception:
        return None


def evidence() -> dict:
    """Compact numbers for the front page, every one read from eval/results (nothing typed in by hand)."""
    out = {}
    e16, s16 = _load("E16_hidden_cause.json"), _load("E16_series.json")
    if e16:
        a, b = e16["A"], e16["B"]
        c = a.get("comparison_same_recording", {})
        out["E16"] = {
            "A_beam": a["beam"], "B_beam": b["beam"], "rivals": a["discovery"]["rivals"],
            "verdict": a["discovery"]["verdict"]["say"],
            "physica_mm": c.get("physica_live", {}), "published_mm": c.get("published_model_updating_downey2020", {}),
            "fft_mm": c.get("fft_tone_through_physica_physics", {}), "note": c.get("note"),
            "error_bar": a["error_bar"], "B_corr": b["zero_labels_correlation"], "B_slope": b["slope_physica_vs_truth"],
            "B_one_label": b["one_label_mm"], "black_box": b["black_box_from_A_mm"],
            "curve_data_driven": b["learn_on_B_from_labels"], "curve_physica": b["physica_plus_labels_on_B"],
            "crossover": b.get("crossover_labels"), "B_error_bar": b["error_bar_from_A"],
            "other_sensors": b.get("other_sensors_on_B"), "trials": b["trials"],
            "sealed_promise": e16.get("sealed_promise_about_B"), "provenance": [a["provenance"], b["provenance"]],
            "series": s16}
    e17 = _load("E17_active_experiments.json")
    if e17:
        out["E17"] = {"label": e17["LABEL"], "policies": e17["policies"], "example": e17["example"], "trials": e17["trials"]}
    e18 = _load("E18_new_cause.json")
    if e18:
        out["E18"] = {"label": e18["LABEL"], "cases": {k: {"built_in": v["built_in"].get("cause"),
                                                            "built_in_pct": v["built_in"].get("explained_pct"),
                                                            "asked": v["asked_scientist"], "verdict": v.get("verdict"),
                                                            "proposals": [{q: t.get(q) for q in ("name", "part", "why", "explained_second_half_pct", "accepted")}
                                                                          for t in v.get("proposals_tested", [])],
                                                            "mode": (v.get("scientist") or {}).get("mode")}
                                                       for k, v in e18["cases"].items()}}
    e15 = _load("E15_sense_all.json")
    if e15:
        out["E15"] = {"beam": e15["beam_sense"].get("summary"), "guitar": e15["guitar_sense"].get("summary"),
                      "twin_r2": e15["beam_twin_check"].get("r2"), "stream_us": e15["beam_stream"].get("us_per_sample")}
    e9, e1 = _load("E9_skill_transfer.json"), _load("E1_feel_without_damage.json")
    if e1:
        m = e1["methods"]["physica_selfmodel_no_damage_data"]
        out["E1"] = {"felt": m["detect_rate_BCD"], "false_alarm": m["false_alarm_rate_heldout_healthy"],
                     "n_healthy": m["n_heldout_healthy_windows"]}
    if e9:
        o = e9["skills"].get("order_broad", {}).get("solo", {})
        out["E9"] = {"source": e9["source"], "target": e9["target"], "solo_detect": o.get("detect"),
                     "solo_false_alarms": o.get("false_alarms"), "solo_flights": o.get("flights_caught_majority")}
    e19 = _load("E19_evolve_sense.json")
    if e19:
        s = e19["search"]
        out["E19"] = {"proposer": e19["proposer"], "current": e19["physica_current_sense"], "proposals": s["proposals"],
                      "valid": s["valid"], "generations": s["generations"], "champion": s.get("champion"),
                      "verdict": s.get("verdict")}
    e20 = _load("E20_wind_blade.json")
    if e20:
        out["E20"] = {k: e20.get(k) for k in ("LABEL", "blade", "temperature_law_pct_per_degC_at_20C", "temperature_swing_pct_minus15_to_40", "mass_experiment", "score",
                                          "ice_grams", "act_refeel", "baseline_temperature_blind", "learned_warm_only",
                                          "examples", "inspection_mission", "card")}
        try:
            out["E20"]["mission_head"] = (RES / "world" / "blade_inspection.waypoints").read_text().splitlines()[:6]
        except Exception:
            out["E20"]["mission_head"] = []
    e26 = _load("E26_sense_anything.json")
    if e26:
        for r in e26.get("runs", []):
            r.pop("evidence", None)
        out["E26"] = e26
    e25 = _load("E25_deliberate_discover.json")
    if e25:
        out["E25"] = e25
    e24 = _load("E24_f1_race_engineer.json")
    if e24:
        out["E24"] = e24
    e23 = _load("E23_program_by_outcome.json")
    if e23:
        code = {}
        for k, fn, n in (("gcode", "support_move.gcode", 8), ("plc", "blade_guard.st", 60), ("mission", "blade_inspection.waypoints", 6)):
            f = RES / "outcome" / fn
            code[k] = f.read_text().splitlines()[:n] if f.exists() else []
        e23["code"] = code
        out["E23"] = e23
    for key, name in (("E21", "E21_kw51_bridge.json"), ("E22", "E22_retune_beam.json")):
        d = _load(name)
        if d:
            out[key] = d
    try:
        from physica.llm import meta_client as mc
        out["meta"] = mc.status()
    except Exception as e:  # pragma: no cover
        out["meta"] = {"error": str(e)}
    return out


class LiveSensor:
    """Keeps the reference tone between requests so a later change can be judged against it."""

    def __init__(self):
        self.lock = threading.Lock()
        self.reference = None
        self.history = []

    def reset(self):
        with self.lock:
            self.reference, self.history = None, []

    def analyze(self, payload: dict) -> dict:
        t = np.asarray(payload["t"], float) / 1000.0  # ms -> s
        Y = np.asarray(payload["y"], float)
        if Y.ndim != 2 or len(t) != len(Y) or len(t) < 60:
            return {"status": "collecting", "need_frames": 60, "have": int(len(t))}
        order = np.argsort(t)
        t, Y = t[order], Y[order]
        keep = np.r_[True, np.diff(t) > 1e-4]
        t, Y = t[keep], Y[keep]
        fs = 1.0 / float(np.median(np.diff(t)))
        tu = np.arange(t[0], t[-1], 1.0 / fs)
        U = np.stack([np.interp(tu, t, Y[:, j]) for j in range(Y.shape[1])], 1)
        U = U - U.mean(0)
        amp = float(np.sqrt((U ** 2).mean()))
        res = {"status": "ok", "fps": round(fs, 1), "seconds": round(float(tu[-1] - tu[0]), 2), "motion_px": round(amp, 3),
               "nyquist_hz": round(fs / 2, 1)}
        if amp < 0.05:
            res["say"] = "Still. Flick the object (or tap it) and keep it in the box."
            return res
        # a quick whole-window spectrum for drawing, and the strongest tone
        w = np.hanning(len(U))[:, None]
        S = np.abs(np.fft.rfft(U * w, n=4 * len(U), axis=0)) ** 2
        S = S.sum(1)
        f = np.fft.rfftfreq(4 * len(U), 1 / fs)
        band = (f > 0.8) & (f < 0.45 * fs)
        if not band.any():
            return res
        pk = int(np.argmax(np.where(band, S, 0)))
        res["spectrum"] = {"f": f[band][::2].round(2).tolist(), "p": (S[band][::2] / S[band].max()).round(4).tolist()}
        from physica.sense import body_type
        from physica.touch.transform import TouchTransform

        try:
            nch = U.shape[1]
            tt = TouchTransform(fs, n_modes=2, band=(0.8, 0.45 * fs), delays=max(int(0.4 * fs), 8), order=8,
                                space_rank=min(4, nch), measure="displacement").fit(U)
            words = sorted(tt.words(), key=lambda m: m["freq_hz"])
            res["modes"] = [{"freq_hz": round(m["freq_hz"], 2), "damping": round(m["damping"], 4),
                             "ring_s": round(m["ring_s"], 2)} for m in words]
            res["body"] = body_type([m["freq_hz"] for m in words]).get("type")
            an = tt.analyze(U, threshold=8.0, min_gap_s=0.5)
            res["events"] = [{"t": round(float(e["t"]), 2), "kind": "touched"} for e in an.get("events", [])
                             if 0.3 < float(e["t"]) < res["seconds"] - 0.2][:6]
        except Exception as e:  # sensing must never take the page down
            res["sense_error"] = f"{type(e).__name__}: {str(e)[:160]}"
        if not res.get("modes") or abs(res["modes"][0]["freq_hz"] - float(f[pk])) > 0.25 * float(f[pk]):
            res["modes"] = [{"freq_hz": round(float(f[pk]), 2), "damping": None, "ring_s": None}] + \
                [m for m in res.get("modes", []) if abs(m["freq_hz"] - float(f[pk])) > 0.25 * float(f[pk])][:1]
        tone = float(res["modes"][0]["freq_hz"]) if res.get("modes") else float(f[pk])
        res["tone_hz"] = round(tone, 2)
        with self.lock:
            self.history.append(tone)
            self.history = self.history[-120:]
            if self.reference is None and len(self.history) >= 3 and np.std(self.history[-3:]) < 0.03 * np.mean(self.history[-3:]):
                self.reference = float(np.mean(self.history[-3:]))
            ref = self.reference
        res["reference_hz"] = ref
        if ref:
            ch = tone / ref - 1
            res["change_pct"] = round(100 * ch, 1)
            if ch < -0.03:
                res["cause"] = ("Its tone went DOWN. Adding mass or weakening a body can only lower tones; holding it "
                                "can only raise them. So: something heavy was added, or it got weaker (or the clamp "
                                "loosened). Holding it is ruled out.")
            elif ch > 0.03:
                res["cause"] = ("Its tone went UP. Only something holding the body (or a shorter overhang) can do that; "
                                "added mass and cracks are ruled out.")
            else:
                res["cause"] = "Same body as before (tone within 3% of the reference)."
        return res
