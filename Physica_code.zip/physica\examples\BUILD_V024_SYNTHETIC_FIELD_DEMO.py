"""Create a DEMONSTRATION-ONLY replay dataset, never real sensor evidence.

The future recording exists at demo-generation time; this checks integration
and numerical prospective forecasting, not trustworthy real chronology.
"""
import json, sys
from pathlib import Path
import numpy as np
from physica.frontier.curious_discovery import simulate


def main():
    root=Path(sys.argv[1] if len(sys.argv)>1 else 'demo/v024_synthetic_field').resolve()
    root.mkdir(parents=True,exist_ok=True)
    (root/'calibration.json').write_text(json.dumps({'method':'SIMULATED DATA ONLY — no physical calibration',
         'operator':'Synthetic fixture generator','date_utc':'2026-11-02','units':'SI','instrument':'Simulated acceleration measurements','physics_baseline':{'stiffness_s2':1.8,'damping_s1':.32,'control_gain':1.0}},indent=2))
    episodes={'train':[],'validation':[]}
    for i in range(5):
        name=f'episode_{i}.csv'
        data=simulate(210+i,'sin_affine',n=90)
        np.savetxt(root/name,data,delimiter=',',comments='',header='x_m,v_m_s,u_m_s2,acc_m_s2')
        episodes['train' if i<4 else 'validation'].append(name)
    (root/'manifest.json').write_text(json.dumps({'fixture_id':'SYNTHETIC_FIXTURE_DO_NOT_MISREPORT','calibration_file':'calibration.json',
                                           'episodes':episodes},indent=2))
    future=simulate(998,'sin_affine',n=90,initial=(.3,.18),control_bias=.02)
    plan={'fixture_id':'SYNTHETIC_FIXTURE_DO_NOT_MISREPORT','dt_s':.025,'x0_m':float(future[0,0]),
          'v0_m_s':float(future[0,1]),'controls_m_s2':future[:,2].tolist()}
    (root/'plan.json').write_text(json.dumps(plan,indent=2))
    np.savetxt(root/'future_SIMULATED.csv',np.column_stack((np.arange(len(future))*.025,future)),delimiter=',',comments='',
               header='time_s,x_m,v_m_s,u_m_s2,acc_m_s2')
    print(json.dumps({'kind':'SYNTHETIC_REPLAY_NOT_REAL_EVIDENCE','folder':str(root)},indent=2))

if __name__=='__main__':main()
