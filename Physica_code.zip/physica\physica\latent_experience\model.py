"""Learned linear latent state from synchronous sensor arrays; no known physical state assumed.

Sensor observations are NOT causal interventions. Causal claims only when action is
independently applied and logged. SVD+ridge is an explicit baseline, not a new foundation model.
"""
import numpy as np

def train(observed, actions, rank=2, ridge=1e-3):
    Y=np.asarray(observed,dtype=float); A=np.asarray(actions,dtype=float)
    if Y.ndim!=2 or Y.shape[0]<20 or Y.shape[1]<2 or A.shape!=(len(Y)-1,):
        raise ValueError('Need >=20 synchronized multisensory rows and one controlled action per transition')
    if not np.isfinite(Y).all() or not np.isfinite(A).all():raise ValueError('nonfinite sensor/action')
    if rank<1 or rank>min(Y.shape[1],Y.shape[0]-2):raise ValueError('invalid rank')
    mu=Y[:-1].mean(axis=0); scale=np.maximum(Y[:-1].std(axis=0),1e-8)
    _,_,V=np.linalg.svd((Y[:-1]-mu)/scale,full_matrices=False)
    basis=V[:rank].T; Z=((Y-mu)/scale)@basis
    X=np.c_[Z[:-1],A,np.ones(len(A))]; target=Z[1:]
    reg=ridge*np.eye(X.shape[1]);reg[-1,-1]=0
    co=np.linalg.solve(X.T@X+reg,X.T@target)
    residual=target-X@co
    return {'mu':mu.tolist(),'scale':scale.tolist(),'basis':basis.tolist(),'coef':co.tolist(),
            'transition_rmse':float(np.sqrt(np.mean(residual**2))),'n_train':len(A),
            'sensor_count':Y.shape[1],'rank':rank,'model':'PCA/SVD + ridge action-conditioned latent linear dynamics',
            'uncertainty':'in-sample residual only; not calibrated for shifted physics'}

def forecast(model,initial_senses,planned_actions):
    mu=np.asarray(model['mu']);scale=np.asarray(model['scale']);B=np.asarray(model['basis']);co=np.asarray(model['coef'])
    y=np.asarray(initial_senses,dtype=float);actions=np.asarray(planned_actions,dtype=float)
    if y.shape!=mu.shape or actions.ndim!=1 or not np.isfinite(y).all() or not np.isfinite(actions).all():raise ValueError('invalid forecast input')
    if len(actions)>10000:raise ValueError('horizon too large')
    z=((y-mu)/scale)@B; out=[]
    for a in actions:
        z=np.r_[z,a,1.]@co
        y_pred=(z@B.T)*scale+mu
        if not np.isfinite(y_pred).all() or np.max(np.abs(y_pred))>1e7: raise ValueError('unstable forecast: abstain')
        out.append(y_pred.tolist())
    return out

def evaluate(model,observed,actions,cutoff):
    Y=np.asarray(observed,dtype=float);A=np.asarray(actions,dtype=float)
    if not (0<cutoff<len(Y)-1) or A.shape!=(len(Y)-1,): raise ValueError('invalid split')
    pred=np.asarray(forecast(model,Y[cutoff],A[cutoff:]),dtype=float)
    truth=Y[cutoff+1:]
    if pred.shape!=truth.shape: raise ValueError('shape mismatch')
    persist=np.repeat(Y[cutoff:cutoff+1],len(truth),axis=0)
    return {'forecast_rmse':float(np.sqrt(np.mean((pred-truth)**2))),
            'persistence_rmse':float(np.sqrt(np.mean((persist-truth)**2))),
            'beats_persistence':bool(np.mean((pred-truth)**2)<np.mean((persist-truth)**2)),
            'horizon':len(truth)}
