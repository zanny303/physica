"""Optional, review-only Meta mechanism nomination via documented Responses JSON.

The LLM cannot set physical coefficients, erase evidence, or control hardware.
Its suggestions are enumerated candidates, never validated causal conclusions.
No network calls unless an operator passes --allow-billed-meta and has a key.
"""
from __future__ import annotations
import argparse,hashlib,json,os,urllib.request
from pathlib import Path

SUPPORTED=('cubic_stiffness','quadratic_drag','coulomb_friction','unknown','insufficient_evidence')
MECHANISM_SCHEMA={'type':'object','properties':{
    'candidate':{'type':'string','enum':list(SUPPORTED)},
    'why_testable':{'type':'string'},
    'discriminating_measurement':{'type':'string'},
    'unsupported_claims':{'type':'string'}},
    'required':['candidate','why_testable','discriminating_measurement','unsupported_claims'],
    'additionalProperties':False}

def make_request(context,model='muse-spark-1.3'):
    if model not in ('muse-spark-1.3','muse-wonder-1.0'):raise ValueError('unsupported model')
    if not isinstance(context,dict) or not context:raise ValueError('need sanitized experimental context')
    if any(x in context for x in ('api_key','auth','secret','future_outcome','test_truth','target_label')):
        raise ValueError('sensitive or test-outcome leakage')
    return {'model':model,'input':('You are suggesting one scientifically falsifiable PHYSICAL hypothesis. '
           'Propose only a supported mechanism or unknown/insufficient_evidence. '
           'Never assert coefficients, measurements, safety approvals, or causal proof. '
           'Suggest NON-ACTUATING observations only. Experimental context (not an answer key): '+
           json.dumps(context,sort_keys=True,allow_nan=False)),
            'text':{'format':{'type':'json_schema','name':'physica_review_candidate',
                     'schema':MECHANISM_SCHEMA,'strict':True}},'store':False}

def parse_candidate_response(raw):
    if not isinstance(raw,dict) or raw.get('status') not in (None,'completed'):raise ValueError('incomplete response')
    content=[]
    for item in raw.get('output',[]):
        if item.get('type')=='message':
            for piece in item.get('content',[]):
                if piece.get('type')=='output_text':content.append(piece.get('text',''))
    if len(content)!=1:raise ValueError('must have exactly one structured text result')
    data=json.loads(content[0]);
    if set(data)!=set(MECHANISM_SCHEMA['required']) or data['candidate'] not in SUPPORTED:
        raise ValueError('unsupported or malformed hypothesis')
    if any(not isinstance(data[k],str) for k in MECHANISM_SCHEMA['required']):raise ValueError('invalid field type')
    return {'candidate':data,'model':raw.get('model'),'response_id':raw.get('id'),
            'scientific_status':'UNVERIFIED_MODEL_NOMINATION_ONLY','no_actuation':True}

def run_live(context,model,allow_billed=False):
    if not allow_billed:raise ValueError('explicit --allow-billed-meta needed')
    key=os.environ.get('MODEL_API_KEY')
    if not key:raise RuntimeError('MODEL_API_KEY not set')
    payload=make_request(context,model)
    body=json.dumps(payload,allow_nan=False).encode('utf-8')
    from physica.llm import meta_client as mc
    raw=mc.post_raw('responses',json.loads(body),task='research_v09_candidate')
    result=parse_candidate_response(raw)
    result.update({'request_sha256':hashlib.sha256(body).hexdigest(),'origin':'AUTHENTICATED_META_API_RESPONSE',
                   'raw_response_sha256':hashlib.sha256(json.dumps(raw,sort_keys=True).encode()).hexdigest()})
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--context',required=True);p.add_argument('--out',required=True)
    p.add_argument('--model',default='muse-spark-1.3',choices=['muse-spark-1.3','muse-wonder-1.0'])
    p.add_argument('--allow-billed-meta',action='store_true');p.add_argument('--dry-run',action='store_true')
    a=p.parse_args();ctx=json.loads(Path(a.context).read_text(encoding='utf8'))
    result=({'origin':'OFFLINE_API_REQUEST_ONLY','request':make_request(ctx,a.model),
             'scientific_status':'NO_META_INFERENCE_EXECUTED'} if a.dry_run else run_live(ctx,a.model,a.allow_billed_meta))
    out=Path(a.out);out.parent.mkdir(exist_ok=True,parents=True)
    out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({'origin':result['origin'],'out':str(out)},indent=2))
if __name__=='__main__':main()
