"""Prospective cross-sensory field protocol. No unattended equipment control.

A: independently calibrated raw CSVs + local outcome attestation -> PEL word.
B: PEL + target calibration + timestamp grid -> signed forecast (NO B data).
B: after prediction is committed, record B CSV -> signed evaluation.
C: form a new B word from measured data, then repeat B->C prepare.

Signatures preserve content integrity, NOT third-party chronology/identity.
"""
from __future__ import annotations
import csv,hashlib,json
from pathlib import Path
from dataclasses import asdict
import numpy as np
from physica.library import sign as signer
from .signals import Channel,MechanicalContext
from .fusion import infer_state,physical_tokens
from .language import experience_record,translate,verify_record


def _canonical(data):return signer.canonical(data)
def _sha(raw):return hashlib.sha256(raw).hexdigest()
def _read_json(path):return json.loads(Path(path).read_text())
def _write(path,payload):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(payload,sort_keys=True,indent=2,allow_nan=False)+'\n')
    return str(p)


def read_timeseries(path,*,value_column='value',time_column='time_s'):
    raw=Path(path).read_bytes(); rows=list(csv.DictReader(raw.decode('utf-8-sig').splitlines()))
    if len(rows)<8 or time_column not in rows[0] or value_column not in rows[0]:
        raise ValueError('CSV requires >=8 rows with time_s/value columns')
    t=np.asarray([float(row[time_column]) for row in rows]);v=np.asarray([float(row[value_column]) for row in rows])
    if not np.all(np.isfinite(t)) or not np.all(np.isfinite(v)) or t[0]<0 or np.any(np.diff(t)<=0):
        raise ValueError('finite timestamp-aligned raw CSV required')
    return t,v,_sha(raw)


def read_times_only(path):
    raw=Path(path).read_bytes();rows=list(csv.DictReader(raw.decode('utf-8-sig').splitlines()))
    if len(rows)<8 or 'time_s' not in rows[0]:
        raise ValueError('target grid requires time_s and >=8 rows')
    # No target observation column may be present, even accidentally.
    if any(k!='time_s' for k in rows[0]):
        raise ValueError('preparation file MUST NOT contain target measurements')
    times=np.asarray([float(row['time_s']) for row in rows])
    if not np.all(np.isfinite(times)) or times[0]<0 or np.any(np.diff(times)<=0):
        raise ValueError('invalid target time grid')
    return times,_sha(raw)


def channel_from_csv(spec,ctx):
    t,raw,digest=read_timeseries(spec['path'],value_column=spec.get('value_column','value'))
    gain=float(spec['si_per_raw_unit'])
    if not np.isfinite(gain) or gain<=0:raise ValueError('calibration gain must be finite positive')
    return Channel(sensor_id=spec['sensor_id'],modality=spec['modality'],observable=spec['observable'],
        time_s=tuple(t),values=tuple(raw*gain),unit=spec['canonical_unit'],
        sigma=float(spec['si_sigma']),calibration_id=spec['calibration_id'],
        body_id=ctx.body_id,raw_unit=spec['raw_unit'],conversion_gain=gain,
        origin=spec['origin'],source_sha256=digest)


def signed_envelope(payload):
    digest=_sha(_canonical(payload))
    return {'protocol':'physica.field-sign/v1','payload':payload,'sha256':digest,
            'ed25519':signer.sign({'sha256':digest,'payload':payload}),
            'note':'signature authenticates content; no independent trusted timestamp'}


def verify_signed(envelope):
    try:
        d=envelope['payload'];h=_sha(_canonical(d))
        return (envelope['protocol']=='physica.field-sign/v1' and
                envelope['sha256']==h and signer.verify({'sha256':h,'payload':d},envelope['ed25519']))
    except (KeyError,ValueError,TypeError):return False


def source_from_manifest(manifest_path,out):
    spec=_read_json(manifest_path);ctx=MechanicalContext(**spec['body_context'])
    # A real observation must have independent attestation before it teaches B.
    # Attestation is not a proof that a real experiment happened; field demo
    # requires an external witness for credible hackathon validation.
    att=spec.get('source_attestation',{})
    if not att.get('supervisor_acknowledgement') or not att.get('attestation_file'):
        raise ValueError('source must include a separately recorded intervention outcome attestation')
    att_file=Path(att['attestation_file']);att_hash=_sha(att_file.read_bytes())
    sensors=[channel_from_csv(s,ctx) for s in spec['channels']]
    if any(s.origin!=ctx.provenance for s in sensors):raise ValueError('channel and body provenance mismatch')
    est=infer_state(sensors,ctx)
    token=physical_tokens(ctx,est,cause=spec['causal_hypothesis'],
         action_id=spec['action_id'],source_sha256s=[s.source_sha256 for s in sensors]+[att_hash],
         provenance=ctx.provenance,checked_outcome=True)
    envelope=experience_record(token,context_source='external_manifest_plus_attestation')
    payload={'pel':envelope,'attestation_sha256':att_hash,
             'body_context':asdict(ctx),'source_manifest_sha256':_sha(Path(manifest_path).read_bytes()),
             'evidence_sha256s':[s.source_sha256 for s in sensors],
             'context_notes':spec.get('context_notes',[]),
             'warning':'locally attested physical claim; not independently timestamped/verified'}
    result=signed_envelope(payload);_write(out,result)
    return {'status':'source_word_signed','output':str(out),
            'word_sha256':envelope['word_sha256'],
            'attestation_sha256':att_hash,'origin':ctx.provenance}


def prepare(source_signed_path,target_calibration_json,target_times_csv,out,*,modality,observable):
    source=_read_json(source_signed_path)
    if not verify_signed(source):raise ValueError('source signature invalid')
    word=source['payload']['pel'];ctx=MechanicalContext(**_read_json(target_calibration_json))
    ts,h=read_times_only(target_times_csv)
    predicted=translate(word,ctx,ts,target_modality=modality,target_observable=observable)
    if predicted['status']!='unverified_cross_sensory_forecast':
        raise ValueError('prediction refused: '+predicted['reason'])
    prediction={'body_calibration':asdict(ctx),'source_signed_sha256':source['sha256'],
        'source_word_sha256':word['word_sha256'], 'target_time_grid_sha256':h,
        'target_sensor_modality':modality,'target_observable':observable,
        'prediction':predicted,
        'status':'SEALED_BEFORE_TARGET_OBSERVATION (operator workflow assertion)',
        'hardware_actuation_allowed':False}
    result=signed_envelope(prediction);_write(out,result)
    return {'status':'prediction_signed_no_target_response_read','out':str(out),'sha256':result['sha256']}


def check(prepared_path,observed_csv,out,*,si_per_raw_unit,si_sigma):
    prepared=_read_json(prepared_path)
    if not verify_signed(prepared):raise ValueError('forecast commitment signature invalid')
    p=prepared['payload'];pred=p['prediction']
    ts,raw,h=read_timeseries(observed_csv)
    expected=np.asarray(pred['time_s']);observed=raw*float(si_per_raw_unit)
    if not np.isfinite(si_per_raw_unit) or si_per_raw_unit<=0 or not np.isfinite(si_sigma) or si_sigma<=0:
        raise ValueError('real sensor requires positive finite independent SI calibration')
    if expected.shape!=ts.shape or not np.allclose(expected,ts,rtol=0,atol=1e-9):
        raise ValueError('target response timestamps differ from signed commitment')
    pred_y=np.asarray(pred['predicted_values'])
    r=observed-pred_y
    report={'status':'measured_response_evaluated_not_preknown','commit_sha256':prepared['sha256'],
            'observed_raw_sha256':h,'measured_values_si':observed.tolist(),'time_s':ts.tolist(),
            'observed_unit':pred['target_unit'],'sensor_si_sigma':float(si_sigma),
            'prediction_error_rmse_si':float(np.sqrt(np.mean(r*r))),
            'prediction_error_max_abs_si':float(np.max(np.abs(r))),
            'target_body':p['body_calibration'],'target_modality':p['target_sensor_modality'],
            'target_observable':p['target_observable'],
            'note':'local comparison, NOT proof of global transfer or independent experiment chronology'}
    signed=signed_envelope(report);_write(out,signed)
    return {'status':'signed_post_observation','out':str(out),'rmse_si':report['prediction_error_rmse_si'],
            'raw_observed_sha256':h}


def learn_next(signed_check_path, target_sensor_spec_json,out,*,action_id,causal_hypothesis):
    reveal=_read_json(signed_check_path)
    if not verify_signed(reveal):raise ValueError('signed measurement invalid')
    info=reveal['payload'];ctx=MechanicalContext(**info['target_body'])
    spec=_read_json(target_sensor_spec_json)
    c=channel_from_csv(spec,ctx)
    if c.source_sha256!=info['observed_raw_sha256']:
        raise ValueError('observed CSV differs from verified reveal')
    est=infer_state([c],ctx)
    token=physical_tokens(ctx,est,cause=causal_hypothesis,action_id=action_id,
        source_sha256s=[c.source_sha256, reveal['sha256']],provenance=ctx.provenance,
        checked_outcome=True)
    envelope=experience_record(token,context_source='signed_prior_prediction_plus_observed_measurement')
    nxt=signed_envelope({'pel':envelope,'parent_reveal_sha256':reveal['sha256'],
                        'body_context':asdict(ctx),'warning':'new physical experience is provisional, conditioned on local model'})
    _write(out,nxt)
    return {'status':'new_source_experience_for_next_machine','out':str(out),'sha256':nxt['sha256']}
