"""Dimensionless, falsifiable missing-mechanism transfer for measured kinematics.

Requires synchronized and independently calibrated displacement, velocity,
acceleration and force. This is *not* inferred from raw microphone pressure or
from an image model. Mechanism discovery uses intervention-disjoint validation.
Records transfer an acceleration/force relationship to an unfamiliar body,
not arbitrary synthetic trajectories or new physical laws.
"""
from __future__ import annotations
import hashlib
import math
import numpy as np
from physica.library import sign
from .core import Body

FEATURES=('cubic_elasticity','quadratic_drag','smooth_contact_friction')


def feature(body, x, v, name, displacement_reference_m):
    x=np.asarray(x,float);v=np.asarray(v,float)
    if name=='cubic_elasticity':
        return body.stiffness_n_m*x**3/displacement_reference_m**2
    if name=='quadratic_drag':
        return body.stiffness_n_m*displacement_reference_m * (
            v*np.abs(v))/max((displacement_reference_m*np.sqrt(body.stiffness_n_m/body.mass_kg))**2,1e-16)
    if name=='smooth_contact_friction':
        return body.force_reference_n*np.tanh(v/body.slip_velocity_scale_m_s)
    raise ValueError('unsupported intervention mechanism')


def _load(ep,body):
    vals=[np.asarray(ep[k],float) for k in ('displacement_m','velocity_m_s','acceleration_m_s2','force_n')]
    if not ep.get('intervention_id') or any(x.ndim!=1 or len(x)<16 or len(x)!=len(vals[0]) or not np.all(np.isfinite(x)) for x in vals):
        raise ValueError('requires synchronized calibrated x, v, acceleration, force and action id')
    if np.max(np.abs(vals[3]))>body.max_authorized_force_n:
        raise ValueError('force exceeds approved model envelope')
    return vals


def _residual(body,ep):
    x,v,a,f=_load(ep,body)
    return f-body.mass_kg*a-body.damping_n_s_m*v-body.stiffness_n_m*x


def discover_and_sign(body:Body, training:list, heldout:list,*, displacement_reference_m,
                      allowed_mechanisms=FEATURES,minimum_heldout_gain=.20,
                      max_heldout_relative_error=.30, measurement_noise_force_n=.0005):
    """Choose a dimensionless coefficient by separate interventions.

    If *no* dictionary candidate explains held-out residual, return UNKNOWN.
    That is open-set rejection, not discovery of arbitrary laws.
    """
    if not (len(training)>=2 and len(heldout)>=1):raise ValueError('need 2 train + 1 independent heldout')
    ids=[ep.get('intervention_id') for ep in training+heldout]
    if len(set(ids))!=len(ids) or any(not x for x in ids):raise ValueError('intervention leakage')
    if not(math.isfinite(displacement_reference_m) and displacement_reference_m>0 and
           0<minimum_heldout_gain<1 and 0<max_heldout_relative_error<1 and
           math.isfinite(measurement_noise_force_n) and measurement_noise_force_n>0):
        raise ValueError('invalid identification policy')
    if not allowed_mechanisms or any(k not in FEATURES for k in allowed_mechanisms):
        raise ValueError('unapproved mechanism family')
    for ep in training+heldout:_load(ep,body)
    rtr=np.concatenate([_residual(body,ep) for ep in training]);rte=np.concatenate([_residual(body,ep) for ep in heldout])
    baseline=float(np.sqrt(np.mean(rte**2)));evaluations=[]
    for name in allowed_mechanisms:
        X=np.concatenate([feature(body,*_load(ep,body)[:2],name,displacement_reference_m) for ep in training])
        Y=np.concatenate([feature(body,*_load(ep,body)[:2],name,displacement_reference_m) for ep in heldout])
        denom=float(X@X)
        if denom<1e-15:
            evaluations.append({'mechanism':name,'status':'UNOBSERVABLE'});continue
        beta=float((X@rtr)/denom)
        rmse=float(np.sqrt(np.mean((rte-beta*Y)**2)))
        improvement=1-rmse/max(baseline,measurement_noise_force_n)
        # An approximate noise-conditioned coefficient uncertainty; cannot
        # replace independent calibration of mass, stiffness or derivative.
        sigma=measurement_noise_force_n/math.sqrt(denom)
        evaluations.append({'mechanism':name,'status':'TESTED_HELDOUT','dimensionless_coefficient':beta,
                            'coefficient_sigma_model_conditional':sigma,
                            'validation_force_rmse_n':rmse,'heldout_gain':improvement})
    valid=[q for q in evaluations if q['status']=='TESTED_HELDOUT']
    winner=min(valid,key=lambda q:q['validation_force_rmse_n']) if valid else None
    if not winner or winner['heldout_gain']<minimum_heldout_gain or winner['validation_force_rmse_n']>max_heldout_relative_error*max(baseline,measurement_noise_force_n):
        return {'status':'UNKNOWN_MECHANISM_OR_INSUFFICIENT_EVIDENCE','candidates':evaluations,
                'known_physics_heldout_rmse_n':baseline,'no_actuation':True}
    payload={'schema':'physica.felt-mechanism-transport.v07','mechanism':winner['mechanism'],
            'dimensionless_coefficient':winner['dimensionless_coefficient'],
            'coefficient_sigma_model_conditional':winner['coefficient_sigma_model_conditional'],
            'source_body':{'id':body.body_id,'boundary_class':body.boundary_class,'mechanism_family':body.mechanism_family,
                           'mass_kg':body.mass_kg,'stiffness_n_m':body.stiffness_n_m,'damping_n_s_m':body.damping_n_s_m},
            'training_intervention_ids':ids[:len(training)],'heldout_intervention_ids':ids[len(training):],
            'source_episode_sha256':[hashlib.sha256(sign.canonical(ep)).hexdigest() for ep in training+heldout],
            'source_displacement_reference_m':displacement_reference_m,
            'measurement_noise_force_n':measurement_noise_force_n,
            'evidence_origin':body.provenance,'validated_force_rmse_n':winner['validation_force_rmse_n'],
            'note':'dictionary-conditional and synthetic unless independently measured; requires target probe'}
    return {'status':'CANDIDATE_SIGNED_REQUIRES_TARGET_PROBE','record':{'payload':payload,
            'sha256':hashlib.sha256(sign.canonical(payload)).hexdigest(),
            'signature_ed25519':sign.sign(payload)},'candidates':evaluations,
            'known_physics_heldout_rmse_n':baseline,'no_actuation':True}


def make_target_probe_certificate(source, target:Body, measured_episode, *,displacement_reference_m,
                                  measurement_noise_force_n=.0005, max_normalized_rmse=3.):
    """Evaluate the *actual signed raw target probe* before any transfer.

    This record authenticates a local measurement; it does not independently
    establish timing or sensor calibration, and never authorizes actuation.
    """
    if source.get('status')!='CANDIDATE_SIGNED_REQUIRES_TARGET_PROBE':
        raise ValueError('unverified source lesson')
    if not(math.isfinite(measurement_noise_force_n) and measurement_noise_force_n>0 and
           math.isfinite(max_normalized_rmse) and max_normalized_rmse>0 and
           math.isfinite(displacement_reference_m) and displacement_reference_m>0):
        raise ValueError('invalid probe policy')
    x,v,a,f=_load(measured_episode,target)
    if source['record']['payload']['source_body']['boundary_class']!=target.boundary_class:
        raise ValueError('incompatible target boundary')
    p=source['record']['payload']
    beta=float(p['dimensionless_coefficient'])
    additional=beta*feature(target,x,v,p['mechanism'],displacement_reference_m)
    predicted=(f-target.damping_n_s_m*v-target.stiffness_n_m*x-additional)/target.mass_kg
    rmse=float(np.sqrt(np.mean((predicted-a)**2)))
    normalized=rmse/(measurement_noise_force_n/target.mass_kg)
    payload={'schema':'physica.felt-mechanism-probe.v07',
             'source_hash':source['record']['sha256'],
             'target':{'id':target.body_id,'mass_kg':target.mass_kg,
                       'stiffness_n_m':target.stiffness_n_m,'damping_n_s_m':target.damping_n_s_m,
                       'boundary_class':target.boundary_class,'mechanism_family':target.mechanism_family},
             'displacement_reference_m':displacement_reference_m,
             'measured_episode':{k:measured_episode[k] for k in ('intervention_id','displacement_m',
                                 'velocity_m_s','acceleration_m_s2','force_n')},
             'measurement_noise_force_n':measurement_noise_force_n,
             'max_normalized_rmse':max_normalized_rmse,
             'reported_normalized_rmse':normalized}
    return {'payload':payload,'sha256':hashlib.sha256(sign.canonical(payload)).hexdigest(),
            'signature_ed25519':sign.sign(payload),
            'status':'ACCEPT_PROBE_MODEL_CONDITIONAL' if normalized<=max_normalized_rmse
            else 'REFUSE_PROBE_MISMATCH'}


def _recheck_probe(source,target,cert,reference):
    if not isinstance(cert,dict) or not isinstance(cert.get('payload'),dict):return False
    p=cert['payload']
    if cert.get('sha256')!=hashlib.sha256(sign.canonical(p)).hexdigest() or not sign.verify(p,cert.get('signature_ed25519','')):
        return False
    if p.get('schema')!='physica.felt-mechanism-probe.v07' or p.get('source_hash')!=source['record']['sha256']:
        return False
    b=p.get('target',{})
    if any(b.get(key)!=value for key,value in (
        ('id',target.body_id),('mass_kg',target.mass_kg),('stiffness_n_m',target.stiffness_n_m),
        ('damping_n_s_m',target.damping_n_s_m),('boundary_class',target.boundary_class),
        ('mechanism_family',target.mechanism_family))):return False
    if p.get('displacement_reference_m')!=reference:return False
    try:
        x,v,a,f=_load(p['measured_episode'],target)
        beta=source['record']['payload']['dimensionless_coefficient']
        extra=beta*feature(target,x,v,source['record']['payload']['mechanism'],reference)
        rmse=float(np.sqrt(np.mean(((f-target.damping_n_s_m*v-target.stiffness_n_m*x-extra)/target.mass_kg-a)**2)))
        noise=float(p['measurement_noise_force_n']);cutoff=float(p['max_normalized_rmse'])
        return (math.isfinite(noise) and noise>0 and math.isfinite(cutoff) and 0<cutoff<=3.
                and math.isfinite(float(p['reported_normalized_rmse']))
                and abs(rmse/(noise/target.mass_kg)-float(p['reported_normalized_rmse']))<1e-8
                and rmse/(noise/target.mass_kg)<=cutoff)
    except (KeyError,ValueError,TypeError,ZeroDivisionError):return False


def predict_target_acceleration(record,target:Body,forecast_request,*,displacement_reference_m,probe_certificate=None):
    """Conditional acceleration prediction. Never permits actuation."""
    if record.get('status')!='CANDIDATE_SIGNED_REQUIRES_TARGET_PROBE':
        return {'status':'REFUSE_UNVERIFIED_SOURCE'}
    r=record['record'];p=r['payload']
    if hashlib.sha256(sign.canonical(p)).hexdigest()!=r.get('sha256') or not sign.verify(p,r.get('signature_ed25519','')):
        return {'status':'REFUSE_INVALID_SOURCE_SIGNATURE'}
    if p['evidence_origin']=='simulation' and target.provenance!='simulation':
        return {'status':'REFUSE_SIMULATION_NOT_REAL_EVIDENCE'}
    if p['source_body']['boundary_class']!=target.boundary_class:
        return {'status':'REFUSE_BOUNDARY_INCOMPATIBLE'}
    if p['source_body']['mechanism_family']!=target.mechanism_family:
        return {'status':'REFUSE_MECHANISM_INCOMPATIBLE'}
    ratio=math.sqrt(target.stiffness_n_m/target.mass_kg)/math.sqrt(p['source_body']['stiffness_n_m']/p['source_body']['mass_kg'])
    if not .5<=ratio<=2.:return {'status':'REFUSE_OUTSIDE_VALIDATED_FREQUENCY_FAMILY'}
    if not(math.isfinite(displacement_reference_m) and displacement_reference_m>0):
        raise ValueError('independent target displacement reference required')
    if probe_certificate is None:return {'status':'PROBE_FIRST'}
    if not _recheck_probe(record,target,probe_certificate,displacement_reference_m):
        return {'status':'REFUSE_PROBE_INVALID_OR_MISMATCH'}
    # Strict prospective field separation: target acceleration is NOT an input.
    # Only calibrated observed kinematics and applied action are permitted.
    if 'acceleration_m_s2' in forecast_request:
        return {'status':'REFUSE_TARGET_OUTCOME_LEAKAGE'}
    required=('displacement_m','velocity_m_s','force_n')
    try:
        x,v,f=[np.asarray(forecast_request[k],float) for k in required]
        if not forecast_request.get('intervention_id') or any(a.ndim!=1 or len(a)<16 or len(a)!=len(x)
            or not np.all(np.isfinite(a)) for a in (x,v,f)) or np.max(np.abs(f))>target.max_authorized_force_n:
            return {'status':'REFUSE_INVALID_FORECAST_REQUEST'}
    except (KeyError,TypeError,ValueError):
        return {'status':'REFUSE_INVALID_FORECAST_REQUEST'}
    beta=float(p['dimensionless_coefficient'])
    feat=feature(target,x,v,p['mechanism'],displacement_reference_m)
    predicted=(f-target.damping_n_s_m*v-target.stiffness_n_m*x-beta*feat)/target.mass_kg
    return {'status':'MODEL_CONDITIONAL_TARGET_FORECAST','predicted_acceleration_m_s2':predicted.tolist(),
            'mechanism':p['mechanism'],'dimensionless_coefficient':beta,
            'source_lesson_sha256':r['sha256'],'probe_sha256':probe_certificate['sha256'],
            'hardware_actuation_allowed':False,
            'caution':'prediction conditioned on observed target kinematics, not prospective unobserved motion'}
