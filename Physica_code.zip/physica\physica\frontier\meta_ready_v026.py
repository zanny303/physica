"""Key-safe Meta Model API preflight and explicitly billable connectivity test.

No credential is ever printed, transmitted to a log file, or required by offline
regression tests. The underlying Meta client handles provider receipts and costs.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path


def diagnose()->dict:
    from physica.llm.meta_client import api_key,base_url,mode,model_id,budget_usd
    from .mechanism_dsl import meta_response_schema
    configured=bool(api_key())
    mock_enabled=os.environ.get('MOCK','1')!='0'
    budget=float(budget_usd())
    return {'stage':'OFFLINE_META_READINESS_DIAGNOSTIC',
            'api_key_present':configured,'mock_explicitly_disabled':not mock_enabled,
            'live_enabled':configured and not mock_enabled,
            'api_endpoint':base_url()+'/chat/completions',
            'wonder_model':model_id('wonder'),'spark_model':model_id('spark'),
            'structured_json_schema_defined':meta_response_schema()['type']=='json_schema',
            'local_budget_usd':budget,
            'local_budget_is_not_provider_billing_guarantee':True,
            'note':'No network request made, and authentication not verified by this command. Never paste your API key into chat.'}


def smoke(*,allow_billed_meta:bool=False,role:str='wonder')->dict:
    if not allow_billed_meta:raise PermissionError('Live smoke test requires --allow-billed-meta')
    if role not in ('spark','wonder'):raise ValueError('Unknown Meta role')
    state=diagnose()
    if not state['live_enabled']:raise PermissionError('Set MODEL_API_KEY and MOCK=0 locally')
    from physica.llm.meta_client import complete
    props={'message':{'type':'string'},'physica_verified':{'type':'boolean'}}
    fmt={'type':'json_schema','json_schema':{'name':'PhysicaV026LiveConnectivity',
         'strict':True,'schema':{'type':'object','properties':props,
                                  'required':list(props),'additionalProperties':False}}}
    messages=[{'role':'system','content':'Return a brief connectivity confirmation. physica_verified MUST be false because no physical experiment occurred.'},
              {'role':'user','content':'Confirm structured API response only. Have you witnessed a physical experiment?'}]
    reply=complete(role,messages,'physica_v026_live_smoke',response_format=fmt,
                   max_completion_tokens=2000,require_fresh=True)
    from .meta_council_v026 import _verified
    source=_verified(reply,expected_role=role,task='physica_v026_live_smoke')
    if not reply.get('content'):
        raise RuntimeError(f"Meta accepted the key but returned no answer (finish_reason: {reply.get('finish_reason')}). "
                           "Muse thinks before it answers, and thinking counts against the reply limit.")
    payload=json.loads(reply['content'])
    if set(payload)!={'message','physica_verified'} or payload['physica_verified'] is not False:
        raise RuntimeError('Provider claimed to verify an unperformed physical experiment')
    return {'stage':'LIVE_META_CONNECTIVITY_VERIFIED_NOT_PHYSICS',
            'provider_receipt':source,'model':reply['model'],
            'actual_physical_experiment_verified':False,
            'scientific_hypothesis_tested':False}


def main():
    p=argparse.ArgumentParser(description='Meta key-safe readiness and explicit live connectivity test')
    p.add_argument('command',choices=('doctor','live-smoke'))
    p.add_argument('--role',choices=('spark','wonder'),default='wonder')
    p.add_argument('--allow-billed-meta',action='store_true')
    p.add_argument('--out')
    a=p.parse_args()
    result=diagnose() if a.command=='doctor' else smoke(allow_billed_meta=a.allow_billed_meta,role=a.role)
    if a.out:
        out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps(result,indent=2,allow_nan=False))

if __name__=='__main__':main()
