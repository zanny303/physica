"""Reproducible *synthetic* 'one machine teaches another' vignette.

Never describe this as physical or model API validation. It demonstrates the
protocol, the prediction->observation->learning loop and a transfer benchmark.
"""
from __future__ import annotations

from datetime import datetime,timezone
import json
from pathlib import Path
import numpy as np

from .schema import (PhysicalEpisode,ModalWord,Quantity,Sensor,Action,Hypothesis,
                     Consequence,Provenance)
from .pacer import Experiment,update,choose_experiment,identifiability
from .transfer import transfer_prior,compare
from .seal import seal,reveal,write_json,verify_seal,verify_reveal
from .store import add,query

HYPOTHESES=("imbalance","loose_mount","bearing_wear")


def toy_actions():
    # Normalized vibration response. Fixed in advance by this controlled simulator.
    return [
        Experiment("listen_only",dict(zip(HYPOTHESES,[1.35,1.37,1.33])),sigma=.14,risk=0.,note="passive vibration"),
        Experiment("guarded_speed_step",dict(zip(HYPOTHESES,[2.10,1.80,1.31])),sigma=.15,risk=.04,note="guarded low-voltage fan only"),
        Experiment("mount_compliance_check",dict(zip(HYPOTHESES,[1.03,2.42,1.17])),sigma=.45,risk=.02,note="fan OFF, hand check mount"),
        Experiment("unguarded_destructive_test",dict(zip(HYPOTHESES,[5.0,6.0,7.0])),sigma=.01,risk=.99,irreversible=True,safety_approved=False),
    ]


def make_episode(machine:str, body:str, probs:dict[str,float], *, measured:bool,
                 modal_frequency:float, observation:float|None=None):
    words=[ModalWord(mode_id="1",frequency=Quantity(value=modal_frequency,unit="Hz",sigma=.1),
                     damping_ratio=Quantity(value=.025,unit="1",sigma=.004),
                     excitation_level=Quantity(value=.40,unit="1",sigma=.02),shape=[1.,.6,.3]),
           ModalWord(mode_id="2",frequency=Quantity(value=2.12*modal_frequency,unit="Hz",sigma=.2),
                     damping_ratio=Quantity(value=.04,unit="1",sigma=.01),
                     excitation_level=Quantity(value=.40,unit="1",sigma=.02),shape=[.2,.8,.7])]
    # In the simulator the predicted consequence for a loose mount is 2.42.
    return PhysicalEpisode(
        episode_id=f"synthetic-{machine}-001",body_id=body,machine_id=machine,
        body_class="small_guarded_fan",boundary_class="bolted_base",
        sensors=[Sensor(sensor_id="simulated_accelerometer",modality="acceleration",sampling_rate_hz=Quantity(value=500,unit="Hz"),
                        calibrated=True,calibration_id="simulator-exact-units-v1",frame="fan_mount")],
        action=Action(action_id="mount_compliance_check",action_type="mount_compliance_check",
                      safety_approved=True,risk_score=.02),
        modal_words=words,hypotheses=[Hypothesis(hypothesis_id=k,posterior=v,identifiable=measured)
                                    for k,v in probs.items()],
        consequence=Consequence(observable="normalized_mount_response",predicted=Quantity(value=2.42,unit="1",sigma=.45),
                                observed=Quantity(value=observation,unit="1",sigma=.02) if observation is not None else None,
                                outcome="verified" if measured else "pending",reversible=True,
                                note="Synthetic numbers; not a physical fan run"),
        provenance=Provenance(origin="simulation",source_uri="physica/experience/demo.py",
                              evidence_note="No hardware involved. Sensor calibration refers only to numerical simulator."),
    )


def run_demo(output_dir:str|Path,seed:int=11) -> dict:
    root=Path(output_dir);root.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(seed)
    action=next(e for e in toy_actions() if e.action_id=="mount_compliance_check")
    prior={h:1./len(HYPOTHESES) for h in HYPOTHESES}
    # Machine A: predicts, cryptographically commits, then the simulator reveals.
    source_pre=make_episode("machine-A","fan-A",prior,measured=False,modal_frequency=23.4)
    sealed=seal(source_pre)
    observation=float(rng.normal(2.42,.07))
    observed=reveal(sealed,Quantity(value=observation,unit="1",sigma=.02))
    observed_posterior=update(prior,action,observation)
    source=make_episode("machine-A","fan-A",observed_posterior,measured=True,
                        modal_frequency=23.4,observation=observation)
    # Signed reveal is the evidence. Updated posterior is in a *separately* signed
    # follow-up episode, not retroactively inserted into the original commitment.
    revised=make_episode("machine-A","fan-A",observed_posterior,measured=False,modal_frequency=23.4)
    revised.episode_id="synthetic-machine-A-learned-002"
    revised.consequence.predicted=Quantity(value=observation,unit="1",sigma=.20)
    revised_seal=seal(revised)
    revised_reveal=reveal(revised_seal,Quantity(value=observation,unit="1",sigma=.02))
    write_json(root/"sealed_before_observation.json",sealed)
    write_json(root/"revealed_consequence.json",observed)
    write_json(root/"learned_episode.json",revised_reveal)
    store=root/"physical_bank"
    add(store,revised_reveal)
    target=make_episode("machine-B","fan-B",prior,measured=False,modal_frequency=20.7)
    target.episode_id="synthetic-machine-B-query"
    target.consequence.predicted=Quantity(value=2.42,unit="1",sigma=.45)
    rows=query(store,target)
    transferred=transfer_prior(source,target,baseline=prior,strength=0.30)
    selected=choose_experiment(transferred["prior"],toy_actions())
    no_bank=choose_experiment(prior,toy_actions())
    # Held-out *simulated* observation on B, after first experiment recommendation.
    b_action=next(a for a in toy_actions() if a.action_id==selected["chosen"])
    actual_b=float(rng.normal(b_action.means["loose_mount"],b_action.sigma))
    posterior_b=update(transferred["prior"],b_action,actual_b)
    posterior_b_no_transfer=update(prior,b_action,actual_b)
    experiment_result={
        "evidence":"SYNTHETIC_SIMULATOR_ONLY","seed":seed,
        "machine_A_posterior":observed_posterior,
        "machine_B_transfer":transferred,
        "bank_matches":rows,
        "safe_experiment_with_bank":selected,
        "safe_experiment_without_bank":no_bank,
        "machine_B_observation":actual_b,
        "machine_B_posterior_with_bank":posterior_b,
        "machine_B_posterior_without_bank":posterior_b_no_transfer,
        "machine_B_identifiability":identifiability(posterior_b,[b_action]),
        "seal_valid":verify_seal(sealed),"reveal_valid":verify_reveal(observed),
        "note":"No source videos, hardware, or Meta API calls used; this tests software protocol behavior."
    }
    write_json(root/"demo_results.json",experiment_result)
    from .ui import render_demo
    render_demo(root)
    from .consequence import consequence_path
    write_json(root/"bracket_whatif_simulation.json", {"status":"SYNTHETIC_ONLY","samples":consequence_path()})
    return experiment_result
