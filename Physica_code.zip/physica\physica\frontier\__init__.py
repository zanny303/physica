"""Experimental, bounded physical-intelligence evaluations."""
