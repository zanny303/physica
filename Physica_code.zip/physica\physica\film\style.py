"""One look for every clip: 1920x1080, dark, big type, and a provenance label that is always on screen."""
from __future__ import annotations

import textwrap
from pathlib import Path

BG, FG, DIM, TEAL, AMBER, RED, LINE = "#0b1118", "#eef5fb", "#8aa0b4", "#4fe3c1", "#f2b84b", "#ff6b6b", "#26384a"
FPS = 30


def fade(t: float, start: float, length: float = 0.5) -> float:
    return float(min(max((t - start) / length, 0.0), 1.0))


def ease(x: float) -> float:
    x = min(max(x, 0.0), 1.0)
    return x * x * (3 - 2 * x)


def new_figure():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig = plt.figure(figsize=(19.2, 10.8), dpi=100)
    fig.patch.set_facecolor(BG)
    return fig


def label(fig, text: str) -> None:
    """Where this data came from. Never leaves the screen."""
    fig.text(0.975, 0.955, text, color=AMBER, fontsize=15, ha="right", va="center", fontweight="bold",
             bbox=dict(boxstyle="round,pad=0.45", fc="#231c0d", ec=AMBER, lw=1.2))


def headline(fig, text: str, alpha: float = 1.0, y: float = 0.955, size: int = 34) -> None:
    fig.text(0.03, y, text, color=FG, fontsize=size, fontweight="bold", va="center", alpha=alpha)


def caption(fig, text: str, alpha: float = 1.0, width: int = 110) -> None:
    fig.text(0.5, 0.045, "\n".join(textwrap.wrap(text, width)), color=DIM, fontsize=19, ha="center", va="center", alpha=alpha)


def axes(fig, rect, off: bool = False):
    ax = fig.add_axes(rect)
    ax.set_facecolor(BG)
    if off:
        ax.axis("off")
    else:
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)
        for s in ("left", "bottom"):
            ax.spines[s].set_color(LINE)
        ax.tick_params(colors=DIM, labelsize=14)
        ax.xaxis.label.set_color(DIM)
        ax.yaxis.label.set_color(DIM)
        ax.xaxis.label.set_size(16)
        ax.yaxis.label.set_size(16)
    return ax


def render(path: str | Path, draw, seconds: float) -> str:
    """draw(fig, t) paints one frame. Needs ffmpeg."""
    from matplotlib.animation import FFMpegWriter
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig = new_figure()
    writer = FFMpegWriter(fps=FPS, codec="libx264", extra_args=["-pix_fmt", "yuv420p", "-crf", "20", "-preset", "veryfast"])
    with writer.saving(fig, str(path), dpi=100):
        for i in range(int(seconds * FPS)):
            fig.clf()
            fig.patch.set_facecolor(BG)
            draw(fig, i / FPS)
            writer.grab_frame(facecolor=BG)
    return str(path)
