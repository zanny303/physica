"""python -m physica.film turbine --out turbine.mp4   Clips from saved results or your own films. No data download, and no API."""
from __future__ import annotations

import argparse
import json
from importlib import import_module
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser(prog="physica.film")
    ap.add_argument("clip", choices=["turbine", "downtime", "opening", "overlay", "twin-beside-real", "seal", "card", "table", "ending", "hear", "feel", "reveal", "tacoma", "pack"])
    ap.add_argument("files", nargs="*")
    ap.add_argument("--out", default=None)
    ap.add_argument("--fps", type=float, help="the film's real frames per second")
    ap.add_argument("--banner", default="REAL FILM")
    ap.add_argument("--active", default=None, help="whose turn on the ribbon: MUSE, SAM, PHYSICA or REALITY")
    ap.add_argument("--text", default=None)
    ap.add_argument("--anchor", default="")
    ap.add_argument("--line", default="The prediction")
    ap.add_argument("--name", default="ruler", help="twin-beside-real: the ruler session. feel and reveal: the cables session, like cables")
    ap.add_argument("--pred", type=int, default=1)
    ap.add_argument("--hz", type=float)
    ap.add_argument("--damping", type=float, default=0.02)
    ap.add_argument("--times", type=float, default=16.0)
    a = ap.parse_args()
    from physica.film import story as ST
    out = a.out or f"{a.clip}.mp4"
    if a.clip == "pack":
        r = ST.pack(a.out or "demo_clips")
        print(f"\n{len(r['made'])} clips in {r['folder']}.")
        for n, why in r["missing"]:
            print(f"Missing {n}: {why}")
        print("Still yours to add: your voice, and music.")
        return
    if a.clip in ("turbine", "downtime"):
        print("Saved", import_module(f"physica.film.{a.clip}").render(out))
    elif a.clip == "opening":
        if not a.files or not a.fps:
            raise SystemExit("opening needs your film of the test motion and --fps")
        print("Saved", ST.opening(a.files[0], out, a.fps))
    elif a.clip == "overlay":
        print("Saved", ST.overlay(a.files[0], out, a.banner, a.active, a.text))
    elif a.clip == "twin-beside-real":
        tw = Path("physica_sessions") / f"{a.name}_twin.json"
        d = json.loads(tw.read_text())
        s = d["sealed"][a.pred - 1]
        if not s.get("grade"):
            raise SystemExit("grade that forecast first: python -m physica.cli ruler grade real.mp4 --pred " + str(a.pred))
        print("Saved", ST.twin_beside_real(tw, a.files[0], s, s["grade"], out))
    elif a.clip == "seal":
        print("Saved", ST.seal_clip(out, a.anchor, a.line))
    elif a.clip in ("feel", "reveal"):
        sess = json.loads((Path("physica_sessions") / f"{a.name}_cables.json").read_text())
        if a.clip == "feel":
            if not a.files or not a.fps:
                raise SystemExit("feel needs your film and --fps")
            print("Saved", ST.feel_film(a.files[0], out, a.fps, sess))
        else:
            if not sess.get("graded"):
                raise SystemExit("run cables reveal first, so there's a real result to show")
            print("Saved", ST.reveal_clip(out, sess["graded"]))
    elif a.clip == "tacoma":
        from physica.meta import cases as CS
        film = a.files[0] if a.files else CS.CLIPS / CS.TACOMA["file"]
        print("Saved", ST.sway_clip(film, a.out or CS.CLIPS / "tacoma_read.mp4", CS.read_sway(film)))
    elif a.clip == "card":
        print("Saved", ST.card(out))
    elif a.clip == "table":
        print("Saved", ST.table(out))
    elif a.clip == "ending":
        print("Saved", ST.ending(out))
    else:
        if a.hz is None:
            raise SystemExit("hear needs --hz, a measured tone")
        print("Saved", ST.hear(a.out or "hear.wav", a.hz, a.damping, a.times))


if __name__ == "__main__":
    main()
