# Data

Raw data is never committed. Point Physica at your local copies with environment variables (see `.env.example`).

## Wind turbine blade in a climate chamber (E20)

ETH Zürich small-scale wind turbine blade benchmark: a Windspot 3.5 kW blade (1.75 m, 5 kg), eight accelerometers,
white-noise shaker, −15 to +40 °C; healthy, added masses (ice stand-ins) and growing cracks. Article: Ou, Tatsis,
Dertimanis, Spiridonakos, Chatzi, Struct. Control Health Monit. 28 (2021) e2660 (CC BY-NC 4.0); full data on Zenodo
(record 3229743). Physica uses the power-spectra extract in `data/PSD_file.zip` of
`git clone https://github.com/josepfontm/EOVmitigation`; unzip it and set `PHYSICA_BLADE_PSD=<folder of .npz>`.

## KW51 railway bridge (E21)

Maes & Lombaert, "Monitoring railway bridge KW51 before, during, and after retrofitting", J. Bridge Eng. 26(3) 2021;
data doi:10.5281/zenodo.3745914 (CC BY-NC-SA 4.0, as listed on Zenodo). Download `trackedmodes.zip` (13 MB), unzip, run
`python eval/e21_kw51_bridge.py trackedmodes.mat`.

## DROPBEAR: a real beam with a hidden sliding support (E16, E19)

Two testbeds from the University of South Carolina ARTS-Lab / High-Rate SHM Working Group, both **CC BY-SA 4.0**.
A linear actuator slides a roller support along a clamped steel beam; a linear transducer measures where it is.
Physica never sees the transducer: it is used only to score.

- **Beam A, Dataset-2** (352.5 x 50.8 x 6.35 mm, tip accelerometer, 25.6 kHz, 44 s; includes the authors' own
  real-time model-updating estimates, used as the published comparison):
  `git clone https://github.com/High-Rate-SHM-Working-Group/Dataset-2-DROPBEAR-Acceleration-vs-Roller-Displacement`
  then `PHYSICA_DROPBEAR2=<clone>/data/DROPBEAR_dataset_with_model_updating_reuslts.json`.
  Cite: Downey et al., "Millisecond Model Updating for Structures Experiencing Unmodeled High-rate Dynamic Events",
  Mech. Syst. Signal Process. 138 (2020) 106551.
- **Beam B, Dataset-8** (501 x 51 x 6.66 mm, two accelerometers and two strain gauges, 5 kHz, 50 trials of 12 s plus
  two slow sweeps; position as transducer volts, 45 mm/V from the 225 mm / 5 V sensor listing, offset unknown):
  `git clone https://github.com/High-Rate-SHM-Working-Group/Dataset-8-DROPBEAR-Acceleration-vs-Roller-Displacement`
  (about 1.2 GB) then `PHYSICA_DROPBEAR8=<clone>/data`.
  Cite: Vereen, Downey, Dodson, Moura, "Dataset-8 DROPBEAR Acceleration vs Roller Displacement" (2023).

Raw data is not committed; `eval/results/E16_*.json` and `E19_*.json` hold the scored outputs.

## PADRE: real drone flights with damaged propellers (P0)
- Source: https://github.com/AeroLabPUT/UAV_measurement_data (AeroLab, Poznan University of Technology)
- Download (about 6.8 GB):
  ```
  GIT_LFS_SKIP_SMUDGE=1 git clone --depth 1 https://github.com/AeroLabPUT/UAV_measurement_data
  export PHYSICA_PADRE_DIR=$PWD/UAV_measurement_data
  ```
- Used: `Parrot_Bebop_2/Raw_data/Bebop2_16g_1kdps_raw_ABCD.csv` (format in `physica/data/padre.py`).
- Licence: **the repository does not state a licence file** (checked Oct 29, 2026). The README says the data is
  shared for research on fault detection. Cite the PADRE papers (JINT 2024: doi 10.1007/s10846-024-02101-7) and
  ask the authors before any commercial use. TODO (Zanea): confirm with the authors or the hackathon rules.

- Also used: `3DR_Solo/Range_data/Solo_ACCEL_16g_GYRO_2kdps_range_*.csv` (second drone, accelerometer in g, 500 Hz;
  loader `physica/data/solo.py`). Same repository and licence note.

## voraus-AD: real robot arm, normal and anomalous pick-and-place cycles (optional, E10)
- Source: https://github.com/vorausrobotik/voraus-ad-dataset (Brockmann et al., IEEE Transactions on Robotics 2023).
- Download the 100 Hz file (~1.1 GB): https://media.vorausrobotik.com/voraus-ad-dataset-100hz.parquet, then
  `export PHYSICA_VORAUS_FILE=/path/to/voraus-ad-dataset-100hz.parquet` and `pip install pyarrow`.
- Licence: **CC BY-NC-SA 4.0** (non-commercial, share-alike). Fine for research and a hackathon demo; credit the
  authors; don't commit the file.

## Fraunhofer unbalance dataset: real shaft, known imbalances (P0)
- Source: Fordatis (Fraunhofer IIS/EAS), "Vibration measurements on a rotating shaft at different unbalance strengths".
  Paper: Mey et al., "Machine Learning-Based Unbalance Detection of a Rotating Shaft Using Vibration Data", arXiv 2005.12742.
- Download the zip from Fordatis, unzip, then `export PHYSICA_FRAUNHOFER_DIR=/path/to/folder` (with `0D.csv … 4E.csv`).
- Levels: 0 none; 1 = 3.281 g @ 14 mm; 2 = 3.281 g @ 18.5 mm; 3 = 3.281 g @ 23 mm; 4 = 6.614 g @ 23 mm
  (m·r ≈ 0, 45.9, 60.7, 75.5, 152.1 g·mm). Sample rate 4096 Hz.
- Licence: check the Fordatis record page and record it here. TODO (Zanea).

## 3D-printer prints: settings -> strength, roughness, elongation (E12, World Sense)
- Source: Selcuk University experiment on an Ultimaker S5 (2018): 50 tensile prints in PLA and ABS. Published on
  Kaggle as "3D Printer Dataset for Mechanical Engineers" (afumetto/3dprinter, `data.csv`).
- A public GitHub copy exists inside https://github.com/anmayg/3D_Print (`print_data.db`, SQLite, 182 rows). It mixes
  the 50 prints with near-copies (inputs nudged, outcomes kept) of undocumented origin. `physica.world.data.load()`
  keeps only prints that follow the original experiment's two design rules and recovers exactly 50 (25 PLA, 25 ABS).
  One record is ambiguous between two near-copies (0.06 mm, 5 mm walls, PLA 215 C); the rule-consistent one is kept.
- Use: `export PHYSICA_PRINT_DATA=/path/to/data.csv` (or `print_data.db`), then `python eval/e12_world_sense.py`.
- Known limits, stated in the results: in all 50 prints, nozzle temperature, bed temperature and fan speed changed
  together, and print speed was fixed by layer height. Specimen geometry and print orientation are not documented.
- Licence: check the Kaggle page before redistributing; the data is not committed here.

## Touch Transform data (E13)
- **ARTS-Lab cantilever beam** (University of South Carolina, Austin Downey): https://github.com/ARTS-Laboratory/dataset-free-vibration-of-cantilever-beam
  `Vibration_measurement.txt`, one accelerometer at the tip, 25.6 kHz, 46 s, with a mass released mid-recording. Photo
  marks the beam at 757 mm and the mass at 268 mm. Licence **CC BY-SA 4.0** (credit; share-alike). Set `PHYSICA_BEAM_FILE`.
- **Guitar clip** from Wu et al., "Eulerian Video Magnification" (SIGGRAPH 2012; paper: 600 fps capture), as bundled
  in https://github.com/jvgemert/pbMoMa (`media/guitar.mp4`). Research use with attribution; not committed here.
  Set `PHYSICA_GUITAR_VIDEO`.
- Simulated video for touch place (E13-B) is generated by `tests/sim_video.py` and labelled as simulation everywhere.

- MAFAULDA (gated on Hugging Face, AI4Manufacturing).
- Live phone sensing with the phyphox app (remote access).
- Real ArduPilot `.bin` logs: only with the owner's written permission.


## Toolchains that check Physica's machine code (E23, optional)

`physica outcome` and `eval/e23_program_by_outcome.py` check the code they write with each machine's own tools. A
missing tool is reported as "not run", never as a pass.

```bash
# Klipper (G-code): host software in batch mode + a Linux-process MCU dictionary
git clone https://github.com/Klipper3d/klipper && cd klipper && cp test/configs/linuxprocess.config .config \
  && make olddefconfig && make && cd ..          # needs gcc; pip install cffi greenlet jinja2 pyserial markupsafe
export PHYSICA_KLIPPER=$PWD/klipper
# matiec (IEC 61131-3 Structured Text -> C), needs flex, bison, autotools
git clone https://github.com/beremiz/matiec && cd matiec && autoreconf -i && ./configure && make && cd ..
export PHYSICA_MATIEC=$PWD/matiec
# ArduPilot SITL (real autopilot code, simulated physics), ~8 min build
git clone --recurse-submodules https://github.com/ArduPilot/ardupilot && cd ardupilot \
  && pip install empy==3.3.4 pexpect future pymavlink && ./waf configure --board sitl && ./waf copter && cd ..
export PHYSICA_ARDUPILOT=$PWD/ardupilot
export PHYSICA_DROPBEAR8=<Dataset-8 clone>/data   # the beam map (see Beam B above)
python eval/e23_program_by_outcome.py
```

## Formula 1 telemetry and an independent lap-time simulator (E24, E25)

- **Telemetry (real):** the F1 live-timing stream of 2020 Round 5 (70th Anniversary GP, Silverstone), Free Practice 2,
  as stored in FastF1's test fixtures (20 cars: speed, rpm, gear, throttle, brake, DRS and X/Y position at ~4 Hz, plus
  the session's weather feed). F1 timing data © Formula One World Championship Ltd; used for non-commercial research
  and demonstration, and not included in this repository.
  ```bash
  git clone --depth 1 --branch v2.3.3 https://github.com/theOehrly/Fast-F1
  export PHYSICA_F1_SESSION=$PWD/Fast-F1/fastf1/testing/reference_data/2020_05_FP2
  ```
- **Track and independent simulator:** TUM laptime-simulation (Heilmeier, Geisslinger, Betz et al., Technical University
  of Munich, LGPL-3.0), which also carries the Silverstone racing line from the TUM racetrack database.
  ```bash
  git clone https://github.com/TUMFTM/laptime-simulation && pip install trajectory_planning_helpers
  export PHYSICA_TUM_LAPTIMESIM=$PWD/laptime-simulation
  export PHYSICA_TUM_RACELINE=$PWD/laptime-simulation/laptimesim/input/tracks/racelines/Silverstone.csv
  pip install numba        # optional: makes Physica's own lap model ~50x faster
  python eval/e24_f1_feel_and_advise.py && python eval/e25_deliberate_discover.py
  ```

## World model on real F1 data (E30)

Needs the same session as E24: `git clone --depth 1 --branch v2.3.3 https://github.com/theOehrly/Fast-F1`, then set `PHYSICA_F1_SESSION=<that>/fastf1/testing/reference_data/2020_05_FP2`. Also `git clone --depth 1 https://github.com/TUMFTM/laptime-simulation`, then set `PHYSICA_TUM_RACELINE=<that>/laptimesim/input/tracks/racelines/Silverstone.csv`. Run `python eval/e30_world_model_f1.py`. F1 timing data is used for non-commercial research and demonstration.
