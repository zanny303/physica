# Today, step by step

Run commands in the `physica` folder, one line at a time. Never show your key on screen, or paste it into chat.

**Deadlines:** film locked at 6:30. Submit by 7:15 PM. The cutoff is 8:00 PM Central.

## 1. Install and check Meta (10 min)

```powershell
cd "$HOME\Downloads\Physica_v0.35.3_Three_Proofs\physica"
python -m pip install -e .
python -m physica.cli meta preflight
```

You want `READY`, with no FAIL lines. Send me anything that fails.

## 2. Real footage, with Muse (15 min). No filming needed

```powershell
python -m physica.cli meta cases --allow-billed-meta
python -m physica.film tacoma
```

This runs Muse and SAM on the Tacoma Narrows film and the guitar film in `clips`. Send me what it prints. A failed step is recorded, not hidden. Start the site to see them under Real footage:

```powershell
python -m physica.studio --open-browser
```

Both films belong to others, so credit them on screen. See `clips/CREDITS.txt`.

**Only if there's time after this, do the cords below.** They're your own result, and they add the most, but the film works without them.

## 3. Build the rig (20 min)

- 4 equal lengths of thin, non-stretchy cord or wire, about 60 to 80 cm. Fishing line or guitar string is best, and thin twine is okay. Dark cord on a light wall.
- A firm rail for the top, like a shelf edge or a broom handle across two chairs. Tie each cord tightly: a loose knot ruins the tone.
- 4 identical bottles hanging, well spaced, not touching anything. Keep them under what the rail and the cord can hold, and keep your feet clear.
- Phone on a tripod, in slow motion (240 fps if you have it), filling the frame with the cords. **Don't move it between films.** Lock focus and exposure.

**Find your real frame rate:** film a phone timer in slow motion, and check how many frames pass per second. Use that for `--fps`.

## 4. The first test, before anything else (20 min)

Put 1 kg on each, weighed on the scale. Pluck each cord once with a pen, about one second apart, then film it.

```powershell
python -m physica.cli cables setup first.mp4 --fps 240 --allow-billed-meta
```

**Go only if every cord gives a clear tone, and the tones roughly match.** Send me what it prints. If Muse or SAM fails, draw the boxes yourself with `--boxes`, in pixels. If the tones fail, try tighter knots or a higher load. If nothing works by 3:00, tell me, and we'll go to the backup.

## 5. Teach it two known loads (15 min)

Weigh each bottle on camera, then pluck all four and film each load:

```powershell
python -m physica.cli cables known low.mp4 --loads 500
python -m physica.cli cables known high.mp4 --loads 1500
```

All four should say `ready`. Bottles can differ, for example `--loads 480,510,500,495`, in the same left-to-right order.

## 6. The reveal, the main shot (20 min)

Have a friend secretly fill each bottle between the two loads, if you can. Otherwise, fill them with your eyes closed. Hang them, pluck, and film, without weighing them.

```powershell
python -m physica.cli cables read secret.mp4
```

Film the screen showing the sealed answer. Then weigh each bottle on camera, and:

```powershell
python -m physica.cli cables reveal --truth 640,1210,930,1480
```

Do this a few times, and **keep every result, including misses.**

## 7. The twin, sealed forecast (10 min)

Pick a load it hasn't seen:

```powershell
python -m physica.cli cables twin --cable "NAME" --g 1200
python -m physica.cli cables twin-grade forecast.mp4 --pred 1
```

The cable names are shown in step 4.

## 8. Muse sets the goal (15 min)

```powershell
python -m physica.cli cables balance --goal "every cord carries the same load" --allow-billed-meta
```

Pour exactly what it says on the scale, film again, then `read` and `reveal` again.

## 10. One real thing, if there's time (15 min)

Film something real: a ratchet strap on a load, a belt on a machine, a bike spoke. With its own calibration you could give force. Without one, only say the tone, and say which is tighter only if it's the same cable type and length.

## 11. Clips (with me)

```powershell
python -m physica.cli speak --allow-billed-meta
python -m physica.film pack
python -m physica.cli evidence
```

## 12. Submit

Check the portal's video length, required links and rule on prior work. Make the repo public, check `docs/BUILT_DURING_EVENT.md`, and make sure no key or raw footage is in it. Upload, submit, and screenshot the confirmation.
