# PHYSICA — Feel unexpected change. Discover what to test. Improve what matters.

**Push the Frontier submission story:** A real printer investigation is the proposed flagship; authenticated Muse helps propose and criticize explanations, but only independent measurements establish what worked. Industrial unplanned downtime is the scalable pain point; archived turbine and F1 data illustrate cross-domain inquiry, not universal causal transfer. **The latest complete automatic reoptimization is demonstrated in a synthetic beam experiment**, not yet on a physical printer.

**Start here for the demo:** [the three proofs, step by step](docs/V035_THREE_PROOFS_RUNBOOK.md).

**New research engine:** [the adaptive world model](docs/V034_WORLD_MODEL.md), an opt-in path with its benchmark results, losses included.

**Start here:** [DEMO.md](DEMO.md) for the single demo story, then the [film day runbook](docs/V034_FILM_DAY_RUNBOOK.md) for the exact commands. For the full staged beam prototype see [v0.31 runbook](docs/V031_OUTCOME_DISCOVERY_REOPTIMIZATION.md). All machine instructions remain human-review-only.

```powershell
python -m pip install -e ".[dev]"
python -m physica.studio --open-browser
python -m physica.frontier.meta_ready_v026 doctor
```

---

# PHYSICA v0.31 — FEEL → INVESTIGATE → PROGRAM BY OUTCOME → VERIFY

**New:** A user states a measurable physical goal. Physica checks its current prediction and uncertainty, notices a measured sensory mismatch, proposes *reviewed* experiments, learns a limited model correction using independent observations, recomputes the most appropriate setting, freezes a future prediction, then grades the measured result. The complete new numerical path is verified **in simulation for an instrumented beam**; machine-specific discovery and optimization require actual experimental evidence. **No real-world avoided downtime, scientific breakthrough, or hardware safety certification is claimed.**

**Start:** `python -m physica.outcome.closed_loop_v031 synthetic-demo --out demo/v031_synthetic` and open `python -m physica.studio --open-browser` → Studio → **Program By Outcome**. For supervised beam measurements and printer/F1/turbine evidence, use [the v0.31 real-experiment runbook](docs/V031_OUTCOME_DISCOVERY_REOPTIMIZATION.md). The v0.30 industrial Sentinel monitoring module, prior discovery engines, Meta research council, F1, printer and turbine apps are preserved.

---

# PHYSICA v0.30 — SENTINEL / Industrial Physical Intelligence

**The problem:** Industrial equipment begins changing physically before a failure or unplanned stop. Physica's research aim is to detect a credible change, investigate why, request the next useful measurement and help an engineer act with better evidence. **No avoided downtime, novel physical law, authenticated Meta call or real-world intervention is claimed by the bundled v0.30 synthetic Sentinel demonstration.**

**Historical v0.30 application:** `python -m physica.studio --open-browser` → `http://127.0.0.1:8765/sentinel`. The existing physical feeling, robot/turbine/F1, Muse Research Council and discovery modules remain available.

**Run synthetic, then real:** `python -m physica.maintenance.cli synthetic-demo --out demo/v030_synthetic`; evaluate independent field-run bearings with `python -m physica.maintenance.cli evaluate --manifest real/manifest.json --out real/report.json`. With a private local API key and explicit opt-in, `python -m physica.maintenance.cli meta-council --report real/report.json --allow-billed-meta --out real/council.json` asks Muse to suggest unverified explanations using only the separately reserved *source-discovery* recordings, never the blind-test measurements.

**Read first:** [Final research, ethical demo storyboard, dataset instructions and validated algorithm candidates](docs/V030_PUSH_FRONTIER_FINAL_RESEARCH.md). The current benchmark is explicitly **simulated**; the innovation hypothesis still needs independent real physical tests. **Never attach trial weights to running fans or automatically operate hazardous equipment.**

---

# Physica — Predictive Feeling, Verified Physical Discovery

**v0.29 reliability upgrade:** The archived drone replay no longer crashes when raw evidence is absent; it says *evidence unavailable* instead of inventing a physical measurement. The cross-domain Feeling Engine can optionally calibrate anomalies from held-out normal operation and **abstain under operating-condition shift**. Read [the v0.29 research and runbook](docs/V029_RELIABLE_FEELING_RESEARCH_AND_RELEASE.md). This is not a verified real-world discovery or a hardware safety guarantee.

**v0.28:** One evidence-first feeling and inquiry workflow across **3D printers, wind-turbine blade analysis and Formula 1 telemetry**, with v0.27's neural–physics discovery and real A→B field protocol preserved. Launch Studio and open **`/feel`**. Read [the new evidence and Meta runbook](docs/V028_UNIFIED_FEELING_ENGINE.md).

**Status:** Parts execute locally; archived evidence and simulated trials are clearly labeled. Live Meta account calls, real-device physical discovery and a universal model have **not** been verified in this package. All industrial and machine outputs are advisory, not operating authorization.

> **New v0.27:** Unified measured feeling → curiosity → Muse hypothesis → experiment → sealed future → later learning/transfer. Start with [`docs/V027_UNIFIED_FEELING_DISCOVERY_RUNBOOK.md`](docs/V027_UNIFIED_FEELING_DISCOVERY_RUNBOOK.md). The included demo is **synthetic**, not real scientific evidence.

> **v0.26 Muse scientific integration:** To use your private Meta Model API key, see [docs/V026_MUSE_DISCOVERY_RUNBOOK.md](docs/V026_MUSE_DISCOVERY_RUNBOOK.md). Run `python -m physica.frontier.meta_ready_v026 doctor` (free), then the optional `live-smoke` and `live_meta_sandbox_v026` commands (explicit paid opt-in). The council is Wonder hypothesis → Spark criticism → Wonder revision → evidence-gated numerical validation; no hardware actuation.

## NEW — v0.24 physics-grounded curiosity research

The new **Curiosity Lab** lives at `http://127.0.0.1:8765/curiosity` in Studio. It demonstrates neural-guided **non-preseeded frequency** search, calibrated sensory surprise, conservative experiment planning and a real-data prospective commit/reveal protocol. All included benchmark numbers are explicitly synthetic; no authenticated Meta or real hardware results are claimed.

- Run `python -m physica.frontier.curious_discovery --seeds 12 --experiment-policy mechanism --out demo/v024.json`.
- Use `python -m physica.frontier.field_discovery --help` for the field protocol.
- Use `python -m physica.frontier.mechanism_dsl --help` for explicitly authorized Meta hypothesis nomination.
- Read `docs/V024_CURIOSITY_NEURAL_PHYSICS_RESEARCH.md` for research, tested baselines, caveats and real-world plan.

---

> **v0.22:** Twin Studio now contains *Teach another machine to act*: a bounded, review-only cross-sensor goal-to-behavior planner. See `docs/V022_GOAL_TO_BEHAVIOUR_TRANSFER.md` for requirements and limitations.

## NEW — Evidence-linked digital twins (v0.21.2)

**Studio → Digital Twin** (or `http://127.0.0.1:8765/twin`): upload a video or time-stamped position recording, inspect what was actually measured, manipulate hypothesized stiffness/damping, and view conditional what-if trajectories. Optional user-approved Meta SAM 3.1 tracks and Muse Spark hypothesis annotations; never infer a true break threshold from one video.

See `docs/V0212_EVIDENCE_DIGITAL_TWIN_AND_FRONTIER.md` for calibration, API opt-in, tested capabilities, and the simulated A→B/C research pipeline.

> **NEW IN v0.21:** [Discovery Observatory](docs/V021_DISCOVERY_OBSERVATORY_AND_FRONTIER_RESEARCH.md) — a Python-backed Meta hypothesis / critique / evidence-gated experiment loop, with a redesigned Studio interface at `/observatory`. Offline examples are simulated and human-authored; hosted Meta inference and physical discovery require separate verification.

# PHYSICA v0.20 — Evidence-First Drop-In Studio

**Giving AI the ability to feel** through measured physical consequences, cautious inference, and experiments.

The single-screen `/` experience now supports actual local video/CSV uploads and refuses unsupported, ambiguous, or incompatible evidence instead of inventing a diagnosis. Meta Muse can propose a template on a **separately authorized paid call**, but the numerical evidence must meet that template's prerequisites. The `Lab` dashboard and all prior modules remain available.

**Windows Terminal (PowerShell shell)** (after extracting into `physicanew\physica`, with an existing venv one directory up):

```powershell
cd C:\Users\budhw\Downloads\physicanew\physica
$env:PYTHONUTF8 = "1"
..\.venv\Scripts\python.exe -m pip install -e ".[dev,video]"
..\.venv\Scripts\python.exe -m physica.studio --open-browser
```

Visit `http://127.0.0.1:8765` → **Drop physical evidence in** → select an MP4/CSV. Set verified frame rate if known; device hint is *user context*, not measured truth. All inputs stay local by default. For Meta, set `MODEL_API_KEY` and `MOCK=0` locally, enable the optional billing checkbox, and approve the separate confirmation. Hosted SAM calls still require Meta credits and the correct parser; no live Meta run is bundled or claimed. [Scientific detail and limitations](docs/V020_EVIDENCE_FIRST_RELEASE.md).

Old v0.19 features (F1 model, turbine, beam, remote signal training, MACE, transfer, outcome programming, lab demos) are preserved. The app **does not** have arbitrary physical understanding or permission to control real equipment.

Built Oct 26 – Nov 4, 2026 for the Meta Global AI Developer Hackathon (Indie track, "Push the Frontier").

# Physica: AI can see and hear. Physica gives it *feel*.

**And a sixth sense: it feels forces no sensor measures.** An F1 car's downforce, drag and power from the public speed
trace. Ice on a wind-turbine blade from its hum (87 g felt for a true 88 g, 124 g for 132 g; a 44 g mass mostly goes unnoticed). Where a hidden support sits inside a steel
beam. Cameras give AI sight and microphones give it hearing; Physica turns motion and vibration into the forces,
masses and stiffnesses behind them, each with an error bar, each checked against something it never saw.

Physica listens to a body's vibration (an accelerometer, a strain gauge, a phone video, a telemetry stream) and works out **what**
changed it, **where**, and **how sure** it is. It rules causes out with physics, picks the experiment that settles
doubt, seals what it expects before it acts, and teaches the **explanation**, not the numbers, to a different
machine. Meta models do the thinking (SAM 3.1 sees, Muse Spark proposes, Muse Wonder runs the loop); Physica does
the feeling; reality does the judging.

```
feel ─► rule causes out (physics) ─► locate ─► choose the experiment ─► seal ─► act ─► reveal ─► teach another machine
                          you say the outcome ─► plan ─► machine code ─► checked by the machine's own toolchain ─┘
```

## New in v0.19: drop anything in

`physica auto <video | sensor file | telemetry folder>`: Meta (Muse Spark; an offline matcher without a key) names the
system and the physics, SAM 3.1 finds the part to watch in a video, and Physica maps what it can feel there. On real
inputs it names a high-speed guitar video's strings E2, A2, D3 (MIT's 600 fps footage), an F1 session (felt power,
drag, downforce for 20 cars), a turbine-blade spectrum (its seven modes) and a DROPBEAR trial. Consumer fix: four phone
clips of a wobbling fan (as-is, then a coin on each blade) give where to add how many grams; on simulated clips the
fix removed 98% of the wobble and the sealed promise was kept. The demo plan is in [DEMO.md](DEMO.md).

## v0.18: the race engineer, deliberate-to-discover, and goals it refuses

- **Feel an F1 car from its public telemetry** (real 2020 Silverstone FP2 live timing, 20 cars): power, drag area,
  DRS drag cut and downforce, with error bars; on laps it never saw it predicts the lap within 0.95 s (a generic F1
  car: 3.62 s). A team asks "faster, but don't lose more than 5 km/h through Maggotts–Becketts"; Physica answers with a
  wing change and a sealed lap time, and TUM's independent lap-time simulator grades it: **9 of 9 lap-time promises
  held** on cars it never calibrated on. [docs/RACE_ENGINEER.md](docs/RACE_ENGINEER.md)
- **Deliberate to discover:** a model (Muse Spark live, an exhaustive search offline) proposes physical laws, Physica's
  physics grades them, the grades go back, it proposes again; the surviving law is tested on unseen cars (E25).
- **The outcome contract:** vague goals are refused before any physics runs; "never run a cracked blade" is refused as
  a promise because the blade sense measurably missed 9 of 111 crack groups; the beam's error bars now use a proper
  conformal split (178/178 moves worked, promises held 89.3% for 90% claimed).

## v0.17: program machines by outcome, not by instruction

Say what you want; Physica writes the machine's own code, checks it with the machine's own tools, seals what the
sensors will read, and lets reality grade it. Full story: [docs/PROGRAM_BY_OUTCOME.md](docs/PROGRAM_BY_OUTCOME.md).

```bash
physica outcome "A pump beside this beam runs at 31 Hz. Keep the beam's tone at least 5% away from it and move the support as little as possible."
```

| Machine | Language written | Checked by | Result (E23) |
|---|---|---|---|
| Steel beam with actuator (**real data**, DROPBEAR) | Klipper G-code, GRBL G-code | real Klipper firmware (batch mode) | 840 goals; **178 of 178 moves worked** on another day's real recordings (planner without error bars: 108 of 145); firmware refuses moves outside what the beam has felt |
| Wind turbine (**real verdicts**, ETH blade) | IEC 61131-3 Structured Text: the PLC enforces the sealed de-icing promise (review-only) | real matiec compiler + gcc | compiles; cracks that look like ice brake when heating doesn't fix them. A "never run a cracked blade" goal is **refused as a promise**: the blade sense missed 9 of 111 crack groups |
| Inspection drone | MAVLink mission | pymavlink + real ArduPilot code (SITL) | flown: 8/8 waypoints, 12.0 m from the blade. **It caught a bug in v0.16's mission** (RTL brought the drone down past the blade tip); fixed |
| Remote-lab robot (CloudPendulum, Chalmers) | lab client script | the real lab, when you run it | written; not run (needs an approved account) |

## Run it in two minutes (no data, no key, no network)

```bash
pip install -e ".[dev,video]"
python -m physica.cli verify                 # 12 claims checked from scratch, ~10 s
python -m physica.studio --open-browser      # the front door: real results, live webcam sensing, the agent
```

On Windows: `..\.venv\Scripts\python.exe -m physica.studio --open-browser` (or double-click `RUN_PHYSICA_STUDIO_WINDOWS.bat`).

## Real use cases (every number is read from `eval/results/`)

| Use case | What Physica maps, how it acts, what it teaches | Data |
|---|---|---|
| **Wind farms: ice, crack, or just cold?** (E20) | A real turbine blade from −15 to +40 °C. Learned from healthy days plus one deliberate experiment (a known 44 g mass); never sees ice or cracks. On a separate test campaign: **6% false alarms vs 69%** for a temperature-blind alarm; cracks of 10 cm+ (total) found 99% of the time in any weather; ice weighed at **87 g for a true 88 g**. Acts: ice → pause and heat with a sealed promise; crack → stop and fly an ArduPilot inspection mission down the blade. Four cracks looked like ice; heating didn't bring them back, the promises broke, and **no cracked blade was restarted**. Teaches: one signed card for sister turbines. | **Real** · ETH Zürich blade benchmark |
| **Smart structures: move it so it stops resonating** (E22) | Physica tells a beam's own actuator where to move its support to stay clear of a nearby motor, and seals the tone it expects. Graded on the real recording when the support really sat there: 63.6 Hz felt for 63.5 expected; 57.0 for 57.6; one promise broke (84.4 for 80.6). | **Real** · DROPBEAR |
| **Bridges: winter, or a real change?** (E21) | Per-mode temperature laws with the freezing jump, learned before a bridge was strengthened; every day judged weather-only or changed, and in which direction. Runs on the KW51 railway bridge data (13 MB download); tested here on a labelled synthetic file in the same format. | Real data, run locally |

Why these, with sources: [docs/USE_CASES.md](docs/USE_CASES.md). How to film them: [DEMO.md](DEMO.md).

## The science underneath

| | What happened | Data |
|---|---|---|
| **Finds a hidden cause** (E16) | A roller slides along a steel beam. Physica is never told. From the tip accelerometer alone it rules out added mass, cracks and temperature (mass and cracks can only lower a beam's tones and temperature moves them a few percent; this beam rang at 1.2–2.2× its bare tone), concludes something is **holding** the beam, and tracks where: **2.40 mm median error** (mean 5.55) with **nothing tuned to this beam** (its measured dimensions and textbook steel; the only choice made from data is which cause it is). The dataset authors' own published real-time method on the same recording: 3.37 mm (mean 8.63). | **Real** · DROPBEAR, 352 mm beam |
| **Knows when it doesn't know** (E16) | It judges for itself whether the support is holding still or moving, and carries a calibrated error bar for each (±4.6 mm / ±34.2 mm). Covered the truth 96% of the time on the half of the recording it never calibrated on (target 90%). | **Real** |
| **Teaches a different machine** (E16) | The explanation travels as a signed card to a second beam: 501 mm, thicker, a different low-g accelerometer, 5 kHz, **no position sensor used**. With **zero labels** its estimate correlates r = 0.83 with the hidden truth over 32 unseen trials. With 1 label: 7.1 mm vs 25.7 mm for learning from B's labels alone; with 2: 3.3 vs 5.0 mm. Carrying A's *numbers* instead fails (99% of B's tones are outside anything A felt; 26.9 mm). From 16 labels on, B's own data wins: the explanation is the head start, not the ceiling. | **Real** · DROPBEAR, 501 mm beam, 52 trials |
| **Keeps honest promises** (E16) | Before reading any of B's truth, Physica sealed a promise about B's error. It **broke** (8.1 mm vs ≤6.6 mm promised): B's scale differs from A's experience by 18%. The seal can't be edited after the fact, so the failure is on record. | **Real** |
| **Chooses its experiments** (E17) | Mass or crack, and where? Physica picks where to tape a 5 g coin by expected information gain and seals the tones it will feel. Right cause: 48% from feeling alone, 60% measuring twice more, 80% with two random coin placements, **78% with one chosen**, **88% with two chosen**; sealed promises held 89%. | Simulation (labelled) |
| **Asks for new ideas, believes only what survives** (E18) | When none of its causes fits (a loosening clamp), it asks Muse Spark for new ones as structured physics, fits each on the first half and judges it on the second. Loosening clamp accepted (100% of unseen moments vs 29% for the best built-in). When two things change at once, every proposal is rejected and it keeps saying it doesn't know. | Simulation; Spark live with a key |
| **Many proposals, one strict judge** (E19) | Proposers write new senses as code (sandboxed). Judged only on beam A's unseen half and on beam B. The best of 72 proposals beat Physica's own sense on A (0.97 vs 2.49 mm) but **lost on B** (7.06 vs 5.67 mm), so it was rejected: the judge catches senses that don't travel. | **Real judge**; offline proposer stand-in, Muse with a key |
| **Feels damage without damage data** (E1, E9) | Drone propellers: 76% of damage windows felt, 0/17 false alarms, learned from one healthy flight. The skill carried to a different drone (3DR Solo): 100% felt, 0/17 false alarms, 8/8 flights. | **Real** · PADRE flights |
| **Touch vs change of body** (E13, E15) | One accelerometer on a real beam: tells a touch from a change of the body itself, says where the mass went, predicts a real tap with a digital twin (R² 0.68), streams at 38 µs per sample. A guitar video: 3 separate strings and their tones from pixels. | **Real** · ARTS-Lab beam, guitar clip |
| **Acts in machine code** (E6, E12, E14) | ArduPilot notch parameters, PLC Structured Text, Marlin/Klipper input shaping, G-code for printed parts, each with a sealed promise checked by feeling again (11/11 promises held on recorded real drone flights; a deliberately wrong setting rolled back 11/11). | Real flights / simulation, labelled |

The full earlier results (E1–E15, with confidence intervals and limits) are in [docs/RESULTS_E1_E15.md](docs/RESULTS_E1_E15.md).

## Meta models inside the loop

| Model | Role in Physica | Where |
|---|---|---|
| **SAM 3.1** | Eyes: finds the object in a video so motion is read from it, not the background | `physica meta sam VIDEO --concept "ruler" --sense` · [physica/meta/sam.py](physica/meta/sam.py) |
| **Muse Spark** | Scientist: proposes new causes as structured physics when Physica's own don't fit | `physica meta scientist` · [physica/meta/scientist.py](physica/meta/scientist.py) |
| **Muse Wonder** | Agent: runs the loop with real tool calls; writes new senses for the judge, in parallel swarms | `physica meta ask "…"` · `physica meta evolve --swarm 8` · [physica/meta/agent.py](physica/meta/agent.py) |
| Muse Glimmer | Optional second safety layer (open weights, self-hosted; not on the Model API) | [physica/agents/glimmer_gate.py](physica/agents/glimmer_gate.py) |

Every call goes through one client ([physica/llm/meta_client.py](physica/llm/meta_client.py)) in the format verified
from Meta's developer docs: `POST https://api.meta.ai/v1/chat/completions` with `muse-spark-1.3` / `muse-wonder-1.0`,
`max_completion_tokens`, tools and JSON schemas; SAM 3.1 through the Files API and a streamed `/v1/responses`.

**To go live** (your key stays in your terminal, never in the repo):

```bash
export MOCK=0 MODEL_API_KEY=...          # PowerShell: $env:MOCK="0"; $env:MODEL_API_KEY="..."
python -m physica.cli meta doctor        # three tiny live calls: Spark answers, Wonder calls a tool, SAM tracks
python -m physica.cli meta scientist     # E18 with live Spark
python -m physica.cli meta evolve --swarm 4   # E19 with live Wonder proposers (needs the DROPBEAR data)
```

Each live call leaves a receipt in `meta_receipts/` (model, time, request hash, response, usage), a hard stop
refuses any call that could take total spend over `PHYSICA_BUDGET_USD` (default $120), and an offline stand-in is
never replayed as a live answer. Without a key, every Meta role runs an offline stand-in that is labelled **NOT Meta**
everywhere it appears.

## Why it matters

Thinking is getting cheap; checking against reality isn't. The 2026 AI mathematics results came from huge numbers of
model proposals filtered by an automatic judge (a proof checker). The physical world has no proof checker: every check
costs a measurement, a machine hour or a broken part. Physica is built to be that judge, and to need fewer checks:
explanations that travel to new machines, experiments chosen for what they will settle, and promises sealed before
the result is known. The full argument, with sources and what we do **not** claim, is in
[docs/WHY_IT_MATTERS.md](docs/WHY_IT_MATTERS.md). The demo script is [DEMO.md](DEMO.md).

## Commands

```bash
physica verify                                   # one-minute self-check
physica outcome "<what you want>" [--machine beam|turbine|drone|pendulum] [--live] [--fly]   # goal -> plan -> machine code -> toolchain check -> sealed promise
physica outcome grade --promise P.json --quantity tone_hz --measured 28.9                     # reality grades it
physica cause track FILE --length-mm L --width-mm W --thickness-mm T [--tip-g G]    # what changed it, and where
physica cause plan  --length-mm 300 --width-mm 30 --thickness-mm 2 --material wood --video before.mp4 --coin-g 5
physica cause reveal sealed_promise.json --video after.mp4
physica cause apply cards/explanation_dropbear_support.json FILE --length-mm ...    # use another machine's explanation
physica cause teach cards/explanation_dropbear_support.json --to http://other-machine:8765
physica sense FILE | physica watch FILE | physica bank find | physica weigh | physica printer-video ...
physica meta status | doctor | ask | scientist | evolve | sam | freeze
python -m physica.studio [--host 0.0.0.0]       # front door; /lab is the full research lab
```

Reproduce the real-data results (download the data first, see [DATA.md](DATA.md)):

```bash
python eval/e20_wind_blade.py        # PHYSICA_BLADE_PSD (wind turbine blade)
python eval/e16_hidden_cause.py      # PHYSICA_DROPBEAR2, PHYSICA_DROPBEAR8
python eval/e22_retune_beam.py       # PHYSICA_DROPBEAR2 (acting on the beam's actuator)
python eval/e21_kw51_bridge.py trackedmodes.mat   # KW51 bridge
python eval/e17_active_experiments.py
python eval/e18_new_cause.py
python eval/e19_evolve_sense.py --swarm 3
python eval/e15_sense_all.py         # PHYSICA_BEAM_FILE, PHYSICA_GUITAR_VIDEO
```

## Repo map

- `physica/cause/` beam physics (`fe.py`), tone tracking (`track.py`), rival causes (`discover.py`), explanation cards (`transfer.py`), active experiments (`intervene.py`), wind blade sense (`blade.py`), long-term structure monitoring (`monitor.py`), CLI
- `physica/act/turbine.py` turbine commands, sealed de-icing promises, ArduPilot inspection missions
- `physica/meta/` SAM parser, Spark scientist, Wonder agent, sense evolution, `physica meta` CLI
- `physica/llm/meta_client.py` the one door to Meta's API (receipts, hard stop, replay)
- `physica/seal.py` sealed predictions (SHA-256 + Ed25519 + time)
- `physica/touch/`, `physica/world/`, `physica/feel/`, `physica/sense.py` the senses (Touch Transform, World Sense, Feel Transform)
- `physica/studio/` the app (`front.html` is the front door; `dashboard.html` is the research lab)
- `physica/mace*`, `physica/feeling`, `physica/grammar`, ... the research line from v0.4–v0.14 (all simulation; see [docs/history](docs/history))
- `eval/` every experiment; `eval/results/` every number; `tests/` (pytest); `cards/` signed cards; `meta_receipts/` live Meta calls

## Honesty rules (in the code, not just here)

Simulation results are labelled on every screen they appear. Offline stand-ins for Meta are labelled NOT Meta.
Physica's tracker is slower than the DROPBEAR authors' millisecond method; its advantages are needing nothing tuned to the
beam and an explanation that travels. Its webcam sense is limited by the camera's frame rate (about 15 Hz at 30 fps).
Real results so far: a wind turbine blade in a climate chamber, two DROPBEAR beams, one more lab beam, one guitar
video and two drone models; the bridge pipeline awaits its data. "To our knowledge"
is the strongest novelty claim we make. Advice, not a safety certification.

Data credits and licences: [DATA.md](DATA.md). Licence: Apache-2.0.

## v0.23 Frontier Lab — evidence-selected hybrid neural physics

Open `/frontier` in Unified Studio. Research code compares physics-only, regularized linear residual, small MLP neural residual, and an extended symbolic mechanism model on independent synthetic intervention episodes. The validation winner is sealed before test scoring. In this controlled periodic simulator, symbolic regression wins decisively over the neural residual, so **the neural network is an experimental fallback, not a new default or a claimed breakthrough**.

The Frontier Lab also shows an offline Muse scientific council. An optional, explicitly billed CLI can run a real Spark → Wonder → Spark → Wonder observation/hypothesis/critique/revision exchange; no hosted calls are made automatically. Read `docs/V023_FRONTIER_RESEARCH.md`.

## v0.25 — Source discovery to target-machine prospective evidence

See [`docs/V025_UNKNOWN_MECHANISM_REAL_TRANSFER.md`](docs/V025_UNKNOWN_MECHANISM_REAL_TRANSFER.md) for the runnable Meta-on/off research protocol, field CSV templates, human-approved probe plan, sealed prospective four-method comparison, and full limitations. Start offline with `python -m physica.frontier.discovery_milestone_v025 synthetic-demo --out demo/v025_demo`; a synthetic fixture is not an authenticated Muse discovery or real hardware result.
