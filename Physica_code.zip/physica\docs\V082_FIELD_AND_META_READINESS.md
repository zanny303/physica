# Physica v0.8.2 — What software can and cannot verify

**Status:** A field-readiness and Meta integration **test harness**, not new physical proof. It does not drive machines, fabricate experiments, or call Meta by default.

## 1. Minimum demonstration

A supervised clamped-strip experiment with externally calibrated geometry, a stable phone/camera, repeatable initial conditions, and independent reference measurements. Use small reversible deflections. Obtain staff authorization for the rig and instruments. The provided model requires *effective modal mass*, stiffness, and damping, not just the beam's total weight; an improperly calibrated model can fail despite correct software. If uninstrumented, a free-decay trial with zero applied force can be used to inspect frequency, but is not adequate for identifying general nonlinear force terms.

Before the target trial, **seal the actual prediction with the existing v0.8.1 forecasting pipeline**, and arrange an independently witnessed timestamp. Do not generate or tune the prediction after seeing the target outcome. Preserve source, target-probe, and held-out main-trial records separately.

## 2. Offline checks (no API billing)

```shell
python -m physica.field.cli meta-doctor --out meta_readiness.json
python -m physica.field.cli preflight REAL_METADATA.json REAL_SENSOR.csv --out field_preflight.json
```

- `REAL_SENSOR.csv` columns are `time_s,displacement_m,force_n` in **seconds, meters, newtons**. Optional `velocity_m_s`, `audio_pressure_pa` are accepted only when independently calibrated. Retain the unmodified raw file.
- `REAL_METADATA.json` follows `examples/field_v082/METADATA_TEMPLATE.json`. Compute the SHA-256 digest from the actual saved file; document the independently measured sensor calibrations and *chronological, witnessed* main experiment. Set `human_authorized=true` only after actual permission.
- For video, add `--video REAL_VIDEO.mp4` and `video_sha256`, `camera: {"meters_per_pixel": ..., "fps": ..., "static_reference_track": true, "clock_synchronized_to_csv": true}`. Pixel-to-metre scaling must come from a ruler/marker in the same plane; camera jitter and depth movement still require independent checks.
- The preflight checks sample rate relative to the *declared* mass/stiffness. If this calibration is wrong, passing preflight does not validate it.
- A supplied witness name/timestamp is checked for presence and chronological order, **not independently authenticated by the code**. Ask a separate human to witness or use a trusted timestamp service.
- Failures generate `REFUSE_INCOMPLETE_REAL_DATA` and explicit reasons. Passing means only that data are structured for supervised validation.

After the experiment, with a signed real forecast produced by v0.8.1, run:

```shell
python -m physica.field.cli score-sealed REAL_METADATA.json REAL_SENSOR.csv SEALED_FORECAST.json --out REAL_EVALUATION.json
```

This deliberately supports **only a calibrated 1:1 visual displacement sensor (metres)** for the initial field experiment; it rejects other sensor mappings rather than silently assuming microphones measure velocity. It checks the experiment/body identity, signed forecast, data hash, time grid and actual measurement units before recomputing the prediction error. It does not independently confirm that the person truly collected the stated measurements.

## 3. Meta Model API

Verified from Meta documentation (October 31, 2026):

- Responses endpoint: `https://api.meta.ai/v1/responses`, OpenAI-compatible client configured with base URL and private `MODEL_API_KEY`.
- Structured responses use `text.format` (not a top-level `response_format`).
- Muse Spark understands uploaded video via file ID referenced in a Responses `input_file` or `input_video` block.
- SAM 3.1 segmentation is a special-token stream. Use `meta-sam-parser` for the video response; never infer displacement in metres from pixel boxes alone.

The offline `meta-doctor` command reports which client packages are installed and that **zero authenticated calls were made**. `meta-sam-parser` must be installed on your workstation before you can exercise the SAM adapter.

For an explicit, potentially billable, real text-only smoke test (no private data, no sensor evidence):

```shell
# Set MODEL_API_KEY locally; never commit it or send it to ChatGPT.
python -m physica.field.cli meta-live-smoke --role both --allow-billed-meta --out META_SMOKE.json
```

The smoke calls Spark and Wonder using a strict JSON schema. If a model is unavailable, quota is exhausted, schema is rejected, or connection fails, the command fails, as it should. Even a passing smoke test is *not* proof that Meta improves physical prediction. The actual physical video pathway remains `python -m physica.feeling.v08_cli ...` or the repository's existing `meta-feel` command, configured with calibrated static reference and camera units. Review `docs/META_LIVE_FIELD_CHECKLIST.md`.

For a meaningful **Meta ablation**, hold out the same real physical trials and fix the same experiment budget. Compare calibrated physics alone, CIRTE without Meta, and CIRTE with real SAM/Spark/Wonder. Store raw input/output hashes, model IDs and actual responses; do not replace failed calls with authored hypotheses and call them Meta results.

## 4. Why there is no 'guarantee'

A code test cannot detect whether the beam is loosely clamped, the force was estimated instead of measured, the phone's slow-motion file has altered timestamps, a sensor is biased, or the chosen physical model is wrong. A physical demo can fail even with clean software. That is why the v0.8.2 harness refuses dubious measurements and keeps simulated / structured-data checks separate from **prospective hardware evidence**.
