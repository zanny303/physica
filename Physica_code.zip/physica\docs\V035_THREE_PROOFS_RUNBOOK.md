# Physica v0.35: the three proofs, step by step

This project sets out to show three things, alongside the sense itself:

1. **A new physical capability.** Physica meets unexpected behaviour, designs an experiment, and finds an explanation that predicts measurements it hasn't seen.
2. **A meaningful Meta contribution.** Muse and SAM measurably improve the investigation, compared with the same system without them.
3. **A visible physical result.** A real machine reaches your goal, and a verified lesson helps a second machine.

**None of this is proven until you run it.** The printer code has only been tested on simulated films. Run this at any point to see what has really been shown, read from your saved results:

```powershell
python -m physica.cli printer-video proof --name printer --other printerB
```

Everything runs on your computer and your key stays there. Physica never moves the machine: you review and run every G-code and setting, with the printer supervised.

## Before you start

**Install, once.** You need Python 3.12 or newer, from python.org, with "Add to PATH" ticked. These are Windows PowerShell commands.

```powershell
cd "$HOME\Downloads\Physica_v0.35.3_Three_Proofs\physica"
py -3.12 -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev,video,meta]"
winget install Gyan.FFmpeg
```

Close PowerShell after that, and open a new one for the next part. `ffmpeg` is only needed for `show`, `ripple` and `physica.film`.

**Every time you open PowerShell.** The key lasts only as long as the window, and it's never saved to a file:

```powershell
cd "$HOME\Downloads\Physica_v0.35.3_Three_Proofs\physica"
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
$env:MODEL_API_KEY = Read-Host "Paste your Meta key, then press Enter"
$env:MOCK = "0"
$env:PHYSICA_BUDGET_USD = "15"
$env:PYTHONUTF8 = "1"
```

Don't record or share your screen while the key is showing, don't paste it into any chat, and don't put it in a file in this folder.

```powershell
python -m physica.frontier.meta_ready_v026 live-smoke --role spark --allow-billed-meta
python -m physica.frontier.meta_ready_v026 live-smoke --role wonder --allow-billed-meta
python -m physica.cli meta doctor
python -m physica.cli meta preflight
python -m physica.cli printer-video excite --axis X | Out-File -Encoding ascii excite.gcode
```

Review `excite.gcode` before running it. It homes the printer, then moves at 200 mm/s and 3000 mm/s² around X = 110 mm, so check that suits your machine. Run it with the bed empty and stay with the printer.

**Check the fix exists on your printer.** Proof 3 needs input shaping. Klipper has it. On Marlin, send `M593` in a terminal: if it answers "unknown command", your firmware doesn't have it.

**Filming, the same every time:**
- Tripod, phone in landscape and in slow motion, untouched between films. Use the same camera setting for every film.
- A high-contrast mark on the print head, with the head moving left to right in frame. Lock focus and exposure if you can.
- Start filming before you run the G-code, and stop after the last move.
- On an iPhone, set Settings > Camera > Formats to Most Compatible, and copy the original files to this folder.

You also need a kitchen scale, calipers, and known weights you can fasten securely. Nothing loose on a moving head.

**Cost safety.** Physica stops itself at $15 by its own count, even if you forget the setting. That count is an estimate, not a limit on Meta's billing. So check your real usage on Meta's billing page after the first test calls, and again after each paid step. Check Physica's count with `python -m physica.cli meta status`. Use a low limit on the account if Meta offers one. When you finish, delete the key. Don't raise the budget unless Meta's page agrees with Physica's count.

## If your printers are Ultimaker (Cura)

I found no sign these printers support `M593` input shaping, and forum posts say newer ones (Griffin firmware, like Ultimaker 3 and S-series) reject G-code without a special header. None of this has been tried on a real Ultimaker, so ask the makerspace staff first, and stay with the printer. Older models like the 2+ use a different format, so this route may not fit them.

**Test motion.** In Cura, pick your exact printer, slice any small object, and save it as `cube.gcode` in the `physica` folder. Then:

```powershell
python -m physica.cli printer-video excite --axis X --header-from cube.gcode | Out-File -Encoding ascii excite.gcode
```

It copies the header, sets all temperatures to zero, and leaves out `G28` and `M84`, because these printers run their own start and end routines. Copy `excite.gcode` to a USB stick. If the printer refuses it, or the head doesn't make the 20 mm moves with pauses, stop and don't film.

**The fix, in Proof 3.** Use Cura settings instead of `M593`. In Cura, note your Outer Wall Speed and Outer Wall Acceleration, then:

```powershell
python -m physica.cli printer-video goal --name printer --drop 0.6 --firmware cura --speed 100 --current-accel 2000
```

It picks the fastest acceleration that meets your goal. Its promise counts only the gentler push, because ringing scales with acceleration. Timing the speed-ups to whole vibration cycles may help a bit more, but it takes no credit for that. The cost is slower outer walls. Set what it prints in Cura. To film it, make the test motion with the acceleration it names, then pass the same number to `check` and `show`:

```powershell
python -m physica.cli printer-video excite --axis X --header-from cube.gcode --accel 800 | Out-File -Encoding ascii excite_after.gcode
python -m physica.cli printer-video check after.mp4 --name printer --accel 800
python -m physica.cli printer-video show before.mp4 after.mp4 --name printer --accel 800 --out shake.mp4
```

Simulated results, 8 machines with a goal of 60%: true ringing fell 65% to 88% on all 8. Graded on film, 3 reached GOAL MET, 3 LOOKS MET, NOT SURE, and 2 GOAL NOT MET, because film can under-read (37% for a true 67%). So film it several times if you can, and let the printed parts have the last word.

**If the printer ignores the acceleration in the test motion,** the film's clock will be off, and so will the tone. The caliper check in Proof 3 is what catches that.

## Proof 1: unexpected, experiment, explanation, unseen

Run `excite.gcode` and film it for each `.mp4` below.

```powershell
# Learn normal, using live SAM to find the head
python -m physica.cli printer-video baseline h1.mp4 h2.mp4 h3.mp4 h4.mp4 --name printer --sam "print head"
# SAM separates the parts, and Physica feels each. Use parts you can see in your shot
python -m physica.cli printer-video parts h1.mp4 --name printer --parts "print head,gantry,printer frame" --allow-billed-meta
# Learn mass and stiffness: fasten a weighed ~100 g, film 3 times, remove it
python -m physica.cli printer-video calibrate w1.mp4 w2.mp4 w3.mp4 --name printer --added-g 100 --head-g 350

# A friend secretly changes something safe, or nothing. Physica seals its answer
python -m physica.cli printer-video compare trial1.mp4 --name printer
# Muse runs the investigation: it looks, feels through Physica, proposes causes, and asks Physica for a test
python -m physica.cli printer-video investigate --name printer --trial 1 --masses 20,50,100,200 --allow-billed-meta

# It designs the test, sealing what each cause predicts before the weight goes on
# (The plan is already sealed. Without Muse, run plan-test --trial 1 --masses 20,50,100,200 to do this step)
# Fasten the weight it chose, film 3 times
python -m physica.cli printer-video test t1.mp4 t2.mp4 t3.mp4 --name printer --trial 1 --added-g 100
# Muse sees the result, explains it, and proposes the next test. Do this before the reveal, so it doesn't see the truth
python -m physica.cli printer-video investigate --name printer --trial 1 --masses 20,50,100,200 --allow-billed-meta
python -m physica.cli printer-video reveal --name printer --trial 1 --truth changed --truth-cause mass --truth-g 60

# The unseen measurement: a load it has never felt, on top of what's already there
python -m physica.cli printer-video predict --name printer --trial 1 --added-g 60
# Fasten that load, film it, and use the prediction number it printed
python -m physica.cli printer-video grade-predict p1.mp4 --name printer --pred 1
```

If a test says "can't tell", there's nothing learned to predict from. In that case, predict from the healthy printer by leaving out `--trial`.

Do 6 to 10 blind trials, including some where nothing changed, and show `printer-video score`. A "can't tell" counts and stays in. In simulation about half the cause tests gave no answer, so use a heavier weight and 5 films if that happens.

**What to call it:** an explanation chosen between rival physical causes by experiment, on this machine. It isn't a new law of physics.

## Proof 2: Muse and SAM, with and without

```powershell
# Muse: 36 real blade cases. Scores Physica alone, Muse alone, Muse with senses, and Physica with Muse reviewing
python -m physica.cli meta senses --allow-billed-meta
python -m physica.cli meta senses --show
# Then the same test on 36 cases the first run never used, with the reviewer rule already fixed
python -m physica.cli meta senses --confirm --allow-billed-meta
# Muse: does it help find hidden laws? Simulated machines, live Muse
python -m physica.worldmodel muse-test --allow-billed-meta

# SAM: the same films with and without its crop. Run after grade-ripple in Proof 3, so calipers can weigh in
python -m physica.cli printer-video sam-compare h1.mp4 h2.mp4 h3.mp4 h4.mp4 --name printer --sam "print head"
```

Use at least 3 films of one unchanged printer for `sam-compare`, or it reads a real change as wander. Calipers decide it only if the two arms differ by more than calipers can resolve, about 4%. Otherwise tone wander between films decides, then stops felt.

**Physica with Muse reviewing** is the true with-and-without test. If the two disagree, it takes the safer action. That rule was fixed before any case-by-case answer was seen, and `--confirm` is the fair test of it.

**Muse in the printer experiment:** its ideas become sealed forecasts, and if a heavier weight is needed to tell them apart, that weight is chosen. In a simulation with one fixed mixed-cause idea, the weight went from 100 g to 200 g, and no-answer tests on mass or stiffness changes fell from 6 of 120 to 0 of 120. A true mix of both still wasn't settled. That idea was written by hand, so it says nothing yet about real Muse ideas. Only list weights your machine can safely carry.

**These can lose.** If Physica alone beats Muse, or the whole frame ties SAM, the scoreboard says so. A tie is quite possible for SAM on a tidy film, and then its honest contribution is that nobody had to crop by hand. Show what Muse and SAM really did, and say plainly what the numbers were.

## Proof 3: your goal on a real machine, then a second machine

```powershell
# Feel it, and film it first with no shaper on
python -m physica.cli printer-video tune before.mp4 --name printer

# Your goal. Physica picks the lightest setting that can meet it, or refuses
python -m physica.cli printer-video goal --name printer --drop 0.7 --goal "Cut ringing on X by at least 70%" --firmware klipper
# Use --firmware marlin if yours only has M593. Review and apply the setting, film again
python -m physica.cli printer-video check after.mp4 --name printer
# If the goal is missed, run goal again: it moves on to the next shaper

# The visible result, for the video: the shake magnified the same on both films
python -m physica.cli printer-video show before.mp4 after.mp4 --name printer --out shake.mp4
```

**The check that never sees the camera.** Slice a simple square wall part with a fixed outer wall speed of 80 to 100 mm/s, with the shaper off.

```powershell
python -m physica.cli printer-video ripple --name printer --speed 100 --out wall.mp4
# Print it. On the wall running along Y, skip the first ripple or two, then measure across several
python -m physica.cli printer-video grade-ripple --name printer --distance-mm 14.3 --ripples 6
```

Then print the same part with the shaper on, and film both parts side by side under low-angle light. **That's your visible result: a pixel reading isn't print quality, and the part is.**

**Let Muse judge the parts blind.** Take two photos of each wall from the same spot and light, then list them as before, after, before, after. Muse isn't told which is which:

```powershell
python -m physica.cli printer-video muse-judge a_before.jpg a_after.jpg b_before.jpg b_after.jpg --name printer --allow-billed-meta
```

**Teach a second printer:**

```powershell
python -m physica.cli printer-video teach --name printer --out lesson.json
```

It says whether the lesson is verified, which takes at least one held prediction on Printer A and none broken. On Printer B:

```powershell
python -m physica.cli printer-video baseline b1.mp4 b2.mp4 b3.mp4 b4.mp4 --name printerB --sam "print head"
python -m physica.cli printer-video predict --name printerB --card lesson.json --head-g 300 --added-g 60
# Fasten 60 g, film it
python -m physica.cli printer-video grade-predict bp1.mp4 --name printerB --pred 1
```

Only `LESSON APPLIES ON THIS PRINTER` counts: verified on A, held on B, and closer than not using the lesson. One prediction on one pair of printers is a demonstration, so say that. It isn't a general result.

## The other machines: the same sense, ready-made clips

These run from saved results, with no download or API:

```powershell
python -m physica.film f1 --out f1.mp4
python -m physica.film turbine --out turbine.mp4
python -m physica.film downtime --out downtime.mp4
```

| Clip | Data | What it can say | What it can't |
|---|---|---|---|
| Turbine | Real ETH blade | False alarms on a healthy blade: 3 of 48 against 33 of 48 | Ice called ice only 9 of 36. 9 of 111 crack checks passed as weather. The drone flew in a simulator |
| Downtime | Real FEMTO bearings run to failure | Alarmed on 10 of 11, against 6 of 11 for a fixed 10 g alarm | A plain alarm on each bearing's own normal also got 10 of 11. Half the warnings are under 8 minutes. These are overloaded lab bearings, so it isn't downtime avoided |
| F1 | Real telemetry, TUM simulator | Setup change faster on 9 of 9 test cars in the simulator | It holds only if a wing step trades drag for downforce near 1:4. Corner promises held 7 of 9. It isn't from video, and it isn't a track test |

**Don't quote F1 power in kW.** Power and drag trade off on the straights, and the felt 420 to 520 kW sits well below what these cars are known to make. The clip shows where they balance instead.

Meta's own page lists submissions as due Nov 4 at 9 PM ET, which is 8 PM Central. Its published standard for the Indie track is creativity, technical ambition, and whether it works, with no published weights. See [how Physica uses Meta](META_INTEGRATION.md).

## Three-minute film

| Time | Show | Proof |
|---|---|---|
| 0:00–0:15 | Printer running. "AI can see and hear. I gave it the senses to feel what no sensor measures." Cut to `shake.mp4` | The sense |
| 0:15–0:35 | A friend secretly changes the printer. Phone film. `compare` seals an answer | 1 |
| 0:35–0:50 | SAM separates the parts. Muse looks at the photos and proposes causes, and Spark challenges them | 1, 2 |
| 0:50–1:15 | `plan-test` shows the weight with and without Muse, and seals forecasts. Weight on, film, verdict, then Muse learns from the result | 1, 2 |
| 1:15–1:30 | `predict` a load it never felt, then grade it on film | 1 |
| 1:30–1:50 | Muse and SAM, with and without: the real numbers, whichever way they came out | 2 |
| 1:50–2:25 | You state a goal. It picks the setting. `wall.mp4`, calipers on the real part, the two parts side by side, and Muse's blind judgement | 2, 3 |
| 2:25–2:35 | Printer A teaches Printer B, graded on a new film | 3 |
| 2:35–2:52 | The same sense elsewhere: turbine cold scene, F1 felt car, one bearing | The range |
| 2:52–3:00 | `proof` on screen. The vision | All |

Cut a step rather than replace it with a simulated result shown as real.

## Sources

- FEMTO/PRONOSTIA bearings: Nectoux et al. 2012, IEEE PHM Prognostic Challenge, copy at github.com/wkzs111/phm-ieee-2012-data-challenge-dataset
- Printed ringing test: Klipper, Resonance_Compensation docs
- Downtime cost: Siemens, True Cost of Downtime 2024, an estimate extrapolated from 181 interviews and public data
