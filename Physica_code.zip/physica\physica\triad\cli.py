"""Three connected Physica experiences. python -m physica.triad.cli --help"""
from __future__ import annotations
import argparse, json,hashlib
from pathlib import Path
from .video import VideoConfig,extract_track,sealed_video_forecast,evaluate_forecast,forecast_next_frames
from .lens import serve_lens,evaluate_uploaded_video
from .evidence import evidence_manifest,commit_prediction,check_commit,reveal_measurements
from .target_experiments import rank_transfer_experiments


def save(dest,data):
    path=Path(dest);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
    return str(path)

def _config(a):
    return VideoConfig(tuple(a.roi),None if a.ref_roi is None else tuple(a.ref_roi),a.pixels_per_metre,
                       max_frames=a.max_frames,axis=a.axis)

def _args_video(p):
    p.add_argument('video',help='local original clip; nothing is sent to a third party by default')
    p.add_argument('--roi',required=True,nargs=4,type=int,metavar=('X','Y','W','H'))
    p.add_argument('--ref-roi',nargs=4,type=int,metavar=('X','Y','W','H'))
    p.add_argument('--pixels-per-metre',type=float)
    p.add_argument('--max-frames',type=int,default=360)
    p.add_argument('--axis',choices=('x','y'),default='y')
    p.add_argument('--out',required=True)

def _prefix_video(source,n,dest):
    from .video import _get_cv
    cv2=_get_cv();cap=cv2.VideoCapture(str(source))
    if not cap.isOpened():raise ValueError('unreadable video')
    fps=cap.get(cv2.CAP_PROP_FPS);w=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH));h=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    wr=cv2.VideoWriter(str(dest),cv2.VideoWriter_fourcc(*'mp4v'),fps,(w,h))
    if not wr.isOpened():raise ValueError('cannot prepare Meta prefix video')
    try:
        for _ in range(n):
            ok,frame=cap.read()
            if not ok:break
            wr.write(frame)
    finally:wr.release();cap.release()

def main(argv=None):
    p=argparse.ArgumentParser(description='Physica Lab + Discover + Lens: one evidenced physics engine')
    sub=p.add_subparsers(dest='cmd',required=True)
    discover=sub.add_parser('discover-video',help='optical-flow forecast and retrospective held-out evaluation')
    _args_video(discover)
    discover.add_argument('--origin',choices=('real_recording','external_recording','simulation'),default='real_recording')
    discover.add_argument('--context',choices=('furniture','mechanical','general'),default='general')
    prepare=sub.add_parser('prepare-video',help='seal forecast on prefix; NO future-frame access')
    _args_video(prepare);prepare.add_argument('--prefix-frames',type=int,required=True)
    prepare.add_argument('--horizon-frames',type=int,default=30)
    prepare.add_argument('--origin',choices=('real_recording','external_recording','simulation'),default='real_recording')
    check=sub.add_parser('check-video',help='reveal full recording after independently stored preparation')
    _args_video(check);check.add_argument('--commit',required=True)
    lens=sub.add_parser('lens-serve',help='local-only phone browser upload and evaluation')
    lens.add_argument('--port',type=int,default=8765)
    design=sub.add_parser('target-design',help='target-transfer Bayesian intervention ranking, no actuation')
    design.add_argument('request');design.add_argument('--out',required=True)
    inspect=sub.add_parser('inspect-mat',help='inspect numeric signals in external MAT files')
    inspect.add_argument('mat');inspect.add_argument('--out',required=True)
    sample=sub.add_parser('sample-mat',help='summarize selected external physical recording')
    sample.add_argument('mat');sample.add_argument('--field',required=True)
    sample.add_argument('--sample-rate',type=float,required=True);sample.add_argument('--unit',required=True)
    sample.add_argument('--license-note',required=True);sample.add_argument('--out',required=True)
    meta=sub.add_parser('meta-scientist',help='REAL billable Meta Spark/Wonder calls on prefix only')
    meta.add_argument('video');meta.add_argument('--prefix-frames',type=int,required=True)
    meta.add_argument('--allow-billed-meta',action='store_true')
    meta.add_argument('--sam-concept',help='optional SAM 3.1 object to segment and track')
    meta.add_argument('--sam-object-id',type=int,help='SAM object ID for optional calibrated motion')
    meta.add_argument('--pixels-per-metre',type=float,help='independently measured camera scale')
    meta.add_argument('--out',required=True)
    a=p.parse_args(argv)
    if a.cmd=='lens-serve':return serve_lens(port=a.port)
    if a.cmd=='target-design':
        r=json.loads(Path(a.request).read_text())
        result=rank_transfer_experiments(r['prior_covariance'],r['target_features'],r['candidates'],
            target_weights=r.get('target_weights'),risk_penalty=r.get('risk_penalty',0),cost_penalty=r.get('cost_penalty',0))
        print(save(a.out,result));return result
    if a.cmd=='inspect-mat':
        from .paderborn import numeric_arrays
        print(save(a.out,{'source':str(a.mat),'fields':{k:list(v) for k,v in numeric_arrays(a.mat).items()}}));return
    if a.cmd=='sample-mat':
        from .paderborn import selected_trace
        r=selected_trace(a.mat,a.field,sample_rate_hz=a.sample_rate,unit=a.unit,
                         source_metadata={'license_note':a.license_note})
        print(save(a.out,r));return
    if a.cmd=='meta-scientist':
        if not a.allow_billed_meta:raise PermissionError('Live Meta requests require --allow-billed-meta')
        import tempfile
        from .meta_context import live_muse_scientist
        # Crop exclusively first frames. Not allowed to see any held-out footage.
        with tempfile.TemporaryDirectory() as td:
            prefix=Path(td)/'observed_only.mp4';_prefix_video(a.video,a.prefix_frames,prefix)
            facts={'original_file_sha256':hashlib.sha256(Path(a.video).read_bytes()).hexdigest(),
                   'visible_frame_limit':a.prefix_frames,'unobserved_outcomes_withheld':True,
                   'request':'describe physical context, confounders and competing testable causes',
                   'no_numeric_measurements_from_language':True}
            spark=live_muse_scientist(facts,[],video_path=str(prefix),role='spark')
            wonder=live_muse_scientist({**facts,'spark_context':spark['reply']},[],video_path=str(prefix),role='wonder')
            sam=None;calibrated=None
            if a.sam_concept:
                from physica.experience.meta_live import sam_video,calibrated_track_displacement
                sam=sam_video(prefix,concept=a.sam_concept)
                if a.pixels_per_metre and a.sam_object_id is not None:
                    from .video import _get_cv
                    cv2=_get_cv();cap=cv2.VideoCapture(str(prefix))
                    fps=float(cap.get(cv2.CAP_PROP_FPS));cap.release()
                    calibrated=calibrated_track_displacement(sam['boxes'],object_id=a.sam_object_id,
                        meters_per_pixel=a.pixels_per_metre,frames_per_second=fps)
        result={'status':'LIVE_META_RESPONSES_RECORDED_NOT_PHYSICALLY_VERIFIED',
                'spark':spark,'wonder':wonder,'sam':sam,'sam_calibrated_motion':calibrated,'action_authorized':False,
                'heldout_outcomes_sent_to_meta':False}
        print(save(a.out,result));return result
    c=_config(a)
    if a.cmd=='discover-video':
        result=evaluate_uploaded_video(a.video,roi=a.roi,reference_roi=a.ref_roi,
            pixels_per_metre=a.pixels_per_metre,origin=a.origin,model_context=a.context)
        print(save(a.out,result));return result
    if a.cmd=='prepare-video':
        trace=extract_track(a.video,c,frame_limit=a.prefix_frames)
        fore=forecast_next_frames(trace,horizon_frames=a.horizon_frames)
        ev=evidence_manifest(a.video,origin=a.origin,modality='video_motion',units=trace['unit'],
                             calibration_id='independent_scale' if c.pixels_per_metre else None)
        commit=commit_prediction(evidence=ev,observation_cutoff_s=fore['training_end_s'],
                                 forecast=fore,model='Physica video baseline + model selection')
        result={'commit':commit,'config':{'roi':a.roi,'ref_roi':a.ref_roi,'pixels_per_metre':a.pixels_per_metre,
                                         'axis':a.axis,'max_frames':a.max_frames},
                'origin':ev['origin'],
                'note':'The original complete file already exists; this only proves the software did not read future frames for its forecast, not independent chronology.'}
        print(save(a.out,result));return result
    if a.cmd=='check-video':
        prepared=json.loads(Path(a.commit).read_text())
        saved=prepared['config']
        if saved!={'roi':a.roi,'ref_roi':a.ref_roi,'pixels_per_metre':a.pixels_per_metre,
                   'axis':a.axis,'max_frames':a.max_frames}:
            raise ValueError('tracking/calibration config differs from sealed prediction')
        commit=prepared['commit']
        if not check_commit(commit):raise ValueError('invalid signature or changed prediction')
        if evidence_manifest(a.video,origin=prepared['origin'],modality='video_motion')['sha256']!=commit['prediction']['evidence_sha256']:
            raise ValueError('video changed after forecast preparation')
        track=extract_track(a.video,c)
        forecast=commit['prediction']['forecast'];met=evaluate_forecast(track,forecast)
        reveal=reveal_measurements(commit,measurement_file=a.video,accuracy=met,
             notes=['This is a retrospective video holdout, not independent witness of video capture or measurement chronology'])
        result={'valid_prediction_signature':True,'measurement':met,'reveal':reveal,
                'independent_chronology':False,'physical_mechanism_verified':False}
        print(save(a.out,result));return result

if __name__=='__main__': main()
