"""The real part. Nothing is broken on purpose. A part printed at real settings came out with a flaw, and Muse investigates it.

Muse sees the film and a photo of the part, and hears the goal. It chooses what to measure and what could explain the flaw, then Physica seals what each explanation says a real test
will show. A person runs the test. Code does the arithmetic and grades the seals, and Muse sets a measurable goal for the file. Muse never moves anything.
"""
from __future__ import annotations

from physica import seal as _seal
from physica.touch import printer_investigate as I
from physica.touch import printer_ripple as R

_tool = I._tool
_shared = {t["function"]["name"]: t for t in I.TOOLS}
TOOLS = [
    _tool("say_what_you_see", "Say what you can and can't tell about the flaw and the machine from the film and the photo, before using any sense.", {"seen": {"type": "string"}}),
    _tool("feel_the_machine", "Physica's sense: the head's tone and how fast it dies away, measured from the film."),
    _shared["segment_and_feel"], _shared["look_closer"],
    _tool("add_cause", "Propose one explanation for the flaw. Say what it predicts, so a real test can rule it out.", {
        "name": {"type": "string"}, "story": {"type": "string"},
        "ripples_follow_the_tone": {"type": "boolean", "description": "true if this explanation predicts ripples spaced at wall speed divided by the head's tone"},
        "tone_falls_with_weight": {"type": "boolean", "description": "true if a weight fastened on the head should lower the tone. false if this tone doesn't come from the head on its belts"}}),
    _tool("seal_the_tests", "Physica seals what each explanation predicts, for calipers on the part and a known weight on the head. A person will run them.", {
        "grams": {"type": "number", "description": "the known weight to fasten on the head. One of the weights available"}}),
    _tool("read_the_tests", "The results, once a person has run them."),
    _tool("set_goal", "Set the measurable goal for the file: how much less ringing is worth how much extra time. Physica writes the file from this.", {
        "drop": {"type": "number", "description": "from 0.1 to 0.9: the share of the ringing to remove"}, "reason": {"type": "string"}}),
    _shared["finish"]]

SYSTEM = """You are Muse, investigating a real printed part with a flaw. The printer isn't broken on purpose. You can see and reason, but you can't feel, so Physica gives you that sense through tools. \
A person does anything physical. You decide what to measure. Work in order: say_what_you_see, then feel the machine, then measure any part you choose with segment_and_feel. Propose up to 3 explanations that make different predictions, including that the flaw isn't \
ringing at all if the photo suggests that. Call seal_the_tests, then finish and tell the person exactly what to do. After the tests: read_the_tests, say what's supported and what's ruled out, then set_goal if ringing is supported, then finish. If ringing isn't supported, say so and don't set a goal. \
Only state numbers that a tool gave you, exactly as given. If you can't tell, say so. Say why in each call, in one short plain sentence for a general audience."""


def grade_tests(sealed: dict, ripple: dict | None, weight: dict | None) -> dict:
    """Code decides. Each explanation made two predictions, and each is held, missed or not yet tested."""
    if not _seal.intact(sealed):
        return {"status": "INVALID", "reason": "the seal was edited"}
    p = sealed["payload"]["prediction"]
    ripple_held = ripple.get("held") if ripple else None
    fell = None
    if weight:
        fell = bool(weight["tone_with_weight_hz"] < p["tone_falls_below_hz"]) if weight["tone_with_weight_hz"] < p["tone_stays_above_hz"] else False
        if p["tone_falls_below_hz"] <= weight["tone_with_weight_hz"] < p["tone_stays_above_hz"]:
            fell = None
    rows = {}
    for c in p["causes"]:
        checks = []
        if ripple_held is not None:
            checks.append(bool(c["ripples_follow_the_tone"]) == bool(ripple_held))
        if fell is not None:
            checks.append(bool(c["tone_falls_with_weight"]) == fell)
        rows[c["name"]] = "not tested yet" if not checks else ("fits every result" if all(checks) else "ruled out")
    return {"status": "GRADED" if checks_done(ripple, weight) else "PARTLY", "causes": rows, "ripple": {k: ripple.get(k) for k in ("spacing_mm", "held", "verdict", "tone_from_part_hz")} if ripple else None, "weight": weight, "tone_fell": fell, "sealed": sealed["anchor"]}


def checks_done(ripple, weight) -> bool:
    return bool(ripple and weight)


class PartCase:
    tools, system = TOOLS, SYSTEM

    def __init__(self, felt: dict, baseline: dict, film, wall_speed: float, goal: str, masses: list[float], sealed: dict | None = None, ripple: dict | None = None, weight: dict | None = None, round_no: int = 1, save=lambda name, data: None, part_reader=None):
        self.felt, self.baseline, self.film, self.wall_speed, self.goal = felt, baseline, film, wall_speed, goal
        self.part_reader = part_reader
        self.masses, self.sealed, self.ripple, self.weight, self.round, self.save = masses, sealed, ripple, weight, round_no, save
        self.result = weight or ripple
        self.rivals: list[dict] = []
        self.dropped: list[dict] = []
        self.plan: dict | None = None
        self.images: list[tuple[str, str]] = []
        self.chose: list[dict] = []
        self.done: dict | None = None
        self.seen = ""
        self.set_goal: dict | None = None

    def stage(self) -> str:
        lead = f'The person\'s goal: "{self.goal}". '
        return lead + ("The tests have been run. Read the results." if self.result else "Nothing has been tested yet.")

    def call(self, name: str, a: dict) -> dict:
        if name in ("segment_and_feel", "look_closer"):
            return I.Case.call(self, name, a)
        if name == "say_what_you_see":
            self.seen = str(a.get("seen", ""))[:500]
            return {"noted": True}
        if name == "feel_the_machine":
            return {"head_tone_hz": self.felt.get("freq_hz"), "damping": self.felt.get("damping"), "tones_across_films_hz": self.baseline.get("tones_hz"), "outer_wall_speed_mm_s": self.wall_speed,
                    "ripple_spacing_if_this_tone_mm": round(self.wall_speed / float(self.felt["freq_hz"]), 3), "note": "From pixels in phone films, not a contact sensor"}
        if name == "add_cause":
            cause = {"name": str(a.get("name", ""))[:60], "story": str(a.get("story", ""))[:300], "ripples_follow_the_tone": bool(a.get("ripples_follow_the_tone")), "tone_falls_with_weight": bool(a.get("tone_falls_with_weight"))}
            if not cause["name"]:
                return {"refused": "give it a name"}
            if cause["name"].lower() not in {r["name"].lower() for r in self.rivals} and len(self.rivals) < 3:
                self.rivals.append(cause)
            return {"added": cause["name"], "causes_so_far": [r["name"] for r in self.rivals]}
        if name == "seal_the_tests":
            return self._seal_tests(float(a.get("grams") or 0))
        if name == "read_the_tests":
            if not self.sealed:
                return {"not_sealed_yet": True}
            if not self.result:
                return {"not_run_yet": True}
            return grade_tests(self.sealed, self.ripple, self.weight)
        if name == "set_goal":
            drop = float(a.get("drop") or 0)
            if not 0.1 <= drop <= 0.9:
                return {"refused": "the goal must remove between 0.1 and 0.9 of the ringing"}
            self.set_goal = {"drop": round(drop, 3), "reason": str(a.get("reason", ""))[:300]}
            self.save("muse_goal", self.set_goal)
            return {"goal_set": drop, "next": "Physica writes the file from this. A person reviews it and starts the print."}
        if name == "finish":
            self.done = {"explanation": str(a.get("explanation", ""))[:1200], "for_the_person": str(a.get("for_the_person", ""))[:500]}
            return {"ended": True}
        return {"error": f"no tool named {name}"}

    def _seal_tests(self, grams: float) -> dict:
        if len(self.rivals) < 2:
            return {"refused": "add at least two explanations that make different predictions first"}
        if len({(r["ripples_follow_the_tone"], r["tone_falls_with_weight"]) for r in self.rivals}) < 2:
            return {"refused": "these explanations all predict the same thing, so no test can separate them"}
        if grams not in self.masses:
            return {"refused": f"choose one of the available weights: {self.masses}"}
        f = float(self.baseline["mean_hz"])
        margin = max(float(self.baseline.get("changed_limit_hz") or 0), 0.01 * f)      # how far the tone wanders on its own, between films
        spacing = R.forecast(self.felt, self.wall_speed)
        self.save("ripple", spacing)
        sealed = _seal.seal({"causes": self.rivals, "grams": grams, "tone_empty_hz": round(f, 2), "tone_falls_below_hz": round(f - margin, 2), "tone_stays_above_hz": round(f - margin / 2, 2),
                             "spacing_mm": spacing["payload"]["prediction"]["spacing_mm"], "spacing_range_mm": spacing["payload"]["prediction"]["spacing_range_mm"], "wall_speed_mm_s": self.wall_speed},
                            "what each explanation predicts, before the part is measured and the weight goes on")
        self.sealed = sealed
        self.plan = {"chosen_g": grams}
        self.save("part_tests", sealed)
        p = sealed["payload"]["prediction"]
        return {"sealed": sealed["anchor"], "fasten_grams": grams, "ripple_spacing_mm": p["spacing_mm"], "ripple_range_mm": p["spacing_range_mm"], "tone_now_hz": p["tone_empty_hz"], "if_it_falls_below_hz": p["tone_falls_below_hz"]}
