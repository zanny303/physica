# Physica v0.5.0 — CIRTE selective interventional experience transfer

Previous v0.4.3 files retained. Added:

- `grammar/observation.py`: independently calibrated native-unit observation operators (microphone Pa, video m, etc.), asynchronous uncertainty-weighted latent-state filtering and out-of-calibration rejection.
- `grammar/cirte.py`: 3-way selective transfer gate, signed-PEL cross-sensor forward predictions, simple external residual-based UNKNOWN mechanism detector and abstract safe machine action contracts.
- `grammar/eig.py`: Monte Carlo Bayesian expected information gain on a preregistered scalar physical response summary, with safety and target transfer value.
- `grammar/meta_cirte.py`: constrained Muse scientific hypothesis expansion, with independently calibrated parameters only; optional live authenticated Spark+Wonder context planning; no authorization for actuation.
- `grammar/meta_ablation.py`: strict evaluation on actual externally recorded held-out model outputs with equal physical experiment budgets and safeguards against reusing a SAM calibration reference as independent truth.
- `grammar/cirte_field.py`: native-unit signed source → prospective target prediction → signed reveal → new candidate source, all with local integrity checks.
- `grammar/cirte_benchmark.py`: controlled 24 source-like / 24 shifted synthetic target benchmark, open-world mismatch, EIG, sensor ablation and contract examples.
- `grammar/world_readout.py`: single-sample test inference and temporal video embedding readouts. Still **no V-JEPA weights or actual inference**.
- New CLI `grammar cirte-*` commands, 21 targeted tests, self-contained sample fixtures and new research/field/hackathon docs.

**Not claimed:** independent real-world machine transfer, live Meta execution, functioning local V-JEPA weights, validated five-sense hardware or novel physical laws.
