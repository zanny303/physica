"""SAM 3.1 as Physica's eyes: which pixels belong to the object, so motion is read from that object only.

SAM 3.1's video output is text, one record per object per frame, e.g.
  <0f>0<|box;x1=211;y1=228;x2=270;y2=254;w=320;h=334;c=0.93|><|mask;x=0;y=0;data=...|>
(Meta's own parser package, meta-sam-parser, is used when installed; this small parser reads the boxes otherwise.)
Without a key, Physica falls back to grouping pixels by how they move (physica.sense.group_bodies).
"""
from __future__ import annotations

import re

import numpy as np

_FRAME = re.compile(r"<(\d+)f>")
_REC = re.compile(r"(?:^|,)\s*(\d+)\s*<\|box;([^|]*)\|>")


def _records(text: str):
    marks = list(_FRAME.finditer(text))
    for i, m in enumerate(marks):
        body = text[m.end(): marks[i + 1].start() if i + 1 < len(marks) else len(text)]
        body = re.sub(r"<\|mask;[^|]*\|>", "", body)
        for oid, kv in _REC.findall(body):
            yield int(m.group(1)), oid, kv


def parse_sam_text(text: str) -> dict[int, list[dict]]:
    frames: dict[int, list[dict]] = {}
    for fr, oid, kv in _records(text):
        d = dict(p.split("=", 1) for p in kv.split(";") if "=" in p)
        try:
            box = tuple(float(d[k]) for k in ("x1", "y1", "x2", "y2"))
        except KeyError:
            continue
        frames.setdefault(int(fr), []).append({"id": int(oid), "box": box, "score": float(d["c"]) if "c" in d else None,
                                               "size": (float(d.get("w", 0)), float(d.get("h", 0)))})
    return frames


def object_boxes(frames: dict[int, list[dict]]) -> dict[int, tuple[float, float, float, float]]:
    """One box per tracked object: the median of its per-frame boxes, in the coordinates SAM reports."""
    per: dict[int, list] = {}
    for recs in frames.values():
        for r in recs:
            per.setdefault(r["id"], []).append(r["box"])
    return {k: tuple(np.median(np.array(v), 0)) for k, v in per.items()}


def box_mask(box, size_wh, shape_hw, pad: float = 0.1) -> np.ndarray:
    """Boolean mask over a (possibly resized) frame for one SAM box."""
    H, W = shape_hw
    sw, sh = size_wh if size_wh and size_wh[0] else (W, H)
    x1, y1, x2, y2 = box
    bw, bh = x2 - x1, y2 - y1
    x1, x2 = (x1 - pad * bw) * W / sw, (x2 + pad * bw) * W / sw
    y1, y2 = (y1 - pad * bh) * H / sh, (y2 + pad * bh) * H / sh
    m = np.zeros((H, W), bool)
    m[max(int(y1), 0):min(int(np.ceil(y2)), H), max(int(x1), 0):min(int(np.ceil(x2)), W)] = True
    return m
