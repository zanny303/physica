"""E22 - Manipulate: move a structure's own support so it stops resonating with a machine next to it (REAL DATA check).

A motor near the DROPBEAR beam runs at f_motor. If the beam's tone sits near f_motor, the beam resonates. Physica
knows WHY the beam's tone is what it is (E16: a rigid support at x), so it can choose where the beam's own actuator
should move the support to put the tone safely away from f_motor (at least 15%), with the shortest move. It writes
the actuator command and SEALS the tone it expects there (with the error bar it calibrated on A in E16).
The check uses the real recording: the moments when the lab's transducer says the support actually sat at that
place, steady, and the tone the beam actually rang at then. Physica's tracker reads that tone; the promise is graded.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica import seal  # noqa: E402
from physica.cause import discover as D  # noqa: E402
from physica.cause.track import track_tone  # noqa: E402
from physica.data import dropbear  # noqa: E402

OUT = ROOT / "eval" / "results"


def plan(beam, f_motor, x_now_mm, clear=0.15, reachable=(48.0, 175.0)):
    xs = D.XS * beam.length * 1e3
    tone = D.curves(beam, "support", 1e5, n=1)[:, 0]
    ok = (np.abs(tone / f_motor - 1) >= clear) & (xs >= reachable[0]) & (xs <= reachable[1])
    if not ok.any():
        return None
    i = int(np.argmin(np.where(ok, np.abs(xs - x_now_mm), np.inf)))
    return {"move_support_to_mm": float(xs[i]), "from_mm": float(x_now_mm), "predicted_tone_hz": float(tone[i]),
            "tone_now_hz": float(np.interp(x_now_mm, xs, tone)), "f_motor_hz": f_motor}


def main():
    A = dropbear.beam_d2()
    d = dropbear.load_d2(os.environ["PHYSICA_DROPBEAR2"])
    e16 = json.loads((OUT / "E16_hidden_cause.json").read_text())
    tol_hz_rel = 0.03  # the tone model's stated tolerance (E16 rival fitting); promises use +-3% of the predicted tone
    bare = A.bare(1)[0]
    T, f1 = track_tone(d["acc"], d["fs"], (0.5 * bare, 3 * bare), lag_s=None)
    truth = np.interp(T, d["pin_t"], d["pin_mm"])
    # steady moments: the transducer moved less than 1 mm over +-0.15 s (used only to grade, never to plan)
    steady = np.array([np.ptp(truth[max(0, i - 3):i + 4]) < 1.0 for i in range(len(T))])
    trials = []
    for f_motor in (50.0, 55.0, 60.0, 65.0, 70.0, 75.0):
        xs = D.XS * A.length * 1e3
        tone = D.curves(A, "support", 1e5, n=1)[:, 0]
        x_res = float(np.interp(f_motor, tone, xs))  # where the beam would resonate with this motor
        p = plan(A, f_motor, x_res)
        if p is None:
            continue
        s = seal.seal({"intervals": {"tone_hz": [p["predicted_tone_hz"] * (1 - tol_hz_rel), p["predicted_tone_hz"] * (1 + tol_hz_rel)]},
                       "command": {"actuator": "roller support", **p}}, "the beam's tone after the move")
        k = steady & (np.abs(truth - p["move_support_to_mm"]) < 2.0) & np.isfinite(f1)
        if k.sum() < 3:
            trials.append({**p, "anchor": s["anchor"], "checked": False, "why": "the recording never held the support there"})
            continue
        felt = float(np.median(f1[k]))
        rv = seal.reveal(s, {"tone_hz": felt}, seal.interval_grade)
        trials.append({**p, "anchor": s["anchor"], "checked": True, "felt_tone_hz": felt, "moments": int(k.sum()),
                       "promise": rv["verdict"], "held": rv["held"],
                       "clearance_felt_pct": round(100 * abs(felt / f_motor - 1), 1)})
    res = {"LABEL": "REAL DATA check of planned actions (DROPBEAR, beam A)", "trials": trials,
           "held": sum(t.get("held", False) for t in trials), "checked": sum(t["checked"] for t in trials),
           "explanation_card": "cards/explanation_dropbear_support.json (E16)",
           "note": "Planned from physics alone; graded on recorded moments when the support really sat there."}
    (OUT / "E22_retune_beam.json").write_text(json.dumps(res, indent=1, default=float))
    for t in trials:
        print(f"motor {t['f_motor_hz']:.0f} Hz: support {t['from_mm']:.0f} -> {t['move_support_to_mm']:.0f} mm, expect "
              f"{t['predicted_tone_hz']:.1f} Hz" + (f", felt {t['felt_tone_hz']:.1f} Hz ({t['moments']} moments): {t['promise']}, "
                                                   f"clear of the motor by {t['clearance_felt_pct']}%" if t["checked"] else f" ({t['why']})"))
    print("promises held", res["held"], "of", res["checked"])


if __name__ == "__main__":
    main()
