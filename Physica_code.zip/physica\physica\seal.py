"""Sealed predictions: write down what you expect BEFORE you look, so the bar can't move afterwards.

A seal is the prediction + a SHA-256 digest + an Ed25519 signature + the UTC time it was made. `reveal` checks the
seal is intact and grades the prediction against what was measured. A signature proves who sealed it and that it
was not edited; it does not prove WHEN. For an independent time witness, publish the 16-character `anchor` somewhere
public with its own timestamp (a commit, a post, an email to yourself) before the reveal.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from physica.library import sign as _sign


def _digest(payload: dict) -> str:
    return hashlib.sha256(_sign.canonical(payload)).hexdigest()


def seal(prediction: dict, what: str, by: str = "physica") -> dict:
    payload = {"what": what, "prediction": prediction, "by": by,
               "sealed_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    d = _digest(payload)
    return {"payload": payload, "sha256": d, "anchor": d[:16], "signature": _sign.sign(payload),
            "note": "Signature proves origin and integrity, not time; publish the anchor to witness the time."}


def intact(s: dict) -> bool:
    return _digest(s["payload"]) == s["sha256"] and _sign.verify(s["payload"], s["signature"])


def reveal(s: dict, measured: dict, grade) -> dict:
    """grade(prediction, measured) -> dict with at least {'held': bool}. Refuses to grade a broken seal."""
    if not intact(s):
        return {"held": False, "verdict": "INVALID: the seal was edited after it was made", "sha256": s.get("sha256")}
    g = grade(s["payload"]["prediction"], measured)
    return {**g, "sealed_at_utc": s["payload"]["sealed_at_utc"], "revealed_at_utc":
            datetime.now(timezone.utc).isoformat(timespec="seconds"), "sha256": s["sha256"], "measured": measured}


def interval_grade(pred: dict, measured: dict) -> dict:
    """Default grader: every predicted quantity given as {name: [lo, hi]} must contain the measured value."""
    rows = {}
    for k, (lo, hi) in pred.get("intervals", {}).items():
        if k in measured:
            v = float(measured[k])
            rows[k] = {"lo": lo, "hi": hi, "measured": v, "inside": lo <= v <= hi}
    held = bool(rows) and all(r["inside"] for r in rows.values())
    return {"held": held, "rows": rows, "verdict": "promise held" if held else "promise broken"}


def save(s: dict, path: str | Path) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(s, indent=1, default=float))
    return p
