"""E16 - Feel a hidden cause, prove it against ground truth, and carry the EXPLANATION to a different machine.

Real data, two different DROPBEAR beams (ARTS-Lab, CC BY-SA 4.0; see DATA.md). A roller support slides along each
beam; a linear transducer measures where it is. Physica never sees the transducer: it is used only to score.

A (2019 rig, 352 mm, tip accelerometer, 25.6 kHz):
  1. Feel the tone move. Rule causes in or out by physics (mass / crack / uniform / support). Locate.
  2. Score against the transducer, and against the dataset authors' own published real-time model updating.
  3. Calibrate an error bar on the first half, check it on the second half. Seal it into a signed explanation card.
B (2022 rig, 501 mm, different low-g accelerometer, 5 kHz, 50 trials), NO position sensor used:
  4. Load A's card, measure B's dimensions, say where B's support is from its tone alone.
  5. Compare with: A's black-box curve carried over; and a data-driven tracker that learns on B from N labels.
Set PHYSICA_DROPBEAR2 (the dataset JSON) and PHYSICA_DROPBEAR8 (the dataset's data/ folder).
"""
from __future__ import annotations

import glob
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica import seal  # noqa: E402
from physica.cause import discover as D  # noqa: E402
from physica.cause import transfer as X  # noqa: E402
from physica.cause.track import track_tone  # noqa: E402
from physica.data import dropbear  # noqa: E402

OUT = ROOT / "eval" / "results"
TRACK = {"band_over_bare": [0.5, 3.0], "win_s": 0.3, "hop_s": 0.05, "lag_s": 0.2,
         "method": "ESPRIT poles + fixed-lag continuity tracker (live: answer 0.35 s after the moment it describes)"}
PROV_A = {"dataset": "Dataset-2 DROPBEAR Acceleration vs Roller Displacement", "licence": "CC BY-SA 4.0",
          "url": "https://github.com/High-Rate-SHM-Working-Group/Dataset-2-DROPBEAR-Acceleration-vs-Roller-Displacement",
          "cite": "Downey et al., Mech. Syst. Signal Process. 138 (2020) 106551"}
PROV_B = {"dataset": "Dataset-8 DROPBEAR Acceleration vs Roller Displacement", "licence": "CC BY-SA 4.0",
          "url": "https://github.com/High-Rate-SHM-Working-Group/Dataset-8-DROPBEAR-Acceleration-vs-Roller-Displacement"}


def mae(e):
    e = np.abs(np.asarray(e, float))
    e = e[np.isfinite(e)]
    return {"median": float(np.median(e)), "mean": float(np.mean(e)), "p90": float(np.percentile(e, 90)), "n": len(e)}


def part_a(path):
    A = dropbear.beam_d2()
    d = dropbear.load_d2(path)
    bare = A.bare(1)[0]
    band = (TRACK["band_over_bare"][0] * bare, TRACK["band_over_bare"][1] * bare)
    res = {"beam": A.describe(), "provenance": PROV_A}
    t0 = time.time()
    T, f1 = track_tone(d["acc"], d["fs"], band, win=TRACK["win_s"], hop=TRACK["hop_s"], lag_s=TRACK["lag_s"])
    res["track_seconds"] = time.time() - t0
    disc = D.discover(A, f1)
    res["discovery"] = {k: v for k, v in disc.items() if not k.startswith("where")}
    # each answer describes the middle of its window and is available win/2 + lag later
    t_ans = T + TRACK["win_s"] / 2 + TRACK["lag_s"]
    truth_ans = np.interp(t_ans, d["pin_t"], d["pin_mm"])
    truth_mid = np.interp(T, d["pin_t"], d["pin_mm"])
    where = disc["where_mm"]
    res["accuracy_mm"] = {"described_moment": mae(where - truth_mid), "if_read_as_now_when_answered": mae(where - truth_ans)}
    pub = d.get("published")
    if pub is not None:
        tp = np.interp(pub["t"], d["pin_t"], d["pin_mm"])
        k = (T >= pub["t"][0]) & (T <= pub["t"][-1])
        curve = D.curves(A, "support", disc["verdict"]["strength"], n=1)[:, 0]
        x_fft = np.interp(pub["freq_hz"], curve, D.XS * A.length * 1e3)
        res["comparison_same_recording"] = {
            "physica_live": mae((where - truth_mid)[k]),
            "published_model_updating_downey2020": mae(pub["pin_mm"] - tp),
            "fft_tone_through_physica_physics": mae(x_fft - tp),
            "note": ("Published method answers every ~7.6 ms with millisecond delay (real-time FE model updating, built "
                     "for speed). Physica answers every 50 ms about a 0.3 s window and delivers each answer 0.35 s "
                     "later. Physica is not faster; it needs nothing tuned to the beam, and its explanation travels.")}
    # calibrate the error bar on the first half, check it on the second
    half = T < T[len(T) // 2]
    eb = X.calibrate_error(where[half], truth_mid[half], A.length)
    w = X.error_bar_mm(eb, where, A.length)
    st = X.steady(where, A.length)
    k2 = ~half & np.isfinite(where)
    res["error_bar"] = {**eb, "steady_half_width_mm": eb["steady_abs_err_over_L"] * A.length * 1e3,
                        "moving_half_width_mm": eb["moving_abs_err_over_L"] * A.length * 1e3,
                        "steady_share_second_half": float(np.mean(st[k2])),
                        "coverage_second_half": float(np.mean(np.abs(where[k2] - truth_mid[k2]) <= w[k2])),
                        "coverage_second_half_steady": float(np.mean((np.abs(where - truth_mid) <= w)[k2 & st]))}
    tone_over_bare = np.nanpercentile(f1 / bare, [5, 95])
    validation = {"median_abs_err_mm": res["accuracy_mm"]["described_moment"]["median"],
                  "coverage_90": res["error_bar"]["coverage_second_half"], "tone_over_bare_5_95": list(tone_over_bare)}
    card = X.explanation_card(A, disc, TRACK, eb, validation, PROV_A)
    bb = X.black_box_card(f1, truth_mid)
    series = {"t": T[::2].round(3).tolist(), "tone_hz": np.round(f1[::2], 2).tolist(),
              "where_mm": np.round(where[::2], 1).tolist(), "truth_mm": np.round(truth_mid[::2], 1).tolist(),
              "bar_mm": np.round(w[::2], 1).tolist()}
    if pub is not None:
        s = slice(None, None, 25)
        series["published_t"] = pub["t"][s].round(3).tolist()
        series["published_mm"] = np.round(pub["pin_mm"][s], 1).tolist()
    return res, card, bb, series


def part_b(folder, card, bb, n_draws=30, seed=0):
    B = dropbear.beam_d8()
    files = sorted(glob.glob(os.path.join(folder, "Random Index Set Random Dwell", "set*", "trial data", "test*.txt")))
    files += sorted(glob.glob(os.path.join(folder, "Index sets", "slow postional displacement", "trial datatest*.txt")))
    trials = []
    for f in files:
        d = dropbear.load_d8(f)
        out = X.apply_card(card, B, d["channels"]["Low G Accel"], d["fs"])
        v = np.interp(out["t"], np.arange(len(d["pin_v"])) / d["fs"], d["pin_v"])
        set_name = Path(f).parts[-3] if "trial data" in f else "slow"
        trials.append({"file": "/".join(Path(f).parts[-3:]), "set": set_name, "where": out["where_mm"],
                       "tone": out["tone_hz"], "truth_mm": v * dropbear.MM_PER_VOLT_D8, "inside": out["inside_experience"],
                       "half": out["error_bar_mm"], "steady": out["steady"]})
    train = [t for t in trials if t["set"] in ("set0", "set1")]
    test = [t for t in trials if t not in train]
    res = {"beam": B.describe(), "provenance": PROV_B, "trials": len(trials), "train_trials": len(train),
           "test_trials": len(test), "truth_scale": f"{dropbear.MM_PER_VOLT_D8} mm per volt (sensor listing); offset unknown"}
    W = np.concatenate([t["where"] for t in test])
    Y = np.concatenate([t["truth_mm"] for t in test])
    TN = np.concatenate([t["tone"] for t in test])
    ok = np.isfinite(W)
    res["zero_labels_correlation"] = float(np.corrcoef(W[ok], Y[ok])[0, 1])
    res["slope_physica_vs_truth"] = float(np.polyfit(Y[ok], W[ok], 1)[0])
    # 1 label: align the two coordinate frames with one labelled moment from a training trial
    Wtr = np.concatenate([t["where"] for t in train])
    Ytr = np.concatenate([t["truth_mm"] for t in train])
    Ttr = np.concatenate([t["tone"] for t in train])
    oktr = np.isfinite(Wtr) & np.isfinite(Ttr)
    rng = np.random.default_rng(seed)
    H = np.concatenate([t["half"] for t in test])
    ST = np.concatenate([t["steady"] for t in test])
    one, one_mean, cover, cover_st = [], [], [], []
    for _ in range(n_draws):
        i = rng.choice(np.where(oktr)[0])
        c = Ytr[i] - Wtr[i]
        e = np.abs(W + c - Y)
        one.append(np.median(e[ok]))
        one_mean.append(np.mean(e[ok]))
        cover.append(np.mean((e <= H)[ok]))
        cover_st.append(np.mean((e <= H)[ok & ST]))
    res["one_label_mm"] = {"median_over_draws": float(np.median(one)), "mean_abs_median_over_draws": float(np.median(one_mean)),
                           "draws": n_draws}
    res["error_bar_from_A"] = {"steady_half_width_mm": float(np.median(H[ST])) if ST.any() else None,
                               "moving_half_width_mm": float(np.median(H[~ST])) if (~ST).any() else None,
                               "coverage_on_B": float(np.median(cover)), "coverage_on_B_steady": float(np.median(cover_st)),
                               "steady_share": float(np.mean(ST[ok]))}
    res["inside_A_experience_pct"] = float(100 * np.mean(np.concatenate([t["inside"] for t in test])[ok]))
    # black box carried from A (A's numbers, aligned with the same one label)
    bbw = X.apply_black_box(bb, TN)
    c_bb = np.nanmedian(Ytr[oktr] - X.apply_black_box(bb, Ttr[oktr]))
    res["black_box_from_A_mm"] = {**mae((bbw + c_bb - Y)[ok]), "note": "aligned with ALL of B's training labels, its best case",
                                  "tones_outside_A_range_pct": float(100 * np.mean((TN[ok] < min(bb['tone_hz'])) | (TN[ok] > max(bb['tone_hz']))))}
    # Labels on B (they need a position sensor B doesn't have). Both learners get the same labelled moments, drawn
    # only where Physica judges the support steady (a person labelling would also pick still moments).
    STtr = np.concatenate([t["steady"] for t in train])
    pool = np.where(oktr & STtr)[0]
    from scipy.stats import theilslopes
    from sklearn.isotonic import IsotonicRegression
    curve, pcurve = [], []
    for N in (1, 2, 4, 8, 16, 32, 64, 128, 256):
        e_dd, e_ph = [], []
        for _ in range(n_draws):
            idx = rng.choice(pool, size=min(N, len(pool)), replace=False)
            fx, fy, wx = Ttr[idx], Ytr[idx], Wtr[idx]
            if N == 1:
                dd = np.full(ok.sum(), fy[0])
                ph = W[ok] + (fy[0] - wx[0])
            elif N == 2:
                sl, ic = np.polyfit(fx, fy, 1) if fx[0] != fx[1] else (0.0, fy.mean())
                dd = sl * TN[ok] + ic
                sl2, ic2 = np.polyfit(wx, fy, 1) if wx[0] != wx[1] else (1.0, (fy - wx).mean())
                ph = sl2 * W[ok] + ic2
            else:
                dd = IsotonicRegression(out_of_bounds="clip").fit(fx, fy).predict(TN[ok])
                sl2, ic2, _, _ = theilslopes(fy, wx)
                if not np.isfinite(sl2):
                    sl2, ic2 = 1.0, float(np.median(fy - wx))
                ph = sl2 * W[ok] + ic2
            e_dd.append(np.median(np.abs(dd - Y[ok])))
            e_ph.append(np.median(np.abs(ph - Y[ok])))
        curve.append({"labels": N, "median_abs_err_mm": float(np.median(e_dd))})
        pcurve.append({"labels": N, "median_abs_err_mm": float(np.median(e_ph))})
    res["learn_on_B_from_labels"] = curve
    res["physica_plus_labels_on_B"] = pcurve
    res["crossover_labels"] = next((c["labels"] for c, q in zip(curve, pcurve)
                                    if c["median_abs_err_mm"] < q["median_abs_err_mm"] and c["labels"] > 1), None)
    # the other sensors on B (honest: one strain gauge and the second accelerometer)
    others = {}
    for ch in ("SG_306_b", "Accel"):
        es = []
        for f in files[:10]:
            d = dropbear.load_d8(f)
            if ch not in d["channels"]:
                continue
            out = X.apply_card(card, B, d["channels"][ch], d["fs"])
            v = np.interp(out["t"], np.arange(len(d["pin_v"])) / d["fs"], d["pin_v"]) * dropbear.MM_PER_VOLT_D8
            k = np.isfinite(out["where_mm"])
            if k.sum() > 10:
                es.append(np.corrcoef(out["where_mm"][k], v[k])[0, 1])
        others[ch] = {"trials": len(es), "median_correlation": float(np.median(es)) if es else None}
    res["other_sensors_on_B"] = others
    ex = test[0]
    series = {"file": ex["file"], "t": (np.arange(len(ex["where"])) * 0.05 + 0.3).round(2).tolist(),
              "where_mm": np.round(ex["where"] + (np.median(Ytr - np.nan_to_num(Wtr, nan=np.nanmedian(Wtr)))), 1).tolist(),
              "truth_mm": np.round(ex["truth_mm"], 1).tolist(), "tone_hz": np.round(ex["tone"], 2).tolist()}
    return res, series


def main():
    res = {}
    a, card, bb, sa = part_a(os.environ["PHYSICA_DROPBEAR2"])
    res["A"] = a
    OUT.mkdir(parents=True, exist_ok=True)
    (ROOT / "cards").mkdir(exist_ok=True)
    (ROOT / "cards" / "explanation_dropbear_support.json").write_text(json.dumps(card, indent=1, default=float))
    # seal B's answer BEFORE B's truth is read: what Physica promises about B from A's card alone
    promise = seal.seal({"intervals": {"one_label_median_abs_err_mm": [0, a["error_bar"]["steady_half_width_mm"] * 501 / 352.5]},
                         "card_sha256": seal._digest(card["payload"])}, "B's support tracking error, from A's card only")
    b, sb = part_b(os.environ["PHYSICA_DROPBEAR8"], card, bb)
    res["B"] = b
    res["sealed_promise_about_B"] = seal.reveal(promise, {"one_label_median_abs_err_mm": b["one_label_mm"]["median_over_draws"]},
                                               seal.interval_grade)
    res["made_with"] = {"track": TRACK, "note": "tracker settings fixed on A before B was scored"}
    (OUT / "E16_hidden_cause.json").write_text(json.dumps(res, indent=1, default=float))
    (OUT / "E16_series.json").write_text(json.dumps({"A": sa, "B": sb}, default=float))
    v = a["discovery"]["verdict"]
    print("A:", v["say"])
    c = a["comparison_same_recording"]
    print("A accuracy (median / mean mm): Physica %.2f / %.2f | published model updating %.2f / %.2f | FFT tone %.2f / %.2f" % (
        c["physica_live"]["median"], c["physica_live"]["mean"], c["published_model_updating_downey2020"]["median"],
        c["published_model_updating_downey2020"]["mean"], c["fft_tone_through_physica_physics"]["median"], c["fft_tone_through_physica_physics"]["mean"]))
    eb = a["error_bar"]
    print("A error bar steady ±%.1f mm / moving ±%.1f mm; coverage on unseen half %.2f (steady %.2f, steady share %.2f)" % (
        eb["steady_half_width_mm"], eb["moving_half_width_mm"], eb["coverage_second_half"], eb["coverage_second_half_steady"], eb["steady_share_second_half"]))
    print("B zero labels: corr %.3f; slope %.3f" % (b["zero_labels_correlation"], b["slope_physica_vs_truth"]))
    e = b["error_bar_from_A"]
    print("B one label: %.2f mm median (mean %.2f); A's bars (steady ±%.1f / moving ±%.1f) cover %.2f on B (steady %.2f)" % (
        b["one_label_mm"]["median_over_draws"], b["one_label_mm"]["mean_abs_median_over_draws"], e["steady_half_width_mm"], e["moving_half_width_mm"], e["coverage_on_B"], e["coverage_on_B_steady"]))
    print("B black box from A: %.2f mm median (tones outside A's range: %.0f%%)" % (b["black_box_from_A_mm"]["median"], b["black_box_from_A_mm"]["tones_outside_A_range_pct"]))
    print("B learn from labels:", [(c["labels"], round(c["median_abs_err_mm"], 2)) for c in b["learn_on_B_from_labels"]])
    print("B physica + labels:", [(c["labels"], round(c["median_abs_err_mm"], 2)) for c in b["physica_plus_labels_on_B"]],
          "-> data-driven overtakes at", b["crossover_labels"], "labels")
    print("other sensors:", b["other_sensors_on_B"])
    print("sealed promise:", res["sealed_promise_about_B"]["verdict"])


if __name__ == "__main__":
    main()
