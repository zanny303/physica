# Physica v0.13 — Agentic Discovery and Prospective Feeling

## What was changed, and why

This release builds on the actual **v0.12.1** repository rather than replacing it.

1. **Autonomous *bounded* mechanism generation** (`physica/mace/agentic_v013.py`): Physica constructs a finite library of polynomial interactions and sine-phase bases from available, calibrated numerical signals. Unlike the v0.12.1 illustrated nomination, it is NOT handed the simulator's missing sine equation. It fits coefficients on source training episodes and selects structures on two independently generated source validation episodes. No target test outcomes are used during structure selection. This is **finite hypothesis search**, not open-ended invention of physical laws.
2. **Source-to-target structural transfer with refusal**: a selected source equation can be refitted on B's own local measurements and evaluated on B's separate low-force probe. Source transfer must outperform the best source-blind candidate on a whole trajectory, not just one-step acceleration. If it does not, the source is refused. A target-only baseline searches the same finite dictionary with the same B data budget. The default demo selects target-only on both B and C: **0% additional source-transfer advantage**; that honest negative result matters.
3. **Frozen predictions and later simulated reveal**: both target forecasts and their signatures are written to `02_forecasts_SEALED_BEFORE_SIMULATOR_REVEAL.json` before calling the simulator to create B/C future observations. Camera and acoustic output are compared separately. In this simulation, B and C both have a calibrated latent physical state available for model fitting: the result is not proof of raw cross-sensory transfer on real bodies.
4. **Real prospective field protocol** (`physica/mace/prospective_field_v013.py`): `prepare` takes only the model, initial state, planned actions, calibration assertion, and a prior-evidence hash; it rejects future measurements. It signs a future sensory forecast. `reveal` is a separate process that takes a later CSV, checks the signature and time alignment, and reports error. A local signature does NOT establish independently witnessed chronology or the trustworthiness of a human-declared calibration. Do not generate actual hardware commands with these utilities.
5. **Opt-in iterative Muse** (`physica/mace/meta_cycle_v013.py`): up to 2 or 3 authenticated, explicitly authorized Muse nominations. Each candidate is parsed by the existing restricted non-executable grammar and fitted to actual training data, then judged against separate validation episodes. Predictions, coefficients, and physical safety decisions are numerical, not LLM assertions. The *Studio* integration limits this to two billed calls. It does not claim authenticated Muse calls were completed in development.
6. **Lockbox privacy fix**: `open_world_meta.investigate()` no longer scores the test lockbox before Meta nomination. The `discover(...,open_lockbox=False)` mode exposes validation-only diagnostics. Test scoring occurs once after model selection on the final branch only. Tests for existing v0.12.1 behavior remain.
7. **Live local dual-modality sensing**: the Studio webcam measures region-of-interest frame difference corrected by background change; optional browser microphone measures acoustic RMS. Both stay locally in the browser and are **uncalibrated**. They are not live SAM segmentation, tactile pressure, SI displacement, or a validated fault diagnosis. The previous signed-SAM video bridge, calibration requirements, video upload, and Lens remain available.
8. **Experiment-planner link**: the investigation publishes non-actuating, review-only follow-up probes ranked by hypothesis disagreement and approximate expected target information, risk and cost. Its Gaussian approximation is not a proof of the best experiment.
9. **Visual theater**: `DISCOVERY_THEATER.html` displays forecast-vs-measurement and fair target-only results with explicit `SIMULATION` warnings. Existing Studio Lab, Discover, Transfer, Lens, Feel Check and Meta sections are preserved.

## How to run on Windows Terminal

From the **directory containing `pyproject.toml`** (the inner `physica` folder), assuming your Python 3.12 virtual environment is one folder above:

```powershell
$env:PYTHONUTF8 = "1"
..\.venv\Scripts\python.exe -m pip install -e ".[dev,video]"
..\.venv\Scripts\python.exe -m physica.studio --open-browser
```

Open `http://127.0.0.1:8765`, then **Launch the Discovery Theater**.

Direct commands:

```powershell
..\.venv\Scripts\python.exe -m physica.mace.agentic_v013 demo --out demo\v013
start demo\v013\DISCOVERY_THEATER.html
..\.venv\Scripts\python.exe -m physica.mace.agentic_v013 benchmark --seeds 12 --out demo\v013_benchmark
..\.venv\Scripts\python.exe -m pytest -q tests\test_mace_v013.py
```

### Use a *real* future sensor measurement

The researcher's `field_plan.json` must contain ONLY:

```json
{
  "target_id": "B_camera",
  "sensor": "camera_m",
  "model": {
    "terms": [
      {"id": "linear_position", "factors": [{"field": "x", "transform": "linear"}]},
      {"id": "linear_velocity", "factors": [{"field": "v", "transform": "linear"}]},
      {"id": "known_acceleration", "factors": [{"field": "u", "transform": "linear"}]},
      {"id": "offset", "factors": []}
    ],
    "coefficients": [-0.82, -0.34, 1.0, 0.0]
  },
  "initial": [0.24, 0.03],
  "planned": {
    "dt": 0.035,
    "u": [0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1],
    "temperature_delta": [0,0,0,0,0,0,0,0,0,0]
  },
  "evidence_sha256": "<actual 64-hex digest from previous calibration and probe data>",
  "calibration": {"verified": false, "units": "m", "independent_reference": "to be supplied"}
}
```

**This example is intentionally blocked:** replace the numerical coefficients with properly fitted values, the evidence hash with the SHA-256 of actual prior raw files, and set `verified` true **only if an independent reference calibration has actually happened**. `u` must be known, approved, dimensionally normalized to the model; no hardware automation is provided.

Then run the first command **before conducting the physical test**:

```powershell
..\.venv\Scripts\python.exe -m physica.mace.prospective_field_v013 prepare --input field_plan.json --out demo\sealed_forecast.json
```

Keep the signed file unchanged. Later collect a CSV whose header is `t,camera_m` and whose timestamps match the planned sampling interval (starting at one `dt`). After the test:

```powershell
..\.venv\Scripts\python.exe -m physica.mace.prospective_field_v013 reveal --sealed demo\sealed_forecast.json --observations actual_future_measurements.csv --out demo\reveal.json
```

An external witness/time-stamped recording is required to independently establish the chronology.

### Live Meta agentic reasoning (optional billed operation)

Set the key **locally** in the same Terminal session. Never include it in a ZIP, Git commit or screenshot:

```powershell
$env:MODEL_API_KEY = "YOUR_PRIVATE_KEY"
..\.venv\Scripts\python.exe -m physica.mace.meta_cycle_v013 --rounds 2 --model muse-wonder-1.0 --allow-billed-meta --out demo\muse_agentic_log.json
```

Or go to **Meta & System** in Studio, check explicit billing authorization and select **Run 2-round agentic Muse experiment**. Both use **synthetic source evidence** in this example. A successful authenticated response is not itself a scientific discovery; compare its validation result with the no-Meta search.

**SAM**: The previous `python -m physica.mace.cli sam-video ...` flow remains, with explicit `--allow-billed-meta`, calibrated pixels-per-metre, and independently verified stationary reference. Meta's `meta-sam-parser` handles the specialized streaming segmentation format. This is video ingestion, **not** unverified inference of stiffness or force.

### Training on real external data

Paderborn Bearing DataCenter: https://mb.uni-paderborn.de/en/kat/research/bearing-datacenter/data-sets-and-download

The existing `physica.remote_bench` trainer can use real vibration and motor-current recordings. Distinct bearing IDs must stay separated across train, validation and test. This is **passive observational sensory training**, not action-conditioned causal ground truth. The current container environment has no DNS/network access to download the dataset; therefore **NO real cloud training was executed for v0.13**.

For a controlled real physical experiment, provide independent `x,v,u,acceleration` measurements with units and timestamps, plus optional independently measured environmental channels. Real hardware, licensing, and calibration are the user's responsibility. CSV protocol: `docs/V0121_UNKNOWN_PHYSICS_META_PROTOCOL.md` and this guide.

## Deep research and why these methods were used

- [Meta Model API documentation](https://dev.meta.ai/docs/overview): Muse Spark/Wonder support structured reasoning. We use their outputs to nominate, not authorize, mechanisms.
- [SAM official client libraries](https://dev.meta.ai/docs/sam/client-libraries): the Meta-SAM parser converts specialized streaming geometry into typed output, still requiring geometric calibration for physical quantities.
- [Meta Wearables Toolkit](https://developers.meta.com/wearables/faq/): supported glasses can provide camera, IMU/motion and audio through compatible apps; this browser app is **not** the native toolkit application.
- [Co-Scientist, Nature (2026)](https://www.nature.com/articles/s41586-026-10644-y): generating and critiquing hypotheses across rounds is useful, but scientific conclusions require experimental verification.
- [Designing physics experiments with AI, Nature (2026)](https://www.nature.com/articles/s41586-026-10898-6): adaptive experimental design requires explicit objectives, reliable simulators and search spaces.
- [PySINDy](https://pysindy.readthedocs.io/en/stable/): sparse equation discovery provides an essential **strong baseline** for later tests. The present finite dictionary and ridge fits are not themselves mathematically novel.

## Measurable next milestones

1. Run a real prospective A→B trial, preserving independently witnessed time order and calibration.
2. Compare source structure transfer with **same-budget** target-only identification and PySINDy/SINDy-with-control on unseen physical bodies. Report negative cases and refusal rates.
3. Have an authenticated Muse model nominate an equation that an equivalent fixed search cannot represent, without access to the hidden truth. Use a third, untouched test experiment.
4. Test calibrated SAM motion against a stationary reference in footage. Evaluate the impact of Meta visual segmentation on numeric motion accuracy (with Meta off vs on).
5. Train/evaluate on actual publicly available vibration + current data; test whether two senses add information under noise and occlusion.
6. Build an actual native glasses companion using the Device Access Toolkit/Mock Device Kit; this ZIP does **not** include or claim that SDK app.

### Truthfulness contract

**Implemented and tested:** bounded mechanism generation, signed simulation forecast/reveal, target-only comparator, local webcam+microphone preview, optional Meta request path, and signed field forecast command.

**Not established:** arbitrary law invention, cross-body transfer advantage, full real-time SAM-powered diagnosis, automatic equipment diagnosis, live Meta model efficacy, native glasses app, trained large multimodal foundation model, or a scientific breakthrough. The results MUST NOT be described as having those properties.
