"""E2: wobble in PHYSICAL UNITS (g·mm) on the Fraunhofer unbalance rig.

Calibrate with healthy data (0D) plus ONE known level (1D, 45.9 g·mm) only.
Predict levels 2-4 on the evaluation files (2E, 3E, 4E; different speed range) and report error in g·mm.
Writes the wobble card model (used by E6's PLC translator) and a signed card.

  PHYSICA_FRAUNHOFER_DIR=/path/to/unzipped python eval/e2_wobble_units.py [--max-rows N]
"""
from __future__ import annotations

import argparse
import json

import numpy as np

from common import boot_ci, save_result
from physica import config
from physica.data import fraunhofer as FH
from physica.feel.axes import WobbleCalibrator
from physica.library import cards


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-rows", type=int, default=None, help="limit rows per file for a quick run")
    ap.add_argument("--root", default=None)
    a = ap.parse_args(argv)
    load = lambda n: FH.order1_windows(FH.load(n, a.root, a.max_rows))
    h, k = load("0D"), load("1D")
    cal = WobbleCalibrator(bin_hz=1.0).fit(h["speed_hz"], h["a1_combined"], k["speed_hz"], k["a1_combined"], FH.LEVELS_GMM[1])
    rows = {}
    for name in ["0E", "1E", "2E", "3E", "4E", "2D", "3D", "4D"]:
        try:
            d = load(name)
        except FileNotFoundError:
            continue
        p = cal.predict(d["speed_hz"], d["a1_combined"])
        g = p["gmm"][p["inside_proven_range"]]
        true = FH.LEVELS_GMM[int(name[0])]
        rows[name] = {"true_gmm": true, "median_est_gmm": float(np.median(g)) if len(g) else None,
                      "est_ci95_median": boot_ci(g, stat=np.median) if len(g) else None,
                      "abs_err_gmm": float(abs(np.median(g) - true)) if len(g) else None,
                      "windows_in_range": int(len(g)), "windows_total": int(len(p["gmm"])),
                      "speed_range_hz": [float(d["speed_hz"].min()), float(d["speed_hz"].max())] if len(d["speed_hz"]) else None,
                      "used_for_calibration": name in ("0D", "1D")}
    held = [r for n, r in rows.items() if n in ("2E", "3E", "4E") and r["median_est_gmm"] is not None]
    if len(held) >= 2:
        t = np.array([r["true_gmm"] for r in held]); e = np.array([r["median_est_gmm"] for r in held])
        summary = {"heldout_levels": len(held), "mean_abs_err_gmm": float(np.mean(np.abs(e - t))),
                   "mean_rel_err": float(np.mean(np.abs(e - t) / t)), "pearson_r": float(np.corrcoef(t, e)[0, 1])}
    else:
        summary = {"note": "evaluation files 2E-4E not found"}
    model = cal.to_dict()
    (config.RESULTS_DIR / "E2_wobble_card_model.json").write_text(json.dumps(model, indent=1))
    c = cards.new_card("sense", "Wobble sense: imbalance in g·mm from the once-per-turn vibration, calibrated with "
                                "healthy data plus one known trial weight (45.9 g·mm).",
                       {"type": "rotating shaft", "model": "Fraunhofer unbalance rig", "id": "fraunhofer-rig"},
                       units="g·mm", sensors=FH.load("0D", a.root, 10).columns["vibration"],
                       proven_range={"speed_hz": list(cal.proven_range_hz)}, metrics=summary, tags=["wobble", "sense card"])
    cards.save(c, model=model, evidence={"E2.json": json.dumps({"rows": rows, "summary": summary}, default=float)})
    out = {"calibration": {"healthy": "0D", "known": "1D", "known_gmm": FH.LEVELS_GMM[1],
                           "proven_speed_range_hz": cal.proven_range_hz, "calib_rel_err_q90": cal.rel_err_q90},
           "rows": rows, "summary": summary, "card": c["id"], "max_rows": a.max_rows}
    save_result("E2_wobble_units", out)
    for n, r in rows.items():
        print(f"{n}: true {r['true_gmm']:6.1f} g·mm  estimated {r['median_est_gmm']}  ({r['windows_in_range']}/{r['windows_total']} windows in proven range)")
    print("summary:", summary)


if __name__ == "__main__":
    main()
