"""MCP server exposing Physica's tools to any agent (Muse Wonder, or any MCP client).

Run:  python -m physica.agents.mcp_server        (stdio transport)
Requires: pip install 'mcp>=2.2,<3'
"""
from __future__ import annotations

from physica.agents import tools as T


def build_server():
    from mcp.server.mcpserver import MCPServer

    srv = MCPServer(name="physica", title="Physica",
                    description="How AI feels the world: feel, check, recall and translate machine knowledge.",
                    instructions="Cite the card id for every claim. Feel Check results are advice, not a safety certification.")

    @srv.tool(description="Summarise a machine source (channels, duration). Never reveals ground-truth labels.")
    def observe(source: str) -> dict:
        return T.observe(source)

    @srv.tool(description="Run the Feel Transform on a source and return the verdict (what the machine feels that it didn't cause).")
    def feel(source: str) -> dict:
        r = T.feel(source, plot=False)
        return r

    @srv.tool(description="Search the signed knowledge library.")
    def recall(query: str = "") -> list:
        return T.recall(query)

    @srv.tool(description="Arrival check: does a card still fit this machine? Use a flight believed to be healthy.")
    def check(card_id: str, source: str) -> dict:
        return T.check(card_id, source)

    @srv.tool(description="What-if: expected healthy vibration at a given rotor peak frequency (Hz).")
    def predict(card_id: str, rotor_peak_hz: float) -> dict:
        return T.predict(card_id, rotor_peak_hz)

    @srv.tool(description="Translate what was felt into a machine's language: 'ardupilot', 'marlin' or 'plc'. Passes the safety gate first.")
    def translate(source: str, target: str) -> dict:
        return T.translate(source, target)

    return srv


def main():
    build_server().run("stdio")


if __name__ == "__main__":
    main()
