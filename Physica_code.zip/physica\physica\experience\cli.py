"""`physica experience` subcommand: reproducible synthetic demo, real sensor ingest,
crypto preregistration, reveal, bank transfer, physical-language JSON schema.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from .schema import PhysicalEpisode,Quantity
from .seal import seal,reveal,verify_seal,verify_reveal,write_json
from .demo import run_demo
from .transfer import compare,transfer_prior
from .store import add,query


def main(args:list[str]|None=None) -> None:
    p=argparse.ArgumentParser(prog="physica experience")
    sub=p.add_subparsers(dest="step",required=True)
    s=sub.add_parser("demo",help="synthetic A->B transfer and consequence, clearly labeled")
    s.add_argument("--out",default="physica_experience_demo");s.add_argument("--seed",type=int,default=11)
    s=sub.add_parser("ingest",help="convert real video/CSV/NPY using ORIGINAL `physica sense`")
    s.add_argument("source");s.add_argument("--out",required=True)
    s.add_argument("--fps",type=float);s.add_argument("--calibration-id")
    s.add_argument("--body-id",default="unlabelled");s.add_argument("--machine-id",default="phone-or-sensor")
    s.add_argument("--boundary-class",default="unknown")
    s=sub.add_parser("seal",help="cryptographically commit to PREDICTION ONLY before experiment")
    s.add_argument("episode");s.add_argument("--out",required=True)
    s=sub.add_parser("reveal",help="record real numeric observation; preserve original signed prediction")
    s.add_argument("committed");s.add_argument("--value",type=float,required=True)
    s.add_argument("--unit",required=True);s.add_argument("--sigma",type=float)
    s.add_argument("--observed-sha256",help="SHA256 of raw observation recording")
    s.add_argument("--out",required=True)
    s=sub.add_parser("verify",help="check Ed25519 seal and optional reveal signature")
    s.add_argument("record")
    s=sub.add_parser("bank-add",help="store signed source record; only verified outcomes can teach")
    s.add_argument("record");s.add_argument("--bank",default="physical_bank")
    s=sub.add_parser("bank-query",help="query compatible signed verified source experiences")
    s.add_argument("target");s.add_argument("--bank",default="physical_bank")
    s=sub.add_parser("transfer",help="derive a prior for B from A (not a verified diagnosis)")
    s.add_argument("source");s.add_argument("target")
    s=sub.add_parser("schema",help="export typed JSON schema for interoperable language")
    s.add_argument("--out",default="experience.schema.json")
    s=sub.add_parser("muse-review",help="constrained Meta Muse planner; mock by default")
    s.add_argument("facts");s.add_argument("--allowed",nargs="*",default=[])
    s.add_argument("--role",choices=["wonder","spark"],default="wonder")
    s=sub.add_parser("frontier-demo",help="v0.3 sealed A->B dimensionless transfer + dual-world experiment (SYNTHETIC)")
    s.add_argument("--out",default="physica_frontier_demo")
    s.add_argument("--seed",type=int,default=24)
    s=sub.add_parser("frontier-ablation",help="repeat simulator across parameter-shift seeds (SYNTHETIC)")
    s.add_argument("--out",default="physica_frontier_ablation")
    s.add_argument("--seeds",type=int,default=30)
    sub.add_parser("meta-status",help="explicit model-integration readiness, no fake API calls")
    s=sub.add_parser("dual-rank",help="rank safe experiments given calibrated same-observable model forecasts")
    s.add_argument("request_json",help="JSON with prior, actions, paired_forecasts; see docs/DUAL_WORLD.md")
    s.add_argument("--out",default="dual_world_ranking.json")
    s=sub.add_parser("frontier-prepare",help="field protocol: seal B forecast BEFORE recording B response")
    s.add_argument("source_reveal_json")
    s.add_argument("source_csv")
    s.add_argument("source_calibration")
    s.add_argument("target_calibration")
    s.add_argument("target_times_csv")
    s.add_argument("--out",required=True)
    s=sub.add_parser("frontier-check",help="field protocol: verify B's post-measurement CSV against sealed forecast")
    s.add_argument("prepared_dir")
    s.add_argument("target_observation_csv")
    s.add_argument("--out",required=True)
    s=sub.add_parser("crate-field-prepare",help="Signed source A experiences -> seal CRATE prediction before B response")
    s.add_argument("sources_manifest");s.add_argument("target_calibration");s.add_argument("target_times_csv")
    s.add_argument("--out",required=True)
    s=sub.add_parser("crate-followup-prepare",help="Learn from B's signed observation, then seal a distinct unseen C forecast")
    s.add_argument("candidate_memory");s.add_argument("prior_B_signed_reveal")
    s.add_argument("C_calibration");s.add_argument("C_times_csv")
    s.add_argument("--out",required=True)
    s=sub.add_parser("crate-probe-gate",help="Independently check signed low-force B probe against source-like held-out conformal threshold")
    s.add_argument("sources_manifest");s.add_argument("target_calibration")
    s.add_argument("probe_reveal");s.add_argument("probe_csv");s.add_argument("probe_calibration")
    s.add_argument("--sensor-sigma-m",type=float,required=True,help="independently calibrated 1-sigma probe displacement noise (metres)")
    s.add_argument("--out",required=True)
    s=sub.add_parser("crate-field-check",help="Compare real B observations with precommitted CRATE prediction and learn candidate memory")
    s.add_argument("prepared_dir");s.add_argument("target_observation_csv");s.add_argument("--out",required=True)
    s=sub.add_parser("meta-crate-prepare",help="LIVE Meta A-side scientific fusion then safe CRATE B prediction (NO B observations)")
    s.add_argument("source_video");s.add_argument("source_sensor_csv");s.add_argument("experiment_request_json")
    s.add_argument("sources_manifest");s.add_argument("target_calibration");s.add_argument("target_times_csv")
    s.add_argument("--concept",required=True);s.add_argument("--track-id",type=int,default=0)
    s.add_argument("--meters-per-pixel",type=float,required=True);s.add_argument("--fps",type=float,required=True)
    s.add_argument("--expected-action",required=True);s.add_argument("--out",required=True)
    s.add_argument("--allow-billed-meta",action="store_true")
    s=sub.add_parser("meta-fusion-live",help="LIVE Spark context + SAM geometry + Wonder scientist + physical safety gate")
    s.add_argument("video");s.add_argument("sensor_csv");s.add_argument("experiment_request_json")
    s.add_argument("--concept",required=True);s.add_argument("--track-id",type=int,default=0)
    s.add_argument("--meters-per-pixel",type=float,required=True);s.add_argument("--fps",type=float,required=True)
    s.add_argument("--out",required=True)
    s.add_argument("--allow-billed-meta",action="store_true",help="confirm paid live Meta API usage")
    s=sub.add_parser("crate-stress",help="synthetic OOD falsification and 0/1-probe sample-efficiency counts")
    s.add_argument("--out",default="crate_stress_v041.json")
    s.add_argument("--seed",type=int,default=42);s.add_argument("--targets",type=int,default=24)
    s=sub.add_parser("crate-demo",help="v0.4 CRATE causal residual transfer closed-loop simulation and scoreboard")
    s.add_argument("--out",default="physica_crate_demo")
    s.add_argument("--seed",type=int,default=42)
    s.add_argument("--targets",type=int,default=24)
    sub.add_parser("meta-preflight",help="show verified Meta model IDs/config, without calling any API")
    s=sub.add_parser("meta-scientist",help="LIVE Muse grounded hypothesis review (requires key)")
    s.add_argument("facts_json");s.add_argument("--allowed",nargs="*",default=[])
    s.add_argument("--role",choices=["spark","wonder"],default="wonder")
    s.add_argument("--image");s.add_argument("--video")
    s.add_argument("--out",required=True)
    s=sub.add_parser("sam-video",help="LIVE SAM 3.1 upload+video tracking (requires key)")
    s.add_argument("video");s.add_argument("--concept",required=True);s.add_argument("--out",required=True)
    s=sub.add_parser("visual-fit",help="train a numeric visual readout from external V-JEPA embeddings and independent calibration")
    s.add_argument("training_json");s.add_argument("calibration_json");s.add_argument("--out",required=True)
    s=sub.add_parser("visual-forecast",help="apply a calibrated visual readout to held-out V-JEPA embedding")
    s.add_argument("readout_json");s.add_argument("embedding_json");s.add_argument("--body-id",required=True)
    s.add_argument("--out",required=True)
    a=p.parse_args(args)
    if a.step=="crate-field-prepare":
        from .crate_field import prepare
        print(json.dumps(prepare(a.sources_manifest,a.target_calibration,a.target_times_csv,a.out),indent=2))
    elif a.step=="crate-followup-prepare":
        from .crate_field import followup_prepare
        print(json.dumps(followup_prepare(a.candidate_memory,a.prior_B_signed_reveal,
            a.C_calibration,a.C_times_csv,a.out),indent=2))
    elif a.step=="crate-probe-gate":
        from .crate_field import probe_gate
        print(json.dumps(probe_gate(a.sources_manifest,a.target_calibration,
            a.probe_reveal,a.probe_csv,a.probe_calibration,a.out,
            sensor_sigma_m=a.sensor_sigma_m),indent=2))
    elif a.step=="crate-field-check":
        from .crate_field import check
        print(json.dumps(check(a.prepared_dir,a.target_observation_csv,a.out),indent=2))
    elif a.step=="meta-crate-prepare":
        from .fusion_transfer import run
        print(json.dumps(run(a.source_video,a.source_sensor_csv,a.experiment_request_json,
            a.sources_manifest,a.target_calibration,a.target_times_csv,concept=a.concept,
            bbox_track_id=a.track_id,meters_per_pixel=a.meters_per_pixel,fps=a.fps,
            expected_action=a.expected_action,output=a.out,
            explicit_bill_permission=a.allow_billed_meta),indent=2))
    elif a.step=="meta-fusion-live":
        from .meta_fusion import run
        r=run(a.video,a.sensor_csv,a.experiment_request_json,concept=a.concept,
              bbox_track_id=a.track_id,meters_per_pixel=a.meters_per_pixel,
              fps=a.fps,output=a.out,explicit_bill_permission=a.allow_billed_meta)
        print(json.dumps({"status":r["status"],"selected_experiment":r["selected_experiment"]},indent=2))
    elif a.step=="crate-stress":
        from .stress_benchmark import run
        print(json.dumps(run(a.out,seed=a.seed,n_targets=a.targets),indent=2))
    elif a.step=="crate-demo":
        from .loop_demo import run
        r=run(a.out,seed=a.seed,n_targets=a.targets)
        print(json.dumps({"provenance":r["evaluation"],"metrics":r["metrics"],
                          "file":str(Path(a.out)/"physica_v04_experience_lab.html")},indent=2))
    elif a.step=="meta-preflight":
        from .meta_live import preflight
        print(json.dumps(preflight(),indent=2))
    elif a.step=="meta-scientist":
        from .meta_live import muse_scientist
        r=muse_scientist(json.loads(Path(a.facts_json).read_text()),a.allowed,role=a.role,
                         image_path=a.image,video_path=a.video)
        write_json(a.out,r);print("REAL LIVE META RESPONSE ->",a.out)
    elif a.step=="sam-video":
        from .meta_live import sam_video
        r=sam_video(a.video,concept=a.concept)
        write_json(a.out,r);print("REAL SAM SEGMENTATION ->",a.out)
    elif a.step=="visual-fit":
        from .visual_bridge import fit_readout
        r=fit_readout(a.training_json,a.calibration_json)
        write_json(a.out,r.__dict__);print("Calibrated readout ->",a.out)
    elif a.step=="visual-forecast":
        from .visual_bridge import VisualReadout,export_forecast
        r=VisualReadout(**json.loads(Path(a.readout_json).read_text()))
        print(json.dumps(export_forecast(r,a.embedding_json,body_id=a.body_id,out=a.out),indent=2))
    elif a.step=="frontier-prepare":
        from .field_protocol import prepare
        print(json.dumps(prepare(a.source_reveal_json,a.source_csv,a.source_calibration,
                                 a.target_calibration,a.target_times_csv,a.out),indent=2))
    elif a.step=="frontier-check":
        from .field_protocol import check
        print(json.dumps(check(a.prepared_dir,a.target_observation_csv,a.out),indent=2))
    elif a.step=="frontier-demo":
        from .frontier_demo import run_frontier_demo
        result=run_frontier_demo(a.out,seed=a.seed)
        print("SYNTHETIC ONLY / NO LIVE META: "+str(Path(a.out)/"physica_v03_experience_lab.html"))
        print(json.dumps({"verification":result["machine_B_local_verification"],
                          "selected_experiment":result["dual_world_experiment_ranking"]["chosen"],
                          "incompatible_body_refused":result["incompatible_machine_C"]["status"],
                          "signed_pred_reveal":result["target_prediction_signed"] and result["target_reveal_signed"]},indent=2))
    elif a.step=="frontier-ablation":
        from .frontier_demo import synthetic_ablation
        res=synthetic_ablation(a.out,seeds=a.seeds)
        print(json.dumps({k:v for k,v in res.items() if k!="rows"},indent=2))
    elif a.step=="meta-status":
        from .meta_world import status
        print(json.dumps(status(),indent=2))
    elif a.step=="dual-rank":
        from .dual_world import rank_actions,CalibratedForecast
        from .pacer import Experiment
        raw=json.loads(Path(a.request_json).read_text())
        actions=[Experiment(**e) for e in raw["actions"]]
        paired={key:(CalibratedForecast(**v[0]),CalibratedForecast(**v[1]))
                for key,v in raw["paired_forecasts"].items()}
        result=rank_actions(raw["prior"],actions,paired)
        write_json(a.out,result)
        print("Dual-world ranking ->",a.out,"chosen:",result["chosen"])
    elif a.step=="demo":
        r=run_demo(a.out,a.seed)
        print("SYNTHETIC ONLY: A teaches B via signed episodes. Artifacts:",a.out)
        print(json.dumps({k:r[k] for k in ("seal_valid","reveal_valid","machine_B_transfer","safe_experiment_with_bank")},indent=2))
    elif a.step=="ingest":
        from .bridge import ingest
        ep=ingest(a.source,fps=a.fps,calibration_id=a.calibration_id,body_id=a.body_id,
                  machine_id=a.machine_id,boundary_class=a.boundary_class)
        write_json(a.out,ep.model_dump(mode="json",exclude_none=True))
        print("Sensed",len(ep.modal_words),"modes; not verified as causal experience ->",a.out)
    elif a.step=="seal":
        ep=PhysicalEpisode.model_validate(json.loads(Path(a.episode).read_text()))
        data=seal(ep);write_json(a.out,data)
        print("PREDICTION SEALED (not a trusted timestamp):",data["sha256"],"->",a.out)
    elif a.step=="reveal":
        data=reveal(json.loads(Path(a.committed).read_text()),Quantity(value=a.value,unit=a.unit,sigma=a.sigma),
                    raw_observation_sha256=a.observed_sha256)
        write_json(a.out,data);print("REVEALED:",data["result"],"residual:",data["residual"],"->",a.out)
    elif a.step=="verify":
        r=json.loads(Path(a.record).read_text())
        good=verify_reveal(r) if r.get("protocol")=="physica.reveal/v1" else verify_seal(r)
        print("VALID" if good else "INVALID")
        if not good:raise SystemExit(2)
    elif a.step=="bank-add":
        print(add(a.bank,json.loads(Path(a.record).read_text())))
    elif a.step=="bank-query":
        ep=PhysicalEpisode.model_validate(json.loads(Path(a.target).read_text()))
        print(json.dumps(query(a.bank,ep),indent=2))
    elif a.step=="transfer":
        f=lambda path: PhysicalEpisode.model_validate(json.loads(Path(path).read_text()))
        print(json.dumps(transfer_prior(f(a.source),f(a.target)),indent=2))
    elif a.step=="schema":
        write_json(a.out,PhysicalEpisode.model_json_schema());print("Wrote",a.out)
    elif a.step=="muse-review":
        from .meta import review
        facts=json.loads(Path(a.facts).read_text())
        print(json.dumps(review(facts,a.allowed,role=a.role),indent=2))

if __name__=="__main__":main()
