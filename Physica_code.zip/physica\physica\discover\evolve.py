"""Sense Evolution (SPEC 5): AI invents new senses as code, and reality is the judge.

Loop (AlphaEvolve-style, scored by real data instead of a math checker):
  1. Spark writes N candidate `sense(psd, f)` programs (numpy only, run in the sandbox).
  2. Score on the SELECT split (borrowed reference labels: healthy vs damage on training units only).
  3. Keep the top K; show them (code + score) to Spark to mutate/combine; repeat for G generations.
  4. Final judgement on the PROVE split only (units never used for selection).

MOCK mode replaces Spark with a random program generator over a small template family. Results produced
in MOCK mode are labelled as such and are NOT Sense Evolution results; they only show the loop works.
"""
from __future__ import annotations

import json
import random
import re

import numpy as np

from physica.discover import sandbox
from physica.llm import meta_client as mc

PROMPT = """You are inventing a new SENSE for a machine. Inputs: psd (windows x units x freqs, vibration power)
and f (freqs in Hz). Write {n} different python functions, each in its own fenced block:
def sense(psd, f):
    # numpy only (np available). Return one score per window: higher = more likely damaged.
Use physics ideas (energy near rotation peaks, harmonics, asymmetry between units, spectral shape).
Best programs so far, with their held-out scores (AUC, higher is better):
{elite}"""

TEMPLATES = [
    "m = (f >= {a}) & (f <= {b})\n    e = np.log10(psd[:, :, m].sum(-1) + 1e-30)\n    return e.{agg}(axis=1)",
    "m = (f >= {a}) & (f <= {b})\n    e = np.log10(psd[:, :, m].sum(-1) / (psd.sum(-1) + 1e-30) + 1e-30)\n    return e.{agg}(axis=1)",
    "m = (f >= {a}) & (f <= {b})\n    p = psd[:, :, m]\n    r = np.log10(p.max(-1) / (np.median(p, -1) + 1e-30) + 1e-30)\n    return r.{agg}(axis=1)",
    "m = (f >= {a}) & (f <= {b})\n    e = np.log10(psd[:, :, m].sum(-1) + 1e-30)\n    return e.max(axis=1) - np.median(e, axis=1)",
]


@mc.register_mock("sense_programs")
def _mock_programs(messages: list[dict]) -> str:
    seed = abs(hash(messages[-1]["content"])) % (2**32)
    rng = random.Random(seed)
    n = int(re.search(r"Write (\d+)", messages[-1]["content"]).group(1))
    elite = re.findall(r"\(f >= (\d+)\) & \(f <= (\d+)\)", messages[-1]["content"])
    blocks = []
    for _ in range(n):
        if elite and rng.random() < 0.7:  # mutate a parent's band
            a, b = map(int, rng.choice(elite))
            a = max(1, a + rng.randint(-20, 20)); b = max(a + 5, b + rng.randint(-20, 20))
        else:
            a = rng.randint(5, 200); b = a + rng.randint(5, 60)
        body = rng.choice(TEMPLATES).format(a=a, b=b, agg=rng.choice(["max", "mean", "std"]))
        blocks.append(f"```python\ndef sense(psd, f):\n    {body}\n```")
    return "\n\n".join(blocks)


def _programs(text: str) -> list[str]:
    return re.findall(r"```python\n(.*?)```", text, flags=re.S)


def auc(neg: np.ndarray, pos: np.ndarray) -> float:
    neg, pos = np.asarray(neg, float), np.asarray(pos, float)
    if len(neg) == 0 or len(pos) == 0 or not (np.all(np.isfinite(neg)) and np.all(np.isfinite(pos))):
        return 0.5
    allv = np.concatenate([neg, pos])
    ranks = allv.argsort().argsort() + 1
    return float((ranks[len(neg):].sum() - len(pos) * (len(pos) + 1) / 2) / (len(neg) * len(pos)))


def evaluate(code: str, psd: np.ndarray, f: np.ndarray, masks: dict) -> dict:
    try:
        s = sandbox.run(code, "sense", {"psd": psd, "f": f})["out"].ravel()
        if s.shape[0] != psd.shape[0] or not np.all(np.isfinite(s)):
            raise sandbox.Rejected("wrong shape or non-finite output")
    except sandbox.Rejected as e:
        return {"ok": False, "error": str(e)}
    groups = masks.get("select_pos_groups") or [masks["select_pos"]]
    # reality must agree on EVERY borrowed unit, not on average: score = worst unit (guards against over-fitting)
    sel = min(auc(s[masks["select_neg"]], s[g]) for g in groups)
    lines = code.count("\n") + 1
    return {"ok": True, "select_auc": sel, "score": sel - 0.002 * lines, "scores": s}


def prove(scores: np.ndarray, masks: dict, q: float = 0.99) -> dict:
    thr = float(np.quantile(scores[masks["select_neg"]], q))
    det = scores[masks["prove_pos"]] > thr
    fa = scores[masks["prove_neg"]] > thr
    return {"prove_auc": auc(scores[masks["prove_neg"]], scores[masks["prove_pos"]]), "threshold": thr,
            "prove_detect": float(det.mean()), "prove_false_alarm": float(fa.mean()),
            "n_pos": int(len(det)), "n_neg": int(len(fa))}


def run(psd: np.ndarray, f: np.ndarray, masks: dict, generations: int = 5, n: int = 12, keep: int = 4,
        log=print) -> dict:
    elite: list[dict] = []
    history = []
    for g in range(1, generations + 1):
        elite_txt = "\n".join(f"AUC={e['select_auc']:.3f}\n```python\n{e['code']}```" for e in elite) or "(none yet)"
        text = mc.chat("spark", [{"role": "user", "content": PROMPT.format(n=n, elite=elite_txt)}],
                       task="sense_programs", max_tokens=4000, temperature=0.9)
        cands = []
        for code in _programs(text):
            r = evaluate(code, psd, f, masks)
            if r["ok"]:
                cands.append({"code": code, **r})
        pool = sorted(elite + cands, key=lambda r: -r["score"])
        elite = pool[:keep]
        best = elite[0] if elite else None
        history.append({"generation": g, "candidates": len(cands), "best_select_auc": best["select_auc"] if best else None})
        log(f"generation {g}: {len(cands)} programs ran, best select AUC {history[-1]['best_select_auc']}")
        if g == 1 and best:
            gen1 = dict(best)
    final = elite[0]
    return {"mock": mc.is_mock(), "history": history,
            "generation_1_best": {"code": gen1["code"], "select_auc": gen1["select_auc"], **prove(gen1["scores"], masks)},
            "final_best": {"code": final["code"], "select_auc": final["select_auc"], **prove(final["scores"], masks)}}


def to_json(res: dict) -> str:
    return json.dumps(res, indent=1, default=float)
