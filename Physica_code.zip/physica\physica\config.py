"""Paths and settings, read from the environment (and .env if present)."""
from __future__ import annotations

import os
from pathlib import Path

try:  # optional
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # pragma: no cover
    pass

REPO_ROOT = Path(__file__).resolve().parent.parent
CARDS_DIR = Path(os.environ.get("PHYSICA_CARDS_DIR", REPO_ROOT / "cards"))
PREDICTIONS_DIR = REPO_ROOT / "predictions"
EVAL_DIR = REPO_ROOT / "eval"
RESULTS_DIR = Path(os.environ.get("PHYSICA_RESULTS_DIR", EVAL_DIR / "results"))
FIGURES_DIR = EVAL_DIR / "figures"
REPLAY_DIR = REPO_ROOT / "replay"
STATE_DIR = Path(os.environ.get("PHYSICA_STATE_DIR", Path.home() / ".physica"))


def padre_dir() -> Path:
    p = os.environ.get("PHYSICA_PADRE_DIR")
    if not p:
        raise RuntimeError(
            "Set PHYSICA_PADRE_DIR to your clone of https://github.com/AeroLabPUT/UAV_measurement_data (see DATA.md)"
        )
    return Path(p)


def fraunhofer_dir() -> Path:
    p = os.environ.get("PHYSICA_FRAUNHOFER_DIR")
    if not p:
        raise RuntimeError("Set PHYSICA_FRAUNHOFER_DIR to the unzipped Fraunhofer unbalance dataset (see DATA.md)")
    return Path(p)
