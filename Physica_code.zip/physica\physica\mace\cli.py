"""Physica MACE commands: research, controlled real-data evaluation, consumer guidance, Muse."""
from __future__ import annotations
import argparse,json
from pathlib import Path
from .research import prospective_demo,run_benchmark
from .meta import request_preview,parse_reply,live_nomination
from .mechanisms import CANDIDATES,compare,fit,score
from .consumer import diagnose
from .sensors import inventory
from .field import import_manifest

def save(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,indent=2,allow_nan=False,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'output':str(p),'status':v.get('status',v.get('origin','COMPLETE'))},allow_nan=False))

def run(argv=None):
    ap=argparse.ArgumentParser(description='MACE — measured causal experience, not machine consciousness')
    sub=ap.add_subparsers(dest='command',required=True)
    a=sub.add_parser('demo');a.add_argument('--out',default='demo/mace');a.add_argument('--seed',type=int,default=2026);a.add_argument('--nomination')
    a=sub.add_parser('benchmark');a.add_argument('--out',default='demo/mace_benchmark');a.add_argument('--seeds',type=int,default=8)
    a=sub.add_parser('field-evaluate');a.add_argument('--manifest',required=True);a.add_argument('--out',required=True);a.add_argument('--nomination')
    a=sub.add_parser('field-investigate');a.add_argument('--manifest',required=True);a.add_argument('--out',required=True)
    a.add_argument('--nomination');a.add_argument('--live-meta',action='store_true');a.add_argument('--allow-billed-meta',action='store_true');a.add_argument('--device',choices=['washing_machine','robot_arm','3d_printer'])
    a=sub.add_parser('discover-unknown');a.add_argument('--manifest');a.add_argument('--seed',type=int,default=2026);a.add_argument('--out',required=True)
    a=sub.add_parser('unknown-investigate',help='Unknown residual → bounded Meta proposal → measured numerical validation')
    a.add_argument('--manifest');a.add_argument('--out',required=True)
    a.add_argument('--seed',type=int,default=2026)
    a.add_argument('--nomination',help='Optional offline proposal JSON (NOT live Meta)')
    a.add_argument('--live-meta',action='store_true')
    a.add_argument('--allow-billed-meta',action='store_true')
    a.add_argument('--model',choices=['muse-spark-1.3','muse-wonder-1.0'],default='muse-wonder-1.0')
    a.add_argument('--measurement-noise-sd',type=float)
    a=sub.add_parser('sense-plan');a.add_argument('--input',required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('target-probe-benchmark');a.add_argument('--seeds',type=int,default=20)
    a.add_argument('--trials',type=int,default=150);a.add_argument('--out',required=True)
    a=sub.add_parser('sam-video');a.add_argument('--video',required=True);a.add_argument('--target',required=True);a.add_argument('--reference',required=True)
    a.add_argument('--fps',type=float,required=True);a.add_argument('--pixels-per-metre',type=float,required=True)
    a.add_argument('--independent-calibration-verified',action='store_true')
    a.add_argument('--stationary-reference-verified',action='store_true')
    a.add_argument('--allow-billed-meta',action='store_true');a.add_argument('--out',required=True)
    a.add_argument('--nomination',help='external proposed mechanism structured JSON; NOT assumed verified')
    a=sub.add_parser('diagnose');a.add_argument('--input',required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('sensor-inventory');a.add_argument('--out',required=True)
    a=sub.add_parser('meta-preview');a.add_argument('--context',required=True);a.add_argument('--out',required=True);a.add_argument('--model',default='muse-spark-1.3')
    a=sub.add_parser('meta-nominate');a.add_argument('--context',required=True);a.add_argument('--out',required=True)
    a.add_argument('--model',default='muse-spark-1.3');a.add_argument('--allow-billed-meta',action='store_true')
    a=sub.add_parser('draft-machine');a.add_argument('--receipt',required=True);a.add_argument('--trace',required=True)
    a.add_argument('--target',choices=['marlin_input_shaper','klipper_input_shaper'],required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('meta-export-training');a.add_argument('--reviewed-case',required=True);a.add_argument('--out',required=True)
    args=ap.parse_args(argv)
    if args.command=='demo':
        
        nominee=None
        if args.nomination:
            d=json.loads(Path(args.nomination).read_text(encoding='utf-8'))
            if d.get('status') not in ('META_PROPOSED_UNVERIFIED','USER_PROPOSED_UNVERIFIED') or not isinstance(d.get('candidate'),dict):
                raise ValueError('must provide unverified nominated term record')
            nominee=d['candidate']
        result=prospective_demo(args.out,args.seed,nomination=nominee)
        print(json.dumps({'out':args.out,'status':result['origin'],'result':result['A_missing_mechanism_selected']},allow_nan=False));return result
    if args.command=='benchmark':
        result=run_benchmark(args.out,args.seeds)
        print(json.dumps({k:v for k,v in result.items() if k!='per_seed'},allow_nan=False,indent=2));return result
    if args.command=='target-probe-benchmark':
        from .target_probe_benchmark import simulate
        if not 1<=args.seeds<=100:raise ValueError('seeds must be 1..100')
        records=[simulate(seed=31415+i*317,trials=args.trials) for i in range(args.seeds)]
        import numpy as np
        report={'origin':'SIMULATION_ONLY','seeds':args.seeds,'trials_per_seed':args.trials,
           'mean_targeted_squared_error':float(np.mean([r['targeted_mean_squared_target_error'] for r in records])),
           'mean_random_squared_error':float(np.mean([r['random_mean_squared_target_error'] for r in records])),
           'targeted_seed_wins':sum(r['targeted_mean_squared_target_error']<r['random_mean_squared_target_error'] for r in records),
           'samples':records,'no_real_world_or_meta_evidence':True}
        save(args.out,report);return report
    if args.command=='sam-video':
        from .vision_bridge import run_video
        report=run_video(args.video,concept_target=args.target,concept_reference=args.reference,
             frames_per_second=args.fps,pixels_per_metre=args.pixels_per_metre,
             calibration_verified=args.independent_calibration_verified,
             static_reference_verified=args.stationary_reference_verified,
             allow_billed=args.allow_billed_meta)
        save(args.out,report);return report
    if args.command=='discover-unknown':
        from .unknown_physics import evaluate_manifest, synthetic_demo
        result=(evaluate_manifest(args.manifest) if args.manifest else synthetic_demo(args.out,args.seed))
        if args.manifest: save(args.out,result)
        return result
    if args.command=='unknown-investigate':
        from .open_world_meta import investigate,investigate_manifest
        if args.live_meta and args.nomination:
            raise ValueError('cannot supply offline nomination together with live Meta')
        nominee=json.loads(Path(args.nomination).read_text(encoding='utf-8')) if args.nomination else None
        noise=args.measurement_noise_sd
        if args.manifest:
            result=investigate_manifest(args.manifest,proposed_reply=nominee,
                live_meta=args.live_meta,allow_billed=args.allow_billed_meta,
                model=args.model,measurement_noise_sd=noise)
        else:
            from .simulation import roll
            body={'id':'source_A','thermal':.82,'extra':.4}
            seed=args.seed
            train=roll(body,seed,'source_training',n=140,unmodelled=True)
            val=roll(body,seed+1,'source_validation_1',n=120,unmodelled=True)
            val+=roll(body,seed+2,'source_validation_2',n=120,unmodelled=True)
            heldout=roll(body,seed+3,'source_heldout_LOCKBOX',n=120,unmodelled=True)
            result=investigate(train,val,heldout,proposed_reply=nominee,
                live_meta=args.live_meta,allow_billed=args.allow_billed_meta,
                model=args.model,measurement_noise_sd=.009 if noise is None else noise)
            result['origin']='SIMULATION_ONLY_NO_PHYSICAL_DISCOVERY'
            result['known_simulator_extra']='0.4 * sin(4*x + v)'
        save(args.out,result);return result
    if args.command=='sense-plan':
        from .active_sensing import choose
        d=json.loads(Path(args.input).read_text(encoding='utf-8'))
        result=choose(**d);save(args.out,result);return result
    if args.command=='field-investigate':
        from .field_investigation import investigate
        nominee=json.loads(Path(args.nomination).read_text(encoding='utf-8')) if args.nomination else None
        result=investigate(args.manifest,nomination=nominee,use_live_meta=args.live_meta,
             allow_billed=args.allow_billed_meta,device=args.device)
        save(args.out,result);return result
    if args.command=='field-evaluate':
        groups,source=import_manifest(args.manifest)
        proposals=CANDIDATES[:2]
        if args.nomination:
            data=json.loads(Path(args.nomination).read_text(encoding='utf-8'))
            if data.get('status') in ('META_PROPOSED_UNVERIFIED','USER_PROPOSED_UNVERIFIED'):
                proposals.append(data['candidate'])
            elif data.get('unknown_or_abstain') is False:
                proposals.append(parse_reply(data)['candidate'])
            else:raise ValueError('invalid candidate nomination record')
        result=compare(groups['train'],groups['validation'],proposals,improvement=.1)
        final=score(groups['test'],result['model'])
        base=score(groups['test'],fit(groups['train'],result['model']['terms'][:4]))
        report={'status':result['status'],'source_provenance':source,'selected_term':result['selected'],
                'blind_test_rmse_acceleration_m_s2':final,'baseline_test_rmse_acceleration_m_s2':base,
                'test_rows_seen_in_model_selection':False,'model':result['model'],
                'note':'real evidence origin is self-declared and chronology not independently witnessed'}
        save(args.out,report);return report
    if args.command=='diagnose':
        p=json.loads(Path(args.input).read_text(encoding='utf-8'))
        report=diagnose(**p);save(args.out,report);return report
    if args.command=='sensor-inventory':save(args.out,{'status':'SENSOR_REGISTRY_NOT_HARDWARE','modalities':inventory()});return
    if args.command in ('meta-preview','meta-nominate'):
        context=json.loads(Path(args.context).read_text(encoding='utf-8'))
        report=({'status':'OFFLINE_REQUEST_ONLY_NO_MODEL_INFERENCE','request':request_preview(context,args.model)}
                if args.command=='meta-preview' else live_nomination(context,args.model,args.allow_billed_meta))
        save(args.out,report);return report
    if args.command=='draft-machine':
        from .codegen import from_signed_trace
        receipt=json.loads(Path(args.receipt).read_text(encoding='utf-8'))
        result=from_signed_trace(receipt,args.trace,target=args.target)
        save(args.out,result);return result
    if args.command=='meta-export-training':
        case=json.loads(Path(args.reviewed_case).read_text(encoding='utf-8'))
        if case.get('verified') is not True or case.get('human_reviewed') is not True or case.get('independent_experiment') is not True:
            raise ValueError('verified + human-reviewed independent experiment required')
        if not all(k in case for k in ('context','candidate','observed_outcome','falsifying_test')):
            raise ValueError('missing training-example ground truth')
        validated=parse_reply({**case['candidate'],'unknown_or_abstain':False})
        answer={'context':case['context'],'candidate':validated['candidate'],'observed_outcome':case['observed_outcome'],
                'falsifying_test':case['falsifying_test'],'label':'HUMAN_REVIEWED_EXPERIMENT_NOT_FINE_TUNED'}
        file=Path(args.out);file.parent.mkdir(parents=True,exist_ok=True)
        file.write_text(json.dumps(answer,allow_nan=False)+'\n',encoding='utf-8')
        print('Exported one reviewed JSONL case; no fine-tuning executed');return answer

if __name__=='__main__':run()
