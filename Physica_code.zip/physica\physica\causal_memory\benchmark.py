"""Deterministic synthetic controlled physical trials; separate groups and seeds.
Report every baseline even when proposed transfer loses. No real-data claims.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np
from .core import Sensor,features,sense,decode,fit,error,choose_mechanism,prospective,transfer,hash_json

def rows(rng,coef,n,body,scale=1.0):
    out=[]
    for j in range(n):
        # Known controlled interventions, not merely observed motor current
        x=float(rng.uniform(-0.7,0.7));v=float(rng.uniform(-0.5,0.5));a=float(rng.uniform(-1,1))
        out.append({'body_id':body,'state':[x,v],'action':a,'acceleration':float(features((x,v),a)@coef+rng.normal(0,.01*scale)),'intervention_type':'controlled'})
    return out

def evaluate(seed=25,trials=24):
    rng=np.random.default_rng(seed); results=[]
    for i in range(trials):
        source=np.array([-1.2,-.3,1.0,-.7,-.08]);shift=float(rng.normal(0,.12))
        target=source.copy();target[3]+=shift
        src_train=rows(rng,source,60,'A');src_val=rows(rng,source,28,'A-validation')
        # 8 target local points (used by BOTH conventional and Physica); target probe separated
        local=rows(rng,target,8,f'T{i}-local')
        probe=rows(rng,target,8,f'T{i}-probe')
        test=rows(rng,target,100,f'T{i}-heldout')
        learned=choose_mechanism(src_train,src_val)
        src=np.asarray(learned['coefficients'])
        target_only=fit(local+probe)
        combined=transfer(src,local,probe)
        scores={'source_only':error(test,src),'target_only':error(test,target_only),
                'transfer':error(test,np.asarray(combined['coefficients'])),
                'zero_shot_linear':error(test,fit(src_train,allow_nonlinear=False))}
        results.append({'target':f'T{i}','shift':shift,'choice':combined['choice'],'scores':scores})
    means={name:float(np.mean([r['scores'][name] for r in results])) for name in results[0]['scores']}
    wins=sum(r['scores']['transfer']<r['scores']['target_only'] for r in results)
    # A small sensory decoder proof, not trained from raw images or microphones
    channels=[Sensor('camera',1.,0.,.02),Sensor('microphone',0.,1.,.03)]
    decoded=decode(sense([.2,-.13],channels),channels)
    return {'schema':'physica.causal_memory.benchmark.v1','origin':'SIMULATED',
            'seed':seed,'trials':trials,'methods_same_target_observation_budget':True,
            'source_has_extra_experiments':True,
            'measurement_units':'synthetic normalized acceleration',
            'heldout_body_groups_disjoint':True,'target_probe_is_used_for_model_selection':True,
            'stronger_independent_validation_needed':True,
            'means':means,'transfer_wins':wins,'decoder_example':decoded.tolist(),
            'individual_trials':results,
            'limits':['Known latent 2-D physical state and sensor calibration','Mechanism candidates are predefined','Random test split is synthetic; no real hardware','Transfer selector uses target probe also used in fit; not a blind independent verification']}

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--seed',type=int,default=25);p.add_argument('--trials',type=int,default=24);a=p.parse_args()
    result=evaluate(a.seed,a.trials);out=Path(a.out);out.parent.mkdir(exist_ok=True,parents=True);out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8');print(json.dumps({'means':result['means'],'transfer_wins':result['transfer_wins'],'trials':a.trials},indent=2))
if __name__=='__main__':main()
