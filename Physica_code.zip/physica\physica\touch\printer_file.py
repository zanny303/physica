"""Write the file. Takes a part Cura already sliced, and changes one thing: how hard the head accelerates on the outer walls.

The moves, the material and the temperatures stay exactly as Cura wrote them, and `check` proves that before any file is handed
over. The rest of the print keeps its speed, so the part costs far less extra time than slowing the whole printer down.
A person reviews the file and starts the print. Physica never sends anything to a machine.
"""
from __future__ import annotations

import hashlib
import math
import re

WALL = ";TYPE:WALL-OUTER"
NOTE = ";PHYSICA "
_ACCEL = re.compile(r"^M204\b(.*)$")
_S = re.compile(r"\bS(\d+(?:\.\d+)?)")
_MOVE = re.compile(r"^G([01])\b(.*)$")
_AXIS = re.compile(r"([XYZEF])(-?\d*\.?\d+)")
_TIME = re.compile(r"^;(?:PRINT\.TIME|TIME):(\d+)")


class CannotRewrite(ValueError):
    """The file can't be changed safely. The message says why, and what to do."""


def load_source(path) -> str:
    """A sliced part. Cura's .ufp is a zip holding the G-code, so it's opened for you. The file written back is plain .gcode."""
    import gzip
    import zipfile
    from pathlib import Path
    p = Path(path)
    raw = p.read_bytes()
    if raw[:2] == b"PK":
        with zipfile.ZipFile(p) as z:
            name = next((n for n in z.namelist() if n.lower().endswith((".gcode", ".gcode.gz"))), None)
            if not name:
                raise CannotRewrite("this .ufp has no G-code inside. In Cura, save the part as a .gcode file")
            raw = z.read(name)
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    return raw.decode("utf-8", errors="replace")


def _lines(text: str) -> list[str]:
    return text.replace("\r\n", "\n").split("\n")


def _print_accel(line: str) -> float | None:
    m = _ACCEL.match(line.strip())
    if not m:
        return None
    s = _S.search(m.group(1))
    return float(s.group(1)) if s else None


def _walk(lines: list[str]):
    """Each motion line with its section and the print acceleration in force."""
    kind, accel = None, None
    x, y, feed = None, None, None
    for ln in lines:
        s = ln.strip()
        if s.startswith(";TYPE:"):
            kind = s[6:]
        elif s.startswith(";LAYER:"):
            kind = None
        a = _print_accel(s)
        if a is not None:
            accel = a
        m = _MOVE.match(s)
        if not m:
            continue
        args = {k: float(v) for k, v in _AXIS.findall(m.group(2).split(";")[0])}
        feed = args.get("F", feed)
        nx, ny = args.get("X", x), args.get("Y", y)
        d = math.hypot(nx - x, ny - y) if None not in (x, y, nx, ny) else 0.0
        x, y = nx, ny
        yield {"kind": kind, "accel": accel, "dist": d, "feed": feed, "extrudes": "E" in args and m.group(1) == "1", "line": s}


def read_part(text: str) -> dict:
    """What Cura asked for on the outer walls."""
    lines = _lines(text)
    if WALL not in (ln.strip() for ln in lines):
        raise CannotRewrite("this file has no outer-wall sections (;TYPE:WALL-OUTER). Slice the part in Cura, and save the file it makes")
    walls = [m for m in _walk(lines) if m["kind"] == "WALL-OUTER" and m["extrudes"] and m["dist"] > 0]
    if not walls:
        raise CannotRewrite("the outer-wall sections of this file have no printing moves")
    accels = sorted({m["accel"] for m in walls if m["accel"] is not None})
    if not accels:
        raise CannotRewrite('this file sets no acceleration. In Cura, turn on "Enable Acceleration Control", slice again, and use that file')
    feeds = sorted(m["feed"] for m in walls if m["feed"])
    time_s = next((int(t.group(1)) for t in map(_TIME.match, lines) if t), None)
    flavor = next((ln.split(":", 1)[1].strip() for ln in lines[:40] if ln.startswith(";FLAVOR:")), None)
    return {"flavor": flavor, "griffin": bool(flavor and flavor.lower() == "griffin"), "wall_accel": max(accels),
            "wall_speed_mm_s": round(feeds[len(feeds) // 2] / 60, 1), "wall_sections": sum(ln.strip() == WALL for ln in lines),
            "cura_time_s": time_s}


def rewrite(text: str, wall_accel: float, notes: list[str] | tuple[str, ...] = ()) -> tuple[str, dict]:
    """Outer walls at no more than wall_accel. Everything else as Cura wrote it."""
    wall_accel = int(round(wall_accel))
    if wall_accel <= 0:
        raise CannotRewrite("the wall acceleration must be above zero")
    part = read_part(text)
    if wall_accel >= part["wall_accel"]:
        raise CannotRewrite(f"this file's outer walls already use {part['wall_accel']:g} mm/s2, which is not above {wall_accel}. Nothing to change")
    out, in_wall, asked, changed = [], False, None, 0

    def slow(value: float) -> str:
        return f"M204 S{min(int(round(value)), wall_accel)}"

    for ln in _lines(text):
        s = ln.strip()
        a = _print_accel(s)
        if a is not None:
            asked = a
            if in_wall:
                # Keep anything else on the line, like a travel acceleration.
                out.append(_S.sub(f"S{min(int(round(a)), wall_accel)}", s))
                changed += 1
                continue
        leaving = in_wall and (s.startswith(";LAYER:") or (s.startswith(";TYPE:") and s != WALL))
        if leaving:
            in_wall = False
            out.append(ln)
            if asked is not None:
                out.append(f"M204 S{int(round(asked))}")
                changed += 1
            continue
        out.append(ln)
        if s == WALL and not in_wall:
            in_wall = True
            out.append(slow(asked if asked is not None else part["wall_accel"]))
            changed += 1
    if notes:
        at = next((i + 1 for i, ln in enumerate(out) if ln.strip() == ";END_OF_HEADER"), 0)
        out[at:at] = [NOTE + n for n in notes]
    body = "\n".join(out)
    report = check(text, body, wall_accel)
    report["lines_changed"] = changed
    return body, report


def check(before: str, after: str, wall_accel: float) -> dict:
    """Prove the two files print the same path: same moves in the same order, and only outer-wall acceleration differs."""
    a, b = list(_walk(_lines(before))), list(_walk(_lines(after)))
    if [m["line"] for m in a] != [m["line"] for m in b]:
        raise CannotRewrite("the moves changed, so this file is not safe to use. Nothing was written")
    keep = lambda t: [ln for ln in _lines(t) if not (ln.strip().startswith("M204") or ln.startswith(NOTE))]  # noqa: E731
    if keep(before) != keep(after):
        raise CannotRewrite("something other than acceleration changed, so this file is not safe to use. Nothing was written")
    walls = 0
    for x, y in zip(a, b):
        if x["kind"] == "WALL-OUTER":
            walls += x["extrudes"]
            if x["accel"] is not None and y["accel"] != min(x["accel"], wall_accel):
                raise CannotRewrite("an outer-wall move didn't get the new acceleration. Nothing was written")
        elif x["accel"] != y["accel"]:
            raise CannotRewrite("the acceleration outside the outer walls changed. Nothing was written")
    return {"same_moves": True, "moves": len(a), "outer_wall_moves": walls}


def _seconds(moves, wall_accel: float | None = None, whole_print: float | None = None) -> float:
    total = 0.0
    for m in moves:
        if not m["dist"] or not m["feed"]:
            continue
        v = m["feed"] / 60
        a = m["accel"] or 3000.0
        if whole_print:
            a = min(a, whole_print)
        elif wall_accel and m["kind"] == "WALL-OUTER":
            a = min(a, wall_accel)
        total += m["dist"] / v + v / a if m["dist"] >= v * v / a else 2 * math.sqrt(m["dist"] / a)
    return total


def time_forecast(text: str, wall_accel: float) -> dict:
    """Extra print time, by a simple model that treats every move as starting and ending at rest. Real corners keep some speed, so
    this overstates the cost. It's a forecast to be checked with a stopwatch. The whole-print row shows what simply slowing everything would cost."""
    moves = list(_walk(_lines(text)))
    base = _seconds(moves)
    if base <= 0:
        raise CannotRewrite("this file has no moves to time")
    walls, whole = _seconds(moves, wall_accel=wall_accel), _seconds(moves, whole_print=wall_accel)
    cura = read_part(text)["cura_time_s"]
    ratio = walls / base
    return {"model_extra_pct": round(100 * (ratio - 1), 1), "whole_print_extra_pct": round(100 * (whole / base - 1), 1), "time_ratio": round(ratio, 4),
            "cura_minutes": round(cura / 60, 1) if cura else None, "forecast_minutes": round(cura * ratio / 60, 1) if cura else None}


def trade_off(text: str, felt: dict, accels: list[float] | None = None) -> dict:
    """The printer twin: for each wall acceleration, how big the ringing gets, where the ripples fall, and what it costs in time.
    Ringing scales with acceleration here, as the sealed goal also assumes. Nothing in this table has been measured yet."""
    part = read_part(text)
    base, f = part["wall_accel"], float(felt["freq_hz"])
    rows = []
    for a in accels or [round(base * s) for s in (1, .85, .7, .55, .4, .3, .2)]:
        if a > base:
            continue
        t = time_forecast(text, a) if a < base else {"model_extra_pct": 0.0, "whole_print_extra_pct": 0.0, "forecast_minutes": (part["cura_time_s"] or 0) / 60 or None}
        rows.append({"wall_accel": int(a), "ringing_pct_of_now": round(100 * a / base), "extra_time_pct": t["model_extra_pct"], "whole_print_extra_pct": t["whole_print_extra_pct"],
                     "minutes": None if t["forecast_minutes"] is None else round(t["forecast_minutes"], 1)})
    return {"label": "TWIN FORECAST, not a measurement", "part": part, "tone_hz": round(f, 2), "spacing_mm": round(part["wall_speed_mm_s"] / f, 2), "rows": rows}


def body_sha256(text: str) -> str:
    """Fingerprint of a file without our own note lines, so a seal can sit inside the file it describes."""
    return hashlib.sha256("\n".join(ln for ln in _lines(text) if not ln.startswith(NOTE)).encode()).hexdigest()
