"""What the page calls: upload a film, have it felt, push its twin, and write the file. Files stay on this computer unless you ask Muse."""
from __future__ import annotations

import base64
import contextlib
import hashlib
import io
import json
import re
import shutil
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SESSIONS = ROOT / "physica_sessions"
UPLOADS = SESSIONS / "uploads"
SCOUT = ROOT / "scout"
MOST_BYTES = 3 * 1024 ** 3
_NAME = re.compile(r"[a-zA-Z0-9][a-zA-Z0-9_. -]{0,120}")
_ID = re.compile(r"[0-9a-f]{12}_[a-zA-Z0-9_. -]{1,120}")
VIDEO = (".mp4", ".mov", ".m4v", ".avi", ".mkv")


def _film(file_id: str) -> Path:
    if not _ID.fullmatch(str(file_id)):
        raise ValueError("unknown file")
    p = UPLOADS / str(file_id)
    if not p.exists():
        raise ValueError("that upload is gone, so add it again")
    return p


def save_upload(name: str, size: int, stream) -> dict:
    """Written straight to disk, so a long slow-motion film needn't fit in memory."""
    if not _NAME.fullmatch(name or ""):
        raise ValueError("use a plain file name, with no folders")
    ext = Path(name).suffix.lower()
    if ext not in VIDEO + (".gcode", ".ufp"):
        raise ValueError("add a video, or a .gcode or .ufp file sliced by Cura")
    if size <= 0 or size > MOST_BYTES:
        raise ValueError("the file must be under 3 GB. Trim it to the moments that matter")
    UPLOADS.mkdir(parents=True, exist_ok=True)
    fid = f"{uuid.uuid4().hex[:12]}_{name}"
    left = size
    with (UPLOADS / fid).open("wb") as f:
        while left:
            chunk = stream.read(min(1 << 20, left))
            if not chunk:
                raise ValueError("the upload stopped part way")
            f.write(chunk)
            left -= len(chunk)
    if ext in (".gcode", ".ufp"):
        return {"id": fid, "kind": "gcode"}
    from physica.meta import scout as SC
    from physica.twin import modes as T
    try:
        info = SC.film_info(UPLOADS / fid)
        frame = T.frame_url(UPLOADS / fid, longest=960)
    except Exception as e:
        (UPLOADS / fid).unlink(missing_ok=True)
        raise ValueError(f"this video couldn't be read. An H.264 mp4 works best: {str(e)[:120]}") from None
    return {"id": fid, "kind": "video", "info": info, "frame": frame, "suspect_fps": info["fps"] < 100}


def feel(body: dict) -> dict:
    """With Muse: the whole path, nothing typed. Without: the most moving patch, and an honest limit on what that can say."""
    from physica.llm import meta_client as mc
    from physica.meta import scout as SC
    from physica.meta import scout_test as ST
    p = _film(body["id"])
    fps = float(body.get("fps") or SC.film_info(p)["fps"])
    if body.get("live"):
        if mc.is_mock():
            raise ValueError("No Meta key in this window, so Muse can't look. Physica can still read the film without it")
        lines: list[str] = []
        r = SC.scout(p, fps, SESSIONS / "scout_page", on_step=lines.append)
        return {**r, "steps": lines, "mode": "live"}
    V, k = SC.load_region(p, None, long_side=256)
    reg = ST.moving_region(V)
    box = tuple(int(v / k) for v in reg) if reg else None
    Vb, _ = SC.load_region(p, box) if box else (V, k)
    got = SC.read_tone(Vb, fps)
    return {"mode": "no model", "parts": [{"part": "the most moving patch", **got, "box_in_film": box}], "fps": fps, "limit": "No Muse here: code can find what moves, but it can't say what it is or what to test"}


PRESETS = {"beam": {"file": "beam_hit.mp4", "title": "Beam hit once, 10,000 frames a second", "fps": 10000.0}, "guitar": {"file": "guitar.mp4", "title": "Guitar, 600 frames a second", "fps": 600.0}}
TUNING = {"low E string": 82.41, "A string": 110.0}


def presets() -> list[dict]:
    return [{"key": k, "title": v["title"]} for k, v in PRESETS.items() if (ROOT / "clips" / v["file"]).exists()]


def add_preset(body: dict) -> dict:
    """A film that ships with Physica, ready to run. It takes the same path as an upload, so removing it or adding your own works the same way."""
    from physica.meta import scout as SC
    from physica.twin import modes as T
    key = str(body.get("key"))
    if key not in PRESETS:
        raise ValueError("no such film")
    src = ROOT / "clips" / PRESETS[key]["file"]
    UPLOADS.mkdir(parents=True, exist_ok=True)
    fid = f"{hashlib.md5(key.encode()).hexdigest()[:12]}_{PRESETS[key]['file']}"
    shutil.copyfile(src, UPLOADS / fid)
    info = SC.film_info(UPLOADS / fid)
    return {"id": fid, "kind": "video", "info": info, "frame": T.frame_url(UPLOADS / fid, longest=960), "suspect_fps": False, "preset": key, "fps": PRESETS[key]["fps"] or info["fps"], "title": PRESETS[key]["title"]}


def run_case(body: dict) -> dict:
    """Run on a ready film: the same steps as `meta cases`. Without a key it reads the film and leaves any saved live result alone."""
    from physica.llm import meta_client as mc
    from physica.meta import cases as CS
    key = str(body.get("key"))
    if key not in PRESETS:
        raise ValueError("no such film")
    lines: list[str] = []
    live = not mc.is_mock()
    if live:
        case = CS.run(CS.CLIPS, live=True, on_step=lines.append, only=key)["cases"][key]
        if case.get("failed"):
            raise ValueError(f"Muse's run failed: {case['failed']}")
    else:
        case = {"guitar": CS.guitar, "beam": CS.beam}[key](CS.CLIPS, False, lines.append)
    drop = ("sealed", "corrected_sealed", "roll_trace", "overlay")
    return {"key": key, "mode": "live" if live else "no key", "steps": lines, "case": {k: v for k, v in case.items() if k not in drop}, "anchor": (case.get("sealed") or {}).get("anchor")}


def strings_twin(body: dict) -> dict:
    """The guitar's twin: one per string, each graded on the half of the film it didn't learn from."""
    from physica.twin import modes as T
    from physica.twin import strings as X
    p = _film(body["id"])
    saved = ROOT / "eval" / "results" / "E35_real_footage.json"
    strings = (json.loads(saved.read_text())["cases"].get("guitar") or {}).get("strings") if saved.exists() else None
    if not strings:
        from physica.meta import cases as CS
        strings = CS.guitar(CS.CLIPS, False, lambda s: None)["strings"]
    tones = {k: v["tone_hz"] for k, v in strings.items()}
    twins = X.read(p, 600.0, tones)
    for k, v in twins.items():
        v["tuning_hz"] = TUNING[k]
        v["to_tune_pct"] = round(((TUNING[k] / v["tone_hz"]) ** 2 - 1) * 100, 1)
        v.update(knob="Tighten or loosen the string", law="Tone goes with the square root of tension.")
    return {"status": "MEASURED", "strings": twins, "frame": T.frame_url(p, longest=864), "label": "TWIN FROM THE FILM"}


def beam_twin(body: dict) -> dict:
    """The film is a thin strip, so the picture is shown four times taller. The motion is not changed."""
    import cv2
    from physica.twin import strike
    p = _film(body["id"])
    t = strike.read(p)
    t.pop("trace", None)
    t.update(knob="Stiffen or soften the beam", law="Tone goes with the square root of stiffness.")
    cap = cv2.VideoCapture(str(p))
    ok, f = cap.read()
    cap.release()
    if not ok:
        raise ValueError("the film couldn't be read")
    ok, png = cv2.imencode(".png", cv2.resize(f, (f.shape[1], f.shape[0] * 4), interpolation=cv2.INTER_LINEAR))
    return {"status": "MEASURED", "strings": {"the beam": t}, "frame": "data:image/png;base64," + base64.b64encode(png.tobytes()).decode(), "label": "TWIN FROM THE FILM"}


def goal_box(body: dict) -> dict:
    from physica.outcome import goalbox as G
    lines: list[str] = []
    r = G.run(str(body.get("goal") or ""), on_step=lines.append)
    return {**r, "notes": lines}


def muse_reads(body: dict) -> dict:
    from physica.outcome import muse_reads as M
    return M.ask(str(body.get("key")))


def speak(body: dict) -> dict:
    from physica.outcome import speak as K
    machine = str(body.get("machine"))
    if machine not in K.CHECKS:
        raise ValueError("no such machine")
    return K.write(machine, on_step=lambda s: None)


def twin_of(body: dict) -> dict:
    from physica.meta import scout as SC
    from physica.twin import modes as T
    if body.get("preset") == "guitar":
        return strings_twin(body)
    if body.get("preset") == "beam":
        return beam_twin(body)
    p = _film(body["id"])
    fps = float(body.get("fps") or SC.film_info(p)["fps"])
    box = tuple(int(v) for v in body["box"]) if body.get("box") else None
    r = T.read_mode(p, fps, box)
    if r["status"] != "MEASURED":
        return r
    return {**r, "frame": T.frame_url(p, box, longest=640), "label": "TWIN FROM YOUR FILM"}


def _ruler_path(name: str) -> Path:
    if not re.fullmatch(r"[a-zA-Z0-9_-]{1,40}", name):
        raise ValueError("bad session name")
    return SESSIONS / f"{name}_twin.json"


def ruler(step: str, body: dict) -> dict:
    """The same steps and the same saved file as the ruler command."""
    from physica.twin import modes as T
    name = str(body.get("name") or "ruler")
    path = _ruler_path(name)
    SESSIONS.mkdir(exist_ok=True)
    twin = json.loads(path.read_text()) if path.exists() else None
    if step == "learn":
        twin = T.learn([str(_film(i)) for i in body["ids"]], float(body["fps"]))
        if twin["status"] != "MEASURED":
            return {"status": "CANT_TELL", "reason": twin.get("reason")}
        path.write_text(json.dumps(twin, default=float))
        return {**{k: twin[k] for k in ("status", "tones_hz", "tone_hz", "spread_pct", "damping", "shape", "field", "direction")}, "frame": T.frame_url(_film(body["ids"][0]), longest=640)}
    if not twin:
        raise ValueError("start with the empty flicks")
    if step == "coin":
        c = T.calibrate(twin, str(_film(body["id"])), float(body["coin_g"]), float(body.get("at", 1)))
        if c["status"] == "MEASURED":
            twin["calibration"] = c
            path.write_text(json.dumps(twin, default=float))
        return c
    if not twin.get("calibration"):
        raise ValueError("film one weighed coin first")
    if step == "curve":
        return {"at": [round(i / 20, 2) for i in range(21)], "hz": [round(T.forecast(twin, float(body["g"]), i / 20), 3) for i in range(21)], "empty_hz": twin["tone_hz"]}
    if step == "predict":
        s = T.seal_forecast(twin, float(body["g"]), float(body["at"]))
        twin.setdefault("sealed", []).append(s)
        path.write_text(json.dumps(twin, default=float))
        return {"number": len(twin["sealed"]), "anchor": s["anchor"], **s["payload"]["prediction"]}
    if step == "grade":
        s = twin["sealed"][int(body["pred"]) - 1]
        g = T.grade(twin, s, str(_film(body["id"])))
        if g["status"] == "MEASURED":
            s["grade"] = g
            path.write_text(json.dumps(twin, default=float))
        return g
    if step == "weigh":
        r = T.weigh(twin, str(_film(body["id"])), float(body.get("at", 1)))
        if r["status"] == "MEASURED":
            twin.setdefault("weighed", []).append(r)
            path.write_text(json.dumps(twin, default=float))
        return r
    raise ValueError("unknown step")


def printer_twin(body: dict) -> dict:
    from physica.touch import printer_file as PF
    name = re.sub(r"[^a-zA-Z0-9_-]", "", str(body.get("name") or "printer"))
    source = PF.load_source(_film(body["id"]))
    sess = SESSIONS / f"{name}.json"
    felt = json.loads(sess.read_text()).get("felt") if sess.exists() else None
    if not felt:
        return {"status": "NEEDS_FILM", "say": f"Film the test motion first, then run: python -m physica.cli printer-video tune your_film.mp4 --name {name}"}
    return {"status": "READY", **PF.trade_off(source, felt)}


def write_file(body: dict) -> dict:
    """The same goal step as the command line, so the page and the command can't disagree."""
    from physica import cli
    name = re.sub(r"[^a-zA-Z0-9_-]", "", str(body.get("name") or "printer"))
    src = _film(body["id"])
    out = UPLOADS / f"{src.stem}_goal.gcode"
    args = ["printer-video", "goal", "--name", name, "--firmware", "cura", "--drop", f"{float(body['drop']):.3f}", "--gcode-in", str(src), "--out", str(out)]
    if body.get("goal"):
        args += ["--goal", str(body["goal"])[:200]]
    said = io.StringIO()
    try:
        with contextlib.redirect_stdout(said):
            cli.main(args)
    except SystemExit as e:
        return {"status": "REFUSED", "say": str(e)}
    return {"status": "WRITTEN" if out.exists() else "NOT_WRITTEN", "said": said.getvalue(), "file": out.name}


def gcode_file(name: str) -> Path | None:
    p = UPLOADS / name
    return p if _ID.fullmatch(name) and name.endswith("_goal.gcode") and p.exists() else None


def scout_films() -> dict:
    SCOUT.mkdir(exist_ok=True)
    m = SCOUT / "scout_manifest.json"
    done = json.loads(m.read_text())["films"] if m.exists() else {}
    return {"folder": str(SCOUT), "films": sorted(p.name for p in SCOUT.iterdir() if p.suffix.lower() in VIDEO), "done": done}


def scout_frame(film: str) -> dict:
    from physica.meta import scout as SC
    if not _NAME.fullmatch(film or "") or not (SCOUT / film).exists():
        raise ValueError("no such film in the scout folder")
    info = SC.film_info(SCOUT / film)
    url = SC.still(SCOUT / film, 0, longest=960)[0]
    return {"frame": url, "info": info}


def scout_save(body: dict) -> dict:
    film = str(body["film"])
    if not _NAME.fullmatch(film) or not (SCOUT / film).exists():
        raise ValueError("no such film in the scout folder")
    box = [int(v) for v in body["box"]]
    if len(box) != 4 or box[2] <= box[0] or box[3] <= box[1]:
        raise ValueError("draw a box on the film")
    ref = float(body["reference_hz"])
    if ref <= 0:
        raise ValueError("the reference tone must be above zero")
    m = SCOUT / "scout_manifest.json"
    data = json.loads(m.read_text()) if m.exists() else {"films": {}}
    data["films"][film] = {"part": str(body["part"])[:80], "box": box, "reference_hz": ref, "reference_how": str(body.get("reference_how", ""))[:160], "fps": float(body["fps"])}
    m.write_text(json.dumps(data, indent=1))
    return {"saved": film, "count": len(data["films"])}


def cable_forecast(body: dict) -> dict:
    """Seal what the twin says a load will do, using the same saved session as the cables command."""
    from physica import seal as _seal  # noqa: F401
    from physica.touch import cables as C
    name = re.sub(r"[^a-zA-Z0-9_-]", "", str(body.get("name") or "cables"))
    path = SESSIONS / f"{name}_cables.json"
    if not path.exists():
        raise ValueError("no cables session yet")
    d = json.loads(path.read_text())
    cable = str(body["cable"])
    cal = (d.get("calibration") or {}).get(cable)
    if not cal or not cal.get("usable"):
        raise ValueError("that cable isn't calibrated")
    s = C.seal_forecast(cal, cable, float(body["g"]))
    d.setdefault("forecasts", []).append(s)
    path.write_text(json.dumps(d, indent=1, default=float))
    return {"number": len(d["forecasts"]), "anchor": s["anchor"], **s["payload"]["prediction"]}
