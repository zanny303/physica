"""Generate three offline demonstrators sharing CIRTE/evidence boundaries.

NO genuine public dataset or Meta call is included. The video and lab examples
are explicitly synthetic. Lens runs against any local user-uploaded video.
"""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
from physica.triad.video import VideoConfig,extract_track,sealed_video_forecast,evaluate_forecast
from physica.triad.target_experiments import rank_transfer_experiments
from physica.triad.evidence import evidence_manifest,commit_prediction
from physica.triad.lens import app_html
from physica.grammar.cirte_field import source_from_native_manifest

def make_video(path):
    import cv2
    w,h=320,220
    output=cv2.VideoWriter(str(path),cv2.VideoWriter_fourcc(*'mp4v'),30,(w,h))
    if not output.isOpened():raise RuntimeError('opencv mp4v codec unavailable')
    try:
        for i in range(120):
            frame=np.zeros((h,w,3),np.uint8)
            for xx in range(12,77,10):
                for yy in range(12,77,10):cv2.circle(frame,(xx,yy),2,(180,180,180),-1)
            z=int(110+13*np.sin(i*.20)*np.exp(-i*.009))
            cv2.rectangle(frame,(130,z-24),(202,z+24),(212,212,212),-1)
            for x in range(136,198,10):
                for dy in (-17,-5,8,20):cv2.circle(frame,(x,z+dy),2,(10,10,10),-1)
            output.write(frame)
    finally:output.release()

def build(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    clip=out/'SYNTHETIC_visual_motion.mp4'
    make_video(clip)
    trace=extract_track(clip,VideoConfig((125,75,82,75),reference_roi=(8,8,75,72),max_frames=120))
    forecast=sealed_video_forecast(trace)
    scores=evaluate_forecast(trace,forecast)
    evidence=evidence_manifest(clip,origin='simulation',modality='video_optical_motion',units='px')
    commit=commit_prediction(evidence=evidence,observation_cutoff_s=forecast['training_end_s'],forecast=forecast,
                             model='Physica heldout optical motion demonstration')
    request=json.loads((Path(__file__).parent/'target_transfer_design.json').read_text())
    target=rank_transfer_experiments(request['prior_covariance'],request['target_features'],request['candidates'])
    result={'origin':'SIMULATION_ONLY','actual_meta_model_calls':0,'real_experiments':0,
            'lab_existing_cirte_replay':'examples/cirte_v05/native_demo/RESULTS_SIMULATION_ONLY.json',
            'discover_video_motion':{'evidence':evidence,'forecast':forecast,'evaluation':scores,'sealed_prediction':commit},
            'lens':'same real-video analysis function as Discover; start local web server',
            'target_directed_learning':target,
            'novelty':'RESEARCH_HYPOTHESIS_NOT_ESTABLISHED',
            'wearables':'phone-browser demonstration, NOT live Meta glasses hardware',
            'scientific_limits':['synthetic video and lab fixtures','no real hardware or API validation',
             'forecasting visible motion does not uniquely identify a physical mechanism']}
    (out/'SIMULATION_ONLY_3_DEMO_REPORT.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'lens_interface_offline_preview.html').write_text(app_html())
    return {'report':str(out/'SIMULATION_ONLY_3_DEMO_REPORT.json'),'heldout_rmse':scores['holdout_rmse'],
            'unit':scores['unit'],'target_experiment':target['chosen_id']}

if __name__=='__main__':print(json.dumps(build(sys.argv[1] if len(sys.argv)>1 else 'examples/triad_v052/showcase'),indent=2))
