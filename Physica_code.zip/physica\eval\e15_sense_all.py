"""E15 - One command for every use case, on real data: physica sense / watch / bank / twin / stream.

  Real beam (ARTS-Lab, CC BY-SA 4.0): watch it (touches, change of body, where the mass went), what kind of object
  it is, the fix in machine code, a twin checked against a real tap, real-time touch stream.
  Real guitar video (600 fps capture per the paper): how many separate objects, which pitches, where.
  Body Bank: seeded with these real bodies; 'what feels like this?' answered from the bank.
Set PHYSICA_BEAM_FILE and PHYSICA_GUITAR_VIDEO (see DATA.md).
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica import bank, twin  # noqa: E402
from physica.sense import load_source, sense  # noqa: E402
from physica.touch.stream import TouchStream  # noqa: E402
from physica.touch.transform import TouchTransform, compare_words  # noqa: E402

OUT = ROOT / "eval" / "results"
BEAM_PROV = {"dataset": "ARTS-Lab free vibration of cantilever beam", "licence": "CC BY-SA 4.0",
             "url": "https://github.com/ARTS-Laboratory/dataset-free-vibration-of-cantilever-beam"}
GTR_PROV = {"dataset": "Eulerian Video Magnification guitar clip (Wu et al. 2012) via pbMoMa", "licence": "research use, attribution",
            "url": "https://github.com/jvgemert/pbMoMa", "capture_fps": 600}


def clean(sheet):
    return {k: v for k, v in sheet.items() if not k.startswith("_")}


def main():
    res = {}
    t0 = time.time()
    s = sense(os.environ["PHYSICA_BEAM_FILE"])
    res["beam_sense"] = {**clean(s), "seconds": time.time() - t0}
    tt_mass = s["_tt"]
    # the body after the change, as the watcher adopted it, for the twin and the bank
    src = load_source(os.environ["PHYSICA_BEAM_FILE"])
    Y, fs = src["Y"][:, 0], src["fs"]
    tw_body = TouchTransform(fs, n_modes=3, band=(3, 250), delays=int(0.3 * fs), order=40, measure="acceleration",
                             merge=0.06).fit(Y[int(26 * fs):int(34 * fs)])
    tw = twin.export(tw_body, {**BEAM_PROV, "learned_from_s": [26, 34]})
    twin.save(tw, OUT / "twin_beam_after.json")
    tap = next(e["t"] for e in s["events"] if e["kind"].startswith("touch (on the new"))
    chk = twin.predict_after(tw, Y, int(tap * fs))
    res["beam_twin_check"] = {k: v for k, v in chk.items() if k not in ("real", "pred")}
    st = TouchStream(tt_mass)
    t1 = time.time()
    ev = st.run(Y)
    res["beam_stream"] = {"events": ev, "us_per_sample": 1e6 * (time.time() - t1) / len(Y), "fs": fs}
    # guitar video
    t0 = time.time()
    g = sense(os.environ["PHYSICA_GUITAR_VIDEO"], fps=600.0, n_modes=4, band=(60, 295), watch=False,
              learn=(0, 0.5))
    res["guitar_sense"] = {**clean(g), "seconds": time.time() - t0}
    # bank: seed with real bodies, then ask it questions
    path = ROOT / "bank" / "bodies.jsonl"
    after_sheet = {"source": src["name"], "kind": "signal", "bodies": [{"type": "clamped beam (cantilever, ruler, diving board, robot finger, drone arm)",
                   "fit_pct": None, "modes": tw_body.words()}], "events": [], "changes": []}
    e1 = bank.add(s, "steel cantilever carrying a heavy mass (ARTS-Lab)", BEAM_PROV, path)
    e2 = bank.add(after_sheet, "same cantilever after the mass was released", BEAM_PROV, path)
    e3 = bank.add(g, "classical guitar, three plucked strings (video)", GTR_PROV, path)
    late = TouchTransform(fs, n_modes=3, band=(3, 250), delays=int(0.3 * fs), order=40, measure="acceleration", merge=0.06).fit(Y[int(30 * fs):int(40 * fs)])
    res["bank"] = {"entries": [e1["name"], e2["name"], e3["name"]], "all_verify": all(bank.verify(e) for e in bank.entries(path)),
                   "query_quiet_late_beam": bank.find(late.words(), path),
                   "query_guitar_A_string": bank.find([{"freq_hz": 108.5, "damping": 0.001, "amp": 0}], path)}
    strong_after = TouchTransform(fs, n_modes=3, band=(3, 250), delays=int(0.3 * fs), order=40, measure="acceleration",
                                  merge=0.06).fit(Y[int(24.3 * fs):int(27.0 * fs)])
    res["words"] = {"with_mass_vs_after (both strongly shaken)": compare_words(tt_mass.words(), strong_after.words()),
                    "after_strong_vs_after_quiet": compare_words(strong_after.words(), late.words())}
    (OUT / "E15_sense_all.json").write_text(json.dumps(res, indent=1, default=float))
    print("\n".join(s["summary"]))
    print("twin check R2 %.3f; stream events %s at %.1f us/sample" % (chk["r2"], [round(e["t"], 3) for e in ev], res["beam_stream"]["us_per_sample"]))
    print("\n".join(g["summary"]))
    print("bank verify", res["bank"]["all_verify"], "| late beam ->", [(q["name"], round(q["distance_pct"], 1), q["verdict_same_shaking"]) for q in res["bank"]["query_quiet_late_beam"][:2]])
    print("guitar 108.5 Hz ->", [(q["name"], round(q["distance_pct"], 2)) for q in res["bank"]["query_guitar_A_string"][:2]])
    print("words:", {k: (v["verdict"], v["say"]) for k, v in res["words"].items()})


if __name__ == "__main__":
    main()
