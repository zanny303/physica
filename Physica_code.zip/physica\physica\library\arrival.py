"""Arrival check (SPEC 7): before a card is used on a new machine, test it on that machine's healthy data.

Verdict 'fits' if the card's predictions cover the new healthy data as well as they covered their own
calibration data; otherwise 'doesn't fit here' and only the failing units are re-learned.
"""
from __future__ import annotations

import numpy as np
from scipy.stats import binom

from physica.feel.selfmodel import OperatingPointSelfModel


def conformal_halfwidth(z_calib: np.ndarray, coverage: float = 0.9) -> float:
    """Split-conformal half-width on |z| from the card's own calibration residuals."""
    a = np.sort(np.abs(np.asarray(z_calib).ravel()))
    n = len(a)
    k = min(n - 1, int(np.ceil((n + 1) * coverage)) - 1)
    return float(a[k])


def check(model: OperatingPointSelfModel, op_new: np.ndarray, lvl_new: np.ndarray, halfwidth: float,
          coverage: float = 0.9, alpha: float = 0.01) -> dict:
    """Per-unit coverage test. A unit fails if its coverage is significantly below the claimed coverage."""
    z = model.z(op_new, lvl_new)
    inside = np.abs(z) <= halfwidth
    units = []
    for k in range(z.shape[1]):
        n, x = len(inside[:, k]), int(inside[:, k].sum())
        p = float(binom.cdf(x, n, coverage))  # chance of seeing this few covered if the card still fits
        units.append({"unit": model.unit_names[k], "coverage": x / n if n else None, "n": n,
                      "p_value": p, "fits": p >= alpha, "median_z": float(np.median(z[:, k]))})
    fits = all(u["fits"] for u in units)
    failing = [u["unit"] for u in units if not u["fits"]]
    return {"verdict": "fits" if fits else "doesn't fit here", "claimed_coverage": coverage,
            "halfwidth_z": halfwidth, "units": units, "relearn": failing}


def relearn_failing(model: OperatingPointSelfModel, op_new: np.ndarray, lvl_new: np.ndarray,
                    failing: list[str], lam: float = 4.0) -> tuple[OperatingPointSelfModel, list[str]]:
    """Re-learn only the failing units, using the old card as the starting guess. Returns (model, changed)."""
    import copy

    new = copy.deepcopy(model)
    changed = []
    for name in failing:
        k = model.unit_names.index(name)
        one = OperatingPointSelfModel(degree=model.degree, unit_names=[name])
        prior = OperatingPointSelfModel(degree=model.degree, unit_names=[name])
        prior.coef, prior.sigma = model.coef[k:k + 1], model.sigma[k:k + 1]
        prior.x_center, prior.x_scale = model.x_center, model.x_scale
        one.fit(op_new[:, k:k + 1], lvl_new[:, k:k + 1], prior=prior, lam=lam)
        new.coef[k], new.sigma[k] = one.coef[0], one.sigma[0]
        changed.append(f"self-model of {name}")
    return new, changed
