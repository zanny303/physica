"""The scoreboard: what has really been shown for the three claims, read from saved sessions and results. Nothing is typed in."""
from __future__ import annotations

import json
from pathlib import Path

SHOWN, PARTLY, NOT_YET, FAILED = "SHOWN", "PARTLY", "NOT YET", "FAILED"


def _read(p: Path):
    try:
        return json.loads(p.read_text())
    except (OSError, ValueError):
        return None


def _row(what: str, status: str, detail: str) -> dict:
    return {"what": what, "status": status, "detail": detail}


def board(sessions: Path, name: str, other: str | None, results: Path) -> dict:
    sessions, results = Path(sessions), Path(results)
    trials = _read(sessions / f"{name}_trials.json") or []
    graded = [t["grade"] for t in trials if t.get("grade")]
    right = sum(g["result"] == "right" for g in graded)
    wrong = sum(g["result"] == "wrong" for g in graded)
    causes = [_read(p) for p in sorted(sessions.glob(f"{name}_cause_*.json"))]
    settled = [c for c in causes if c and c.get("state")]
    preds = _read(sessions / f"{name}_predictions.json") or []
    pg = [r["grade"] for r in preds if (r.get("grade") or {}).get("held") is not None]
    ripple = _read(sessions / f"{name}_ripple_graded.json")
    first = [
        _row("Noticed an unexpected change, blind", (FAILED if wrong > right else SHOWN) if graded else NOT_YET, f"{right} right, {wrong} wrong, {len(graded) - right - wrong} no answer, of {len(graded)} revealed"),
        _row("Designed an experiment and settled the cause", SHOWN if settled else (PARTLY if causes else NOT_YET), f"{len(settled)} settled of {len(causes)} tested"),
        _row("Predicted measurements it had not seen", (SHOWN if any(g["held"] for g in pg) else FAILED) if pg else NOT_YET, f"{sum(g['held'] for g in pg)} held of {len(pg)} sealed predictions"),
        _row("Film agrees with calipers on a printed part", (SHOWN if ripple.get("held") else FAILED) if ripple else NOT_YET, f"film {ripple.get('tone_from_film_hz')} Hz, calipers {ripple.get('tone_from_part_hz')} Hz" if ripple else "no caliper reading"),
    ]
    senses = _read(results / "E28_muse_senses.json")
    if senses and senses.get("status") == "COMPLETE" and senses.get("mode", "live") != "mock":
        from physica.meta.senses_test import pooled, with_review
        senses = pooled(senses, _read(results / "E28_muse_senses_confirm.json")) or senses
        s = with_review(senses)["scores"] if senses.get("rows") else senses["scores"]
        key = "right_action"
        alone, helped = s["physica_alone"].get(key), s.get("physica_plus_muse", s["muse_senses"]).get(key)
        better = s.get("physica_plus_muse", s["muse_senses"])
        a_miss, b_miss = s["physica_alone"].get("dangerous_misses"), better.get("dangerous_misses")
        fewer = a_miss is not None and b_miss is not None and b_miss < a_miss
        muse = _row("Muse beats the same system without it (real blade)", SHOWN if helped > alone else (PARTLY if helped == alone and fewer else FAILED),
                    f"right action: Physica alone {alone}, with Muse reviewing {helped}, of {senses['cases_done']}" + (f". Cracks missed: {a_miss} and {b_miss}" if a_miss is not None and b_miss is not None else ""))
    else:
        muse = _row("Muse beats the same system without it (real blade)", NOT_YET, "run: physica meta senses --allow-billed-meta")
    wm = _read(results / "E31_world_model_muse.json")
    if wm and wm.get("status") == "COMPLETE":
        n = wm["lower_test_error_with_muse"]
        muse2 = _row("Muse helps discovery on hidden laws (simulated)", SHOWN if n else FAILED, f"lower error in {n} of {wm['runs']}, term used in {wm['muse_term_used']}")
    else:
        muse2 = _row("Muse helps discovery on hidden laws (simulated)", NOT_YET, "run: python -m physica.worldmodel muse-test --allow-billed-meta")
    sam = _read(sessions / f"{name}_sam_compare.json")
    if sam:
        d = sam["decided"]
        status = (SHOWN if sam.get("located_by") else NOT_YET) if d == sam["crop"] else (PARTLY if d == "tie" else FAILED)
        samr = _row("SAM beats the same films without it", status, f"decided by {sam['decided_by']}: {d}" + ("" if sam.get("located_by") else " (not live SAM)"))
    else:
        samr = _row("SAM beats the same films without it", NOT_YET, 'run: printer-video sam-compare films --sam "print head"')
    receipts = results.parent.parent / "meta_receipts"
    n = len(list(receipts.glob("*"))) if receipts.exists() else 0
    plans = [_read(p) for p in sorted(sessions.glob(f"{name}_plan_*.json"))]
    used = [p for p in plans if p and p.get("muse_rivals")]
    moved = sum(p.get("chosen_g") != p.get("chosen_g_without_muse") for p in used)
    won = sum(1 for c in causes if c and c.get("top_rival") in (c.get("muse_rival_names") or []))
    muse3 = _row("Muse changed what the printer experiment tested", (SHOWN if moved or won else PARTLY) if used else NOT_YET,
                 f"Muse's ideas were in {len(used)} test(s), changed the weight in {moved}, and gave the closest forecast in {won}" if used else "run: printer-video muse-causes, then plan-test")
    updated = [_read(p) for p in sorted(sessions.glob(f"{name}_muse_causes_*.json"))]
    investigations = [_read(p) for p in sorted(sessions.glob(f"{name}_investigation_*.json"))]
    learned = sum(1 for u in updated if u and u.get("round", 1) > 1) + sum(1 for i in investigations if i and i.get("experiment_read") and i.get("finished"))
    muse4 = _row("Muse learned from a result and proposed the next test", SHOWN if learned else NOT_YET, f"{learned} trial(s)" if learned else "run: printer-video muse-update, after a test")
    parts = _read(sessions / f"{name}_parts.json")
    sam2 = _row("SAM separated the machine's parts, and Physica felt each", (SHOWN if parts.get("status") == "MEASURED" else PARTLY) if parts else NOT_YET,
                ", ".join(f"{k}: {v.get('reading', 'not read')}" for k, v in parts["parts"].items()) if parts else "run: printer-video parts")
    second = [muse, muse3, muse4, muse2, samr, sam2, _row("Live Meta receipts on file", SHOWN if n else NOT_YET, f"{n} receipts")]
    goal = _read(sessions / f"{name}_goal.json") or {"attempts": []}
    gg = [x["grade"] for x in goal["attempts"] if x.get("grade")]
    last = gg[-1] if gg else None
    lesson_rows = [r for r in (_read(sessions / f"{other}_predictions.json") or []) if r.get("lesson_status")] if other else []
    statuses = [r["lesson_status"] for r in lesson_rows]
    judged = _read(sessions / f"{name}_muse_judge.json")
    third = [
        _row("Real machine reached your goal, on a new film", (SHOWN if last["met"] else (PARTLY if "LOOKS" in last["verdict"] else FAILED)) if last else NOT_YET, f"{last['verdict']}: {100 * last.get('drop', 0):.0f}% against {100 * last.get('want_drop', 0):.0f}%, {len(gg)} attempt(s)" if last else "run: printer-video goal, apply it, check"),
        _row("Before and after part, side by side", "YOUR CALL", "Show the parts. No film reading replaces them"),
        _row("Muse picked the fixed part, without knowing which it was", (SHOWN if judged["picked_fixed"] > judged["pairs"] / 2 else FAILED) if judged else NOT_YET,
             f"{judged['picked_fixed']} of {judged['pairs']} pairs, {judged['cant_tell']} can't tell" if judged else "run: printer-video muse-judge, with photos of both parts"),
        _row("Verified lesson helped a second machine", (SHOWN if "LESSON_APPLIES_ON_THIS_PRINTER" in statuses else (PARTLY if "HELD_BUT_SOURCE_NOT_VERIFIED" in statuses else FAILED)) if statuses else NOT_YET, ", ".join(s.replace("_", " ").lower() for s in statuses) or "needs a second printer"),
    ]
    return {"printer": name, "second_printer": other, "1_new_physical_capability": first, "2_meta_contribution": second, "3_visible_physical_result": third}


def as_text(b: dict) -> str:
    out = []
    for title, key in (("1. New physical capability", "1_new_physical_capability"), ("2. Meta's measured contribution", "2_meta_contribution"), ("3. Visible physical result", "3_visible_physical_result")):
        out.append(title)
        out += [f"  {r['status']:<10} {r['what']}\n{'':<13}{r['detail']}" for r in b[key]]
    return "\n".join(out)
