"""Physica Lens: real browser video ingest into the SAME motion/forecast core.

Prototype: ordinary phone browser upload or mobile camera capture. NOT a native
Meta glasses app or a claim of glasses hardware compatibility. Exposes no
machine-control endpoints and never infers force or chemical content from video.
"""
from __future__ import annotations
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
import hashlib,json, tempfile,urllib.parse,os
from .video import VideoConfig,extract_track,sealed_video_forecast,evaluate_forecast
from .evidence import evidence_manifest

MAX_UPLOAD=50*1024*1024

def evaluate_uploaded_video(path,*,roi,reference_roi=None,pixels_per_metre=None,origin='real_recording',
                            cutoff=.65,model_context=None):
    c=VideoConfig(tuple(roi),None if reference_roi is None else tuple(reference_roi),pixels_per_metre)
    track=extract_track(path,c)
    forecast=sealed_video_forecast(track,cutoff_fraction=cutoff)
    metrics=evaluate_forecast(track,forecast)
    ev=evidence_manifest(path,origin=origin,modality='video_optical_motion',units=track['unit'],
                         calibration_id='externally_calibrated_scale' if pixels_per_metre else None)
    # These are HYPOTHESES for a possible mechanism, never a diagnosis.
    interpretations={
      'furniture':{'observation':'A selected region moved in the video.',
       'candidate_causes':['Uneven surface contact','Loose joint or flexible frame','Camera motion or perspective'],
       'safe_step':'With the object empty and unloaded, repeat a gentle reversible observation from a fixed camera; compare with a stable background marker.'},
      'mechanical':{'observation':'Video motion was extracted, not a mechanical force.',
       'candidate_causes':['Changing operating state','Loose attachment','Vibration from a nearby source','Camera motion'],
       'safe_step':'Observe only; ask a qualified operator to perform approved measurements. Do not alter operating machinery.'},
      'general':{'observation':'Motion was measured in the selected image region.',
       'candidate_causes':['Interaction with the object','Environmental change','Camera movement','Unmodeled mechanism'],
       'safe_step':'Keep the camera fixed; obtain a reference measurement and make only safe, reversible comparisons.'}
    }
    chosen=interpretations.get(model_context or 'general', interpretations['general'])
    return {'product':'Physica Lens v0.5.2','status':'RECORDED_VIDEO_ANALYSIS_NOT_CAUSAL_DISCOVERY',
            'evidence':ev,'track':track,'forecast':forecast,'heldout_test':metrics,
            'guidance':chosen,'meta_context':{'status':'NOT_CALLED','model_contribution':'not_evaluated'},
            'independent_observation_required_before_physical_claim':True,
            'lab_transfer_authorized':False}


def app_html():
    return '''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>Physica Lens</title><style>
:root{color-scheme:dark}body{font:16px system-ui,sans-serif;background:#0c1425;color:#ecf2ff;max-width:960px;margin:25px auto;padding:0 16px}h1{font-size:2.4rem}p{line-height:1.55;color:#b9c8e0}.panel{background:#18233a;border:1px solid #394966;border-radius:15px;padding:20px;margin:16px 0}input,select,button{font:inherit;background:#263955;color:white;border:1px solid #7183a3;border-radius:9px;padding:10px}button{background:#1f8f87;cursor:pointer}button:disabled{opacity:.6}label{display:block;margin:14px 0}video,canvas{max-width:100%;border-radius:10px}canvas{touch-action:none;cursor:crosshair}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:.88rem;color:#d8e7ff}small{color:#95a7be}#status{font-weight:bold} .em{color:#6ee7b7}</style></head><body>
<h1>Physica <span class="em">Lens</span></h1><p>A physical investigation assistant: <b>observe → predict → test → learn</b>. This is a phone-browser prototype. It does not use live Meta glasses, authorize repairs, or claim to know hidden physical causes from a video.</p>
<div class="panel"><h2>1 · Supply real evidence</h2><label>Record or upload a video <input id="file" type="file" accept="video/mp4,video/quicktime,video/webm" capture="environment"/></label><video id="v" controls playsinline></video><p>Pause at a clear frame, then drag a rectangle around a textured, moving part. The analysis predicts a later part of the same recording.</p><canvas id="cv"></canvas><p id="region">No region selected.</p><label>Context: <select id="context"><option value="general">General physical object</option><option value="furniture">Wobbling table / furniture</option><option value="mechanical">Machine or appliance (observation only)</option></select></label><label>Optional independently measured pixels per metre <input id="ppm" inputmode="decimal" placeholder="Leave blank: pixel units only"/></label><button id="run">Analyze recorded motion</button><p id="status" role="status"></p></div>
<div class="panel"><h2>2 · What the evidence supports</h2><div id="summary">No observations yet.</div><canvas id="plot" width="720" height="280" role="img" aria-label="Observed and predicted physical motion"></canvas><pre id="out"></pre><small>Predictions use a retrospective holdout. The recording already exists; this is not independent chronological proof. A real instrument, separate camera reference and calibration are necessary for stronger physical conclusions.</small></div>
<script>
const $=id=>document.getElementById(id), canvas=$('cv'),ctx=canvas.getContext('2d');let blob=null,box=null;
$('file').onchange=()=>{blob=$('file').files[0];if(blob){$('v').src=URL.createObjectURL(blob);box=null;$('status').textContent='Choose a moving part on the preview.';}};
function draw(){const v=$('v');if(!v.videoWidth)return;canvas.width=Math.min(700,v.videoWidth);canvas.height=Math.round(canvas.width*v.videoWidth**-1*v.videoHeight);ctx.drawImage(v,0,0,canvas.width,canvas.height);if(box){ctx.strokeStyle='#64eccd';ctx.lineWidth=3;ctx.strokeRect(box.x,box.y,box.w,box.h);}}
$('v').addEventListener('loadeddata',draw);$('v').addEventListener('seeked',draw);$('v').addEventListener('pause',draw);
let origin=null;function xy(e){const r=canvas.getBoundingClientRect();return{x:Math.max(0,Math.min(canvas.width,(e.clientX-r.left)*canvas.width/r.width)),y:Math.max(0,Math.min(canvas.height,(e.clientY-r.top)*canvas.height/r.height))}}
canvas.addEventListener('pointerdown',e=>{origin=xy(e);canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointerup',e=>{if(!origin)return;const p=xy(e);box={x:Math.min(origin.x,p.x),y:Math.min(origin.y,p.y),w:Math.abs(origin.x-p.x),h:Math.abs(origin.y-p.y)};origin=null;draw();$('region').textContent='Selected area: '+JSON.stringify(box)});
function renderPlot(result){const c=$('plot'),x=c.getContext('2d'),w=c.width,h=c.height;x.clearRect(0,0,w,h);x.fillStyle='#0b1830';x.fillRect(0,0,w,h);const tr=result.track,fo=result.forecast;let times=tr.time_s.concat(fo.forecast_time_s),ys=tr.motion.concat(fo.forecast_motion);let t0=Math.min(...times),t1=Math.max(...times),y0=Math.min(...ys),y1=Math.max(...ys);if(y1<=y0){y1=y0+1}const X=t=>24+(w-48)*(t-t0)/(t1-t0||1),Y=y=>h-24-(h-48)*(y-y0)/(y1-y0);const line=(t,v,color,from,to,dashed=false)=>{x.strokeStyle=color;x.lineWidth=2;x.setLineDash(dashed?[7,6]:[]);x.beginPath();for(let j=from;j<to;j++){j===from?x.moveTo(X(t[j]),Y(v[j])):x.lineTo(X(t[j]),Y(v[j]))}x.stroke();x.setLineDash([])};line(tr.time_s,tr.motion,'#8bdbf1',0,tr.time_s.length);line(fo.forecast_time_s,fo.forecast_motion,'#74e5ab',0,fo.forecast_time_s.length,true);x.setLineDash([4,4]);x.strokeStyle='#adb5c6';x.beginPath();x.moveTo(X(fo.training_end_s),0);x.lineTo(X(fo.training_end_s),h);x.stroke();x.setLineDash([]);x.fillStyle='#e3edf9';x.font='13px system-ui';x.fillText('Blue: recorded motion   Green dashed: prefix-only forecast   |: withheld frames',16,18)}
$('run').onclick=async()=>{if(!blob||!box||box.w<8||box.h<8){$('status').textContent='Upload a video and select a textured moving region.';return}let scale=$('v').videoWidth/canvas.width;let roi=[box.x,box.y,box.w,box.h].map(x=>Math.round(x*scale));let q=new URLSearchParams({roi:roi.join(','),context:$('context').value});if($('ppm').value)q.set('ppm',$('ppm').value);$('status').textContent='Analyzing optical motion…';$('run').disabled=true;try{const r=await fetch('/api/analyze?'+q,{method:'POST',headers:{'Content-Type':blob.type||'video/mp4'},body:blob});const result=await r.json();if(!r.ok)throw Error(result.error||'Analysis failed');$('summary').textContent='Motion units: '+result.track.unit+' · Held-out prediction RMSE: '+result.heldout_test.holdout_rmse.toPrecision(4)+' '+result.track.unit+' · Persistent baseline RMSE: '+result.heldout_test.persistence_rmse.toPrecision(4)+' '+result.track.unit+'. The physical cause is not identified.';renderPlot(result);$('out').textContent=JSON.stringify({guide:result.guidance,metrics:result.heldout_test,model:result.forecast.model,evidence_sha256:result.evidence.sha256,limitations:result.track.limitations},null,2);$('status').textContent='Analysis completed; result is a recorded-video holdout, not a prospective experiment.'}catch(e){$('status').textContent=e.message}finally{$('run').disabled=false}};
</script></body></html>'''


def serve_lens(host='127.0.0.1',port=8765):
    # Bind only loopback: video recordings may contain sensitive personal imagery.
    if host not in ('127.0.0.1','localhost'):
        raise ValueError('Lens prototype can only bind localhost')
    class Handler(BaseHTTPRequestHandler):
        def _send(self,status,body,contenttype):
            out=body.encode() if isinstance(body,str) else body
            self.send_response(status);self.send_header('Content-Type',contenttype)
            self.send_header('Content-Length',str(len(out)))
            self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
            self.end_headers();self.wfile.write(out)
        def do_GET(self):
            if urllib.parse.urlsplit(self.path).path=='/':return self._send(200,app_html(),'text/html; charset=utf-8')
            self._send(404,'Not found','text/plain')
        def do_POST(self):
            url=urllib.parse.urlsplit(self.path)
            if url.path!='/api/analyze':return self._send(404,'Not found','text/plain')
            try:
                n=int(self.headers.get('Content-Length','-1'))
                if n<=0 or n>MAX_UPLOAD:raise ValueError('video upload must be 1–50 MB')
                if self.headers.get('Content-Type','').split(';')[0] not in ('video/mp4','video/quicktime','video/webm','application/octet-stream'):
                    raise ValueError('unsupported video MIME')
                qs=urllib.parse.parse_qs(url.query)
                roi=[int(x) for x in qs['roi'][0].split(',')]
                ppm=float(qs['ppm'][0]) if qs.get('ppm') else None
                ctx=qs.get('context',['general'])[0]
                with tempfile.TemporaryDirectory(prefix='physica_lens_') as root:
                    path=Path(root)/'upload.mp4';path.write_bytes(self.rfile.read(n))
                    data=evaluate_uploaded_video(path,roi=roi,pixels_per_metre=ppm,model_context=ctx)
                self._send(200,json.dumps(data,allow_nan=False),'application/json')
            except Exception as exc:
                self._send(422,json.dumps({'error':str(exc)[:400]}),'application/json')
    httpd=ThreadingHTTPServer((host,port),Handler)
    print(f'Physica Lens local-only: http://{host}:{port} (Ctrl+C to stop)',flush=True)
    try:httpd.serve_forever()
    finally:httpd.server_close()
