# Physica v0.27 — Unified Predictive Feeling & Discovery

- Added `physica.frontier.feeling_discovery_loop_v027`: one orchestrator for measured prediction error → inquiry gate → bounded Muse or offline structure → scientific validation → review-only experiment plan → prospective A→B forecast → reveal → later learning and candidate experience memory.
- Added source chronology: pre-trigger neural model trains on earlier source TRAIN episodes and scores a separate source TRAIN episode before Muse; validation is reserved for hypothesis selection.
- Added mandatory declared acceleration uncertainty for the calibrated curiosity trigger; declines to infer missing calibration noise.
- Passed training-only sensory signal into Muse council's context rather than treating model prose as evidence.
- Added opt-in three-call Muse experiment using a private API key; Studio remains strictly offline and free from billable API access.
- Added a separately sealed *second* future test to compare predictions before/after incorporating the earlier measured outcome, reporting regressions honestly and noting the extra training budget.
- Added a portable **candidate** physical-experience memory containing model expression/coefficients, calibration/evidence hashes, and validation requirements. It is not an approved transferable law.
- Added Studio MACE task and end-to-end localhost HTTP regression.
- Synthetic-only validation and safety tests added. No claims of validated real machines or discovery of new physics.
