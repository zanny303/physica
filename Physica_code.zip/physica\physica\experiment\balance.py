"""Fan balancing from a phone: find WHERE to add weight and HOW MUCH, then check the fix by feeling again.

Why it matters: a wobbling fan (ceiling fan, desk fan, PC fan, drone prop) is fixed today by trial and error.
Physica finds the fix from four short recordings, without a speed sensor (the classic amplitude-only four-run
balancing method, Everett-style):
  run O    : the fan as it is
  run T0   : a small trial weight (e.g. a coin + tape) on blade 1
  run T120 : the same weight moved one-third of a turn (on blade 2 of a 3-blade fan)
  run T240 : moved another third (blade 3)
Physica finds the once-per-turn line itself: the line that changes when YOU move the weight (what your action
causes; the rest is the fan's own steady vibration). From the four amplitudes it solves for the trial weight's
effect, then the correction that cancels the original wobble. A built-in consistency check says "can't tell,
repeat the runs" when the four measurements don't agree with each other.
"""
from __future__ import annotations

import numpy as np
from scipy.signal import welch

from physica.act import contract

ANGLES = (0.0, 120.0, 240.0)


def spectrum(acc: np.ndarray, fs: float) -> tuple[np.ndarray, np.ndarray]:
    x = acc.reshape(acc.shape[0], -1)
    x = x - x.mean(0)
    f, p = welch(x, fs=fs, nperseg=min(len(x), int(fs * 4)), axis=0)
    return f, p.sum(axis=1)


def find_once_per_turn(runs: list[tuple[np.ndarray, float]], band=(3.0, 80.0)) -> float:
    """Choose coherent 1x response shared across trials, not the strongest 3x harmonic.

    Score candidates on common spectral power AND plausible 2x/3x companions;
    require response on several independent trials. Reject ambiguous results.
    Frequency must be independently confirmed for an actual balancing decision.
    """
    specs = [spectrum(a, fs) for a, fs in runs]
    f = specs[0][0]
    m = (f >= band[0]) & (f <= min(band[1], .45*min(fs for _, fs in runs)))
    P = np.array([np.interp(f, fr, pr) for fr, pr in specs])
    mean = np.mean(P, axis=0)
    if not m.any() or not np.isfinite(mean).all() or mean[m].max() < 1e-12:
        raise ValueError('No usable periodic measurement')
    # Peak prominence across all recordings; favor lower fundamental when a
    # strong harmonic appears at its exact integer multiple.
    from scipy.signal import find_peaks
    peaks, _ = find_peaks(mean)
    peaks = [i for i in peaks if m[i] and mean[i] > .035 * mean[m].max()]
    if not peaks:
        raise ValueError('No stable shared rotation-frequency candidate')
    def near(fr):
        i = int(np.argmin(np.abs(f - fr)))
        return float(np.max(mean[max(0, i-1):i+2]))
    scores = []
    for i in peaks:
        base = float(mean[i]); harm = sum(near(k*f[i]) / k**2 for k in (2,3) if k*f[i] < f[-1])
        across = np.maximum(P[:, i], 1e-20)
        # Reject a line driven by just one of the four trials.
        coverage = float(np.count_nonzero(across >= .02*mean[m].max()) / len(runs))
        score = (base + .5*harm) * coverage / max(f[i]**.12, 1)
        scores.append((score, float(f[i])))
    scores.sort(reverse=True)
    f0=scores[0][1]
    # A strong lower harmonic can be the fundamental even if the highest peak
    # occurs at 3x due to camera aliasing. Never infer rotor identity from this.
    return f0


def amplitude(acc: np.ndarray, fs: float, f0: float, rel: float = 0.04) -> float:
    f, p = spectrum(acc, fs)
    m = np.abs(f - f0) <= max(rel * f0, f[1] - f[0])
    return float(np.sqrt(p[m].sum() * (f[1] - f[0])))


def solve(A0: float, A: list[float], trial_g: float, angles=ANGLES) -> dict:
    """Amplitudes only: A_k^2 = A0^2 + |T|^2 + 2 A0 Re(T e^{i theta_k}). Linear in (|T|^2, Re T, Im T)."""
    th = np.radians(angles)
    M = np.stack([np.ones(3), 2 * A0 * np.cos(th), -2 * A0 * np.sin(th)], axis=1)
    u, tr, ti = np.linalg.solve(M, np.array(A) ** 2 - A0 ** 2)
    T = complex(tr, ti)
    consistency = abs(u - abs(T) ** 2) / max(u, abs(T) ** 2, 1e-12)
    mass = trial_g * A0 / max(abs(T), 1e-12)
    angle = float(np.degrees(np.pi - np.angle(T)) % 360)
    return {"trial_effect": abs(T), "correction_g": float(mass), "correction_angle_deg": angle,
            "consistency_error": float(consistency), "trusted": bool(consistency < 0.35 and abs(T) > 0.05 * A0)}


def split_between_blades(mass: float, angle_deg: float, blades: int) -> list[dict]:
    """Put the correction on the two blades either side of the ideal angle (same radius as the trial weight)."""
    step = 360.0 / blades
    a = int(angle_deg // step) % blades
    b = (a + 1) % blades
    A = np.array([[np.cos(np.radians(a * step)), np.cos(np.radians(b * step))],
                  [np.sin(np.radians(a * step)), np.sin(np.radians(b * step))]])
    w = np.linalg.solve(A, mass * np.array([np.cos(np.radians(angle_deg)), np.sin(np.radians(angle_deg))]))
    return [{"blade": a + 1, "grams": round(float(w[0]), 2)}, {"blade": b + 1, "grams": round(float(w[1]), 2)}]


def plan(trial_g: float = 1.0, blades: int = 3) -> str:
    return ("Advisory/simulation only: never attach coins, tape or improvised weights to a spinning consumer fan. "
            "If using a manufacturer-approved, guarded laboratory balancing rig with trained supervision, "
            "record a baseline and three rated calibration-weight trials at equal angular offsets and speed, "
            "using an independently measured tachometer. Confirm calibration, mechanical limits, and operator approval "
            "before any physical correction. Physica does not actuate the rotor.")


def run(o, t0, t120, t240, trial_g: float, blades: int = 3) -> dict:
    """o, t0, t120, t240: (acc, fs) recordings. Returns the fix and the promise (written before you act)."""
    runs = [o, t0, t120, t240]
    rates=[float(fs) for _,fs in runs]
    if any(not np.isfinite(fs) or fs<=0 for fs in rates) or max(rates)/min(rates)>1.01:
        raise ValueError('All measurements must use the same verified sampling/frame rate')
    lengths=[len(y) for y,_ in runs]
    if min(lengths)<100 or max(lengths)/min(lengths)>1.2:
        raise ValueError('All recordings must have comparable measurement durations')
    f0 = find_once_per_turn(runs)
    A = [amplitude(a, fs, f0) for a, fs in runs]
    s = solve(A[0], A[1:], trial_g)
    out = {"once_per_turn_hz": f0, "rpm": f0 * 60, "amplitudes": A, **s}
    if not s["trusted"]:
        out["verdict"] = "can't tell"
        out["text"] = ("The four runs are inconsistent. No correction is recommended. "
                       "Verify the measurements on a guarded, rated laboratory fixture with trained supervision.")
        return out
    out["placement"] = split_between_blades(s["correction_g"], s["correction_angle_deg"], blades)
    out["verdict"] = "fix found"
    out["text"] = (f"MODEL ONLY (rated laboratory rig, trained approval required): predicted correction "
                   f"{s['correction_g']:.2f} g at {s['correction_angle_deg']:.0f} degrees. "
                   "Never improvise or attach weights to consumer fans, aircraft propellers, or other spinning machines.")
    out["promise"] = contract.promise(
        f"balance weight {s['correction_g']:.2f} g at {s['correction_angle_deg']:.0f} deg",
        f"After the fix, the once-per-turn wobble at {f0:.1f} Hz drops by at least half.",
        [{"metric": "wobble_drop_fraction", "op": ">=", "value": 0.5, "say": "once-per-turn wobble drops ≥ 50%"}])
    return out


def check(result: dict, after) -> dict:
    a = amplitude(after[0], after[1], result["once_per_turn_hz"])
    drop = 1 - a / result["amplitudes"][0]
    return {"after_amplitude": a, "wobble_drop_fraction": drop,
            "judgement": contract.judge(result["promise"], {"wobble_drop_fraction": drop})}


def consistent_video_signal(path, fps=None):
    """One fixed optical-flow *velocity* method across all videos; no phase/flow switching.

    Frame motion is measured over the SAME fixed grid; video shake alone does not
    establish that a rotor exists or that its attachments are safe.
    """
    from pathlib import Path
    from physica.touch.video import load_gray
    from physica.touch.weigh import flow_motion
    import cv2
    video = Path(path)
    cap = cv2.VideoCapture(str(video))
    detected = float(cap.get(cv2.CAP_PROP_FPS))
    cap.release()
    rate = fps or detected
    if not np.isfinite(rate) or rate < 10:
        raise ValueError('Video frame rate is missing or too low for rotor analysis')
    V = load_gray(str(video))
    if V.ndim != 3 or len(V) < 120:
        raise ValueError('Not enough frames to measure consistent periodic motion')
    out = flow_motion(V, width=160, step=8, keep=180)
    return np.asarray(out['signals'], float), rate
