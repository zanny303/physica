"""Check machine code with the machine's own real toolchain, not with our own parser.

- Klipper (motion firmware on a large share of 3D printers and lab stages): batch mode runs the real host
  software on our G-code and config and writes the exact step commands it would send to the board.
- matiec (the IEC 61131-3 compiler inside OpenPLC and Beremiz): compiles the PLC Structured Text to C,
  then gcc compiles that C, as a soft PLC would.
- pymavlink (the MAVLink reference library) loads the mission; ArduPilot SITL (the real autopilot code) can fly it.

Each check reports the tool, its version and what it found. A missing tool is reported as "not run", never as a pass.
Tool locations: PHYSICA_KLIPPER (a Klipper checkout with out/klipper.dict built), PHYSICA_MATIEC (matiec build dir).
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def _git_rev(path: Path) -> str:
    try:
        return subprocess.run(["git", "-C", str(path), "rev-parse", "--short", "HEAD"], capture_output=True,
                              text=True, timeout=10).stdout.strip() or "unknown"
    except Exception:
        return "unknown"


def klipper(config: str, gcode: str, expect_mm: float | None = None, stepper: str = "support",
            mm_per_step: float | None = None) -> dict:
    root = Path(os.environ.get("PHYSICA_KLIPPER", ""))
    d = root / "out" / "klipper.dict"
    if not (root / "klippy" / "klippy.py").exists() or not d.exists():
        return {"tool": "Klipper", "ran": False, "why": "set PHYSICA_KLIPPER to a Klipper checkout with out/klipper.dict"}
    with tempfile.TemporaryDirectory() as t:
        t = Path(t)
        (t / "printer.cfg").write_text(config)
        (t / "plan.gcode").write_text(gcode)
        r = subprocess.run([sys.executable, str(root / "klippy" / "klippy.py"), str(t / "printer.cfg"), "-i",
                            str(t / "plan.gcode"), "-o", str(t / "out.serial"), "-v", "-d", str(d), "-l", str(t / "k.log")],
                           capture_output=True, text=True, timeout=300)
        log = (t / "k.log").read_text(errors="replace") if (t / "k.log").exists() else r.stderr
        errors = [ln for ln in log.splitlines() if re.search(r"error|out of range|Must home|Unknown command", ln, re.I)
                  and "Exiting" not in ln and "/proc/" not in ln and "/sys/" not in ln]
        dump = subprocess.run([sys.executable, str(root / "klippy" / "parsedump.py"), str(d), str(t / "out.serial")],
                              capture_output=True, text=True, timeout=120).stdout
    steps = [ln for ln in dump.splitlines() if ln.startswith("queue_step")]
    net = 0
    dir_now = 1
    for ln in dump.splitlines():
        if ln.startswith("set_next_step_dir"):
            m = re.search(r"dir=(\d+)", ln)
            dir_now = 1 if m and m.group(1) == "1" else -1
        elif ln.startswith("queue_step"):
            m = re.search(r"count=(\d+)", ln)
            net += dir_now * int(m.group(1)) if m else 0
    out = {"tool": "Klipper (klippy batch mode)", "version": _git_rev(root), "ran": True, "exit_code": r.returncode,
           "errors": errors[:5], "step_commands": len(steps), "net_steps": net}
    if mm_per_step:
        out["moved_mm"] = round(abs(net) * mm_per_step, 4)
        if expect_mm is not None:
            out["expected_mm"] = round(abs(expect_mm), 4)
            out["match"] = bool(abs(out["moved_mm"] - abs(expect_mm)) <= mm_per_step * 2)
    out["passed"] = bool(r.returncode == 0 and not errors and out.get("match", True))
    return out


def matiec(st_source: str, compile_c: bool = True) -> dict:
    root = Path(os.environ.get("PHYSICA_MATIEC", ""))
    iec2c = root / "iec2c"
    if not iec2c.exists():
        return {"tool": "matiec", "ran": False, "why": "set PHYSICA_MATIEC to a matiec build folder (iec2c, lib/)"}
    with tempfile.TemporaryDirectory() as t:
        t = Path(t)
        (t / "plc.st").write_text(st_source)
        r = subprocess.run([str(iec2c), "-I", str(root / "lib"), "-T", str(t), str(t / "plc.st")],
                           capture_output=True, text=True, timeout=120)
        out = {"tool": "matiec iec2c (IEC 61131-3)", "version": _git_rev(root), "ran": True,
               "exit_code": r.returncode, "messages": (r.stdout + r.stderr).strip().splitlines()[-6:],
               "c_files": sorted(p.name for p in t.glob("*.c"))}
        if r.returncode == 0 and compile_c and shutil.which("gcc"):
            objs = []
            for c in t.glob("*.c"):
                if c.name in ("POUS.c",):  # included by the resource file
                    continue
                o = c.with_suffix(".o")
                g = subprocess.run(["gcc", "-c", str(c), "-o", str(o), "-I", str(root / "lib" / "C"), "-I", str(t),
                                    "-w"], capture_output=True, text=True, timeout=120)
                objs.append({"file": c.name, "gcc_exit": g.returncode, "err": g.stderr.strip().splitlines()[:3]})
            out["gcc"] = objs
            out["passed"] = all(o["gcc_exit"] == 0 for o in objs) and bool(objs)
        else:
            out["passed"] = r.returncode == 0
    return out


def mavlink_mission(wpl_text: str) -> dict:
    try:
        from pymavlink import mavwp
    except Exception:
        return {"tool": "pymavlink", "ran": False, "why": "pip install pymavlink"}
    with tempfile.NamedTemporaryFile("w", suffix=".waypoints", delete=False) as f:
        f.write(wpl_text)
        fn = f.name
    try:
        L = mavwp.MAVWPLoader()
        n = L.load(fn)
        items = [L.wp(i) for i in range(L.count())]
        alts = [w.z for w in items[1:] if w.command == 16]
        return {"tool": "pymavlink mavwp", "ran": True, "items": n, "max_alt_m": max(alts) if alts else None,
                "min_alt_m": min(alts) if alts else None, "commands": sorted({int(w.command) for w in items}),
                "passed": n == len(wpl_text.strip().splitlines()) - 1}
    except Exception as e:  # noqa: BLE001
        return {"tool": "pymavlink mavwp", "ran": True, "passed": False, "error": str(e)}
    finally:
        os.unlink(fn)


def ardupilot_sitl(wpl_text: str, home: tuple, tower: tuple | None = None, speedup: int = 10,
                   timeout_s: float = 240.0) -> dict:
    """Fly the mission on the real ArduPilot copter code in software-in-the-loop (simulated physics).

    home = (lat, lon, alt_m, heading). Records the flown track and reports: mission accepted, waypoints reached,
    closest horizontal approach to the tower/blade line, highest altitude, landed and disarmed.
    """
    import math
    import time as _t
    root = Path(os.environ.get("PHYSICA_ARDUPILOT", ""))
    binary = root / "build" / "sitl" / "bin" / "arducopter"
    parm = root / "Tools" / "autotest" / "default_params" / "copter.parm"
    if not binary.exists():
        return {"tool": "ArduPilot SITL", "ran": False, "why": "set PHYSICA_ARDUPILOT to an ArduPilot checkout "
                "with ./waf configure --board sitl && ./waf copter done"}
    from pymavlink import mavutil, mavwp
    work = Path(tempfile.mkdtemp())
    (work / "m.waypoints").write_text(wpl_text)
    loader = mavwp.MAVWPLoader()
    loader.load(str(work / "m.waypoints"))
    proc = subprocess.Popen([str(binary), "-S", "--model", "+", "--speedup", str(speedup), "--defaults", str(parm),
                             "-I0", "--home", ",".join(str(x) for x in home)], cwd=work,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    out = {"tool": "ArduPilot SITL (arducopter)", "version": _git_rev(root), "ran": True, "speedup": speedup}
    try:
        m = None
        for _ in range(60):
            try:
                m = mavutil.mavlink_connection("tcp:127.0.0.1:5760", source_system=255)
                break
            except Exception:  # noqa: BLE001
                _t.sleep(0.5)
        m.wait_heartbeat(timeout=30)
        m.mav.request_data_stream_send(m.target_system, m.target_component, mavutil.mavlink.MAV_DATA_STREAM_ALL, 10, 1)
        # upload mission (resend the count until the autopilot starts asking for items)
        _t.sleep(3.0)
        m.mav.mission_clear_all_send(m.target_system, m.target_component, 0)
        m.recv_match(type="MISSION_ACK", blocking=True, timeout=5)
        sent, t0, last_count = 0, _t.time(), 0.0
        while _t.time() - t0 < 60:
            if sent == 0 and _t.time() - last_count > 3:
                m.mav.mission_count_send(m.target_system, m.target_component, loader.count(), 0)
                last_count = _t.time()
            msg = m.recv_match(type=["MISSION_REQUEST", "MISSION_REQUEST_INT", "MISSION_ACK"], blocking=True, timeout=1)
            if msg is None:
                continue
            if msg.get_type() == "MISSION_ACK":
                if sent == 0:
                    continue
                out["mission_ack"] = int(msg.type)
                break
            w = loader.wp(msg.seq)
            w.target_system, w.target_component = m.target_system, m.target_component
            m.mav.send(w)
            sent += 1
        out["mission_items_sent"] = sent
        out["mission_accepted"] = out.get("mission_ack") == 0
        # wait for EKF / GPS, then arm in GUIDED, take off, switch to AUTO
        m.wait_gps_fix() if hasattr(m, "wait_gps_fix") else None
        armed = False
        t0 = _t.time()
        while _t.time() - t0 < 120 and not armed:
            m.set_mode("GUIDED")
            m.arducopter_arm()
            hb = m.recv_match(type="HEARTBEAT", blocking=True, timeout=3)
            armed = bool(hb and hb.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
            if not armed:
                _t.sleep(1.0)
        out["armed"] = armed
        if not armed:
            return out
        m.mav.command_long_send(m.target_system, m.target_component, mavutil.mavlink.MAV_CMD_NAV_TAKEOFF, 0,
                                0, 0, 0, 0, 0, 0, 10)
        _t.sleep(2.0)
        m.set_mode("AUTO")
        track, reached, t0 = [], set(), _t.time()
        disarmed = False
        while _t.time() - t0 < timeout_s:
            msg = m.recv_match(type=["GLOBAL_POSITION_INT", "MISSION_ITEM_REACHED", "HEARTBEAT", "STATUSTEXT"],
                               blocking=True, timeout=5)
            if msg is None:
                continue
            k = msg.get_type()
            if k == "GLOBAL_POSITION_INT":
                track.append((msg.lat / 1e7, msg.lon / 1e7, msg.relative_alt / 1000.0))
            elif k == "MISSION_ITEM_REACHED":
                reached.add(int(msg.seq))
            elif k == "HEARTBEAT" and track and max(a for _, _, a in track) > 5:
                if not (msg.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED):
                    disarmed = True
                    break
        nav = [i for i in range(1, loader.count()) if loader.wp(i).command == 16]
        out["waypoints"] = len(nav)
        out["waypoints_reached"] = len(set(nav) & reached)
        out["max_alt_m"] = round(max(a for _, _, a in track), 1) if track else None
        out["landed_and_disarmed"] = disarmed
        if tower and track:
            lat0, lon0 = tower
            def horiz(la, lo):
                dn = (la - lat0) * 111_320.0
                de = (lo - lon0) * 111_320.0 * math.cos(math.radians(lat0))
                return math.hypot(dn, de)
            high = [horiz(la, lo) for la, lo, a in track if a > 15]
            out["closest_to_blade_line_m"] = round(min(high), 1) if high else None
        out["track_points"] = len(track)
        out["passed"] = bool(out["mission_accepted"] and out["waypoints_reached"] == len(nav) and disarmed)
        out["track"] = track[:: max(1, len(track) // 400)]
        return out
    except Exception as e:  # noqa: BLE001
        out["error"] = repr(e)
        out["passed"] = False
        return out
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except Exception:  # noqa: BLE001
            proc.kill()
