"""Write the turbine's response to a blade verdict as IEC 61131-3 Structured Text, the language turbine and
factory PLCs run (Bachmann, Beckhoff, Siemens, CODESYS, OpenPLC).

The sealed de-icing promise becomes code the machine itself enforces: after heating, the turbine may only resume
if Physica's change score has fallen to the sealed threshold; otherwise it brakes and calls an inspection, and only a
human RESET clears that. Inputs arrive as Modbus/OPC UA registers (%IW), outputs drive %QX coils, as on OpenPLC.
"""
from __future__ import annotations

VERDICT_CODE = {"weather only": 0, "ice": 1, "crack": 2, "structural": 3, "can't tell": 4}


def blade_guard(promise_threshold: float, anchor: str, heat_minutes: int = 45, turbine_id: str = "WTG07") -> str:
    thr100 = int(round(promise_threshold * 100))
    return f"""(* Physica blade guard for {turbine_id}. Generated from a goal; sealed promise {anchor}.
   REVIEW-ONLY LOGIC, NOT SAFETY-CERTIFIED. It is only as good as the blade sense feeding VERDICT: on the ETH test
   campaign that sense judged 9 of 111 cracked-blade groups as weather (8 = the smallest, 5 cm crack).
   Goal: keep producing through the freeze; restart after de-icing only if the sealed promise holds.
   VERDICT: 0 weather only, 1 ice, 2 crack, 3 structural, 4 can't tell. Scores arrive x100 as INT. *)
FUNCTION_BLOCK PHYSICA_BLADE_GUARD
  VAR_INPUT
    VERDICT : INT;
    SCORE_X100 : INT;
    RESET_BY_INSPECTOR : BOOL;
  END_VAR
  VAR_OUTPUT
    RUN_PERMIT : BOOL;
    HEATERS_ON : BOOL;
    BRAKE : BOOL;
    DISPATCH_INSPECTION : BOOL;
    STATE : INT;
  END_VAR
  VAR
    HEAT_TIMER : TON;
    PROMISE_X100 : INT := {thr100};
  END_VAR

  CASE STATE OF
    0: (* running *)
      RUN_PERMIT := TRUE; HEATERS_ON := FALSE; BRAKE := FALSE; DISPATCH_INSPECTION := FALSE;
      IF VERDICT = 1 THEN
        STATE := 1;
      ELSIF VERDICT >= 2 THEN
        STATE := 3;
      END_IF;
    1: (* ice-like: pause and heat *)
      RUN_PERMIT := FALSE; HEATERS_ON := TRUE;
      HEAT_TIMER(IN := TRUE, PT := T#{heat_minutes}m);
      IF HEAT_TIMER.Q THEN
        HEAT_TIMER(IN := FALSE);
        HEATERS_ON := FALSE;
        STATE := 2;
      END_IF;
    2: (* grade the sealed promise: ice gone means the blade feels like itself again *)
      IF SCORE_X100 <= PROMISE_X100 THEN
        STATE := 0;
      ELSE
        STATE := 3; (* heating did not fix it: not ice *)
      END_IF;
    3: (* stopped: brake, call the drone and a human *)
      RUN_PERMIT := FALSE; HEATERS_ON := FALSE; BRAKE := TRUE; DISPATCH_INSPECTION := TRUE;
      IF RESET_BY_INSPECTOR THEN
        STATE := 0;
      END_IF;
  END_CASE;
END_FUNCTION_BLOCK

PROGRAM TURBINE_MAIN
  VAR
    VERDICT_IN AT %IW0 : INT;
    SCORE_IN AT %IW1 : INT;
    RESET_IN AT %IX0.0 : BOOL;
    RUN_OUT AT %QX0.0 : BOOL;
    HEAT_OUT AT %QX0.1 : BOOL;
    BRAKE_OUT AT %QX0.2 : BOOL;
    INSPECT_OUT AT %QX0.3 : BOOL;
  END_VAR
  VAR
    GUARD : PHYSICA_BLADE_GUARD;
  END_VAR
  GUARD(VERDICT := VERDICT_IN, SCORE_X100 := SCORE_IN, RESET_BY_INSPECTOR := RESET_IN);
  RUN_OUT := GUARD.RUN_PERMIT;
  HEAT_OUT := GUARD.HEATERS_ON;
  BRAKE_OUT := GUARD.BRAKE;
  INSPECT_OUT := GUARD.DISPATCH_INSPECTION;
END_PROGRAM

CONFIGURATION CONFIG0
  RESOURCE RES0 ON PLC
    TASK MAINTASK(INTERVAL := T#100ms, PRIORITY := 0);
    PROGRAM INSTANCE0 WITH MAINTASK : TURBINE_MAIN;
  END_RESOURCE
END_CONFIGURATION
"""


def simulate(verdicts: list[int], scores_x100: list[int], promise_x100: int, heat_scans: int = 3) -> list[dict]:
    """Python mirror of the state machine, scan by scan, used to test the logic the PLC will run."""
    state, timer, out = 0, 0, []
    for v, s in zip(verdicts, scores_x100):
        if state == 0:
            if v == 1:
                state = 1
            elif v >= 2:
                state = 3
        elif state == 1:
            timer += 1
            if timer >= heat_scans:
                timer, state = 0, 2
        elif state == 2:
            state = 0 if s <= promise_x100 else 3
        out.append({"state": state, "run": state == 0, "brake": state == 3, "heat": state == 1})
    return out
