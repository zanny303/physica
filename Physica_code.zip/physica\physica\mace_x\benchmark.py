"""Reproducible simulation of A-to-B calibrated transfer and learning curves.

Source machines and target machines are separate. Each probe selector sees a
list of predeclared safe actions, not the simulated observations. All algorithms
receive equal target observation budgets. Target errors use an untouched query
set that never enters model selection. Source machine data is extra prior data.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .core import (FEATURES,SensorCalibration,calibrated_rows,fit_source_memory,
                   fit_target, predict, rank_probes, posterior_summary,phi)

BUDGETS=(0,1,2,4,8,16,32)
COEF_MEAN=np.array([-.75,-.38,1.02,.03,.33])
COEF_SCALE=np.array([.08,.06,.075,.025,.06])


def calibration(device, modality, seed):
    gain,bias={'acoustic':(.65,.23),'motor_current':(1.35,-.1),
               'inertial':(1.0,.02),'visual_kinematics':(2.0,-.08)}[modality]
    return SensorCalibration(modality,gain,bias,.035*abs(gain),
                             f'SIMULATED_cal_{device}_{seed}','SIMULATED')


def task(seed, n_sources=9, n_candidates=75, n_test=150, regime='related'):
    if regime not in ('related','shifted','omitted'):
        raise ValueError('unknown target regime')
    rng=np.random.default_rng(seed)
    sources={};cals={}
    for i in range(n_sources):
        device=f'A{i:02d}'
        modality=('acoustic' if i%2==0 else 'motor_current')
        cal=calibration(device,modality,seed);cals[device]=cal
        theta=COEF_MEAN+rng.normal(0,COEF_SCALE)
        source=[]
        for j in range(125):
            x,v,u=rng.uniform(-1.1,1.1,3)
            physical=float(phi(dict(x=x,v=v,u=u))@theta+rng.normal(0,.035))
            source.append({'body_id':device,'episode_id':f'src{i}_ep{j//25}',
                 'x':float(x),'v':float(v),'u':float(u),'modality':cal.modality,
                 'observation':float(cal.gain*physical+cal.bias)})
        sources[device]=source
    memory=fit_source_memory(sources,cals, floor=.06)
    # B is NOT in sources. Shifted and omitted make transfer more difficult.
    truth=COEF_MEAN+rng.normal(0,COEF_SCALE)
    if regime=='shifted':truth=truth+np.array([.85,-.7,-.45,.38,-.55])
    target_id=f'B_{seed}_{regime}'
    target_modality=('inertial' if seed%2 else 'visual_kinematics')
    target_cal=calibration(target_id,target_modality,seed)
    # Candidate pool is created before revealing target outcome; queries are
    # generated from a separate stream with no intervention selection overlap.
    candidates=[]
    for j in range(n_candidates):
        if j%3==0: x,v,u=rng.uniform(-1,1),rng.uniform(-.1,.1),rng.uniform(-1,1)
        elif j%3==1: x,v,u=rng.uniform(-.1,.1),rng.uniform(-1,1),rng.uniform(-1,1)
        else: x,v,u=rng.uniform(-1,1,3)
        candidates.append({'x':float(x),'v':float(v),'u':float(u),
                           'intervention_type':'controlled','approved_reversible':True,
                           'expected_noise_sd':.035,'risk':0.,'cost':0.})
    queries=[{'x':float(rng.uniform(-1,1)),'v':float(rng.uniform(-1,1)),
              'u':float(rng.uniform(-1,1))} for _ in range(n_test)]
    # The withheld test labels are generated only after query construction.
    omitted=lambda q: .58*np.cos(3.6*q['x']-1.2*q['v']) if regime=='omitted' else 0.
    def true_response(q):return float(phi(q)@truth+omitted(q))
    test_truth=np.array([true_response(q) for q in queries])
    # Fixed noise keyed by candidate index to avoid favorable chance draws.
    measurement_noise=rng.normal(0,.035,size=n_candidates)
    def reveal(index):
        q=candidates[index];a=true_response(q)+float(measurement_noise[index])
        return {'body_id':target_id,'episode_id':f'target_probe_{index}',
                'x':q['x'],'v':q['v'],'u':q['u'],'modality':target_cal.modality,
                'observation':float(target_cal.gain*a+target_cal.bias)}
    return {'memory':memory,'calibration':target_cal,'candidates':candidates,
            'queries':queries,'test_truth':test_truth,'reveal':reveal,
            'target_id':target_id,'regime':regime,
            'source_machine_count':n_sources,'source_observation_count':sum(map(len,sources.values()))}


def _rmse(model, queries, target):
    y=predict(model,queries)['mean']
    return float(np.sqrt(np.mean((y-target)**2)))


def _sparse_stlsq(rows,*,ridge=.0003,threshold=.035):
    """Source-blind sparse linear-in-library system ID, STLSQ-like baseline.

    It uses exactly B's samples and the same feature library. Not a full
    PySINDy evaluation; for n<5 it falls back to a regularized local model.
    """
    model=fit_target(rows,None,mode='local')
    if len(rows)<5:return model
    X=np.stack([phi(r) for r in rows]);y=np.array([r['acceleration'] for r in rows])
    sig=np.maximum(np.linalg.norm(X,axis=0),1e-10)
    Z=X/sig
    active=np.ones(len(FEATURES),dtype=bool)
    coefs=np.zeros(len(FEATURES))
    for _ in range(5):
        if not active.any():break
        small=np.linalg.solve(Z[:,active].T@Z[:,active]+np.eye(active.sum())*ridge,
                              Z[:,active].T@y)
        coefs[:]=0;coefs[active]=small/sig[active]
        new_active=(np.abs(coefs)>threshold)
        # Do not drop the action term by convenience; keep it identifiable.
        new_active[2]=True
        if np.array_equal(active,new_active):break
        active=new_active
    base=model['components'][0]
    base['mean']=coefs
    return model


def _pick(method, posterior, available, candidates, queries, rng):
    if not available:raise ValueError('no remaining experiments')
    if method=='random':return int(rng.choice(available))
    if method!='targeted':raise ValueError('unknown probe method')
    # Rank only remaining actions, using no outcomes; map to stable original IDs.
    selected=rank_probes(posterior,[candidates[i] for i in available],queries)
    if not selected['ranked']:return int(rng.choice(available))
    return available[selected['ranked'][0]['index']]


def evaluate_one(seed,regime='related',budgets=BUDGETS):
    rng=np.random.default_rng(seed+91713)
    world=task(seed,regime=regime)
    memory=world['memory'];queries=world['queries'];truth=world['test_truth']
    modes={
        'target_only_random':('local','random'),
        'target_only_active':('local','targeted'),
        'stlsq_target_only':('stlsq','random'),
        'hierarchical_random':('hierarchical','random'),
        'mace_x_random':('mixture','random'),
        'mace_x_active':('mixture','targeted'),
    }
    records={}
    maxbudget=max(budgets)
    for name,(fitmode,policy) in modes.items():
        available=list(range(len(world['candidates'])))
        observations=[];points=[]
        # Use SAME random target probes for all random policies.
        method_rng=np.random.default_rng(seed+8818 if policy=='random' else seed+19781)
        for n in range(maxbudget+1):
            if n in budgets:
                if fitmode=='stlsq':model=_sparse_stlsq(observations)
                else:model=fit_target(observations,memory if fitmode!='local' else None,
                                     mode=fitmode,target_id=world['target_id'])
                score=_rmse(model,queries,truth)
                point={'n':n,'rmse':score}
                if fitmode=='mixture':point['source_posterior_weight']=float(model['components'][0]['weight'])
                points.append(point)
            if n==maxbudget:break
            planner=fit_target(observations,memory if fitmode not in ('local','stlsq') else None,
                              mode='local' if fitmode=='stlsq' else fitmode,target_id=world['target_id'])
            idx=_pick(policy,planner,available,world['candidates'],queries,method_rng)
            available.remove(idx)
            raw=world['reveal'](idx)
            observations.extend(calibrated_rows([raw],world['calibration']))
        records[name]=points
    return {'seed':seed,'regime':regime,'results':records,
            'memory_source_count':world['source_machine_count'],
            'source_samples_not_counted_as_target_probes':world['source_observation_count'],
            'cross_sensory_source_modalities':['acoustic','motor_current'],
            'target_modality':world['calibration'].modality,
            'target_test_outcomes_used_for_selection':False}


def run(seed_count=12,regimes=('related','shifted','omitted'),budgets=BUDGETS):
    if not 1<=seed_count<=200:raise ValueError('seed_count must be 1..200')
    if not budgets or sorted(set(budgets))!=list(budgets) or min(budgets)<0 or max(budgets)>64:
        raise ValueError('budgets must be increasing, unique and <=64')
    runs=[]
    for regime in regimes:
        for i in range(seed_count):runs.append(evaluate_one(1000+i*17,regime,budgets))
    methods=list(runs[0]['results'])
    means={}
    for regime in regimes:
        subset=[r for r in runs if r['regime']==regime]
        means[regime]={m:[{'n':n,
             'rmse':float(np.mean([next(p['rmse'] for p in r['results'][m] if p['n']==n) for r in subset]))}
             for n in budgets] for m in methods}
    summaries={}
    for regime in regimes:
        subset=[r for r in runs if r['regime']==regime]
        for n in (v for v in budgets if v>0):
            def vals(name):return np.array([next(p['rmse'] for p in r['results'][name] if p['n']==n) for r in subset])
            local=vals('target_only_random');transfer=vals('mace_x_random')
            active=vals('mace_x_active');local_active=vals('target_only_active')
            summaries[f'{regime}_{n}']={'target_only_mean':float(local.mean()),
                'transfer_mean':float(transfer.mean()),
                'transfer_win_count':int(np.sum(transfer<local)),
                'transfer_loss_count':int(np.sum(transfer>local)),
                'mace_x_active_mean':float(active.mean()),
                'target_only_active_mean':float(local_active.mean()),
                'n_target_devices':len(subset)}
    # Paired machine-level bootstrap, not correlated time-step resampling.
    uncertainty={}
    bootstrap_rng=np.random.default_rng(714)
    for regime in regimes:
        subset=[r for r in runs if r['regime']==regime]
        for n in (k for k in budgets if k>0):
            def at(r,method):return next(p['rmse'] for p in r['results'][method] if p['n']==n)
            diff=np.array([at(r,'target_only_random')-at(r,'mace_x_random') for r in subset])
            boot=np.mean(diff[bootstrap_rng.integers(len(diff),size=(1200,len(diff)))],axis=1)
            uncertainty[f'{regime}_{n}']={'paired_rmse_reduction_mean':float(diff.mean()),
                'machine_level_bootstrap_95pct_interval':[float(v) for v in np.quantile(boot,[.025,.975])],
                'n_independent_targets':len(diff),'positive_is_transfer_better':True}
    return {'schema':'physica.mace_x.learning_curves.v014',
        'origin':'SIMULATION_ONLY','seed_count':seed_count,'target_machine_count':len(runs),
        'budgets':list(budgets),'heldout_query_count_per_target':150,
        'source_machine_count_per_run':9,'source_samples_per_run':1125,
        'source_data_disclosed_separately':True,'sensor_calibration_provenance':'SIMULATED',
        'source_mean_parameter_family_shared_with_related_targets':True,
        'source_and_target_machine_ids_disjoint':True,
        'no_authenticated_meta_calls':True,'no_real_hardware_claim':True,
        'notes':['Cross-sensory mappings are supplied by independently specified SIMULATED calibration constants; not learned from raw video/audio.',
             'Bayesian source prior is not a novel algorithm on its own.',
             'Source and target assume a shared finite dynamical feature library. Omitted family violates this assumption.',
             'Target queries and test labels are held out of fitting and probe ranking.',
             'Random baselines and active baselines use the same B observation counts but may select different B observations.',
             'STLSQ is an in-project sparse regression comparator, not a run of the full PySINDy package.'],
        'aggregate':means,'comparisons':summaries,'machine_level_bootstrap_intervals':uncertainty,'per_machine':runs}


def save(result,path):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return p
