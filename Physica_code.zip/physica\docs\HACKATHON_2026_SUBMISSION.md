# Physica — Meta AI Hackathon submission package (draft)

**Title:** PHYSICA — Give machines a language for physical experience

**Tagline:** Cameras see how things look. Physica learns how things respond, predicts what happens next, and teaches that experience to another machine.

**One-sentence problem:** Physical AI struggles with mass, stiffness, damping, touch, damage, sensor domain shift, rare failures and costly machine-specific tuning; image recognition alone cannot resolve those quantities.

**What is delivered in this archive:** original Physica sensing/evaluation/traditional Body Bank/translators, plus PACER v0.2 physical episode JSON Schema, safety-gated causal experiment selection, operational consequence loop, signed prediction + reveal, compatible prior transfer, deterministic demo and interactive dashboard. Muse review hook can call a configured Meta Model API in live mode; SAM/V-JEPA full pretrained integrations are still planned, not bundled.

## Best first product use case

**Guarded industrial/robotic equipment that learns faults and safe diagnostic steps from its fleet.** A machine with cheap vibration/video sensing predicts the consequence of an operation, detects deviations, writes an annotated experience record, and another compatible machine can use that as a prior rather than starting cold. In hackathon terms, demonstrate two small guarded fans or robot joints, not unguarded high-energy machines. This maximizes visible value (repair and fleet learning) while keeping physical risk reasonable.

A deliberately sacrificial bracket experiment illustrates **irreversible consequence**; a ruler with hidden mass illustrates blind physical measurement. Neither is verified physically in PACER's bundled sandbox. The original repository contains separate real beam and drone test scripts and saved results.

## Three-minute video (script + shot list)

**0:00–0:25 — The gap.** Real phone/drone footage or existing original beam/flight output. "Vision knows what the machine looks like. But can it tell what force did, what changed, or what will break next?" Overlay: what is sensed vs what is only inferred.

**0:25–0:55 — Machine A feels.** Show sensor waveform and Physica's existing Feel Transform, cancellation of healthy self-motion, hypothesis scores and source provenance. Do not assert rotor localisation when original `E8` said ambiguous.

**0:55–1:20 — The irreversible consequence.** Open `experience_lab.html` > Consequence sandbox and move the loading slider. "Before touching the physical object, Physica simulates possible deformation and the chance the next force could damage it—and rejects unsafe actions." Say "simulation" visibly. For the final submission replace with a real guarded *sacrificial* bracket video only after safe independently recorded measurements.

**1:20–1:50 — Seal, act, reveal.** Show `sealed_before_observation.json` and `revealed_consequence.json`. A prediction is cryptographically committed, simulator/experiment produces a response, Physica compares and records the residual. Demonstrate tampering: edit a predicted number and `physica experience verify` must return `INVALID`. This can be filmed now in the offline demo.

**1:50–2:30 — Machines teach machines.** Machine A learns a mount-fault posterior from the source episode. Open the "Teach Machine B" tab; change to second fan (different absolute resonance), compare dimensionless modal ratios, excite at compatible conditions, transfer a prior and select a *new safe verification experiment*. Show with/without prior posteriors. Explain that this is presently a **synthetic** proof of the software protocol, not a confirmed real transfer gain.

**2:30–2:50 — Meta's role.** SAM 3.1: object/part tracking; V-JEPA 2: learned visual dynamics; Muse Wonder/Spark: hypothesis explanations, instrument selection and constrained tool orchestration; PACER: grounded numerical physics and safety gate. If you haven't personally run SAM/V-JEPA live, label their roles "planned". Show exactly which Muse adapter is `mock` or `live`.

**2:50–3:00 — Close.** "AI learned to share words. Physica is building a way for machines to share what the physical world taught them."

## Assets in the archive

- `examples/experience/experience_lab.html`: offline interactive evidence browser, from a deterministic simulator.
- `examples/experience/demo_results.json`: machine-readable simulation and transfer results.
- `examples/experience/sealed_before_observation.json`: signed commitment.
- `examples/experience/revealed_consequence.json`: signed response and a linked commitment.
- `examples/experience/learned_episode.json`: learned transferable signed episode.
- `examples/experience/experience.schema.json`: JSON Schema for the physical language.
- `eval/results/*.json`: original repository's prior experiment outputs, not independently reproduced here.
- `README.md`, `SPEC.md`, `DATA.md`: original project design, commands and data sources.

## Submission honesty and judge questions

**Q: Is this a new FFT?** No; modal innovations are established. PACER is a proposed integration of sensing, causal reasoning, experiment selection, signed consequences and transfer.

**Q: Did you demonstrate real cross-machine transfer?** The original repository reports an Order Feel skill transfer across drone models (`E9`); the new signed Physical Episode A→B protocol is *synthetic only* so far. These are distinct things.

**Q: Does AI actually feel pain or damage?** No claim of subjective experience. "Feel" means predict a sensor response, detect an unexpected physical consequence and adapt future actions.

**Q: Is Meta essential?** The final architecture uses Muse as scientist/reviewer, SAM for perception and V-JEPA for dynamics priors; current runnable offline demo can operate without Meta API, so integration is **not yet proven indispensable**. Never label mock calls as live.

**Q: Are the results a safety certification?** No. Especially for fans, printers, structures, robots and brackets, require supervised tests and protected hardware.

## What is still required for a truly complete winning submission

1. Run at least one complete, filmed, *real* A→B transfer experiment, collecting raw synchronized sensor/video and calibrated actions.
2. Test blind predictions with independent evidence of pre-commit time and reproducible raw-file hashes; quantify failure interval coverage and false positives, including misses.
3. Obtain Meta Model API credentials and run the live Muse reviewer/agent with request/response audit. If available, integrate official SAM 3.1 and V-JEPA 2 dependencies/weights and present comparative ablations.
4. Compare A→B with/without prior across many held-out bodies and report intervention efficiency and risk, including refusal cases.
5. Review appropriate hackathon rules, privacy consent and hardware safety before submission.

There is no guarantee of winning; the demo and core code are a credible starting point with explicit evidence boundaries.
