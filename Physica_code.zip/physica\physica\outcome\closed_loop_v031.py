"""v0.31: evidence-gated Program-By-Outcome → investigate → reoptimize → verify.

Supported numerical reidentification in this release: measured beam resonance tone as a
function of actuator support position. Other Physica applications retain their own
physical solvers; this module never claims one beam law governs unrelated equipment.

No hardware actuation. Every stage is a separate, explicit CLI invocation. A local
SHA256 is an integrity check, NOT independent proof of chronology or calibration.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

from .contract import check as check_goal
from .engineer import plan
from .spec import OutcomeSpec, offline_parse
from .worlds.beam import BeamWorld

SCHEMA = 'physica.outcome_closed_loop.v031'
MODEL_SCHEMA = 'physica.beam_model.v031'


class EvidenceRefusal(ValueError):
    """Invalid or insufficient evidence; never substitute simulated measurements."""


def _canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def _digest(obj: Any) -> str:
    return hashlib.sha256(_canonical(obj)).hexdigest()


def _file_digest(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _finite(value, name: str, *, positive: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
        raise EvidenceRefusal(f'{name} must be finite and numeric')
    if positive and value <= 0:
        raise EvidenceRefusal(f'{name} must be greater than zero')
    return float(value)


def _read_json(path: Path) -> dict:
    obj = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(obj, dict):
        raise EvidenceRefusal(f'{path.name} must contain one JSON object')
    return obj


def _validate_model(doc: dict) -> BeamWorld:
    if doc.get('schema') != MODEL_SCHEMA or doc.get('unit_support') != 'V' or doc.get('unit_tone') != 'Hz':
        raise EvidenceRefusal('Expected an explicitly unit-labelled v0.31 beam model')
    coef = np.asarray(doc.get('coef', []), dtype=float)
    cal = doc.get('calibration', [])
    rng = doc.get('support_range_v', [])
    if coef.ndim != 1 or not (1 <= len(coef) <= 5) or not np.all(np.isfinite(coef)):
        raise EvidenceRefusal('Beam polynomial coefficients are invalid')
    if not isinstance(cal, list) or len(cal) < 5:
        raise EvidenceRefusal('Model requires at least five recorded calibration residuals')
    if not isinstance(rng, list) or len(rng) != 2:
        raise EvidenceRefusal('Missing support range')
    lo, hi = [_finite(v, 'support bound') for v in rng]
    if lo >= hi:
        raise EvidenceRefusal('Invalid support range')
    v, r = [], []
    for entry in cal:
        if not isinstance(entry, dict):
            raise EvidenceRefusal('Malformed calibration sample')
        x = _finite(entry.get('support_v'), 'calibration support')
        res = _finite(entry.get('abs_residual_hz'), 'absolute calibration residual')
        if res < 0 or not lo <= x <= hi:
            raise EvidenceRefusal('Calibration residual or support out of range')
        v.append(x); r.append(res)
    if doc.get('origin') not in ('simulation', 'real_recording'):
        raise EvidenceRefusal('Model origin must be declared')
    if doc.get('origin') == 'real_recording':
        provenance = str(doc.get('training_record_sha256', ''))
        if len(provenance) != 64 or any(c not in '0123456789abcdef' for c in provenance.lower()):
            raise EvidenceRefusal('Real model requires its source-recording hash')
    return BeamWorld(coef, np.asarray(v), np.asarray(r), (lo, hi))


def _validate_approved(doc: dict, system_id: str, world: BeamWorld) -> list[float]:
    if doc.get('machine_id') != system_id or not doc.get('approved_by') or doc.get('automatic_actuation') is not False:
        raise EvidenceRefusal('An explicitly named human-approved, non-actuating settings list is required')
    values = doc.get('support_positions_v')
    if not isinstance(values, list) or len(values) < 10 or len(values) > 1000:
        raise EvidenceRefusal('Need 10–1000 explicitly approved support positions')
    x = sorted(set(_finite(a, 'approved position') for a in values))
    if len(x) < 10 or not all(world.in_range(a) for a in x):
        raise EvidenceRefusal('Approved positions must contain ten distinct in-range settings')
    return x


def _probes(approved: list[float], current: float, world: BeamWorld, forcing_hz: float) -> list[dict]:
    """Predeclare fit/validation locations without seeing any probe outcomes.

    This is safe *coverage sampling*, not a claim of optimal Bayesian information gain.
    The order privileges the goal boundary and locations with large existing uncertainty.
    """
    scored = []
    for x in approved:
        p = world.predict(x)
        # Close-to-forcing candidates matter for a resonance-avoidance goal.
        target = abs(p['tone_hz'] - forcing_hz)
        width = p['hi'] - p['lo']
        importance = width / (1 + target) - .001 * abs(x - current)
        scored.append((importance, x))
    seed_set = sorted(x for _, x in sorted(scored, reverse=True)[:4])
    spaced = [approved[round(i * (len(approved) - 1) / 8)] for i in range(9)]
    combined = sorted(set(seed_set + spaced))
    if len(combined) < 9:
        combined = sorted(set(combined + approved))
    # Assign alternating locations to fit vs holdout to avoid all validation at an edge.
    chosen = combined[:9] if len(combined) == 9 else [combined[round(i * (len(combined)-1) / 8)] for i in range(9)]
    return [{'experiment_id': ('fit_' if i % 2 == 0 else 'validation_') + f'{i+1:02d}',
             'split': 'fit' if i % 2 == 0 else 'validation', 'support_v': float(x),
             'unit_support': 'V', 'unit_measurement': 'Hz', 'requires_human_approval': True}
            for i, x in enumerate(chosen)]


def _plan_json(plan_obj) -> dict:
    return plan_obj.to_json()


def _sensory_surprise(world: BeamWorld, machine_id: str, current: float,
                      sensation: dict | None) -> dict | None:
    if sensation is None:
        return None
    if sensation.get('machine_id') != machine_id or sensation.get('unit_support') != 'V' or sensation.get('unit_tone') != 'Hz':
        raise EvidenceRefusal('Sensation must match the same machine and SI-labelled physical quantity')
    location=_finite(sensation.get('support_v'),'sensation support')
    if abs(location-current)>1e-6:
        raise EvidenceRefusal('Sensation is not measured at the declared current state')
    measured=_finite(sensation.get('observed_tone_hz'),'observed tone',positive=True)
    sensor_sigma=_finite(sensation.get('sensor_sigma_hz'),'measured sensor noise',positive=True)
    if not sensation.get('sensor_id') or not sensation.get('calibration_ref'):
        raise EvidenceRefusal('Measured sensation requires a sensor and calibration reference')
    prediction=world.predict(current)
    # The model's empirical interval half-width is used as a conservative noise
    # proxy here; this is a trigger heuristic, NOT a calibrated p-value.
    proxy_width=max((prediction['hi']-prediction['lo'])/2, 0.)
    combined=math.hypot(sensor_sigma,proxy_width)
    z=abs(measured-prediction['tone_hz'])/combined
    return {'expected_tone_hz':prediction['tone_hz'],'observed_tone_hz':measured,
        'observed_minus_predicted_hz':measured-prediction['tone_hz'],
        'surprise_z_proxy':z, 'review_trigger':bool(z>=3.),
        'sensor_id':str(sensation['sensor_id']),
        'calibration_ref':str(sensation['calibration_ref']),
        'sensor_uncertainty_sigma_hz':sensor_sigma,
        'statistical_significance_or_fault_diagnosis_claimed':False,
        'metadata_not_independent_calibration_proof':True}


def start(goal: str, model_doc: dict, approved_doc: dict, *, machine_id: str,
          current_support_v: float, investigate: bool = False,
          sensation: dict | None = None) -> dict:
    world = _validate_model(model_doc)
    if not machine_id or not isinstance(machine_id, str):
        raise EvidenceRefusal('Machine ID required')
    current = _finite(current_support_v, 'current support')
    if not world.in_range(current):
        raise EvidenceRefusal('Current machine support is outside measured range')
    approved = _validate_approved(approved_doc, machine_id, world)
    spec = offline_parse(goal, machine='beam')
    problems = check_goal(spec)
    if spec.unclear or problems:
        raise EvidenceRefusal('Incomplete goal: ' + '; '.join(dict.fromkeys(spec.unclear + problems)))
    initial = plan(spec, world, {'support_v': current, 'presets': np.asarray(approved)})
    feeling = _sensory_surprise(world,machine_id,current,sensation)
    needs = bool(investigate or initial.status == 'no action meets the goal' or (feeling and feeling['review_trigger']))
    probes = _probes(approved, current, world, float(spec.context['forcing_hz'])) if needs else []
    doc = {
        'schema': SCHEMA, 'machine': 'beam', 'machine_id': machine_id,
        'origin': model_doc['origin'], 'goal': goal,
        'model': model_doc, 'model_sha256': _digest(model_doc),
        'approved_settings': approved_doc, 'approved_sha256': _digest(approved_doc),
        'current_support_v': current, 'initial_plan': _plan_json(initial),
        'sensory_surprise': feeling, 'discovery_trigger': ('MANUAL_INVESTIGATION' if investigate else
            'CALIBRATED_SENSORY_SURPRISE_HEURISTIC' if feeling and feeling['review_trigger'] else
            'NO_FEASIBLE_ACTION' if initial.status=='no action meets the goal' else 'NO_DISCOVERY_NEEDED'),
        'probe_plan': probes,
        'stage': 'AWAITING_INDEPENDENT_PROBES' if needs else 'READY_FOR_REVIEW',
        'causal_claim': 'UNVERIFIED', 'no_hardware_actuation': True,
        'limitations': ['Probes require human review and actual separately recorded evidence',
                        'A local SHA256 is not an independent timestamp or calibration certificate',
                        'The correction family is a bounded beam-specific residual model, not universal physics'],
    }
    doc['session_commit_sha256'] = _digest(doc)
    return doc


def _validate_session(session: dict, expected_stage: str) -> None:
    original = dict(session)
    receipt = original.pop('session_commit_sha256', None)
    if session.get('schema') != SCHEMA or _digest(original) != receipt:
        raise EvidenceRefusal('Session commitment failed; planning evidence may have been changed')
    if session.get('stage') != expected_stage:
        raise EvidenceRefusal(f'Expected stage {expected_stage}; got {session.get("stage")}')
    if _digest(session['model']) != session['model_sha256'] or _digest(session['approved_settings']) != session['approved_sha256']:
        raise EvidenceRefusal('Model or approved settings changed')


def _load_probes(csv_path: Path, session: dict, calibration: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if calibration.get('machine_id') != session['machine_id'] or calibration.get('unit_tone') != 'Hz' or not calibration.get('sensor_id'):
        raise EvidenceRefusal('Missing matching instrument ID and units')
    sigma = _finite(calibration.get('measured_sigma_hz'), 'instrument measurement sigma', positive=True)
    if not calibration.get('calibration_method') or not calibration.get('calibration_date_utc'):
        raise EvidenceRefusal('Independent calibration procedure/date metadata required')
    with csv_path.open(newline='', encoding='utf-8') as fp:
        rows = list(csv.DictReader(fp))
    if len(rows) != len(session['probe_plan']):
        raise EvidenceRefusal('Every planned probe must have exactly one result')
    expected = {p['experiment_id']:p for p in session['probe_plan']}
    found: set[str] = set()
    fit_x, fit_y, val_x, val_y = [], [], [], []
    for row in rows:
        pid = row.get('experiment_id')
        if pid not in expected or pid in found:
            raise EvidenceRefusal('Unknown or repeated experiment ID')
        found.add(pid)
        p = expected[pid]
        if row.get('split') != p['split'] or row.get('unit_support') != 'V' or row.get('unit_tone') != 'Hz':
            raise EvidenceRefusal('Split or units do not match committed plan')
        x = float(row['support_v']); y = float(row['tone_hz'])
        _finite(x, 'probe support'); _finite(y, 'probe tone')
        if abs(x - p['support_v']) > 1e-6 or y <= 0:
            raise EvidenceRefusal('Probe action differs from committed plan or tone is nonpositive')
        (fit_x if p['split']=='fit' else val_x).append(x)
        (fit_y if p['split']=='fit' else val_y).append(y)
    if len(fit_x) < 5 or len(val_x) < 4:
        raise EvidenceRefusal('Insufficient independent fit/validation experiments')
    return np.asarray(fit_x), np.asarray(fit_y), np.asarray(val_x), np.asarray(val_y)


class CorrectedBeamWorld:
    """Conservative correction accepted only inside the measured probe envelope."""
    machine = 'beam'

    def __init__(self, base: BeamWorld, coefficient: list[float], anchor: float, validation_abs: list[float],
                 fit_domain: tuple[float, float], sigma: float):
        self.base = base
        self.coef = coefficient
        self.anchor = anchor
        self.validation_abs = validation_abs
        self.fit_domain = fit_domain
        self.sigma = sigma

    def predict(self, v: float) -> dict:
        if not self.base.in_range(v) or not self.fit_domain[0] <= v <= self.fit_domain[1]:
            return {'refused':True, 'why':'Outside validated correction support range'}
        prior = self.base.predict(v)
        correction = sum(c * (v - self.anchor)**i for i, c in enumerate(self.coef))
        n = len(self.validation_abs)
        # Conservative finite-sample empirical residual bound; no formal
        # coverage claim under local extrapolation or distribution shift.
        q = min(1., math.ceil((n+1)*.9)/n)
        error = float(np.quantile(self.validation_abs, q))
        h = max((prior['hi']-prior['lo'])/2, error + self.sigma)
        m = prior['tone_hz'] + correction
        return {'refused':False, 'tone_hz':float(m), 'lo':float(m-h), 'hi':float(m+h),
                'model':'validated_affine_residual', 'empirical_not_formal_coverage':True}

    def candidates(self, spec, state):
        return self.base.candidates(spec, state)

    def outcome(self, a):
        return self.predict(a['support_v'])

    def feasible(self, spec, pred, use_error_bar=True):
        return self.base.feasible(spec,pred,use_error_bar)

    def cost(self, spec, action, pred, state):
        return self.base.cost(spec,action,pred,state)

    def describe(self, action, pred, state):
        return self.base.describe(action,pred,state)


def propose_muse_residual_family(session: dict, fit_x: np.ndarray, fit_residual: np.ndarray,
                                 *, allow_billed_meta: bool) -> dict:
    """Optional authenticated Muse structural proposal using ONLY five fit probes.

    The ordinary affine baseline is evaluated regardless of the proposal.
    A Muse-generated quadratic term must beat it on separate validation points
    before the numerical model can use it. This is hypothesis selection, not
    arbitrary parameter rewriting or verified novel causal discovery.
    """
    if not allow_billed_meta:
        raise EvidenceRefusal('Explicit --allow-billed-meta required for Muse inference')
    from physica.llm import meta_client as client
    if client.is_mock():
        raise EvidenceRefusal('Set your private MODEL_API_KEY and MOCK=0 before live inference')
    from physica.frontier.meta_council_v026 import _verified
    schema={'type':'json_schema','json_schema':{
        'name':'PhysicaBeamResidualV031','strict':True,
        'schema':{'type':'object','additionalProperties':False,
                  'properties':{'family':{'type':'string','enum':['affine_residual','quadratic_residual','abstain']},
                    'reason':{'type':'string'},'potential_confounder':{'type':'string'}},
                  'required':['family','reason','potential_confounder']}}}
    context={'split':'TRAIN_FIT_ONLY_NO_VALIDATION_OR_FUTURE_OUTCOME',
       'goal':session['goal'], 'machine_id':session['machine_id'],
       'observed_training_residuals':[{'support_v':float(x),'observed_minus_baseline_hz':float(y)}
                                      for x,y in zip(fit_x,fit_residual)],
       'notice':'These samples cannot establish causality. Do not invent other data or declare a mechanism verified.'}
    try:
        r=client.complete('wonder',[
            {'role':'system','content':('You are a skeptical physical modeling researcher. Choose only from the '
             'three specified bounded structural responses using the five training-only observations. '
             'A nonlinear candidate should be proposed only if there is evidence of curvature. '
             'No learned coefficients, experiments, or validation results are allowed in your response.')},
            {'role':'user','content':json.dumps(context,sort_keys=True)}],
            'physica_v031_outcome_residual_proposal',max_completion_tokens=2200,
            response_format=schema,require_fresh=True)
        proof=_verified(r,expected_role='wonder',task='physica_v031_outcome_residual_proposal')
        content=r['content'].strip()
        if content.startswith('```'):
            lines=content.splitlines()
            if lines[-1].strip()=='```': content='\n'.join(lines[1:-1]).strip()
        proposal=json.loads(content)
        if (not isinstance(proposal,dict) or set(proposal)!={'family','reason','potential_confounder'} or
              proposal['family'] not in ('affine_residual','quadratic_residual','abstain') or
              not all(isinstance(proposal[k],str) and 0<len(proposal[k])<=600 for k in ('reason','potential_confounder'))):
            raise EvidenceRefusal('Muse did not return a valid bounded proposal')
        return {'status':'META_AUTHENTICATED_PROPOSAL_UNVERIFIED','family':proposal['family'],
                'reason':proposal['reason'],'potential_confounder':proposal['potential_confounder'],
                'receipt':proof, 'validation_was_hidden':True}
    except Exception as exc:
        # Paid calls can fail or be truncated. Never turn a failed call into a
        # claimed Meta discovery, leak the model response, or block local fallback.
        return {'status':'META_ABSTAIN', 'failure_class':type(exc).__name__,
                'family':'abstain','validation_was_hidden':True}


def learn(session: dict, probes_csv: Path, calibration_json: Path, *, min_improvement: float = .10,
          live_meta: bool = False, allow_billed_meta: bool = False,
          human_candidate: str | None = None) -> dict:
    _validate_session(session, 'AWAITING_INDEPENDENT_PROBES')
    base = _validate_model(session['model'])
    calibration = _read_json(calibration_json)
    fit_x, fit_y, val_x, val_y = _load_probes(probes_csv,session,calibration)
    if probes_csv.resolve() == calibration_json.resolve():
        raise EvidenceRefusal('Calibration and experiment records cannot be the same file')
    sigma = _finite(calibration['measured_sigma_hz'],'calibrated sigma',positive=True)
    base_train = np.polyval(base.coef,fit_x)
    base_val = np.polyval(base.coef,val_x)
    anchor = float(np.mean(fit_x))
    shift = np.column_stack((np.ones(len(fit_x)), fit_x-anchor))
    blind_coefs = np.linalg.lstsq(shift, fit_y-base_train,rcond=None)[0]
    blind_prediction = base_val+blind_coefs[0]+blind_coefs[1]*(val_x-anchor)
    baseline_rmse = float(np.sqrt(np.mean((val_y-base_val)**2)))
    blind_rmse = float(np.sqrt(np.mean((val_y-blind_prediction)**2)))
    if live_meta and human_candidate is not None:
        raise EvidenceRefusal('Cannot combine human fixture with authenticated Muse nomination')
    muse={'status':'NOT_CALLED','family':'abstain'}
    if live_meta:
        muse=propose_muse_residual_family(session,fit_x,fit_y-base_train,
                 allow_billed_meta=allow_billed_meta)
    if human_candidate is not None:
        if human_candidate not in ('affine_residual','quadratic_residual','abstain'):
            raise EvidenceRefusal('Human candidate outside bounded grammar')
        muse={'status':'HUMAN_AUTHORED_FIXTURE_NOT_META','family':human_candidate}
    coefs=blind_coefs
    estimate_val=blind_prediction
    chosen_family='affine_residual_shift_and_slope'
    meta_incremental_holdout_gain_hz=0.0
    if muse['family']=='quadratic_residual':
        design = np.column_stack((np.ones(len(fit_x)),fit_x-anchor,(fit_x-anchor)**2))
        proposed = np.linalg.lstsq(design,fit_y-base_train,rcond=None)[0]
        quad_prediction = base_val + proposed[0]+proposed[1]*(val_x-anchor)+proposed[2]*(val_x-anchor)**2
        quad_rmse = float(np.sqrt(np.mean((val_y-quad_prediction)**2)))
        meta_incremental_holdout_gain_hz = blind_rmse - quad_rmse
        # The richer proposal must materially improve on the *existing affine*
        # search despite model selection on a very small validation set.
        if meta_incremental_holdout_gain_hz > max(.05*blind_rmse,sigma):
            coefs=proposed
            estimate_val=quad_prediction
            chosen_family='quadratic_residual_proposed_by_'+('META' if live_meta else 'HUMAN_FIXTURE')
    adjusted_rmse = float(np.sqrt(np.mean((val_y-estimate_val)**2)))
    # With only 4 validation probes, a reduction that is within the declared
    # sensor sigma is not credible as a new discovered mechanism.
    improvement = baseline_rmse - adjusted_rmse
    accepted = bool(improvement > max(float(min_improvement)*baseline_rmse, sigma))
    val_abs = np.abs(val_y-estimate_val).tolist()
    domain = [float(min(min(fit_x),min(val_x))), float(max(max(fit_x),max(val_x)))]
    world = (CorrectedBeamWorld(base,coefs.tolist(),anchor,val_abs,tuple(domain),sigma) if accepted else base)
    spec = offline_parse(session['goal'],machine='beam')
    approved = np.asarray(_validate_approved(session['approved_settings'],session['machine_id'],base))
    revised_plan = plan(spec, world, {'support_v':session['current_support_v'], 'presets':approved})
    holdout = {
       'baseline_rmse_hz':baseline_rmse, 'candidate_rmse_hz':adjusted_rmse,
       'absolute_improvement_hz':improvement,
       'source_blind_candidate_accepted':accepted,
       'validation_split_used_for_selection_not_final_test':True,
       'candidate_family':chosen_family,
       'source_blind_affine_rmse_hz':blind_rmse,
       'muse_incremental_holdout_gain_hz':meta_incremental_holdout_gain_hz,
       'muse_proposal_selected_for_prediction':bool(accepted and chosen_family.startswith('quadratic_residual')),
       'model_discovery_claim':'BOUNDED_RESIDUAL_CORRECTION_NOT_UNKNOWN_PHYSICS',
       'fit_episodes':len(fit_x),'validation_episodes':len(val_x),
       'calibration_sigma_hz':sigma,
    }
    result = {k:v for k,v in session.items() if k != 'session_commit_sha256'}
    result['evidence'] = {'probe_csv_sha256':_file_digest(probes_csv),
        'calibration_sha256':_file_digest(calibration_json),
        'calibration_sensor_id':calibration['sensor_id'],
        'source_origin':session['origin'],
        'calibration_metadata_self_reported_not_independently_audited':True,
        'fit_and_validation_separate_from_final_reveal':True}
    result['validation'] = holdout
    result['muse_proposal'] = muse
    result['updated_model'] = {'accepted':accepted, 'coef':[float(c) for c in coefs],
         'anchor':anchor, 'validation_abs_residual_hz':val_abs,
         'fit_domain_v':domain,'sigma_hz':sigma}
    result['revised_plan']=revised_plan.to_json()
    result['causal_claim']='CANDIDATE_CORRECTION_VALIDATED_FOR_PREDICTION_ONLY' if accepted else 'NO_SUPPORTED_CORRECTION'
    result['stage']='AWAITING_FUTURE_OUTCOME' if revised_plan.status=='act' else 'NO_SAFE_ACTION_OR_ALREADY_MET'
    if result['stage']=='AWAITING_FUTURE_OUTCOME':
        pred = revised_plan.predicted
        result['forecast']={'quantity':'tone_hz','unit':'Hz','action_support_v':revised_plan.action['support_v'],
                           'predicted_tone_hz':pred['tone_hz'],'interval_hz':[pred['lo'],pred['hi']],
                           'description':'Future measurement after operator-approved adjustment'}
        result['forecast_commit_sha256']=_digest(result['forecast'])
    result['no_hardware_actuation']=True
    result['session_commit_sha256']=_digest(result)
    return result


def verify(session: dict, future_json: Path) -> dict:
    _validate_session(session,'AWAITING_FUTURE_OUTCOME')
    future = _read_json(future_json)
    if _file_digest(future_json) in {session['evidence']['probe_csv_sha256'],session['evidence']['calibration_sha256']}:
        raise EvidenceRefusal('Future outcome reuses previous data file')
    forecast = session.get('forecast') or {}
    if _digest(forecast) != session.get('forecast_commit_sha256'):
        raise EvidenceRefusal('Future forecast commitment was changed')
    if future.get('experiment_id') != 'future_outcome_01' or future.get('machine_id') != session['machine_id']:
        raise EvidenceRefusal('Future experiment identity differs from declared target machine')
    if future.get('unit_support') != 'V' or future.get('unit_tone') != 'Hz':
        raise EvidenceRefusal('Future measurement has wrong units')
    setting=_finite(future.get('support_v'),'future support position')
    if abs(setting-forecast['action_support_v'])>1e-6:
        raise EvidenceRefusal('Actual action does not match sealed predicted action')
    if future.get('calibration_sha256')!=session['evidence']['calibration_sha256']:
        raise EvidenceRefusal('Future measurement calibration provenance does not match')
    measured=_finite(future.get('measured_tone_hz'),'future measured tone')
    if measured<=0:
        raise EvidenceRefusal('Measured frequency cannot be nonpositive')
    lo,hi=forecast['interval_hz']
    goal=offline_parse(session['goal'],machine='beam')
    forcing=float(goal.context['forcing_hz']); margin=float(goal.get('tone_hz','outside_band_pct'))
    goal_lo=forcing*(1-margin/100);goal_hi=forcing*(1+margin/100)
    covered=bool(lo<=measured<=hi)
    goal_met=bool(measured<goal_lo or measured>goal_hi)
    evidence={'future_measurement_sha256':_file_digest(future_json),
       'future_outcome_id':future['experiment_id'],'observed_hz':measured,
       'forecast_hz':forecast['predicted_tone_hz'],
       'absolute_prediction_error_hz':abs(measured-forecast['predicted_tone_hz']),
       'forecast_interval_held':covered,'measured_goal_met':goal_met,
       'calibration_sha256':future['calibration_sha256'],
       'independent_timestamp_not_verified':True,
       'hardware_actuation_not_verified_by_software':True,
       'not_a_general_safety_certification':True}
    status='MEASURED_GOAL_MET' if goal_met and covered else ('MEASURED_GOAL_MET_UNCALIBRATED_FORECAST' if goal_met else 'GOAL_NOT_MET')
    return {'schema':SCHEMA,'stage':'FUTURE_OUTCOME_REVEALED','status':status,
            'machine_id':session['machine_id'],'origin':session['origin'],
            'initial_plan':session['initial_plan'],'revised_plan':session['revised_plan'],
            'selected_model':session['causal_claim'],'holdout':session['validation'],
            'measured':evidence, 'experience_memory':{
                'eligible_for_review_only_transfer':bool(covered and goal_met and session['validation']['source_blind_candidate_accepted']),
                'lesson':'Measured local resonance residual correction; compatibility must be revalidated on a different machine',
                'source_machine_id':session['machine_id'], 'no_automatic_transfer_or_actuation':True},
            'scientific_discovery_established':False,'unplanned_downtime_prevented':False}


def export_beam_model(tone_points_npz: Path) -> dict:
    """Export a beam model from the existing independently split DROPBEAR tone-point cache.

    Extraction of the tone points from raw recordings occurs in the existing
    physica.outcome.worlds.beam.tone_points pipeline. The caller must audit the
    raw dataset and whether its purported calibration is genuine.
    """
    with np.load(tone_points_npz, allow_pickle=False) as archive:
        if 'points' not in archive:
            raise EvidenceRefusal('Expected the saved DROPBEAR tone_points cache')
        points=archive['points']
    required={'file','group','pin_v','tone_hz'}
    if points.dtype.names is None or not required.issubset(set(points.dtype.names)):
        raise EvidenceRefusal('Invalid tone points field schema')
    sweep=points[(points['group']=='sweep') & np.isfinite(points['tone_hz'])]
    if len(sweep)<30 or len(set(sweep['file']))<4:
        raise EvidenceRefusal('Need sufficient independent beam sweep recordings')
    try:
        fitted=BeamWorld.learn(sweep)
    except (ValueError, np.linalg.LinAlgError, FloatingPointError) as e:
        raise EvidenceRefusal('Beam model identification failed on supplied tone points') from e
    if len(fitted.cal_res)<5 or not np.all(np.isfinite(fitted.cal_res)):
        raise EvidenceRefusal('Beam model lacks reliable held-out calibration residuals')
    return {'schema':MODEL_SCHEMA,'origin':'real_recording',
            'unit_support':'V','unit_tone':'Hz',
            'coef':[float(v) for v in fitted.coef],
            'support_range_v':[float(v) for v in fitted.v_range],
            'calibration':[{'support_v':float(x),'abs_residual_hz':float(y)}
               for x,y in zip(fitted.cal_v,fitted.cal_res)],
            'training_record_sha256':_file_digest(tone_points_npz),
            'source_note':'Derived from user-supplied tone-point cache; independently verify raw recording origins and instrument calibration'}


def domain_inquiry(field_manifest: Path, *, desired_goal: str,
                   live_meta: bool = False, allow_billed_meta: bool = False) -> dict:
    """Bridge the shared printer/F1/turbine Feeling Engine into Outcome Mode.

    This intentionally returns an inquiry, NOT a numerical actuator plan: those
    domains must validate their own dynamics and constraints before optimization.
    """
    from dataclasses import replace
    from physica.unified.field import from_field_manifest
    from physica.unified.engine import investigate
    from physica.unified.meta import run_domain_research_council
    if not isinstance(desired_goal, str) or len(desired_goal.strip()) < 12:
        raise EvidenceRefusal('Describe the desired, measurable physical outcome')
    felt = from_field_manifest(field_manifest)
    felt = replace(felt, outcome_goal=desired_goal.strip())
    inquiry = investigate(felt)
    meta = {'status': 'NOT_CALLED'}
    if live_meta:
        if felt.evidence_split != 'train':
            raise EvidenceRefusal('Meta may only receive training-split evidence, never future outcomes')
        if not allow_billed_meta:
            raise EvidenceRefusal('Explicit --allow-billed-meta is required')
        meta = run_domain_research_council(felt, allow_billed_meta=True)
    return {
        'schema': SCHEMA, 'stage': 'AWAITING_DOMAIN_SPECIFIC_VALIDATED_DYNAMICS',
        'machine': felt.domain, 'machine_id': felt.system_id, 'desired_outcome': desired_goal,
        'origin': felt.dataset_origin,
        'inquiry': inquiry, 'meta_science_proposals': meta,
        'why_no_actuator_plan': ('No validated domain-specific outcome optimizer is linked to this '
            'field measurement; the investigation may suggest observations but cannot '
            'turn an F1, printer or turbine diagnosis into a safe control action.'),
        'recommended_next_step': inquiry['next_evidence_options'],
        'no_hardware_actuation': True, 'no_unverified_goal_completion_claim': True,
    }


def synthetic_demo(*, out: Path, seed: int = 31) -> dict:
    """Exercise the entire protocol with a simulator; labeled simulated everywhere."""
    rng=np.random.default_rng(seed)
    out.mkdir(parents=True, exist_ok=True)
    grid=np.linspace(.1,.9,21)
    # Intentionally missing load-dependent resonance offset + slope in base.
    model={'schema':MODEL_SCHEMA,'unit_support':'V','unit_tone':'Hz',
        'coef':[10.,23.], 'support_range_v':[0.,1.],
        'calibration':[{'support_v':float(x),'abs_residual_hz':.06} for x in np.linspace(0,1,15)],
        'origin':'simulation'}
    approved={'machine_id':'SIM-BEAM-01','approved_by':'SIMULATED_APPROVAL_NOT_HUMAN',
       'automatic_actuation':False,'support_positions_v':[float(x) for x in grid]}
    goal='Keep this beam away from the pump at 31 Hz by 5%, moving the support as little as possible.'
    def reality(x):
        return 23+10*x+2.0-3.0*(x-.5)
    sensation={'machine_id':'SIM-BEAM-01','support_v':.7,'unit_support':'V',
        'unit_tone':'Hz','observed_tone_hz':reality(.7),
        'sensor_sigma_hz':.015,'sensor_id':'SIM-SENSOR',
        'calibration_ref':'SIMULATED_CALIBRATION_NOT_REAL'}
    session=start(goal,model,approved,machine_id='SIM-BEAM-01',current_support_v=.7,
                  investigate=False,sensation=sensation)
    (out/'01_committed_experiments.json').write_text(json.dumps(session,indent=2))
    calibration={'machine_id':session['machine_id'],'unit_tone':'Hz','sensor_id':'SIMULATED-TONE-SENSOR',
        'measured_sigma_hz':.015,'calibration_method':'SIMULATED fixed noise model',
        'calibration_date_utc':'2026-11-02T00:00:00Z'}
    cal_path=out/'02_calibration_SIMULATED.json';cal_path.write_text(json.dumps(calibration,indent=2))
    csv_path=out/'02_separate_probe_results_SIMULATED.csv'
    with csv_path.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['experiment_id','split','support_v','tone_hz','unit_support','unit_tone'])
        writer.writeheader()
        for p in session['probe_plan']:
            writer.writerow({'experiment_id':p['experiment_id'],'split':p['split'],
              'support_v':p['support_v'],'tone_hz':round(reality(p['support_v'])+rng.normal(0,.012),8),
              'unit_support':'V','unit_tone':'Hz'})
    learned=learn(session,csv_path,cal_path)
    (out/'03_reoptimization_and_sealed_forecast.json').write_text(json.dumps(learned,indent=2))
    if learned['stage']!='AWAITING_FUTURE_OUTCOME':
        summary={'schema':SCHEMA,'origin':'simulation','stage':learned['stage'],
                 'reason':'No plan selected after synthetic measurements','verified':False}
    else:
        x=learned['forecast']['action_support_v']
        after={'experiment_id':'future_outcome_01','machine_id':session['machine_id'],
               'support_v':x,'unit_support':'V','unit_tone':'Hz',
               'measured_tone_hz':reality(x)+float(rng.normal(0,.012)),
               'calibration_sha256':learned['evidence']['calibration_sha256']}
        result_path=out/'04_future_outcome_revealed_SIMULATED.json'
        result_path.write_text(json.dumps(after,indent=2))
        summary=verify(learned,result_path)
        (out/'05_verified_result_SIMULATED.json').write_text(json.dumps(summary,indent=2))
    summary['ORIGIN']='SIMULATION_ONLY_NOT_REAL_MEASUREMENTS_NOT_META_INFERENCE'
    (out/'REPORT_SIMULATED.json').write_text(json.dumps(summary,indent=2))
    return summary


def main(argv=None) -> int:
    ap=argparse.ArgumentParser(description='v0.31 review-only staged goal → inquiry → learning → reoptimization → prospective verification')
    sub=ap.add_subparsers(dest='command',required=True)
    demo=sub.add_parser('synthetic-demo');demo.add_argument('--out',type=Path,default=Path('demo/outcome_loop_v031'));demo.add_argument('--seed',type=int,default=31)
    st=sub.add_parser('start');st.add_argument('--goal',required=True);st.add_argument('--model',type=Path,required=True)
    st.add_argument('--approved-settings',type=Path,required=True);st.add_argument('--machine-id',required=True)
    st.add_argument('--current-support-v',type=float,required=True);st.add_argument('--investigate',action='store_true')
    st.add_argument('--sensation',type=Path,help='Optional calibrated current-state sensation JSON; triggers investigation on surprise')
    st.add_argument('--out',type=Path,required=True)
    learn_p=sub.add_parser('learn');learn_p.add_argument('--session',type=Path,required=True)
    learn_p.add_argument('--probes',type=Path,required=True);learn_p.add_argument('--calibration',type=Path,required=True)
    learn_p.add_argument('--out',type=Path,required=True)
    learn_p.add_argument('--live-meta',action='store_true',help='Explicit paid, training-only Muse proposal')
    learn_p.add_argument('--allow-billed-meta',action='store_true')
    exported=sub.add_parser('export-beam-model')
    exported.add_argument('--tone-points-npz',type=Path,required=True)
    exported.add_argument('--out',type=Path,required=True)
    domain=sub.add_parser('domain-inquiry');domain.add_argument('--field-manifest',type=Path,required=True)
    domain.add_argument('--goal',required=True);domain.add_argument('--live-meta',action='store_true')
    domain.add_argument('--allow-billed-meta',action='store_true');domain.add_argument('--out',type=Path,required=True)
    check=sub.add_parser('verify');check.add_argument('--session',type=Path,required=True)
    check.add_argument('--future-measurement',type=Path,required=True);check.add_argument('--out',type=Path,required=True)
    args=ap.parse_args(argv)
    try:
        if args.command=='synthetic-demo':
            result=synthetic_demo(out=args.out,seed=args.seed)
        elif args.command=='export-beam-model':
            result=export_beam_model(args.tone_points_npz)
        elif args.command=='domain-inquiry':
            result=domain_inquiry(args.field_manifest,desired_goal=args.goal,
              live_meta=args.live_meta,allow_billed_meta=args.allow_billed_meta)
        elif args.command=='start':
            result=start(args.goal,_read_json(args.model),_read_json(args.approved_settings),
              machine_id=args.machine_id,current_support_v=args.current_support_v,investigate=args.investigate,
              sensation=_read_json(args.sensation) if args.sensation else None)
        elif args.command=='learn':
            result=learn(_read_json(args.session),args.probes,args.calibration,
                live_meta=args.live_meta,allow_billed_meta=args.allow_billed_meta)
        else:
            result=verify(_read_json(args.session),args.future_measurement)
        if args.command!='synthetic-demo':
            args.out.parent.mkdir(parents=True,exist_ok=True)
            args.out.write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf8')
        print(json.dumps({'status':result.get('stage'), 'origin':result.get('origin'),
           'result':str(args.out),'no_automatic_hardware_actuation':True},indent=2))
        return 0
    except (EvidenceRefusal,KeyError,TypeError,ValueError,FileNotFoundError,json.JSONDecodeError) as e:
        print(json.dumps({'status':'ABSTAIN_INVALID_OR_INSUFFICIENT_EVIDENCE',
              'error_type':type(e).__name__, 'error':str(e)[:500], 'no_hardware_actuation':True}))
        return 2


if __name__=='__main__':
    raise SystemExit(main())
