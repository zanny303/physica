"""Prospective Bayesian information gain for a small hypothesis family.

Full Monte Carlo EIG for scalar *measured summaries* of a physical response.
Unlike mean-separation heuristics, accounts for priors, predictive variances,
noise, overlap, and possibility of non-identifying probes. Controlled candidate
set only. Target-transfer usefulness weighted separately from local EIG.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import pi
import numpy as np
from scipy.special import logsumexp

@dataclass(frozen=True)
class CandidateAction:
    action_id: str
    predicted_summary: dict[str,float]
    predicted_sigma: dict[str,float]
    risk:float
    cost:float
    reversible:bool=True
    supervisor_approved:bool=True
    transfer_gain:float=0.
    def __post_init__(self):
        if not self.action_id or set(self.predicted_summary)!=set(self.predicted_sigma) or len(self.predicted_summary)<2:
            raise ValueError('complete distinct candidate predictions required')
        vals=[*self.predicted_summary.values(),*self.predicted_sigma.values(),
              self.risk,self.cost,self.transfer_gain]
        if not np.all(np.isfinite(vals)) or any(v<=0 for v in self.predicted_sigma.values()) or not 0<=self.risk<=1 or self.cost<0 or self.transfer_gain<0:
            raise ValueError('invalid candidate numerical inputs')


def information_gain(priors,action:CandidateAction,*,seed=0,samples=4096):
    if set(priors)!=set(action.predicted_summary) or any(not np.isfinite(p) or p<=0 for p in priors.values()):
        raise ValueError('nonzero finite priors over same hypotheses required')
    if samples<100 or samples>100000:raise ValueError('sample range 100..100000')
    names=list(priors)
    p=np.asarray([priors[n] for n in names],dtype=float);p/=p.sum()
    mu=np.array([action.predicted_summary[n] for n in names]);sig=np.array([action.predicted_sigma[n] for n in names])
    rng=np.random.default_rng(seed)
    states=rng.choice(len(names),size=samples,p=p)
    y=mu[states]+sig[states]*rng.normal(size=samples)
    loglik=-.5*((y[:,None]-mu[None,:])/sig[None,:])**2 -np.log(sig[None,:]*np.sqrt(2*pi))
    log_joint=loglik+np.log(p)[None,:]
    log_p_y=logsumexp(log_joint,axis=1)
    # Expected KL(posterior || prior) = E_{H,y} log p(y|H)/p(y).
    eig=float(np.mean(loglik[np.arange(samples),states]-log_p_y))
    return float(np.clip(eig,0,np.log(len(names))+1e-9))


def rank_eig(priors, actions,*,max_risk=.15,max_cost=float('inf'),
             risk_weight=1.,cost_weight=.1,transfer_weight=1.,samples=4096,seed=123):
    vals=[max_risk,max_cost,risk_weight,cost_weight,transfer_weight]
    if any(np.isnan(v) or v<0 for v in vals) or max_risk>1:
        raise ValueError('nonfinite policy or bad risk threshold')
    if any(not np.isfinite(v) for v in vals if v!=float('inf')):raise ValueError('nonfinite policy')
    if not actions or len({a.action_id for a in actions})!=len(actions):raise ValueError('unique actions required')
    rows=[]
    for i,a in enumerate(actions):
        if not a.reversible or not a.supervisor_approved or a.risk>max_risk or a.cost>max_cost:
            rows.append({'action_id':a.action_id,'status':'refuse_safety'});continue
        eig=information_gain(priors,a,seed=seed+i,samples=samples)
        # Transfer gain is a pre-declared expected cross-target value; not measured benefit.
        utility=eig+transfer_weight*a.transfer_gain-risk_weight*a.risk-cost_weight*a.cost
        rows.append({'action_id':a.action_id,'status':'eligible',
                     'expected_information_gain_nats':eig,
                     'prospective_transfer_gain':a.transfer_gain,'utility':float(utility)})
    ok=[r for r in rows if r['status']=='eligible']
    winner=max(ok,key=lambda r:(r['utility'],r['action_id'])) if ok else None
    return {'status':'choose_supervised_experiment' if winner else 'stop_no_safe_probe',
            'chosen_action_id':winner['action_id'] if winner else None,
            'ranking':sorted(rows,key=lambda r:r.get('utility',float('-inf')),reverse=True),
            'interpretation':'Monte Carlo EIG on preregistered scalar response summary; conditional on candidate set and measurement model',
            'hardware_actuation_allowed':False}
