"""Type a change. Muse reads what you want, code runs experiments on a map of a real beam, each forecast is sealed and then tested on real moments it didn't learn from, and the winner becomes a machine file. Nothing is sent to a machine."""
from __future__ import annotations

import json
import re

import numpy as np

from physica import config, seal as _seal
from physica.llm import meta_client as mc
from physica.outcome.compile import gcode

RES = config.REPO_ROOT / "eval" / "results"
OUT = RES / "E37_goal_box.json"
EXAMPLE = "A motor beside this beam now runs at 60 Hz. Keep the beam's tone at least 5% away from it, and move the support as little as possible. The support is at 90 mm."
ASK = """A person typed this about a real steel beam whose tone changes as a support slides along it:
"{goal}"
Pull out what they want. Use only numbers they gave. Use null for anything they didn't say.
Reply as JSON: {{"motor_hz": <number or null>, "margin_pct": <number or null>, "start_mm": <number or null>, "aim": "smallest_move" or "most_clearance", "firmware": "klipper" or "grbl", "not_possible_here": "<anything they asked for that moving this beam's support can't do, or empty>"}}"""
SHAPE = {"title": "Goal", "type": "object", "properties": {"motor_hz": {"type": ["number", "null"]}, "margin_pct": {"type": ["number", "null"]}, "start_mm": {"type": ["number", "null"]}, "aim": {"type": "string"}, "firmware": {"type": "string"}, "not_possible_here": {"type": "string"}}, "required": ["motor_hz", "margin_pct", "start_mm", "aim", "firmware", "not_possible_here"]}
WRITE = """Write {firmware} G-code for this one move. A person reviews it before anything runs.
The support is at {start} mm. Move it to {to} mm, then pause 1.5 s so the tone can be measured.
{rules}
Reply as JSON: {{"file": "<the complete file>", "why": "<one sentence: which measured number decided this move>"}}"""
RULES = {"klipper": "Use only MANUAL_STEPPER STEPPER=support lines (ENABLE=1, SET_POSITION to the start, one MOVE with SPEED=5 ACCEL=50), G4 pauses in ms, and ; comments.",
         "grbl": "Use only G21 G90, G92 X to the start, one G1 X with F300, G4 P1.5, M2, and ( ) comments."}


def data() -> tuple[np.ndarray, np.ndarray]:
    a = json.loads((RES / "E16_series.json").read_text())["A"]
    mm, hz = np.array(a["truth_mm"], float), np.array(a["tone_hz"], float)
    keep = np.isfinite(mm) & np.isfinite(hz)
    return mm[keep], hz[keep]


ASK_DRONE = """A person typed this about a drone inspecting a wind turbine blade:
"{goal}"
Pull out what they want. Use only numbers they gave. Use null for anything they didn't say.
Reply as JSON: {{"standoff_m": <distance from the blade, or null>, "photo_every_m": <or null>, "hub_m": <hub height, or null>, "blade_m": <blade length, or null>}}"""


def is_drone(goal: str) -> bool:
    return bool(re.search(r"\b(drone|mission|waypoints?|inspect\w*|fly|flight)\b", goal.lower()))


def read_drone(goal: str, on_step=print) -> dict:
    said = re.findall(r"\d+(?:\.\d+)?", goal)
    if not mc.is_mock():
        from physica.meta import scout as SC
        r = mc.respond("spark", [{"role": "user", "content": [{"type": "input_text", "text": ASK_DRONE.format(goal=goal)}]}], "physica_goal_box_drone", effort="low", schema={"title": "Drone", "type": "object", "properties": {k: {"type": ["number", "null"]} for k in ("standoff_m", "photo_every_m", "hub_m", "blade_m")}, "required": ["standoff_m", "photo_every_m", "hub_m", "blade_m"]})
        got = SC.parse_json(r["content"])
        for k, v in list(got.items()):
            if v is not None and not any(abs(float(n) - float(v)) < 1e-6 for n in said):
                on_step(f"Muse gave {k} = {v}, which isn't in what you typed, so it was dropped.")
                got[k] = None
        got["read_by"] = "Muse Spark, live"
    else:
        low = goal.lower()

        def near(pat):
            m = re.search(pat, low)
            return float(m.group(1)) if m else None
        got = {"standoff_m": near(r"(\d+(?:\.\d+)?)\s*(?:m|metres?|meters?)\s*(?:away|from|stand)"), "photo_every_m": near(r"every\s*(\d+(?:\.\d+)?)"), "hub_m": near(r"(\d+(?:\.\d+)?)\s*(?:m|metres?|meters?)?\s*(?:hub|tower)"), "blade_m": near(r"(\d+(?:\.\d+)?)\s*(?:m|metres?|meters?)?\s*blade"), "read_by": "small parser, because Muse isn't connected"}
    for k, v in (("standoff_m", 12.0), ("photo_every_m", 4.0), ("hub_m", 60.0), ("blade_m", 30.0)):
        got[k] = float(got[k]) if got.get(k) is not None else v
    return got


def run_drone(goal: str, on_step=print) -> dict:
    from physica.act.turbine import inspection_mission
    from physica.outcome import check, speak as K
    want = read_drone(goal, on_step)
    out = {"kind": "drone", "goal": goal, "understood": want, "label": "A REAL ARDUPILOT MISSION FILE. Nothing was sent to a drone"}
    if want["photo_every_m"] <= 0 or want["blade_m"] <= 0:
        return {**out, "status": "REFUSED", "why": "the photo spacing and blade length must be above zero"}
    if want["blade_m"] >= want["hub_m"] - 6:
        return {**out, "status": "REFUSED", "why": "that blade would reach too close to the ground for this hub height"}
    try:
        w = inspection_mission(56.2, 9.5, 90.0, want["hub_m"], want["blade_m"], standoff_m=want["standoff_m"], step_m=want["photo_every_m"])
    except ValueError as e:
        return {**out, "status": "REFUSED", "why": str(e).replace("refused: ", "")}
    def checked(text):
        got = K.check_drone(text, K.records()["drone"], want["hub_m"], want["blade_m"], want["photo_every_m"])
        for c in got:
            m = re.search(r"closest ([\d.]+) m", c["detail"])
            if m:
                got.append({"check": f"keeps the {want['standoff_m']:g} m you asked for", "ok": float(m.group(1)) >= want["standoff_m"] - 1, "detail": c["detail"]})
                break
        return got
    written, rounds, first_failed = "mission code", 1, []
    if not mc.is_mock():
        from physica.meta import scout as SC
        row = w.splitlines()[1].split()
        prompt = K.PROMPT.format(goal=goal, felt=json.dumps({"launch_point": {"lat": row[8], "lon": row[9]}, "tower": {"lat": 56.2, "lon": 9.5}, "hub_height_m": want["hub_m"], "blade_m": want["blade_m"], "blade": "parked straight down from the hub", "standoff_m": want["standoff_m"], "photo_every_m": want["photo_every_m"], "first_photo_altitude_m": want["hub_m"] - 1.5, "last_photo_altitude_m": max(want["hub_m"] - 1.5 - want["blade_m"], 5.0)}), language="ArduPilot mission (QGC WPL 110)", rules="\n".join("- " + x for x in ("First line QGC WPL 110, then tab-separated rows: index current frame command p1 p2 p3 p4 lat lon alt autocontinue", "Row 0 is home at the launch point, altitude 0", "Commands 22 takeoff, 16 waypoint, 203 photo, 21 land only", "Stay above the launch point the whole flight. Climb, then a 16 and a 203 at each photo altitude from first to last, then 21 land")))
        prev = None
        for n in range(1, 4):
            r = mc.respond("spark", [{"role": "user", "content": [{"type": "input_text", "text": prompt}]}], "physica_goal_box_drone_write", previous_response_id=prev, effort="low", schema=K.ANSWER)
            prev = r.get("response_id") or prev
            try:
                text = str(SC.parse_json(r["content"]).get("file") or "")
            except Exception:
                text = ""
            got = checked(text)
            failed = [c for c in got if not c["ok"]]
            if n == 1:
                first_failed = [c["check"] for c in failed]
            on_step(f"Muse's mission, round {n}: " + ("every check passed" if not failed else f"{len(failed)} failed"))
            rounds = n
            if not failed:
                w, written = text, "Muse Spark, live"
                break
            prompt = "That mission failed these checks. Send the complete file again as the same JSON.\n" + "\n".join(f"- {c['check']}: {c['detail']}" for c in failed)
        else:
            written = "mission code, because Muse's mission kept failing the checks"
    checks = checked(w)
    bad = [c for c in checks if not c["ok"]]
    out["machine_file"] = {"file": w, "written_by": written, "rounds": rounds, "first_failed": first_failed, "checks": checks}
    if bad:
        return {**out, "status": "REFUSED", "why": "the mission failed its checks: " + "; ".join(c["check"] for c in bad)}
    return {**out, "status": "WRITTEN"}


def read_goal(goal: str, on_step=print) -> dict:
    """Muse reads it if it's connected, and a small parser if not. Either way, code checks that each number really is in what was typed."""
    live = not mc.is_mock()
    if live:
        from physica.meta import scout as SC
        r = mc.respond("spark", [{"role": "user", "content": [{"type": "input_text", "text": ASK.format(goal=goal)}]}], "physica_goal_box_read", effort="low", schema=SHAPE)
        got = SC.parse_json(r["content"])
        said = re.findall(r"\d+(?:\.\d+)?", goal)
        for k in ("motor_hz", "margin_pct", "start_mm"):
            if got.get(k) is not None and not any(abs(float(n) - float(got[k])) < 1e-6 for n in said):
                on_step(f"Muse gave {k} = {got[k]}, which isn't in what you typed, so it was dropped.")
                got[k] = None
        got["read_by"] = "Muse Spark, live"
    else:
        low = goal.lower()
        hz = re.search(r"(\d+(?:\.\d+)?)\s*hz", low)
        pct = re.search(r"(\d+(?:\.\d+)?)\s*(?:%|percent)", low)
        mm = re.search(r"(\d+(?:\.\d+)?)\s*mm", low)
        got = {"motor_hz": float(hz.group(1)) if hz else None, "margin_pct": float(pct.group(1)) if pct else None, "start_mm": float(mm.group(1)) if mm else None,
               "aim": "most_clearance" if re.search(r"as far|most clearance|maximum clearance|furthest", low) else "smallest_move", "firmware": "grbl" if "grbl" in low else "klipper", "not_possible_here": "", "read_by": "small parser, because Muse isn't connected"}
    got["aim"] = "most_clearance" if got.get("aim") == "most_clearance" else "smallest_move"
    got["firmware"] = "grbl" if got.get("firmware") == "grbl" else "klipper"
    return got


def experiments(want: dict, bin_mm: float = 2.0) -> dict:
    """Learns from the first half of a real recording. Tries every place the support could go. The best are sealed, then tested on the second half, one at a time, until one holds."""
    mm, hz = data()
    half = len(mm) // 2
    learn_mm, learn_hz, test_mm, test_hz = mm[:half], hz[:half], mm[half:], hz[half:]
    motor, margin, start = want["motor_hz"], want["margin_pct"] if want.get("margin_pct") is not None else 5.0, want.get("start_mm")
    low, high = motor * (1 - margin / 100), motor * (1 + margin / 100)
    edges = np.arange(np.floor(learn_mm.min()), learn_mm.max() + bin_mm, bin_mm)
    tried, clear = [], []
    for a in edges:
        here = (learn_mm >= a) & (learn_mm < a + bin_mm)
        if here.sum() < 3:
            continue
        tones = learn_hz[here]
        centre, spread = float(np.median(tones)), max(float(1.4826 * np.median(np.abs(tones - np.median(tones)))), .15)
        row = {"mm": round(float(a + bin_mm / 2), 1), "forecast_hz": round(centre, 2), "band": [round(centre - 2 * spread, 2), round(centre + 2 * spread, 2)], "moments": int(here.sum())}
        row["clear"] = row["band"][1] < low or row["band"][0] > high
        tried.append(row)
        if row["clear"]:
            clear.append(row)
    if not tried:
        return {"status": "REFUSED", "why": "no place on this beam has enough measurements"}
    if start is None:
        start = float(np.median(mm))
    if want["aim"] == "most_clearance":
        clear.sort(key=lambda r: -min(abs(r["forecast_hz"] - low), abs(r["forecast_hz"] - high)))
    else:
        clear.sort(key=lambda r: abs(r["mm"] - start))
    out = {"motor_hz": motor, "margin_pct": margin, "danger": [round(low, 2), round(high, 2)], "start_mm": round(float(start), 1), "learned_moments": int(half), "tried": tried, "places_tried": len(tried), "places_clear": len(clear), "aim": want["aim"], "tests": []}
    if not clear:
        return {**out, "status": "REFUSED", "why": f"nowhere the support can go keeps the tone clear of {low:.1f} to {high:.1f} Hz"}
    for row in clear[:8]:
        near = np.abs(test_mm - row["mm"]) <= bin_mm
        s = _seal.seal({"support_mm": row["mm"], "tone_hz": row["band"]}, "the beam's tone with the support here, before it's tested on unseen moments")
        if near.sum() < 3:
            out["tests"].append({**row, "anchor": s["anchor"], "result": "no real moments to test it on, so it isn't used", "held": False})
            continue
        measured = test_hz[near]
        inside = float(((measured < low) | (measured > high)).mean())
        held = inside >= .9
        out["tests"].append({**row, "anchor": s["anchor"], "real_moments": int(near.sum()), "measured_hz": round(float(np.median(measured)), 2), "share_clear": round(inside, 2), "held": held, "result": f"{inside:.0%} of {int(near.sum())} real moments stayed clear"})
        if held:
            return {**out, "status": "FOUND", "best": out["tests"][-1], "move_mm": round(abs(row["mm"] - start), 1), "already_fine": abs(row["mm"] - start) <= bin_mm}
    return {**out, "status": "REFUSED", "why": "every forecast that looked clear failed on the real moments, so no file was written"}


def check_file(text: str, firmware: str, start: float, to: float) -> list[dict]:
    def c(name, ok, detail=""):
        return {"check": name, "ok": bool(ok), "detail": detail}
    if firmware == "grbl":
        rows = [re.sub(r"\(.*?\)", "", ln).strip() for ln in text.splitlines()]
        rows = [r for r in rows if r]
        odd = [r for r in rows if not re.fullmatch(r"(G21 G90|G21|G90|G92 X-?[\d.]+|G1 X-?[\d.]+ F[\d.]+|G4 P[\d.]+|M2)", r)]
        moves = [float(m.group(1)) for r in rows if (m := re.fullmatch(r"G1 X(-?[\d.]+) F[\d.]+", r))]
        sets = [float(m.group(1)) for r in rows if (m := re.fullmatch(r"G92 X(-?[\d.]+)", r))]
        feed = [float(m.group(1)) for r in rows if (m := re.search(r"\bF([\d.]+)", r))]
        fast = bool(feed and max(feed) > 600)
    else:
        rows = [ln.split(";")[0].strip() for ln in text.splitlines()]
        rows = [r for r in rows if r]
        odd = [r for r in rows if not re.fullmatch(r"(MANUAL_STEPPER\s+STEPPER=support(\s+[A-Z_]+=[-\d.]+)+|G4\s+P\d+)", r)]
        moves = [float(m.group(1)) for r in rows if (m := re.search(r"\bMOVE=(-?[\d.]+)", r))]
        sets = [float(m.group(1)) for r in rows if (m := re.search(r"SET_POSITION=(-?[\d.]+)", r))]
        speed = [float(m.group(1)) for r in rows if (m := re.search(r"SPEED=([\d.]+)", r))]
        fast = bool(speed and max(speed) > 10)
    return [c("only allowed commands", not odd, "; ".join(odd[:3])), c("exactly one move", len(moves) == 1, f"{len(moves)} moves"),
            c("starts from where the support is", len(sets) == 1 and abs(sets[0] - start) < .06, str(sets)),
            c("moves to the place the experiments chose", len(moves) == 1 and abs(moves[0] - to) < .06, str(moves)),
            c("within the speed limit", not fast, ""), c("pauses so the tone can be measured", any(r.startswith("G4") for r in rows), "")]


def write_file(plan: dict, firmware: str, on_step=print) -> dict:
    start, to = plan["start_mm"], plan["best"]["mm"]
    anchor = plan["best"]["anchor"]
    if mc.is_mock():
        text = gcode.grbl_move(start, to, anchor) if firmware == "grbl" else gcode.klipper_move(start, to, anchor)
        return {"file": text, "written_by": "code, because Muse isn't connected", "rounds": 1, "checks": check_file(text, firmware, start, to), "first_failed": []}
    from physica.meta import scout as SC
    prompt, prev, first_failed = WRITE.format(firmware=firmware, start=start, to=to, rules=RULES[firmware]), None, []
    for n in range(1, 4):
        r = mc.respond("spark", [{"role": "user", "content": [{"type": "input_text", "text": prompt}]}], "physica_goal_box_write", previous_response_id=prev, effort="low", schema={"title": "MachineFile", "type": "object", "properties": {"file": {"type": "string"}, "why": {"type": "string"}}, "required": ["file", "why"]})
        prev = r.get("response_id") or prev
        try:
            said = SC.parse_json(r["content"])
        except Exception:
            said = {}
        text = str(said.get("file") or "")
        checks = check_file(text, firmware, start, to)
        bad = [c for c in checks if not c["ok"]]
        if n == 1:
            first_failed = [c["check"] for c in bad]
        on_step(f"Muse's file, round {n}: " + ("every check passed" if not bad else f"{len(bad)} failed"))
        if not bad:
            return {"file": text, "why": said.get("why"), "written_by": "Muse Spark, live", "rounds": n, "checks": checks, "first_failed": first_failed}
        prompt = "That file failed these checks. Send the complete file again as the same JSON.\n" + "\n".join(f"- {c['check']}: {c['detail']}" for c in bad)
    return {"file": None, "written_by": "Muse Spark, live", "rounds": 3, "checks": checks, "first_failed": first_failed, "failed": True}


def run(goal: str, on_step=print) -> dict:
    goal = str(goal or "").strip()[:600]
    if len(goal) < 5:
        raise ValueError("Type what you want changed, like: a motor beside this beam now runs at 60 Hz")
    if is_drone(goal):
        return run_drone(goal, on_step)
    want = read_goal(goal, on_step)
    out = {"goal": goal, "understood": want, "label": "REAL RECORDING OF A LAB BEAM (DROPBEAR). Nothing was sent to a machine"}
    if want.get("motor_hz") is None:
        return {**out, "status": "ASK", "why": "Say what frequency to keep the beam away from, like: a motor runs at 60 Hz"}
    plan = experiments(want)
    out["experiments"] = {k: v for k, v in plan.items() if k != "tried"}
    out["tried"] = plan.get("tried", [])
    if plan["status"] != "FOUND":
        return {**out, "status": "REFUSED", "why": plan["why"]}
    if plan.get("already_fine"):
        return {**out, "status": "NO_CHANGE", "why": f"the support is already somewhere that stays clear of the motor, so no move or file is needed. Real moments there measured {plan['best']['measured_hz']} Hz"}
    f = write_file(plan, want["firmware"], on_step)
    out["machine_file"] = f
    out["firmware"] = want["firmware"]
    if not f.get("file"):
        return {**out, "status": "REFUSED", "why": "Muse's file kept failing the checks, so no file was written"}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    out["status"] = "WRITTEN"
    if not mc.is_mock():
        OUT.write_text(json.dumps(out, indent=1, default=float))
    return out


if __name__ == "__main__":
    r = run(EXAMPLE)
    e = r.get("experiments", {})
    print(f"Understood by: {r['understood'].get('read_by')}")
    for t in e.get("tests", []):
        print(f"  {t['mm']} mm, forecast {t['forecast_hz']} Hz: {'held' if t['held'] else 'failed'}, {t['result']}")
    print(r["status"], r.get("why") or "")
    if r.get("machine_file"):
        print(f"Written by {r['machine_file']['written_by']}:\n{r['machine_file']['file']}")
    if r["status"] != "WRITTEN":
        raise SystemExit(1)
