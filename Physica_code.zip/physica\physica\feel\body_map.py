"""Body map: a machine learns where its own parts are from what it causes itself, then says WHERE a feeling comes from.

Why: on a quadcopter, "which rotor is damaged?" can't be answered by loudness. The flight controller spreads a
fault across all rotors, and vibration travels through the whole frame. The strongest-shaking arm was the damaged
one in only 45% of felt windows (E8).

The idea (inspired by how infants build a body map from self-touch): in healthy flight each rotor spins at a
slightly different speed, so each rotor's own vibration line can be told apart. At that line, the 12 sensor channels
(4 arms x 3 axes) move in a fixed pattern set by where that rotor sits on the frame. That pattern, the principal
eigenvector of the cross-spectral matrix, is the rotor's FINGERPRINT. It is learned from healthy flight only.

A damaged propeller adds a once-per-turn force at the same hub, so the felt line moves the frame in the same
pattern. Physica takes the felt line's pattern and asks which rotor's fingerprint it matches.
It needs no damage data, no motor-speed telemetry and no model of the drone.

Honest "can't tell": two rotors whose fingerprints overlap (judged from healthy data alone, before any fault) are
reported together ("B or D"), not guessed between.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.signal import get_window


@dataclass
class BodyMap:
    unit_names: list = field(default_factory=lambda: list("ABCD"))
    win_s: float = 5.0
    nperseg: int = 1024
    min_sep_bins: int = 3      # a rotor's line is used only if it is clearly apart from the other rotors' lines
    set_overlap: float = 0.5   # fingerprints this similar (|<a,b>|^2) are reported together
    fs: float | None = None
    band: tuple | None = None
    fingerprints: np.ndarray | None = None  # (units, channels) complex
    used: list | None = None

    # ---- shared machinery ----
    def stft(self, acc: np.ndarray, fs: float) -> list[np.ndarray]:
        """acc (N, units, axes) -> one array (segments, freqs, channels) per window."""
        x = acc.reshape(acc.shape[0], -1)
        W, hop = int(self.win_s * fs), self.nperseg // 2
        w = get_window("hann", self.nperseg)
        out = []
        for i in range(x.shape[0] // W):
            seg = x[i * W:(i + 1) * W] - x[i * W:(i + 1) * W].mean(0)
            out.append(np.array([np.fft.rfft(seg[s:s + self.nperseg] * w[:, None], axis=0)
                                 for s in range(0, W - self.nperseg + 1, hop)]))
        return out

    def freqs(self, fs: float) -> np.ndarray:
        return np.fft.rfftfreq(self.nperseg, 1 / fs)

    @staticmethod
    def pattern(S: np.ndarray, k: int) -> np.ndarray:
        """How the whole frame moves at bin k: principal eigenvector of the cross-spectral matrix (k-1..k+1)."""
        X = S[:, max(k - 1, 0):k + 2, :].reshape(-1, S.shape[-1])
        C = X.T @ X.conj() / len(X)
        return np.linalg.eigh(C)[1][:, -1]

    def _unit_lines(self, S: np.ndarray, f: np.ndarray) -> np.ndarray:
        n_units = len(self.unit_names)
        P = (np.abs(S) ** 2).mean(0).reshape(len(f), n_units, -1).sum(-1)
        idx = np.where((f >= self.band[0]) & (f <= self.band[1]))[0]
        return idx[np.argmax(P[idx], axis=0)]

    # ---- learning the body map (healthy data only) ----
    def fit(self, acc: np.ndarray, fs: float, band: tuple, windows_idx=None) -> "BodyMap":
        self.fs, self.band = float(fs), tuple(band)
        f = self.freqs(fs)
        S_all = self.stft(acc, fs)
        idx = range(len(S_all)) if windows_idx is None else windows_idx
        n_units, n_ch = len(self.unit_names), S_all[0].shape[-1]
        M = np.zeros((n_units, n_ch, n_ch), complex)
        used = np.zeros(n_units, int)
        for i in idx:
            ks = self._unit_lines(S_all[i], f)
            for a in range(n_units):
                if all(abs(ks[a] - ks[b]) >= self.min_sep_bins for b in range(n_units) if b != a):
                    v = self.pattern(S_all[i], int(ks[a]))
                    M[a] += np.outer(v, v.conj())
                    used[a] += 1
        if (used == 0).any():
            raise ValueError(f"no healthy window separates unit(s) {[u for u, n in zip(self.unit_names, used) if n == 0]}")
        self.fingerprints = np.array([np.linalg.eigh(M[a])[1][:, -1] for a in range(n_units)])
        self.used = used.tolist()
        return self

    def overlap(self) -> np.ndarray:
        return np.abs(self.fingerprints.conj() @ self.fingerprints.T) ** 2

    # ---- attribution ----
    def attribute(self, S: np.ndarray, line_hz: float) -> dict:
        f = self.freqs(self.fs)
        k = int(np.argmin(np.abs(f - line_hz)))
        u = self.pattern(S, k)
        sc = np.abs(self.fingerprints.conj() @ u) ** 2
        best = int(np.argmax(sc))
        group = [b for b in range(len(sc)) if b == best or self.overlap()[best, b] > self.set_overlap]
        return {"best": self.unit_names[best], "scores": dict(zip(self.unit_names, np.round(sc, 3).tolist())),
                "answer": [self.unit_names[b] for b in group]}

    def strongest_line(self, S: np.ndarray) -> float:
        f = self.freqs(self.fs)
        m = (f >= self.band[0]) & (f <= self.band[1])
        P = (np.abs(S) ** 2).mean(0).sum(-1)
        return float(f[m][np.argmax(P[m])])

    # ---- storage ----
    def to_dict(self) -> dict:
        return {"unit_names": self.unit_names, "win_s": self.win_s, "nperseg": self.nperseg,
                "min_sep_bins": self.min_sep_bins, "set_overlap": self.set_overlap, "fs": self.fs,
                "band": list(self.band), "used": self.used,
                "fingerprints_re": self.fingerprints.real.round(6).tolist(),
                "fingerprints_im": self.fingerprints.imag.round(6).tolist()}

    @classmethod
    def from_dict(cls, d: dict) -> "BodyMap":
        b = cls(unit_names=d["unit_names"], win_s=d["win_s"], nperseg=d["nperseg"], min_sep_bins=d["min_sep_bins"],
                set_overlap=d["set_overlap"])
        b.fs, b.band, b.used = d["fs"], tuple(d["band"]), d["used"]
        b.fingerprints = np.array(d["fingerprints_re"]) + 1j * np.array(d["fingerprints_im"])
        return b
