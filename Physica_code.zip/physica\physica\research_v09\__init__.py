"""v0.9 research candidates: evidence-calibrated transfer and guarded sensing.

Provisional scientific methods; not demonstrated novel or real-world validated.
"""
