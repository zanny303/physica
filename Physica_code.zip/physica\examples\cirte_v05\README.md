# CIRTE v0.5 runnable examples

All files here are **synthetic or illustrative**. Never claim the mock Muse response, fake low-force probe, or local signatures are genuine experimental or Meta evidence.

From repository root:

```sh
pip install -e '.[dev]'
python -m physica.cli grammar cirte-benchmark --out examples/cirte_v05_benchmark.json
python examples/cirte_v05/BUILD_NATIVE_SIMULATION.py examples/cirte_v05/native_demo
python -m physica.cli grammar cirte-plan examples/cirte_v05/scientist_request.json --out /tmp/cirte_plan.json
pytest -q tests/test_cirte_v05.py
```

The native demo creates `A_mic_Pa.csv`, `A_signed_PEL.json`, `B_sealed_forecast.json`, `B_measured_after_commit.csv`, `B_signed_reveal.json`, `B_new_signed_PEL.json`, and equivalent C outputs. It records A's microphone **pressure**, not imaginary velocity. B and C are observed using camera **displacement**. Source and target body parameters are independently known *to this simulator*.

`grammar cirte-source`, `cirte-prepare`, `cirte-check`, and `cirte-learn-next` expose the same stages for real external CSVs. The native example’s B calibration/probe are synthetic, so do not present them as evidence of a hardware experiment.

For a real Meta test use `grammar cirte-meta-plan-live ... --allow-billed-meta`, never a mocked response. No API credentials are stored in the repo.
