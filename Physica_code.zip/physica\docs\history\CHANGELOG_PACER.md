# Physica v0.2 source update — 2026-10-30

**Origin:** merged into the actual user-uploaded `physica.zip` repository, *not* a separate clean-room replacement. Existing `physica/feel`, `physica/touch`, `physica/world`, `physica/translate`, `physica/library`, `physica/agents`, `eval`, `tests` and original evidence files are retained. The archived `.git` directory was excluded for a lightweight portable release; no source files were intentionally deleted.

## Added / changed

- `physica/experience/schema.py`: typed PEL PhysicalEpisode, calibrated sensors, SI/unit-bearing quantities, modes, hypotheses, actions, measured outcomes and provenance; JSON Schema export.
- `physica/experience/pacer.py`: modal innovations, Gaussian Bayesian updating, identifiability guard, quadrature EIG, action risk gate and analytical 1-DOF prior.
- `physica/experience/transfer.py`: dimensionless modal comparison; refuses mismatched calibration/boundaries/excitation/intervention; transfers cautiously weighted causal *priors* only from verified outcomes.
- `physica/experience/seal.py`: SHA256 + Ed25519 signing, signed reveal and tamper verification using original Physica key library.
- `physica/experience/store.py`: safe filename hashing, signed-reveal verification and verified-only physical experience search.
- `physica/experience/bridge.py`: converts original Physica video/CSV/NPY sensing into PEL without inventing intervention or physics ground truth.
- `physica/experience/meta.py`: constrained, explicitly mock/live Muse scientist reviewer, tool/action whitelisting and hashes.
- `physica/experience/consequence.py`: physically interpretable but assumption-driven coupon breakage *sandbox* with irreversible-action risk gate.
- `physica/experience/demo.py`, `ui.py`, `cli.py`: repeatable two-machine simulated teaching/verification demo, interactive offline presentation and `physica experience` commands.
- `tests/test_experience.py`: seven new tests for data validation, physical inference, safety, transfer/refusal, cryptographic tampering, end-to-end demo and counterfactual risk.
- `docs/PACER_PHYSICAL_LANGUAGE.md`, `HACKATHON_2026_SUBMISSION.md`, `META_PACER_INTEGRATION.md`, `REAL_WORLD_VALIDATION.md`: new protocol, science, submission, Meta status, hardware validation.
- `examples/experience/`: runnable generated synthetic outputs, signed commitment/reveal, compatibility records, demo UI and schema.
- `pyproject.toml`: version 0.2.0, explicit Pydantic v2 dependency.
- `physica/cli.py`: backward-compatible `experience` command delegation.

## Validation performed on this packaged version

- Automated new PACER tests: **7 passed**.
- Automated PACER + selected original suites (`test_act.py`, `test_product.py`): **13 passed total** (new included).
- The larger original test collection includes expensive modal/system-identification tests and did not finish before the execution timeout; do not interpret this as an overall passing test suite or a test failure.
- CLI smoke: `python -m physica.cli experience demo`, `experience schema`, `experience verify` and JSON artifacts generated successfully.
- A synthetic Machine A→B transfer and an illustrative bracket consequence were executed. No new *physical* validation or live Meta model inference was performed.

## Known limitations

- Full SAM 3.1, V-JEPA 2 and real-time Muse API integration/benchmarking remain unverified; existing Meta client supports configurable API calls but defaults to offline mock when unconfigured.
- An Ed25519 signature is not a third-party proof of observation chronology. Canonicalization is sorted-key JSON, not full RFC 8785 JCS.
- Modal comparisons rely on equal mode count and sorted frequency-mode correspondence; sophisticated mode tracking, source/target geometry matching and distribution-shift calibration are future work.
- New `experience ingest` records measured modal features from original `sense` but cannot automatically recover forces, certify real breakage or assign unique causes from passive observations.
- New PACER synthetic benchmark gives no basis for claiming general performance improvements across unfamiliar hardware.

## Quick start

```bash
python -m pip install -e ".[dev]"
python -m physica.cli experience demo --out demo
python -m physica.cli experience verify demo/sealed_before_observation.json
python -m physica.cli experience verify demo/revealed_consequence.json
python -m pytest tests/test_experience.py -q
```

Open `demo/experience_lab.html` in a browser. The original commands (`physica feel`, `physica sense`, `physica bank`, etc.) are unchanged.
