# v0.4.3 – Causal Discovery / Research Edition

Implements mechanism-identifiability-aware supervised probe design, calibrated Muse context weighting with no-effect-before-heldout-validation, WAV spectral and event timing ingest, chemical kinetics module, a strict embedding-to-SI readout with body-disjoint split conformal calibration, OOD abstention and leakage checks, 24/32 trial synthetic baseline, CLI commands and 14+ new tests. Preserves all v0.4.2 CRATE/CSG, field CSV, Meta adapter and original Physica functionality.

**Limitations:** No live Meta calls, V-JEPA weights, smell/taste instruments, physical robot actuation or new real A→B→C validation occurred. Existing synthetic knowledge transfer is not an established scientific breakthrough. The new research planner computes *signal separation*, not exact expected information gain, and its uncertainty guarantee is exchangeability-dependent.
