# v0.30 — Sentinel, industrial physical inquiry and final hackathon focus

- Added `physica.maintenance` package: typed, fail-closed per-machine time-series evaluation for contextual vibration residuals vs an RMS-only comparator.
- Uses separately identified training, independent normal-calibration, source-discovery, and blind test machines. Refuses overlapping groups, invalid observations, insufficient independent calibration and excessive operating-context shift.
- Preserves strict causal claim boundaries: no future sensor access, no fault label inference, no downtime prevented, no automatic hardware action.
- Adds verified-file hash, separated source-only Muse context and an optional 3-call Wonder → Spark → Wonder council, always producing unverified suggestions.
- Adds NASA IMS timestamped waveform feature extractor and XJTU-SY per-minute two-axis raw CSV importer, and merge-features utility.
- Adds `http://127.0.0.1:8765/sentinel` Studio interactive viewer for packaged synthetic data, with clearly visible evidence labels.
- Keeps all v0.29 modules; prior reliability fixes remain.
- Adds regression/evidence leakage tests, research guide, refreshed demo and README. Does NOT assert a new breakthrough or a real preventive-maintenance benefit.
