# Hardware and real-world validation: reproducible and safe

The new `experience_lab.html` is **not a substitute for real measurements**. Use it to rehearse the experience language and signed record protocol. The original project's `DATA.md` and `README.md` document public drone datasets, a lab beam, real guitar video and several simulation validations. No new hardware was used in this build.

## 1. Single guarded low-voltage fan → second guarded fan

Use two guarded USB or similarly low-voltage fans, stable tripods, and a phone on a rigid stand. Do not touch moving blades, add rotor weights or modify electrical wiring. A reversible external *stationary mount* stiffness change is a suitable low-risk perturbation. Record all settings, sensor orientation, frame rate, body geometry, mount class, temperature and control-input levels. Collect A baseline, A known mount change, B baseline, then B verification action. Use the same physical signal/units and excitation range and separate training/validation data.

* Before B acts: create a signed prediction and demonstrate the hash before opening the B outcome recording. Also have an externally trusted clock/witness for unambiguous chronology.
* Compare B with/without A's experience: number of safe probes to reach accurate diagnosis, calibration of posterior, false alarms and harm rate. Include deliberately incompatible mounting/excitation tests that must yield `refused`.
* The transfer layer is a **prior**, not a substitute for checking B locally.

## 2. Ruler + known hidden mass

Clamp a flexible metal strip, use a marked and repeated tap/deflection location, a high-frame-rate camera if available, and known calibration loads. Lock focus/exposure and document dimensions, clamp condition and actual frame timing. Film baseline, known-load calibration and blind load. Commit estimated interval before weighing/revealing, report errors and interval coverage on every run (including failures). Frequency shifts can reflect many causes; do not claim unique mass inversion without the calibration assumptions.

## 3. Sacrificial printed bracket (irreversible consequence)

Only use a small **non-structural**, intentionally disposable coupon in a shielded fixture with eye protection. No overhead or load-bearing household structures. Use documented print orientation/material and calibrated loads. First establish statistical fracture thresholds from several separate coupons, so the model has a real failure distribution. Only perform a destructive experiment under supervised, contained conditions. Use signed interval predictions and recorded actual failure loads; stop immediately for clamp slip/unexpected behavior. PACER's bundled bracket simulation assumes a failure mean of 10 N and SD of 1.5 N and must **not** be applied as hardware limit.

## 4. Meta model verification

Use real model keys (never ship in ZIP), audit request/response hashes and check model IDs and exact inference mode. SAM/V-JEPA are not connected to PEL in this archive. Reproduce improvements against the non-Meta baseline before attributing any gain.

## Minimum report

For every intervention include raw recording and SHA256; source/sensor calibration; environment; baseline and holdout; explicit hypotheses; action safety approval; sealed prediction and trusted chronology; measured consequence with uncertainty; errors including counterexamples; whether cross-machine comparability passed; and model mode (`live`, `mock`, `disabled`).
