"""CRATE closed-loop benchmark and offline hackathon evidence. SIMULATION ONLY."""
from __future__ import annotations
from dataclasses import replace
from pathlib import Path
from math import pi
import json, hashlib, html
import numpy as np
from .causal_transport import (trace, fit_memory, conformal_calibrate, twin_response,
                               rmse, select_safe_probe)
from .transport import BodyCalibration, compatibility
from .frontier_demo import _episode
from .seal import seal,reveal,verify_reveal,verify_seal,write_json
from .schema import Quantity


def body(i, rng, *, force=None):
    hz=float(rng.uniform(17.,24.))
    return BodyCalibration(f'SYNTH-BODY-{i:04d}','clamped_strip','calibrated_step_force',hz,
        float(rng.uniform(550.,1250.)),float(force if force is not None else rng.uniform(1.,2.)),
        (1.,2.1),(.032,.04),f'SYNTH-CAL-{i:04d}',True)


def true_response(t,c,latent,*,rng=None,sensor_sigma=0.0):
    """Simulated unmodelled elastic response plus per-machine variation.
    CRATE's mechanistic twin doesn't know these terms. This is a *favorable*
    shared-latent family for transfer and MUST NOT be used for generalisation claims.
    """
    tau=np.asarray(t)*c.fundamental_hz
    amp,phase,quirk=latent
    extra=(amp*np.exp(-.32*tau)*np.sin(2*pi*1.68*tau+phase)
           +quirk*np.exp(-.65*tau)*np.sin(2*pi*2.22*tau))
    signal=twin_response(t,c)+(c.applied_step_force_n/c.stiffness_n_per_m)*extra
    return signal if rng is None else signal+rng.normal(0,sensor_sigma,len(t))


def _record(i,rng):
    c=body(i,rng)
    lat=(float(rng.normal(.085,.010)), float(rng.normal(.0,.06)), float(rng.normal(.012,.008)))
    t=np.linspace(0,8/c.fundamental_hz,240)
    y=true_response(t,c,lat,rng=rng,sensor_sigma=7e-6)
    return (trace(c,t,y),lat)


def evaluate(*,seed=42,n_targets=24):
    if not 5<=n_targets<=200:raise ValueError('n_targets between 5 and 200')
    rng=np.random.default_rng(seed)
    observations=[_record(i,rng) for i in range(50+n_targets)]
    train=[x[0] for x in observations[:28]]
    cal=[x[0] for x in observations[28:50]]
    targets=observations[50:]
    mem=fit_memory(train)
    conformal=conformal_calibrate(train,cal,alpha=.10)
    q=conformal['q_dimensionless']
    if q is None:raise RuntimeError('not enough held-out calibration machines')
    rows=[]; first=None
    for i,(entry,lat) in enumerate(targets):
        c=entry.body
        t=np.asarray(entry.time_s)
        # a new, *low-force* probe is observed before a higher-force test;
        # test observations are created only AFTER the zero-shot forecasts.
        low=replace(c,applied_step_force_n=c.applied_step_force_n*.35)
        probe_y=true_response(t,low,lat,rng=rng,sensor_sigma=7e-6)
        local=trace(low,t,probe_y)
        pred0=mem.forecast(c,t,conformal_q=q,observation_noise_m=7e-6)
        pred1=mem.forecast(c,t,local_probe=local,conformal_q=q,observation_noise_m=7e-6)
        # Fairer baselines: calibrated mechanistic physics, nearest neighbor
        # normalized residual, and a no-transfer local low-force physics scaling.
        physical=twin_response(t,c)
        q_target=t*c.fundamental_hz
        norm_candidates=mem.residual_library
        source_cal=np.asarray([[float(s.body.fundamental_hz),float(s.body.stiffness_n_per_m)] for s in train])
        dist=np.linalg.norm((source_cal-np.array([c.fundamental_hz,c.stiffness_n_per_m]))/
                            np.array([8.,700.]),axis=1)
        nearest_idx=int(np.argmin(dist))
        nn=physical+np.interp(q_target,mem.grid_tau,norm_candidates[nearest_idx])*(c.applied_step_force_n/c.stiffness_n_per_m)
        local_only=np.asarray(probe_y)*c.applied_step_force_n/low.applied_step_force_n
        # Held-out target high-force consequence (not read during fit/calibration).
        actual=true_response(t,c,lat,rng=rng,sensor_sigma=7e-6)
        z0=np.asarray(pred0['displacement_m']);z1=np.asarray(pred1['displacement_m'])
        lo=np.asarray(pred0['lower_m']);hi=np.asarray(pred0['upper_m'])
        row={'target':c.machine_id,'mechanistic_rmse_m':rmse(physical,actual),
             'nearest_normalized_rmse_m':rmse(nn,actual),
             'local_only_rmse_m':rmse(local_only,actual),
             'crate_zero_shot_rmse_m':rmse(z0,actual),
             'crate_one_probe_rmse_m':rmse(z1,actual),
             'entire_waveform_inside_90pct_band':bool(np.all((actual>=lo)&(actual<=hi))),
             'pointwise_fraction_inside_band':float(np.mean((actual>=lo)&(actual<=hi)))}
        rows.append(row)
        if first is None:
            first={'machine':c, 'times':t, 'actual':actual, 'zero':z0,
                   'adapted':z1,'physics':physical,'nearest':nn,'local_only':local_only,
                   'low_probe':probe_y,'q':q, 'pred0':pred0, 'pred1':pred1}
    keys=[k for k in rows[0] if k.endswith('rmse_m')]
    summary={k:float(np.mean([x[k] for x in rows])) for k in keys}
    summary.update({'whole_trajectory_band_coverage':float(np.mean([x['entire_waveform_inside_90pct_band'] for x in rows])),
                    'mean_pointwise_band_coverage':float(np.mean([x['pointwise_fraction_inside_band'] for x in rows])),
                    'calibration_machines':len(cal),'training_machines':len(train),'holdout_target_machines':len(targets)})
    report={'evaluation':'SYNTHETIC_SIMULATION_ONLY','random_seed':seed,'description':'Leave-machine-out split; held-out test force after one lower-force probe',
            'metrics':summary,'conformal':conformal,'rows':rows,
            'notes':['Generator uses shared latent oscillatory residual; this is a favorable transfer setting.',
                     'Local-only baseline uses a complete low-force waveform; one probe does NOT mean one data point.',
                     'No Koopman baseline; no industry standard evaluation. Some baselines can outperform the proposed model.',
                     'Conformal bands calibrated on source-like held-out machines, with no domain-shift guarantee.',
                     'No SAM, Muse, V-JEPA or physical hardware ran in this benchmark.']}
    return report,first,mem,train


def _svg_lines(times,series):
    x=np.asarray(times); yy=np.concatenate([np.asarray(y) for _,y,_ in series]);lo=float(yy.min());hi=float(yy.max());
    scale=max(hi-lo,1e-8)
    fragments=[]
    for name,y,color in series:
        pts=' '.join(f'{40+940*(float(t)-x[0])/(x[-1]-x[0]):.2f},{275-230*(float(v)-lo)/scale:.2f}' for t,v in zip(x,y))
        fragments.append(f'<polyline fill="none" stroke="{color}" stroke-width="2.5" points="{pts}"/>')
    return ('<svg viewBox="0 0 1020 320" role="img" aria-label="Synthetic displacement forecast, baseline, and observation">'
            '<rect width="1020" height="320" rx="16" fill="#111a2c"/>'+''.join(fragments)+'</svg>')


def render_page(root,report,first,seal_valid,refused):
    m=report['metrics']; body=first['machine'];t=first['times'];
    svg=_svg_lines(t,[('actual',first['actual'],'#31d0ac'),('CRATE zero-shot',first['zero'],'#fbbf24'),
                      ('one local probe',first['adapted'],'#a78bfa'),('mechanistic twin',first['physics'],'#64748b')])
    metrics=''.join(f'<div class="metric"><small>{html.escape(k.replace("_"," "))}</small><b>{v*1000:.4f} mm</b></div>'
                    for k,v in m.items() if k.endswith('rmse_m'))
    rows=''.join(f'<tr><td>{html.escape(r["target"])}</td><td>{r["mechanistic_rmse_m"]*1000:.3f}</td><td>{r["crate_zero_shot_rmse_m"]*1000:.3f}</td><td>{r["crate_one_probe_rmse_m"]*1000:.3f}</td></tr>' for r in report['rows'])
    page=f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PHYSICA — Physical Experience Lab v0.4</title><style>
:root{{background:#0b1120;color:#e5edf8;font-family:Inter,ui-sans-serif,system-ui,sans-serif}}*{{box-sizing:border-box}}body{{margin:0}}
main{{max-width:1120px;margin:auto;padding:40px 22px 90px}}h1{{font-size:clamp(42px,6vw,76px);letter-spacing:-.07em;margin:14px 0}}
.tag{{font-size:12px;letter-spacing:.15em;color:#77ead2;font-weight:800}}h2{{margin:30px 0 16px;font-size:25px}}p,li{{color:#a7b7cc;line-height:1.65}}
.panel{{background:#111a2c;border:1px solid #24314d;border-radius:19px;padding:24px;margin:22px 0}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(165px,1fr));gap:12px}}
.metric{{background:#17223a;border-radius:14px;padding:16px}}small{{display:block;color:#95a6bb;font-size:11px;text-transform:uppercase}}
b{{font-size:21px;display:block;margin-top:6px}}.pill{{border-radius:22px;background:#234033;color:#9ffdd5;padding:5px 12px;font-size:12px}}
.warning{{background:#412a20;border:1px solid #705035;padding:14px;border-radius:12px;color:#ffcea0}}
table{{width:100%;border-collapse:collapse;font-size:13px}}td,th{{padding:10px;text-align:left;border-bottom:1px solid #2d3953}}th{{color:#9faec3}}
.legend span{{margin-right:22px}}button{{background:#55ddbf;color:#0b1620;padding:12px 20px;border:0;border-radius:10px;cursor:pointer;font-weight:700}}
.hide{{display:none}}pre{{overflow:auto;white-space:pre-wrap;font-size:12px;line-height:1.6;background:#0b1120;padding:15px;border-radius:12px}}
</style><main><div class="tag">PHYSICA / PHYSICAL EXPERIENCE LAB / FRONTIER v0.4</div>
<h1>The machine<br>remembers the <i>impact.</i></h1>
<p>Machine A experiences a physical force. Machine B uses its physics-calibrated causal residual to predict a new response. The prediction is signed before B is measured. A low-force probe can refine the memory.</p>
<div class="warning"><strong>SYNTHETIC DEMONSTRATION — NOT REAL HARDWARE OR LIVE META.</strong> The simulated machines share a favorable response family. Do not mistake this for proof of a universal breakthrough.</div>
<section class="panel"><span class="pill">CRATE / Causal Residual Alignment &amp; Transport of Experience</span>
<h2>Held-out Machine B: synthetic waveforms</h2>{svg}
<p class="legend"><span style="color:#31d0ac">● Observation</span><span style="color:#fbbf24">● Zero-shot transfer</span><span style="color:#a78bfa">● One local probe</span><span style="color:#64748b">● Physics-only</span></p>
</section><section class="panel"><h2>Honest held-out benchmark ({m['holdout_target_machines']} synthetic machines)</h2>
<div class="grid">{metrics}</div><p>Training: {m['training_machines']} machines · Calibration: {m['calibration_machines']} machines · Target: {m['holdout_target_machines']} unseen simulation bodies.</p>
<p>90% nominal conformal whole-response band coverage: <strong>{m['whole_trajectory_band_coverage']*100:.1f}%</strong>. Source-like exchangeability assumed.</p>
<button id="toggle">Inspect individual trials</button><div id="trials" class="hide" style="overflow:auto;margin-top:20px"><table><thead><tr><th>Target</th><th>Physics RMSE (mm)</th><th>Zero-shot RMSE (mm)</th><th>One-probe RMSE (mm)</th></tr></thead><tbody>{rows}</tbody></table></div></section>
<section class="grid"><div class="panel"><h2>Machine A teaches B</h2><p>Measured physical response → dimensionless causal residual → new body calibration → sealed response forecast.</p>
<p>Ed25519 prediction &amp; reveal signatures verified: <strong>{str(seal_valid)}</strong></p></div>
<div class="panel"><h2>Physica knows when to refuse</h2><p>An incompatible boundary setup cannot inherit this physical memory.</p><p>Refusal: <strong>{html.escape(str(refused))}</strong></p></div></section>
<section class="panel"><h2>Meta models: explicit, grounded responsibilities</h2><p><strong>Muse Spark 1.3:</strong> context, image/video reading and initial labels; <strong>SAM 3.1:</strong> video masks and tracking; <strong>Muse Wonder 1.0:</strong> causal hypotheses, experimental critiques, human explanation; <strong>V-JEPA 2:</strong> optional open-weight latent visual dynamics requiring a separately calibrated readout; <strong>Physica:</strong> physical units, safety, uncertainty, sealed causal evidence and transport.</p><p>These adapters are prepared against Meta's public API contracts. No model ran in this offline showcase.</p></section>
<section class="panel"><h2>Testable, not magical</h2><p>Source-only split · timestamp-integrity caveat · irreversible-action refusal · observable-calibration check · conformal held-out coverage · one-probe update · independent baselines.</p><p>See <code>docs/V04_BREAKTHROUGH_AND_META.md</code> and <code>synthetic_crate_benchmark.json</code> for detailed evidence.</p></section></main>
<script>document.getElementById('toggle').onclick=function(){{let e=document.getElementById('trials');e.classList.toggle('hide');this.textContent=e.classList.contains('hide')?'Inspect individual trials':'Hide individual trials'}};</script></html>'''
    (root/'physica_v04_experience_lab.html').write_text(page)


def run(out,seed=42,n_targets=24):
    root=Path(out);root.mkdir(parents=True,exist_ok=True)
    report,target,memory,sources=evaluate(seed=seed,n_targets=n_targets)
    # Explicit witnessable chronology of the code, NOT independent real-world timestamp.
    idx=len(target['times'])//2;c=target['machine']
    pred=float(target['zero'][idx]);band=float(target['q']*c.applied_step_force_n/c.stiffness_n_per_m)
    committed=seal(_episode(c,pred,max(band,1e-7)))
    write_json(root/'01_sealed_prediction.json',committed)
    obs=float(target['actual'][idx])
    revealed=reveal(committed,Quantity(value=obs,unit='m'))
    write_json(root/'02_revealed_observation.json',revealed)
    assert verify_seal(committed) and verify_reveal(revealed)
    incompatible=replace(c,boundary_class='free_free',machine_id='INCOMPATIBLE-C')
    refused=compatibility(sources[0].body,incompatible)
    assert refused['status']=='refused'
    safe=select_safe_probe([
        {'id':'listen','force_n':.05,'approved':True,'irreversible':False,'risk':.001},
        {'id':'low_force','force_n':.25,'approved':True,'irreversible':False,'risk':.01},
        {'id':'irreversible_break','force_n':100.,'approved':False,'irreversible':True,'risk':.99},
    ],c,max_deflection_m=.004)
    report.update({'selected_probe':safe,'incompatible_C':refused,
                   'seal_verified':verify_seal(committed),'reveal_verified':verify_reveal(revealed),
                   'prediction_sha256':committed['sha256'],
                   'single_prediction_verdict':revealed['result'],
                   'meta_models_executed':False,'hardware_experiments':False})
    write_json(root/'synthetic_crate_benchmark.json',report)
    render_page(root,report,target,verify_reveal(revealed),refused['reasons'])
    return report
