"""Long-term monitoring of any structure from its tracked natural frequencies and the weather (bridges, towers, masts).

Same idea as the blade (physica.cause.blade), for assets that report modal frequencies over months:
  1. Learn each mode's law with temperature from a baseline period, including the extra stiffening when the
     structure freezes (a knot below about 0 degC, chosen by blocked cross-validation, month by month).
  2. Group by day. Noise of a day's verdict = scatter of baseline days (carries what the law misses).
  3. Each day: weather only, or changed. If changed, the direction says which kinds of cause are possible
     (Rayleigh): tones UP only from added stiffness (repair, strengthening, a support) or removed mass; tones DOWN
     only from lost stiffness (damage) or added mass. Mixed directions = the structure was redistributed.
  4. A change is declared when it persists (several days in a row), and dated.
"""
from __future__ import annotations

import numpy as np
from scipy import stats


def _design(T, knot):
    T = np.asarray(T, float)
    return np.c_[np.ones_like(T), T] if knot is None else np.c_[np.ones_like(T), T, np.maximum(0.0, knot - T)]


class Monitor:
    def __init__(self, knots=(None, -1.0, 0.0, 1.0, 2.0, 3.0)):
        self.knots = knots

    def learn(self, F, T, month):
        """F: (n, modes) Hz with NaN where untracked; T: (n,) degC; month: (n,) labels for blocked CV."""
        F, T, month = np.asarray(F, float), np.asarray(T, float), np.asarray(month)
        self.models = []
        for k in range(F.shape[1]):
            y = np.log(F[:, k])
            ok = np.isfinite(y) & np.isfinite(T)
            best = None
            for knot in self.knots:
                err = []
                for m in np.unique(month[ok]):
                    tr, te = ok & (month != m), ok & (month == m)
                    if tr.sum() < 50 or te.sum() < 5:
                        continue
                    c, *_ = np.linalg.lstsq(_design(T[tr], knot), y[tr], rcond=None)
                    err.append(np.mean((_design(T[te], knot) @ c - y[te]) ** 2))
                score = float(np.mean(err)) if err else np.inf
                if best is None or score < best[0]:
                    best = (score, knot)
            c, *_ = np.linalg.lstsq(_design(T[ok], best[1]), y[ok], rcond=None)
            self.models.append({"knot": best[1], "coef": c, "cv_rmse_pct": 100 * float(np.sqrt(best[0]))})
        return self.models

    def residual(self, F, T):
        F, T = np.asarray(F, float), np.asarray(T, float)
        return np.column_stack([np.log(F[:, k]) - _design(T, m["knot"]) @ m["coef"] for k, m in enumerate(self.models)])

    @staticmethod
    def daily(R, day):
        days = np.unique(day)
        M = np.array([np.nanmean(R[day == d], 0) if np.isfinite(R[day == d]).any() else np.full(R.shape[1], np.nan)
                      for d in days])
        return days, M

    def learn_noise(self, R, day):
        _, M = self.daily(R, day)
        M = M[np.isfinite(M).all(1)]
        self.cov = np.cov(M.T) + np.eye(M.shape[1]) * 1e-12
        self.sd = np.sqrt(np.diag(self.cov))
        return M

    def judge_day(self, r, alpha=1e-3):
        ok = np.isfinite(r)
        if ok.sum() < 2:
            return {"verdict": "can't tell", "why": "too few modes tracked"}
        S = self.cov[np.ix_(ok, ok)]
        d = float(r[ok] @ np.linalg.solve(S, r[ok]))
        thr = float(stats.chi2.ppf(1 - alpha, ok.sum()))
        z = np.full(len(r), np.nan)
        z[ok] = r[ok] / self.sd[ok]
        out = {"score": d, "threshold": thr, "z": z, "residual_pct": 100 * r}
        if d <= thr:
            out["verdict"] = "weather only"
        else:
            up, down = np.nansum(z > 3), np.nansum(z < -3)
            if up and not down:
                out["verdict"] = "stiffer"
                out["say"] = "Tones went UP beyond the weather: only added stiffness (repair, strengthening) or removed mass can do that."
            elif down and not up:
                out["verdict"] = "softer"
                out["say"] = "Tones went DOWN beyond the weather: lost stiffness (damage) or added mass. Inspect."
            else:
                out["verdict"] = "redistributed"
                out["say"] = "Some tones UP and some DOWN beyond the weather: the structure itself was changed (works, damage and repair)."
        return out

    @staticmethod
    def first_persistent(days, verdicts, run=5):
        streak = 0
        for d, v in zip(days, verdicts):
            streak = streak + 1 if v not in ("weather only", "can't tell") else 0
            if streak >= run:
                return d
        return None
