"""v0.8: sealed *future* sensory predictions from actions and initial state.

Unlike v0.7's conditional acceleration estimate, no future target x/v/a is
accepted as input. Every source lesson and local probe is checked before use.
The simulator is a bounded model, not a robot controller or hardware proof.
"""
from __future__ import annotations
from dataclasses import asdict
from datetime import datetime, timezone
from hashlib import sha256
import math
from typing import Mapping
import numpy as np
from physica.library import sign
from .core import Body, Sense, sense_prediction
from .mechanism_transfer import FEATURES, feature, _recheck_probe


def _f64_1d(value, name, minimum=2):
    out = np.asarray(value, dtype=float)
    if out.ndim != 1 or out.size < minimum or not np.isfinite(out).all():
        raise ValueError(f'{name} must contain {minimum}+ finite values')
    return out


def simulate_future(body: Body, times_s, force_n, initial_state, *,
                    mechanism='cubic_elasticity', beta=0., displacement_reference_m=.01):
    """Open-loop RK4; linear force interpolation, not observed target motion."""
    t = _f64_1d(times_s, 'times_s')
    u = _f64_1d(force_n, 'force_n')
    z0 = np.asarray(initial_state, dtype=float)
    if (len(t) != len(u) or t[0] < 0 or np.any(np.diff(t) <= 0)
        or z0.shape != (2,) or not np.isfinite(z0).all()):
        raise ValueError('invalid future intervention and initial state')
    if np.max(np.abs(u)) > body.max_authorized_force_n + 1e-12:
        raise ValueError('force exceeds approved simulation/model envelope')
    if np.max(np.diff(t)) * math.sqrt(body.stiffness_n_m / body.mass_kg) > .35:
        raise ValueError('future time-step too coarse')
    if mechanism not in FEATURES or not math.isfinite(float(beta)) or abs(beta) > 3.:
        raise ValueError('invalid bounded mechanism and coefficient')
    if not math.isfinite(displacement_reference_m) or displacement_reference_m <= 0:
        raise ValueError('invalid displacement reference')
    z = np.empty((len(t), 2), dtype=float)
    z[0] = z0
    for i in range(len(t) - 1):
        dt = float(t[i + 1] - t[i])
        def slope(state, fraction):
            force = (1. - fraction) * u[i] + fraction * u[i + 1]
            x, v = state
            residual = beta * float(feature(body, x, v, mechanism, displacement_reference_m))
            return np.array([v, (force - body.stiffness_n_m*x - body.damping_n_s_m*v - residual) / body.mass_kg])
        k1 = slope(z[i], 0.)
        k2 = slope(z[i] + dt*k1/2., .5)
        k3 = slope(z[i] + dt*k2/2., .5)
        k4 = slope(z[i] + dt*k3, 1.)
        z[i + 1] = z[i] + dt*(k1 + 2*k2 + 2*k3 + k4)/6.
        if not np.isfinite(z[i + 1]).all():
            raise ValueError('unstable hypothetical trajectory')
    return z


def _valid_source(source):
    if not isinstance(source, dict) or source.get('status') != 'CANDIDATE_SIGNED_REQUIRES_TARGET_PROBE':
        return False
    r = source.get('record', {})
    p = r.get('payload')
    if not isinstance(p, dict):
        return False
    return (sha256(sign.canonical(p)).hexdigest() == r.get('sha256')
            and sign.verify(p, r.get('signature_ed25519', '')))


def seal_future_sensations(source, target: Body, senses: Mapping[str,Sense],
                           *, times_s, force_n, initial_state,
                           displacement_reference_m, probe_certificate=None,
                           experiment_id=None,
                           between_machine_sigma=.02,
                           max_disagreement_z=2.5):
    """No future target kinematics permitted. Refuses before generating forecast."""
    if not _valid_source(source):
        return {'status':'REFUSE_SOURCE_INVALID'}
    p = source['record']['payload']
    src = p['source_body']
    if p.get('evidence_origin') == 'simulation' and target.provenance != 'simulation':
        return {'status':'REFUSE_SYNTHETIC_TO_HARDWARE'}
    if target.boundary_class != src['boundary_class'] or target.mechanism_family != src['mechanism_family']:
        return {'status':'REFUSE_INCOMPATIBLE_MECHANICS'}
    frequency_ratio = math.sqrt((target.stiffness_n_m/target.mass_kg) / (src['stiffness_n_m']/src['mass_kg']))
    if not .5 <= frequency_ratio <= 2.:
        return {'status':'REFUSE_FREQUENCY_SHIFT'}
    if probe_certificate is None:
        return {'status':'PROBE_FIRST'}
    if not _recheck_probe(source, target, probe_certificate, displacement_reference_m):
        return {'status':'REFUSE_PROBE_INVALID_OR_MISMATCH'}
    if not (math.isfinite(float(between_machine_sigma)) and 0 < between_machine_sigma <= 3.
            and math.isfinite(float(max_disagreement_z)) and 0 < max_disagreement_z <= 20.):
        raise ValueError('predeclared adaptation thresholds must be finite and positive')
    if not experiment_id or not isinstance(experiment_id, str):
        raise ValueError('prospectively declared experiment_id required')
    if not senses or any(k != s.sensor_id for k,s in senses.items()):
        raise ValueError('named calibrated senses required')
    if any((s.calibration_origin == 'simulation') != (target.provenance == 'simulation') for s in senses.values()):
        return {'status':'REFUSE_UNVERIFIED_SENSOR_CALIBRATION'}
    # Read target-probe measurements only from the signed, independently
    # recomputed certificate. No caller-supplied coefficient is authoritative.
    from .hierarchical_transfer_v08 import combine_source_and_probe
    measured_probe = probe_certificate['payload']['measured_episode']
    try:
        posterior = combine_source_and_probe(
            source, target, measured_probe, displacement_reference_m,
            certificate=probe_certificate,
            between_machine_sigma=between_machine_sigma,
            max_disagreement_z=max_disagreement_z)
    except (ValueError, TypeError, KeyError, OverflowError):
        return {'status': 'REFUSE_ADAPTATION_UNVERIFIED'}
    chosen_beta = posterior['coefficient']
    state = simulate_future(target, times_s, force_n, initial_state,
                            mechanism=p['mechanism'], beta=chosen_beta,
                            displacement_reference_m=displacement_reference_m)
    preds = {k:sense_prediction(target,s,state).tolist() for k,s in senses.items()}
    # These are model-conditional parameter sensitivity bands, NOT reliable
    # frequentist confidence intervals under unknown material/dynamics shift.
    sigma_beta = math.sqrt(posterior['posterior_variance_model_conditional'])
    interval_states = [simulate_future(target, times_s, force_n, initial_state,
                       mechanism=p['mechanism'],
                       beta=float(np.clip(chosen_beta + delta*1.96*sigma_beta, -3., 3.)),
                       displacement_reference_m=displacement_reference_m)
                       for delta in (-1., 1.)]
    predicted_sensor_bands = {}
    for key, sensor in senses.items():
        candidates = [preds[key]] + [sense_prediction(target, sensor, z).tolist() for z in interval_states]
        candidate_matrix = np.asarray(candidates)
        predicted_sensor_bands[key] = {
            'lower': np.min(candidate_matrix, axis=0).tolist(),
            'upper': np.max(candidate_matrix, axis=0).tolist(),
            'interpretation': 'parameter_sensitivity_only_not_empirical_coverage'}
    payload = {'schema':'physica.sealed-future-sensation.v081',
               'experiment_id':experiment_id,'body':asdict(target),
               'senses':{k:asdict(s) for k,s in senses.items()},
               'times_s':list(map(float,times_s)),'applied_force_n':list(map(float,force_n)),
               'initial_state_m_m_s':list(map(float,initial_state)),
               'predicted_state_m_m_s':state.tolist(), 'predicted_sensor_values':preds,
               'sensor_parameter_sensitivity_bands': predicted_sensor_bands,
               'adaptation': {**posterior,
                              'policy':'signed_probe_hierarchical_with_local_fallback',
                              'between_machine_sigma_predeclared':between_machine_sigma,
                              'max_disagreement_z_predeclared':max_disagreement_z},
               'source_lesson_sha256':source['record']['sha256'],
               'probe_certificate_sha256':probe_certificate['sha256'],
               'mechanism':p['mechanism'],'dimensionless_coefficient':chosen_beta,
               'evidence_origin':'SIMULATED' if target.provenance == 'simulation' else 'PROSPECTIVE_SENSOR_DATA',
               'sealed_at_utc':datetime.now(timezone.utc).isoformat(),
               'hardware_actuation_allowed':False,
               'notice':'Local signing alone does not establish independent chronology; parameter sensitivity is not coverage.'}
    return {'status':'SEALED_FUTURE_SENSATIONS', 'payload':payload,
            'sha256':sha256(sign.canonical(payload)).hexdigest(),
            'signature_ed25519':sign.sign(payload)}


def score_future_reveal(sealed, measured_by_sensor, *, measurement_origin, experiment_id):
    """Only after sealing: compare independently supplied held-out observations."""
    if sealed.get('status') != 'SEALED_FUTURE_SENSATIONS':
        return {'status':'REFUSE_UNSEALED'}
    p = sealed['payload']
    if (sha256(sign.canonical(p)).hexdigest() != sealed.get('sha256') or
        not sign.verify(p, sealed.get('signature_ed25519',''))):
        return {'status':'REFUSE_TAMPERED_FORECAST'}
    if experiment_id != p['experiment_id']:
        return {'status':'REFUSE_DIFFERENT_INTERVENTION'}
    if measurement_origin not in ('SIMULATED','REAL_MEASUREMENT') or measurement_origin != p['evidence_origin'].replace('PROSPECTIVE_SENSOR_DATA','REAL_MEASUREMENT'):
        return {'status':'REFUSE_ORIGIN_MISMATCH'}
    if set(measured_by_sensor) != set(p['predicted_sensor_values']):
        return {'status':'REFUSE_MISSING_OR_EXTRA_SENSOR'}
    metrics = {}
    for key, expected in p['predicted_sensor_values'].items():
        observed = _f64_1d(measured_by_sensor[key], key)
        exp = np.asarray(expected,float)
        if len(observed) != len(exp):
            return {'status':'REFUSE_CLOCK_OR_LENGTH_MISMATCH'}
        noise = p['senses'][key]['noise_std']
        bounds = p.get('sensor_parameter_sensitivity_bands', {}).get(key)
        band_coverage = None
        if bounds:
            low = _f64_1d(bounds['lower'], 'lower', minimum=len(exp))
            high = _f64_1d(bounds['upper'], 'upper', minimum=len(exp))
            if np.any(low > high):
                return {'status': 'REFUSE_INVALID_BAND'}
            band_coverage = float(np.mean((observed >= low) & (observed <= high)))
        metrics[key] = {'fraction_within_parameter_sensitivity_band': band_coverage,
                        'rmse_native_units':float(np.sqrt(np.mean((observed-exp)**2))),
                        'rmse_in_calibrated_sensor_noise':float(np.sqrt(np.mean(((observed-exp)/noise)**2))),
                        'unit':p['senses'][key]['unit']}
    # A signed reveal receipt binds the actual raw observations to their metrics;
    # the source data themselves remain separately inspectable.
    receipt = {'status':'MEASURED_AFTER_SEAL','experiment_id':experiment_id,
               'sealed_sha256':sealed['sha256'],
               'measurement_data_sha256':sha256(sign.canonical(measured_by_sensor)).hexdigest(),
               'measurement_origin':measurement_origin,
               'sensor_metrics':metrics,'hardware_actuation_allowed':False,
               'notice':'Local signing is not independent proof of when the experiment happened.'}
    return {**receipt, 'receipt_sha256':sha256(sign.canonical(receipt)).hexdigest(),
            'receipt_signature_ed25519': sign.sign(receipt)}


def verify_reveal_receipt(receipt, sealed, measured_by_sensor):
    """Revalidate signed reveal metrics and raw observations without trusting the receipt."""
    if not isinstance(receipt, dict) or not isinstance(sealed, dict):
        return False
    try:
        base = {k:v for k,v in receipt.items()
                if k not in ('receipt_sha256','receipt_signature_ed25519')}
        sealed_payload = sealed.get('payload')
        if not isinstance(sealed_payload,dict): return False
        if (sealed.get('status') != 'SEALED_FUTURE_SENSATIONS'
            or sha256(sign.canonical(sealed_payload)).hexdigest() != sealed.get('sha256')
            or not sign.verify(sealed_payload, sealed.get('signature_ed25519',''))):
            return False
        if (receipt.get('status') != 'MEASURED_AFTER_SEAL'
            or base.get('sealed_sha256') != sealed.get('sha256')
            or base.get('measurement_data_sha256') != sha256(sign.canonical(measured_by_sensor)).hexdigest()
            or sha256(sign.canonical(base)).hexdigest() != receipt.get('receipt_sha256')
            or not sign.verify(base, receipt.get('receipt_signature_ed25519',''))):
            return False
        # Recompute RMSE and band diagnostics; do not merely verify a signature
        # on values that could have been computed incorrectly.
        expected = sealed['payload']['predicted_sensor_values']
        if set(measured_by_sensor) != set(expected): return False
        for sensor, pred in expected.items():
            observed = _f64_1d(measured_by_sensor[sensor], sensor)
            if len(observed) != len(pred): return False
            exp = np.asarray(pred, dtype=float)
            noise = float(sealed['payload']['senses'][sensor]['noise_std'])
            m = receipt['sensor_metrics'][sensor]
            if not np.isclose(float(m['rmse_native_units']),float(np.sqrt(np.mean((observed-exp)**2))),atol=1e-12):return False
            if not np.isclose(float(m['rmse_in_calibrated_sensor_noise']),float(np.sqrt(np.mean(((observed-exp)/noise)**2))),atol=1e-12):return False
            band = sealed_payload.get('sensor_parameter_sensitivity_bands',{}).get(sensor)
            expected_coverage = None
            if band:
                low=np.asarray(band['lower'],float)
                high=np.asarray(band['upper'],float)
                if low.shape != observed.shape or high.shape != observed.shape or not np.isfinite(low).all() or not np.isfinite(high).all():return False
                expected_coverage=float(np.mean((observed >= low) & (observed <= high)))
            reported=m.get('fraction_within_parameter_sensitivity_band')
            if (expected_coverage is None) != (reported is None):return False
            if expected_coverage is not None and not np.isclose(expected_coverage,reported,atol=1e-12):return False
        return True
    except (ValueError,TypeError,KeyError,OverflowError):
        return False
