"""Phone recordings: the free phyphox app ("Acceleration (without g)" or "Acceleration with g" experiment,
Export -> CSV). Also accepts any CSV with a time column and x/y/z acceleration columns.

Phones sample unevenly, so the recording is resampled onto an even clock at its median rate.
Returns acc (N, 1, 3) in m/s^2 (one 'unit': the phone) and the sample rate in Hz.
"""
from __future__ import annotations

import csv
import io
import re
from pathlib import Path

import numpy as np


def _cols(header: list[str]) -> tuple[int, list[int]]:
    low = [h.strip().strip('"').lower() for h in header]
    t = next(i for i, h in enumerate(low) if h.startswith("time") or h == "t" or h.startswith("t ("))
    axes = []
    for ax in "xyz":
        pat = re.compile(rf"(^|[^a-z]){ax}([^a-z]|$)")
        axes.append(next(i for i, h in enumerate(low) if i != t and pat.search(h)))
    return t, axes


def load_phyphox(path: str | Path) -> tuple[np.ndarray, float]:
    text = Path(path).read_text(encoding="utf-8-sig")
    dialect = csv.Sniffer().sniff(text.splitlines()[0], delimiters=",;\t")
    rows = list(csv.reader(io.StringIO(text), dialect))
    t_i, ax_i = _cols(rows[0])
    data = []
    for r in rows[1:]:
        try:
            data.append([float(r[t_i].replace(",", ".") if dialect.delimiter == ";" else r[t_i])] +
                        [float(r[i].replace(",", ".") if dialect.delimiter == ";" else r[i]) for i in ax_i])
        except (ValueError, IndexError):
            continue
    d = np.array(data)
    d = d[np.argsort(d[:, 0])]
    t = d[:, 0] - d[0, 0]
    fs = 1.0 / float(np.median(np.diff(t)))
    tu = np.arange(0, t[-1], 1 / fs)
    acc = np.stack([np.interp(tu, t, d[:, k]) for k in (1, 2, 3)], axis=1)
    return acc[:, None, :], fs


def write_phyphox(path: str | Path, t: np.ndarray, acc: np.ndarray) -> Path:
    """Write a phyphox-style CSV (used by tests and simulations)."""
    lines = ['"Time (s)","Acceleration x (m/s^2)","Acceleration y (m/s^2)","Acceleration z (m/s^2)"']
    lines += [f"{ti:.6f},{a[0]:.6f},{a[1]:.6f},{a[2]:.6f}" for ti, a in zip(t, acc)]
    Path(path).write_text("\n".join(lines) + "\n")
    return Path(path)
