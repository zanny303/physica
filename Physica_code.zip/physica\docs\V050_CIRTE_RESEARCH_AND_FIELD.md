# Physica v0.5: CIRTE — Causal Interventional Representation & Transfer of Experience

**Version:** 0.5.0  
**Status:** functioning research software; all new demonstrations and benchmarks are **simulation-only**.  
**Scientific status:** a **candidate original combination**, not a peer-reviewed new theorem, learned universal causal grammar, or experimentally demonstrated general breakthrough.

## The precise scientific claim to test

> Can Machine A learn a *causal intervention-response rule* through one sensory apparatus, and can another machine with different physical parameters and sensors use the transferred rule to make a better **prospectively sealed** prediction, with fewer target interventions, while knowing when NOT to transfer?

The central shift from v0.4.3 is from illustrative `hearing=velocity` to **independently calibrated native-unit observation operators**. Existing Touch Transform, Body Map, PACER, CRATE, CSG, signed protocols, real WAV ingress, and separate chemical observation remain intact.

## Physical mathematics and architectural assumptions

In the current mechanical domain, latent physical state is \(z_t = (x_t,\dot x_t)\) for a forced damped oscillator:

\[
\frac{d}{dt}\begin{pmatrix}x\\v\end{pmatrix}
=\begin{pmatrix}0&1\\-k/m&-2\zeta\sqrt{k/m}\end{pmatrix}
\begin{pmatrix}x\\v\end{pmatrix}+\begin{pmatrix}0\\F/m\end{pmatrix}.
\]

Each **different** sensor observes a calibrated function of this physical state, for example

\[y^s_t = H_s z_t+b_s+\epsilon_{s,t}.\]

A microphone's raw unit **can be pressure in pascals**, rather than pretending that acoustic pressure equals velocity. A sensor gets its \(H_s\) from **paired external reference measurements** and held-out validation (`grammar/observation.py`). Video pixel tracks must independently be scaled into meaningful physical units, SAM's masks/boxes are only visual *geometry*. A conventional linear sensor observation filter combines asynchronous observations by calibrated uncertainty and rejects conflicting readings. Nonlinear dynamics, environment acoustics, propagation, unknown clock drift, chemical response, and coupling across physical bodies require other state models; the current oscillator is NOT universal.

PEL 3 already stores signed and normalized physical action-response episodes. CIRTE translates signed dimensionless responses into a new body's local displacement/velocity, and then through the receiving sensor's own calibrated \(H_s\). The **source and target do not need to share sensors**, but they **must** share identifiable response physics within the validated regime. The receiving body's frequency, stiffness, damping, action amplitude, mounting class, and observation calibration are supplied: **zero-shot means zero target *main response* examples, not zero target characterization**.

### Explicit epistemic gates

`grammar/cirte.py` supplies `transfer_validity`:

* **probe_first** if the target's mount/action regime matches, but no independent low-force validation of its hidden dynamics has been observed.
* **transfer** only after an externally supplied, low-force response agrees under a preregistered tolerance and uncertainty threshold. This is conditional permission to **predict**, not permission to actuate.
* **refuse** for unsupported mounting, missing calibration, unverifiable signed source, high drift, nonfinite inputs or out-of-domain parameters.

After transfer the system can forecast the target's **sensor-native** output, not merely a displacement graph. Source uncertainty and sensor noise do NOT amount to a validated *full prediction interval*, so CIRTE intentionally leaves the full interval `null` until independent coverage calibration is possible. Risk of failure under hidden dynamics remains.

### Open-world unknown mechanisms

`unknown_mechanism_test` compares the best known model's held-out standardized response mismatch to an external residual distribution. A large mismatch becomes **unknown_mechanism_or_sensor_failure**. It cannot by itself distinguish new physical phenomena from a broken or miscalibrated sensor. `meta_cirte.new_hypothesis_from_muse` accepts only parameterized mechanisms in a restrictive registry (mass, stiffness, damping, sensor bias), and only independently measured numerical parameter values. Muse may **propose** a mechanism family, but cannot make up physical parameters or have its proposal accepted as a discovery. A truly new family still needs an independent model-implementation and identification study.

### True experiment selection versus a mean-separation heuristic

`grammar/eig.py` implements Monte Carlo expected information gain over a **predeclared scalar response summary** \(Y\) with hypothesis-conditioned Gaussian measurements:

\[
I(H;Y\mid do(a),D) =\mathbb{E}_{H,Y}\left[\log\frac{p(Y\mid H,a,D)}{p(Y\mid a,D)}\right].
\]

The planner ranks expected information gain plus **predeclared** target transfer value minus cost/risk, and rejects unapproved or destructive experiments. The assumed hypothesis family and measurement noise can be wrong; a high score is not proof of identifiability or of a safe action. It never actuates hardware.

### Physica's 'language of physical experience'

The PEL word is not just a sensor measurement. It packages a locally measured response, intervention semantics, normalized time and response, uncertainty, evidence references, mechanism hypothesis, domain constraints, and a source identity/hash. The `executable_contract` creates a hardware-neutral **requested effect** with allowed action families and hard physical limits; it never emits control commands. A receiving machine must independently resolve that abstract effect to its own *approved* controller and pass hardware safety supervision.

## Meta models: scientific jobs, not decorative chatbot narration

1. **Muse Spark 1.3:** In an authenticated run, inspects video and sensor-context manifest, notices experimental setup, objects, missing measurements and confounders. It cannot provide physical numbers. `meta_cirte.live_grounded_plan` saves hashes and the model ID.
2. **SAM 3.1:** Provides per-part video boxes/masks and tracking via the Responses API; physically calibrated and cross-checked tracks join CSG's sensors using existing `grammar/meta_csg.py`. For rigorous **Meta-on/off** scores, the independent test reference **must differ** from any calibration/cross-check reference. The v0.4.3 code reports an in-run diagnostic and clearly says it's not a held-out result.
3. **Muse Wonder 1.0:** Proposes competing explanations, a possible new *parameterized* mechanism, and an allowed experiment. CIRTE's numeric EIG/risk layer makes the selection. Without independent held-out Muse proposal-reliability data, its hints do NOT change numerical scientific priors.
4. **V-JEPA 2 / 2.1:** Official separate open-weight PyTorch world-model family. The v0.5 `temporal_features` and `fit_temporal_readout` now handle time-window *exported embeddings* and allow single-frame-window inference at test time. This is a calibrated readout, NOT an executed V-JEPA encoder, trained action-conditioned predictor, or independent video world forecast. Running weights requires separate supported GPU hardware and checkpoints. The project should add a real inference run and calibrate outputs against independent physical ground truth.
5. **Muse Glimmer:** Optional separately hosted low-latency textual context; not a sensor and not a Meta API hosted model. **Smell and taste:** Existing separate chemical dynamics are typed and synthetic; no physical electronic nose/tongue or calibration standards were supplied.

**Official Meta sources checked (October 30, 2026):**
- Model API docs: https://dev.meta.ai/docs/overview
- Responses endpoint and content formats: https://dev.meta.ai/docs/protocols/responses
- Model routing and SAM: https://dev.meta.ai/docs/models
- Meta FAIR V-JEPA 2/2.1 source: https://github.com/facebookresearch/vjepa2

`grammar/meta_cirte.py` supports an offline synthetic proposal example and an **explicitly billed live Muse Spark→Wonder call** on your local video with `MODEL_API_KEY`. Never paste a private key into ChatGPT or include it in your ZIP. Before making any billable calls, check the account's model access and response schema; the adapters are documentation-grounded but **live compatibility is unverified here**. A model's suggested action remains *untrusted* even after authentication.

## What can actually be run now

Install from a shell in the repository:

```sh
pip install -e '.[dev]'

# 1: Full 24-target stress benchmark, including shifted dynamics
python -m physica.cli grammar cirte-benchmark --trials 24 --out demo/cirte_benchmark.json

# 2: Three-machine native-unit A→B→C example, with signed prediction and reveal
python examples/cirte_v05/BUILD_NATIVE_SIMULATION.py examples/cirte_v05/native_demo

# 3: EIG experiment planning, no Meta called or billed
python -m physica.cli grammar cirte-plan examples/cirte_v05/scientist_request.json --out demo/plan.json

# 4: Offline fixture simulating a Muse-proposed hint (NOT an authenticated response)
python -m physica.cli grammar cirte-plan examples/cirte_v05/scientist_request.json \
   --meta-reply-json examples/cirte_v05/REPLAY_NOT_META.json --out demo/plan_with_mock_hint.json

# 5: A genuinely authenticated Muse Spark and Wonder call: only on YOUR machine
export MODEL_API_KEY='YOUR_PRIVATE_META_KEY'
python -m physica.cli grammar cirte-meta-plan-live examples/cirte_v05/scientist_request.json \
    /path/to/real_machine_video.mp4 --allow-billed-meta --out demo/live_meta_plan.json

# 6: After collecting real paired held-out truth AND actual Meta output records
python -m physica.cli grammar cirte-meta-ablation baseline.json meta_on.json --out demo/meta_ablation.json
```

**Existing Meta+SAM+CSG live pipeline is still available** using `grammar meta-csg-live`, but requires real video, sensor reference, accurate camera calibration and the user's key. No simulated response should be labelled as live API output.

### Prospective native-sensor field protocol

See `examples/cirte_v05/native_demo` for the **synthetic demonstration format**, not real data. To apply the same procedure to real microphones, video and accelerometers:

1. Independently calibrate each sensor's output (`CalibratedSensor`: gain on displacement, gain on velocity, offset, noise, clock shift) using paired controlled reference trials, including **disjoint validation trials**. Document a calibration ID and retain raw instrument files.
2. Create a source A manifest with body properties, experimental action, `source_attestation` file, native-unit CSV with exact `time_s,value` headers, and sensor-calibration JSON. Run `grammar cirte-source manifest.json --out A_signed.json`.
3. Independently calibrate B's body and receiving sensor. Collect a **small, safe, supervised low-force probe** under a declared policy. Its response and hashed raw data determine whether transfer is allowed. Prepare B's main response grid file with timestamps **only**. Run `grammar cirte-prepare A_signed.json B_body.json B_sensor.json B_times.csv B_probe.json --out B_sealed.json`. This reads **no B main response values**.
4. Separately publish or notarize the signed prediction hash to establish external chronology. Then run the supervised main test under the same condition and save its `time_s,value` native-unit CSV. `grammar cirte-check B_sealed.json B_observed.csv --out B_reveal.json` verifies prediction integrity before opening the observation.
5. `grammar cirte-learn-next B_reveal.json B_observed.csv --action-id ... --hypothesis ... --out B_new_signed.json` writes a signed **candidate** physical memory. Independently repeat the procedure for new, disjoint Machine C; report every mismatch and refusal.

**Safety:** No commands may directly drive robots, fans, printers or hazardous machinery. All actions are approved and operated by the user's trained supervisor, physically limited by hardware. Do not deliberately cause unprotected structural failure. External chronology cannot be proven by the repository's local signing alone.

## Reproducible v0.5 benchmark (all synthetic)

`examples/cirte_v05_benchmark.json` records the seed and accepted/refused denominators. The current default 24-target source-like family is designed to match the source oscillator's underlying mechanics; the 24 shifted targets have a much larger hidden component that the supplied low-force probe can detect. In that setup the transfer gate accepts the 24 source-like cases and rejects the 24 shifted cases. **This is not a statistical real-world failure rate, and the gating thresholds were not tuned on independently collected hardware.**

The benchmark separately reports calibration-aware audio/video joint state reconstruction, EIG-based reversible probe planning, rejection of a destructive action, an UNKNOWN-mechanism test and the abstract machine-language contract. The native A→B→C sample is also simulated and uses a known compatible oscillator family.

## Mandatory experimental comparisons for genuine novelty

- **Physical baselines:** physics-only, one-target calibrated system ID, nearest source, CRATE, classical shared-dynamics transfer (e.g. Koopman representation), CSG, and CIRTE.
- **Same budgets:** count target interventions, hardware calibration hours and actual cost, not just prediction RMSE.
- **Sensory ablations:** audio only, vision only, vibration only, partial/noisy/corrupted readings, unpaired clocks; report RMSE and honest abstention.
- **Meta ablations:** no Meta; SAM only; Muse proposals only; both; with independently executed V-JEPA when available. Compare on identical *independent* target outcomes not used to calibrate SAM/feature conversion.
- **Open-world OOD:** unknown masses, looseness, plastic contact, loose sensors, boundary changes, new geometry/materials and target *dynamics* that violate transfer assumptions. Compare risk-versus-coverage, not just successes.
- **Statistics:** machine-level holdouts, randomized action order, independent calibration/training/test splits, confidence intervals across truly independent fixtures, blinded comparison and all failures included.

Science must be evaluated against closely related previous work; **CIRTE does not invent Kalman filters, residual learning, normalized mechanics, EIG, conformal prediction, or causal representations**. The possible contribution is the independently tested *combination* and its new selective cross-sensory intervention-transfer benefit.

### Related work requiring proper novelty comparison

- Meta FAIR **V-JEPA 2** (Assran et al.), video world-model representations and action-conditioned planning: https://github.com/facebookresearch/vjepa2
- **TacX**, multisensory tactile representation learning (2025): search paper and official publication before claiming priority.
- **Cross-Sensor Touch Generation**, translating between tactile sensor types (2025): search paper and official publication before claiming uniqueness.
- **Residual Physics Learning** (Sontakke et al., 2023) and related sim-to-real residual dynamics methods.
- **Bayesian optimal experiment design**, classical methods; CIRTE's scalar EIG is a specific implementation under conditional noise assumptions.
- **System identification**, DMD/Koopman mechanics, state innovation tests, operational modal analysis: well-established foundations.

## Honest remaining limits after software release

- **Real-world hardware:** no independently collected physical A→B→C demonstration was performed in this environment.
- **Meta:** no authenticated Muse/SAM calls executed here because no user key was shared; optional live code is still unverified against user's account.
- **V-JEPA:** no actual video model weights downloaded/executed; only calibrated exported-feature machinery.
- **Six-sense integration:** mechanical vision/acoustic/touch pathways implemented at a *linear calibrated-state* level; real chemical sensors and specialized physical mechanisms are not validated.
- **Breakthrough status:** no state-of-the-art performance or real-world transfer advantage has been demonstrated, no claim of an AI's subjective experience.

The strongest honest statement to demonstrate is: **“Physica predicts in the native sense of a different machine, refuses unsupported transfers, and independently checks what physical reality did.”**
