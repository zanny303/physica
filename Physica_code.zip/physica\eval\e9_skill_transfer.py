"""E9: do senses learned on one machine transfer to a DIFFERENT machine as skills?

Source machine: Parrot Bebop 2. Target machine: 3DR Solo (bigger, different motors and propellers). Both from
PADRE, real flights. On the target, every skill gets ZERO damage data: only the first half of one healthy flight
to relearn its numbers. Judged on the second half of that flight (false alarms) and on 8 damaged Solo flights.

Skills compared (all learned on the Bebop; only their numbers are relearned on the Solo):
  hz_band      the Bebop self-model in plain frequency (95-200 Hz band, operating-point curve)
  order_narrow orders 0.85-1.15 of the main line: where damage showed on the Bebop (over-fits the source)
  order_broad  orders 0.25-1.25 of the main line: the machine's whole rhythm (Order Feel)
  order_broad_speed  same, with each order's level conditioned on speed (ablation; added after a first look
               at these results, so reported as exploratory)
  spectrogram  plain band power vs healthy statistics (no self-cancelling), same band as hz_band
Plus 'copy numbers': the Bebop's fitted order_broad numbers applied to the Solo unchanged (arrival check).
"""
from __future__ import annotations

import numpy as np

from common import CFG, SINGLE, binom_ci, cluster_boot_ci, save_result
from physica.data import padre, solo
from physica.feel.feel_transform import windows
from physica.feel.order_feel import OrderFeel
from physica.feel.selfmodel import OperatingPointSelfModel
from physica.feel.spectra import band_peak, window_psd

from physica import config

SOLO_DAMAGE = [c for c in solo.CODES if c != "0000"]


def feats(machine: str, code: str) -> dict:
    cache = config.REPO_ROOT / ".cache" / "features9" / f"{machine}_{code}.npz"
    if cache.exists():
        d = np.load(cache)
        return {k: d[k] for k in d.files}
    rec = (padre if machine == "bebop" else solo).load(code)
    f, psd = window_psd(rec.acc, rec.fs, windows(rec.acc.shape[0], rec.fs, CFG.win_s), CFG.nperseg)
    cache.parent.mkdir(parents=True, exist_ok=True)
    np.savez(cache, f=f, psd=psd)
    return {"f": f, "psd": psd}


class HzBand:
    def fit(self, psd, f, fs):
        op, lvl = band_peak(psd, f, CFG.band)
        self.m = OperatingPointSelfModel(unit_names=list("ABCD")).fit(op, lvl)
        self.thr = self.m.calibrate_threshold(op, lvl, CFG.q, CFG.margin)
        return self

    def felt(self, psd, f):
        op, lvl = band_peak(psd, f, CFG.band)
        return self.m.z(op, lvl).max(axis=1) > self.thr


class Spectrogram:
    def fit(self, psd, f, fs):
        self.mb = (f >= CFG.band[0]) & (f <= CFG.band[1])
        bp = 10 * np.log10(psd[:, :, self.mb].sum(axis=2) + 1e-30)
        self.mu, self.sd = bp.mean(0), bp.std(0, ddof=1)
        self.thr = float(np.quantile(((bp - self.mu) / self.sd).max(1), CFG.q) + CFG.margin)
        return self

    def felt(self, psd, f):
        bp = 10 * np.log10(psd[:, :, self.mb].sum(axis=2) + 1e-30)
        return ((bp - self.mu) / self.sd).max(1) > self.thr


def skills():
    return {"hz_band": HzBand,
            "order_narrow": lambda: OrderFeel(orders=(0.85, 1.15)),
            "order_broad": lambda: OrderFeel(orders=(0.25, 1.25)),
            "order_broad_speed": lambda: OrderFeel(orders=(0.25, 1.25), speed_aware=True),
            "spectrogram": Spectrogram}


def evaluate(model, healthy, damage: dict) -> dict:
    n = healthy["psd"].shape[0]
    ho = np.arange(n // 2, n)
    fa = model.felt(healthy["psd"][ho], healthy["f"])
    per, groups = {}, []
    for code, d in damage.items():
        hit = model.felt(d["psd"], d["f"]).astype(float)
        per[code] = round(float(hit.mean()), 3)
        groups.append(hit)
    allhit = np.concatenate(groups)
    return {"detect": float(allhit.mean()), "detect_ci95_cluster_by_flight": cluster_boot_ci(groups),
            "false_alarms": f"{int(fa.sum())}/{len(fa)}", "false_alarm_ci95_exact": binom_ci(int(fa.sum()), len(fa)),
            "flights_caught_majority": f"{sum(v > 0.5 for v in per.values())}/{len(per)}", "per_flight": per}


def main():
    out = {"source": "Parrot Bebop 2 (PADRE)", "target": "3DR Solo (PADRE)", "skills": {}}
    machines = {
        "bebop": (feats("bebop", "0000"), {c: feats("bebop", c) for r in "BCD" for c in SINGLE[r]}, padre.FS),
        "solo": (feats("solo", "0000"), {c: feats("solo", c) for c in SOLO_DAMAGE}, solo.FS),
    }
    for name, make in skills().items():
        row = {}
        for mname, (h, dmg, fs) in machines.items():
            n = h["psd"].shape[0]
            cal = np.arange(n // 2)
            m = make().fit(h["psd"][cal], h["f"], fs)  # numbers relearned from healthy data only
            row[mname] = evaluate(m, h, dmg)
            if isinstance(m, OrderFeel):
                row[mname]["learned"] = m.meta
                row[mname]["where_felt_orders_median"] = {c: round(float(np.median(m.where(d["psd"], d["f"]))), 2)
                                                          for c, d in dmg.items()}
        out["skills"][name] = row
        print(f"{name:13s} Bebop detect {row['bebop']['detect']:.2f} FA {row['bebop']['false_alarms']} | "
              f"Solo detect {row['solo']['detect']:.2f} FA {row['solo']['false_alarms']} "
              f"flights {row['solo']['flights_caught_majority']}")
    # copy numbers: Bebop-fitted order_broad applied to the Solo unchanged -> arrival check
    hb, hs = machines["bebop"][0], machines["solo"][0]
    mb = OrderFeel().fit(hb["psd"][: hb["psd"].shape[0] // 2], hb["f"], padre.FS)
    ns = hs["psd"].shape[0]
    arr = mb.arrival(hs["psd"][: ns // 2], hs["f"])
    own = OrderFeel().fit(hs["psd"][: ns // 2], hs["f"], solo.FS).arrival(hs["psd"][ns // 2:], hs["f"])
    out["copy_numbers"] = {"healthy_solo_windows_inside_bebop_card": arr["inside"], "arrival_verdict": arr["verdict"],
                           "why": arr.get("why"),
                           "note": "A first version checked only z-scores and wrongly said 'fits' (the Bebop card's error "
                                   "bars were wide enough to swallow a different drone). Fixed by adding the proven-range "
                                   "check Physica uses everywhere else.",
                           "after_relearning_on_solo_heldout_inside": own["inside"], "after_relearning_verdict": own["verdict"],
                           "bebop_main_line_hz": mb.ref_hz,
                           "solo_main_line_hz": OrderFeel().fit(hs["psd"][: ns // 2], hs["f"], solo.FS).ref_hz}
    print("copy numbers:", out["copy_numbers"])
    save_result("E9_skill_transfer", out)


if __name__ == "__main__":
    main()
