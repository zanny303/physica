# v0.3 research integration (2026-10-30)

Source: user's 206-line Deep Research assessment of Physica v0.2.
Original v0.2 repository and its demos are retained in this updated archive.

New: dual-world calibrated disagreement module, dimensionless causal response
token, A→B signed synthetic experiment, unsafe action/mismatched-body refusal,
reproducible synthetic ablation, offline experience-lab UI, Meta Responses gateway,
visual forecast ingestion, docs and tests. Setuptools version 0.3.0 and pytest
path fixed so `pytest` works without manually setting `PYTHONPATH`.

Still missing: real physical A→B transfer experiment and independent witness,
calibrated visual-model forecast, SAM 3.1 tracking and V-JEPA 2 inference, live
Muse calls, benchmark versus strong transfer baselines and winning submission
video. A test passing on synthetic data does not make those features complete.
