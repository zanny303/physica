"""E6: one discovery, every machine's language.

(1) ArduPilot: the felt vibration mode on real PADRE damage flights -> harmonic-notch .param file ->
    the equivalent notch replayed on the same recorded vibration (in-band reduction, out-of-band change).
    Caveat: PADRE is a Parrot Bebop 2 sampled at 500 Hz, not an ArduPilot log; peaks may be aliased.
    Final check belongs in ArduPilot's Filter Review Tool with a real, permitted ArduPilot log.
(2) PLC: a wobble card -> IEC 61131-3 Structured Text -> Python mirror replay (trip before limit).
    Uses the Fraunhofer card if E2 has produced one; otherwise a clearly labelled synthetic card.
(3) Marlin M593 / Klipper: syntax-checked text from a felt mode (syntax only, no printer here).
"""
from __future__ import annotations

import json

import numpy as np

from common import SINGLE, CFG, healthy_split, padre_features, save_result
from physica import config
from physica.data import padre
from physica.feel.selfmodel import OperatingPointSelfModel
from physica.act import contract
from physica.translate import ardupilot, gcode, plc_st

OUT = config.RESULTS_DIR / "translations"


def ardupilot_part(sm, thr):
    rows = {}
    for r in "BCD":
        for c in SINGLE[r]:
            d = padre_features(c)
            z = sm.z(d["op"], d["lvl"])
            felt = z.max(axis=1) > thr
            if not felt.any():
                continue
            arm = int(np.bincount(z[felt].argmax(axis=1), minlength=4).argmax())
            freq = float(np.median(d["op"][felt, arm]))
            p = ardupilot.notch_params(freq, harmonics=1, mode=0)
            rec = padre.load(c)
            res = ardupilot.replay_notch(rec.acc[:, arm, :], padre.FS, p["INS_HNTCH_FREQ"], p["INS_HNTCH_BW"])
            fn = ardupilot.write_param_file(p, OUT / f"ardupilot_notch_{c}.param",
                                            header=[f"Physica: felt mode on arm {'ABCD'[arm]} of PADRE flight {c}",
                                                    "Static notch (MODE 0). Measured at 500 Hz: verify frequency on a full-rate log.",
                                                    "Advice, not a safety certification."])
            prom = contract.notch_promise(p["INS_HNTCH_FREQ"], p["INS_HNTCH_BW"])
            kept = contract.judge(prom, res)["verdict"] == "kept"
            # negative control: a deliberately mis-set notch (1.5x the felt frequency) must be caught and rolled back
            wrong = ardupilot.notch_params(1.5 * freq)
            res_w = ardupilot.replay_notch(rec.acc[:, arm, :], padre.FS, wrong["INS_HNTCH_FREQ"], wrong["INS_HNTCH_BW"],
                                           check_hz=p["INS_HNTCH_FREQ"], check_bw_hz=p["INS_HNTCH_BW"])
            caught = contract.judge(prom, res_w)["verdict"] == "rolled back"
            rows[c] = {"arm": "ABCD"[arm], "freq_hz": p["INS_HNTCH_FREQ"], "bw_hz": p["INS_HNTCH_BW"], **res,
                       "promise_kept": kept, "wrong_notch_hz": wrong["INS_HNTCH_FREQ"],
                       "wrong_notch_in_band_reduction_db": res_w["in_band_reduction_db"], "wrong_notch_rolled_back": caught,
                       "param_file": str(fn.relative_to(config.REPO_ROOT))}
    inb = [v["in_band_reduction_db"] for v in rows.values()]
    oob = [v["out_of_band_change_db"] for v in rows.values()]
    return {"flights": rows, "median_in_band_reduction_db": float(np.median(inb)) if inb else None,
            "promises_kept": int(sum(v["promise_kept"] for v in rows.values())),
            "wrong_notches_rolled_back": int(sum(v["wrong_notch_rolled_back"] for v in rows.values())),
            "promise": "shake at the felt frequency drops >= 10 dB and everything else moves < 3 dB",
            "median_out_of_band_change_db": float(np.median(oob)) if oob else None, "n": len(rows)}


def plc_part():
    calib, source = plc_st.calibration(config.RESULTS_DIR)
    st = plc_st.generate_st(calib, alarm_gmm=100.0, trip_gmm=130.0, card_id="wobble-card")
    (OUT / "FB_PhysicaFeel.st").write_text(st)
    problems = plc_st.check_structure(st)
    ramp = plc_st.ramp_test(calib, 100.0, 130.0)  # imbalance grows 0 -> 160 g*mm inside the proven range
    first_trip = ramp["trip_at_gmm"]
    return {"source": source, "structure_problems": problems, "trip_at_gmm": first_trip,
            "alarm_when_balanced": ramp["alarm_when_balanced"], "alarm_at_gmm": ramp["alarm_at_gmm"],
            "trip_setpoint_gmm": 130.0, "alarm_setpoint_gmm": 100.0,
            "limit_gmm": 152.1, "trips_before_limit": first_trip is not None and first_trip < 152.1,
            "st_file": str((OUT / "FB_PhysicaFeel.st").relative_to(config.REPO_ROOT)),
            "openplc": "Not run here. Load the .st into OpenPLC, check the %IW/%QX map, replay data via Modbus."}


def gcode_part(sm, thr):
    from physica.feel.dmd import dmd_modes

    rec = padre.load("0100")
    seg = rec.acc[: int(5 * padre.FS), 1, :]
    modes = [m for m in dmd_modes(seg - seg.mean(0), padre.FS, rank=12, delays=16) if 20 < m["freq_hz"] < 200]
    m = max(modes, key=lambda m: m["amplitude"])
    lines = gcode.marlin_m593(m["freq_hz"], min(max(m["damping_ratio"], 0.01), 0.5))
    (OUT / "input_shaping.gcode").write_text("\n".join(lines) + "\n")
    (OUT / "klipper_input_shaper.cfg").write_text(gcode.klipper_input_shaper(m["freq_hz"], m["freq_hz"]))
    return {"lines": lines, "all_valid": all(gcode.valid_m593(x) for x in lines),
            "note": "Syntax check only: the mode comes from a drone arm, not a printer. Demonstrates the translation path."}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    split = healthy_split()
    h = padre_features("0000")
    cal = np.array(split["calib"])
    sm = OperatingPointSelfModel(unit_names=list("ABCD")).fit(h["op"][cal], h["lvl"][cal])
    thr = sm.calibrate_threshold(h["op"][cal], h["lvl"][cal], CFG.q, CFG.margin)
    out = {"ardupilot": ardupilot_part(sm, thr), "plc": plc_part(), "marlin_klipper": gcode_part(sm, thr)}
    save_result("E6_translators", out)
    a = out["ardupilot"]
    print(f"ArduPilot notch on {a['n']} real damaged flights: in-band -{a['median_in_band_reduction_db']:.1f} dB (median), "
          f"out-of-band {a['median_out_of_band_change_db']:+.2f} dB | promises kept {a['promises_kept']}/{a['n']}, "
          f"wrong notches rolled back {a['wrong_notches_rolled_back']}/{a['n']}")
    print("PLC:", {k: out['plc'][k] for k in ('source', 'structure_problems', 'trip_at_gmm', 'trips_before_limit')})
    print("Marlin:", out["marlin_klipper"]["lines"], "valid:", out["marlin_klipper"]["all_valid"])


if __name__ == "__main__":
    main()
