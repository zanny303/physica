"""Reproducible, expressly synthetic action→sensation→learning→transfer exhibit."""
from __future__ import annotations
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
import json
import numpy as np
from .core import (Body,Sense,Interaction,predict_senses,compare_feeling,fit_physical_feeling,export_trial,
    sign_lesson,prepare_low_force_probe,check_low_force_probe,transfer_check,signed_forecast,
    verify_consequence,verify_lesson,verify_forecast,verify_reveal)


def mk_trial(body,senses,intervention_id,*,ratio,times,force,initial_state,seed):
    rng=np.random.default_rng(seed)
    physics=predict_senses(body,times,force,initial_state,senses,
                           friction_force_n=ratio*body.force_reference_n)
    ys={key:tuple(float(v) for v in (physics['sensations'][key]+rng.normal(0,s.noise_std,len(times))))
        for key,s in senses.items()}
    digest=sha256(json.dumps({'id':intervention_id,'signals':ys},sort_keys=True).encode()).hexdigest()
    return Interaction(intervention_id,body,tuple(float(x) for x in times),
        tuple(float(x) for x in force),tuple(float(x) for x in initial_state),
        ys,senses,digest,'simulation')


def _force(t,scale,frequency,phase=0.):
    return scale*np.sin(2*np.pi*frequency*t+phase)*np.sin(np.pi*np.minimum(t/1.2,1))**2


def make_lab(seed=2026):
    times=np.linspace(0.,1.2,241)
    A=Body('A_audio_touch',.09,22.,.10,.22,.27)
    B=Body('B_camera',.12,32.,.16,.25,.31)
    C=Body('C_proprioception',.10,27.,.13,.24,.28)
    Sa={'mic':Sense('mic','hearing','Pa',(0.,130.),0.,.025,'calibration_mic_A_01'),
        'tactile':Sense('tactile','touch','mV',(420.,0.),0.,.035,'calibration_strain_A_01')}
    Sb={'camera':Sense('camera','sight','mm',(1000.,0.),0.,.032,'camera_B_independent_scale')}
    Sc={'encoder':Sense('encoder','proprioception','counts/s',(0.,175.),0.,.04,'encoder_C_calibrated')}
    source_ratio=.135
    training=[mk_trial(A,Sa,f'A_train_{i}',ratio=source_ratio,times=times,
         force=_force(times,.11+.02*i,2.2+i*.8,phase=.3*i),initial_state=(.012+i*.001,.11+i*.02),seed=seed+i)
              for i in range(3)]
    validation=[mk_trial(A,Sa,'A_heldout_new_action',ratio=source_ratio,times=times,
         force=_force(times,.16,4.1,phase=.4),initial_state=(.01,.16),seed=seed+9)]
    fit=fit_physical_feeling(training,validation)
    if fit['status']!='SUPPORTED_HELDOUT':raise RuntimeError(f'A source mechanism not supported: {fit}')
    lesson=sign_lesson(fit,A,evidence_digests=[t.evidence_sha256 for t in training+validation])
    probe_force=_force(times,.06,2.8)
    probe=prepare_low_force_probe(lesson,B,Sb,times,probe_force,(.004,.06))
    # Only now create the simulated future probe result.
    bprobe_observed=mk_trial(B,Sb,'B_low_force_probe',ratio=source_ratio,times=times,
         force=probe_force,initial_state=(.004,.06),seed=seed+21)
    checked_probe=check_low_force_probe(lesson,probe,bprobe_observed)
    gate=transfer_check(lesson,B,Sb,local_probe=checked_probe)
    full_force=_force(times,.16,3.4)
    full_forecast=signed_forecast(lesson,B,Sb,times,full_force,(.01,.13),probe=checked_probe)
    # Main target measurements generated only *after* sealed prediction is ready.
    btest=mk_trial(B,Sb,'B_blind_after_seal',ratio=source_ratio,times=times,
           force=full_force,initial_state=(.01,.13),seed=seed+25)
    bverify=verify_consequence(full_forecast,btest) if verify_forecast(full_forecast) else {'status':'ABSTAIN'}
    # B becomes a second evidence source only if B verification succeeded.
    btrain=[bprobe_observed,btest]
    bval=mk_trial(B,Sb,'B_independent_validation',ratio=source_ratio,times=times,
        force=_force(times,.10,4.5,phase=.4),initial_state=(.008,.11),seed=seed+30)
    bfit=fit_physical_feeling(btrain,[bval],prior=(fit['normalized_friction_ratio'],max(.025,fit['approximate_parameter_se'])))
    # C gets a new, independent probe: neither A nor B measurements are C's response.
    lesson2=sign_lesson(bfit,B,evidence_digests=[t.evidence_sha256 for t in btrain+[bval]]) if bfit['status']=='SUPPORTED_HELDOUT' else None
    cprobe=None;c_gate=None;c_forecast=None;c_reveal=None
    if lesson2:
        cforce=_force(times,.06,3.)
        cprobe_forecast=prepare_low_force_probe(lesson2,C,Sc,times,cforce,(.004,.075))
        cmeasure=mk_trial(C,Sc,'C_low_force_probe',ratio=source_ratio,times=times,
            force=cforce,initial_state=(.004,.075),seed=seed+32)
        cprobe=check_low_force_probe(lesson2,cprobe_forecast,cmeasure)
        c_gate=transfer_check(lesson2,C,Sc,local_probe=cprobe)
        cforce2=_force(times,.13,3.6)
        c_forecast=signed_forecast(lesson2,C,Sc,times,cforce2,(.009,.12),probe=cprobe)
        cmeasure2=mk_trial(C,Sc,'C_blind_after_seal',ratio=source_ratio,times=times,
           force=cforce2,initial_state=(.009,.12),seed=seed+34)
        c_reveal=verify_consequence(c_forecast,cmeasure2) if verify_forecast(c_forecast) else {'status':'ABSTAIN'}
    surprise_before=compare_feeling(validation[0],friction_force_n=0.)
    surprise_after=compare_feeling(validation[0],friction_force_n=fit['normalized_friction_ratio']*A.force_reference_n)
    alt_B=Body('B_changed_mount',.12,32.,.16,.25,.31,boundary_class='free_free')
    rejected=transfer_check(lesson,alt_B,Sb)
    return {'schema':'physica.predictive-feeling.demo.v06','origin':'simulation',
            'source_estimate':fit,'source_lesson':lesson,'source_signature_ok':verify_lesson(lesson),
            'source_train':training,'source_validation':validation,'B_probe_trial':bprobe_observed,
            'B_main_trial':btest,'B_validation_trial':bval,
            'surprise_before_learning':surprise_before,'surprise_after_learning':surprise_after,
            'B_probe':checked_probe,'B_transfer_gate':gate,'B_sealed_forecast':full_forecast,
            'B_reveal':bverify,'B_new_experience':bfit,'B_updated_lesson':lesson2,
            'C_probe':cprobe,'C_gate':c_gate,'C_sealed_forecast':c_forecast,'C_reveal':c_reveal,
            'C_probe_trial':cmeasure if lesson2 else None, 'C_main_trial':cmeasure2 if lesson2 else None,
            'incompatible_body_refusal':rejected,
            'no_live_Meta_calls':True,'no_real_hardware_measurements':True,
            'does_not_prove_subjective_feeling':True}


def create_demo(output,seed=2026):
    root=Path(output);root.mkdir(parents=True,exist_ok=True)
    d=make_lab(seed)
    for key in ('source_lesson','B_sealed_forecast','B_reveal','B_updated_lesson','C_sealed_forecast','C_reveal','B_probe','C_probe'):
        if d.get(key) is not None:(root/(key+'.json')).write_text(json.dumps(d[key],indent=2)+'\n')
    for key in ('source_train','source_validation','B_probe_trial','B_main_trial','B_validation_trial','C_probe_trial','C_main_trial'):
        entry=d.get(key)
        if entry is not None:
            value=[export_trial(t) for t in entry] if isinstance(entry,list) else export_trial(entry)
            (root/(key+'_SYNTHETIC.json')).write_text(json.dumps(value,indent=2)+'\n')
    for label,body,senses,probe_trial,main_trial in (
        ('B',d['B_probe_trial'].body,d['B_probe_trial'].senses,d['B_probe_trial'],d['B_main_trial']),
        ('C',d['C_probe_trial'].body if d['C_probe_trial'] else None,
         d['C_probe_trial'].senses if d['C_probe_trial'] else None,d['C_probe_trial'],d['C_main_trial'])):
        for phase,trial in (('probe',probe_trial),('main',main_trial)):
            if trial is not None:
                request={'body':asdict(body),'senses':{k:asdict(v) for k,v in senses.items()},
                         'time_s':list(trial.times_s),'force_n':list(trial.applied_force_n),
                         'initial_state':list(trial.initial_state_m_m_s)}
                (root/(label+'_'+phase+'_request.json')).write_text(json.dumps(request,indent=2)+'\n')
    ignore={'source_lesson','B_sealed_forecast','B_reveal','B_updated_lesson','C_sealed_forecast','C_reveal',
            'B_probe','C_probe','source_train','source_validation','B_probe_trial',
            'B_main_trial','B_validation_trial','C_probe_trial','C_main_trial'}
    summary={k:v for k,v in d.items() if k not in ignore}
    summary['B_result']=d['B_reveal']['status'];summary['C_result']=d['C_reveal']['status'] if d['C_reveal'] else 'not_run'
    (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (root/'experience_lab.html').write_text(render_lab(d))
    return summary


def render_lab(d):
    p=d['B_sealed_forecast']['forecast']
    curve={'time':p['time_s'],'predicted':p['prediction']['camera'],
           'label':'Camera (mm)','source_ratio':d['source_estimate']['normalized_friction_ratio'],
           'results':{'B':d['B_reveal']['status'],'C':d['C_reveal']['status'] if d['C_reveal'] else 'no_result',
                      'changed_mount':d['incompatible_body_refusal']['reason']},
           'evidence':{'A':d['source_lesson']['sha256'],'B_forecast':d['B_sealed_forecast']['sha256'],
                       'C_forecast':d['C_sealed_forecast']['sha256'] if d['C_sealed_forecast'] else ''}}
    data=json.dumps(curve).replace('</','<\\/')
    return '''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Physica v0.6 | Feeling Laboratory</title><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{background:#081625;color:#e2f3ff;font:16px system-ui;margin:auto;max-width:1050px;padding:28px}h1{font-size:2.5rem}h2{color:#7fe5d4}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.card{background:#102639;border:1px solid #335363;border-radius:13px;padding:18px}small,p{color:#b8cedb}strong{color:#a5ffe0}canvas{width:100%;background:#071b2c;border-radius:10px}code{word-break:break-all;font-size:12px}</style></head><body><h1>PHYSICA <small>v0.6</small></h1><h2>Giving AI the ability to feel</h2><p><strong>SIMULATION ONLY</strong> — action-conditioned sensory prediction, mismatch detection, verified experience, and cross-body transport. Not machine consciousness, live Meta inference, or a hardware trial.</p><div class="grid"><div class="card"><h2>A · Feels</h2><p>Calibrated microphone pressure + tactile displacement. The difference between expected and observed sensations reveals a missing contact-friction response.</p></div><div class="card"><h2>B · Predicts</h2><p>A's signed experience predicts B's camera response. Low-force measurement must verify applicability first.</p></div><div class="card"><h2>C · Learns</h2><p>B's verified outcome becomes a signed lesson, translated into C's proprioceptive encoder units.</p></div></div><h2>Action → predicted feeling</h2><canvas id="curve" width="960" height="260"></canvas><p>Solid trace: SEALED conditional prediction. The complete observed response is stored in the separate signed reveal record. The image is not a recording of hardware.</p><div class="grid"><div class="card" id="res"></div><div class="card"><h2>When feeling cannot transfer</h2><p id="refusal"></p></div></div><h2>Audit-ready commitments</h2><div id="hashes"></div><p><small>Ed25519 signatures authenticate local records but do not witness experiment time. Model-conditional synthetic checks; not independently calibrated risk.</small></p><script>const D=__DATA__;let c=document.getElementById('curve'),x=c.getContext('2d'),t=D.time,y=D.predicted;const left=42,right=c.width-22,top=24,bottom=c.height-42,min=Math.min(...y),max=Math.max(...y),T=t[t.length-1]-t[0],Y=max-min||1; x.fillStyle='#092536';x.fillRect(0,0,c.width,c.height);x.strokeStyle='#33536c';for(let k=0;k<5;k++){let h=top+(bottom-top)*k/4;x.beginPath();x.moveTo(left,h);x.lineTo(right,h);x.stroke()}x.strokeStyle='#71f3d3';x.lineWidth=2.5;x.beginPath();t.forEach((v,i)=>{let a=left+(right-left)*(v-t[0])/T,b=bottom-(bottom-top)*(y[i]-min)/Y;i?x.lineTo(a,b):x.moveTo(a,b)});x.stroke();x.fillStyle='#deefff';x.font='14px system-ui';x.fillText(D.label+' · synthetic sealed prediction',left,18);document.getElementById('res').innerHTML='<h2>Signed results</h2><p>B: <strong>'+D.results.B+'</strong></p><p>C: <strong>'+D.results.C+'</strong></p><p>Source normalized friction: '+D.source_ratio.toFixed(4)+'</p>';document.getElementById('refusal').textContent=D.results.changed_mount;document.getElementById('hashes').innerHTML=Object.entries(D.evidence).map(([k,v])=>'<p>'+k+': <code>'+v+'</code></p>').join('');</script></body></html>'''.replace('__DATA__',data)
