"""Optional live Meta Muse science review on non-sensitive numeric experiment summary.
Never acts on hardware, never edits executable controller files, never asserts hypothesis is established.
"""
import argparse,json,os,urllib.request
from pathlib import Path

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--report',required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--model',choices=['muse-spark-1.3','muse-wonder-1.0'],default='muse-spark-1.3')
    ap.add_argument('--allow-billed-meta',action='store_true');a=ap.parse_args()
    if not a.allow_billed_meta:raise SystemExit('Refused: --allow-billed-meta is required')
    key=os.environ.get('MODEL_API_KEY')
    if not key:raise SystemExit('MODEL_API_KEY is missing; set in local Terminal')
    doc=json.loads(Path(a.report).read_text(encoding='utf-8'))
    # Minimize sent data: only source and aggregate metrics, not raw local recordings.
    safe={'origin':doc.get('origin'),'algorithm':doc.get('algorithm'),'metrics':doc.get('metrics'),'limitations':doc.get('limitations')}
    prompt='You are a scientific critic. Give 2 falsifiable hypotheses, 2 safe NON-ACTUATING measurements, competing no-Meta baselines, and explicit uncertainty. Never invent observed measurements. The numerical Physica experiment summary is: '+json.dumps(safe)
    from physica.llm import meta_client as mc
    result=mc.post_raw('chat/completions',{'model':a.model,'messages':[{'role':'user','content':prompt}],'max_completion_tokens':1500},task='latent_meta_scientist')
    out={'origin':'AUTHENTICATED_META_API_RESPONSE','model':a.model,'raw_response':result,'sent_data_summary':safe,'scientific_validation':'hypotheses only; not evidence of mechanism'}
    path=Path(a.out);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(out,indent=2),encoding='utf-8')
    print('Saved authenticated suggestion response:',path)
if __name__=='__main__':main()
