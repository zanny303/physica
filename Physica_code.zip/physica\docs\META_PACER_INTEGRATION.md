# Meta's roles in Physica

Physica's original repository already has an offline-first Meta client (`physica/llm/meta_client.py`), Muse Wonder tool loop (`physica/agents/wonder_agent.py`), and Glimmer gate. This extension adds `physica.experience.meta.review` with tool/action whitelisting and audit hashes.

| Component | Intended role | Status in THIS ZIP |
|---|---|---|
| Muse Wonder | Interpret grounded numerical facts; generate and critique hypotheses; advise on safe authorized actions and explain uncertainty | **Live-capable via configurable Meta Model API** if endpoint, valid credentials, model identifier and prices are supplied; not live-tested here. Defaults to explicitly labelled `mock`. |
| Muse Spark | Tool orchestration / alternative scientific reviewer | Same live-capable adapter, configuration required, not tested live here. |
| Muse Glimmer | Optional on-device alternative/low-latency agent | Existing Glimmer adapter in original source; local weights/server not included. |
| SAM 3.1 / SAM 2 | Detect, segment, track physical parts in video | Designed integration role; **not wired into the new episode ingest**. Existing Physica video extraction uses its own signal processing/OpenCV. |
| V-JEPA 2 | Visual dynamics prior, candidate state prediction / world-model comparison | Planned experimental integration; no model weights, inference or verified benchmark here. |
| Muse Image | Visual identity for submission if required | Not used; not necessary for physical causality. |

To run configured Muse mode, use the *original* `.env.example`, supplying values **from Meta's actual developer documentation**:

```dotenv
MOCK=0
META_API_BASE_URL=<provider-endpoint>
META_API_KEY=<your-secret>
MODEL_WONDER=<real-model-identifier>
MODEL_SPARK=<real-model-identifier>
PRICE_WONDER_IN=<usd-per-million-input-tokens>
PRICE_WONDER_OUT=<usd-per-million-output-tokens>
PRICE_SPARK_IN=<usd-per-million-input-tokens>
PRICE_SPARK_OUT=<usd-per-million-output-tokens>
```

The original client assumes an OpenAI-style `/chat/completions` endpoint; validate this assumption against the service actually provisioned for your account. Running `physica experience muse-review facts.json --allowed mount_compliance_check --role wonder` produces `mode=live` only when the client is configured and goes through that call path; otherwise it clearly reports `mode=mock`. A response containing a non-whitelisted action is rejected (`null`). No LLM may change numeric posterior values, inferred units, risk-score cutoffs or raw sensor measurements.

For additional honesty, Muse model names are not hardcoded: availability varies by account/API surface. Existing internal mocked examples must not be represented as live successful calls.

## Live integration acceptance tests

- Feed identical fixed sensor measurements to the Muse reviewer in live mode; record request hash, response hash, exact model ID and access conditions.
- Check action whitelist: hallucinated dangerous actions must be rejected.
- Benchmark SAM ROI tracking stability versus the original custom video ROI extraction on nuisance camera motion.
- Compare V-JEPA conditional predictions against the original explicit twin, on held-out real clips with calibration, covering disagreement and uncertainty instead of silently averaging.
- Run PACER+Muse versus PACER alone to measure any improvement in experiment choice or human diagnostic quality; quantify whether Meta models are indeed central rather than cosmetic.

**Do not claim the live integration has been validated until these are executed with authorised access.**
