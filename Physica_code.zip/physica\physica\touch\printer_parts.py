"""SAM names the parts, and Physica feels each one: which parts of the machine shake, and how much, at the head's tone.

A crop can only say the head rings. With each part measured on its own, a tone shared by the frame points to the printer
rocking on its table, which a test on the head alone can't show. Readings are pixels of motion in the same film, so they compare
parts with each other. They aren't calibrated displacement.
"""
from __future__ import annotations

import numpy as np

from physica.touch import printer_video as PV
from physica.touch import video
from physica.touch.printer_video import ringing_amp

MOVES_WITH_HEAD = 0.5
STILL_BELOW = 0.1


def part_ringing(V: np.ndarray, fps: float, box: tuple[int, int, int, int] | None, f: float, p: dict = PV.EXCITE, mask_at=None) -> dict:
    """Ringing at tone f in the moments after each stop. box is in the film's loaded pixels. With mask_at(frame), SAM's mask for that
    moment chooses the pixels, so a part that travels between stops is still read on its own."""
    amps = []
    for w in PV.pauses(V, fps, p):
        keep = None
        if mask_at is not None:
            m = mask_at(int(w.start))
            ys, xs = np.where(m) if m is not None else ((), ())
            if not len(xs):
                continue
            x1, y1, x2, y2 = max(int(xs.min()) - 4, 0), max(int(ys.min()) - 4, 0), int(xs.max()) + 5, int(ys.max()) + 5
            keep = m[y1:y2, x1:x2]
        else:
            x1, y1, x2, y2 = box
        seg = V[w][:, y1:y2, x1:x2]
        if seg.shape[1] < 8 or seg.shape[2] < 8 or len(seg) < 20:
            continue
        M = video.motion(seg, wavelength=6, sigma=2.5, step=2, keep=0.3 if keep is not None else 0.15, direction="horizontal")
        Y = M["signals"]
        if keep is not None:
            inside = keep[M["rows"], M["cols"]]
            if inside.sum() < 4:
                continue
            Y = Y[:, inside]
        amps.append(ringing_amp(Y, fps, f))
    return {"ringing_px": round(float(np.median(amps)), 4) if amps else None, "stops": len(amps)}


def wall_ripple(before: np.ndarray, after: np.ndarray, shortest_px: float = 3.0) -> dict:
    """How much the ripple on a flat wall shrank, from two photos taken the same way: light low and from the side, same distance, and cropped to the same
    part of the wall, with layers running left to right. It finds the ripple's period in the first photo, and reads the same period in the second.
    It's a relative score for these two photos, not a depth in millimetres."""
    def profile(g):
        y = g.astype(np.float64).mean(0)
        x = np.arange(len(y))
        y = y - np.polyval(np.polyfit(x, y, 3), x)
        return y * np.hanning(len(y)) / max(g.mean(), 1e-6)
    a, b = profile(before), profile(after)
    A, B = np.abs(np.fft.rfft(a)), np.abs(np.fft.rfft(b))
    low, high = 6, int(len(a) / shortest_px)      # at least six ripples across the crop, so shading can't pass for a ripple
    if high <= low + 2:
        return {"status": "CANT_TELL", "reason": "the crop is too small to read a ripple"}
    i = low + int(np.argmax(A[low:high]))
    floor = float(np.median(A[low:high]))
    if A[i] < 4 * floor:
        return {"status": "CANT_TELL", "reason": "no clear ripple in the first photo", "contrast": round(float(A[i] / max(floor, 1e-12)), 1)}
    got = float(np.interp(i * (len(B) - 1) / (len(A) - 1), np.arange(len(B)), B))      # the same period in the second photo, read the same way
    return {"status": "MEASURED", "period_px": round(len(a) / i, 1), "before": round(float(A[i]), 4), "after": round(got, 4), "drop": round(1 - got / float(A[i]), 3),
            "limit": "Two photos, same light. A relative score, not a depth."}


def blind_pack(pairs: list[tuple[str, str]], out_dir, seed: int) -> dict:
    """Unlabelled photos for someone who doesn't know which part is which. The key is sealed, and stays closed until they've chosen."""
    import shutil
    from pathlib import Path

    from physica import seal as _seal
    rng = np.random.default_rng(seed)
    out, key = Path(out_dir), []
    out.mkdir(parents=True, exist_ok=True)
    for i, (before, after) in enumerate(pairs, 1):
        order = [(before, "before"), (after, "after")]
        if rng.random() < .5:
            order.reverse()
        for letter, (path, kind) in zip("AB", order):
            shutil.copyfile(path, out / f"pair{i}_{letter}{Path(path).suffix.lower()}")
            key.append({"pair": i, "letter": letter, "is": kind})
    sealed = _seal.seal({"key": key}, "which photo is which, before anyone chooses")
    return {"folder": str(out), "anchor": sealed["anchor"], "sealed": sealed, "ask": "Which photo in each pair has the smoother wall? They should write down A or B before seeing the key."}


def read_parts(V: np.ndarray, fps: float, boxes: dict[str, tuple[int, int, int, int]], f: float, reference: str, p: dict = PV.EXCITE, masks: dict | None = None) -> dict:
    rows = {name: part_ringing(V, fps, None, f, p, masks[name]) if masks and name in masks else part_ringing(V, fps, boxes[name], f, p) for name in (list(masks) if masks else list(boxes))}
    ref = (rows.get(reference) or {}).get("ringing_px")
    if not ref:
        return {"status": "CANT_TELL", "reason": f"no clear ringing measured on {reference}", "parts": rows, "tone_hz": round(f, 2), "reference": reference}
    for name, r in rows.items():
        if r["ringing_px"] is None:
            r["reading"] = "not enough to read"
            continue
        r["relative_to_reference"] = round(r["ringing_px"] / ref, 3)
        r["reading"] = ("the reference" if name == reference else "moves with it" if r["relative_to_reference"] >= MOVES_WITH_HEAD
                        else "nearly still" if r["relative_to_reference"] < STILL_BELOW else "moves a little")
    return {"status": "MEASURED", "parts": rows, "tone_hz": round(f, 2), "reference": reference, "limit": "Pixel motion in one film, not calibrated displacement"}
