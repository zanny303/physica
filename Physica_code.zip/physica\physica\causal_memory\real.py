"""Controlled-action CSV evaluation. Real provenance is declared, never assumed.

CSV required: body_id,split,position,velocity,action,acceleration,intervention_type
split is train/validation/test, body IDs of test must differ from train.
Units must be independently calibrated by user; no independent verification.
"""
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np
from .core import fit,error,choose_mechanism

def train_csv(csv_path,out,*,origin='user_declared_real'):
    path=Path(csv_path);groups={'train':[],'validation':[],'test':[]};ids={k:set() for k in groups}
    with path.open(encoding='utf-8-sig',newline='') as fh:
        for record in csv.DictReader(fh):
            group=record.get('split','')
            if group not in groups:raise ValueError('split must be train, validation, or test')
            body=record.get('body_id','')
            if not body:raise ValueError('body_id required')
            row={'body_id':body,'state':[float(record['position']),float(record['velocity'])],
                'action':float(record['action']),'acceleration':float(record['acceleration']),
                'intervention_type':record.get('intervention_type')}
            groups[group].append(row);ids[group].add(body)
    if (ids['train']&ids['test']) or (ids['validation']&ids['test']):
        raise ValueError('test body leaks into train or validation')
    if len(groups['train'])<6 or not groups['validation'] or not groups['test']:raise ValueError('need nonempty disjoint train/validation/test')
    result=choose_mechanism(groups['train'],groups['validation']);coeff=np.asarray(result['coefficients'])
    target_fit=None
    # No target adaptation in this strict zero-shot version
    result.update({'origin':origin,'real_measurements_independently_verified':False,
                   'provenance_user_declared':True,'causal_assumption':'actions must be supervised interventions with measured confounders',
                   'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                   'train_bodies':sorted(ids['train']),'validation_bodies':sorted(ids['validation']),
                   'test_bodies':sorted(ids['test']),'test_rmse':error(groups['test'],coeff),
                   'records_per_split':{k:len(v) for k,v in groups.items()},
                   'model':'regularized prescribed linear/nonlinear physical features; not a foundation model'})
    output=Path(out);output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('csv');ap.add_argument('--out',required=True)
    args=ap.parse_args();r=train_csv(args.csv,args.out);print(json.dumps({'test_rmse':r['test_rmse'],'test_bodies':r['test_bodies']},indent=2))
if __name__=='__main__':main()
