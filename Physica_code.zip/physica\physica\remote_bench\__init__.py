"""Reproducible grouped evaluation of public recorded physical signals.

Real source recordings are downloaded by the researcher under their dataset license;
Physica never presents synthetic demonstrations as external validation.
"""
