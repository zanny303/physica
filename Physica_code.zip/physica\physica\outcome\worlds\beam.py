"""The beam's sensed map: where the support sits -> the tone the beam rings at, with error bars.

Built only from what the machine felt: every stretch where the actuator held
the roller still, the first tone heard there by BOTH accelerometers (a point is
kept only when the two agree within 3%). The map is a smooth curve through
those points; its error bar is split-conformal and local (the 90% quantile of
held-out misses within 0.3 V of the query), so it is wide where the beam is
moody (near the clamp the tone flips between ~24 and ~26 Hz) and narrow where
it is not. Outside the positions it has felt, it refuses.

Data: DROPBEAR Dataset-8 (see physica.data.dropbear). Set PHYSICA_DROPBEAR8 to its data/ folder.
"""
from __future__ import annotations

import glob
import os
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass

import numpy as np
from scipy import signal

from physica.cause.track import esprit
from physica.data.dropbear import MM_PER_VOLT_D8, load_d8

FS = 5000.0


def dwells(pin: np.ndarray, fs: float = FS, min_s: float = 0.35, tol: float = 0.006):
    """Index ranges where the roller sat still."""
    pm = signal.medfilt(pin, 101)
    out, i, n = [], 0, len(pm)
    while i < n:
        j = i
        while j < n and abs(pm[j] - pm[i]) < tol:
            j += 1
        if (j - i) / fs >= min_s:
            out.append((i, j))
        i = max(j, i + 1)
    return out


def first_tone(x: np.ndarray, fs: float = FS, band=(15.0, 90.0)) -> float:
    """First bending tone (Hz) of a still stretch, or nan. 60 Hz mains hum is skipped."""
    y = signal.decimate(signal.decimate(np.asarray(x, float) - np.mean(x), 5), 5)
    f2 = fs / 25
    y = signal.sosfiltfilt(signal.butter(4, [12, 95], "bandpass", fs=f2, output="sos"), y)
    f, z, a = esprit(y, f2, order=12)
    k = (f > band[0]) & (f < band[1]) & (z > -0.005) & (z < 0.1) & (np.abs(f - 60) > 1.5)
    return float(f[np.argmax(np.where(k, a, 0))]) if k.any() else float("nan")


def _group(fn: str) -> str:
    return ("sweep" if "Slow Postional" in fn else "standard" if "Standard Index" in fn
            else "random" if "Random Index Set Random Dwell" in fn else "other")


def _points(fn: str, agree: float = 0.03):
    d = load_d8(fn)
    pin, low, high = d["pin_v"], d["channels"]["Low G Accel"], d["channels"]["Accel"]
    rows = []
    for i, j in dwells(pin, d["fs"]):
        s = i + int(0.03 * d["fs"])
        fl, fh = first_tone(low[s:j], d["fs"]), first_tone(high[s:j], d["fs"])
        ok = np.isfinite(fl) and np.isfinite(fh) and abs(fl - fh) <= agree * fl
        rows.append((float(np.median(pin[i:j])), (fl + fh) / 2 if ok else np.nan, fl, fh, (j - i) / d["fs"], i / d["fs"]))
    return fn, rows


DT = [("file", "U200"), ("group", "U10"), ("pin_v", "f8"), ("tone_hz", "f8"), ("tone_low", "f8"),
      ("tone_high", "f8"), ("dur_s", "f8"), ("t_s", "f8")]


def tone_points(data_dir: str | None = None, cache: str | None = None, workers: int | None = None) -> np.ndarray:
    """Every still stretch in every trial: file, group (sweep / standard / random), pin_v, tone_hz (nan if the
    two accelerometers disagree), the two raw tones, duration and start time."""
    if cache and os.path.exists(cache):
        return np.load(cache, allow_pickle=False)["points"]
    root = data_dir or os.environ.get("PHYSICA_DROPBEAR8", "")
    files = sorted(glob.glob(os.path.join(root, "**", "test*.txt"), recursive=True))
    if not files:
        raise FileNotFoundError("DROPBEAR Dataset-8 trials not found; set PHYSICA_DROPBEAR8 to the dataset's data/ folder")
    with ProcessPoolExecutor(workers) as ex:
        res = list(ex.map(_points, files))
    pts = np.array([(os.path.relpath(fn, root), _group(fn), *r) for fn, rows in res for r in rows], dtype=DT)
    if cache:
        os.makedirs(os.path.dirname(cache) or ".", exist_ok=True)
        np.savez_compressed(cache, points=pts)
    return pts


def presets(points: np.ndarray, tol: float = 0.02, min_count: int = 2) -> np.ndarray:
    """Positions the actuator's index set actually commands (clusters of still stretches)."""
    v = np.sort(points["pin_v"])
    groups, cur = [], [v[0]]
    for x in v[1:]:
        if x - cur[-1] <= tol:
            cur.append(x)
        else:
            groups.append(cur)
            cur = [x]
    groups.append(cur)
    return np.array([np.median(g) for g in groups if len(g) >= min_count])


@dataclass
class BeamWorld:
    """Knob: support position (transducer volts; mm = volts x 45). Quantity: first tone (Hz)."""
    coef: np.ndarray
    cal_v: np.ndarray
    cal_res: np.ndarray
    v_range: tuple
    coverage: float = 0.9
    window_v: float = 0.3
    machine: str = "beam"
    knob: str = "support position"

    @classmethod
    def learn(cls, points: np.ndarray, coverage: float = 0.9, deg: int = 3, seed: int = 0) -> "BeamWorld":
        p = points[np.isfinite(points["tone_hz"])]
        files = np.unique(p["file"])
        rng = np.random.default_rng(seed)
        half = set(rng.permutation(files)[: len(files) // 2])
        a = np.array([f in half for f in p["file"]])
        coef = np.polyfit(p["pin_v"][a], p["tone_hz"][a], deg)  # the curve sees only the fitting half
        res = np.abs(p["tone_hz"][~a] - np.polyval(coef, p["pin_v"][~a]))  # misses on the calibration half
        # Proper split conformal: the curve is never refit with the calibration half. The local window makes the bar
        # adapt to where the beam is moody; that locality is a heuristic, so coverage is checked on another day.
        return cls(coef, p["pin_v"][~a], res, (float(p["pin_v"].min()), float(p["pin_v"].max())), coverage)

    def in_range(self, v: float) -> bool:
        return self.v_range[0] - 1e-9 <= v <= self.v_range[1] + 1e-9

    def half_width(self, v: float) -> float:
        k = np.abs(self.cal_v - v) <= self.window_v
        r = self.cal_res[k] if k.sum() >= 15 else self.cal_res
        n = len(r)
        q = min(1.0, np.ceil((n + 1) * self.coverage) / n)
        return float(np.quantile(r, q))

    def predict(self, v: float) -> dict:
        if not self.in_range(v):
            return {"refused": True, "why": f"{v:.3f} V is outside the positions this beam has felt "
                    f"({self.v_range[0]:.2f}-{self.v_range[1]:.2f} V)"}
        m, h = float(np.polyval(self.coef, v)), self.half_width(v)
        return {"refused": False, "tone_hz": m, "lo": m - h, "hi": m + h}

    @staticmethod
    def mm(v: float) -> float:
        return float(v) * MM_PER_VOLT_D8

    # --- engineer interface -------------------------------------------------------------------
    def candidates(self, spec, state):
        grid = state.get("presets")
        if grid is None:
            grid = np.arange(self.v_range[0], self.v_range[1] + 1e-9, 0.01)
        return [{"support_v": float(v)} for v in grid]

    def outcome(self, action):
        return self.predict(action["support_v"])

    def feasible(self, spec, pred, use_error_bar: bool = True):
        if pred.get("refused"):
            return False, pred["why"]
        F, pct = spec.context["forcing_hz"], spec.get("tone_hz", "outside_band_pct")
        lo_band, hi_band = F * (1 - pct / 100), F * (1 + pct / 100)
        lo, hi = (pred["lo"], pred["hi"]) if use_error_bar else (pred["tone_hz"], pred["tone_hz"])
        ok = hi < lo_band or lo > hi_band
        return ok, ("whole error bar clear of" if ok else "error bar touches") + f" {lo_band:.1f}-{hi_band:.1f} Hz"

    def cost(self, spec, action, pred, state):
        move = abs(action["support_v"] - state["support_v"]) * MM_PER_VOLT_D8
        F = spec.context["forcing_hz"]
        clearance = min(abs(pred["lo"] - F), abs(pred["hi"] - F)) / F
        return (-clearance, move) if spec.objective == "max_clearance" else (move, -clearance)

    def describe(self, action, pred, state):
        mv = (action["support_v"] - state["support_v"]) * MM_PER_VOLT_D8
        return (f"move the support {mv:+.1f} mm (to {self.mm(action['support_v']):.1f} mm): tone "
                f"{pred['tone_hz']:.1f} Hz, sealed {pred['lo']:.1f}-{pred['hi']:.1f} Hz")
