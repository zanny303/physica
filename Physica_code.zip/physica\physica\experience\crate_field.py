"""CRATE field protocol: signed source experiences -> sealed B forecast -> measured B.

No automatic hardware control. Sensor files, calibrations and clocks are supplied
by an operator; signatures prove integrity but NOT acquisition time or truth.
This module never reads B observations in prepare(). A contradictory outcome is
usable *learning evidence*, not a basis to rewrite a previously sealed forecast.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import numpy as np
from physica.library import sign as S

from .causal_transport import trace, fit_memory, conformal_calibrate, aligned_residual
from .field_protocol import read_csv, read_calibration, file_hash, _hash_json
from .schema import PhysicalEpisode, Provenance, Quantity
from .seal import seal, reveal, verify_seal, verify_reveal, write_json
from .transport import BodyCalibration, compatibility, local_verify
from .frontier_demo import _episode


def _resolve_manifest(manifest_path):
    p=Path(manifest_path).resolve()
    doc=json.loads(p.read_text())
    if not isinstance(doc,dict) or not isinstance(doc.get('training'),list):
        raise ValueError('source manifest must contain training array')
    def load_rows(key):
        result=[]
        for row in doc.get(key,[]):
            if not isinstance(row,dict) or not all(k in row for k in ('reveal','sensor_csv','calibration')):
                raise ValueError('manifest row requires reveal, sensor_csv, calibration')
            result.append({k:str((p.parent/row[k]).resolve()) for k in ('reveal','sensor_csv','calibration')})
        return result
    return load_rows('training'),load_rows('calibration'),file_hash(p)


def _source_trace(row):
    record=json.loads(Path(row['reveal']).read_text())
    if not verify_reveal(record) or record.get('result')!='verified':
        raise ValueError('source must have a valid signed verified reveal')
    episode=PhysicalEpisode.model_validate(record['episode'])
    if episode.provenance.origin!='real_sensor':
        raise ValueError('simulation cannot enter real-sensor CRATE field protocol')
    if record.get('observation_sha256')!=file_hash(row['sensor_csv']):
        raise ValueError('signed source record does not hash-link sensor CSV')
    cal=read_calibration(row['calibration'])
    if (episode.machine_id!=cal.machine_id or episode.boundary_class!=cal.boundary_class
        or episode.action.action_type!=cal.action_class
        or not episode.sensors or not all(s.calibrated for s in episode.sensors)):
        raise ValueError('signed episode does not match source calibration and measured sensors')
    t,y=read_csv(row['sensor_csv'])
    idx=episode.annotations.get('index_to_verify',len(y)//2)
    if (not isinstance(idx,int) or not 0<=idx<len(y) or
            record.get('observation',{}).get('unit')!='m' or
            not np.isclose(y[idx],record['observation']['value'],atol=1e-8,rtol=1e-5)):
        raise ValueError('signed scalar reveal does not match the raw waveform')
    return trace(cal,t,y,provenance='real_sensor'),{
        'machine_id':cal.machine_id,'sensor_csv_sha256':file_hash(row['sensor_csv']),
        'reveal_sha256':file_hash(row['reveal']), 'calibration_sha256':file_hash(row['calibration'])}


def prepare(source_manifest, target_calibration, target_times_csv, out,
            *, upstream_meta_sha256=None, chosen_action_id=None, risk_evidence=None):
    """Write sealed forecast BEFORE reading any target-response CSV.

    The source manifest lists signed, hash-linked, distinct training machines and
    optional independent held-out calibration machines; see docs/V041_FIELD.md.
    """
    root=Path(out)
    if root.exists() and any(root.iterdir()):
        raise FileExistsError('refusing to overwrite an existing sealed experiment directory')
    rows,cal_rows,manifest_hash=_resolve_manifest(source_manifest)
    if len(rows)<2:raise ValueError('at least two distinct signed source machines required')
    sources=[];provenance=[]
    for row in rows:
        t,p=_source_trace(row);sources.append(t);provenance.append(p)
    if len({t.body.machine_id for t in sources})!=len(sources):
        raise ValueError('training source machine IDs must be distinct')
    heldout=[]
    for row in cal_rows:
        t,p=_source_trace(row);heldout.append(t);provenance.append({**p,'role':'calibration'})
    if len({t.body.machine_id for t in sources+heldout})!=len(sources+heldout):
        raise ValueError('training/calibration leakage')
    target=read_calibration(target_calibration)
    t_target=read_csv(target_times_csv,response_required=False)
    mem=fit_memory(sources)
    if any(compatibility(s.body,target)['status']!='comparable' for s in sources+heldout):
        raise ValueError('target incompatible with source/calibration machines')
    conformal=None
    if heldout:
        conformal=conformal_calibrate(sources,heldout)
    q=conformal['q_dimensionless'] if conformal and conformal['coverage_supported'] else None
    result=mem.forecast(target,t_target,conformal_q=q)
    result['source_provenance']='real_sensor_verified_signed_inputs'
    result['signed_training_machines']=len(sources)
    result['heldout_calibration_machines']=len(heldout)
    result['interval_status']='source_like_calibrated' if q is not None else 'NO_VALIDATED_INTERVAL'
    result['target_response_measured']=False
    result['meta_involvement']='linked_live_source_review' if upstream_meta_sha256 else 'none'
    mid=len(t_target)//2
    sigma=None
    if result['upper_m'] is not None:
        sigma=max(1e-12,(result['upper_m'][mid]-result['displacement_m'][mid])/2.)
    # Full source memory and target calibration are covered by the signed
    # prediction; otherwise stage-two learning could silently swap evidence.
    payload={'version':mem.version,'grid_tau':mem.grid_tau.tolist(),
             'mean':mem.mean.tolist(),'residual_library':mem.residual_library.tolist(),
             'sources':[c.__dict__ for c in mem.source_calibrations],
             'source_ids':list(mem.source_ids)}
    ep=_episode(target,result['displacement_m'][mid],sigma if sigma is not None else 0.)
    ep.consequence.predicted.sigma=sigma
    ep.consequence.observable='tip_step_displacement_at_committed_index'
    ep.episode_id='crate-field-'+target.machine_id+'-preintervention'
    ep.sensors[0].sensor_id='target_sensor_expected_not_yet_measured'
    ep.action.action_id=chosen_action_id or 'human_step_force'
    ep.action.safety_approved=False  # a signed forecast is not permission to actuate
    ep.provenance=Provenance(origin='derived',source_uri=str(source_manifest),
        evidence_note='CRATE prediction from signed source real-sensor records. Target B not yet observed. '+
        'No valid 90% interval without held-out whole-machine calibration.')
    ep.annotations={'full_forecast_sha256':_hash_json(result),
        'source_manifest_sha256':manifest_hash,'source_evidence':provenance,
        'target_calibration_sha256':_hash_json(target.__dict__),
        'source_memory_sha256':_hash_json(payload),
        'target_times_sha256':file_hash(target_times_csv),
        'index_to_verify':mid,'upstream_meta_sha256':upstream_meta_sha256,
        'risk_evidence':risk_evidence,'interval_status':result['interval_status']}
    locked=seal(ep)
    root.mkdir(parents=True,exist_ok=True)
    # Store the numeric memory so that later observed consequences can update it
    # without re-reading or silently replacing source records.
    write_json(root/'source_memory.json',payload)
    write_json(root/'target_calibration.json',target.__dict__)
    write_json(root/'source_evidence.json',{'signed_inputs':provenance,'manifest_sha256':manifest_hash})
    write_json(root/'target_forecast.json',result)
    write_json(root/'01_sealed_target_prediction.json',locked)
    write_json(root/'manifest.json',{'stage':'PREDICTION_LOCKED_TARGET_UNOBSERVED',
        'prediction_sha256':locked['sha256'],'requires_external_witness_timestamp':True,
        'interval_status':result['interval_status'],'hardware_actuation_allowed':False,
        'source_count':len(sources),'calibration_count':len(heldout),
        'not_a_hardware_validation':'Operator-supplied files and calibration require independent audit'})
    return {'status':'PREDICTION_LOCKED_TARGET_UNOBSERVED',
        'prediction_sha256':locked['sha256'], 'interval_status':result['interval_status'],
        'training_sources':len(sources),'calibration_sources':len(heldout)}


def check(prepared_dir, target_observation_csv, out):
    """Verify independent target measurement and export a tentative learned memory.

    Candidate memory is never scored on the same response used to update it.
    """
    root=Path(prepared_dir)
    committed=json.loads((root/'01_sealed_target_prediction.json').read_text())
    if not verify_seal(committed):raise ValueError('tampered target commitment')
    episode=PhysicalEpisode.model_validate(committed['prediction'])
    forecast=json.loads((root/'target_forecast.json').read_text())
    if _hash_json(forecast)!=episode.annotations['full_forecast_sha256']:
        raise ValueError('tampered target trajectory')
    memory=json.loads((root/'source_memory.json').read_text())
    target=read_calibration(root/'target_calibration.json')
    if _hash_json(memory)!=episode.annotations['source_memory_sha256']:
        raise ValueError('tampered source memory')
    if (_hash_json(target.__dict__)!=episode.annotations['target_calibration_sha256']
            or target.machine_id!=episode.machine_id):
        raise ValueError('tampered target calibration')
    sources=[BodyCalibration(**s) for s in memory['sources']]
    if any(compatibility(s,target)['status']!='comparable' for s in sources):
        raise ValueError('incompatible stored source memory')
    t,y=read_csv(target_observation_csv)
    if len(t)!=len(forecast['time_s']) or not np.allclose(t,forecast['time_s'],rtol=0,atol=1e-10):
        raise ValueError('target response clock grid is not the sealed prediction grid')
    local=local_verify({'status':'unverified_forecast','time_s':forecast['time_s'],
                        'displacement_m':forecast['displacement_m'],
                        'provenance':'real_sensor'},t,y)
    mid=episode.annotations['index_to_verify']
    recorded=reveal(committed,Quantity(value=float(y[mid]),unit='m'),
                    raw_observation_sha256=file_hash(target_observation_csv))
    if not verify_reveal(recorded):raise AssertionError('signed reveal failed verification')
    # Learn from unexpected outcomes, too: do NOT make the measured target a
    # held-out score of a model that has already absorbed it.
    tau=t*target.fundamental_hz
    grid=np.asarray(memory['grid_tau'],dtype=float)
    overlap=grid[(grid>=tau[0]-1e-10)&(grid<=tau[-1]+1e-10)]
    learned=None
    if len(overlap)>=8 and target.machine_id not in memory['source_ids']:
        observed=trace(target,t,y,provenance='real_sensor')
        new=aligned_residual(observed,overlap)
        old=np.vstack([np.interp(overlap,grid,np.asarray(x)) for x in memory['residual_library']])
        newlib=np.vstack([old,new])
        learned={'version':'physica.crate/v1-local-UPDATE_UNVALIDATED',
                 'grid_tau':overlap.tolist(),'mean':np.mean(newlib,axis=0).tolist(),
                 'residual_library':newlib.tolist(),
                 'source_ids':memory['source_ids']+[target.machine_id],
                 'sources':memory['sources']+[target.__dict__],
                 'target_signed_reveal_sha256':_hash_json(recorded),
                 'note':'Includes B observation; test on new C, not B, to evaluate transfer advantage'}
    out=Path(out)
    report={'status':'TARGET_OBSERVED_SIGNED','source_provenance':'user_supplied_real_sensor_unwitnessed',
        'signature_valid':verify_reveal(recorded),'prediction_sha256':committed['sha256'],
        'observation_sha256':file_hash(target_observation_csv),
        'verification':local, 'point_seal_verdict':recorded['result'],
        'interval_status':forecast['interval_status'],
        'learning':'candidate_memory_updated_requires_fresh_target_validation' if learned else 'insufficient_overlap_for_update',
        'warnings':['External witness required for independently proven chronology',
                    'Real provenance is asserted by data supplier, not independently audited',
                    'A single verification does not show physical generalization']}
    write_json(out,report)
    write_json(out.with_name(out.stem+'_signed_reveal.json'),recorded)
    if learned:
        # Sign the *whole* new model state, not only the B source observation.
        # Otherwise someone could edit the residual array before forecasting C.
        payload_hash=_hash_json(learned)
        proof={'memory_sha256':payload_hash,
               'prior_B_reveal_sha256':_hash_json(recorded),
               'purpose':'physica.crate/candidate-memory/v1'}
        learned['memory_signature']={'payload':proof,
            'signature_ed25519':S.sign(proof)}
        write_json(out.with_name(out.stem+'_candidate_updated_memory.json'),learned)
    return report


def probe_gate(source_manifest,target_calibration,probe_reveal,probe_csv,probe_calibration,out,
               *, sensor_sigma_m):
    """Conservatively audit a signed, low-force B probe BEFORE any high-force B test.

    Requires held-out source machines for a conformal whole-response threshold.
    A pass does not authorize hardware action; no fitted target response is read.
    """
    training,calibration,manifest_hash=_resolve_manifest(source_manifest)
    if len(training)<2:raise ValueError('need two distinct signed source machines')
    train=[_source_trace(row)[0] for row in training]
    heldout=[_source_trace(row)[0] for row in calibration]
    mem=fit_memory(train)
    calibrated=conformal_calibrate(train,heldout) if heldout else None
    q=calibrated['q_dimensionless'] if calibrated and calibrated['coverage_supported'] else None
    target=read_calibration(target_calibration)
    probe,provenance=_source_trace({'reveal':str(probe_reveal),
        'sensor_csv':str(probe_csv),'calibration':str(probe_calibration)})
    if probe.body.machine_id in {x.body.machine_id for x in train+heldout}:
        raise ValueError('target probe machine leaked into source calibration/training')
    verdict=mem.assess_probe_shift(target,probe,conformal_q=q,
        sensor_sigma_m=sensor_sigma_m)
    verdict.update({'source_manifest_sha256':manifest_hash,
        'target_probe_source_sha256':provenance['sensor_csv_sha256'],
        'independent_heldout_machines':len(heldout),
        'requires_human_supervision':True,
        'not_an_actuation_authorization':True,
        'uncertainty_note':'Conformal threshold assumes exchangeable source-like machine residuals'})
    write_json(out,verdict)
    return verdict


def followup_prepare(candidate_memory_json, verified_prior_reveal_json,
                     new_target_calibration, new_target_times_csv, out):
    """Read *post-B* candidate memory and precommit a distinct unseen C forecast.

    This is the prospective A,B -> C loop; C observations are NOT read here.
    A failed B prediction is still teachable evidence, conditional on signed
    B measurement integrity, but it is NOT proof that the new model is better.
    """
    candidate=json.loads(Path(candidate_memory_json).read_text())
    prior=json.loads(Path(verified_prior_reveal_json).read_text())
    if not verify_reveal(prior) or not prior.get('observation_sha256'):
        raise ValueError('fresh-memory creation requires signed raw-hash-linked B reveal')
    if candidate.get('target_signed_reveal_sha256')!=_hash_json(prior):
        raise ValueError('candidate memory does not correspond to signed B outcome')
    signature=candidate.get('memory_signature')
    unsigned={k:v for k,v in candidate.items() if k!='memory_signature'}
    expected={'memory_sha256':_hash_json(unsigned),
              'prior_B_reveal_sha256':_hash_json(prior),
              'purpose':'physica.crate/candidate-memory/v1'}
    if (not isinstance(signature,dict) or signature.get('payload')!=expected
        or not S.verify(expected,signature.get('signature_ed25519',''))):
        raise ValueError('candidate-memory signature invalid or contents tampered')
    source_cals=[BodyCalibration(**s) for s in candidate['sources']]
    source_ids=candidate['source_ids']
    if len(source_cals)!=len(source_ids) or [c.machine_id for c in source_cals]!=source_ids:
        raise ValueError('candidate-memory calibration source IDs inconsistent')
    grid=np.asarray(candidate['grid_tau'],dtype=float)
    lib=np.asarray(candidate['residual_library'],dtype=float)
    mean=np.asarray(candidate['mean'],dtype=float)
    if (grid.ndim!=1 or len(grid)<8 or not np.all(np.isfinite(grid)) or np.any(np.diff(grid)<=0)
        or lib.shape!=(len(source_ids),len(grid)) or mean.shape!=grid.shape
        or not np.all(np.isfinite(lib)) or not np.all(np.isfinite(mean))
        or not np.allclose(lib.mean(axis=0),mean,atol=1e-10,rtol=1e-8)):
        raise ValueError('candidate-memory numeric structure invalid')
    from .causal_transport import ResidualMemory
    mem=ResidualMemory(grid,mean,len(source_ids),lib,tuple(source_ids),
                       source_calibrations=tuple(source_cals))
    c=read_calibration(new_target_calibration)
    if c.machine_id in source_ids:
        raise ValueError('prospective target machine already appears in training memory')
    t=read_csv(new_target_times_csv,response_required=False)
    predicted=mem.forecast(c,t)
    predicted.update({'source_provenance':'real_sensor_chain_pending_external_witness',
        'source_memory_digest':_hash_json(candidate),'prior_signed_B_reveal_sha256':_hash_json(prior),
        'interval_status':'NO_VALIDATED_INTERVAL','target_response_measured':False})
    mid=len(t)//2
    ep=_episode(c,predicted['displacement_m'][mid],0.)
    ep.consequence.predicted.sigma=None
    ep.consequence.observable='tip_step_displacement_at_committed_index'
    ep.episode_id='crate-followup-'+c.machine_id+'-before-observation'
    ep.sensors[0].sensor_id='target_sensor_expected_not_yet_measured'
    ep.action.safety_approved=False
    ep.provenance=Provenance(origin='derived',source_uri=str(candidate_memory_json),
        evidence_note='Prospective C forecast after signed B learning. Target C NOT observed. No calibrated confidence interval.')
    ep.annotations={'full_forecast_sha256':_hash_json(predicted),
        'source_memory_sha256':_hash_json(candidate),
        'target_calibration_sha256':_hash_json(c.__dict__),
        'index_to_verify':mid,'prior_B_signed_reveal_sha256':_hash_json(prior),
        'interval_status':'NO_VALIDATED_INTERVAL'}
    root=Path(out)
    if root.exists() and any(root.iterdir()):
        raise FileExistsError('cannot overwrite an existing signed C experiment')
    root.mkdir(parents=True,exist_ok=True)
    write_json(root/'source_memory.json',candidate)
    write_json(root/'target_calibration.json',c.__dict__)
    write_json(root/'target_forecast.json',predicted)
    committed=seal(ep)
    write_json(root/'01_sealed_target_prediction.json',committed)
    write_json(root/'manifest.json',{'stage':'FOLLOWUP_C_PRECOMMITTED_NOT_MEASURED',
        'prior_B_reveal_sha256':_hash_json(prior),'prediction_sha256':committed['sha256'],
        'hardware_actuation_allowed':False,'external_witness_required':True})
    return {'status':'FOLLOWUP_C_PRECOMMITTED_NOT_MEASURED',
            'prediction_sha256':committed['sha256'],'target_machine':c.machine_id}
