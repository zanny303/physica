"""E17 - Causal Modal Intervention: choose the experiment that settles WHY a body changed (LABELLED SIMULATION).

A steel ruler clamped to a desk (250 mm overhang, 25 x 1 mm) has changed: either something heavy is taped on it,
or it is cracked, somewhere. Physica feels three tones. Then it may do up to two experiments from a menu a person
can do at home (tape a 5 g coin at one of six places, or just measure again), sealing what it expects to feel
before each one. Policies compared on the same hidden truths:
  none   - decide from the first feel only
  again  - measure twice more (more data, no intervention)
  random - tape the coin at random places
  eig    - Physica's choice: the experiment with the largest expected information gain
Truth is simulated on a finer beam model than Physica's belief uses (no inverse crime), with tone noise.
Seeds here differ from those used while building (5 and 11).
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica.cause import intervene as I  # noqa: E402
from physica.cause.fe import Beam  # noqa: E402

OUT = ROOT / "eval" / "results"


def boot(x, n=2000, seed=0):
    x = np.asarray(x, float)
    r = np.random.default_rng(seed)
    m = [r.choice(x, len(x)).mean() for _ in range(n)]
    return [float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))]


def main(trials: int = 60):
    model = Beam(0.25, 0.025, 0.001, "steel", name="steel ruler, 250 mm overhang", n_el=40)
    truth_beam = Beam(0.25, 0.025, 0.001, "steel", n_el=60)
    coin = 0.005 / model.mass_kg
    rng = np.random.default_rng(2026)
    truths = []
    for _ in range(trials):
        c = str(rng.choice(["mass", "crack"]))
        x = float(rng.uniform(0.15, 0.9))
        s = float(rng.uniform(0.05, 0.35) if c == "mass" else rng.uniform(0.3, 0.7))
        truths.append((c, x, s))
    plans = {"none": ("none", 0), "again x2": ("again", 2), "random x2": ("random", 2), "eig x1": ("eig", 1),
             "eig x2": ("eig", 2)}
    res = {"LABEL": "SIMULATION: hidden causes known by construction", "beam": model.describe(),
           "coin_g": 5.0, "coin_over_ruler_mass": coin, "trials": trials, "policies": {}}
    for name, (pol, budget) in plans.items():
        rs = [I.run(model, t, coin, policy=pol, budget=budget, truth_beam=truth_beam, seed=1000 + i)
              for i, t in enumerate(truths)]
        right = [r["right_cause"] for r in rs]
        pe = [r["place_err"] * model.length * 1e3 for r in rs if r["place_err"] is not None]
        ph = [h for r in rs for h in r["promises_held"]]
        res["policies"][name] = {
            "right_cause": float(np.mean(right)), "right_cause_ci95": boot(right),
            "place_err_mm_median": float(np.median(pe)) if pe else None,
            "confidence_mean": float(np.mean([r["final"]["confidence"] for r in rs])),
            "confidence_when_wrong": (float(np.mean([r["final"]["confidence"] for r in rs if not r["right_cause"]]))
                                      if not all(right) else None),
            "sealed_promises_held": float(np.mean(ph)) if ph else None, "promises": len(ph)}
        print(f"{name:10s} right cause {np.mean(right):.2f} {boot(right)}  place err {np.median(pe) if pe else float('nan'):.1f} mm"
              f"  promises held {np.mean(ph) if ph else float('nan'):.2f} ({len(ph)})")
    # one investigation, written out step by step for the demo page
    t = ("crack", 0.3, 0.55)
    inv = I.Investigation(model, coin)
    r = np.random.default_rng(7)

    def feel(iv):
        f = I.tones(truth_beam, t, None if iv is None or iv.kind == "again" else iv, 3)
        return f * np.exp(r.normal(0, 0.004, 3))

    story = []
    f0 = feel(None)
    inv.observe(f0)
    story.append({"step": "feel", "felt_hz": f0.round(2).tolist(), "belief": inv.belief()})
    for _ in range(2):
        iv, menu = inv.next_experiment(r)
        promise = inv.promise(iv)
        felt = feel(iv)
        rv = I._seal.reveal(promise, {f"tone{k + 1}_hz": float(v) for k, v in enumerate(felt)}, I._seal.interval_grade)
        inv.observe(felt, iv)
        story.append({"step": "experiment", "menu": menu, "chosen": iv.say(model), "sealed": promise["payload"]["prediction"],
                      "anchor": promise["anchor"], "felt_hz": felt.round(2).tolist(), "promise": rv["verdict"],
                      "belief": inv.belief()})
    res["example"] = {"truth": {"cause": t[0], "place_mm": t[1] * 250, "stiffness_lost": t[2]}, "story": story}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "E17_active_experiments.json").write_text(json.dumps(res, indent=1, default=float))
    b = story[-1]["belief"]
    print("example: truth crack at 75 mm ->", b["cause"], round(b["confidence"], 3), round((b["place"] or 0) * 250, 1), "mm")


if __name__ == "__main__":
    main()
