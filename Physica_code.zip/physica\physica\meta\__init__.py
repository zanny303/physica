"""Meta models in Physica's loop: SAM 3.1 as eyes, Muse Spark as the scientist who proposes new causes, Muse Wonder
as the agent that runs the experiment loop with tools. Every call goes through physica.llm.meta_client."""
