"""Shared evidence contract for Lab, Discover, and Lens.

Stores provenanced assets, withheld future split, physical calibration,
prospective predictions, and observed outcomes as separate objects.
A hash or signature proves integrity, not that a real experiment happened.
"""
from __future__ import annotations
import hashlib,json,math
from pathlib import Path
from datetime import datetime, timezone
from physica.library import sign

VALID_ORIGINS={'real_recording','external_recording','simulation','signed_replay'}

def hash_file(path):
    p=Path(path)
    return hashlib.sha256(p.read_bytes()).hexdigest()

def evidence_manifest(path, *, origin, modality, dataset=None, units=None, calibration_id=None,
                      license_note=None, actual_intervention=False):
    p=Path(path)
    if not p.is_file():raise FileNotFoundError(str(p))
    if origin not in VALID_ORIGINS or not modality or len(p.name)>180:
        raise ValueError('invalid origin/modality')
    return {'schema':'physica.evidence.v1','origin':origin,'modality':modality,'filename':p.name,
            'sha256':hash_file(p),'bytes':p.stat().st_size,'dataset':dataset,
            'units':units,'calibration_id':calibration_id,'license_note':license_note,
            'intervention_recorded':bool(actual_intervention),
            'evidence_is_not_proof_of_causality':True}

def commit_prediction(*, evidence, observation_cutoff_s, forecast, model, author_label='physica'):
    if evidence.get('schema')!='physica.evidence.v1':raise ValueError('missing real evidence manifest')
    if not (isinstance(observation_cutoff_s,(int,float)) and math.isfinite(observation_cutoff_s) and observation_cutoff_s>=0):
        raise ValueError('invalid forecast cutoff')
    if not isinstance(forecast,dict) or not forecast:raise ValueError('no forecast')
    payload={'schema':'physica.forecast.commit.v1','evidence_sha256':evidence['sha256'],
             'observation_cutoff_s':observation_cutoff_s,'forecast':forecast,'model':str(model),
             'author':str(author_label),'created_at_utc':datetime.now(timezone.utc).isoformat(),
             'future_observations_not_used_to_fit':True}
    return {'prediction':payload,'signature_ed25519':sign.sign(payload),
            'sha256':hashlib.sha256(sign.canonical(payload)).hexdigest()}

def check_commit(commit):
    if not isinstance(commit,dict) or not isinstance(commit.get('prediction'),dict):return False
    return (commit.get('sha256')==hashlib.sha256(sign.canonical(commit['prediction'])).hexdigest()
            and sign.verify(commit['prediction'],commit.get('signature_ed25519','')))

def reveal_measurements(commit, *, measurement_file, accuracy, notes=None):
    if not check_commit(commit):raise ValueError('forged or modified prediction commitment')
    if not isinstance(accuracy,dict) or not accuracy:raise ValueError('need evaluation metrics')
    # This links a later measurement file; local timestamp alone cannot witness time order.
    payload={'schema':'physica.forecast.reveal.v1','commit_sha256':commit['sha256'],
             'measurement_sha256':hash_file(measurement_file),'metrics':accuracy,
             'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
             'notes':notes or [],'independent_timestamp_witness':False}
    return {'reveal':payload,'signature_ed25519':sign.sign(payload)}
