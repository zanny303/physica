# Physica v0.7: Predictive Feeling, Reliable Senses, Transferable Mechanisms

**Research status (Oct 2026): software and simulation evidence, NOT a validated physical breakthrough.**

## Purpose

The algorithm's engineering definition of *feeling* is: a body takes an externally authorized physical action; predicts the consequence for each independently calibrated sense; measures the physical consequence; tests the innovations; updates only when measurements are consistent; and stores a scoped, signed transferable lesson. This does not imply subjective experience or consciousness.

v0.6 implemented the basic loop. v0.7 focuses on the 2026 audit's two empirical weaknesses: (1) adding sound to touch did not outperform touch alone on its original metric; and (2) the headline contact-friction baseline unfairly omitted friction.

## New executable components

- `physica/feeling/reliable_fusion.py`: `TrustedFeelingFilter`, batch two-state [position, velocity] Kalman innovation update with each sensor's calibrated observation operator, measured noise, and a joint normalized innovation squared (NIS) gate. Accepts missing channels. A contradictory joint observation is **not assimilated**. Reports model-conditional uncertainty. Physics predicts before sensing. Calibration drift and sensor correlation must still be quantified on real hardware.
- `physica/feeling/fair_benchmark.py`: conventional single-coefficient smooth-friction fit using exactly the same observed low-force B probe, compared with source transfer and source+probe. The old friction-free model remains labelled as an incomplete comparator, not the research standard.
- `physica/feeling/mechanism_transfer.py`: signed, normalized candidate mechanism discovery from *independently measured* acceleration, displacement, velocity and force, using disjoint source interventions. Supported library: cubic elasticity, quadratic drag, and smooth contact friction. Requires a distinct, signed low-force B probe; recomputes raw data mismatch and binds to target calibration. Prediction for B requires measured target **x,v,F**; supplying held-out acceleration is refused. The current demonstration predicts acceleration *conditional on target kinematics* and is **not** a prospective full trajectory predictor.
- `physica/feeling/meta_ablation.py`: offline reproducible comparison between a registry-wide physics candidate search and a candidate subset proposed in a saved Muse response. Neither Muse's words nor numeric parameters become sensor evidence; an offline reply is **never called live or authenticated**.
- `physica/feeling/v07_benchmarks.py`: transparent evaluations of fair baseline, complementary sensory fusion, noise corruption, novel mechanism, and refusal when none of the allowed mechanisms fits.
- `physica/feeling/v07_cli.py`: CLI for new synthetic benchmark, actual calibrated time-stamped samples in JSON, offline mechanism discovery, low-force probe and conditional target forecast, and a saved-reply Meta ablation.

## Why the v0.6 119x headline was inadequate

It compared a friction-aware model to a *friction-free* physics model. Both v0.7 target-adapted methods use precisely the same B low-force probe and identical target body/sensor calibration. The stronger model can be as accurate as or better than Physica. Report all competitors, not a single favorable ratio.

## Real experiment procedure

1. Independently calibrate force in newtons, camera displacement in metres, microphone pressure in pascals, and synchronization/time uncertainty. Do **not** assume a microphone measures velocity absent a calibrated observation operator.
2. Identify source Machine A's body, fixture and boundary conditions; record at least two distinct, reversible training actions and one intervention-disjoint validation action with synchronized video/audio/force/acceleration. Document failed trials and clipping.
3. Run mechanism discovery. An unsupported or unknown mechanism is an outcome, not an error to hide.
4. Register Machine B's independent mass/stiffness/damping/reference scale, approved force envelope and sensing calibration. Keep B's main response out of the fit. Run, record and sign a separate small supervised probe. Verify its physical disagreement from raw measured signals before conditional prediction.
5. Commit predictions before the main trial. The cubic-model demonstration *conditions on measured target displacement/velocity*; a blind intervention-to-full-trajectory prediction requires an additional time-domain simulator and independent testing. Do not represent the conditional benchmark as prospective full-trajectory evidence.
6. Compare B on: (a) physics-only, (b) conventional local friction fit using the B probe, (c) source transfer, (d) source+same B probe, and where applicable a sparse nonlinear ID baseline. Keep data and calibration budgets equal; report accepted vs refused runs, confidence intervals, runtime and cost.
7. Evaluate a deliberately unknown mechanism and a shifted boundary or sensor calibration. Refusal must be scored, not excluded.
8. Try C only after B has a genuinely verified lesson and independent test data.

## Meta: essential prospective role, not invented evidence

- **Muse Spark** examines pre-intervention video *context and confounders*; candidate source-scene hashes recorded.
- **SAM 3.1** produces tracked boxes/masks for physically relevant parts. The existing `meta_bridge.py` accepts SAM tracks **only** with independently calibrated scale, clock and fixed-reference motion correction. Meta documents SAM via the Responses API, with special-token geometry parsed by its official library; it does not give newtons or stiffness.
- **Muse Wonder** proposes falsifiable mechanism families and approved candidate experiments. The numerical physics/search engine is the authority on likelihood and safety. An LLM cannot set force coefficients.
- **V-JEPA 2**, if separately deployed, may contribute visual dynamics embeddings but needs trained, held-out calibrated physical readouts before becoming numeric physics evidence.

For the **Meta-on/off** comparison, record genuine billable Model API outputs and immutable scene hashes, then compare *the same real training/heldout interventions* using all registered physical hypotheses versus the Muse-nominated subset, equal intervention and measurement budgets. Record candidate recall, errors, experiment counts, latency and refusal. An offline JSON comparison can establish software behavior but **not Meta's contribution**.

Docs: https://dev.meta.ai/docs/sam/overview ; https://dev.meta.ai/docs/media-segmentation

## Run

```bash
pip install -e '.[dev,video]'
python -m physica.feeling.v07_cli benchmark --trials 12 --out demo/v07_study.json
pytest -q tests/test_feeling_v070.py tests/test_predictive_feeling_v060.py
python -m physica.feeling.v07_cli fuse examples/v07_research/fusion_input_SIMULATED.json --out demo/v07_sensors.json
python -m physica.feeling.v07_cli discover-mechanism examples/v07_research/mechanism_source_SIMULATED.json --out demo/source_candidate.json
python -m physica.feeling.cli meta-feel path/to/real.mp4 --allow-billed-meta --out demo/meta_real_result.json
```

**Never share API keys.** The live Meta route requires `MODEL_API_KEY`, user-supplied video, and model access. No paid API calls or real-machine interventions were executed in creating this release.

## Science and novelty boundary

Kalman filters, innovation gating, classical system ID, Bayesian experimental design, sparse polynomial dynamics discovery, dimensionless normalization and constrained language-model orchestration all have established prior art. The **candidate** contribution is their integration into transferable, action-conditioned sensory experience with strict applicability/refusal and prospective interventional evaluation. The software alone does not establish the novelty, reliability, or superiority of that combination.

**The hackathon claim must remain:** "Physica gives machines a computational form of physical feeling. It predicts sensed consequences, detects when its models fail, and can transfer *conditional, testable* lessons." A real discovery or Meta-dependent improvement has yet to be verified.
