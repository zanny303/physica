"""E10: a real robot arm feels collisions, extra weight and friction without a touch sensor (voraus-AD).

Runs on your machine: needs the 1.1 GB voraus-AD parquet (export PHYSICA_VORAUS_FILE=...). Healthy-only:
the first half of normal cycles (by sample id) teaches 'what this robot causes itself'; the second half is held out.
Reports AUROC (the dataset paper's metric), detection at a healthy-only threshold, false alarms, per anomaly kind,
and where on the arm and in the task each feeling sits.
"""
from __future__ import annotations

import sys

import numpy as np

from common import binom_ci, save_result
from physica.data import voraus
from physica.feel.torque_feel import TorqueFeel


def auroc(neg, pos):
    allv = np.r_[neg, pos]
    r = allv.argsort().argsort() + 1
    return float((r[len(neg):].sum() - len(pos) * (len(pos) + 1) / 2) / (len(neg) * len(pos)))


def main(file=None, name="E10_robot_touch"):
    cyc = voraus.load(file)
    normal = [c for c in cyc if not c["anomaly"]]
    anom = [c for c in cyc if c["anomaly"]]
    cal, ho = normal[: len(normal) // 2], normal[len(normal) // 2:]
    tf = TorqueFeel().fit(cal)
    s_ho = np.array([tf.score(c) for c in ho])
    s_an = np.array([tf.score(c) for c in anom])
    fa = int((s_ho > tf.threshold).sum())
    out = {"n_calibration_normal": len(cal), "n_heldout_normal": len(ho), "n_anomalies": len(anom),
           "threshold": tf.threshold, "auroc": auroc(s_ho, s_an) if len(anom) and len(ho) else None,
           "detect": float((s_an > tf.threshold).mean()) if len(anom) else None,
           "false_alarms": f"{fa}/{len(ho)}", "false_alarm_ci95_exact": binom_ci(fa, len(ho)), "per_kind": {}}
    for k in sorted({c["category"] for c in anom}):
        idx = [i for i, c in enumerate(anom) if c["category"] == k]
        out["per_kind"][k] = {"n": len(idx), "auroc": auroc(s_ho, s_an[idx]) if len(ho) else None,
                              "detect": float((s_an[idx] > tf.threshold).mean()),
                              "typical_where": tf.where(anom[idx[0]])}
    save_result(name, out)
    print({k: out[k] for k in ("auroc", "detect", "false_alarms", "n_anomalies")})
    return out


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else None)
