# Physica v0.8.3: Cloud training + Meta scientific reasoning + three demonstrations

## Explicit evidence tiers

**1. Actually executed here:** 40 GENERATED synthetic recordings across 20 simulated bearing groups, classified with equal group-disjoint train/test splits; next-sensation linear models also trained and evaluated on held-out simulated groups. Numeric weights are saved in `examples/cloud_v083/simulated_pilot/`. This validates training code, **not physical generalization**.

**2. Ready to execute on real public data:** Paderborn group-disjoint benchmark and action-independent motor-current/vibration prediction. Full dataset is not in the ZIP; source requires download, attribution, and a noncommercial-use license. No real dataset accuracy is claimed.

**3. Ready to execute on real recorded video:** Physics-IQ Verified clips from official Hugging Face. The existing `physica.triad.cli` forecasts tracked movement on a withheld portion of a real video; it is **not** the official benchmark's generative-video metric, and optical flow does not measure forces without independent calibration.

**4. Live integration requiring your private credentials:** Muse Spark scene context, Muse Wonder testable hypotheses, SAM 3.1 tracking; requires `MODEL_API_KEY` and Meta optional dependencies. No authenticated runs were performed in this release.

**5. External physical actuation and lab intervention:** not performed here. A cloud dataset showing natural behavior is observational; real interventions require supervised hardware or a remote lab with actual controllable equipment.

## Official sources (checked October 31, 2026)

- Paderborn Bearing DataCenter: https://mb.uni-paderborn.de/en/kat/research/bearing-datacenter (CC BY-NC 4.0; cite Lessmeier et al. 2016)
- Recording download: https://mb.uni-paderborn.de/en/kat/research/bearing-datacenter/data-sets-and-download
- Physics-IQ Verified: https://huggingface.co/datasets/Anates-Labs-Research/Physics-IQ-Verified (CC BY 4.0; see authors' intended benchmark protocol)
- Physics-IQ code: https://github.com/google-deepmind/physics-IQ-benchmark
- DROID: https://droid-dataset.github.io/ (~76k trajectories; 100-episode debug sample is ~2GB)
- NASA IMS bearings: https://data.nasa.gov/dataset/ims-bearings (a complementary time-to-failure signal benchmark)
- CWRU bearing signals: https://engineering.case.edu/bearingdatacenter/download-data-file
- LabsLand real remote labs: https://labsland.com/en/ (some sessions may need subscription/booking; inspect export permissions before relying on them)
- Meta Model API model docs: https://dev.meta.ai/docs/models
- Meta wearables: https://developers.meta.com/wearables/faq/

## Training (CPU sufficient for first Paderborn run)

```
pip install -e '.[dev,video]'

# Check pipeline locally; reports SIMULATED_TRAINING_PILOT
python -m physica.remote_bench.cli pilot --out demo/trained_pilot

# After downloading licensed Paderborn recordings to a separate /data/paderborn folder:
python -m physica.triad.cli inspect-mat /data/paderborn/N09_M07_F10_K001_1.mat --out inspect.json

# Build an accurate body-label CSV from official Paderborn factsheets, NOT guessed filename labels.
# Replace vib/current field names with actual paths displayed by inspect-mat.
python -m physica.remote_bench.index_external /data/paderborn /data/official_labels.csv \
  --vibration-field 'REPLACE_AFTER_INSPECTION' --current-field 'REPLACE_AFTER_INSPECTION' \
  --sample-rate REPLACE_WITH_DOCUMENTED_RATE --out /data/paderborn/manifest.json

# These commands enforce disjoint BEARING IDs across training and evaluation:
python -m physica.remote_bench.cli train /data/paderborn/manifest.json --out demo/real_bearing_model
python -m physica.remote_bench.cli train-next /data/paderborn/manifest.json --out demo/real_next_sensation
```

Read `report.json` and `next_sensation_report.json`. Compare the three modalities honestly (vibration, motor current, fusion). Report test bearing IDs, balanced accuracy, ROC-AUC, held-out prediction RMSE and negative results. Do not label passive motor current as an action; without intervention labels this is correlation and signal prediction only. Paderborn's force units and MAT nested fields must be checked; in many releases field paths are nested in MATLAB structs. No reusing windows from a test bearing in training or hyperparameter selection.

### Cloud recommendation

Google Colab CPU is sufficient for the first spectral-classification and small Ridge forecast baseline. Upload the ZIP/project and external dataset files to your Colab session or mounted Drive. For the heavy DROID dataset or V-JEPA 2 weights, GPU resources are separate and optional. Meta Model API credit funds hosted Muse/SAM calls, not third-party cloud GPU rental.

### What *training* means here

- **Trained:** small recording-level spectral classifier (supervised, pilot synthetic) and near-future Ridge sensory predictor (pilot synthetic). Both weight files saved numerically as `.npz`, no pickle required.
- **Training-ready:** repeat on real Paderborn measured recordings with independent bearing-level splits; no number claimed until actual data is run.
- **Not trained:** Meta's Muse models, V-JEPA 2, an AI foundation model that understands all five senses, a real robot policy.

## Physica Discover: real footage challenge

1. Download a permitted **Physics-IQ Verified** experiment clip from its official repository. Choose **an object with trackable motion**; fluid flow and magnetism may not fit current oscillator forecasting.
2. Choose a moving ROI and a static reference ROI. **Do not give the model frames after the cutoff**. For a stronger prospective proof, physically create a prefix-only video file before preparing and hash-committing the forecast.
3. Run:

```
python -m physica.triad.cli prepare-video full_real_clip.mp4 --roi X Y W H \
  --ref-roi RX RY RW RH --prefix-frames 90 --horizon-frames 30 --out demo/cloud_commit.json
python -m physica.triad.cli check-video full_real_clip.mp4 --roi X Y W H \
  --ref-roi RX RY RW RH --commit demo/cloud_commit.json --out demo/cloud_checked.json
```

In a retrospective downloaded clip, the entire source file already exists; this shows **prefix-only code access**, not independent chronology. Report pixel error vs persistence. SAM tracking replaces the ROI only if an authenticated SAM call has been made. Hidden future video values must not be sent to Muse.

## Muse and machine-specific code

Muse Spark: interpret environment and likely components. Muse Wonder: propose competing mechanisms, a whitelist action, and a test to distinguish them. **Physica** performs measured parameter estimation and generates auditable draft G-code, Klipper config or ArduPilot notch parameter files via fixed translators. No raw Muse code is flashed or executed.

```
# Real measured evidence with independent calibration is required; template intentionally fails otherwise.
python -m physica.remote_bench.cli machine-draft \
  examples/cloud_v083/VERIFIED_MEASUREMENT_TEMPLATE.json \
  --muse-reply examples/cloud_v083/ILLUSTRATIVE_MUSE_REPLY_NOT_LIVE.json --out demo/machine_draft

# With approved, independently measured evidence, a REAL billable call:
export MODEL_API_KEY='your_private_key_on_your_own_machine'
python -m physica.remote_bench.cli live-muse-draft /data/verified_evidence.json \
  --allow-billed-meta --out demo/live_machine_review
```

The failed command above is intentional: fabricated, simulated, or uncalibrated evidence cannot produce machine settings suitable for a real device. Authorized outputs still need firmware compatibility review, supervised bench tests, and rollback verification. An LLM may draft application code for engineers, but it must not independently set unmeasured frequencies or execute potentially dangerous hardware actions.

## Three-demo story (3 minutes)

**0:00–0:55 — Physica Lab:** A predicted physical sensation is sealed before a real approved action at the makerspace. Show independently calibrated force, video, and optionally sound; reveal the signed comparison and an honest baseline. If no real action has been performed, label the example as simulated.

**0:55–1:50 — Physica Discover (cloud):** load a withheld *real* Physics-IQ video and/or measured Paderborn bearing. Show the split (train bodies vs unseen test bodies), physics interpretation, a future forecast, failure/abstention, and evidence that fusion did or did not help. Live Muse scene analysis can propose a missing explanation, but only measurements can confirm it.

**1:50–2:35 — Physica Lens + machine translation:** a consumer uploads a phone video about a wobbling object. Muse supplies context and a safe observation, Physica checks it against its knowledge. Then show the reviewed machine-specific configuration generated from independently verified measurements, NOT autonomously actuated. Meta Ray-Ban Display Web App Simulator can demonstrate a *display* interface without glasses; Web Apps don't automatically grant streaming camera access.

**2:35–3:00 — Common invention:** action → expected sensation → real sensory surprise → causal test → verified portable PEL record → another body. Explicitly separate demonstrated capability from long-term research ambition.

## Hard evidence checklist

- Cloud classification split **by bearing ID**; enough distinct bearing IDs per class for train/test, plus held-out operating conditions if data permits.
- Audio/current/vibration unit provenance and sample alignment checked; no cross-sensor labels inferred from filenames alone.
- Dataset author/license attribution displayed in submission.
- Vision predictions are measured in pixels unless separately calibrated.
- Compare same data and compute budget for vibration-only, current-only, fusion, persistence, and physics baselines.
- Meta-on vs Meta-off data and decisions saved. Missing Meta executions must be marked missing.
- Machine instructions must be offline drafts from measured values, never raw LLM code applied to hardware.
- Distinguish replaying recorded experiments from active remote experiments and local physical intervention.
