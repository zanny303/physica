"""The Studio front page: feeling force, and only what has really been shown."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RES = ROOT / "eval" / "results"
CLIPS = {"turbine": RES / "film" / "turbine.mp4", "downtime": RES / "film" / "downtime.mp4", "tacoma": ROOT / "clips" / "tacoma_bridge.mp4", "guitar": ROOT / "clips" / "guitar.mp4", "tacoma_read": ROOT / "clips" / "tacoma_read.mp4",
         "shake": ROOT / "shake.mp4", "wall": ROOT / "wall.mp4", "film": ROOT / "physica_demo.mp4"}


def _read(p: Path):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _sessions() -> Path:
    """Your own run, or the copy of it saved in the repo for anyone who downloads it."""
    here, saved = ROOT / "physica_sessions", RES / "real_run"
    return saved if saved.exists() and not any(here.glob("*investigation*")) else here


def _round(v, n=2):
    return round(float(v), n)


def _latest(pattern: str):
    found = sorted(_sessions().glob(pattern), key=lambda p: p.stat().st_mtime)
    return _read(found[-1]) if found else None


def story(name: str = "cables") -> list[dict]:
    """The real run, step by step, from saved files only. A step with no saved result isn't shown as done."""
    d = _read(_sessions() / f"{name}_cables.json") or {}
    steps: list[dict] = []

    def add(ribbon, title, line, done=True, detail=None, image=None):
        steps.append({"ribbon": ribbon, "title": title, "line": line, "done": bool(done), "detail": detail, "image": image})
    if d.get("muse_saw"):
        add("MUSE", "Muse looks", d["muse_saw"], True, d.get("muse_named"))
    else:
        add("MUSE", "Muse looks", "Muse watches the film and names each cable by what it holds. Nothing is typed.", False)
    if d.get("overlay"):
        add("SAM", "SAM pins each cable", f"{d.get('located_by', 'SAM')}. Words typed: {d.get('typed_words')}.", True, None, d["overlay"])
    else:
        add("SAM", "SAM pins each cable", "Each cable keeps its own pixels through the film, so their tones can't blur into one.", False)
    reads = d.get("readings") or []
    if reads:
        sealed = reads[0]["sealed"]
        rows = [f"{k}: {r['grams']} g, from {r['range_g'][0]} to {r['range_g'][1]}" if r["status"] == "READ" else f"{k}: can't tell" for k, r in sealed["payload"]["prediction"]["cables"].items()]
        add("PHYSICA", "It feels the force", f"Sealed {sealed['anchor']}, before anything went on the scale. A cable's tone rises with the square root of how hard it's pulled.", True, rows)
    else:
        add("PHYSICA", "It feels the force", "Each cable's tone, from pixels alone, becomes grams. The answer is sealed first.", False)
    graded = next((r["graded"] for r in reads if r.get("graded")), None)
    if graded:
        rows = [f"{k}: Physica {r.get('physica_g', 'cannot tell')}, scale {r['scale_g']:g} g" + (f", off by {r['error_pct']}%" if "error_pct" in r else "") for k, r in graded["cables"].items()]
        add("REALITY", "The scale", f"Read {graded['read']} of {graded['of']}. Median error {graded['median_error_pct']}%, against {graded['equal_share_error_pct']}% for sharing the total equally.", True, rows)
    else:
        add("REALITY", "The scale", "A kitchen scale, on camera, grades every cable.", False)
    done = [f for f in d.get("forecasts") or [] if f.get("grade")]
    if done:
        rows = [f"{f['payload']['prediction']['grams']:g} g on {f['payload']['prediction']['cable']}: forecast {f['grade']['forecast_hz']} Hz, measured {f['grade']['measured_hz']} Hz, {'held' if f['grade']['held'] else 'missed'}" for f in done]
        add("REALITY", "The twin's forecast", "Sealed before the load went on.", True, rows)
    plan = d.get("plan")
    if plan:
        after = next((r["graded"] for r in reads[1:] if r.get("graded")), None)
        moves = [f"{k}: {'add' if m >= 0 else 'remove'} {abs(m)} g" for k, m in plan["moves_g"].items()]
        tail = ""
        if after:
            scale = [r["scale_g"] for r in after["cables"].values()]
            tail = f" After the move, the scale's spread was {max(scale) - min(scale):g} g, down from {plan['spread_now_g']} g as read."
        add("MUSE", "Muse sets the goal", (plan.get("muse_why") or plan["goal"]) + tail, True, moves)
    else:
        add("MUSE", "Muse sets the goal", "Muse chooses the target, and code works out what to move. A person moves it, films again, and the scale checks it.", False)
    return steps


def recordings() -> list[dict]:
    """One card of real-data results, read from the saved files, tagged with the kind of data."""
    out = []
    e16, e24, e20, e9, e23 = (_read(RES / f) for f in ("E16_hidden_cause.json", "E24_f1_race_engineer.json", "E20_wind_blade.json", "E9_skill_transfer.json", "E23_program_by_outcome.json"))
    if e16:
        c = e16["A"]["comparison_same_recording"]
        promise = e16["sealed_promise_about_B"]
        out.append({"unit": "mm", "big": f"{_round(c['physica_live']['median'])} mm", "line": f"A hidden support inside a steel beam, found from vibration alone. The published method on the same recording: {_round(c['published_model_updating_downey2020']['median'])} mm.",
                    "limit": "Real sensor recording.", "label": "REAL RECORDINGS"})
    if e24:
        f = e24["feel_check_held_out_laps"]
        kn = [c["downforce_250kmh_kN"] for c in e24["felt"]]
        out.append({"unit": "kN", "big": f"{min(kn)} to {max(kn)} kN", "line": f"Downforce of 20 F1 cars, from one public speed trace. Lap time on laps it never saw: off by {f['physica']['lap_time_error_s_median']} s, against {f['generic_f1']['lap_time_error_s_median']} s for a generic car and {f['field_average']['lap_time_error_s_median']} s for the field average.",
                    "limit": "Real public telemetry. Car mass assumed.", "label": "REAL TELEMETRY", "clip": "f1"})
    if e20:
        s = e20["score"]
        out.append({"unit": "false alarms", "big": f"{round(s['healthy_false_alarm'] * 48)} vs {round(e20['baseline_temperature_blind']['healthy_false_alarm'] * 48)}", "line": "False alarms in 48 checks of a healthy wind-turbine blade through the cold, against a temperature-blind alarm.",
                    "limit": "Real lab blade, on a shaker.", "label": "REAL LAB BLADE", "clip": "turbine"})
    if e9:
        h = e9["skills"]["hz_band"]["bebop"]
        plain = e9["skills"].get("spectrogram") or e9["skills"].get("plain_spectrogram") or {}
        base = (plain.get("bebop") or {}).get("detect")
        flight = (e23 or {}).get("C_drone", {}).get("flight", {})
        out.append({"unit": "drone", "big": f"{100 * h['detect']:.0f}%", "line": f"Propeller damage felt in {100 * h['detect']:.0f}% of real flight windows, with {h['false_alarms']} false alarms" + (f". A plain spectrogram: {100 * base:.0f}%." if base else "."),
                    "limit": f"Real flights, range {100 * h['detect_ci95_cluster_by_flight'][0]:.0f} to {100 * h['detect_ci95_cluster_by_flight'][1]:.0f}%. Its inspection mission flew {flight.get('waypoints_reached', '?')} of 8 waypoints in ArduPilot's simulator.", "label": "REAL FLIGHTS, SIMULATED MISSION"})
    return out


def data(name: str = "cables") -> dict:
    from physica.llm import meta_client as mc
    out = {"meta": {"live": not mc.is_mock(), "receipts": len(list((ROOT / "meta_receipts").glob("*"))) if (ROOT / "meta_receipts").exists() else 0},
           "story": story(name), "recordings": recordings(), "clips": {k: v.exists() for k, v in CLIPS.items()}}
    sess = _read(_sessions() / f"{name}_cables.json") or {}
    usable = {k: {"a": v["grams_per_hz2"], "b": v["offset_g"]} for k, v in (sess.get("calibration") or {}).items() if v.get("usable")}
    if usable:
        out["twin"] = {"cables": usable, "fps": sess.get("fps")}
    from physica.outcome import speak as K
    from physica.studio import film_api
    out["presets"] = film_api.presets()
    from physica.outcome import muse_reads as MR
    try:
        out["reads"] = {"cases": MR.cases(), "saved": (_read(MR.OUT) or {}).get("cases") or {}}
    except Exception:
        out["reads"] = None
    said = _read(K.OUT) or {}
    out["speak"] = {"machines": {k: {x: v[x] for x in ("title", "language", "goal", "felt", "source")} for k, v in K.records().items()}, "saved": said.get("machines") or {}, "example": __import__("physica.outcome.goalbox", fromlist=["EXAMPLE"]).EXAMPLE}
    cases = _read(RES / "E35_real_footage.json")
    if cases and cases.get("cases"):
        out["footage"] = {"note": "Real films with published or known answers.", "cases": {k: {x: (y.replace(" Check before showing publicly.", "") if x == "credit" and isinstance(y, str) else y) for x, y in v.items() if x not in ("sealed", "corrected_sealed", "roll_trace")} for k, v in cases["cases"].items() if "failed" not in v}}
    twin = _read(_sessions() / "ruler_twin.json")
    if twin:
        out["ruler"] = {k: twin.get(k) for k in ("tone_hz", "tones_hz", "spread_pct", "damping", "calibration", "weighed")}
        out["ruler"]["graded"] = [s.get("grade") for s in twin.get("sealed", []) if s.get("grade")]
    return out
