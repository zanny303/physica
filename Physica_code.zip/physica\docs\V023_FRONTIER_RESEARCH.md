# Physica v0.23: evidence-selected neural physics and Meta research council

## Decision: what NOT to blindly add

* **Neural residual dynamics:** implemented as a small MLP learned acceleration residual alongside the known physical equation. It can be stepped as a hybrid neural differential model, but the current benchmark scores *one-step acceleration* on a different episode. A full differentiable Neural ODE with trajectory training is NOT claimed.
* **Symbolic regression library:** a strong regularized candidate dictionary tests whether an interpretable equation outperforms a network. It is not guaranteed to contain an unknown real mechanism.
* **RL:** NOT added. An RL policy trained on a wrong simulator can exploit model errors, and no verified real reward/action/safety environment exists. First obtain realistic intervention data and evaluate constrained planning and information gain; only then compare offline/model-based RL against those baselines.
* **SPINN and large GNN:** NOT added. SPINNs solve structured multidimensional PDEs; graphs need reliably identified components and broad training diversity. Neither is justified by the present 1D controlled benchmark.
* **Multi-agent Meta:** offline, bounded role-specific protocol implemented. Muse Spark can serve observer/critic/experiment designer; Muse Wonder can serve scientist/reviewer. Model agreement does not constitute evidence. Authenticated multi-agent API calls and their measured benefit are NOT included.

## Reproduce

From the extracted `physica` directory with Python and package dependencies installed:

```powershell
$env:PYTHONUTF8 = '1'
python -m physica.frontier.hybrid --seeds 6 --out demo/frontier_ablation.json
python -m pytest -q tests/test_frontier_v023.py
python -m physica.studio --open-browser
```

Visit `http://127.0.0.1:8765/frontier` to run a fresh four-seed benchmark and inspect the offline council protocol.

## Synthetic evaluation protocol

Every seed uses four separate training interventions, a fifth validation intervention, and an independent, seed-separated final test intervention. Physica evaluates four alternatives on the same evidence: known-physics-only, linear learned residual, a nonlinear MLP residual, and a richer symbolic feature dictionary. The winning architecture is selected from validation without inspecting final test scores. **This is a one-step observed-state acceleration benchmark**. Evaluate recursive state trajectories and out-of-distribution sensors BEFORE claiming reliable rollout ability.

## Meta architecture and safe route to production

1. Grounded observer produces measured channels plus units, timing, calibration and sensor availability.
2. Muse Wonder proposes a short list of falsifiable mathematical mechanisms with explicit variables and predicted divergences.
3. Muse Spark critic independently checks identifiability, alternative explanations and missing evidence.
4. Experiment designer ranks only allowed, supervised and reversible measurement proposals, never actuating devices.
5. Physica numerical engine fits candidates from source data; separates training, validation and untouched prospective test episodes, commits to predictions before outcomes, and compares equal-budget baselines.
6. Wonder reviewer summarizes numerical evidence, contradictions and refusal conditions. A separate machine-specific adapter requires documented operator permission.

Model context between roles should be structured and limited to *frozen, labeled* measurements and previous critique. Do not feed held-out target truths to proposer, planner, or reviewer. Use explicit authorization, existing Meta budget controls and spending caps for live Model API requests. This version adds no secret background Meta calls and no additional hardware endpoints.

Meta official documentation: https://dev.meta.ai/docs/models ; https://dev.meta.ai/docs/overview .

## Impact / remaining unknowns

The research goal is not a higher number of neural networks; it is a reproducible improvement in unfamiliar-mechanism discovery and goal-conditioned cross-machine transfer. This release does NOT prove novel scientific discovery, a new mathematical learning algorithm, live multi-agent effectiveness, or a real-hardware breakthrough.

### Optional authenticated inter-model exchange

```powershell
$env:MODEL_API_KEY = 'YOUR_OWN_KEY'
$env:MOCK = '0'
python -m physica.frontier.council --context examples/frontier_v023_context.json --live --acknowledge-billing --out demo/frontier_live.json
```

This **explicitly makes up to four billed calls**: Spark grounding → Wonder hypothesis → Spark adversarial critique → Wonder revision. The previous roles' structured JSON is passed as context into subsequent calls, making the dialogue substantive and inspectable. The underlying Meta client records call receipts and enforces its configured spending budget. The scientist is not allowed to actuate a machine. Do not put secrets in context files. Any live response must be numerically fitted and challenged on new physical measurements before it can become an accepted mechanism.
