"""Spectral helpers shared by the Feel Transform."""
from __future__ import annotations

import numpy as np
from scipy.signal import welch


def window_psd(x: np.ndarray, fs: float, wins: list[tuple[int, int]], nperseg: int = 512) -> tuple[np.ndarray, np.ndarray]:
    """Welch PSD per window and per unit, summed over the last axis (e.g. x/y/z).

    x: (N, units, axes) or (N, units). Returns f (nf,), psd (n_windows, units, nf).
    """
    x = np.asarray(x, float)
    if x.ndim == 2:
        x = x[:, :, None]
    out = []
    f = None
    for s, e in wins:
        seg = x[s:e] - x[s:e].mean(axis=0, keepdims=True)
        f, p = welch(seg, fs=fs, nperseg=min(nperseg, e - s), axis=0)  # p: (nf, units, axes)
        out.append(p.sum(axis=2).T)
    return f, np.asarray(out)


def band_peak(psd: np.ndarray, f: np.ndarray, band: tuple[float, float], halfwidth_bins: int = 2) -> tuple[np.ndarray, np.ndarray]:
    """Dominant peak frequency and log10 power around it, per window and unit."""
    m = (f >= band[0]) & (f <= band[1])
    fb = f[m]
    P = psd[..., m]
    i = P.argmax(axis=-1)
    freq = fb[i]
    lvl = np.zeros(i.shape)
    it = np.nditer(i, flags=["multi_index"])
    for j in it:
        idx = it.multi_index
        lo, hi = max(0, int(j) - halfwidth_bins), int(j) + halfwidth_bins + 1
        lvl[idx] = np.log10(P[idx][lo:hi].sum() + 1e-30)
    return freq, lvl


def band_power_db(psd: np.ndarray, f: np.ndarray, band: tuple[float, float]) -> np.ndarray:
    m = (f >= band[0]) & (f <= band[1])
    return 10 * np.log10(psd[..., m].sum(axis=-1) + 1e-30)
