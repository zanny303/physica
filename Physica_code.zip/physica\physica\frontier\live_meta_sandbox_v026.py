"""Live Meta scientist on a controlled simulated world — no simulated Meta answers.

This makes real billable Wonder/Spark requests against training-only synthetic
measurements. It deliberately does not provide the simulator's hidden law to
Meta. A failed hypothesis remains a failed result, never replaced by the known
human-authored answer. Future target outcomes are generated after commitment.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
from .discovery_milestone_v025 import source_discover,plan_probe,target_commit,target_reveal
from .synthetic_milestone_v025 import _fixture,_run,_sensor_csv


def live_meta_sandbox(out:Path, *, allow_billed_meta:bool=False,seed:int=7)->dict:
    if not allow_billed_meta:
        raise PermissionError('The sandbox will call real Meta models; use --allow-billed-meta')
    out.mkdir(parents=True,exist_ok=True)
    source_par={'stiffness_s2':1.8,'damping_s1':.32,'control_gain':1.,'effect_gain':.96}
    target_par={'stiffness_s2':2.06,'damping_s1':.43,'control_gain':.91,'effect_gain':.72}
    source_manifest=_fixture(out/'source_A_SIMULATED','SOURCE_SIMULATED',source_par,1000+seed*100)
    target_manifest=_fixture(out/'target_B_SIMULATED','TARGET_SIMULATED',target_par,
                             4000+seed*100,ntrain=2,nval=2)
    # The source hypothesis is NOT manually supplied: 3 fresh authenticated calls.
    source=source_discover(source_manifest,out/'meta_source_receipt.json',
                           live_meta=True,allow_billed_meta=True)
    status={'version':'0.26','stage':'LIVE_META_SYNTHETIC_SCIENTIFIC_EXPERIMENT',
      'meta_calls':source['meta_council_provenance']['authenticated_live_calls'],
      'meta_receipts':source['meta_council_provenance']['receipts'],
      'meta_proposed_hypotheses':source['meta_council_provenance']['proposals'],
      'source_validation':source['selection_comparison'],
      'source_candidate_accepted':source['source_candidate_accepted_for_transfer'],
      'actual_physical_experiment_performed':False,
      'world':'SYNTHETIC_LIBRARY_CONSTRUCTED_WORLD_NOT_HARDWARE',
      'provider_call_receipts_not_independent_scientific_verification':True}
    if not source['source_candidate_accepted_for_transfer']:
        status['stage']='LIVE_META_HYPOTHESIS_FAILED_SIMULATED_VALIDATION'
        status['target_heldout_metrics']=None
        (out/'LIVE_META_SYNTHETIC_REPORT.json').write_text(json.dumps(status,indent=2,allow_nan=False))
        return status
    probe=plan_probe(out/'meta_source_receipt.json',target_manifest,out/'committed_target_probe.json',
                     max_distance=5.)
    plan=probe['probe_plan']
    sample=_run(7000+seed,'TARGET_SIMULATED',params=target_par,
                initial=(plan['x0_m'],plan['v0_m_s']),controls=plan['controls_m_s2'])
    probefile=out/'target_B_SIMULATED'/'probe_measured_after_design.csv'
    _sensor_csv(probefile,sample,with_time=True)
    manifest=json.loads(target_manifest.read_text())
    manifest['episodes']['train'].append(probefile.name)
    target_manifest.write_text(json.dumps(manifest,indent=2))
    control=(.3*np.sin(np.arange(95)*.081)+.25*np.cos(np.arange(95)*.044)).tolist()
    future_plan={'fixture_id':'TARGET_SIMULATED','dt_s':.025,
      'x0_m':.38,'v0_m_s':-.21,'controls_m_s2':control}
    future=out/'FUTURE_TARGET_PLAN_PREDECLARED.json'
    future.write_text(json.dumps(future_plan,indent=2))
    commit=target_commit(out/'meta_source_receipt.json',target_manifest,future,
       out/'SEALED_FUTURE_BEFORE_MEASUREMENT.json',probe_receipt=out/'committed_target_probe.json',
       probe_recording=probefile)
    # No physical/simulated target test is created before the commitment above.
    actual=_run(9000+seed,'TARGET_SIMULATED',n=95,params=target_par,
             initial=(future_plan['x0_m'],future_plan['v0_m_s']),controls=control)
    observed=out/'target_B_SIMULATED'/'future_generated_after_seal.csv'
    _sensor_csv(observed,actual,with_time=True)
    reveal=target_reveal(out/'SEALED_FUTURE_BEFORE_MEASUREMENT.json',observed,out/'target_reveal.json')
    status.update(stage='LIVE_META_SYNTHETIC_ABLATION_COMPLETE',
       forecast_commit_sha256=commit['sha256'],
       target_heldout_metrics=reveal['held_out_metrics'],
       meta_structure_beats_all_ablations=reveal['meta_structure_beats_all_ablations'],
       selected_before_future=reveal['selected_before_test'],
       no_real_world_breakthrough_claim=True)
    (out/'LIVE_META_SYNTHETIC_REPORT.json').write_text(json.dumps(status,indent=2,allow_nan=False))
    return status


def main():
    parser=argparse.ArgumentParser(description='3 real Meta calls + synthetic source/target physics (billed opt-in)')
    parser.add_argument('--out',default='demo/v026_live_meta_sandbox')
    parser.add_argument('--seed',type=int,default=7)
    parser.add_argument('--allow-billed-meta',action='store_true')
    args=parser.parse_args()
    status=live_meta_sandbox(Path(args.out),seed=args.seed,allow_billed_meta=args.allow_billed_meta)
    print(json.dumps({'stage':status['stage'],'out':str(args.out),
        'meta_calls':status['meta_calls'],
        'source_candidate_accepted':status['source_candidate_accepted'],
        'meta_structure_won':status.get('meta_structure_beats_all_ablations')},indent=2))

if __name__=='__main__':main()
