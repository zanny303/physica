"""Many proposals, one strict judge: Meta models invent new senses, and reality decides.

This is the pattern behind the 2026 AI mathematics results (thousands of model proposals, accepted only if an
automatic checker - Lean - verifies them), moved to the physical world, where there is no Lean. Physica's judge is
reality: measured ground truth the proposer never sees, on a body it never trained on.

Task: write `tone(W, fs)` - for each short window of a beam's vibration (rows of W), return the beam's first tone
in Hz (numpy only, run in Physica's sandbox). Physica turns tones into "where is the hidden support" with its own
physics, then scores millimetres against the lab's position transducer:
  SELECT  first half of beam A        (used to rank and breed proposals)
  PROVE   second half of beam A       (never shown to the proposer or used to rank)
  TRAVEL  beam B, a different machine (never shown; 1-label frame alignment, as in E16)
A proposal replaces Physica's current sense only if it wins on PROVE and on TRAVEL.

No key: an offline stand-in writes programs from a small family of textbook estimators, labelled NOT Meta.
"""
from __future__ import annotations

import json
import random
import re

import numpy as np

from physica.discover import sandbox
from physica.llm import meta_client as mc

PROMPT = """You are inventing a new SENSE for Physica. Input: W, an array (windows x samples) of a clamped steel
beam's acceleration, band-passed around its first bending tone, sampled at fs Hz (each window is 0.3 s). Something
hidden (a support) slides along the beam, so the tone changes from window to window (roughly {lo:.0f}-{hi:.0f} Hz).
Write {n} DIFFERENT python functions, each in its own ```python block:
def tone(W, fs):
    # numpy only (np available, no other imports). Return one float per row: the first tone in Hz.
Ideas: zero-padded FFT with peak interpolation, autocorrelation, subspace/Prony methods, phase slopes, robust
averaging, rejecting windows that are not ringing. Each program is run in a sandbox (10 s for all windows) and judged
by how many millimetres off its tones put the hidden support, against a measuring device you never see.
Best programs so far and their judged errors (median mm, lower is better):
{elite}"""

FAMILY = {
    "fft_peak": """def tone(W, fs):
    n = W.shape[1] * {pad}
    S = np.abs(np.fft.rfft(W * np.{win}(W.shape[1]), n=n, axis=1))
    f = np.fft.rfftfreq(n, 1.0 / fs)
    m = (f > {lo}) & (f < {hi})
    k = np.argmax(S[:, m], axis=1)
    return f[m][k]""",
    "fft_parabolic": """def tone(W, fs):
    n = W.shape[1] * {pad}
    S = np.log(np.abs(np.fft.rfft(W * np.{win}(W.shape[1]), n=n, axis=1)) + 1e-12)
    f = np.fft.rfftfreq(n, 1.0 / fs)
    idx = np.where((f > {lo}) & (f < {hi}))[0]
    k = idx[np.argmax(S[:, idx], axis=1)]
    k = np.clip(k, 1, S.shape[1] - 2)
    r = np.arange(len(W))
    a, b, c = S[r, k - 1], S[r, k], S[r, k + 1]
    d = 0.5 * (a - c) / (a - 2 * b + c + 1e-12)
    return (k + np.clip(d, -0.5, 0.5)) * fs / n""",
    "autocorr": """def tone(W, fs):
    X = W - W.mean(axis=1, keepdims=True)
    n = X.shape[1]
    F = np.fft.rfft(X, n=2 * n, axis=1)
    R = np.fft.irfft(F * np.conj(F), axis=1)[:, :n]
    lo_lag, hi_lag = int(fs / {hi}), int(fs / {lo})
    seg = R[:, lo_lag:hi_lag]
    k = np.argmax(seg, axis=1) + lo_lag
    return fs / k""",
}


@mc.register_mock("evolve_tone")
def _stand_in(messages):
    txt = messages[-1]["content"]
    n = int(re.search(r"Write (\d+)", txt).group(1))
    lo, hi = (float(v) for v in re.search(r"roughly (\d+)-(\d+) Hz", txt).groups())
    rng = random.Random(abs(hash(txt)) % (2 ** 32))
    out = []
    for _ in range(n):
        name = rng.choice(list(FAMILY))
        code = FAMILY[name].format(pad=rng.choice([1, 2, 4, 8, 16]), win=rng.choice(["hanning", "hamming", "blackman", "ones"]),
                                   lo=round(lo * rng.uniform(0.8, 1.0), 1), hi=round(hi * rng.uniform(1.0, 1.3), 1))
        out.append(f"# OFFLINE STAND-IN (not Meta): textbook estimator '{name}'\n```python\n{code}\n```")
    return "\n\n".join(out)


def programs(text: str) -> list[str]:
    return [p.strip() for p in re.findall(r"```python\n(.*?)```", text or "", flags=re.S)]


def windows(x, fs, band, win=0.3, hop=0.05, target_fs=None):
    from scipy import signal

    from physica.cause.track import decimate_to
    y, f2 = decimate_to(x, fs, target_fs or max(4 * band[1], 400.0))
    y = signal.sosfiltfilt(signal.butter(4, [band[0] * 0.8, min(band[1] * 1.2, f2 * 0.45)], "bandpass", fs=f2, output="sos"), y)
    n, h = int(win * f2), int(hop * f2)
    idx = np.arange(0, len(y) - n, h)
    W = np.stack([y[i:i + n] for i in idx])
    return W, f2, idx / f2 + win / 2


def judge(code: str, W, fs, to_mm, truth_mm, mask=None, timeout=10.0) -> dict:
    try:
        out = sandbox.run(code, "tone", {"W": W, "fs": np.array(fs)}, timeout=timeout)["out"]
    except sandbox.Rejected as e:
        return {"ok": False, "why": str(e)[:200]}
    out = np.asarray(out, float).ravel()
    if out.shape[0] != W.shape[0]:
        return {"ok": False, "why": f"returned {out.shape[0]} tones for {W.shape[0]} windows"}
    where = to_mm(out)
    e = np.abs(where - truth_mm)
    if mask is not None:
        e = e[mask]
    e = e[np.isfinite(e)]
    if len(e) < 10:
        return {"ok": False, "why": "too few usable tones"}
    return {"ok": True, "median_mm": float(np.median(e)), "mean_mm": float(np.mean(e)), "tones": out}


def run(A: dict, B: dict, generations: int = 4, n: int = 8, keep: int = 3, role: str = "wonder", seed: int = 0,
        swarm: int = 1) -> dict:
    """A, B: {'W','fs','to_mm','truth_mm'} (B's truth used only after the search, 1-label aligned).
    swarm: independent proposers per generation, called in parallel (each sees the same elite; the cost stop still
    applies to every call)."""
    nA = len(A["W"])
    select = np.arange(nA) < nA // 2
    prove = ~select
    lo, hi = A["band"]
    history, elite, seen = [], [], set()
    for g in range(generations):
        el = "\n".join(f"[{e['median_mm']:.2f} mm]\n```python\n{e['code']}\n```" for e in elite) or "(none yet)"
        from concurrent.futures import ThreadPoolExecutor

        def ask(k):
            msg = [{"role": "user", "content": PROMPT.format(n=n, lo=lo, hi=hi, elite=el) +
                    (f"\n(Proposer {k + 1} of {swarm}: try ideas the others are unlikely to try.)" if swarm > 1 else "")}]
            return mc.complete(role, msg, task="evolve_tone", max_completion_tokens=6000)

        with ThreadPoolExecutor(max_workers=max(1, min(swarm, 8))) as ex:
            replies = list(ex.map(ask, range(swarm)))
        r = replies[0]
        codes = [c for rr in replies for c in programs(rr["content"])]
        for code in codes:
            if code in seen:
                continue
            seen.add(code)
            j = judge(code, A["W"], A["fs"], A["to_mm"], A["truth_mm"], mask=select)
            row = {"generation": g, "code": code, "mode": r["mode"], **({k: v for k, v in j.items() if k != "tones"})}
            history.append(row)
            if j["ok"]:
                elite.append(row)
        elite = sorted(elite, key=lambda e: e["median_mm"])[:keep]
    out = {"proposals": len(history), "valid": sum(h["ok"] for h in history), "mode": history[-1]["mode"] if history else None,
           "generations": [{"generation": g, "best_select_mm": min([h["median_mm"] for h in history if h["generation"] <= g and h["ok"]] or [None])}
                           for g in range(generations)]}
    if not elite:
        out["verdict"] = "no proposal ran"
        return out
    best = elite[0]
    pa = judge(best["code"], A["W"], A["fs"], A["to_mm"], A["truth_mm"], mask=prove)
    pb = judge(best["code"], B["W"], B["fs"], B["to_mm"], B["truth_mm"])
    out["champion"] = {"code": best["code"], "select_mm": best["median_mm"], "prove_A_mm": pa.get("median_mm"),
                       "travel_B_mm": pb.get("median_mm") if pb.get("ok") else None}
    return out
