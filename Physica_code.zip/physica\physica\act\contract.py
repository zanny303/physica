"""Action contracts: every action Physica takes carries a promise about what the machine should feel afterwards.

This is the efference-copy idea applied to Physica's own actions. A brain predicts the feeling its own movement
will cause and cancels it; Physica writes down the feeling its action should cause BEFORE acting, then feels
again and compares. If the promise holds, the action is kept and recorded as proven. If it doesn't, the action
is rolled back and recorded as 'didn't work' (a negative result is knowledge too).

The promise is fixed before the measurement exists: `promise()` returns a frozen record with a timestamp and a
digest, and `judge()` refuses a promise whose digest doesn't match (so the bar can't move after the fact).
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import operator

OPS = {">=": operator.ge, "<=": operator.le, ">": operator.gt, "<": operator.lt}


def _digest(p: dict) -> str:
    body = {k: p[k] for k in ("action", "text", "checks", "made_at_utc")}
    return hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()[:16]


def promise(action: str, text: str, checks: list[dict]) -> dict:
    """checks: [{"metric": name, "op": ">=", "value": number, "say": plain words}]"""
    for c in checks:
        if c["op"] not in OPS:
            raise ValueError(f"unknown op {c['op']}")
    p = {"action": action, "text": text, "checks": checks,
         "made_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")}
    p["digest"] = _digest(p)
    return p


def judge(p: dict, measured: dict) -> dict:
    if _digest(p) != p.get("digest"):
        raise ValueError("promise was changed after it was made")
    rows = []
    for c in p["checks"]:
        m = measured.get(c["metric"])
        ok = m is not None and bool(OPS[c["op"]](m, c["value"]))
        rows.append({**c, "measured": m, "pass": ok})
    kept = all(r["pass"] for r in rows)
    return {"verdict": "kept" if kept else "rolled back", "checks": rows,
            "text": ("The machine felt what Physica promised, so the change is kept."
                     if kept else "The machine did not feel what Physica promised, so the change is rolled back "
                                  "and recorded as 'didn't work'.")}


def notch_promise(freq_hz: float, bw_hz: float, min_drop_db: float = 10.0, max_side_db: float = 3.0) -> dict:
    """The ArduPilot notch's promise: the shake the controller feels at the felt frequency drops a lot, and
    nothing else it feels moves much (a notch that blurs everything would hide real problems)."""
    return promise(
        f"ArduPilot harmonic notch at {freq_hz:.1f} Hz (width {bw_hz:.1f} Hz)",
        f"After the change, the shake the flight controller feels around {freq_hz:.0f} Hz drops by at least "
        f"{min_drop_db:.0f} dB, and everything else it feels changes by less than {max_side_db:.0f} dB.",
        [{"metric": "in_band_reduction_db", "op": ">=", "value": min_drop_db,
          "say": f"shake near {freq_hz:.0f} Hz drops ≥ {min_drop_db:.0f} dB"},
         {"metric": "abs_out_of_band_change_db", "op": "<=", "value": max_side_db,
          "say": f"everything else moves < {max_side_db:.0f} dB"}])


def plc_promise(trip_gmm: float, limit_gmm: float) -> dict:
    return promise(
        f"PLC function block: alarm, then trip at {trip_gmm:.0f} g·mm",
        f"The machine stays quiet while balanced, and trips before imbalance reaches {limit_gmm:.0f} g·mm.",
        [{"metric": "alarm_when_balanced", "op": "<=", "value": 0, "say": "no alarm on a balanced shaft"},
         {"metric": "trip_at_gmm", "op": "<", "value": limit_gmm, "say": f"trips before {limit_gmm:.0f} g·mm"}])
