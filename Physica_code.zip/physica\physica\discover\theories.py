"""Propose: Muse Spark writes rival theories as code (SPEC 4.2). Prove: three splits + conformal + physics checks.

A theory is a Python function `simulate(params, x) -> y` plus a parameter box. Theories run only in the sandbox.
"""
from __future__ import annotations

import json
import re

import numpy as np

from physica.discover import sandbox
from physica.llm import meta_client as mc

PROMPT = """You are the physicist inside Physica. Data summary (JSON) of a machine signal follows.
Write {n} RIVAL theories for how y depends on x. Each theory is a fenced python block containing:
NAME = "short name"
PARAMS = {{"param": [low, high], ...}}
def simulate(params, x):
    # numpy only (np is available), vectorised over x, returns y
Make the theories genuinely different in physical assumption. No imports except numpy/math.
Data summary:
{summary}"""


@mc.register_mock("theories")
def _mock_theories(messages: list[dict]) -> str:
    """Offline stand-in for Spark (MOCK mode). Four textbook-style rival theories."""
    blocks = [
        ('constant level', '{"c": [-12, 12]}', "return np.full_like(x, params['c'], dtype=float)"),
        ('linear in rotor speed', '{"a": [-1, 1], "c": [-60, 60]}', "return params['a'] * x + params['c']"),
        ('quadratic resonance shape', '{"a": [-0.01, 0.01], "x0": [80, 220], "c": [-12, 12]}',
         "return params['a'] * (x - params['x0']) ** 2 + params['c']"),
        ('power law in speed', '{"k": [-8, 8], "c": [-60, 60]}', "return params['k'] * np.log10(x) + params['c']"),
    ]
    return "\n\n".join(f'```python\nNAME = "{n}"\nPARAMS = {p}\ndef simulate(params, x):\n    {b}\n```' for n, p, b in blocks)


def parse(text: str) -> list[dict]:
    out = []
    for code in re.findall(r"```python\n(.*?)```", text, flags=re.S):
        try:
            sandbox.check_ast(code)
            name = re.search(r'NAME\s*=\s*"([^"]+)"', code).group(1)
            params = json.loads(re.search(r"PARAMS\s*=\s*(\{.*?\})\n", code, flags=re.S).group(1))
            out.append({"name": name, "params": params, "code": code})
        except Exception as e:  # unparseable or rejected theories are recorded, not run
            out.append({"name": "rejected", "error": str(e), "code": code})
    return out


BASELINE = {"name": "constant level", "params": {"c": [-100, 100]},
            "code": 'NAME = "constant level"\nPARAMS = {"c": [-100, 100]}\ndef simulate(params, x):\n'
                    '    return np.full_like(x, params["c"], dtype=float)\n'}


def propose(summary: dict, n: int = 4) -> list[dict]:
    text = mc.chat("spark", [{"role": "user", "content": PROMPT.format(n=n, summary=json.dumps(summary))}],
                   task="theories", max_tokens=2500)
    th = parse(text)
    if not any(t.get("name") == "constant level" for t in th):  # every theory must beat 'nothing changes'
        th.append(dict(BASELINE))
    return th


def fit(theory: dict, x: np.ndarray, y: np.ndarray, fit_mask: np.ndarray) -> dict:
    names = list(theory["params"])
    lo = [theory["params"][k][0] for k in names]
    hi = [theory["params"][k][1] for k in names]
    out = sandbox.run(theory["code"], "simulate", {"x": x, "y": y, "fit_mask": fit_mask.astype(np.int8)}, mode="fit",
                      extra={"param_names": names, "lo": lo, "hi": hi, "starts": 4})
    return {"params": dict(zip(names, out["params"].tolist())), "pred": out["pred"]}


def prove(theories: list[dict], x: np.ndarray, y: np.ndarray, splits: dict, rel_tol: float = 1.2,
          physics_checks=None) -> dict:
    """Fit on 'fit', choose on 'select', judge ONLY on 'prove'. Winner must beat the 'constant' baseline on prove
    and pass physics checks; error bars are split-conformal from the select split."""
    res = []
    for th in theories:
        if th.get("name") == "rejected":
            res.append({**th, "status": "rejected"})
            continue
        try:
            f = fit(th, x, y, splits["fit"])
        except sandbox.Rejected as e:
            res.append({"name": th["name"], "status": "failed to run", "error": str(e)})
            continue
        err = lambda m: float(np.sqrt(np.mean((f["pred"][m] - y[m]) ** 2)))
        checks = [c(th, f, x) for c in (physics_checks or [])]
        ok_phys = all(c["pass"] for c in checks)
        res.append({"name": th["name"], "params": f["params"], "rmse_fit": err(splits["fit"]),
                    "rmse_select": err(splits["select"]), "rmse_prove": err(splits["prove"]),
                    "physics": checks, "physics_ok": ok_phys, "status": "ran", "_pred": f["pred"], "code": th["code"]})
    ran = [r for r in res if r["status"] == "ran" and r["physics_ok"]]
    if not ran:
        return {"verdict": "nothing proven", "theories": _clean(res)}
    best = min(ran, key=lambda r: r["rmse_select"])
    resid = np.abs(best["_pred"][splits["select"]] - y[splits["select"]])
    n = len(resid)
    q = float(np.sort(resid)[min(n - 1, int(np.ceil((n + 1) * 0.9)) - 1)]) if n else float("nan")
    cover = float(np.mean(np.abs(best["_pred"][splits["prove"]] - y[splits["prove"]]) <= q))
    base = next((r for r in res if r["name"] == "constant level" and r["status"] == "ran"), None)
    beats = base is None or best["rmse_prove"] < base["rmse_prove"] / rel_tol if best is not base else False
    verdict = "proven" if (beats and cover >= 0.8) else "not proven"
    for r in res:
        r["outcome"] = ("winner" if r is best else "falsified (worse on held-out)") if r["status"] == "ran" else r["status"]
    return {"verdict": verdict, "winner": best["name"], "conformal_halfwidth_90": q, "prove_coverage": cover,
            "beats_constant_baseline": bool(beats), "theories": _clean(res)}


def _clean(res):
    return [{k: v for k, v in r.items() if not k.startswith("_")} for r in res]
