"""Torque Feel: a robot arm feels touch, extra load and wear with no touch sensor.

The robot's controller already predicts the torque its own planned motion needs (its efference copy). Physica
cancels that prediction, then cancels the part of the leftover the robot ALWAYS has at each moment of its task
(friction, model error), learned from normal cycles only. What remains is what the world did to the robot.

Own coordinates for a robot: the phase of its task (0 = cycle start, 1 = cycle end), not seconds, so cycles of
slightly different length line up. Same procedure shape as Order Feel: re-time, self-cancel, calibrate on healthy.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


def _phase_resample(t: np.ndarray, x: np.ndarray, bins: int) -> np.ndarray:
    ph = (t - t[0]) / max(t[-1] - t[0], 1e-9)
    grid = np.linspace(0, 1, bins)
    return np.stack([np.interp(grid, ph, x[:, j]) for j in range(x.shape[1])], axis=0)  # (joints, bins)


@dataclass
class TorqueFeel:
    bins: int = 200
    smooth_bins: int = 5
    std_floor: float = 1e-3
    q: float = 0.99
    margin: float = 0.5
    mu: np.ndarray | None = None
    sd: np.ndarray | None = None
    threshold: float | None = None
    meta: dict = field(default_factory=dict)

    def residual(self, cyc: dict) -> np.ndarray:
        return _phase_resample(cyc["t"], cyc["measured"] - cyc["predicted"], self.bins)

    def leftover(self, cyc: dict) -> np.ndarray:
        z = (self.residual(cyc) - self.mu) / self.sd
        k = np.ones(self.smooth_bins) / self.smooth_bins
        return np.stack([np.convolve(r, k, mode="same") for r in z])

    def score(self, cyc: dict) -> float:
        return float(np.abs(self.leftover(cyc)).max())

    def fit(self, normal_cycles: list[dict]) -> "TorqueFeel":
        R = np.stack([self.residual(c) for c in normal_cycles])
        self.mu, self.sd = R.mean(0), np.maximum(R.std(0, ddof=1) if len(R) > 1 else np.ones_like(R[0]), self.std_floor)
        s = np.array([self.score(c) for c in normal_cycles])
        self.threshold = float(np.quantile(s, self.q) + self.margin)
        self.meta = {"n_normal_cycles": len(normal_cycles)}
        return self

    def where(self, cyc: dict) -> dict:
        L = np.abs(self.leftover(cyc))
        j, b = np.unravel_index(L.argmax(), L.shape)
        return {"joint": int(j) + 1, "phase": round(float(b / (self.bins - 1)), 2)}
