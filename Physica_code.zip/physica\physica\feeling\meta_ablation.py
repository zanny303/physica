"""Physica v0.7 reproducible Meta-on/off causal-candidate comparison.

Model outputs *nominate* bounded mechanism names. Physica independently fits
force residuals. This function does not call Meta, and an offline JSON reply
is never evidence of authenticated inference. Train/heldout interventions are
identical in the two arms: no hidden data-budget advantage for Meta.
"""
from __future__ import annotations
from .core import Body
from .mechanism_transfer import FEATURES, discover_and_sign


def compare_meta_candidates(body:Body,training,heldout,meta_reply,*,displacement_reference_m,
                            source_provenance='UNVERIFIED_OFFLINE_REPLY'):
    if not isinstance(meta_reply,dict):raise ValueError('model response must be structured')
    proposals=meta_reply.get('hypotheses',[])
    if not isinstance(proposals,list):raise ValueError('invalid candidate list')
    names=[]
    for p in proposals:
        if not isinstance(p,dict):continue
        # Never allow Muse to provide force parameters or arbitrary code.
        family=p.get('mechanism_family',p.get('name'))
        if family in FEATURES and family not in names:names.append(family)
    control=discover_and_sign(body,training,heldout,displacement_reference_m=displacement_reference_m,
                              allowed_mechanisms=FEATURES)
    assisted=(discover_and_sign(body,training,heldout,displacement_reference_m=displacement_reference_m,
                                allowed_mechanisms=names) if names else {'status':'ABSTAIN_NO_GROUNDED_CANDIDATE'})
    return {'schema':'physica.feeling.meta-ablation.v07',
            'model_provenance':source_provenance,
            'authenticated_live_inference':False,
            'approved_meta_candidate_names':names,
            'equal_training_and_heldout_interventions':True,
            'physics_all_candidates_status':control['status'],
            'meta_restricted_status':assisted['status'],
            'physics_all_candidate_count':len(FEATURES),
            'meta_restricted_candidate_count':len(names),
            'physics_best_family':control.get('record',{}).get('payload',{}).get('mechanism'),
            'meta_best_family':assisted.get('record',{}).get('payload',{}).get('mechanism'),
            'evidence_note':'Candidate reduction is not improved prediction; requires independently collected Meta outputs and empirical trials',
            'hardware_actuation_allowed':False}
