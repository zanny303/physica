"""Filmable clips made only from saved results. Every clip carries a label saying where its data came from."""
