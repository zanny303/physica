# Physica v0.11 — Reliable Causal Feeling & Meta Scientist

**Patch + research evaluation release based on v0.10.0rc1.** The exact source archive is preserved except for the documented module, CLI, tests, docs and Studio changes.

- Fixed MACE's research benchmark crash from divergent learned PCA/Ridge rollouts, replacing it with chronologically validation-gated model choice and safe abstention.
- Replaced constant `target_value_proxy` with candidate-specific Gaussian posterior target-variance reduction, plus approximate inter-mechanism information, cost/risk/goal ranking.
- Added a reproducible target-probe benchmark with equal-budget random-probe comparison (simulated, conditional on known physics).
- Added missing-sense acquisition planning requiring independently calibrated measurement operators, explicitly rejecting fabricated virtual-sensor measurements.
- Added Meta → bounded mechanism term → physical parameter fit → held-out validation → prospective experiment proposal using controlled input and an explicit paid API gate.
- Added official Meta SAM 3.1 parser bridge that converts authenticated pixel tracks to calibrated displacement only after reference/scale checks.
- Repaired missing `MACE` Studio dashboard task-group rendering and added new research tasks.
- Preserved all previous user-facing Lab/Discover/Lens, machine-draft, CRATE and CIRTE modules.

**Do not claim:** real-world superiority, authenticated Meta inference performed here, novel law discovered, safety-certified machine control, all five working senses, autonomous consumer repairs, or validated scientific novelty.

See `docs/V011_RELIABLE_CAUSAL_FEELING.md` for commands, metrics, failure cases, and research sources.
