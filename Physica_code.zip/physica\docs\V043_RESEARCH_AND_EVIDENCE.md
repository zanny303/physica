# Physica v0.4.3 – Causal sensory discovery research release

**Version:** 0.4.3. **Scope:** executable research software layered on the original Physica project. **Honesty rule:** software test success is not a real-world scientific discovery; model adapter presence is not an authenticated Meta inference.

## Research question

Can action-conditioned knowledge be transferred from one body and sensor configuration to another using physically grounded latent-state operators, with enough confidence to decide which controlled experiment could actually distinguish mechanisms? The key is not claiming “the first AI with five senses” but estimating *cause → intervention → observable consequences*, encoding transferable conditions and measuring when the mapping is not identifiable.

## Research-backed architectural choices

1. **TacX (CoRL 2025)** learns shared representations from tactile image, sound, motion and pressure. Therefore multisensory fusion itself is **prior art**. Physica should test intervention-conditional, body-conditional transfer as an increment. https://proceedings.mlr.press/v305/higuera25a.html
2. **Cross-Sensor Touch Generation (CoRL 2025)** demonstrates tactile transfer, including with a common intermediate depth representation. Therefore transferring between sensor modalities is **prior art**. Physica’s putative contribution is a physical *causal response operator* with abstention and testable response, not image translation. https://proceedings.mlr.press/v305/rodriguez25a.html
3. **V-JEPA 2 (Meta FAIR, 2025)** predicts visual states; action-conditioned V-JEPA 2-AC supports robotics planning. It does **not** automatically output calibrated force or stiffness. The new `world_readout.py` accepts exported features only, trains on body-disjoint SI-labeled outcomes and split-calibrates prediction intervals. It does not download Meta weights. https://ai.meta.com/research/publications/v-jepa-2-self-supervised-video-models-enable-understanding-prediction-and-planning/ and https://github.com/facebookresearch/vjepa2
4. **Residual Physics Learning (Sontakke et al., 2023)** learns unmodeled dynamics for robot transfer. Residual correction is **prior art**; Physica CRATE combines scaled physical residuals with transfer checks and event provenance. https://arxiv.org/abs/2303.09597
5. **Multimodal causal representation learning (ICLR 2025)** establishes identifiability under *specific sparsity assumptions*. Physica should never infer unique causal truth from arbitrary paired sensor readings. `discovery.py` refuses when candidate consequences overlap; still not a general causal-identification proof. https://proceedings.iclr.cc/paper_files/paper/2025/hash/2ec91b31ac4aa578d99309d4f00c81ad-Abstract-Conference.html
6. **ConformalDAgger (ICLR 2025)** and **CaPTURe (COPA 2026)** motivate uncertainty-based intervention and contact-dependent calibration. Exchangeability and shifts matter. The readout reports split-conformal **marginal** intervals on matching data only and abstains on gross embedding novelty; no safety guarantee under unknown dynamics. https://proceedings.iclr.cc/paper_files/paper/2025/hash/19deda616aebc9bee6c1990baa5f1f0e-Abstract-Conference.html and https://proceedings.mlr.press/v329/marques26a.html

## New implementation

- `physica/grammar/discovery.py`: independent mechanism hypotheses, predictive response operators for displacement/velocity/acceleration, constrained supervised probe selection, identifiability refusal, prospective Gaussian-likelihood update with explicit effective-sample assumption. Separation is a *surrogate* of information gain, not exact EIG. The candidate set must be physically specified in advance.
- `physica/grammar/world_readout.py`: fit a regularized linear readout of exported visual-world embeddings to an independently measured scalar in SI units; hold out **entire body IDs** for calibration; compute a split-conformal absolute-residual interval; refuse obvious latent OOD inputs and body leakage. Not V-JEPA inference and not a validation of coverage under shift.
- `physica/grammar/sensor_audio.py`: load real WAV PCM, detect clipping and spectral peaks, hash original audio, compare independently identifiable timing markers; strictly no uncalibrated conversion of microphone amplitudes into newtons/meters.
- `physica/grammar/chemical.py`: independent first-order response-kinetics fit from calibrated concentration or conductivity sensors; explicitly not a molecular identity classifier and not a mechanical FFT. Real chemical sensors need hardware calibration, drift and selectivity studies.
- `physica/grammar/frontier_benchmark.py`: true mechanism sampled *after* intervention plan is fixed, compares selected probe to random eligible probe, exercises synthetic visual embedding readout and OOD abstention, and reports assumptions. The simulator generates data from the same candidate family: this is a deliberately easy synthetic test, **not real scientific confirmation**.
- `physica grammar discover`: turns mechanistic calibration candidates and a safety-approved action whitelist into a *suggestion*, with no actuator control. A Muse hypothesis hint can only influence prior numerically after separately held-out reliability counts of that precise model/domain. Without such evidence, it is inert.

## Meta's **necessary** role and how to prove it

- Muse Spark: identify scene geometry, operating state, confounds and missing measurements that **change the candidate causal graph**. Use structured output; schema-validate names/constraints. Give it measured facts and video, not authority to invent numeric force values.
- SAM 3.1: provide tracked geometric regions; integrate tracked displacement only when camera scale, clock, and external sensor cross-check are available. Existing `grammar meta-csg-live` provides that adapter; **untested without credentials/media**.
- Muse Wonder: propose rival mechanisms and safe experiment classes, subject to a physical safety whitelist. When its hypotheses have been separately validated, optional bounded context priors can change numerical experiment ranking; otherwise compare/report suggestions as qualitative hypotheses only.
- V-JEPA 2: independently run local pretrained weights, export visual features, fit the new body-disjoint *physical readout* and verify prediction against actual independent sensor records. To show true dual-world disagreement, compare calibrated physics and V-JEPA measurements on identical observables, units, and time grids. An embedding alone cannot be used as a force measurement.
- Muse Glimmer: optional local, user-provisioned text/scene descriptions; no model weights bundled and no automatic download.
- To claim Meta materially **improved** Physica: preregister a held-out set of recordings, run Meta-on vs Meta-off under an identical sensor/action budget, record part-localization accuracy, false hypothesis rate, experiment count to a predefined error threshold, and irreversible-action refusal. A synthetic `meta_candidate_hints` field is **not** a real ablation.

### Tested and untested model capabilities

According to Meta developer docs (as checked October 30, 2026), the Model API base URL is `https://api.meta.ai/v1`, using `MODEL_API_KEY`; Muse Spark / Wonder and SAM 3.1 are hosted, while V-JEPA 2 weights are in the research repository. Authenticated API execution remains **unverified here**. https://dev.meta.ai/docs/overview ; https://dev.meta.ai/docs/media-segmentation

## Six senses / ontological limitations

| Sense | Current pathway | Cannot honestly claim without hardware |
|---|---|---|
| Sight | local frame-to-motion, optional Meta SAM pixel tracks and independent camera calibration | universal measurement of forces from arbitrary pixels |
| Hearing | **actual WAV audio ingestion and frequency/clock features**, independently calibrated dynamics converter only | arbitrary microphone -> accurate force without transfer function |
| Touch | force/displacement/acceleration sensor channel, Touch Transform and CRATE | high-resolution skin-like feel without a tactile sensor |
| Proprioception | measured inertial/motor-state channels | self-knowledge without calibrated body dynamics |
| Smell | calibrated chemical concentration channel with response-time fitting | identifying unknown chemical molecules from a single generic VOC level |
| Taste | calibrated conductivity/pH types and step conductivity kinetics | identifying arbitrary dissolved compounds from a pH/conductivity reading |

## Formal novelty target (candidate, NOT yet proved)

Let a body have hidden physical state z and an intervention a. Different sensors observe `y_m = h_m(z,c) + noise`; mechanistic predictions define `y_hat_m(z,c,a)`. The proposed **causal sensory grammar** stores interventions and **unitful counterfactual response kernels** `K_{a→m}(τ,c)` and their transferable dimensionless constraints. Before transfer, check compatibility, physical observability, sensor calibration and cross-modal state-identifiability. Pick safe reversible tests that separate competing models by their predicted response distributions; seal the forecast before data collection; update physical memory and check predictions on unseen machine C. The *composition* may be a novel engineering contribution; no individual formula is claimed as invented.

If two causes predict the same recorded sensor response, the experiment is **unidentifiable** even if an LLM writes a confident story. The new algorithm returns `stop_unidentifiable_or_unsafe` when no discriminating supervised probe exists.

## Reproducible offline commands

```bash
pip install -e '.[dev]'
python -m physica.cli grammar demo --out demo/csg
python -m physica.cli grammar research-benchmark --out demo/research_v043.json --trials 32
python -m physica.cli grammar discover examples/frontier_v043/mechanisms_SIMULATED.json --out demo/probe.json
python -m physica.cli grammar audio-audit some_real_audio.wav --out demo/audio.json
python -m physica.cli grammar world-fit examples/frontier_v043/embeddings_SIMULATED_train_cal.npz --model-id SYNTHETIC-NOT-VJEPA --observable displacement --unit m --out demo/readout.json
python -m physica.cli grammar world-predict demo/readout.json examples/frontier_v043/embeddings_SIMULATED_test.npz --out demo/world.json
pytest -q tests/test_frontier_v043.py tests/test_grammar_v042.py tests/test_crate_v041_audit.py
```

**Real-world protocol:** Use `physica grammar source` on real calibrated A CSVs plus signed/witnessed attestation, `prepare` on B's time-only grid, physically perform an approved low-force probe, `check` the signed target measurement, `learn-next`, then seal C before observing it. Preregister source selection, units, clocks, candidate hypotheses and calibration splits; let a separate witness record the chronology. Use multiple distinct bodies and compare to physics-only, within-target system identification, CRATE, nearest-neighbor transfer, Koopman/latent-dynamics baselines. Report failures and domain shifts. The repository does NOT autonomously actuate machines.

## Submission risks and go/no-go

- **Stop** if actual physical data is unavailable, independent camera/audio timing uncertain, calibration inconsistent, LLM candidate unsupported by measurements, or transfer becomes overconfident under shift.
- Physical experiments cannot be substituted with synthetic assertions. Real Meta billing calls cannot be executed without the owner's locally configured key, and V-JEPA's non-trivial pretrained weights and inference runtime must be provisioned separately.
- Meta's official Indie judging emphasizes creativity, technical ambition and whether the project *works*. Before November 4, 2026, the highest-impact proof is a single independently witnessed A→B prediction plus Meta-on/off experimental evidence: https://dev.meta.ai/events/global-hackathon

## Three-minute hackathon film outline

0:00—0:15: Show a sealed prediction *before* measurement of a distinct B machine; no numeric outcome displayed early. 0:15—0:40: Show A learning via audio plus calibrated acceleration, with real sensor traces and time marks. 0:40—1:05: Meta Spark supplies operating context and SAM tracks the part; label actual API responses; Muse Wonder proposes rival causes. 1:05—1:35: Physica refuses an unsafe or unidentifiable probe, performs approved reversible test, observes whether prediction holds. 1:35—2:00: Translate physical experience into B's visual-motion sensor and measure result; show errors versus named baselines. 2:00—2:25: Carry B's signed experience forward to C; include domain-shift refusal. 2:25—2:45: Show Meta-on/off causal hypothesis and experiment-count metrics, honestly report failure cases. 2:45—3:00: “Machines can exchange the experimentally verified consequences of interacting with the world.” Only show a real B/C scene if it was actually filmed and externally witnessed; otherwise label simulation clearly.

## Chemical response CLI (calibrated data, not species identification)

```bash
python -m physica.cli grammar chemistry-audit examples/frontier_v043/chemical_manifest_SYNTHETIC.json --out demo/chemical.json
```

The distributed chemical example is **synthetic**. For real e-nose readings, supply independent raw-to-mol/m³ calibration, chemistry-compatible sensor selectivity characterization, and provenance; recording a VOC time constant is NOT equivalent to knowing the molecular species. The same model works for conductivity, not pH without a separately validated non-linear chemical response model.
