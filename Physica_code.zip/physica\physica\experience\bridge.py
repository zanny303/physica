"""Convert existing `physica sense FILE` results to typed physical-language episodes.

This is *passive sensing*, not verified causal inference. It preserves unknown
calibration, unknown actions, no unearned causal attribution, and raw-file hash.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from .schema import PhysicalEpisode,Sensor,ModalWord,Quantity,Action,Consequence,Provenance


def ingest(source:str|Path, *, fps:float|None=None, calibration_id:str|None=None,
           body_id:str="unlabelled",machine_id:str="phone-or-sensor",
           boundary_class:str="unknown") -> PhysicalEpisode:
    from physica.sense import sense
    source=Path(source)
    if not source.is_file():raise FileNotFoundError(source)
    result=sense(source,fps=fps)
    words=[]
    for i,w in enumerate(result["words"]):
        if w.get("freq_hz",0)<=0:continue
        amp=w.get("amp")
        if amp is not None and amp<0:amp=None
        words.append(ModalWord(mode_id=f"mode-{i+1}",
                               frequency=Quantity(value=float(w["freq_hz"]),unit="Hz"),
                               damping_ratio=Quantity(value=float(w["damping"]),unit="1"),
                               excitation_level=Quantity(value=float(amp),unit="arb") if amp is not None else None))
    body_type=result["bodies"][0]["type"] if result["bodies"] else "unknown"
    modality="video" if result["kind"]=="video" else "acceleration"
    return PhysicalEpisode(episode_id="sensed-"+hashlib.sha256(source.read_bytes()).hexdigest()[:18],
                           body_id=body_id,machine_id=machine_id,body_class=body_type,
                           boundary_class=boundary_class,
                           sensors=[Sensor(sensor_id="sensor0",modality=modality,
                                sampling_rate_hz=Quantity(value=float(result["fs"]),unit="Hz"),
                                calibrated=bool(calibration_id),calibration_id=calibration_id)],
                           action=Action(action_id="unknown_action",action_type="passive_observation",
                                         safety_approved=False),modal_words=words,
                           consequence=Consequence(observable="dynamics_change_unknown",note="No verified intervention or consequence"),
                           provenance=Provenance(origin="real_sensor",raw_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                                                 source_uri=str(source),evidence_note="Physical features extracted by original Physica sense; unknown measurement uncertainty."))
