"""Non-actuating, evidence-recomputed machine configuration drafts.

A signed claim alone is insufficient: raw CSV SHA-256 and spectral peak must agree.
No model-generated arbitrary source code is executed or flashed to any device.
"""
from __future__ import annotations
import csv,hashlib,math
from pathlib import Path
import numpy as np
from physica.library.sign import verify
from physica.remote_bench.machine_drafts import draft


def from_signed_trace(receipt,raw_csv,*,target):
    if not isinstance(receipt,dict) or set(receipt)!={'payload','signature'}:raise ValueError('signed raw receipt required')
    p=receipt['payload']
    if not verify(p,receipt['signature']):raise ValueError('invalid or altered evidence signature')
    if p.get('measurement_origin') not in ('external_recorded','supervised_physical_experiment'):
        raise ValueError('simulated data cannot authorize real configuration draft')
    if p.get('independent_calibration') is not True or p.get('acceleration_unit')!='m/s^2':
        raise ValueError('calibrated acceleration evidence required')
    path=Path(raw_csv)
    raw=path.read_bytes()
    if len(raw)>8_000_000 or hashlib.sha256(raw).hexdigest()!=p.get('sha256'):
        raise ValueError('raw recording hash mismatch')
    reader=csv.DictReader(raw.decode('utf-8-sig').splitlines())
    if not {'t','acceleration'}<=set(reader.fieldnames or []):raise ValueError('time + acceleration required')
    time=[];values=[]
    for row in reader:
        time.append(float(row['t']));values.append(float(row['acceleration']))
    if len(time)<128 or not np.isfinite(time).all() or not np.isfinite(values).all():raise ValueError('not enough finite raw measurements')
    t=np.asarray(time);v=np.asarray(values);dt=np.diff(t)
    if np.any(dt<=0) or np.std(dt)/np.mean(dt)>.005:raise ValueError('uniform independent sampling required')
    f=np.fft.rfftfreq(len(v),float(np.mean(dt)));spec=np.abs(np.fft.rfft((v-v.mean())*np.hanning(len(v))))
    valid=(f>=5)&(f<=min(180,.45/np.mean(dt)))
    if not valid.any():raise ValueError('unable to resolve target frequency')
    peak=float(f[valid][np.argmax(spec[valid])]);declared=p.get('resonance_frequency_hz')
    if not isinstance(declared,(float,int)) or not math.isfinite(declared) or abs(peak-declared)>max(2.,.04*peak):
        raise ValueError('claimed resonance unsupported by raw recording')
    damp=p.get('damping_ratio')
    if not isinstance(damp,(float,int)) or not math.isfinite(damp) or not (.001<=damp<.8):
        raise ValueError('invalid damping; require independent fitting')
    if target not in ('marlin_input_shaper','klipper_input_shaper'):raise ValueError('only non-actuating reviewed printer drafts permitted')
    evidence={'status':'verified_sensor_fit','independent_calibration':True,'origin':p['measurement_origin'],
        'resonance_frequency_hz':peak,'damping_ratio':damp,'approved_draft_targets':[target]}
    result=draft(evidence,approved_target=target)
    result['raw_recording_sha256']=p['sha256']
    result['signed_record_verified']=True
    result['frequency_recomputed_from_raw_hz']=peak
    result['measurement_chronology_independently_witnessed']=False
    result['source_data_origin_is_attested_not_independently_proven']=True
    return result
