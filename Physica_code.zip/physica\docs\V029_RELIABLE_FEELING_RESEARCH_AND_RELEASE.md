# Physica v0.29 — Reliable Feeling, Evidence-Aware Curiosity

This release **fixes the known drone Feel Check failure** and introduces an **optional** physically grounded normal-residual calibration envelope to the shared printer, turbine and F1 inquiry system. This is an engineering improvement, **not** a guarantee of a scientific discovery, a sound machine, a Meta API result, or a hardware-safe action.

## 1. The replay bug and correct solution

The old Studio `/feel-check/api/feel?source=padre%3A0000` route assumed an existing `replay/feel/0000.json`; the distribution ZIP intentionally excludes third-party PADRE data and precomputed replay results. Thus it raised an exception and returned HTTP 422. Previously, the source selector falsely looked like a ready-to-play example.

The repaired route returns an explicit **`EVIDENCE_UNAVAILABLE`** result when the measured replay isn't bundled, including a `verdict.status=unavailable`, `no_safety_clearance=true` and instructions for reconstructing the replay from authorized data. The interface clearly labels missing files and suppresses a plot, fabricated anomaly metrics, or machine actions. When an actual correctly source-tagged replay file is present, it is returned without modification. Malformed replay paths and target requests are rejected. We did **not** fabricate drone measurements to make a test pass.

For an actual replay, obtain the PADRE data (instructions and license caveats in `DATA.md`), then use:

```powershell
python -m physica.app.build_replay
python -m physica.studio --open-browser
```

The replay builder expects raw PADRE and other inputs. It may also require the configured third-party models/data. A signed result is not a certificate of physical truth.

## 2. The research gap worth fixing

A 3-sigma difference between expected and observed sensor readings is **not** necessarily evidence of a new physical mechanism. Correlated, heteroscedastic or heavy-tailed normal machine behavior can produce high residuals. A detector calibrated on one operating condition can fail under another. This confuses three distinct questions:

1. Is the observation unusual **relative to prior normal machine experience**?
2. Are we operating within the conditions where that comparison is meaningful?
3. Does that observation support a *specific causal mechanism*?

v0.29 addresses **questions 1–2 conservatively**, leaving question 3 to the Muse+physical numerical discovery and intervention-verification pipeline. It does not claim to identify hidden physics from an abnormal residual alone.

### New method: operating-envelope-aware sensory surprise

For independent normal calibration run `i`, calculate the standardized residual

```
z_i = abs(observed_i - predicted_i) / hypot(sensor_sigma_i, prediction_sigma_i)
```

Use a **separate, held-out normal** calibration set of `n` independent runs to select the conformal rank `ceil((n+1)(1-alpha))`, at the requested false-alert fraction `alpha`. The threshold is an empirical quantile, **not a Gaussian standard deviation cutoff**. The score is a candidate anomaly when a future standardized difference exceeds the threshold.

The method **abstains** if measured speed/temperature/load context is absent or outside the explicitly supplied operating envelope, if units differ, if required calibration is missing, or if the calibration file hash matches the evaluated raw recording. No out-of-envelope result authorizes operation of a machine. For a turbine, even the absence of a detected anomaly is **never** restart clearance.

This is based on established **split conformal prediction**, not a novel mathematical guarantee. Nominal finite-sample guarantees rely on independent/exchangeable calibration and future normal examples. Time-correlated frames from a single video are **not** independent calibration runs. A bounded RPM interval does not by itself prove statistical exchangeability; matching contextual bounds only screens an obvious form of distribution shift.

### Build a normal envelope from your own sensor recordings

Prepare a CSV of **independent normal runs**, not successive samples from the same video:

```
run_id,predicted,observed,predicted_sigma,observed_sigma
normal_001,0.8,0.83,0.04,0.04
normal_002,0.8,0.79,0.04,0.04
...
```

At 10% nominal false-alert fraction, provide at least **10** independent runs; more are preferable. Provide realistic sensor/model uncertainty and record distinct source experiments. Prepare optional JSON for bounded operating context, e.g. `{"rpm":[200,800]}`. The limits must come from instrument logs and physical study design, not copied from example values.

```powershell
python -m physica.unified.uncertainty_v029 `
  --normal-runs-csv real/normal_runs.csv `
  --quantity acc --unit m/s^2 --alpha 0.1 `
  --context-bounds real/operating_limits.json `
  --out real/normal_envelope.json
```

To use the profile with the common field-data inquiry:

```powershell
python -m physica.unified.cli `
  --field-manifest --input real/trial/manifest.json `
  --normal-envelope real/normal_envelope.json `
  --operating-context real/trial/operating_context.json `
  --out real/trial/inquiry.json
```

**Critical:** The field manifest must identify independently recorded observations, calibration metadata, forecast predictions and the target system. If the operating context is outside the normal calibration region, the result is `cant_tell` and the reason is included. This method is optional; v0.28's previous comparison behavior remains available for backwards compatibility but must not be advertised as formal false-alarm calibration.

### Model-discrepancy-aware experiment design

The existing cross-domain `choose_probe` model now optionally accepts a nonnegative
`model_discrepancy_sigma` for each candidate. It ranks probes using effective
noise `hypot(sensor_sigma, model_discrepancy_sigma)` instead of trusting a
narrow sensor likelihood when the physics model has large measured residuals.

```json
{"id":"probe_A","means":[0.0,2.0],"sigma":0.1,
 "model_discrepancy_sigma":20.0,"approved":true,"cost":0.0,"risk":0.0}
```

The discrepancy value **must** come from held-out system-identification
residuals at comparable operating conditions; the planner does not invent it.
With no supplied discrepancy, behavior remains backwards-compatible, but the
estimated information gain can be overoptimistic. This change is a
straightforward robust Bayesian-design engineering measure, not new theory.

## 3. Reproducible synthetic stress test

```
python -m eval.e29_calibration_stress --trials 300 --out demo/v029_calibration_stress_SIMULATED.json
```

Simulates a heavy-tailed normal residual distribution, independent normal calibration runs, test outcomes, and an out-of-bounds operating regime. It compares a naive fixed-z rule with the new empirical envelope and tests fail-closed context checks. It is an **implementation benchmark** with a favorable known simulation, not evidence for real turbine/F1/printer generalization, discovery, improved scientific causal reasoning, or safety certification.

## 4. Deep research — best next investments

- **DiscoverPhysics (Wiemann et al., 2026, arXiv:2605.26087).** Test physically modified worlds with new hidden variables and score **explanation accuracy separately from trajectory prediction**. Physica should seek unknown-law recoveries on these worlds rather than only recovering the simulator's embedded sine function.
- **Goal-oriented optimal experimental design (Zhong et al., SIAM/ASA J. Uncertainty Quantification, 2026; DOI:10.1137/24M1649344).** Existing Physica candidates maximize mechanism information. Add a distinct evaluation of information about *the target's outcome*; test against standard information gain and random probing under equal budgets.
- **Robust experimental design under model discrepancy (Yang et al., Journal of Computational Physics, 2026; DOI:10.1016/j.jcp.2025.114469).** When all proposed models are wrong, disagreement alone can choose misleading experiments. Quantify model discrepancy and refuse poorly specified experimental options.
- **Conformal prediction under distribution shift (Correia & Louizos, NeurIPS 2025; 2026 DistMatch).** Normal residual thresholds can fail under shift. Our version abstains for detected context mismatch rather than pretending that marginal calibration transfers to every machine. Future work should investigate properly evaluated online/time-series calibration.
- **REFORMS consensus checklist (Science Advances 2024, PMC11092361).** Holdout integrity, repeated seeds, external datasets, data provenance, negative results, and proper statistical uncertainty are required for a credible scientific breakthrough claim.

## 5. What is still unverified

- Real authenticated Meta Muse or SAM calls, since local credentials and accounts are not available in this test environment.
- Real independent operating-condition calibration, live physical interventions, new physical discoveries, and cross-machine breakthrough-level advantages.
- Independent third-party timestamp authority for physical predictions.
- Full acceptance of third-party PADRE, F1, turbine, beam and printer raw datasets.

**Research target:** a Muse-proposed mechanism missing from Physica's original model library must survive physically independent, predeclared interventions on unseen machines and improve goals/forecasts over competitive no-Meta methods. No algorithm can guarantee this result a priori.
