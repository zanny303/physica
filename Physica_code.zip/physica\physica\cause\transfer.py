"""Carry an explanation, not a curve, to a different machine.

Machine A (a lab rig with a position sensor) discovers WHY its tone moves (e.g. "a rigid support is sliding along
me") and measures how wrong its physics is (a calibrated error bar). It writes that down as a signed explanation
card. Machine B is a different body (other length, other thickness, other sensor) with NO position sensor. B
measures its own dimensions, loads A's card, and from its felt tone alone says where its hidden support is, with
A's calibrated error bar scaled to its own length, and refuses where A's experience doesn't reach.

A black-box card (A's tone->position curve) is kept for comparison: it carries A's numbers, not A's understanding,
so it cannot know that B's tones mean something else.
"""
from __future__ import annotations

import numpy as np

from physica.cause import discover as D
from physica.cause.fe import Beam
from physica.cause.track import track_tone
from physica.library import sign as _sign

SCHEMA = "physica.explanation.v1"


def steady(where_mm, length_m, span: int = 3, tol_over_L: float = 0.02) -> np.ndarray:
    """Physica's own judgement of whether the hidden change is holding still: its estimate barely moves over
    +-span windows. Uses no ground truth, so it works on any machine."""
    x = np.asarray(where_mm, float) / (length_m * 1e3)
    n = len(x)
    out = np.zeros(n, bool)
    for i in range(n):
        w = x[max(0, i - span):i + span + 1]
        w = w[np.isfinite(w)]
        out[i] = len(w) >= span and (w.max() - w.min()) <= tol_over_L
    return out


def _conformal(e, q):
    e = np.sort(e[np.isfinite(e)])
    n = len(e)
    if n == 0:
        return float("nan")
    return float(e[min(int(np.ceil((n + 1) * q)) - 1, n - 1)])


def calibrate_error(est_mm, true_mm, length_m, q: float = 0.9) -> dict:
    """Split-conformal error bars from A's own ground truth, in fractions of the length (so they can travel):
    one for moments Physica judges steady, one for moments it judges moving."""
    est = np.asarray(est_mm, float)
    e = np.abs(est - np.asarray(true_mm)) / (length_m * 1e3)
    st = steady(est, length_m)
    return {"q": q, "steady_abs_err_over_L": _conformal(e[st], q), "moving_abs_err_over_L": _conformal(e[~st], q),
            "abs_err_over_L": _conformal(e, q), "n_steady": int(np.isfinite(e[st]).sum()),
            "n_moving": int(np.isfinite(e[~st]).sum()), "median_abs_err_over_L": float(np.nanmedian(e))}


def error_bar_mm(eb: dict, where_mm, length_m) -> np.ndarray:
    st = steady(where_mm, length_m)
    return np.where(st, eb["steady_abs_err_over_L"], eb["moving_abs_err_over_L"]) * length_m * 1e3


def explanation_card(beam: Beam, discovery: dict, track_cfg: dict, error_bar: dict, validation: dict,
                     source: dict) -> dict:
    v = discovery["verdict"]
    where = np.asarray(discovery["where_mm"], float) / (beam.length * 1e3)
    f1n = np.asarray(validation.get("tone_over_bare_5_95", [np.nan, np.nan]))
    payload = {
        "schema": SCHEMA, "kind": "explanation",
        "claim": f"Tone changes on this kind of body are explained by: {v['what']}",
        "cause": v["cause"], "strength": v["strength"], "strength_name": v["strength_name"],
        "ruled_out": v["ruled_out"], "explained_pct": v["explained_pct"],
        "how_to_feel": track_cfg,
        "error_bar": error_bar,
        "validity": {"x_over_L": [float(np.nanmin(where)), float(np.nanmax(where))],
                     "tone_over_bare": [float(f1n[0]), float(f1n[1])],
                     "body": "slender clamped beam; frequencies from one sensor anywhere on it"},
        "validation_on_source": validation, "source_body": beam.describe(), "provenance": source,
    }
    return {"payload": payload, "signature": _sign.sign(payload)}


def verify_card(card: dict) -> bool:
    return _sign.verify(card["payload"], card["signature"])


def apply_card(card: dict, beam: Beam, x: np.ndarray, fs: float, lag_s: float | None = 0.2) -> dict:
    """Use A's explanation on body B: where is B's hidden change, with A's error bar, and where A's experience ends."""
    if not verify_card(card):
        raise ValueError("explanation card signature does not verify; refusing to use it")
    p = card["payload"]
    cfg = p["how_to_feel"]
    bare = beam.bare(1)[0]
    band = (cfg["band_over_bare"][0] * bare, cfg["band_over_bare"][1] * bare)
    T, f1 = track_tone(x, fs, band, win=cfg["win_s"], hop=cfg["hop_s"], lag_s=lag_s)
    where = D.invert(beam, p["cause"], p["strength"], f1)
    half = error_bar_mm(p["error_bar"], where, beam.length)
    xl = where / (beam.length * 1e3)
    lo, hi = p["validity"]["x_over_L"]
    margin = 0.05
    inside = (xl >= lo - margin) & (xl <= hi + margin)
    return {"t": T, "tone_hz": f1, "where_mm": where, "lo_mm": where - half, "hi_mm": where + half,
            "inside_experience": inside, "error_bar_mm": half, "steady": steady(where, beam.length), "bare_hz": bare}


def black_box_card(f1_hz, true_mm, bins: int = 30) -> dict:
    """A tone->position curve learned from labelled moments (monotone, binned medians): what 'transfer the
    numbers' carries, and what a data-driven tracker learns from labels."""
    f, x = np.asarray(f1_hz, float), np.asarray(true_mm, float)
    ok = np.isfinite(f) & np.isfinite(x)
    f, x = f[ok], x[ok]
    edges = np.quantile(f, np.linspace(0, 1, max(min(bins, len(f) // 3), 2) + 1))
    cf, cx = [], []
    for a, b in zip(edges[:-1], edges[1:]):
        k = (f >= a) & (f <= b)
        if k.sum() >= min(3, len(f)):
            cf.append(float(np.median(f[k])))
            cx.append(float(np.median(x[k])))
    cx = list(np.maximum.accumulate(cx))
    return {"tone_hz": cf, "where_mm": cx}


def apply_black_box(bb: dict, f1_hz) -> np.ndarray:
    return np.interp(np.asarray(f1_hz, float), bb["tone_hz"], bb["where_mm"])


def envelope(card: dict) -> dict:
    """What travels between machines: the card plus the sender's public key, so the receiver can check who signed it
    and that nothing changed on the way (whether to TRUST that key is the receiver's decision)."""
    from cryptography.hazmat.primitives import serialization

    pem = _sign.load_or_create_key().public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode()
    return {"card": card, "sender_public_key_pem": pem}


def receive(env: dict) -> dict:
    """Receiver side: verify the signature with the sender's key, report whether that key is one we already trust,
    and say what the explanation lets this machine do."""
    import hashlib

    from cryptography.hazmat.primitives import serialization

    card, pem = env["card"], env["sender_public_key_pem"]
    pub = serialization.load_pem_public_key(pem.encode())
    intact = _sign.verify(card["payload"], card["signature"], pub)
    fp = hashlib.sha256(pem.encode()).hexdigest()[:16]
    trusted = any(k.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode() == pem
                  for k in _sign.trusted_keys())
    p = card["payload"]
    return {"intact": intact, "sender_key": fp, "already_trusted": trusted,
            "cause": p.get("cause"), "claim": p.get("claim"), "validity": p.get("validity"),
            "error_bar": p.get("error_bar"), "source_body": p.get("source_body", {}).get("name"),
            "verdict": ("accepted: signature intact" if intact else "REJECTED: signature does not match") +
                       ("" if trusted else " (sender's key is new to this machine: decide whether to trust it)")}
