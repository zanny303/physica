"""Muse Wonder as the agent: answers questions by running Physica's tools, citing card and evidence.

Real mode: a JSON tool loop over the chat API (works with any chat model; Wonder per SPEC).
MOCK mode: a scripted plan with the same tool calls, so the demo and tests run offline.
"""
from __future__ import annotations

import json

from physica.agents import tools as T
from physica.llm import meta_client as mc

SYSTEM = (
    "You are Physica's agent. You can call tools to observe, feel, check and translate machines. "
    "Reply ONLY with JSON: {\"tool\": name, \"args\": {...}} to call a tool, or {\"answer\": text, \"cites\": [card ids]} "
    "when done. Every answer must cite the card(s) and the evidence numbers you used. Never claim a rotor is damaged unless "
    "the verdict says it is localized; otherwise say what you can't tell and which experiment would settle it. "
    "Always end with: Advice, not a safety certification. Tools: " + ", ".join(T.TOOLS)
)


@mc.register_mock("wonder_step")
def _mock_step(messages: list[dict]) -> str:
    """Scripted plan: feel the source, recall the card, then answer from the evidence."""
    q = messages[1]["content"]
    src = q.split("[source=")[-1].split("]")[0] if "[source=" in q else "padre:0000"
    done = [m["content"] for m in messages if m["role"] == "user" and m["content"].startswith("TOOL_RESULT")]
    if not done:
        return json.dumps({"tool": "feel", "args": {"source": src}})
    res = json.loads(done[-1][len("TOOL_RESULT "):])
    v = res["verdict"]
    if v["status"] == "healthy":
        ans = (f"It feels like its healthy self: {v['felt_windows']}/{v['windows']} windows felt anything unusual "
               f"(threshold z={res['threshold_z']:.2f}, learned from a healthy flight). Safe to continue the normal "
               f"pre-flight checks.")
    else:
        ans = (f"Don't fly it yet. {v['text']} That is {v['felt_fraction']:.0%} of 5-second windows above the threshold "
               f"set on a healthy flight (z={res['threshold_z']:.2f}).")
    return json.dumps({"answer": ans + " Advice, not a safety certification.", "cites": [res["card_used"]]})


@mc.register_mock("explain")
def _mock_explain(messages: list[dict]) -> str:
    r = json.loads(messages[-1]["content"])
    v = r.get("verdict", r)
    return (f"{v.get('text', '')} Physica learned what this machine feels like when healthy, cancels what it causes "
            f"itself, and reports only what's left. {v.get('disclaimer', '')}")


def ask(question: str, source: str, max_steps: int = 6) -> dict:
    msgs = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": f"{question} [source={source}]"}]
    trace = []
    for _ in range(max_steps):
        text = mc.chat("wonder", msgs, task="wonder_step", max_tokens=600, temperature=0.2)
        try:
            step = json.loads(text[text.find("{"): text.rfind("}") + 1])
        except json.JSONDecodeError:
            msgs.append({"role": "assistant", "content": text})
            msgs.append({"role": "user", "content": "Reply with valid JSON only."})
            continue
        msgs.append({"role": "assistant", "content": json.dumps(step)})
        if "answer" in step:
            return {"answer": step["answer"], "cites": step.get("cites", []), "trace": trace}
        name, args = step.get("tool"), step.get("args", {})
        if name not in T.TOOLS:
            msgs.append({"role": "user", "content": f"Unknown tool {name}."})
            continue
        result = T.TOOLS[name](**args)
        if isinstance(result, dict):
            result.pop("feelogram_png", None)
        trace.append({"tool": name, "args": args})
        msgs.append({"role": "user", "content": "TOOL_RESULT " + T.dumps(result)})
    return {"answer": "I couldn't finish within the step limit.", "cites": [], "trace": trace}


def explain(result: dict) -> str:
    msgs = [{"role": "system", "content": "Explain this Physica result in two plain sentences for a non-expert. "
                                          "Keep every number. End with the disclaimer."},
            {"role": "user", "content": T.dumps(result)}]
    return mc.chat("wonder", msgs, task="explain", max_tokens=300, temperature=0.2)
