"""A digital twin of each string, from one film: the tone, how fast it dies away, and where it moves, all read from the pixels. Its forecast is graded on the part of the film it didn't learn from."""
from __future__ import annotations

import numpy as np
from scipy.signal import hilbert

WIDTH_HZ = 9.0


def _frames(film) -> np.ndarray:
    import cv2
    cap = cv2.VideoCapture(str(film))
    out = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        out.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY))
    cap.release()
    return np.stack(out).astype(np.float32)


def _trace(band: np.ndarray, energy: np.ndarray, count: int = 400) -> np.ndarray:
    idx = np.argsort(energy.ravel())[-count:]
    u, s, _ = np.linalg.svd(band.reshape(band.shape[0], -1)[:, idx], full_matrices=False)
    return u[:, 0] * s[0]


def _fit(y: np.ndarray, fps: float, around: float) -> dict:
    """Tone, decay and phase from a stretch of the motion, by least squares over a fine grid of tones."""
    t = np.arange(y.size) / fps
    env = np.abs(hilbert(y))
    keep = env > env.max() * .1
    decay = max(0.0, -float(np.polyfit(t[keep], np.log(env[keep]), 1)[0]))
    best = None
    for f in np.arange(around - WIDTH_HZ, around + WIDTH_HZ, .02):
        d = np.exp(-decay * t)
        A = np.c_[d * np.cos(2 * np.pi * f * t), d * np.sin(2 * np.pi * f * t)]
        c, res, *_ = np.linalg.lstsq(A, y, rcond=None)
        e = float(((A @ c - y) ** 2).sum())
        if best is None or e < best[0]:
            best = (e, f, c)
    return {"hz": float(best[1]), "decay": decay, "c": best[2]}


def read(film, fps: float, tones: dict[str, float], grid: tuple[int, int] = (108, 48)) -> dict:
    grey = _frames(film)
    T = grey.shape[0]
    spec = np.fft.rfft(grey, axis=0)
    hz = np.fft.rfftfreq(T, 1 / fps)
    out = {}
    for name, tone in tones.items():
        keep = ((hz >= tone - WIDTH_HZ) & (hz <= tone + WIDTH_HZ)).reshape(-1, 1, 1)
        band = np.fft.irfft(spec * keep, n=T, axis=0).astype(np.float32)
        energy = np.sqrt((band ** 2).mean(axis=0))
        y = _trace(band, energy)
        half = T // 2
        # Everything the forecast uses comes from the first half only. The second half is raw pixels, unfiltered.
        early = np.fft.rfft(grey[:half], axis=0)
        hz1 = np.fft.rfftfreq(half, 1 / fps)
        keep1 = ((hz1 >= tone - WIDTH_HZ) & (hz1 <= tone + WIDTH_HZ)).reshape(-1, 1, 1)
        band1 = np.fft.irfft(early * keep1, n=half, axis=0)
        idx = np.argsort(np.sqrt((band1 ** 2).mean(axis=0)).ravel())[-400:]
        u, sv, vt = np.linalg.svd(band1.reshape(half, -1)[:, idx], full_matrices=False)
        learned = _fit(u[:, 0] * sv[0], fps, tone)
        t2 = np.arange(half, T) / fps
        d = np.exp(-learned["decay"] * t2)
        A = np.c_[d * np.cos(2 * np.pi * learned["hz"] * t2), d * np.sin(2 * np.pi * learned["hz"] * t2)]
        guess = A @ learned["c"]
        real = grey[half:].reshape(T - half, -1)[:, idx]
        real = (real - real.mean(axis=0)) @ vt[0]
        real = real - np.polyval(np.polyfit(t2, real, 2), t2)
        r = float(np.corrcoef(guess, real)[0, 1])
        full = _fit(y, fps, tone)
        norm = np.clip(energy / max(float(np.percentile(energy, 99.7)), 1e-6), 0, 1)
        h, w = norm.shape
        gw, gh = grid
        cells = np.array([[norm[int(j * h / gh):max(int((j + 1) * h / gh), int(j * h / gh) + 1), int(i * w / gw):max(int((i + 1) * w / gw), int(i * w / gw) + 1)].max() for i in range(gw)] for j in range(gh)])
        out[name] = {"status": "MEASURED", "tone_hz": round(full["hz"], 2), "damping": round(full["decay"] / (2 * np.pi * full["hz"]), 5), "direction": "vertical", "fps": fps,
                     "field": {"w": gw, "h": gh, "data": [round(float(v), 3) for v in cells.ravel()]},
                     "holdout": {"learned_on_s": round(half / fps, 3), "predicted_s": round((T - half) / fps, 3), "learned_hz": round(learned["hz"], 2), "match_r": round(r, 3)}, "phase": [float(full["c"][0]), float(full["c"][1])], "decay_per_s": round(full["decay"], 3)}
    return out
