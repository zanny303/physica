"""Does SAM help? The same films read with and without its crop, scored the same way.

Calipers on a printed part settle it if the two arms differ by more than a caliper reading can resolve, because neither arm
can see them. Otherwise it falls to precision: how much the tone wanders between films of one unchanged printer, then stops felt.
SAM can lose or tie this, and if so it says so.
"""
from __future__ import annotations

import numpy as np

from physica.touch import printer_video as PV
from physica.touch import printer_watch as W

CLEAR_DIFFERENCE = 0.10    # a difference under 10% isn't called a win
CALIPER_RESOLVES = 0.04    # about 0.5 mm across a 12 mm span: calipers can't separate arms closer than this
MIN_FILMS_FOR_WANDER = 3


def read_arm(files: list[str], plan: dict) -> dict:
    rows = []
    for f in files:
        r = PV.tune(W.load(f, plan))
        rows.append({"film": f, "error": r["error"]} if "error" in r else {"film": f, "tone_hz": round(r["felt"]["freq_hz"], 3), "stops": r["felt"]["windows"], "ringing_px": round(r["felt"]["ringing_px"], 4)})
    tones = [r["tone_hz"] for r in rows if "tone_hz" in r]
    return {"films": rows, "films_read": len(tones), "stops_felt": sum(r.get("stops", 0) for r in rows),
            "tone_hz": round(float(np.median(tones)), 3) if tones else None, "tone_wander_hz": round(float(np.std(tones)), 3) if len(tones) > 1 else None}


def _better(a: float | None, b: float | None, higher: bool) -> str:
    """Which of a, b wins, if clearly."""
    if a is None or b is None:
        return "can't compare"
    if abs(a - b) <= CLEAR_DIFFERENCE * max(abs(a), abs(b), 1e-9):
        return "tie"
    return "first" if (a > b) == higher else "second"


def compare(files: list[str], crop_plan: dict, crop_name: str = "SAM crop", truth_hz: float | None = None) -> dict:
    whole = read_arm(files, W.plan_load(files[0], None))
    crop = read_arm(files, crop_plan)
    for arm in (whole, crop):
        arm["error_vs_calipers_hz"] = round(abs(arm["tone_hz"] - truth_hz), 3) if truth_hz and arm["tone_hz"] else None
    name = {"first": crop_name, "second": "whole frame", "tie": "tie", "can't compare": "can't compare"}
    scores = {"stops_felt": name[_better(crop["stops_felt"], whole["stops_felt"], True)],
              "tone_wander": name[_better(crop["tone_wander_hz"], whole["tone_wander_hz"], False)],
              "error_vs_calipers": name[_better(crop["error_vs_calipers_hz"], whole["error_vs_calipers_hz"], False)]}
    decided, by = "tie", "no clear difference"
    gap = None
    if truth_hz and whole["error_vs_calipers_hz"] is not None and crop["error_vs_calipers_hz"] is not None:
        gap = abs(whole["error_vs_calipers_hz"] - crop["error_vs_calipers_hz"])
    if gap is not None and gap > CALIPER_RESOLVES * truth_hz:
        decided, by = scores["error_vs_calipers"], "calipers"
    elif min(whole["films_read"], crop["films_read"]) >= MIN_FILMS_FOR_WANDER and scores["tone_wander"] not in ("tie", "can't compare"):
        decided, by = scores["tone_wander"], "tone wander between films"
    elif scores["stops_felt"] not in ("tie", "can't compare"):
        decided, by = scores["stops_felt"], "stops felt"
    return {"films": len(files), "crop": crop_name, "truth_hz_from_calipers": truth_hz, "whole_frame": whole, "with_crop": crop, "scores": scores,
            "decided": decided, "decided_by": by, "crop_window": crop_plan.get("roi"), "located_by": crop_plan.get("located_by") and "live SAM 3.1"}
