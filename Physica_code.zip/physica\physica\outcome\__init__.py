"""Program machines by outcome, not by instruction.

You say the outcome you want ("keep this beam away from the pump's 31 Hz,
move the support as little as possible"). Physica:

1. turns the words into a checkable spec (Muse Spark live, or the offline parser),
2. reads its sensed map of the machine (what each knob does, with error bars),
3. searches the knobs, keeping only actions whose *whole* error bar meets the spec,
4. writes the chosen action in the machine's own language (G-code, PLC
   Structured Text, a MAVLink mission, a remote-lab script),
5. checks that code with the machine's real toolchain (Klipper, the matiec
   IEC 61131-3 compiler, pymavlink / ArduPilot SITL),
6. seals a promise of what the sensors will read after the action,
7. lets reality grade the promise.
"""
from .spec import OutcomeSpec, parse_goal  # noqa: F401
from .engineer import Plan, plan  # noqa: F401
