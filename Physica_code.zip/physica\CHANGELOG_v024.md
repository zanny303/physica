# Physica v0.24: Curiosity-Driven Neural–Physics Discovery (research release)

- Added action-conditioned neural residual **ensemble** over a declared known-physics prior.
- Added broad continuous-frequency neural-to-symbolic equation discovery (no pre-entered exact sine parameters), plus independent model validation and unexplained-residual warnings.
- Added bounded neural disagreement and mechanism-directed D-optimal experiment-selection recommendations; equal-budget random/no-probe comparisons.
- Added a strict Meta output envelope and locally validated, bounded non-executable mathematical expression grammar. Real paid Muse calls require explicit authorization; no authenticated calls were made in this release.
- Added calibrated sensory fusion, physical prediction innovations and refusal when sensors conflict or virtual sensors are presented as real.
- Added a **two-step real-field interface**: SHA-256 forecast commitment on a predeclared control schedule, then separately timestamped physical outcome reveal. Prevents test data reuse, wrong units, invalid calibration structure and changed control schedules; cannot authenticate physical provenance or timestamp by itself.
- Added Studio `/curiosity` and `/api/frontier/curiosity` with a self-contained interactive display backed by real local Python simulations.
- Added strong RBF kernel ridge comparison, 36 paired simulated cases across 12 seeds, time-varying and hidden-memory negative controls, and tests.
- **No research breakthrough, real hardware validation, or Meta-on algorithmic improvement is claimed.** The full legacy test suite remains unverified; selected tests pass.
