"""Ground Meta scene context in externally measured physical feeling.

Muse/SAM can propose *which mechanism to test* and which physical component to
measure; they never supply calibrated mass, force, confidence, or sensor values.
A model's judgment becomes a candidate hypothesis, not a physical fact.
"""
from __future__ import annotations
from hashlib import sha256
import json
from pathlib import Path
from .core import fit_physical_feeling

REGISTRY=('smooth_contact_friction',)


def contextual_hypotheses(reply,*,scene_sha256,registered=REGISTRY):
    if not isinstance(reply,dict) or not isinstance(scene_sha256,str) or len(scene_sha256)!=64:
        raise ValueError('need structured Meta reply and grounded scene digest')
    if reply.get('scene_sha256')!=scene_sha256:
        return {'status':'ABSTAIN_UNGROUNDED_CONTEXT','candidates':[], 'reason':'model reply not bound to this scene'}
    proposals=reply.get('hypotheses',[])
    if not isinstance(proposals,list):raise ValueError('hypotheses must be a list')
    names=[]
    for item in proposals:
        if isinstance(item,dict):
            name=item.get('mechanism_family',item.get('name'))
            if name in registered and name not in names:names.append(name)
    if not names:
        return {'status':'UNKNOWN_MECHANISM','candidates':[],
                'reason':'proposed mechanisms lack a calibrated, executable test model'}
    return {'status':'TESTABLE_CANDIDATES_NOT_EVIDENCE','candidates':names,
            'context':str(reply.get('scene_context',''))[:500],
            'candidate_source':str(reply.get('model_id','unverified_model_response'))[:120],
            'meta_did_not_set_physical_values':True}


def evaluate_contextual_hypothesis(train,heldout,context,*,max_ratio=.8):
    """Physical evidence, not Muse prose, decides whether a hypothesis survives."""
    if context.get('status')!='TESTABLE_CANDIDATES_NOT_EVIDENCE':
        return {'status':'ABSTAIN_CONTEXT_NOT_TESTABLE'}
    best=None
    for family in context['candidates']:
        result=fit_physical_feeling(train,heldout,candidate_mechanism=family,max_ratio=max_ratio)
        if result.get('status')=='SUPPORTED_HELDOUT' and (best is None or
            result['heldout_sensor_error_normalized']<best['heldout_sensor_error_normalized']):
            best=result
    return best or {'status':'UNKNOWN_OR_UNSUPPORTED',
                    'reason':'independent interventions do not support model hypothesis'}


def live_muse_feeling_context(video_path,*,allow_billed_meta=False):
    """Billable real Muse call, explicitly opt-in. Uses existing Meta SDK adapter.

    The response must be converted into the constrained hypothesis registry,
    checked against a *distinct* source video hash and heldout physical actions.
    API model output alone is never signed as a measured physical experience.
    """
    if not allow_billed_meta:raise PermissionError('live Muse requires explicit billing opt-in')
    from physica.experience.meta_live import muse_scientist
    data=Path(video_path).read_bytes();digest=sha256(data).hexdigest()
    facts={'scene_sha256':digest,'request':'propose physically testable context and mechanisms',
           'approved_hypotheses':list(REGISTRY),
           'do_not_estimate_forces_from_video_without_calibration':True,
           'do_not_access_heldout_physical_measurements':True}
    out=muse_scientist(facts,[],role='spark',video_path=str(video_path))
    # Meta response schemas vary. Do not fabricate missing JSON fields.
    reply=out.get('reply',{})
    if not isinstance(reply,dict):
        return {'status':'ABSTAIN_MODEL_RETURNED_NONSTRUCTURED_REPLY', 'model_output':out}
    if 'scene_sha256' not in reply:
        # Ground the response only if the call was made on this exact video.
        reply={**reply,'scene_sha256':digest}
    return {'context':contextual_hypotheses(reply,scene_sha256=digest),
            'authenticated_model_response':out,
            'independent_sensor_verification_required':True}
