"""Turn experiment results into signed SKILL cards: a procedure (not numbers) plus its record on every machine.

A skill card says how to feel, in the machine's own coordinates, and where that has worked or failed. Numbers are
relearned on each new machine from healthy data; the arrival check decides whether a card's numbers can be reused.
Re-running replaces earlier skill cards. Run after e9_skill_transfer.py (and e10_robot_touch.py if you have it).
"""
from __future__ import annotations

import json
import shutil

import common  # noqa: F401  (puts the repo on the import path, like the other eval scripts)

from physica import config
from physica.feel.order_feel import OrderFeel
from physica.library import cards


def r(name):
    p = config.RESULTS_DIR / f"{name}.json"
    return json.loads(p.read_text()) if p.exists() else None


def main():
    for c in cards.all_cards():
        if "skill" in c.get("tags", []):
            shutil.rmtree(config.CARDS_DIR / c["id"], ignore_errors=True)
    e9 = r("E9_skill_transfer")
    if not e9:
        raise SystemExit("Run eval/e9_skill_transfer.py first")
    desc = {
        "order_broad": ("Order Feel: feel damage in orders of the machine's own main vibration line (0.25-1.25x)",
                        OrderFeel(orders=(0.25, 1.25)).procedure()),
        "hz_band": ("Hz-band self-model: feel damage as extra power at the rotor peak, 95-200 Hz", {"band_hz": [95, 200]}),
        "order_narrow": ("Narrow Order Feel: only 0.85-1.15x, where damage showed on the Bebop (over-fits its source)",
                         OrderFeel(orders=(0.85, 1.15)).procedure()),
    }
    made = []
    for key, (claim, proc) in desc.items():
        rows = e9["skills"][key]
        record = [{"machine": m, "detect": round(v["detect"], 3), "false_alarms": v["false_alarms"],
                   "flights_caught": v["flights_caught_majority"]} for m, v in rows.items()]
        works_everywhere = all(float(v["false_alarms"].split("/")[0]) == 0 and v["detect"] >= 0.5 for v in rows.values())
        c = cards.new_card("skill", claim, {"type": "quadcopter", "id": "any rotor-driven machine"},
                           units="z vs this machine's own healthy", context={"procedure": proc, "source": "E9"},
                           metrics={"per_machine": record, "transfer_verdict": "kept" if works_everywhere else
                                    "kept with limits" if key != "order_narrow" else "retired: over-fits its source"},
                           changed=["learned on Parrot Bebop 2", "carried to 3DR Solo"], tags=["skill"])
        cards.save(c, evidence={"E9.json": config.RESULTS_DIR / "E9_skill_transfer.json"})
        made.append((key, c["metrics"]["transfer_verdict"]))
    e10 = r("E10_robot_touch")
    if e10:
        c = cards.new_card("skill", "Torque Feel: a robot arm feels touch, load and wear by cancelling its own "
                           "predicted torque, in task-phase coordinates", {"type": "robot arm", "id": "voraus-AD cobot"},
                           units="z vs normal cycles", metrics={"auroc": e10["auroc"], "false_alarms": e10["false_alarms"]},
                           tags=["skill"])
        cards.save(c, evidence={"E10.json": config.RESULTS_DIR / "E10_robot_touch.json"})
        made.append(("torque_feel", "robot"))
    print(made)


if __name__ == "__main__":
    main()
