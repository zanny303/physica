"""Build the signed knowledge library from the evaluation results (run after E1, E4, E7, E8).

Creates: a 'healthy self-model' sense card for the Bebop 2 (what it should feel), one per-arm unit card,
a fault card (what prop damage feels like), a negative-knowledge card (localisation is NOT proven from
passive flight data), and adds the arrival-check track record from E7.
"""
from __future__ import annotations

import json
import shutil

import numpy as np

from common import CFG, healthy_split, padre_features
from physica import config
from physica.feel.selfmodel import OperatingPointSelfModel
from physica.library import arrival, cards

MACHINE = {"type": "quadcopter", "model": "Parrot Bebop 2", "id": "padre-bebop2"}
SENSORS = ["arm A/B/C/D accelerometers, 500 Hz (PADRE)"]


def load(name):
    return json.loads((config.RESULTS_DIR / f"{name}.json").read_text())


def main(fresh: bool = True):
    if fresh and config.CARDS_DIR.exists():
        shutil.rmtree(config.CARDS_DIR)
    split = healthy_split()
    h = padre_features("0000")
    cal = np.array(split["calib"])
    sm = OperatingPointSelfModel(unit_names=list("ABCD")).fit(h["op"][cal], h["lvl"][cal])
    sm.calibrate_threshold(h["op"][cal], h["lvl"][cal], CFG.q, CFG.margin)
    hw = arrival.conformal_halfwidth(sm.z(h["op"][cal], h["lvl"][cal]), 0.9)
    e1, e7, e8, e4 = load("E1_feel_without_damage"), load("E7_arrival_check"), load("E8_localization_limit"), load("E4_compounding")
    phys = e1["methods"]["physica_selfmodel_no_damage_data"]

    c = cards.new_card(
        "sense", "Healthy self-model: the vibration a healthy Bebop 2 arm should feel at each rotor speed peak "
                 "(what it causes itself). Anything above it is felt.",
        MACHINE, units="log10 power, z vs healthy", sensors=SENSORS,
        context={"data": "PADRE healthy flight 0000, calibration half", "window_s": CFG.win_s, "band_hz": CFG.band},
        proven_range={"rotor_peak_hz": [float(h["op"][cal].min()), float(h["op"][cal].max())]},
        metrics={"heldout_false_alarm": phys["false_alarm_rate_heldout_healthy"],
                 "heldout_false_alarm_ci95": phys["false_alarm_ci95_exact"],
                 "damage_detect_rotors_BCD": phys["detect_rate_BCD"],
                 "damage_detect_ci95": phys["detect_ci95_cluster_by_flight"],
                 "threshold_z": sm.threshold, "conformal_halfwidth_z": hw, "source": "eval/results/E1_feel_without_damage.json"},
        tags=["healthy self-model", "fleet card", "bebop2", "feel transform"])
    from physica.data import padre
    from physica.feel.feel_transform import FeelTransform
    rec = padre.load("0000")
    ft = FeelTransform(list("ABCD")).fit(rec.acc, padre.FS, window_idx=cal)
    model = {**sm.to_dict(), "touch_base": ft.touch_base}
    healthy = cards.save(c, model=model,
                         evidence={"E1.json": config.RESULTS_DIR / "E1_feel_without_damage.json"})
    hid = c["id"]
    for k, v in e7["matrix"].items():
        a, b = k.split("->")
        if a == b:
            cards.add_track_record(hid, f"arrival check arm {a}", v["verdict"] == "fits", {"coverage": v["coverage"]})

    for i, arm in enumerate("ABCD"):
        u = OperatingPointSelfModel(unit_names=[arm])
        u.coef, u.sigma, u.threshold = sm.coef[i:i + 1], sm.sigma[i:i + 1], sm.threshold
        u.x_center, u.x_scale = sm.x_center, sm.x_scale
        uc = cards.new_card("sense", f"Unit card, arm {arm}: healthy self-model of this arm only (reusable as a starting guess)",
                            {**MACHINE, "unit": arm}, units="log10 power", sensors=SENSORS, parent=hid,
                            changed=["split from fleet card"], metrics={"sigma": float(sm.sigma[i])},
                            tags=["unit card", "bebop2"])
        cards.save(uc, model=u.to_dict())

    fc = cards.new_card(
        "fault", "A damaged propeller is felt as vibration near the rotor's rotation peak (95-200 Hz) above what the "
                 "healthy self-model predicts, strongest on the damaged arm in most chipped-prop cases.",
        MACHINE, units="z vs healthy", sensors=SENSORS, parent=hid, changed=["fault signature from damage flights"],
        metrics={"detect_rotors_BCD": phys["detect_rate_BCD"], "per_file": phys["per_file"]},
        tags=["prop damage", "fault", "bebop2"])
    cards.save(fc, evidence={"E1.json": config.RESULTS_DIR / "E1_feel_without_damage.json"})

    nc = cards.new_card(
        "negative", "NOT PROVEN: naming WHICH rotor is damaged from passive flight vibration. The strongest-shaking arm "
                    f"was the damaged rotor in {e8['localization_accuracy_on_felt_windows']:.0%} of felt windows (chance 25%).",
        MACHINE, units="accuracy", sensors=SENSORS, parent=hid, changed=["localisation test failed"],
        metrics={"accuracy": e8["localization_accuracy_on_felt_windows"], "ci95": e8["localization_ci95_exact"],
                 "n": e8["n_felt_windows"], "why": e8["why"], "experiment_needed": e8["experiment_requested"]},
        tags=["localisation", "negative knowledge", "bebop2"])
    cards.save(nc, evidence={"E8.json": config.RESULTS_DIR / "E8_localization_limit.json"})

    xc = cards.new_card(
        "experiment", "Compounding record: starting from relatives' knowledge, a new arm's self-model stayed under 5% false "
                      "alarms after " + ", ".join(f"{t}: {v['library']['seconds_to_5pct_false_alarm']} s (vs "
                                                  f"{v['cold']['seconds_to_5pct_false_alarm']} s from scratch)"
                                                  for t, v in e4["targets"].items()),
        MACHINE, units="seconds of healthy flight", sensors=SENSORS, parent=hid, changed=["leave-one-arm-out test"],
        metrics={t: {k: v[k]["seconds_to_5pct_false_alarm"] for k in v} for t, v in e4["targets"].items()},
        tags=["compounding", "bebop2"])
    cards.save(xc, evidence={"E4.json": config.RESULTS_DIR / "E4_compounding.json"})
    print(json.dumps(cards.library_counts(), indent=1))


if __name__ == "__main__":
    main()
