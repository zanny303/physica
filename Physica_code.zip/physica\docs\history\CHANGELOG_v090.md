# Physica v0.9.0 research candidate — completed software changes

**Development status:** candidate methods, simulation-verified. NOT a demonstrated new law, first-of-its-kind algorithm, real physical feeling, or authenticated Meta success.

1. `physica/research_v09/transfer.py`: machine-population hierarchical physical prior, explicit parameter variability, target probe gate, no prior contamination on gross mismatch, and prospective forecasting from initial state and planned actions. The combination uses **established empirical Bayes and system identification**. It is a candidate for cross-sensor experiment-efficient use, not claimed new math.
2. `active_probe.py` and `probe_benchmark.py`: precommitted, budget-matched, target-directed Bayesian A-optimal intervention selection; candidate ranking cannot inspect results. Sensor observation provenance remains outside the synthetic model.
3. `latent_experience/guarded.py`: chronological validation selects latent representation prediction or conventional ARX; retains whichever actually predicts better, rather than advertising the learned model unconditionally.
4. `research_v09/benchmark.py` and `run.py`: multi-seed simulation with distinct source/target body groups and 3 scenarios: source-like, shifted model parameter, and omitted mechanism. Reports both prospective future sensory trajectories and conditional acceleration. Source experiments are counted separately.
5. `research_v09/experience.py`: reproducible A-sound/contact to B-camera/inertial **simulated** workflow with different calibrated observation maps and separate SHA-256 forecast commitment versus outcome reveal. A local SHA is integrity only, not independent chronology proof.
6. `research_v09/meta_bridge.py`: optional billable Muse Spark/Wonder Responses API with strict structured nomination schema and candidate allowlist. Default is offline dry run. No hardware commands from model outputs; requires private `MODEL_API_KEY` and explicit `--allow-billed-meta`. Authenticated execution NOT tested here.
7. Physica Studio adds offline research, Meta contract, and cross-sensor experience tasks; no automated actuation and no billable requests launched from Studio.
8. New regression tests and explicit negative results.

## Essential exclusions

- Did NOT download/train on Paderborn or any other independent physical dataset.
- Did NOT test Moody physical experiments or collect calibrated sensor signals.
- Did NOT execute billable Muse, SAM, or V-JEPA model inference.
- Did NOT demonstrate arbitrary missing-mechanism invention, five real senses, or a model beating state-of-the-art across physically different real systems.
- Repeated successful simulator trials are not independent physical replications.

## Key research hypothesis

Target-directed experimental selection plus selectively reused causal source priors might reduce target experiments needed for cross-sensor physical response prediction while withholding incompatible transfers. Establish novelty only after comparing to hierarchical system ID, Bayesian optimal design, latent dynamics, SINDy, and cross-embodiment baselines on real held-out bodies and tasks.
