from physica.outcome.cli import main

main()
