"""Create a standalone, offline v0.8.1 synthetic evidence viewer; no internet/CDN."""
from pathlib import Path
import json
import html


def main(folder):
    root=Path(folder)
    seal=json.loads((root/'04_SEALED_BEFORE_OUTCOME.json').read_text())
    measured=json.loads((root/'05_outcome_generated_after_seal_SIMULATED.json').read_text())
    receipt=json.loads((root/'06_signed_reveal_receipt.json').read_text())
    summary=json.loads((root/'07_result_and_fair_baselines.json').read_text())
    bench=json.loads((root/'benchmark_24_synthetic.json').read_text())
    payload=json.dumps({'seal':seal['payload'],'data':measured['observed_by_sensor'],'receipt':receipt,
                        'summary':summary,'bench':bench},separators=(',',':')).replace('</','<\\/')
    doc='''<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Physica v0.8.1 — Predictive Feeling Lab (SIMULATION)</title>
<style>body{font-family:system-ui,-apple-system,sans-serif;background:#0d1525;color:#eaf3ff;max-width:1100px;margin:0 auto;padding:28px 18px;line-height:1.5}h1{font-size:clamp(25px,5vw,43px);margin:0}h2{font-size:22px;margin-top:22px}.lead{color:#a7bbd5}.tag{font-size:12px;letter-spacing:.10em;background:#243145;border:1px solid #687894;color:#d4e4f5;border-radius:20px;padding:6px 10px;display:inline-block;margin-bottom:15px}section{border:1px solid #31425a;background:#162338;border-radius:16px;padding:20px;margin:18px 0}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}.metric{border:1px solid #3b506a;border-radius:12px;background:#1d2d43;padding:14px}.number{font-size:27px;font-weight:700}.hint{color:#a9c0db;font-size:13px}svg{max-width:100%;display:block;border-radius:10px;background:#102033}strong{color:#f6fdff}.good{color:#66e7c2}.warn{color:#ffd38e}button{background:#274263;color:white;border:1px solid #7998b7;border-radius:8px;padding:9px 12px;margin-right:6px;cursor:pointer}button:focus{outline:2px solid white}code{font-family:ui-monospace,monospace;overflow-wrap:anywhere}.legend{display:flex;flex-wrap:wrap;gap:14px;font-size:13px;color:#bad2ed}.dot{display:inline-block;width:13px;height:3px;vertical-align:middle;margin-right:5px}</style>
</head><body><span class="tag">OFFLINE SIMULATION ONLY · NO LIVE META · NO REAL HARDWARE</span><h1>PHYSICA <span style="color:#7ccafa">v0.8.1</span></h1>
<p class="lead">Predict a physical sensation before revealing the generated measurement. The signed forecast now uses the verified <strong>source + target-probe</strong> estimate, and its adaptation decision is locked inside the commitment.</p>
<div class="cards"><div class="metric"><div class="hint">Signed response RMSE vs generated truth</div><div class="number" id="run-error"></div></div>
<div class="metric"><div class="hint">24-target average · signed hierarchical</div><div class="number" id="avg-error"></div></div>
<div class="metric"><div class="hint">24-target average · target only</div><div class="number" id="local-error"></div></div>
<div class="metric"><div class="hint">Signed adaptation</div><div style="font-weight:bold" id="adapt"></div></div></div>
<section><h2>Sealed forecast → generated measurement</h2><div class="legend"><span><i class="dot" style="background:#52dcc1"></i>Signed predicted camera movement</span><span><i class="dot" style="background:#ffbd6f"></i>Generated outcome</span></div>
<svg id="chart" viewBox="0 0 980 350" role="img" aria-label="Camera displacement forecast and subsequent simulated measurement"></svg><p class="hint">This is a simulated response in camera millimeters; the small measurement noise is intentionally retained. Generated truth was not an input to the forecast function.</p></section>
<section><h2>Verify the evidence</h2><div>Forecast SHA-256: <code id="hash"></code></div><div>Reveal receipt: <code id="receipt"></code></div>
<p class="hint">Source lesson, raw low-force probe, forecast, measurement and receipt are separately saved in this example directory. The CLI can cryptographically verify the receipt using the raw observation. <strong>Local signatures do not prove real experiment chronology or truth.</strong></p></section>
<section><h2>What this proves—and doesn't</h2><p class="good">✓ The actual signed future predictor uses the same hierarchical posterior tested in the benchmark, rather than the weaker source-only estimate.</p><p class="good">✓ A target-probe disagreement triggers a local-only fallback or refusal, depending on available verified evidence.</p>
<p class="warn">! The parameter bands are model-sensitivity diagnostics, not empirically calibrated confidence intervals. The simulator assumes a known mechanism family and independently supplied target parameters.</p><p class="warn">! This demonstration has zero authenticated Muse/SAM calls and zero real hardware experiments. A future independent witness is needed for real chronological evidence.</p></section>
<script>const D=__DATA__;const X=D.seal.times_s, P=D.seal.predicted_sensor_values.camera, Y=D.data.camera;
const fmt=x=>x.toFixed(4)+' mm';document.getElementById('run-error').textContent=fmt(D.summary.signed_forecast_rmse_mm_vs_noiseless_truth);
document.getElementById('avg-error').textContent=fmt(D.bench.mean_camera_rmse_mm.actual_signed_posterior_on_accepted_only);
document.getElementById('local-error').textContent=fmt(D.bench.mean_camera_rmse_mm.local_friction_equal_probe);
document.getElementById('adapt').textContent=D.summary.sealed_adaptation;document.getElementById('hash').textContent=D.summary.forecast_hash;
document.getElementById('receipt').textContent=D.summary.receipt_hash;
const svg=document.getElementById('chart'), W=980,H=350,pad=45;
const min=Math.min(...Y,...P), max=Math.max(...Y,...P),rng=(max-min)||1;
const pt=(a,i)=>[pad+(W-2*pad)*i/(a.length-1),H-pad-(H-2*pad)*(a[i]-min)/rng];
const NS='http://www.w3.org/2000/svg';function el(tag,att){const e=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(att))e.setAttribute(k,v);svg.appendChild(e)}
for(let j=0;j<5;j++){let y=pad+(H-2*pad)*j/4;el('line',{x1:pad,y1:y,x2:W-pad,y2:y,stroke:'#3a506b','stroke-dasharray':'4 5'});let lab=document.createElementNS(NS,'text');lab.setAttribute('x','3');lab.setAttribute('y',y+4);lab.setAttribute('fill','#b5c8e0');lab.setAttribute('font-size','12');lab.textContent=(max-rng*j/4).toFixed(2);svg.appendChild(lab)}
for(const [a,color] of [[P,'#52dcc1'],[Y,'#ffbd6f']])el('polyline',{points:a.map((v,i)=>pt(a,i).join(',')).join(' '),fill:'none',stroke:color,'stroke-width':'2.5','stroke-linejoin':'round'});
</script></body></html>'''
    (root/'experience_lab.html').write_text(doc.replace('__DATA__',payload),encoding='utf-8')
    print(root/'experience_lab.html')


if __name__=='__main__':
    import sys
    main(sys.argv[1] if len(sys.argv)>1 else 'examples/v081_prospective_simulated')
