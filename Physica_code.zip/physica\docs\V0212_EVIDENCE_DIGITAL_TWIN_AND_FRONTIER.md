# Physica v0.21.2 — Evidence-Linked Digital Twin & Unknown-Physics Investigation

## What changed

This release extends v0.21's bounded, prospective unknown-physics engine with a **video/data → evidence-linked diagram → conditional simulation → missing-measurement request** workflow. It retains the previous Observatory and Physica modules.

### One-minute demonstration

1. Launch Studio, then select **Digital Twin** from the top of the main page, or visit `http://127.0.0.1:8765/twin`.
2. Click **Load synthetic demo**. Check that it is clearly marked `SYNTHETIC_GENERATED_INSIDE_PHYSICA`. Inspect its *measured* 1D trace, and compare the learned second-order surrogate to a constant-acceleration baseline on later recorded samples.
3. Click **Restraint weakens** and **Add damping**. The canvas changes *hypothesized parameters* and plots a **conditional, simulation-only** outcome. It does **not** predict actual breakage or verified repair.
4. Drag the diagram body. This manipulates its **visual representation only**, not the evidence or hardware; the sliders are the numerical interventions.
5. Upload `examples/twin_v0212/mechanical_oscillator_SIMULATED.csv` or `examples/twin_v0212/moving_block_SIMULATED.mp4`. The video example is a generated moving marker with a stationary background, NOT real physical evidence. For it, select ROI `0.27,0.35,0.46,0.36` (the block); without a validated length calibration it stays in **pixel units**.
6. Upload an unknown file, a single frequency, or a video with inadequate tracking. See the **ABSTAIN / OBSERVATION_ONLY** response. Request calibrated position + a synchronous approved action + a separate check experiment before making a causal claim.
7. Open **Discovery Observatory** and run the separate, fully frozen A→B→C research scenario. *It is still a simulated benchmark.*

### Files the Twin accepts

| Input | What it truly supplies | What is NOT established |
|---|---|---|
| CSV `t_s,displacement_m` (`command` optional) | Position time series; conditional dynamics if identifiable | Directly measured spring constant, mass, safety limit, true cause |
| CSV `t_s,position_px` | Relative pixel motion unless verified pixels/metre supplied | Metres, force, hidden components |
| Steady MP4/MOV/etc | Region-tracked relative optical motion, background drift diagnostic, fps from container or user override | 3D CAD, object identities, rigid-body depth, forces |
| `samples:[{t_s,displacement_m}]` JSON | Claimed calibrated motion samples; preserves claim source | Independent attestation of calibration or sensor origin |
| Official parsed Meta SAM 3.1 tracks (via guarded CLI below) | Target and stationary-reference pixel tracks; a calibrated *operator-verified* displacement signal | Object masses, strength, break threshold, true cause |

The numerical engine fits `x'' = -(k/m)x -(c/m)x' + g u + b` to training samples **only when** data are sufficient and a held-out later segment beats the constant-acceleration baseline. The stiffness/mass and damping/mass ratios are model parameters, NOT independently established stiffness or damping. For a real causal mechanism, add controlled interventions and disjoint episodes; later time points of one recording are not enough.

## Actual local commands (Windows Terminal / PowerShell)

```powershell
cd C:\Users\budhw\Downloads\physicanew\physica
$env:PYTHONUTF8 = "1"
..\.venv\Scripts\python.exe -m pip install -e ".[dev,video]"
..\.venv\Scripts\python.exe -m physica.studio --open-browser
```

Direct CLI, zero API cost:

```powershell
..\.venv\Scripts\python.exe -m physica.twin.cli --synthetic-demo --out demo\twin_example.json
..\.venv\Scripts\python.exe -m physica.twin.cli examples\twin_v0212\mechanical_oscillator_SIMULATED.csv --out demo\twin_csv.json
..\.venv\Scripts\python.exe -m physica.twin.cli examples\twin_v0212\moving_block_SIMULATED.mp4 --roi 0.27,0.35,0.46,0.36 --out demo\twin_video.json
```

### Real Meta SAM 3.1 object tracking, explicitly optional and billed

The existing official parser in `physica.grammar.meta_sam_official` is used (not regex). Two independent SAM concept prompts provide the **moving object** and an independently verified **stationary reference**. If there are multiple similarly supported objects, the adapter refuses to merge them; select a more specific object or use a box/point prompt workflow. The video must be MP4/MOV, and the guard accepts 10–900 frames. An **upper-bound reservation** is made before both calls through the shared Meta spending ledger; the amount is conservative and not equal to provider billing. It records a hashed input and an API-call receipt; the model key stays local.

```powershell
..\.venv\Scripts\python.exe -m pip install -e ".[dev,video,meta]"
$env:MOCK="0"
$env:MODEL_API_KEY="<your private key, entered locally>"
$env:PHYSICA_BUDGET_USD="5"
..\.venv\Scripts\python.exe -m physica.twin.cli "YOUR_CLIP.mp4" --sam-target "moving pendulum" --sam-reference "fixed reference marker" --fps 120 --pixels-per-metre 800 --calibration-verified --reference-stationary-verified --allow-billed-meta --out demo\sam_twin.json
```

**Do not supply fake calibration or stationarity confirmations.** API access, live model efficacy, the camera calibration and stationary-reference claim were not verified in the offline release tests. This route sends the clip to Meta, unlike the browser's local optical flow.

### Optional Muse mechanism annotation

Set `MOCK=0` and `MODEL_API_KEY` in the Studio Terminal. On the Twin page, check the billing acknowledgment and click **Ask Muse to annotate the twin**. Muse Spark receives only the **measured summary and model limits**, not the original video. It returns at most three alternative candidate explanations and what to measure next; output must pass a strict schema. All proposals are labelled `MUSE_SUGGESTIONS_NOT_VERIFIED`. The same shared spending-ledger reservation mechanism applies. There is no claim here of Meta-on outperforming Meta-off.

## Connection to scientific discovery / transfer

`physica.mace.causal_fork_v021` adds the missing *discriminating experiment and target stage* absent from the earlier standalone v0.21 Observatory. It searches expanded bounded periodic terms on Machine A without supplying the simulator's actual law, chooses candidate interventions before generating held-out observations, freezes the **complete** prediction payload in `02_FULL_FROZEN_FORECAST_BEFORE_REVEAL.json` with SHA-256 integrity, and compares machines B and C with an equally capable target-only mechanism search using identical local samples. Camera and acoustic sensor packages differ across simulated bodies. The algorithm may seek additional pilot data or refuse source transfer.

The reproduced 8-seed benchmark finds:

- 8 seeded source problems investigated; mean source camera error falls from **0.06776 m** (older baseline) to **0.00423 m** (expanded search).
- 16 target machine cases; mean selected error **0.004325**, tied with equally capable target-only learning.
- Target-only wins / transferred wins: no demonstrated improvement; **source transfer accepted in 0/16 cases** under the conservative gate.
- No authenticated Meta calls and **zero** real physical experiments in this benchmark.

This is stronger *integration and research discipline*, not a proven cross-machine transfer breakthrough. The frozen digest is a tamper detection hash **if a separate earlier copy survives**, not independently witnessed time attestation. For actual transferable physics, test source and target data collected on independent real machines.

## Next frontier beyond this release

- **Scene graphs from multiple cameras / depth and independently measured geometry**. A single monocular clip cannot recover hidden mechanical constraints or a metric 3D model without priors and calibration.
- **Uncertainty-aware hybrid digital twin** with neural residual plus symbolic mechanism; calibration against separate real interventions and in-distribution detector.
- **Active fault localization** with intervention design: competing mechanisms must predict different outcomes for a safe test; if they don't, abstain.
- **Transferable outcome-conditioned physical skills**, measured on independent machines. Compare against classical system identification, sparse identification, hierarchical Bayes and local-only active design under equal experimental budgets.
- **External lab / calibrated physical A→B evidence** and a measured Meta-on/Meta-off ablation. These are scientific experiments not obtainable by code alone.
- **Safety-critical actions** must stay under certified external interlocks, manual authorization and engineering approval. Studio and Twin do not actuate motors, drones, turbines, printers or household fans.

## Current Meta documentation

- SAM 3.1 overview: https://dev.meta.ai/docs/sam/overview
- SAM 3.1 segmentation and tracking prompt protocol: https://dev.meta.ai/docs/sam/segmenting
- Model API media segmentation: https://dev.meta.ai/docs/media-segmentation

**Status:** completed local prototype, with offline tests and deterministic synthetic examples. Not 3D CAD reconstruction, an autonomously discovered physical law, an observed break event, a native Meta glasses client, or a validated real-world predictive digital twin.
