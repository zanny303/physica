"""External measured-signal adapter (no third-party datasets bundled).

MAT files vary by source and version. Inspect available numeric paths first;
import only a selected field with documented units, sample rate and license.
Do not derive actual fault labels from filenames without supplied metadata.
"""
from __future__ import annotations
import numpy as np
from scipy.io import loadmat
from pathlib import Path
import json
from .evidence import evidence_manifest

def numeric_arrays(mat_path):
    try: data=loadmat(str(mat_path),squeeze_me=True,struct_as_record=False)
    except NotImplementedError as exc:raise ValueError('MATLAB v7.3/HDF5: convert with an authorized HDF5 reader') from exc
    result={}
    def recurse(node,path,depth=0):
        if depth>9:return
        if isinstance(node,np.ndarray):
            if node.dtype.kind in 'fiub' and node.size>=8 and np.all(np.isfinite(node)):
                result[path]=np.asarray(node).shape
            elif node.dtype.kind=='O' and node.size<=300:
                for i,x in enumerate(node.ravel()):recurse(x,f'{path}[{i}]',depth+1)
        elif hasattr(node,'_fieldnames'):
            for field in node._fieldnames:recurse(getattr(node,field),f'{path}.{field}' if path else field,depth+1)
    for k,v in data.items():
        if not k.startswith('__'):recurse(v,k)
    return result

def selected_trace(mat_path,field,*,sample_rate_hz,unit,source_metadata=None):
    fields=numeric_arrays(mat_path)
    if field not in fields:raise ValueError('field not found: inspect numeric paths first')
    if not isinstance(sample_rate_hz,(int,float)) or not np.isfinite(sample_rate_hz) or sample_rate_hz<=0:
        raise ValueError('verified positive sample rate required')
    # Reach exact field without evaluating arbitrary code.
    import re
    data=loadmat(str(mat_path),squeeze_me=True,struct_as_record=False)
    parts=re.findall(r'[^.\[\]]+|\[\d+\]',field)
    arr=data[parts[0]]
    for p in parts[1:]:arr=arr[int(p[1:-1])] if p.startswith('[') else getattr(arr,p)
    arr=np.asarray(arr,dtype=float).reshape(-1)
    ev=evidence_manifest(mat_path,origin='external_recording',modality='recorded_numeric_signal',
           dataset=(source_metadata or {}).get('dataset','external_mat'),units=unit,
           license_note=(source_metadata or {}).get('license_note'))
    return {'evidence':ev,'field':field,'sample_rate_hz':float(sample_rate_hz),'unit':unit,
            'n_samples':int(len(arr)),'rms':float(np.sqrt(np.mean(arr**2))),
            'signal_not_verified_causal':True,
            'requires_heldout_machine_split':True}
