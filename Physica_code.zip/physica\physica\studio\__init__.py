"""Single localhost cockpit for existing Physica research services and demos."""
