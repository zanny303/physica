"""Dimensionless causal experience transport between known second-order bodies.

Physical token: tau=f1*t and q = measured displacement * stiffness / step force.
For matched boundary/action/modal families, a receiver with its OWN force,
stiffness and frequency can rescale: t_B=tau/f_B, x_B=q*F_B/k_B.

This is an *assumption-driven, auditable* representation, not a model that
can map arbitrary robots or infer unmeasured stiffness. No extrapolation,
unknown calibration, unsafe actions, or silent unit conversion allowed.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
from math import isfinite, sqrt
import numpy as np


@dataclass(frozen=True)
class BodyCalibration:
    machine_id: str
    boundary_class: str
    action_class: str
    fundamental_hz: float
    stiffness_n_per_m: float
    applied_step_force_n: float
    mode_ratios: tuple[float,...]
    damping_ratios: tuple[float,...]
    calibration_id: str
    verified_sensor: bool

    def __post_init__(self):
        if not all((self.machine_id, self.boundary_class, self.action_class, self.calibration_id)):
            raise ValueError("all identification/calibration labels required")
        if not self.verified_sensor: raise ValueError("calibrated sensor required")
        vals=(self.fundamental_hz,self.stiffness_n_per_m,self.applied_step_force_n)
        if any(not isfinite(x) or x<=0 for x in vals):
            raise ValueError("positive finite frequency, stiffness and step force required")
        if not self.mode_ratios or len(self.mode_ratios)!=len(self.damping_ratios):
            raise ValueError("nonempty equal-size mode/damping vectors required")
        if any(not isfinite(x) or x<=0 for x in self.mode_ratios):
            raise ValueError("positive finite mode ratios required")
        if abs(self.mode_ratios[0]-1)>1e-5:
            raise ValueError("first mode ratio must be 1")
        if any(not isfinite(z) or z<0 or z>=1 for z in self.damping_ratios):
            raise ValueError("valid damping 0 <= zeta < 1 required")


def _vector(time, response):
    t=np.asarray(time,dtype=float); y=np.asarray(response,dtype=float)
    if t.ndim!=1 or y.ndim!=1 or len(t)!=len(y) or len(t)<3:
        raise ValueError("need equal-size time and displacement vectors (>=3)")
    if not np.all(np.isfinite(t)) or not np.all(np.isfinite(y)) or t[0]<0:
        raise ValueError("finite, nonnegative time required")
    if not np.all(np.diff(t)>0):
        raise ValueError("time must be strictly increasing")
    return t,y


def compatibility(a: BodyCalibration, b: BodyCalibration, *, max_ratio_error=.10,
                  max_damping_error=.025) -> dict:
    reasons=[]
    if a.boundary_class!=b.boundary_class: reasons.append("boundary_mismatch")
    if a.action_class!=b.action_class: reasons.append("action_family_mismatch")
    if len(a.mode_ratios)!=len(b.mode_ratios): reasons.append("mode_count_mismatch")
    else:
        err=float(np.sqrt(np.mean(np.log(np.asarray(a.mode_ratios)/b.mode_ratios)**2)))
        if err>max_ratio_error: reasons.append("modal_shape_mismatch")
        if float(np.max(np.abs(np.asarray(a.damping_ratios)-b.damping_ratios)))>max_damping_error:
            reasons.append("damping_mismatch")
    return {"status":"refused" if reasons else "comparable", "reasons":reasons,
            "requires_local_verification":True,
            "warning":"matching modes alone do not guarantee transferable dynamics"}


def encode(source: BodyCalibration, time_s, displacement_m, *, provenance: str,
           source_outcome_verified: bool, source_evidence_sha256: str) -> dict:
    if not source_outcome_verified:
        raise ValueError("source outcome not verified; no teaching")
    if provenance not in ("real_sensor","simulation"):
        raise ValueError("explicit real/simulation provenance required")
    if (len(source_evidence_sha256)!=64 or
            any(c not in "0123456789abcdef" for c in source_evidence_sha256)):
        raise ValueError("source evidence SHA256 required")
    t,y=_vector(time_s,displacement_m)
    token={"schema_id":"physica.dimensionless-step-response/v1",
           "source_machine":source.machine_id,
           "source_body":source.__dict__,
           "tau":(t*source.fundamental_hz).tolist(),
           "normalized_displacement":(y*source.stiffness_n_per_m/source.applied_step_force_n).tolist(),
           "provenance":provenance, "source_evidence_sha256":source_evidence_sha256,
           "units":{"tau":"1","normalized_displacement":"1","response":"m",
                    "frequency":"Hz","stiffness":"N/m","step_force":"N"},
           "assumptions":["linear time invariant near the operating point", "step force (not impulse)",
                          "calibrated stiffness, force and sensor", "modal-family similarity"]}
    token["token_sha256"]=hashlib.sha256(json.dumps(token,sort_keys=True).encode()).hexdigest()
    return token


def decode_forecast(token:dict, target:BodyCalibration, target_time_s) -> dict:
    if token.get("schema_id")!="physica.dimensionless-step-response/v1":
        raise ValueError("unknown physical token")
    chk=dict(token); digest=chk.pop("token_sha256",None)
    if hashlib.sha256(json.dumps(chk,sort_keys=True).encode()).hexdigest()!=digest:
        raise ValueError("altered physical token")
    src=BodyCalibration(**chk["source_body"])
    result=compatibility(src,target)
    if result["status"]!="comparable":
        return {"status":"refused","comparison":result}
    t=np.asarray(target_time_s,dtype=float)
    if t.ndim!=1 or not np.all(np.isfinite(t)) or not np.all(np.diff(t)>0):
        raise ValueError("target time grid must be strictly increasing")
    tau_b=t*target.fundamental_hz
    tau=np.asarray(chk["tau"])
    if tau_b[0]<tau[0]-1e-9 or tau_b[-1]>tau[-1]+1e-9:
        raise ValueError("out-of-range forecast (extrapolation forbidden)")
    norm=np.interp(tau_b,tau,chk["normalized_displacement"])
    pred=norm*target.applied_step_force_n/target.stiffness_n_per_m
    return {"status":"unverified_forecast", "comparison":result,
            "time_s":t.tolist(),"displacement_m":pred.tolist(),
            "source_sha256":digest,"provenance":chk["provenance"],
            "requires_local_verification":True}


def local_verify(forecast:dict, time_s, observed_displacement_m, *,
                 max_normalized_rmse=.12) -> dict:
    if forecast.get("status")!="unverified_forecast":
        raise ValueError("no transferable forecast")
    t,y=_vector(time_s,observed_displacement_m)
    tp=np.asarray(forecast["time_s"])
    if t.shape != tp.shape or not np.allclose(t,tp,rtol=1e-9,atol=1e-12):
        raise ValueError("observation grid must match committed forecast")
    pred=np.asarray(forecast["displacement_m"])
    rmse=float(np.sqrt(np.mean((pred-y)**2)))
    # Scale by peak-to-peak observed response (never by an arbitrary epsilon).
    scale=float(np.max(y)-np.min(y))
    if scale<=1e-12:
        return {"status":"inconclusive", "reason":"no measurable dynamic response","rmse_m":rmse}
    nr=rmse/scale
    return {"status":"locally_verified" if nr<=max_normalized_rmse else "contradicted",
            "normalized_rmse":nr,"rmse_m":rmse,
            "threshold":max_normalized_rmse,"provenance":forecast["provenance"],
            "note":"verification applies only to this specific local experiment"}
