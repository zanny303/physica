# Physica v0.4.1 — Audit repairs, prospective CRATE experiment and limits

**Implemented and unit-tested; NO real Physica hardware experiment, live Muse call, live SAM call or V-JEPA inference occurred while building this release.** This is a research prototype, not a general machine safety controller. It never sends actuator commands.

## Fixed two security/safety bugs in the v0.4 audit

1. `ResidualMemory.forecast` requires stored source calibration anchors and verifies **every** source against the target **inside the public method**. `free_free` vs `clamped_strip`, incompatible actuation families and modal/damping mismatches now refuse inference before model evaluation. A manually constructed memory with no calibration anchors also refuses.
2. `select_safe_probe` fails closed: NaN, infinity, negative force/cost/risk, overflow in utility/SNR, and non-finite global safety limits cannot create an eligible action. Invalid individual candidates return `rejected_invalid_numeric` with `null` rather than non-JSON NaN numbers. No hardware actuation is authorized.

These changes are backward-compatible with `fit_memory` and the tests under `tests/test_crate_v04.py`.

## New prospective experiment: source A teaches target B **before B is measured**

Prepare a JSON `signed_sources.json` with at least two **different already-measured source machines**, each with a signed, hash-linked source reveal, its original sensor CSV, and verified calibration file. To claim calibrated 90% intervals, also include independent *held-out whole machines* under `calibration` (at least 9 for a nominal 90% conformal quantile). Example structure:

```json
{
  "training": [
    {"reveal": "A1_reveal.json", "sensor_csv": "A1_displacement.csv", "calibration": "A1_cal.json"},
    {"reveal": "A2_reveal.json", "sensor_csv": "A2_displacement.csv", "calibration": "A2_cal.json"}
  ],
  "calibration": []
}
```

Source records must be signed with an authentic trusted key, link the exact CSV SHA-256, refer to a `real_sensor` episode with a calibrated sensor, match the body's machine ID, boundary and action class, and contain a numeric scalar reveal consistent with the CSV at its signed index. **Signing simulated data as `real_sensor` does not create physical evidence**; use actual experiments and witness the collection. Relative paths resolve from the manifest's location. All source and target calibrations need measured frequency, stiffness, force, modes, damping, boundary, and calibration ID.

1. Record the `time_s` grid for target B's **future** experiment. Include only the `time_s` column. Do **not** record or inspect B's displacement yet.
2. Create B's forecast and signature:

```bash
python -m physica.cli experience crate-field-prepare signed_sources.json B_calibration.json B_future_times.csv --out experiment_B_pretest
```

3. Preserve `experiment_B_pretest/01_sealed_target_prediction.json` and `target_forecast.json`; ask a third party to timestamp the **prediction SHA-256** before touching B. Cryptographic signing alone does not establish chronology.
4. Operate the low-force, independently supervised physical experiment with appropriate safety equipment; record `time_s,displacement_m` in **metres**, with independently measured force and synchronized clocks.
5. Compare B's **later** measurements against the exact original prediction:

```bash
python -m physica.cli experience crate-field-check experiment_B_pretest B_observed.csv --out experiment_B_result.json
```

This outputs a verified signed reveal, RMSE, local validation verdict, raw CSV hash, and a **tentative updated memory**. A surprising/contradictory result is retained as a learning signal, not silently discarded or moved into the original training set. **The same observed B response must NEVER be used to score its own updated memory.** Evaluate the candidate memory on independently unseen machine C.

With two source machines and no held-out calibration, prediction intervals are **UNCALIBRATED** and the signed scalar prediction has `sigma=null`, rather than inventing a 90% confidence interval. A signed reveal can then show `contradicted` even when the waveform RMSE is small: use the separately reported local-verification metric, not the point verdict, for that distinction.

## Optional: real Meta source analysis -> safely selected CRATE forecast

The live fusion entry point uses **existing source A** video and independent source A displacement sensor, never target B observations. It runs Muse Spark for visible context, SAM 3.1 for source component tracking/cross-check against calibrated physical motion, and Muse Wonder for hypotheses. Physica's numeric gate then selects among the approved safe experiment IDs. **Only if that selection equals the explicitly expected action, and a separate calibrated force/deflection eligibility gate passes, does CRATE sign target B's prediction.**

```bash
python -m physica.cli experience meta-crate-prepare source_A.mp4 source_A_synchronized.csv experiment_request.json signed_sources.json B_calibration.json B_future_times.csv \
  --concept 'tip of metal strip' --meters-per-pixel 0.0001 --fps 30 --expected-action safe_low_force \
  --out experiment_B_with_meta --allow-billed-meta
```

`--meters-per-pixel`, frame rate, independent sensor timings and action risk must be physically measured and validated. **`--allow-billed-meta` may incur account charges.** Authentication requires `MODEL_API_KEY` locally; don't share keys or include them in archive files. The live path is *not* claimed to be validated in this release. V-JEPA's calibrated forecast remains optional: the existing dual-world ranking expects real externally generated, held-out-calibrated physical forecasts; no V-JEPA model weights, execution or fabricated force readings are bundled.

## An attempted falsification, not a winning claim

Run:

```bash
python -m physica.cli experience crate-stress --out crate_stress.json --targets 24
```

This tests the earlier source-like simulation and a deliberately **out-of-family hidden forcing residual** on otherwise compatible machines. In the predeclared seed-42 stress scenario, the source-like CRATE zero-shot mean RMSE was **0.00988 mm** and nominal 90% full-trajectory coverage **23/24**. Under the hidden-dynamics shift, mean RMSE rose to **0.10464 mm**, and the source-like uncertainty band covered **0/24** full trajectories. This is a real limitation of the synthetic algorithm. Mode compatibility alone cannot detect all underlying physics changes; unsupervised zero-shot transfer therefore cannot be called universally safe or calibrated. An optional signed low-force B probe can be compared to the existing source memory **before** attempting a distinct higher-force test. This catches some shifts but does not guarantee safety.

With an explicitly defined **0.015 mm accuracy threshold** and **at most one low-force whole-waveform probe**, the source-like seed-42 24-target experiment finds 23 zero-probe CRATE successes, 0 rescued by the one probe, and 1 still unresolved; nearest-normalized source achieves 20 zero-probe successes. This threshold is a simulator metric, not a general sample-efficiency result. There is **no Koopman or advanced learned-dynamics baseline here**.

### Key research controls still missing

- Measured B-to-A camera and sensor timestamps, scale/perspective correction, sensor calibration provenance and external witness.
- Hardware A-to-B trials across several physical machines and **new physical families**, including deliberately incompatible cases.
- Source-only conformal calibration on real independent machines, risk-adjusted test plans and a low-force domain-shift detector before high-load interventions.
- Authenticated live Meta/model calls; pre-vs-post model ablations demonstrating causal value from SAM/Muse.
- Controlled comparisons to ARX/modal ID, system identification plus scale, nearest source, Koopman/shared-latent learning and CRATE on *real* held-out outcomes.

**Scientific claim appropriate today:** Physica implements a falsifiable candidate architecture for signed, dimensionless causal physical-experience transfer and guarded experiment selection. Its novelty and physical transfer advantage are **hypotheses**, not confirmed breakthroughs or hackathon-winning guarantees.

## Optional low-force domain-shift check (not a safety certificate)

If you already collected a **signed, hash-linked, lower-force B response** with its own calibration and have at least 9 independent whole-machine calibration records, run:

```bash
python -m physica.cli experience crate-probe-gate signed_sources.json B_high_force_cal.json B_low_force_reveal.json B_low_force.csv B_low_force_cal.json \
  --sensor-sigma-m 0.000007 --out low_force_shift_check.json
```

The supplied `--sensor-sigma-m` **must be independently calibrated**, not copied from this example. The gate compares the B low-force residual with source-like memory using the held-out normalized conformity threshold **plus an explicit 3.5-sigma sensor-noise heuristic**. Without held-out calibration or measured sensor noise it **will not clear** a source-like result. The 3.5-sigma correction is *not* formally calibrated for the maximum across all video/sensor frames and does not authorize actuation.

On this release's **specific** seed-42 synthetic stress set, the adjusted gate rejected **24/24 deliberately shifted** low-force probes and falsely rejected **0/24 source-like** probes. This is a controlled diagnostic, not sensitivity/specificity evidence for actual machines. It requires new hardware validation.

## Transfer what B learned to a previously unseen C

After B's measured CSV has been checked and signed, do **not** overwrite the original B prediction. Instead use its signed candidate model update to forecast C, a distinct machine not used in the source memory:

```bash
python -m physica.cli experience crate-followup-prepare \
  experiment_B_result_candidate_updated_memory.json \
  experiment_B_result_signed_reveal.json C_calibration.json C_future_times.csv \
  --out experiment_C_pretest
```

`crate-followup-prepare` checks the signature over **the entire candidate updated memory**, links the signed B reveal, enforces compatible calibration and new machine ID, and seals a C prediction **without reading C's future observation**. Then use `crate-field-check experiment_C_pretest C_observed.csv --out C_result.json` to verify the C outcome. Evaluate C's forecast **before C's data are learned**. Signing B's memory and C's forecast cannot prove experimental chronology without an external timestamp/witness.
