# Physica v0.7 — Reliable Predictive Feeling (2026-10-30)

Added independently calibrated, reliability-aware *joint* sensory innovation filtering, fair same-low-force-probe friction baseline, intervention-separated identification of three normalized mechanism candidates and signed target-probe verification, target-outcome leakage refusal, actual-data CLI, simulated ablation results, Meta candidate-name versus physics-registry ablation harness, reproducible research exhibit, and v0.7 technical/field guide.

Retains the original Body Map, Touch Transform, CSG, CRATE, CIRTE, PACER, signed A→B→C, Lab, Discover, Lens, and Meta adapters. None of the new mechanisms are established novel physical laws. All bundled v0.7 results are simulated. No live Meta API or physical hardware was exercised. Full older repository suite may be computationally expensive.
