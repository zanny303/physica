# Physica v0.41.0: real footage

Runs on real films with published or known answers: a 1940 bridge film (17.0 cycles per minute as it plays, against a published 18) and a 600 fps guitar (80.98 and 108.52 Hz, against tuning of 82.41 and 110). Muse can reason about the film's own speed, and code does the arithmetic. No live Muse run of this yet.

# Physica v0.40.0: feel force

The demo moved from printing, which took hours, to cables: film several cords, and Muse finds them, SAM keeps them apart, and Physica says how hard each is pulling, sealed before a scale checks it. Tested on simulated cords and a local stand-in only until a real film runs.

# Physica v0.39.0: one real part

**Muse watches video for the first time.** It names the parts that matter, points at them, and chooses what gets measured. SAM's masks are now kept and choose which pixels Physica reads. Muse investigates a real flaw on a real part, seals what each explanation predicts, and sets the goal. Physica writes a ready-to-print file, changing only outer-wall acceleration, and proves nothing else changed.

Also new: a twin you can push, from one tripod film; sealed coin forecasts; a with-and-without test with rules sealed first; one page in place of the old site.

**Tested on simulated films and a local stand-in only, not yet on Meta's live video path or on any real Ultimaker.** Compression can hide motion under about 0.3 pixels in simulated tests, and Physica says it can't tell rather than guessing. The blade twin test (not video) is a scratch result: on a separate session it left about 13 to 17% of the slow tone's shift unexplained, and across all tones it cut the error by about a third.

# Physica v0.38.1: the three proofs

**First real Muse results, 72 real blade checks across both runs, with no case counted twice:** right action on 45 for Physica alone, 45 for Physica with Muse reviewing, 45 for Muse with senses, 42 for Muse alone. Cracks missed: 5, 3, 3, 1. Needless stops: 2, 2, 2, 9. Muse as reviewer changed 6 actions: right 3, wrong 3. The gaps are small, on one blade, so they're not a general result. `meta senses --show --both` prints it.


**New in v0.38:** the front page shows only results and adds where this can go. `/more` is a guide to everything else you can try. Disclaimers about things Physica isn't claiming are gone, while labels on each real result stay. Muse can now investigate a bearing part-way through its life with `feel_bearing`, without seeing the end of the run.


**New in v0.37, Muse at the centre:** `printer-video investigate` has Muse run the investigation, calling Physica as its sense through tools, and stopping for a person to do anything physical. The website's front page shows the latest investigation. `/try/ruler` and `/try/file` are clean pages for the two hands-on tools. Tested on simulated films and a local stand-in only.


**New in v0.36, a bigger role for Meta. See docs/META_INTEGRATION.md:**
- `meta preflight`: one live test of each Meta step, with pass or fail and the cost.
- `muse-causes` now sends Muse photos from the films, Spark challenges its ideas, and an empty reply is asked again.
- `muse-update`: Muse sees the result, explains it, proposes the next test, and any unmeasured number is flagged.
- `muse-judge`: Muse compares photos of the two parts blind.
- `parts`: SAM separates the machine's parts, and Physica feels each.
- The count now uses Meta's published prices. The old guesses were up to 50 times too high for SAM.

**Not tested live:** these ran against a local stand-in and on simulated films. No real Muse or SAM call has used them yet.


**New in v0.35.6, from your first real Muse run, where 20 of 72 replies were cut off:**
- Longer reply limits on every Muse call the demo uses.
- `printer-video muse-causes`: Muse's ideas become sealed forecasts in the experiment, and can change the weight chosen.
- `meta senses --show` adds Physica with Muse reviewing, the true with-and-without score, with no new calls. `--confirm` repeats the test on cases the first run never used.

**New in v0.35.5:** a clean Studio front page with the three claims, Muse results and clips, read from saved results. The older page moved to `/everything`. `meta senses --retry-no-answer` asks again only where Muse gave no usable reply, with more room, and keeps the first run on file.


**Added in v0.35.4, for printers with no input shaping, like Ultimaker:** `goal --firmware cura` picks the fastest wall acceleration that meets your goal, using Cura settings only. `excite --header-from` copies the header newer Ultimakers require, with no heat. `excite`, `check` and `show` take `--accel`. Tested on simulated films only, and not yet on any real Ultimaker.


**Fixed in v0.35.3, found by your first live call:** Muse Spark always reasons before it answers, and that counts against the reply limit. The connection test allowed only 90 tokens, so the answer came back empty. Reply limits on the live test, `meta doctor`, `meta senses`, `meta ask` and the rival proposer are now large enough, and an empty reply gives a clear message.


**Fixed in v0.35.2:** the spending stop now defaults to $15 instead of $120, so forgetting the setting can't raise it.


**Fixed in v0.35.1, found by rehearsing every step in order:**
- The scoreboard missed goal, ripple and SAM results filed under a different name. Use one `--name` for everything.
- `printer-video excite` told you to tape the phone to the head. It now says tripod.
- `tune` and `sam-compare` reuse the crop from the baseline, so they don't pay for SAM again.

**New, all additive. Existing commands still work.**
- `printer-video goal`: you set a measurable target. It picks the lightest shaper that meets it across the felt tone range, or refuses, and `check` grades it on a new film. A miss moves on to the next shaper.
- `printer-video sam-compare`: the same films with and without SAM's crop, decided by calipers if they can resolve the gap, otherwise by precision. SAM can lose or tie.
- `printer-video ripple` and `grade-ripple`: a sealed forecast of ripple spacing on a printed part, graded with calipers, so the camera isn't checking itself.
- `printer-video show`: the measured shake magnified equally on before and after films.
- `printer-video proof`: a scoreboard for the three claims, read only from saved results. It shows NOT YET and FAILED too.
- `python -m physica.film f1|turbine|downtime`: clips from saved results, each labelled with its data source.

**Changed:** a printer lesson now records its evidence. It counts as verified only after a held prediction on the source printer with none broken, and `LESSON APPLIES ON THIS PRINTER` also needs a held prediction on the new printer that beats not using the lesson.

**New real-data result, E32, downtime on bearings that really failed (FEMTO, 11 test bearings, rules set on 6 others):**

| Alarm | Rang before the end | Median warning |
|---|---|---|
| Physica (all bands, added up over time) | 10 of 11 | 9.1 min, or 7.5 without one alarm so early it may be false |
| Plain alarm on each bearing's own normal | 10 of 11 | 2.2 min |
| Fixed 10 g alarm | 6 of 11 | 4.5 min, when it rang |

My first version of this sense lost to the plain alarm (7 of 11). I then chose the method above on the 6 learning bearings only and ran it on the test set once, but the test set had already been seen once, so treat the gain as weaker evidence than a first run. A warning in an overloaded lab run isn't downtime avoided.

**Not tested:** no live Meta call, no real printer film and no real SAM comparison. The printer steps have run on simulated films only. All three proofs are still open until you run them.
