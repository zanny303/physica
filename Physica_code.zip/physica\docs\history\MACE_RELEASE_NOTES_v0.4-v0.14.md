## NEW: v0.14 — Probabilistic Cross-Machine Experience Transfer (MACE-X)

This release adds an uncertainty-aware source experience memory, guarded Bayesian target adaptation, target-directed safe probes, independently calibrated cross-sensory acceleration proxies, an optional strictly gated Muse transfer strategist and a 0–32 shot cross-machine learning-curve benchmark. Results remain **SIMULATION ONLY** until a real field trial and authenticated Meta ablation are performed.

```powershell
python -m physica.mace_x.cli benchmark --seeds 12 --out demo/mace_x_v014/curves.json
python -m physica.mace_x.cli example --out demo/mace_x_v014/memory.json
python -m physica.mace_x.cli meta-advise --preview-only --out demo/mace_x_v014/meta_preview.json
```

Read [v0.14 research and field protocol](docs/V014_PROBABILISTIC_EXPERIENCE_TRANSFER.md). The existing v0.13 bounded mechanism discovery and Unified Studio are retained.

---

## v0.13 — Agentic Discovery, Sealed Cross-Sensory Forecasts, and Meta Scientist

**One application:** launch `python -m physica.studio --open-browser` (on Windows, use the Python executable in your `.venv`). Click **Launch the Discovery Theater** for a new end-to-end, clearly labeled synthetic investigation: automatically nominate bounded sine-phase mechanisms, validate across independent episodes, select or refuse transfer to camera/audio targets, sign forecast before generating simulator truth, compare against a target-only search baseline. Local webcam and microphone preview are available separately.

**Additional CLI:** `python -m physica.mace.agentic_v013 demo --out demo/v013`; `python -m physica.mace.agentic_v013 benchmark --seeds 12 --out demo/v013_bench`; `python -m physica.mace.prospective_field_v013 prepare|reveal`; `python -m physica.mace.meta_cycle_v013 --allow-billed-meta --out demo/meta.json` (requires your own Meta key).

**Research verdict:** reproducible software, not a proven cross-machine learning advantage, not independent real-hardware experience, and not a newly discovered natural law. Real dataset training and live Meta calls were NOT executed in this release. Read [the full v0.13 research guide](docs/V013_AGENTIC_DISCOVERY_FIELD_META_AND_LIMITS.md).

## v0.12.1: Unknown physics and testable Meta hypotheses

When real or simulated validation residuals show unexplained physics, Physica can refuse a surrogate explanation, request missing measurements, or invite an **explicitly approved, billable** Muse Spark/Wonder nomination that is fit and tested by the numerical model. Read [the v0.12.1 scientific protocol](docs/V0121_UNKNOWN_PHYSICS_META_PROTOCOL.md). Neither live Meta success nor physical discovery is claimed by the offline demonstration.

```bash
python -m physica.mace.cli unknown-investigate --seed 2026 --out demo/unknown_preview.json
python -m physica.mace.cli unknown-investigate --seed 2026 --nomination examples/mace_v0121/author_hypothesis_SIMULATED.json --out demo/unknown_offline.json
```

---

**Current release: Physica v0.12 — [Discovery Observatory and Live Sensing](docs/V012_DISCOVERY_AND_STUDIO.md).** The new mechanism-search benchmark is simulation-only; the Meta scientist and SAM require separate authenticated execution; the webcam monitor measures uncalibrated pixels. Run `python -m physica.studio --open-browser` after installation.

**Latest research hardening release:** [v0.11 Reliable Causal Feeling & Meta Scientist](docs/V011_RELIABLE_CAUSAL_FEELING.md). This upgrade fixes the v0.10 crash and adds target-aware probe design; see the report for what is and is not verified.

# PHYSICA v0.10 — MACE Multisensory Active Causal Experience

**Giving AI the ability to feel** (engineering: predicted and measured physical consequences, not consciousness).

MACE runs a bounded offline experiment in which A learns an additional physical mechanism from **controlled simulated** interventions and B/C receive prospective signed forecasts via a separate target probe. It also offers guarded optional Muse-generated hypothesis proposals, real controlled-action CSV evaluation, safety-aware sensor extension, and evidence-limited device diagnostics in **Unified Studio**. Complete previous Physica features are retained.

**Windows Terminal (PowerShell shell)** (after extracting ZIP to `C:\Users\budhw\Downloads\physicanew\physica`):

```powershell
cd C:\Users\budhw\Downloads\physicanew\physica
$env:PYTHONUTF8 = "1"
..\.venv\Scripts\python.exe -m pip install -e ".[dev,video]"
..\.venv\Scripts\python.exe -m physica.studio --open-browser
```

Open `http://127.0.0.1:8765` → **MACE Investigation** → **Run**. No Meta key is required for the offline demonstrations.

```powershell
..\.venv\Scripts\python.exe -m physica.mace.cli demo --out demo\mace
..\.venv\Scripts\python.exe -m physica.mace.cli benchmark --seeds 8 --out demo\mace_benchmark
..\.venv\Scripts\python.exe -m physica.mace.cli meta-preview --context examples\mace_v010\meta_training_context.json --out demo\meta_preview.json
```

**Truthful evidence labels:** Synthetic is not real hardware. The default candidate is **human-authored in source**, not Muse-generated. Live authenticated Meta inference requires your private `MODEL_API_KEY` and `--allow-billed-meta`. Missing-sensor predictions are never equivalent to a measurement. No arbitrary generated code is executed.

Full technical guide: [`docs/V010_MACE_RESEARCH_AND_REAL_DEPLOYMENT.md`](docs/V010_MACE_RESEARCH_AND_REAL_DEPLOYMENT.md).

---

## v0.9.0rc1 — Selective Predictive Feeling (research candidate)

The new `physica.research_v09` package implements source-population hierarchical physical transfer, safe target-directed Bayesian probe design, independent future-sensation forecasting, and a guarded latent-versus-ARX model selector. A simulated cross-sensory experience runs from audio/contact-proxy on Machine A to camera/inertial-proxy on B with a separate integrity commitment and reveal. Physica Studio exposes the non-actuating offline benchmark and a strict-schema Meta API preflight.

**Crucial:** v0.9 is not a proven scientific breakthrough or real-world five-sense AI. The new studies use physics simulators and **known/calibrated observation maps**, the learner uses conventional empirical Bayes and A-optimal design, and authenticated Meta calls have not been performed. Source machines use extra experiments and a local SHA-256 hash does not prove independent chronology. Real physical tests and comparison to strong published baselines remain necessary.

See [`docs/V090_RESEARCH_CANDIDATE_AND_REAL_EVIDENCE.md`](docs/V090_RESEARCH_CANDIDATE_AND_REAL_EVIDENCE.md) and `CHANGELOG_v090.md`. Reproduce with `python -m physica.research_v09.run --seeds 18 --trials 24 --out demo/research_v09/benchmarks.json`.

# Physica v0.8.4 — Unified Studio

**One interface for Physica Lab, Discover, Lens, Transfer, original Feel Check and Meta readiness.**

On Windows, from the folder containing this `pyproject.toml` (e.g., `C:\Users\budhw\Downloads\physicanew\physica`), with your virtual environment in the parent directory:

```powershell
..\.venv\Scripts\python.exe -m pip install -e ".[dev,video]"
..\.venv\Scripts\python.exe -m physica.studio
```

Or double-click **`RUN_PHYSICA_STUDIO_WINDOWS.bat`** from the extracted `physica` folder once the dependencies are installed; it opens your browser automatically.

Open **http://127.0.0.1:8765**. Use **Ctrl+C** to stop the server. Studio launches only explicitly selected, fixed, non-billable, non-actuating research workflows. Its synthetic demos are *not* hardware results. The original CLI commands still work. The locally installed entrypoint `physica-studio` is also available.

See [`CHANGELOG_v084.md`](CHANGELOG_v084.md) for Studio contents, security, evidence limits, and tests.

---

> **v0.8.1 latest:** [Signed Adaptive Prospective Feeling release](CHANGELOG_v081.md) · [Scientific evidence and real-field guide](docs/V081_PROSPECTIVE_EVIDENCE_AND_FIELD_GUIDE.md) · [New offline evidence lab](examples/v081_prospective_simulated/experience_lab.html). The actual signed future forecast now uses the verified hierarchical source+target-probe estimate and local-only fallback, rather than the source-only value. A signed reveal receipt can be independently recomputed. **Simulated results only; no authenticated Meta calls or real hardware experiments.**

```sh
python -m physica.feeling.v081_replay --out demo/v081_staged
python -m physica.feeling.v08_cli benchmark --out demo/v081_24.json --trials 24
python -m pytest -q tests/test_feeling_v081.py
```

---

> **v0.8 research extension:** see [Prospective Feeling example and honest evaluation](examples/v08_prospective/README.md) and [v0.8 changelog](CHANGELOG_v080.md). The new future-sensation demo is **SIMULATED**, not live hardware or authenticated Meta inference.

# Physica v0.7 — Reliable Predictive Feeling and Transferable Mechanisms

**New:** a reliability-aware joint sensory filter (with refusal when senses disagree), a stronger conventional friction baseline with the *same target probe*, and independent-intervention search for missing causal force mechanisms, which can be conditionally transported to a different calibrated body with a signed raw low-force check. Existing original Physica Lab · Discover · Lens and all previous modules are preserved.

```bash
pip install -e '.[dev,video]'
python -m physica.feeling.v07_cli benchmark --trials 12 --out demo/v07_research.json
python -m physica.feeling.v07_cli fuse examples/v07_research/fusion_input_SIMULATED.json --out demo/fused_senses.json
python -m physica.feeling.cli demo --out demo/feeling_v06
python -m physica.triad.cli lens-serve --port 8765
```

Start at **[v0.7 science and real-field guide](docs/V070_MULTISENSORY_FEELING_AND_EVIDENCE.md)**, the [v0.7 evidence lab](examples/v07_research/evidence_lab.html), and [v0.7 changelog](CHANGELOG_v070.md). New experiments are **synthetic only**. Live Meta/SAM calls and real hardware were **not** executed; this is not evidence of consciousness or a demonstrated scientific breakthrough.

---

# Physica v0.6 — Giving AI the ability to feel (predictive physical feeling)

**NEW:** Action-conditioned sensory prediction; compare expected versus observed sound, motion, touch, and proprioceptive response; learn bounded candidate contact dynamics from intervention-separated evidence; teach another calibrated body with an independently recomputed low-force probe; sign predictions and outcomes; predict C in a different sensor's units; bounded online adaptive feeling and counterfactual supervised suggestions. All v0.5.2 features remain.

**Offline simulation:**

```sh
pip install -e '.[dev,video]'
python -m physica.feeling.cli demo --out demo/feeling_v06
python -m physica.feeling.cli benchmark --out demo/feeling_benchmark.json --trials 20
python -m physica.triad.cli lens-serve --port 8765
pytest -q tests/test_predictive_feeling_v060.py
```

The live measured-data pipeline has separate `learn`, `prepare-probe`, `check-probe`, `prepare`, and `check` commands; inspect **[v0.6 technical / Meta / field guide](docs/V060_PREDICTIVE_FEELING_RESEARCH.md)**, **[hackathon film script](docs/HACKATHON_V060_FEEL.md)** and **[v0.6 changelog](CHANGELOG_v060.md)**.

**Truth in labeling:** This work does **not** demonstrate subjective feelings, real cross-machine physical experimentation, chemical identification, authenticated Meta inference, local V-JEPA model execution, or established novelty. The included new examples are explicitly **simulation**. A completed ZIP cannot prove the physical research claim without external measurements.

---

# Physica v0.5.2 — Physica Lab · Discover · Lens

**New in v0.5.2:** three demonstrations driven by the same physical-evidence boundaries, target-directed experiment selection, a real-video prefix/heldout predictor, and a local Physica Lens browser prototype. Existing CIRTE, CSG, PEL, CRATE, Touch Transform, Meta adapters, and A→B→C field workflows remain intact. Research novelty and a hackathon win are **not established**. No authenticated Meta calls or independent physical experiments were performed for this release.

```bash
pip install -e ".[dev,video]"
python examples/triad_v052/BUILD_TRIAD.py examples/triad_v052/showcase
python -m physica.triad.cli target-design examples/triad_v052/target_transfer_design.json --out experiment_choice.json
python -m physica.triad.cli lens-serve --port 8765
```

**Start with `docs/V052_THREE_ACTS_RESEARCH.md`** for the three-demo design, real recorded-video forecast, Meta setup, public datasets, experimental controls and limitations. `--meta` functionality is billable and requires your own `MODEL_API_KEY`; do not share or commit the key.

---

# Physica v0.5.1 — Meta Context & Mechanism Discovery

**Latest release:** Audit-bound transfer authorization, raw low-force probe recomputation, multidimensional sensor calibration ranges, officially parsed SAM 3.1 geometry, Muse schema-constrained scientific context, and heldout-tested nonlinear mechanism candidates. **No live Meta or real hardware experiment was performed here.** See [`docs/V051_DEEP_RESEARCH_META_BREAKTHROUGH.md`](docs/V051_DEEP_RESEARCH_META_BREAKTHROUGH.md) and [`examples/v051_research/demo/research_lab.html`](examples/v051_research/demo/research_lab.html).

Offline run:

```bash
pip install -e ".[dev]"
python examples/v051_research/BUILD_DEMO.py examples/v051_research/demo
python -m physica.cli grammar cirte-mechanism examples/v051_research/demo/interventions_SIMULATED.json --out demo/mechanism.json
```

---

# Physica v0.5 — CIRTE (Causal Interventional Representation & Transfer of Experience)

**Latest research release: simulated research software, not demonstrated real-hardware intelligence.**

New since v0.4.3: physical acoustic pressure can enter a calibrated latent state without being falsely labelled as velocity; native-unit A→B→C signed transfer; safe **transfer / probe_first / refuse** gate; expected-information-gain experiments; UNKNOWN mechanism handling; constrained Meta scientific hypotheses; temporal latent readout and rigorous held-out Meta ablation input checks.

Start here: **[v0.5 research and field instructions](docs/V050_CIRTE_RESEARCH_AND_FIELD.md)** | **[three-minute hackathon plan](docs/V050_HACKATHON_SUBMISSION.md)** | **[change log](CHANGELOG_v050.md)**.

```sh
pip install -e '.[dev]'
python -m physica.cli grammar cirte-benchmark --out demo/cirte_benchmark.json
python examples/cirte_v05/BUILD_NATIVE_SIMULATION.py examples/cirte_v05/native_demo
pytest -q tests/test_cirte_v05.py
```

**Unverified:** real A→B→C physical measurements, live Meta API calls, locally run V-JEPA, chemical hardware, research novelty against state-of-the-art. This release does not silently convert simulation into validation.

---

# Physica v0.4.3 research extension

See **[docs/V043_RESEARCH_AND_EVIDENCE.md](docs/V043_RESEARCH_AND_EVIDENCE.md)** and **[CHANGELOG_v043.md](CHANGELOG_v043.md)** for the new causal-sensory research, validated and unvalidated components. Original README and CLI continue below.

---

# Physica v0.4.2 — Causal Sensory Grammar (CSG)

**New:** a physically typed, sensor-to-sensor experience language, calibrated multisensory mechanical inference, prospective signed A→B→C tests, and a documentation-grounded optional live Meta→SAM→CSG→PEL workflow. It extends the complete original project; the six-sense robot, live Meta calls and hardware results are **not** claimed complete.

```bash
python -m pip install -e '.[dev]'
python -m physica.cli grammar demo --out demo/csg --trials 12
python -m physica.cli grammar benchmark --out demo/csg_benchmark.json --trials 24
python -m physica.cli grammar schema --out docs/pel_v3.schema.json
python -m pytest -q tests/test_grammar_v042.py
```

Open `demo/csg/experience_lab.html`. The pre-rendered example lives at `examples/csg_showcase/experience_lab.html`. **Everything on that demo is simulated.** See [full protocol](docs/V042_CAUSAL_SENSORY_GRAMMAR.md), [hackathon materials](docs/HACKATHON_V042.md) and [changelog](CHANGELOG_v042.md). Existing `physica experience ...` commands and all previous features remain available.

---

> **v0.4.1 safety/field update (October 2026):** v0.4 audit bugs repaired, real-sensor A→B precommit/check pipeline added, optional billed source-side Muse/SAM/Wonder→CRATE workflow connected, and out-of-family synthetic stress tests added. See [CHANGELOG_v041.md](CHANGELOG_v041.md) and [docs/V041_AUDIT_AND_FIELD.md](docs/V041_AUDIT_AND_FIELD.md). Live model and hardware experiments **not performed** in this release.

# NEW: Physica v0.4 — CRATE research edition

**One-line thesis:** Physica aims to let compatible machines exchange calibrated physical action–response experiences rather than only text, using an explicit mechanistic baseline plus causal residual transfer.

**Try it offline:**

```bash
pip install -e ".[dev]"
python -m physica.cli experience crate-demo --out demo --seed 42 --targets 24
python -m physica.cli experience meta-preflight
pytest -q tests/test_crate_v04.py tests/test_frontier.py tests/test_experience.py
```

Open `demo/physica_v04_experience_lab.html`. **All new CRATE benchmark results are synthetic; no live Meta API or hardware transfer is claimed.** See `docs/V04_BREAKTHROUGH_AND_META.md`, `docs/META_LIVE_FIELD_CHECKLIST.md`, `docs/HACKATHON_PITCH_v04.md`, and `CHANGELOG_v04.md`. This release **retains all previous modules, tests and evaluations**.

---

# PHYSICA v0.3 — Physical Experience Between Machines

> **New in v0.3:** experimental dual-world causal residual experiment ranking,
> dimensionless step-response transfer, audit-ready signed A→B simulation,
> Meta Responses gateway, incompatible-body refusal and repeated synthetic ablation.
>
> **Honest status:** these additions are tested on an oscillator simulator, **not**
> validated on real machine A/B pairs; Muse, SAM 3.1 and V-JEPA 2 were **not** run
> in the v0.3 demo. Mathematical parts draw on established system identification,
> Bayesian design and dimensional analysis. Do not claim a novel theorem or a win.

```bash
python -m pip install -e '.[dev]'
python -m physica.cli experience frontier-demo --out frontier_demo
python -m physica.cli experience frontier-ablation --out frontier_ablation --seeds 30
python -m physica.cli experience meta-status
pytest -q tests/test_frontier.py tests/test_experience.py
```

Open `frontier_demo/physica_v03_experience_lab.html` for the offline demonstration.
The machine A and B prediction commitments, signed reveal and transfer token are
stored separately under `frontier_demo/`; independent trusted timestamps are **not**
provided. For live physical validation, follow `docs/REAL_WORLD_VALIDATION.md`.
For architecture, mathematics, Meta availability and recommended competition demo,
read `docs/FRONTIER_v03.md` and `docs/DUAL_WORLD.md`.

---

> **NEW — Physica v0.2 PACER Physical Experience Language (2026-10-30).** This distribution preserves the original Feel Transform/Body Map/Order Feel/Body Bank/Meta agents and adds **a typed language for action→consequence episodes, safety-constrained causal experiment selection, Ed25519 sealed predictions and reveals, cross-machine comparability checks, and a self-contained synthetic Machine A→B demo**. Start with `python -m physica.cli experience demo --out demo`, then open `demo/experience_lab.html`. See [PACER Protocol](docs/PACER_PHYSICAL_LANGUAGE.md), [Hackathon Materials](docs/HACKATHON_2026_SUBMISSION.md) and [Validation Status](docs/REAL_WORLD_VALIDATION.md). **Synthetic demo is not real-world validation.** Muse live mode needs API access; SAM 3.1 and V-JEPA 2 are not yet integrated into this new layer. The original source claims/evaluation datasets have not all been rerun independently in this update.

Built Oct 26 – Nov 4, 2026 for the Meta Global AI Developer Hackathon.

## v0.8.2 field/demo readiness (no invented real-world proof)

The new `physica.field` module tests real sensor evidence, prospective chronology, calibration, API readiness and signed-reveal data integrity before interpreting a physical demonstration. See `docs/V082_FIELD_AND_META_READINESS.md` for Moody Makerspace steps, templates and limitations.

```bash
python -m physica.field.cli meta-doctor --out meta_readiness.json
python -m physica.field.cli preflight REAL_METADATA.json REAL_SENSOR.csv --out field_preflight.json
python -m physica.field.cli score-sealed REAL_METADATA.json REAL_SENSOR.csv SEALED_FORECAST.json --out real_evaluation.json
```

This code **cannot guarantee** a successful hardware test, authenticated Meta model usefulness, or an algorithmic breakthrough. It does not control hardware.

## v0.8.3: train from cloud signals, evaluate recorded physics, and draft machine actions

See [`docs/V083_CLOUD_META_TRAINING_AND_THREE_DEMOS.md`](docs/V083_CLOUD_META_TRAINING_AND_THREE_DEMOS.md).

```bash
pip install -e '.[dev,video]'
python -m physica.remote_bench.cli pilot --out demo/pilot
python -m physica.remote_bench.cli train-next demo/pilot/manifest.json --out demo/next  # optional, pilot already trains both
python -m physica.remote_bench.showcase demo/pilot --out demo/physica_discover_cloud.html
```

The included pilot weights and exhibit use **generated synthetic signals only**. For actual cloud training, separately obtain licensed Paderborn raw recordings, inspect MAT fields, supply independently verified group labels, and run `python -m physica.remote_bench.cli train ...` and `train-next ...`. Whole physical bearing IDs are held out from training. Existing `python -m physica.triad.cli prepare-video/check-video` supports prefix-only recorded-video forecasting and `meta-scientist` supports opt-in live Spark/Wonder/SAM contextual analyses. The new `live-muse-draft` command recommends **review-only** bounded machine instructions from verified measurements; it never actuates hardware.


## v0.8.5 Research Core
Run `python -m physica.causal_memory.benchmark --out demo/causal_memory.json` for controlled-action cross-body synthetic mechanism training. See `docs/V085_CAUSAL_EXPERIENCE_RESEARCH.md`. This is not independently trained real-world foundation-model intelligence.


## v0.8.6 · Learned experience and Meta reasoning
See `docs/V086_LEARNED_EXPERIENCE_RELEASE.md`. Studio now includes a learned action-conditioned sensory experiment and offline Meta doctor. Paid inference remains explicit local CLI opt-in.
