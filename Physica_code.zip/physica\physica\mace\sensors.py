"""Machine-only sensor modalities and conservative virtual-sensing contracts."""
from __future__ import annotations
import math
import numpy as np

MODALITIES={
    'camera_m': {'unit':'m','sees':'calibrated displacement','requires':'independent length scale and stationary reference'},
    'audio_m_per_s':{'unit':'m/s','sees':'calibrated velocity proxy','requires':'independent transfer function; raw audio is not velocity'},
    'tactile_n':{'unit':'N','sees':'contact force','requires':'calibrated force transducer'},
    'imu_accel':{'unit':'m/s^2','sees':'accelerometer acceleration','requires':'orientation and gravity correction'},
    'motor_current_a':{'unit':'A','sees':'motor electrical current','requires':'motor telemetry calibration'},
    'temperature_c':{'unit':'degC','sees':'surface temperature','requires':'thermometer or calibrated thermal sensor'},
    'magnetic_ut':{'unit':'uT','sees':'magnetic-field variation','requires':'magnetometer calibration'},
    'ultrasonic_hz':{'unit':'Hz','sees':'ultrasound features','requires':'ultrasonic transducer'},
    'radar_doppler_hz':{'unit':'Hz','sees':'radar motion signature','requires':'radar transceiver'},
    'chemical_ppm':{'unit':'ppm','sees':'specific gas concentration','requires':'chemically calibrated sensor, not camera inference'},
    'hyperspectral_reflectance':{'unit':'relative','sees':'wavelength-dependent reflectance','requires':'spectrometer plus illumination calibration'},
}

def fuse_state(measurements, calibration, *, chi2_limit=10.83):
    """Infer [position,velocity] from independently calibrated channel operators.

    No inference from uncalibrated audio, IMU, chemical or raw image content.
    The joint innovation test on redundant measurements abstains on conflict.
    """
    rows=[];values=[];sigmas=[]
    if set(measurements)-set(MODALITIES): raise ValueError('unsupported sensor')
    for name,value in measurements.items():
        if name not in ('camera_m','audio_m_per_s'): continue
        info=calibration.get(name)
        if not isinstance(info,dict) or info.get('independently_calibrated') is not True:continue
        if name=='audio_m_per_s' and info.get('transfer_function_verified') is not True:continue
        sd=info.get('noise_sd');gain=info.get('gain')
        samples=value if isinstance(value,list) else [value]
        if not samples or len(samples)>24:raise ValueError('invalid number of redundant observations')
        if any(isinstance(n,bool) or not isinstance(n,(int,float)) or not math.isfinite(n) for n in (sd,gain,*samples)) or sd<=0 or abs(gain)<1e-9:raise ValueError('invalid calibrated measurement')
        for sample in samples:
            rows.append([gain,0.] if name=='camera_m' else [0.,gain]);values.append(float(sample));sigmas.append(float(sd))
    if len(rows)<2:return {'status':'ABSTAIN_UNOBSERVABLE','available_channels':len(rows),'missing_or_unverified':[k for k in measurements if k not in calibration]}
    H=np.asarray(rows);y=np.asarray(values);sd=np.asarray(sigmas)
    Hw=H/sd[:,None];yw=y/sd
    if np.linalg.matrix_rank(Hw)<2:return {'status':'ABSTAIN_UNOBSERVABLE','available_channels':len(rows)}
    state=np.linalg.lstsq(Hw,yw,rcond=None)[0]
    error=float(np.sum(((H@state-y)/sd)**2))
    if error>chi2_limit:return {'status':'ABSTAIN_CONFLICT','chi2':error,'calibration':'independent telemetry required'}
    cov=np.linalg.inv(Hw.T@Hw)
    return {'status':'FUSED_ESTIMATE_NOT_DIRECT_MEASUREMENT','state_x_m_v_mps':state.tolist(),
            'covariance':cov.tolist(),'chi2':error,'channels':len(rows),
            'redundancy_validated':bool(len(rows)>2)}

def inventory():return MODALITIES

def virtual_sense(name, model_prediction, calibrated_sd, *, evidence_kind='indirect_model_prediction'):
    if name not in MODALITIES:raise ValueError('unknown machine sense')
    if not isinstance(model_prediction,(int,float)) or not math.isfinite(model_prediction):raise ValueError('invalid prediction')
    if not isinstance(calibrated_sd,(int,float)) or not math.isfinite(calibrated_sd) or calibrated_sd<=0:raise ValueError('invalid uncertainty')
    return {'modality':name,'value_estimated':float(model_prediction),'unit':MODALITIES[name]['unit'],
            'uncertainty_sd':float(calibrated_sd),'kind':evidence_kind,
            'status':'VIRTUAL_ESTIMATE_NOT_MEASURED','do_not_use_as_ground_truth':True}
