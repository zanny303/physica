# Physica v0.8.1 — Signed Adaptive Prospective Feeling

Built directly on the user-provided **Physica v0.8 Prospective Feeling Enhanced** ZIP. All prior packages, demonstration paths, and tests were retained.

## Fixed: signed prediction used wrong algorithm

The v0.8 benchmark calculated `combine_source_and_probe(...)`, then scored its result **separately** from the signed `seal_future_sensations(...)` forecast. The signed forecast still used the source-only beta. That was the single highest-impact correctness gap because a favorable benchmark did not represent the actual live forecast.

In v0.8.1 `seal_future_sensations` now independently validates the signed source and target probe, extracts the measured probe **only from the signed certificate**, recomputes the hierarchical model (including model-conditional local-only fallback), and signs the actual chosen coefficient and complete adaptation metadata with its future sensory predictions. This closes the benchmark/demo disconnect without allowing a caller-supplied coefficient to bypass evidence checks.

- Source and local parameter estimates, source weight, discrepancy z-score, variance assumption, and fallback status are included in the signed forecast.
- The signed low-force certificate's sensor-force noise cannot be replaced with a more favorable value during posterior fitting.
- Declared cross-body variance and conflict threshold are input-validated and signed.
- v0.8.1 now includes model-conditional **parameter sensitivity envelopes**, labeled explicitly as not calibrated statistical coverage intervals.
- Reveal scoring also creates a separate signed receipt binding the raw measurement hash and recomputed errors.
- A `verify-reveal` CLI action rechecks the forecast signature, receipt signature, input hash, and numerical metrics against the independently supplied raw measurements.
- A staged synthetic example creates the signed target future forecast **before** generating synthetic target truth. This is still not independently witnessed physical chronology.

## Reproducible evaluations — simulated only

**24 compatible synthetic targets (seed 2026):**

| Method | Average future camera-position RMSE (mm) |
| --- | ---: |
| Physics without nonlinear mechanism | 0.75654 |
| Source only | 0.03032 |
| Conventional target-only model, one target probe | 0.02182 |
| Hierarchical source + the same target probe | **0.01826** |
| **Actual signed v0.8.1 forecast** | **0.01826** |

The source+probe model improves the *mean* RMSE about 16.3% over target-only in this favorable simulation, but **loses to target-only on 9 of 24 individual machines**. It also consumes **three prior source experiments** that the target-only baseline doesn't; equal target-probe count is not equal total experiment count. The data generator already assumes the mechanism family and favorable cross-body similarity.

**Declared parameter-shift stress (seed 25):** values 0.22/0.26 use the hierarchical posterior; 0.30–0.50 trigger **local-only fallback inside the signed forecast**; 0.65/0.80 refuse. This is not a real OOD reliability claim. Different unmodeled dynamics could defeat the gate.

**One simulated staged replay:** for hidden beta 0.244, the actual signed forecast has RMSE 0.00940 mm versus synthetic noiseless truth, but the target-only result is **better** (0.00288 mm). The source-only result is 0.05597 mm. The negative comparison is preserved.

## What is *not* achieved by this release

- No authenticated Meta model calls or demonstrated benefit from SAM/Muse/V-JEPA.
- No real synchronized external force, camera and audio experiment; no independent timestamp/witness.
- No empirical calibration of transfer uncertainty or the conditional sensitivity envelopes.
- No proof of a novel fundamental algorithm, broad generalization, or subjective consciousness.
- No robot actuator control. All numerical outputs are informational only.

See `docs/V081_PROSPECTIVE_EVIDENCE_AND_FIELD_GUIDE.md`, `examples/v081_prospective_simulated/`, `physica/feeling/prospective_v08.py`, and the new regression tests.
