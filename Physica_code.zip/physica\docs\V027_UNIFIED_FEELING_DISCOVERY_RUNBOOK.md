# Physica v0.27 — Unified Predictive Feeling, Discovery and Transfer

**Computational physical sensation, not subjective experience. Research-only; no hardware actuation.**

This release links the pre-existing neural dynamics, calibrated sensor-belief interface, source-blind symbolic baselines, authenticated Muse Wonder–Spark–Wonder Research Council, mathematical model fitting, safe review-only experiment planning, A→B prospective transfer, measured revelation, and an experience-memory stage **into a single evidence-gated workflow**.

## Important boundary

The default demonstration uses **two simulated machines and a human-written hypothesis** whose mathematical *family* matches the simulator. Its purpose is to verify the workflow and test refusals, NOT to claim the model discovered a previously unknown real physical law. A live Muse call can nominate an entirely different hypothesis and may fail validation. A local SHA-256 seal is not an independent timestamp. Operator-entered calibration provenance is not independently certified.

### What each stage actually does

1. **Feel**: From one SOURCE TRAIN episode, compare calibrated known-physics one-step acceleration with measured acceleration; the neural predictor is trained on *earlier* SOURCE TRAIN episodes, then tested on the last TRAIN episode. Declared sensor noise is required; otherwise abstain. Source VALIDATION is not opened for the feeling gate.
2. **Curiosity trigger**: If a predeclared fraction of measurements has statistically large physics prediction errors, request scientific investigation. Low surprise does not start Muse.
3. **Discover**: The original neural-symbolic search supplies a source-blind baseline. Muse Wonder proposes a bounded AST hypothesis, Spark attacks it, Wonder may revise it. Numerical parameters are fitted on SOURCE TRAIN, then compared on separate SOURCE VALIDATION episodes. An unsupported law is rejected.
4. **Experiment**: Fit both candidate models to the same target pre-probe data. Choose a conservative, supported target probe where their predicted responses differ. Write and integrity-seal the review-only plan. A person conducts the physical experiment; Physica never controls hardware.
5. **Experience/forecast**: After the planned probe's controls, sampling interval and initial state are verified, fit candidate and target-only models with the same evidence budget and commit their predictions for a **different future experiment**.
6. **Reveal**: Read that future sensor record *after* the prediction receipt exists. Compare every frozen forecast, flag a possible sensory mismatch and explicitly report unsuccessful transfer.
7. **Learn/transfer**: Move that formerly future episode into a **new** target training manifest *after it has been scored*. Optionally export a signed candidate physical lesson containing the updated bounded expression and fitted coefficients. A new experiment is needed to evaluate whether this knowledge helps. It cannot retroactively improve the original scored test. A later receiving machine must perform its own compatibility and validation checks.

The design intentionally treats mathematical hypotheses as **proposals**, not model truths. Neural ensemble variance is an exploratory diagnostic, **not calibrated physical uncertainty**.

## Windows setup (PowerShell)

From inside the extracted `physica` folder:

```powershell
python -m pip install -e ".[dev]"
$env:PYTHONUTF8 = "1"
python -m physica.frontier.meta_ready_v026 doctor
```

### Offline full-loop demo (no network, no Meta API charges)

```powershell
python -m physica.frontier.feeling_discovery_loop_v027 synthetic-demo `
  --seed 7 --out demo/v027_offline
```

See `demo/v027_offline/RESULTS_SYNTHETIC.json` and the stage receipts in `demo/v027_offline/EXPERIENCE_LOOP/`. The demo also runs **a second unseen trial**: it freezes one forecast before incorporating the first test into training and another after learning. Both are sealed before the second simulator outcome is generated. The before/after comparison uses an *additional training episode*, so it is not an equal-data-budget benchmark.

For a negative-control law that Physica should reject:

```powershell
python -m physica.frontier.feeling_discovery_loop_v027 synthetic-demo `
  --wrong-hypothesis --out demo/v027_rejection
```

The default demo is also in Studio → **MACE Investigation**:

```powershell
python -m physica.studio --open-browser
```

### Live Muse full-loop sandbox (your own key, no need to share)

Set your environment privately. Do not put credentials in command-line arguments, uploaded data files, Git repositories, or demo recordings:

```powershell
$env:MODEL_API_KEY = "YOUR_PRIVATE_META_API_KEY"
$env:MOCK = "0"
$env:PHYSICA_BUDGET_USD = "5"
python -m physica.frontier.meta_ready_v026 doctor
python -m physica.frontier.meta_ready_v026 live-smoke --role wonder --allow-billed-meta
python -m physica.frontier.feeling_discovery_loop_v027 synthetic-demo `
  --live-meta --allow-billed-meta --out demo/v027_muse_sandbox
```

This makes **three fresh billable API calls** for the candidate research council if the source sensory gate activates. The rest of the experiment still runs in a **simulated world**. Muse's hypothesis is allowed to fail; it is never replaced by the built-in correct human hypothesis. The actual API authentication and provider output have not been tested in the developer's environment. Check current provider access and model identifiers for your account before billing.

**Security:** local client receipts are useful provenance and integrity evidence but do not prove model-provider provenance independently against malicious local tampering. A third-party audit needs independently recorded provider confirmations and externally witnessed prediction timestamps.

## Use your own physical machines (manual staged experiment)

Physical recordings must be accompanied by SOURCE and TARGET manifests, each located inside its own evidence folder. Each manifest has exactly this shape:

```json
{
  "fixture_id": "MACHINE_A_UNIQUE_ID",
  "calibration_file": "calibration.json",
  "episodes": {
    "train": ["source_train1.csv", "source_train2.csv", "source_train3.csv"],
    "validation": ["source_val1.csv", "source_val2.csv"]
  }
}
```

Calibration JSON requires `method`, `operator`, `date_utc`, `instrument`, `units`, and a supported known-physics baseline. v0.27 also needs a **justified measurement-noise standard deviation** to trigger calibrated curiosity:

```json
{
  "method": "Independent calibration method (describe, do not claim it if absent)",
  "operator": "CALIBRATION_OPERATOR",
  "date_utc": "2026-11-02T00:00:00Z",
  "instrument": "SPECIFIC_INSTRUMENT_AND_SERIAL",
  "units": "SI",
  "sensor_sigma_acc_m_s2": 0.01,
  "physics_baseline": {
    "stiffness_s2": 1.8,
    "damping_s1": 0.32,
    "control_gain": 1.0
  }
}
```

**Numbers above are examples only, not real measured calibration values.** The supported physical model is a controlled, one-dimensional spring/damper-like system, not an arbitrary robot or machine. You cannot simply relabel unrelated camera or sound data as these measurements.

Training/validation CSV columns in exact order:

```text
x_m,v_m_s,u_m_s2,acc_m_s2
```

Future probe and test recordings require an additional leading `time_s` column and strictly increasing elapsed time starting at zero. Target source/validation files must not duplicate source data. The names `MACHINE_A_UNIQUE_ID` and `MACHINE_B_UNIQUE_ID` must differ and must refer to physically distinct systems, not arbitrary aliases for the same setup.

**Step A — establish surprise and have Muse investigate the source:**

```powershell
python -m physica.frontier.feeling_discovery_loop_v027 investigate `
  --source-manifest real/A/manifest.json `
  --target-manifest real/B/manifest.json `
  --live-meta --allow-billed-meta --out real/investigation
```

If the evidence is incomplete or the hypothesis fails validation, the system **refuses** and does not plan an experiment. Inspect `real/investigation/00_LOOP_STATUS.json`. Otherwise review `03_TARGET_PROBE_PLAN.json`. Its planned acceleration inputs are **requests for an approved physical experimental procedure**, never controller commands.

**Step B — physically run only an approved safe target probe** with independent observation and accurate timing. Write the record `real/B/target_probe.csv`, then append that filename to `real/B/manifest.json` under `episodes.train`. Set a separate future, unexecuted action plan containing exactly `fixture_id,dt_s,x0_m,v0_m_s,controls_m_s2`. **Do not record the future test yet.**

```powershell
python -m physica.frontier.feeling_discovery_loop_v027 commit `
  --loop-dir real/investigation `
  --target-manifest real/B/manifest.json `
  --probe-csv real/B/target_probe.csv `
  --future-plan real/future_target_plan.json `
  --out real/investigation/04_TARGET_FORECAST_COMMIT.json
```

Save an independent timestamp for the committed forecast using an external witness or append-only service. Local JSON hashes alone cannot prove chronological order to a skeptical reviewer.

**Step C — execute the future test safely only after the sealed forecast exists**, and record its actual output as `real/B/future_test.csv`. The system verifies the planned initial state, action schedule and timestamps:

```powershell
python -m physica.frontier.feeling_discovery_loop_v027 reveal `
  --commit real/investigation/04_TARGET_FORECAST_COMMIT.json `
  --measurements real/B/future_test.csv `
  --out real/investigation/06_FUTURE_REVEAL.json
```

**Step D — convert the observed response into a learning opportunity for the *next* trial:**

```powershell
python -m physica.frontier.feeling_discovery_loop_v027 learn `
  --reveal real/investigation/06_FUTURE_REVEAL.json `
  --target-manifest real/B/manifest.json `
  --measurements real/B/future_test.csv `
  --forecast-commit real/investigation/04_TARGET_FORECAST_COMMIT.json `
  --out real/investigation
```

This creates `manifest_after_experience.json` within machine B's evidence directory. Future forecasts fitted against this updated manifest may now learn from the previously scored test, but they must be evaluated on a **new** unseen experiment. A review-only transferable lesson is recorded in `05_EXPERIENCE_MEMORY.json`.

## Scientific evaluation to claim a real advance

An algorithmic-breakthrough claim requires independent real experiments, generalization to unseen physical systems, matched-budget comparisons against source-blind symbolic discovery, nonlinear system identification and neural dynamics, reliable calibrated uncertainty, evidence of genuine Meta discovery advantage, and failure reporting. The current full-loop simulator by itself meets **none** of those conditions.

## Known limitations

- Only a declared 1D controlled mechanical sensor model is implemented in this particular field loop; other Physica applications remain separate adapters.
- No physical actuation, Meta glasses sensor streaming, or third-party laboratory access.
- No authenticated Meta execution was possible without the user's private key. Offline source hypotheses are human authored.
- Curiosity starts from a thresholded prospective-looking *one-step* sensor innovation using contemporaneously measured x,v,u; only the later B experiment is a fully sealed, action-conditioned future trajectory.
- The source neural teacher is trained on earlier SOURCE TRAIN episodes; this does not constitute universal multisensory self-supervised representation learning.
- The selected probe maximizes bounded disagreement under support penalties; it is not shown to beat optimal design or random probing on real equipment.
- Sensor sigma is a declaration. The library checks form, not whether the calibration procedure actually occurred.
- A post-reveal experience can help or hurt on a subsequent test; no improvement is guaranteed.

Tests: `python -m pytest -q tests/test_feeling_discovery_loop_v027.py tests/test_meta_council_v026.py tests/test_discovery_milestone_v025.py`.
