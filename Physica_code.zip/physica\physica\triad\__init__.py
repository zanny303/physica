"""Physica three-experience interfaces: Lab, Discover, Lens."""
