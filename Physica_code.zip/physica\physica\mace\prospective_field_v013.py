"""Separate-run, signed, prospective real-observation protocol.

The prepare command MUST NOT receive future measured data. Reveal requires
signed forecast, verified raw observation bytes and independently supplied
correct timestamps/sampling. Signatures alone do not establish chronology.
"""
from __future__ import annotations
import argparse,csv,hashlib,io,json,math
from pathlib import Path
import numpy as np
from physica.library.sign import sign,verify
from .agentic_v013 import _write
from .mechanisms import validate_term,feature
from .simulation import forecast_without_truth


def prepare(payload):
    if not isinstance(payload,dict) or set(payload)!={'target_id','sensor','model','initial','planned','evidence_sha256','calibration'}:
        raise ValueError('unsupported prepare shape: no future outcomes accepted')
    if payload['sensor'] not in ('camera_m','audio_m_per_s'):raise ValueError('unknown calibrated sensor')
    if payload['calibration'].get('verified') is not True:
        raise ValueError('external independent sensor calibration required')
    if not isinstance(payload['evidence_sha256'],str) or len(payload['evidence_sha256'])!=64:
        raise ValueError('expected signed source-and-target probe evidence hash')
    model=payload['model']
    if set(model)!= {'terms','coefficients'} or len(model['terms'])!=len(model['coefficients']):
        raise ValueError('only a fixed, externally reviewed numerical model accepted')
    for t in model['terms']:validate_term(t)
    if len(model['terms'])>12:raise ValueError('too many terms')
    if not all(type(w) in (float,int) and math.isfinite(w) and abs(w)<100 for w in model['coefficients']):
        raise ValueError('invalid fitted coefficients')
    planned=payload['planned']
    if not isinstance(planned,dict) or set(planned)!= {'dt','u','temperature_delta'}:
        raise ValueError('planned actions and measured context required')
    if not isinstance(planned['u'],list) or not 8<=len(planned['u'])<=600 or len(planned['u'])!=len(planned['temperature_delta']):
        raise ValueError('bounded action plan length required')
    if any(not isinstance(x,(float,int)) or isinstance(x,bool) or not math.isfinite(x) or abs(x)>10 for x in planned['u']):
        raise ValueError('unapproved or extreme action plan')
    forecast=forecast_without_truth(model,payload['initial'],planned)
    sealed={'schema':'physica.mace.field.v013','origin':'USER_SUPPLIED_REAL_CLAIM_NOT_INDEPENDENTLY_CERTIFIED',
            'target_id':payload['target_id'],'sensor':payload['sensor'],
            'evidence_sha256':payload['evidence_sha256'],'calibration':payload['calibration'],
            'initial':payload['initial'],'planned':planned,'model':model,
            'forecast':forecast,'NO_FUTURE_MEASUREMENT_WAS_PROVIDED':True}
    return {'payload':sealed,'signature':sign(sealed)}


def reveal(signed,raw_bytes):
    if not isinstance(signed,dict) or set(signed)!= {'payload','signature'}:
        raise ValueError('invalid signed forecast receipt')
    if not verify(signed['payload'],signed['signature']):raise ValueError('signed forecast was changed')
    committed=signed['payload']; reader=csv.DictReader(io.StringIO(raw_bytes.decode('utf-8-sig')))
    if not reader.fieldnames or not {'t',committed['sensor']}.issubset(reader.fieldnames):
        raise ValueError('raw CSV must include time and calibrated sensor readings')
    values=[];times=[]
    for row in reader:
        values.append(float(row[committed['sensor']]));times.append(float(row['t']))
    predicted=committed['forecast']
    if len(values)!=len(predicted):raise ValueError('observed sequence length differs from signed forecast')
    if not all(math.isfinite(v) for v in values+times) or any(b<=a for a,b in zip(times,times[1:])):
        raise ValueError('invalid measured timestamps or values')
    dt=float(committed['planned']['dt'])
    if any(abs(times[i]-(i+1)*dt)>max(.005,dt*.1) for i in range(len(times))):
        raise ValueError('raw measurements not aligned with signed prediction timestamps')
    predicted_values=[float(r[committed['sensor']]) for r in predicted]
    residual=np.array(values)-np.array(predicted_values)
    return {'schema':'physica.mace.field_reveal.v013','status':'MEASUREMENT_SCORED_AGAINST_SIGNED_FORECAST',
            'sensor':committed['sensor'],'rmse':float(np.sqrt(np.mean(residual**2))),
            'mae':float(np.mean(np.abs(residual))),
            'observations_sha256':hashlib.sha256(raw_bytes).hexdigest(),
            'forecast_signature_valid':True,'not_independently_witnessed_chronology':True,
            'caution':'source/calibration and measurement truthfulness remain externally supplied'}


def main(argv=None):
    p=argparse.ArgumentParser(description='Separate real-measurement forecast and reveal')
    subs=p.add_subparsers(dest='action',required=True)
    for verb in ('prepare','reveal'):
        x=subs.add_parser(verb);x.add_argument('--out',required=True)
        if verb=='prepare':x.add_argument('--input',required=True)
        else:x.add_argument('--sealed',required=True);x.add_argument('--observations',required=True)
    x=p.parse_args(argv)
    if x.action=='prepare':
        raw=json.loads(Path(x.input).read_text(encoding='utf-8'))
        report=prepare(raw)
    else:
        report=reveal(json.loads(Path(x.sealed).read_text(encoding='utf-8')),Path(x.observations).read_bytes())
    out=Path(x.out);_write(out.parent,out.name,report)
    print(json.dumps({'out':str(out),'status':x.action,'sensor':report.get('sensor',report.get('payload',{}).get('sensor'))}))
if __name__=='__main__':main()
