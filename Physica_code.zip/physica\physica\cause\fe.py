"""A beam Physica can reason with: Euler-Bernoulli finite elements, clamped at x=0, with whatever the world adds to it.

Everything is dimensionless (EI = rho*A = L = 1); `Beam` converts to Hz and millimetres from a ruler-and-calipers
description. The world can add:
  - point masses (a coin, a sensor, a tool),             -> frequencies can only go DOWN  (Rayleigh)
  - local stiffness loss (a crack, a loose joint),       -> frequencies can only go DOWN
  - translational springs / supports (a finger, a roller, a shelf bracket) -> frequencies can only go UP
These one-way rules are what let Physica rule causes out before it fits anything.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.linalg import eigh

STEEL = {"E": 209.5e9, "rho": 7900.0}
ALUMINIUM = {"E": 69e9, "rho": 2700.0}
WOOD_RULER = {"E": 11e9, "rho": 700.0}
PLASTIC_RULER = {"E": 3.0e9, "rho": 1190.0}  # acrylic; real rulers vary, so calibrate with the bare tone
MATERIALS = {"steel": STEEL, "aluminium": ALUMINIUM, "aluminum": ALUMINIUM, "wood": WOOD_RULER, "plastic": PLASTIC_RULER}


def _element(le: float):
    k = np.array([[12, 6 * le, -12, 6 * le], [6 * le, 4 * le ** 2, -6 * le, 2 * le ** 2],
                  [-12, -6 * le, 12, -6 * le], [6 * le, 2 * le ** 2, -6 * le, 4 * le ** 2]]) / le ** 3
    m = np.array([[156, 22 * le, 54, -13 * le], [22 * le, 4 * le ** 2, 13 * le, -3 * le ** 2],
                  [54, 13 * le, 156, -22 * le], [-13 * le, -3 * le ** 2, -22 * le, 4 * le ** 2]]) * le / 420
    return k, m


def _shape(x: float, n_el: int):
    le = 1.0 / n_el
    e = min(max(int(x / le), 0), n_el - 1)
    s = (x - e * le) / le
    return e, np.array([1 - 3 * s ** 2 + 2 * s ** 3, le * (s - 2 * s ** 2 + s ** 3), 3 * s ** 2 - 2 * s ** 3,
                        le * (-s ** 2 + s ** 3)])


def eig(n_el: int = 60, n: int = 3, tip_mass: float = 0.0, masses=(), springs=(), ei=None, shapes: bool = False,
        clamp_rot: float | None = None):
    """Dimensionless angular eigenvalues sqrt(lambda) (and optionally node displacements) of a clamped beam.
    masses: [(x, mass / beam mass)], springs: [(x, k L^3 / EI)], ei: per-element EI multipliers,
    clamp_rot: rotational stiffness of the clamp (k_rot L / EI); None = perfectly rigid clamp."""
    le = 1.0 / n_el
    k, m = _element(le)
    N = 2 * (n_el + 1)
    K, M = np.zeros((N, N)), np.zeros((N, N))
    for e in range(n_el):
        i = 2 * e
        K[i:i + 4, i:i + 4] += k * (1.0 if ei is None else ei[e])
        M[i:i + 4, i:i + 4] += m
    for x, mu in list(masses) + ([(1.0, tip_mass)] if tip_mass else []):
        e, Nf = _shape(x, n_el)
        M[2 * e:2 * e + 4, 2 * e:2 * e + 4] += mu * np.outer(Nf, Nf)
    for x, kap in springs:
        e, Nf = _shape(x, n_el)
        K[2 * e:2 * e + 4, 2 * e:2 * e + 4] += kap * np.outer(Nf, Nf)
    first = 2
    if clamp_rot is not None:  # a clamp that lets the root rotate a little, resisted by a spring
        K[1, 1] += clamp_rot
        first = 1
    if shapes:
        w2, V = eigh(K[first:, first:], M[first:, first:], subset_by_index=[0, n - 1])
        V = V if first == 2 else V[1:]
        return np.sqrt(np.maximum(w2, 0)), np.vstack([np.zeros((1, n)), V[0::2]])
    w2 = eigh(K[first:, first:], M[first:, first:], eigvals_only=True, subset_by_index=[0, n - 1])
    return np.sqrt(np.maximum(w2, 0))


@dataclass
class Beam:
    """A clamped beam described the way a person would measure it: free length, width, thickness (metres),
    material, and any sensor stuck on the tip (kg)."""
    length: float
    width: float
    thickness: float
    material: str = "steel"
    tip_mass_kg: float = 0.0
    E: float | None = None
    rho: float | None = None
    name: str = "beam"
    n_el: int = 60
    _cache: dict = field(default_factory=dict, repr=False)

    def __post_init__(self):
        mat = MATERIALS.get(self.material, STEEL)
        self.E = self.E or mat["E"]
        self.rho = self.rho or mat["rho"]

    @property
    def mass_kg(self) -> float:
        return self.rho * self.width * self.thickness * self.length

    @property
    def hz_per_unit(self) -> float:
        EI = self.E * self.width * self.thickness ** 3 / 12
        rA = self.rho * self.width * self.thickness
        return float(np.sqrt(EI / (rA * self.length ** 4)) / (2 * np.pi))

    @property
    def tip_mu(self) -> float:
        return self.tip_mass_kg / self.mass_kg

    def freqs(self, n: int = 3, **world) -> np.ndarray:
        """Natural frequencies in Hz with the world's additions (positions as fractions of the length)."""
        return eig(self.n_el, n, tip_mass=self.tip_mu, **world) * self.hz_per_unit

    def bare(self, n: int = 3) -> np.ndarray:
        return self.freqs(n)

    def calibrated(self, bare_hz: float) -> "Beam":
        """The same beam with its stiffness set so its bare first tone matches a measured one (e.g. a flick of the
        intact ruler). Removes the guess about the material."""
        f = self.bare(1)[0]
        return Beam(self.length, self.width, self.thickness, self.material, self.tip_mass_kg,
                    E=self.E * (bare_hz / f) ** 2, rho=self.rho, name=self.name + " (calibrated)", n_el=self.n_el)

    def describe(self) -> dict:
        return {"name": self.name, "length_mm": self.length * 1e3, "width_mm": self.width * 1e3,
                "thickness_mm": self.thickness * 1e3, "material": self.material, "tip_mass_g": self.tip_mass_kg * 1e3,
                "bare_hz": [round(float(f), 2) for f in self.bare(3)]}
