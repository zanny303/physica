"""E4: compounding. Does knowledge from relatives let a NEW rotor learn 'healthy' from less data?

Leave-one-rotor-out on PADRE. For the target rotor, three learners see only `b` windows of its healthy flight:
  cold    - learns its self-model from scratch
  library - starts from the other rotors' curve shape (prior) and gives way to its own evidence
  fixed   - takes the other rotors' curve shape as fixed truth, learns only the level (what NOT to do)
Measured on held-out healthy windows (false alarms) and its own damage flights (detection).
"""
from __future__ import annotations

import numpy as np

from common import SEED, SINGLE, healthy_split, padre_features, save_result
from physica.feel.selfmodel import OperatingPointSelfModel
from physica.library.prior import relatives_prior

Z_THR = 4.0  # fixed threshold for every learner and budget (no per-budget tuning)
BUDGETS = [1, 2, 3, 4, 6, 8, 12, 17]  # windows of 5 s
REPS = 40


def fixed_truth(op, lvl, prior):
    m = OperatingPointSelfModel(unit_names=["new"]).fit(op, lvl, prior=prior, lam=1e6)
    return m


def main():
    split = healthy_split()
    h = padre_features("0000")
    cal, ho = np.array(split["calib"]), np.array(split["heldout"])
    rng = np.random.default_rng(SEED)
    out = {"z_threshold": Z_THR, "budgets_s": [b * 5 for b in BUDGETS], "reps": REPS, "targets": {}}
    for ti, tgt in enumerate("ABCD"):
        others = [k for k in range(4) if k != ti]
        rel = OperatingPointSelfModel(unit_names=[ "ABCD"[k] for k in others]).fit(h["op"][cal][:, others], h["lvl"][cal][:, others])
        prior = relatives_prior([rel])
        dmg = [padre_features(c) for c in SINGLE[tgt]]
        res = {k: {"false_alarm": [], "detect": []} for k in ("cold", "library", "fixed_truth")}
        for b in BUDGETS:
            acc = {k: ([], []) for k in res}
            for _ in range(REPS):
                idx = rng.choice(cal, size=b, replace=False)
                op, lvl = h["op"][idx, ti:ti + 1], h["lvl"][idx, ti:ti + 1]
                models = {
                    "cold": OperatingPointSelfModel(unit_names=["new"]).fit(op, lvl,
                             center=prior.x_center, scale=prior.x_scale) if b > 0 else None,
                    "library": OperatingPointSelfModel(unit_names=["new"]).fit(op, lvl, prior=prior, lam=4.0),
                    "fixed_truth": fixed_truth(op, lvl, prior),
                }
                for k, m in models.items():
                    fa = np.mean(m.z(h["op"][ho, ti:ti + 1], h["lvl"][ho, ti:ti + 1])[:, 0] > Z_THR)
                    det = np.mean(np.concatenate([m.z(d["op"][:, ti:ti + 1], d["lvl"][:, ti:ti + 1])[:, 0] > Z_THR for d in dmg]))
                    acc[k][0].append(fa); acc[k][1].append(det)
            for k in res:
                res[k]["false_alarm"].append(float(np.mean(acc[k][0])))
                res[k]["detect"].append(float(np.mean(acc[k][1])))
        def first_quiet(fa, level=0.05):
            """Smallest budget from which the false-alarm rate STAYS at or below the level."""
            for i, b in enumerate(BUDGETS):
                if all(v <= level for v in fa[i:]):
                    return b * 5
            return None
        for k in res:
            q = first_quiet(res[k]["false_alarm"])
            res[k]["seconds_to_5pct_false_alarm"] = q
            res[k]["detect_at_that_point"] = res[k]["detect"][BUDGETS.index(q // 5)] if q else None
        out["targets"][tgt] = res
        print(tgt, {k: res[k]["seconds_to_5pct_false_alarm"] for k in res},
              "| detect at 85 s:", {k: round(res[k]["detect"][-1], 2) for k in res})
    save_result("E4_compounding", out)


if __name__ == "__main__":
    main()
