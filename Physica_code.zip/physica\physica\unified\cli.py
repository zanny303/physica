"""Universal review-only evidence inquiry interface for supported Physica domains."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from .adapters import from_printer,from_turbine,from_f1,sha256_file
from .engine import investigate
from .meta import run_domain_research_council
from .field import from_field_manifest
from .uncertainty_v029 import load_envelopes


def main(argv=None):
    p=argparse.ArgumentParser(description='Physica 0.28 shared physical inquiry, no actuation')
    p.add_argument('--domain',choices=['printer','turbine','f1'],help='Required for domain summary JSON; field manifest supplies its own domain')
    p.add_argument('--field-manifest',action='store_true',help='Interpret --input as an evidence-backed CSV field manifest')
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--after',type=Path,help='Printer after-video result JSON, if available')
    p.add_argument('--car-id',default=None)
    p.add_argument('--system-id',default=None)
    p.add_argument('--raw-recording',type=Path,help='A file used for physical observations: hashed, not uploaded')
    p.add_argument('--calibration-ref',default=None)
    p.add_argument('--split',choices=['train','validation','test','mixed','unknown'],default='unknown')
    p.add_argument('--simulated',action='store_true')
    p.add_argument('--live-meta',action='store_true')
    p.add_argument('--allow-billed-meta',action='store_true')
    p.add_argument('--candidate-probes',type=Path,help='Optional calibrated rival forecasts for candidate tests')
    p.add_argument('--normal-envelope',type=Path,help='Optional held-out normal residual calibration JSON (v0.29)')
    p.add_argument('--operating-context',type=Path,help='Optional measured operating context JSON (v0.29)')
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args(argv)
    try:
        if a.field_manifest:
            felt=from_field_manifest(a.input)
            if a.domain and a.domain!=felt.domain:raise ValueError('Domain differs from field manifest')
        else:
            if not a.domain:raise ValueError('Specify --domain or --field-manifest')
            data=json.loads(a.input.read_text(encoding='utf8'))
            if not isinstance(data,dict):raise ValueError('Expected a JSON report object')
            raw=sha256_file(a.raw_recording) if a.raw_recording else None
            kw=dict(source_ref=str(a.input),raw_sha256=raw,
                    calibration_ref=a.calibration_ref,simulated=a.simulated,evidence_split=a.split)
            if a.domain=='printer':
                after=json.loads(a.after.read_text(encoding='utf8')) if a.after else None
                felt=from_printer(data,after=after,system_id=a.system_id or 'printer',**kw)
            elif a.domain=='turbine':
                felt=from_turbine(data,system_id=a.system_id or 'turbine',**kw)
            else:
                felt=from_f1(data,system_id=a.system_id or 'f1',car_id=a.car_id,**kw)
        probes=json.loads(a.candidate_probes.read_text()) if a.candidate_probes else None
        envelopes=load_envelopes(json.loads(a.normal_envelope.read_text())) if a.normal_envelope else None
        context=json.loads(a.operating_context.read_text()) if a.operating_context else None
        if context is not None and not isinstance(context,dict): raise ValueError('Operating context must be a JSON object')
        result=investigate(felt,candidate_probes=probes,normal_envelopes=envelopes,operating_context=context)
        if a.live_meta:
            # training-only context is enforced even before incurring any Meta cost
            if felt.evidence_split!='train':raise ValueError('Live discovery requires explicit training-only evidence')
            meta=run_domain_research_council(felt,allow_billed_meta=a.allow_billed_meta)
            result['meta_provenance']=meta['status']
            result['meta_scientific_review']=meta
            if meta['status']=='META_COUNCIL_PROPOSALS_UNVERIFIED':
                result['candidate_mechanisms']=[{'name':h['name'],'claim':h['claim'],
                    'status':'META_PROPOSED_NOT_VALIDATED'} for h in meta['revised']['hypotheses']]
        a.out.parent.mkdir(parents=True,exist_ok=True)
        a.out.write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf8')
        print(json.dumps({'output':str(a.out),'status':result['evidence_status'],
                          'meta':result['meta_provenance']},indent=2))
        return 0
    except (ValueError,TypeError,KeyError,FileNotFoundError,json.JSONDecodeError) as exc:
        # No automatic machine actions ever occur. User error gives a clean CLI refusal.
        print(json.dumps({'status':'ABSTAIN_INVALID_EVIDENCE',
                          'error_type':type(exc).__name__,
                          'instruction':'Check domain, input JSON, calibration provenance and split'}))
        return 2

if __name__=='__main__':raise SystemExit(main())
