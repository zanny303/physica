"""E28 step 1: build the case file for the Muse with-and-without-senses test (REAL DATA, derived numbers only).

Uses exactly the E20 protocol: everything is learned from session 1, every scored group comes from session 2.
For each group it stores what a model could be shown:
  raw_tones_hz  the blade's seven peak frequencies and the chamber temperature (no interpretation)
  felt          what Physica's sense computes from those tones (weather removed, change score, mode pattern, mass)
The verdict and the truth are stored for scoring only. Prompts never include the truth or the blade's case letter, and
the ids are shuffled so an id says nothing about the case.

  PHYSICA_BLADE_PSD=<folder of .npz> python eval/e28_blade_cases.py
Data: ETH Zurich small-scale blade benchmark (Ou et al. 2021, doi:10.1002/stc.2660; PSD extract via EOVmitigation).
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "eval"))
from physica.data import blade_eth as B  # noqa: E402
from e20_wind_blade import groups, run  # noqa: E402

OUT = ROOT / "eval" / "results" / "E28_blade_cases.json"


def mean_tones(bs, group):
    return np.nanmean([bs.tones(p, t) for p, t in group], 0)


def by_temperature(bs, tests):
    table = defaultdict(list)
    for (_, temp), g in groups(tests):
        table[temp].append(mean_tones(bs, g))
    return {str(t): np.nanmean(v, 0).round(2).tolist() for t, v in sorted(table.items())}


def main():
    tests = B.load()
    bs, rows = run(tests)
    s1 = [t for t in tests if t.session == 1]
    s2 = [t for t in tests if t.session == 2]
    fp = bs.mass_fingerprint
    judged = {}
    for r in rows:
        judged.setdefault((r["case"], r["temp_c"]), []).append(r)
    built = []
    for (c, temp), g in groups(s2):
        r = judged[(c, temp)].pop(0)
        grams = float(r["residual_pct"][0] / 100 / fp[0]) if "residual_pct" in r and fp[0] < 0 else None
        built.append({
            "temp_c": float(temp), "n_tests": len(g), "raw_tones_hz": mean_tones(bs, g).round(2).tolist(),
            "felt": {k: r.get(k) for k in ("residual_pct", "z", "change_score", "change_threshold", "slow_mode_lead")}
            | {"mass_equivalent_g": None if grams is None or grams <= 0 else round(grams, 1)},
            "physica_verdict": r["verdict"], "truth": r["truth"], "truth_case": c, "truth_size": r["size"]})
    order = np.random.default_rng(2028).permutation(len(built))
    cases = [dict(id=f"blade_group_{i + 1:03d}", **built[k]) for i, k in enumerate(order)]
    healthy = [t for t in s1 if t.case == "R"]
    mass = [t for t in s1 if t.case == "A"]
    out = {"LABEL": "REAL DATA (derived): ETH Zurich blade, session 2 groups, learned from session 1 only",
           "source": "Ou et al. 2021, doi:10.1002/stc.2660; PSD extract via github.com/josepfontm/EOVmitigation",
           "licence_note": "Article CC BY-NC 4.0; check the data licence before commercial use",
           "mode_order": ["mode 2 (slow swinging)", "mode 3", "mode 4", "mode 5", "mode 6", "mode 7", "mode 8"],
           "reference": {"healthy_tones_by_temp_c": by_temperature(bs, healthy),
                         "with_44g_mass_tones_by_temp_c": by_temperature(bs, mass),
                         "note": "Session 1 averages: the same raw material Physica learned from."},
           "sense_rules": {"change_threshold_meaning": "chi-square limit (alpha 0.001) on the weather-free change",
                           "slow_mode_lead_44g_mass": round(float(bs.mass_lead), 2)},
           "cases": cases}
    OUT.write_text(json.dumps(out, indent=1))
    print(f"{len(cases)} cases -> {OUT}")


if __name__ == "__main__":
    main()
