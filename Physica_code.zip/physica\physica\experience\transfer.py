"""Machine A -> Body Bank -> Machine B: comparability before knowledge transfer.

Transfer only calibrated/action-compatible episodes with matching excitation units;
non-identical modal scales are aligned by within-body ratios, not raw frequencies.
A matched episode supplies a *prior* for B, never a causal finding by itself.
"""
from __future__ import annotations

from .schema import PhysicalEpisode
from .pacer import normalize
from typing import Iterable
import math
import numpy as np


def physical_words(ep: PhysicalEpisode) -> dict:
    modes=sorted(ep.modal_words,key=lambda m:m.frequency.value)
    if not modes: return {"frequency_ratios":[],"damping":[],"excitation":None}
    base=modes[0].frequency.value
    return {"frequency_ratios":[m.frequency.value/base for m in modes],
            "damping":[m.damping_ratio.value for m in modes],
            "excitation":modes[0].excitation_level.model_dump(mode="json") if modes[0].excitation_level else None}


def compare(a: PhysicalEpisode, b: PhysicalEpisode, *, max_excitation_ratio: float = 4.0,
            max_modal_log_error: float = .15) -> dict:
    """Return comparable/refused and a dimensionless domain-shift score.

    Calibration status and excitation matching are part of the model, not optional
    scoring metadata. Unknowns are refused, allowing later targeted calibration.
    """
    reasons=[]
    if a.body_class!=b.body_class or "unknown" in (a.body_class,b.body_class):
        reasons.append("body_class_mismatch_or_unknown")
    if a.boundary_class!=b.boundary_class or "unknown" in (a.boundary_class,b.boundary_class):
        reasons.append("boundary_class_mismatch_or_unknown")
    if a.action.action_type!=b.action.action_type:
        reasons.append("intervention_family_mismatch")
    if not (a.sensors and b.sensors and all(s.calibrated for s in a.sensors+b.sensors)):
        reasons.append("uncalibrated_sensor")
    if not (a.modal_words and b.modal_words):
        reasons.append("no_modal_words")
    aw,bw=physical_words(a),physical_words(b)
    x,y=aw["excitation"],bw["excitation"]
    if x is None or y is None or x["value"]<=0 or y["value"]<=0 or x["unit"]!=y["unit"]:
        reasons.append("excitation_missing_or_incompatible")
    elif max(x["value"]/y["value"],y["value"]/x["value"])>max_excitation_ratio:
        reasons.append("excitation_out_of_range")
    if len(aw["frequency_ratios"])!=len(bw["frequency_ratios"]):
        reasons.append("mode_count_mismatch")
    if reasons:
        return {"status":"refused","reasons":reasons,"similarity":None,"transferable":False}
    rat_a=np.asarray(aw["frequency_ratios"])
    rat_b=np.asarray(bw["frequency_ratios"])
    # first mode ratio is always 1; other modes distinguish family shapes
    error=float(np.sqrt(np.mean(np.log(rat_a/rat_b)**2)))
    zeta_error=float(np.mean(np.abs(np.asarray(aw["damping"])-np.asarray(bw["damping"]))))
    if error>max_modal_log_error:
        return {"status":"refused","reasons":["modal_signature_shift"],"modal_log_error":error,
                "similarity":None,"transferable":False}
    base_a=min(m.frequency.value for m in a.modal_words)
    base_b=min(m.frequency.value for m in b.modal_words)
    similarity=math.exp(-3*error-10*zeta_error)
    return {"status":"comparable","reasons":[],"similarity":float(similarity),"transferable":True,
            "modal_log_error":error,"frequency_scale":base_b/base_a,"damping_difference":zeta_error,
            "note":"prior only: verify on B with a safe intervention"}


def transfer_prior(source: PhysicalEpisode, target: PhysicalEpisode, *, baseline: dict[str,float] | None=None,
                   strength: float=0.65) -> dict:
    """Geometrically mix source evidence into B's prior; no claim of zero-shot verification."""
    verdict=compare(source,target)
    if not verdict["transferable"]:
        return {"status":"refused","comparison":verdict,"prior":None}
    if source.consequence.outcome!="verified":
        return {"status":"refused","comparison":verdict,"prior":None,
                "reason":"source_consequence_not_verified"}
    source_p={h.hypothesis_id:h.posterior for h in source.hypotheses}
    if not source_p:
        return {"status":"refused","comparison":verdict,"prior":None,"reason":"no_source_posterior"}
    base=normalize(baseline or {k:1.0 for k in source_p})
    if set(base)!=set(source_p): raise ValueError("hypothesis label mismatch; map classes before transfer")
    alpha=min(1.0,max(0.0,strength))*verdict["similarity"]
    logp={k:(1-alpha)*math.log(max(base[k],1e-12))+alpha*math.log(max(source_p[k],1e-12)) for k in base}
    best=max(logp.values())
    p=normalize({k:math.exp(v-best) for k,v in logp.items()})
    return {"status":"prior_transferred","prior":p,"comparison":verdict,
            "strength_effective":alpha,"requires_local_verification":True}


def search_bank(target: PhysicalEpisode, candidates: Iterable[PhysicalEpisode], *, max_results:int=5) -> list[dict]:
    rows=[]
    for ep in candidates:
        q=compare(ep,target)
        if q["transferable"] and ep.consequence.outcome=="verified":
            rows.append({"source_episode_id":ep.episode_id,"comparison":q,
                         "source_hypotheses":{h.hypothesis_id:h.posterior for h in ep.hypotheses}})
    return sorted(rows,key=lambda r:r["comparison"]["similarity"],reverse=True)[:max_results]
