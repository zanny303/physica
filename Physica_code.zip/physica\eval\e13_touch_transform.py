"""E13 - The Touch Transform: feel what an object is and what touched it, imagine consequences, act in machine code.

  A. Real beam (ARTS-Lab cantilever, one accelerometer at the tip, 25.6 kHz; CC BY-SA 4.0). Set PHYSICA_BEAM_FILE.
     Feel touches vs. body changes; feel where the lost mass was; imagine the ringing a touch causes; act.
  B. Simulated video (LABELLED SIMULATION): a clamped bar tapped at random known places; can it feel where?
  C. Real video (MIT guitar clip, 600 fps capture per the paper; 300 frames). Set PHYSICA_GUITAR_VIDEO.
     Pitches from pixels, which string is which, interval between strings, frequency precision vs the FFT.
Settings for A were chosen on this recording, then frozen; B and C use them unchanged except the sample rate.
"""
from __future__ import annotations

import base64
import datetime as dt
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
from scipy.signal import decimate

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica.act import contract  # noqa: E402
from physica.touch import act, beam, video  # noqa: E402
from physica.touch.transform import TouchTransform, feel_stream, same_body  # noqa: E402
from physica.translate import ardupilot, gcode  # noqa: E402

OUT = ROOT / "eval" / "results"
BEAM_MM, MASS_MM = 757.0, 268.0
NOTES = {"E2": 82.41, "A2": 110.0, "D3": 146.83, "G3": 196.0}


def cents(a, b):
    return float(1200 * np.log2(a / b))


def load_beam():
    D = np.loadtxt(os.environ["PHYSICA_BEAM_FILE"], skiprows=23)
    x = D[:, 1] - np.median(D[:, 1])
    fs = 1 / np.median(np.diff(D[:, 0]))
    return decimate(decimate(x, 8), 5), fs / 40


def body(x, fs, a, b, n=3):
    i = slice(int(a * fs), int(b * fs))
    return TouchTransform(fs, n_modes=n, band=(3, 250), delays=200, order=40, measure="acceleration", merge=0.06).fit(x[i])


def part_a():
    x, fs = load_beam()
    out = {"fs_hz": fs}
    b_on, b_off = body(x, fs, 11.2, 20.5), body(x, fs, 24.3, 30.0)
    out["felt_body_with_mass"] = [{"freq_hz": m.freq_hz, "damping": m.damping} for m in b_on.modes]
    out["felt_body_after"] = [{"freq_hz": m.freq_hz, "damping": m.damping} for m in b_off.modes]
    ideal = beam.cantilever_freqs()
    f_off = [m.freq_hz for m in b_off.modes]
    out["physics_check"] = {"felt_ratios": [f / f_off[0] for f in f_off], "uniform_beam_ratios": (ideal / ideal[0]).tolist(),
                            "fit_with_sensor_tip_mass": beam.fit_body(f_off)}
    # 1. touch or body change?
    t0 = time.time()
    ev = feel_stream(x, b_on)
    out["feel_stream"] = {"events": [{k: v for k, v in e.items() if k != "shifts"} for e in ev], "seconds": time.time() - t0,
                          "truth": "taps at ~10.99 s and ~23.92 s; mass released at ~21.62 s (visible in the raw signal)"}
    # 2. where was the mass? Which felt mode before is which after: adding a point mass lowers every mode but each
    #    stays above the next-lower mode of the plain beam (eigenvalue interlacing), so mode k with the mass is the
    #    strongest felt mode between plain-beam modes k-1 and k.
    on_b = body(x, fs, 11.2, 20.5, n=8).modes
    edges = [0.0] + f_off
    bend_on = [max([m for m in on_b if edges[k] < m.freq_hz < edges[k + 1]], key=lambda m: m.energy).freq_hz
               for k in range(len(f_off))]
    resid = np.sqrt(np.mean(np.square(beam.fit_body(f_off)["residual_pct"]))) / 100
    loc = beam.feel_mass_change(bend_on, f_off)
    out["where_was_the_mass"] = {"felt_mm": loc["position"] * BEAM_MM,
                                 "felt_90_mm": [v * BEAM_MM for v in loc["position_90"]],
                                 "photo_mm": MASS_MM, "error_mm": loc["position"] * BEAM_MM - MASS_MM,
                                 "mass_vs_beam": loc["mass_fraction"], "fit_error_pct": loc["fit_error_pct"],
                                 "model_error_used_pct": 100 * loc["rel_sd"], "bending_modes_with_mass_hz": bend_on}
    # 3. imagination: feel the push at 23.91 s from 50 ms after it, imagine the next 2 s, compare with reality
    b_late = body(x, fs, 26.0, 34.0)
    seg0 = int(23.5 * fs)
    seg = x[seg0:int(26.6 * fs)]
    res = {}
    for name, bd in (("right body (learned 26-34 s)", b_late), ("old body (with the mass)", b_on)):
        Z, E = bd.modal(seg)
        g = (np.abs(bd.touch_vectors(E)) ** 2).sum(1)
        i = int(np.argmax(g[: int(1.0 * fs)] > 50 * np.median(g[: int(0.3 * fs)])))
        p = bd.push(seg, i, pre_s=0.1, post_s=0.05, skip_s=0.01)
        a = i + int(0.06 * fs)
        b = a + int(2.0 * fs)
        y_hat = bd.free_run(p["a_post"], b - a, start=a - i)[:, 0]
        real = seg[a:b] - bd.mean[0]
        r2 = 1 - np.sum((real - y_hat) ** 2) / np.sum((real - real.mean()) ** 2)
        res[name] = {"r2_next_2s": float(r2), "corr": float(np.corrcoef(real, y_hat)[0, 1]),
                     "amplitude_ratio": float(y_hat.std() / real.std()), "touch_at_s": (seg0 + i) / fs,
                     "felt_from_s": 0.06, "imagined_s": 2.0}
        if name.startswith("right"):
            np.save(OUT / "touch_beam_predict.npy", np.stack([np.arange(a, b) / fs + seg0 / fs, real, y_hat]))
            imag = (p, i, bd)
    out["imagine_the_consequence"] = res
    # 4. act: move it without ringing (any machine carrying it), and stop it ringing (a robot's counter-tap)
    m12 = [{"freq_hz": m.freq_hz, "damping": m.damping} for m in b_off.modes[:2]]
    sm = act.shape_motion(m12)
    m593 = gcode.marlin_m593(m12[0]["freq_hz"], m12[0]["damping"], axes="X")
    klip = gcode.klipper_input_shaper(m12[0]["freq_hz"], m12[0]["freq_hz"], shaper="zv")
    notch = ardupilot.notch_params(m12[1]["freq_hz"], m12[1]["freq_hz"] / 2)
    sm["promise"] = contract.promise("input shaping from the felt body",
                                     f"A fast move shaped this way leaves {100 * sm['felt_ringing_left']:.1f}% of the ringing an "
                                     f"unshaped move leaves (imagined through the felt modes), for {1000 * sm['added_delay_s']:.0f} ms of delay.",
                                     [{"metric": "ringing_left", "op": "<=", "value": 0.2, "say": "<= 20% of unshaped ringing"}])
    out["act_move_without_ringing"] = {**sm, "marlin": m593, "klipper": klip, "ardupilot_notch_for_mode2": notch}
    p, i, bd = imag
    now = int(0.1 * bd.fs)  # the robot decides 0.1 s after the touch
    xi, S, _ = beam.mode_shapes(n=3, tip_mass=beam.fit_body(f_off)["tip_mass"])
    zc = p["a_post"] * bd.lam[bd.sel] ** now
    sk = bd.s[bd.sel]
    q0 = zc / sk ** 2 / S[:, -1]  # tip acceleration -> displacement modal coordinates (unit-RMS FE shapes)
    order = np.argsort([m.freq_hz for m in bd.modes])
    ct = act.counter_tap([bd.modes[k].freq_hz for k in order], [bd.modes[k].damping for k in order], S, q0[order])
    ct["where_mm"] = float(xi[ct["point"]] * BEAM_MM)
    out["act_stop_the_ringing"] = {**{k: v for k, v in ct.items() if k != "point"},
                                   "robot_action": {"action": "tap", "where_mm_from_clamp": round(ct["where_mm"]),
                                                    "when_s_from_now": round(ct["wait_s"], 3),
                                                    "impulse_relative": round(ct["impulse_per_mass"], 6),
                                                    "direction": "with" if ct["impulse_per_mass"] > 0 else "against"},
                                   "promise": contract.promise("counter-tap", f"Ringing over the next 2 s drops to "
                                                               f"{100 * ct['ringing_left']:.0f}% of what it would be untouched.",
                                                               [{"metric": "ringing_left", "op": "<=", "value": round(ct["ringing_left"] + 0.1, 2),
                                                                 "say": "ringing drops as imagined (+10% margin)"}])}
    # 5. words: one machine telling another what it felt
    w_on, w_a1, w_a2 = b_on.words(), body(x, fs, 24.3, 27.0).words(), body(x, fs, 27.0, 34.0).words()
    out["words"] = {"with_mass": w_on, "after_24_27s": w_a1, "after_27_34s": w_a2,
                    "same_body(with mass, after 24-27 s)": same_body(w_on, w_a1),
                    "same_body(after 24-27 s, after 27-34 s)": same_body(w_a1, w_a2),
                    "note": "settings identical for every window; the 27-34 s window rings ~5x more quietly"}
    page = {"modes_after": [{"f": m.freq_hz, "z": m.damping} for m in b_off.modes],
            "modes_with_mass": [{"f": f, "z": m.damping} for f, m in zip(bend_on, b_on.modes)],
            "x": xi.tolist(), "shapes_after": S.round(4).tolist(),
            "shapes_with_mass": beam.mode_shapes(n=3, point_masses=[(loc["position"], loc["mass_fraction"])],
                                                 tip_mass=beam.fit_body(f_off)["tip_mass"])[1].round(4).tolist(),
            "mass_x": loc["position"], "mass_photo_x": MASS_MM / BEAM_MM, "events": out["feel_stream"]["events"],
            "posterior": loc["position_posterior"], "counter_tap": out["act_stop_the_ringing"]["robot_action"]}
    return out, page


def part_b(seeds=20):
    sys.path.insert(0, str(ROOT / "tests"))
    from sim_video import render

    errs, naive, found, total, times = [], [], 0, 0, []
    for seed in range(seeds):
        V, touches, _, _ = render(seed=seed)
        mo = video.motion(V, wavelength=8, sigma=3, step=1, keep=0.25)
        Y, cols = mo["signals"], mo["cols"]
        t0 = time.time()
        tt = TouchTransform(240.0, n_modes=4, band=(1, 115), delays=60, order=24, space_rank=12, max_damping=0.05,
                            merge=0.1).fit(Y)
        an = tt.analyze(Y, threshold=6, min_gap_s=0.4)
        times.append(time.time() - t0)
        total += len(touches)
        for tr in touches:
            hit = [e for e in an["events"] if abs(e["t"] - tr["t"]) < 0.05]
            if not hit:
                continue
            found += 1
            e = hit[0]
            L = tt.localize(tt.push(Y, e["i"], pre_s=0.15, post_s=0.15, skip_s=0.01)["v"])
            sc = np.zeros(160)
            for c in np.unique(cols):
                sc[c] = L["score"][cols == c].max()
            errs.append(abs(int(np.argmax(sc)) - 10 - tr["x"]) / 140)
            mv = np.abs(Y[e["i"]:e["i"] + 24]).max(0)
            nc = np.zeros(160)
            for c in np.unique(cols):
                nc[c] = mv[cols == c].max()
            naive.append(abs(int(np.argmax(nc)) - 10 - tr["x"]) / 140)
    e, nv = np.array(errs), np.array(naive)
    rng = np.random.default_rng(0)
    boot = [np.median(rng.choice(e, len(e))) for _ in range(2000)]
    return {"LABEL": "SIMULATION: rendered video of a clamped bar; checks the method where the truth is known",
            "scenes": seeds, "touches": total, "felt": found,
            "place_error_median_pct": 100 * float(np.median(e)), "median_ci95_pct": [100 * float(np.quantile(boot, 0.025)), 100 * float(np.quantile(boot, 0.975))],
            "within_10pct": float((e < 0.1).mean()), "naive_moves_most_error_median_pct": 100 * float(np.median(nv)),
            "naive_within_10pct": float((nv < 0.1).mean()), "seconds_per_scene": float(np.mean(times))}


def part_c():
    V = video.load_gray(os.environ["PHYSICA_GUITAR_VIDEO"])
    t0 = time.time()
    mo = video.motion(V, wavelength=4, sigma=2, step=2, keep=0.3)
    Y = mo["signals"]
    cfg = dict(n_modes=3, band=(60, 295), delays=16, order=24, space_rank=6, max_damping=0.05)
    tt = TouchTransform(600.0, **cfg).fit(Y)
    secs = time.time() - t0
    halves = [TouchTransform(600.0, **cfg).fit(Y[h]) for h in (slice(0, 150), slice(150, 300))]
    modes = []
    for m in tt.modes:
        near = min(NOTES, key=lambda k: abs(cents(m.freq_hz, NOTES[k])))
        w = np.abs(m.shape)
        top = w > np.quantile(w, 0.9)
        hf = []
        for h in halves:
            q = min(h.modes, key=lambda q: abs(q.freq_hz - m.freq_hz))
            hf.append(q.freq_hz if abs(q.freq_hz - m.freq_hz) < 0.03 * m.freq_hz else None)
        modes.append({"freq_hz": m.freq_hz, "damping": m.damping, "nearest_note": near, "cents_from_note": cents(m.freq_hz, NOTES[near]),
                      "split_half_hz": hf, "where_row_px": float(np.average(mo["rows"][top], weights=w[top])),
                      "where_col_px": float(np.average(mo["cols"][top], weights=w[top]))})
    order = [m["nearest_note"] for m in sorted(modes, key=lambda m: m["where_row_px"])]
    e, a = [m["freq_hz"] for m in modes if m["nearest_note"] == "E2"], [m["freq_hz"] for m in modes if m["nearest_note"] == "A2"]
    out = {"modes": modes, "strings_top_to_bottom": order, "seconds": secs,
           "fft_bin_hz_same_clip": 600.0 / 300,
           "split_half_spread_hz": float(max(abs(m["split_half_hz"][0] - m["split_half_hz"][1]) for m in modes if None not in m["split_half_hz"])),
           "found_in_both_halves": [m["nearest_note"] for m in modes if None not in m["split_half_hz"]],
           "interval_E_to_A_cents": cents(a[0], e[0]) if e and a else None, "ideal_fourth_cents": 500.0}
    # page: frame + downsampled mode maps
    import cv2

    cap = cv2.VideoCapture(os.environ["PHYSICA_GUITAR_VIDEO"])
    ok, frame = cap.read()
    ok_, png = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
    H, W = mo["shape"]
    maps = []
    for m in tt.modes:
        img = np.zeros((H // 2, W // 2), np.float32)
        img[mo["rows"] // 2, mo["cols"] // 2] = m.shape
        img = cv2.GaussianBlur(img, (3, 3), 0)
        maps.append((img / (np.abs(img).max() + 1e-9) * 127).astype(np.int8).ravel().tolist())
    page = {"jpg": base64.b64encode(png.tobytes()).decode(), "w": W, "h": H, "map_w": W // 2, "map_h": H // 2,
            "modes": [{"f": m.freq_hz, "z": m.damping, "note": mm["nearest_note"], "cents": mm["cents_from_note"]} for m, mm in zip(tt.modes, modes)],
            "maps": maps}
    return out, page


def main():
    res, page = {}, {}
    res["A_real_beam"], page["beam"] = part_a()
    print("A done")
    if os.environ.get("E13_ONLY_A"):
        print(json.dumps({k: res["A_real_beam"][k] for k in ("felt_body_after", "where_was_the_mass", "imagine_the_consequence", "physics_check", "act_move_without_ringing", "act_stop_the_ringing", "feel_stream")}, indent=1, default=float)[:6000])
        return
    res["B_sim_video_touch_place"] = part_b()
    print("B done", res["B_sim_video_touch_place"])
    res["C_real_guitar_video"], page["guitar"] = part_c()
    print("C done")
    x = np.random.default_rng(0).standard_normal(100_000)
    tt = TouchTransform(1000.0, n_modes=3, band=(1, 400), delays=40, order=16).fit(x[:20000])
    t0 = time.time(); tt.modal(x); t_tt = time.time() - t0
    t0 = time.time(); [np.fft.rfft(x) for _ in range(10)]; t_fft = (time.time() - t0) / 10
    res["speed"] = {"touch_transform_us_per_sample": 1e6 * t_tt / len(x), "fft_us_per_sample": 1e6 * t_fft / len(x),
                    "note": "the FFT is faster per sample; the Touch Transform runs sample-by-sample (streaming, no window) "
                            "and its cost grows with modes, not with recording length"}
    res["made_at_utc"] = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    (OUT / "E13_touch_transform.json").write_text(json.dumps(res, indent=1, default=float))
    (OUT / "touch_page_data.json").write_text(json.dumps(page, default=float))
    print(json.dumps({k: v for k, v in res.items() if k != "A_real_beam"}, indent=1, default=float)[:3000])
    print(json.dumps({k: res["A_real_beam"][k] for k in ("where_was_the_mass", "imagine_the_consequence", "physics_check")}, indent=1, default=float))


if __name__ == "__main__":
    main()
