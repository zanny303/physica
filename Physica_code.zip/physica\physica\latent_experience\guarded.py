"""Out-of-sample guarded predictor: chooses learned latent or sensor ARX.

ARX is an established strong control-system baseline and is retained as a
first-class model. Chronological validation decides BEFORE final holdout.
This improves honest predictive reliability; it is NOT a novel new learner.
"""
import numpy as np
from .model import train as train_latent,forecast as forecast_latent

def fit_arx(y,actions,ridge=.005):
    Y=np.asarray(y,float);A=np.asarray(actions,float)
    if Y.ndim!=2 or Y.shape[0]<20 or Y.shape[1]<2 or A.shape!=(len(Y)-1,):
        raise ValueError('invalid observation and action dimensions')
    if not np.isfinite(Y).all() or not np.isfinite(A).all():raise ValueError('nonfinite')
    mu=Y[:-1].mean(0); sd=np.maximum(Y[:-1].std(0),1e-8)
    z=(Y-mu)/sd
    design=np.c_[z[:-1],A,np.ones(len(A))]
    regularize=np.eye(design.shape[1])*ridge;regularize[-1,-1]=0
    co=np.linalg.solve(design.T@design+regularize,design.T@z[1:])
    return {'mu':mu.tolist(),'sd':sd.tolist(),'coef':co.tolist(),'model':'action-conditioned ARX with ridge'}

def forecast_arx(model,start,actions):
    mu=np.asarray(model['mu']);sd=np.asarray(model['sd']);co=np.asarray(model['coef'])
    y=np.asarray(start,float);A=np.asarray(actions,float)
    if y.shape!=mu.shape or A.ndim!=1 or not np.isfinite(y).all() or not np.isfinite(A).all():
        raise ValueError('invalid forecast input')
    if len(A)>10000:raise ValueError('horizon too large')
    z=(y-mu)/sd; result=[]
    for a in A:
        z=np.r_[z,a,1.]@co
        out=z*sd+mu
        if not np.isfinite(out).all() or np.max(np.abs(out))>1e7:raise ValueError('unstable forecast')
        result.append(out.tolist())
    return result

def _rmse(pred,truth):return float(np.sqrt(np.mean((np.asarray(pred)-truth)**2)))

def evaluate_guarded(Y,A,rank=2,train_fraction=.55,val_fraction=.15):
    Y=np.asarray(Y,float);A=np.asarray(A,float)
    n=len(Y);i=int(n*train_fraction);j=int(n*(train_fraction+val_fraction))
    if i<30 or j-i<15 or n-j<15 or A.shape!=(n-1,):raise ValueError('not enough disjoint time blocks')
    # Never fit on validation while deciding between candidate algorithms.
    latent_selection=train_latent(Y[:i+1],A[:i],rank=rank)
    arx_selection=fit_arx(Y[:i+1],A[:i])
    val_y=Y[i+1:j+1]; val_a=A[i:j]
    val_errors={'latent':_rmse(forecast_latent(latent_selection,Y[i],val_a),val_y),
                'ARX':_rmse(forecast_arx(arx_selection,Y[i],val_a),val_y)}
    choice=min(val_errors,key=val_errors.get)
    # Refit only prefix through validation; test block remains untouched.
    latent=train_latent(Y[:j+1],A[:j],rank=rank)
    arx=fit_arx(Y[:j+1],A[:j])
    test_y=Y[j+1:];test_a=A[j:]
    raw={'latent':_rmse(forecast_latent(latent,Y[j],test_a),test_y),
         'ARX':_rmse(forecast_arx(arx,Y[j],test_a),test_y)}
    raw['guarded']=raw[choice];raw['persistence']=_rmse(np.tile(Y[j],(len(test_y),1)),test_y)
    return {'origin':'EVALUATED_SUPPLIED_OBSERVATIONS','selected':choice,'validation_rmse':val_errors,
            'test_rmse':raw,'train_rows':i+1,'validation_rows':j-i,'test_rows':len(test_y),
            'test_data_used_for_model_choice':False,'no_meta_calls':True,
            'limitations':['No proof of novel dynamics discovery','Single chronological holdout is not cross-machine generalization',
             'ARX baseline can be better than learned latent model','Real data require independently logged actions and sensor calibration']}
