"""Precompute every result the Feel Check app shows, so judges can run it with no data and no API key.

  PHYSICA_PADRE_DIR=... python -m physica.app.build_replay
"""
from __future__ import annotations

import json
import shutil

from physica import config
from physica.agents import tools as T  # noqa: F401
from physica.agents import wonder_agent as W
from physica.app.server import DEMO_SOURCES, Live, certificate
from physica.llm import meta_client


def main():
    out = config.REPLAY_DIR
    (out / "feel").mkdir(parents=True, exist_ok=True)
    (out / "ask").mkdir(parents=True, exist_ok=True)
    (out / "translate").mkdir(parents=True, exist_ok=True)
    live = Live()
    # start clean: drop certificates and action records from earlier replay builds (the core library stays)
    from physica.library import cards as C
    for c in C.all_cards():
        if set(c.get("tags", [])) & {"feel certificate", "action record"}:
            shutil.rmtree(config.CARDS_DIR / c["id"], ignore_errors=True)
    for s in DEMO_SOURCES:
        src = s["source"]
        code = src.split(":")[1]
        r = T.feel(src)
        shutil.copyfile(r.pop("feelogram_png"), out / "feel" / f"{code}.png")
        r["certificate"] = certificate(r)
        (out / "feel" / f"{code}.json").write_text(json.dumps(r, indent=1, default=str))
        (out / "ask" / f"{code}.json").write_text(json.dumps(W.ask("Is this drone safe to fly?", src), indent=1, default=str))
        for target in ("ardupilot", "marlin", "plc"):
            if target != "ardupilot" and s is not DEMO_SOURCES[0]:  # factory and printer actions don't depend on the drone
                continue
            t = live.translate(src, target)
            name = f"{code}_{target}.json" if target == "ardupilot" else f"{target}.json"
            (out / "translate" / name).write_text(json.dumps(t, indent=1, default=str))
        print("replay ready:", src, "->", r["verdict"]["text"][:80])
    (out / "discover.json").write_text(json.dumps(live.discover(), indent=1, default=str))
    (out / "evidence.json").write_text(json.dumps(live.evidence(), indent=1, default=str))
    (out / "library.json").write_text(json.dumps(live.library(), indent=1, default=str))
    n = meta_client.freeze_for_replay()
    print(f"froze {n} cached model responses into replay/llm")


if __name__ == "__main__":
    main()
