"""Physica's tools, shared by the MCP server, the Wonder agent and the Feel Check app.

Sources are strings like 'padre:0100' (a real PADRE flight). Ground-truth labels are never returned
by observe/feel, so an agent cannot peek at the answer.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

import numpy as np

from physica import config
from physica.agents import glimmer_gate
from physica.data import padre
from physica.feel.feel_transform import FeelConfig, FeelTransform
from physica.feel.selfmodel import OperatingPointSelfModel
from physica.library import arrival, cards
from physica.translate import ardupilot, gcode, plc_st

MACHINE = {"type": "quadcopter", "model": "Parrot Bebop 2", "id": "padre-bebop2"}
FEELOGRAM_DIR = config.REPO_ROOT / ".cache" / "feelograms"


def _parse(source: str) -> tuple[str, str]:
    kind, _, ref = source.partition(":")
    if kind != "padre" or not ref:
        raise ValueError("sources look like 'padre:0100' (more source types arrive with their loaders)")
    return kind, ref


@lru_cache(maxsize=32)
def _recording(code: str) -> padre.Recording:
    return padre.load(code)


def healthy_card() -> tuple[dict, OperatingPointSelfModel]:
    """The library's 'what a healthy Bebop 2 feels like' card (built by eval/build_library.py)."""
    found = cards.recall(type="sense", machine_type="quadcopter", tag="fleet card")
    if not found:
        raise RuntimeError("No healthy self-model card yet. Run: python eval/build_library.py")
    card, model = cards.load(found[-1]["id"])
    sm = OperatingPointSelfModel.from_dict(model)
    sm.touch_base = model.get("touch_base")
    return card, sm


def body_map_card():
    """The drone's body map (rotor fingerprints learned from healthy flight, eval/e11_body_map.py), if built."""
    from physica.feel.body_map import BodyMap

    found = [c for c in cards.recall(type="sense", tag="body map") if c["machine"].get("id") == MACHINE["id"]]
    if not found:
        return None, None
    card, model = cards.load(found[-1]["id"])
    return card, BodyMap.from_dict(model)


def where(code: str, sm) -> dict | None:
    """Two independent cues for WHERE a felt shake comes from: the body map (whose fingerprint does the frame's
    motion match?) and the loudest arm. If they agree, name the rotor; if not, name both and ask for the spin test."""
    from physica.feel.feel_transform import windows
    from physica.feel.spectra import band_peak, window_psd

    card, bm = body_map_card()
    if bm is None:
        return None
    r = _recording(code)
    f, psd = window_psd(r.acc, padre.FS, windows(r.acc.shape[0], padre.FS, 5.0), 512)
    op, lvl = band_peak(psd, f, (95.0, 200.0))
    z = sm.z(op, lvl)
    S = bm.stft(r.acc, padre.FS)
    votes_map, votes_loud = [], []
    for i in range(min(len(S), len(z))):
        if z[i].max() <= sm.threshold:
            continue
        a = int(z[i].argmax())
        votes_map.append(bm.attribute(S[i], float(op[i, a]))["best"])
        votes_loud.append("ABCD"[a])
    if not votes_map:
        return None
    top = lambda v: max(set(v), key=v.count)  # noqa: E731
    m, l = top(votes_map), top(votes_loud)
    out = {"body_map": m, "body_map_share": f"{votes_map.count(m)}/{len(votes_map)}", "loudest_arm": l,
           "loudest_share": f"{votes_loud.count(l)}/{len(votes_loud)}", "agree": m == l, "card": card["id"]}
    out["text"] = (f"Both cues point to rotor {m}: its body-map fingerprint matches the shake ({out['body_map_share']} "
                   f"felt windows) and its arm is loudest. Confirm with the spin test before replacing anything."
                   if m == l else
                   f"The shake matches rotor {m}'s body-map fingerprint ({out['body_map_share']} felt windows), but arm "
                   f"{l} is loudest. Spin-test rotors {m} and {l} first.")
    return out


def observe(source: str) -> dict:
    _, code = _parse(source)
    r = _recording(code)
    return {"source": source, "machine": MACHINE, "duration_s": round(r.duration_s, 1), "fs_hz": r.fs,
            "channels": [f"arm {a} accelerometer x/y/z (m/s^2)" for a in padre.ROTORS] +
                        [f"arm {a} gyro x/y/z (deg/s)" for a in padre.ROTORS]}


def feel(source: str, plot: bool = True) -> dict:
    _, code = _parse(source)
    card, sm = healthy_card()
    ft = FeelTransform(list("ABCD"), FeelConfig(), self_model=sm)
    ft.touch_base = getattr(sm, "touch_base", None)
    fg = ft.transform(_recording(code).acc, padre.FS, source=source)
    if fg.verdict.get("status") == "felt":
        w = where(code, sm)
        if w:
            fg.verdict["where"] = w
            fg.verdict["text"] = fg.verdict["text"].split(" Strongest signal")[0] + " " + w["text"]
    out = {"source": source, "card_used": card["id"], "verdict": fg.verdict, "threshold_z": fg.threshold,
           "felt_fraction": fg.verdict["felt_fraction"], "per_window_max_z": np.asarray(fg.z).max(axis=1).round(2).tolist()}
    if plot:
        FEELOGRAM_DIR.mkdir(parents=True, exist_ok=True)
        png = FEELOGRAM_DIR / f"{code}.png"
        fg.plot(png, title=f"Feelogram: {MACHINE['model']} flight {code}")
        out["feelogram_png"] = str(png)
    return out


def recall(query: str = "") -> list[dict]:
    return [{k: c[k] for k in ("id", "type", "claim", "machine", "metrics", "lineage", "track_record")}
            for c in cards.recall(query)]


def check(card_id: str, source: str) -> dict:
    """Arrival check: does this card's 'healthy' still fit this machine? (use a flight believed healthy)"""
    from physica.feel.spectra import band_peak, window_psd
    from physica.feel.feel_transform import windows

    card, model = cards.load(card_id)
    sm = OperatingPointSelfModel.from_dict(model)
    _, code = _parse(source)
    r = _recording(code)
    wins = windows(r.acc.shape[0], padre.FS, 5.0)
    f, psd = window_psd(r.acc, padre.FS, wins, 512)
    op, lvl = band_peak(psd, f, (95.0, 200.0))
    hw = card["metrics"].get("conformal_halfwidth_z", 2.0)
    v = arrival.check(sm, op, lvl, hw)
    return {"card": card_id, "source": source, **v}


def predict(card_id: str, rotor_peak_hz: float) -> dict:
    """What-if: the vibration level this machine should feel at a given rotor speed peak, per arm."""
    card, model = cards.load(card_id)
    sm = OperatingPointSelfModel.from_dict(model)
    op = np.full((1, len(sm.unit_names)), float(rotor_peak_hz))
    pred = sm.predict(op)[0]
    lo, hi = card.get("proven_range", {}).get("rotor_peak_hz", [None, None])
    inside = lo is not None and lo <= rotor_peak_hz <= hi
    return {"card": card_id, "rotor_peak_hz": rotor_peak_hz, "inside_proven_range": inside,
            "expected_log10_level": dict(zip(sm.unit_names, np.round(pred, 3).tolist())),
            "note": "Outside the proven range this is a guess, not a proven prediction." if not inside else "Within proven range."}


REAL_ACTION_DRONE = ("The notch makes the flight controller stop fighting this shake; it does not fix the propeller. "
                     "Real fix: spin each motor alone for 3 s on the ground to find the damaged prop, replace it, "
                     "then run Feel Check again.")


def translate(source: str, target: str) -> dict:
    """Turn what was felt into the machine's own language, then act and re-feel.

    target: 'ardupilot' (drone flight controller), 'plc' (factory controller), 'marlin' (3D printer).
    Every action passes the safety gate first and carries a promise (an action contract) written BEFORE acting;
    re-feeling afterwards keeps the change or rolls it back.
    """
    from physica.act import contract

    out_dir = config.REPO_ROOT / ".cache" / "translations"
    out_dir.mkdir(parents=True, exist_ok=True)
    if target == "plc":
        return _plc_action()
    if target == "marlin":
        return _marlin_action()
    if target != "ardupilot":
        raise ValueError("target must be ardupilot, plc or marlin")
    fl = feel(source, plot=False)
    v = fl["verdict"]
    if v["status"] != "felt":
        return {"target": target, "skipped": "Nothing felt, so nothing to change. Physica doesn't act without a reason."}
    _, code = _parse(source)
    card, sm = healthy_card()
    from physica.feel.spectra import band_peak, window_psd
    from physica.feel.feel_transform import windows

    r = _recording(code)
    wins = windows(r.acc.shape[0], padre.FS, 5.0)
    f, psd = window_psd(r.acc, padre.FS, wins, 512)
    op, lvl = band_peak(psd, f, (95.0, 200.0))
    z = sm.z(op, lvl)
    felt = z.max(axis=1) > sm.threshold
    arm = int(np.bincount(z[felt].argmax(axis=1), minlength=4).argmax())
    freq = float(np.median(op[felt, arm]))
    proven = card.get("proven_range", {}).get("rotor_peak_hz")
    action = {"tool": "translate", "target": target, "source": source, "freq_hz": freq, "card": card["id"],
              "proven_range_hz": proven}
    gate = glimmer_gate.review(action)
    if not gate["approved"]:
        return {"target": target, "blocked_by_safety_gate": gate}
    p = ardupilot.notch_params(freq)
    path = ardupilot.write_param_file(p, out_dir / f"notch_{code}.param",
                                      header=[f"Physica from {source}, card {card['id']}",
                                              "Static notch (MODE 0) measured at 500 Hz: verify on a full-rate ArduPilot log.",
                                              "Advice, not a safety certification."])
    prom = contract.notch_promise(p["INS_HNTCH_FREQ"], p["INS_HNTCH_BW"])  # written BEFORE acting
    res = ardupilot.replay_notch(r.acc[:, arm, :], padre.FS, p["INS_HNTCH_FREQ"], p["INS_HNTCH_BW"], spectra=True)
    spectra = res.pop("spectra")
    return {"target": target, "machine": "drone flight controller (ArduPilot)", "file": str(path), "params": p,
            "gate": gate, "promise": prom, "replay": res, "spectra": spectra, "judgement": contract.judge(prom, res),
            "how_tested": "Replayed on this flight's real recorded vibration (arm with the strongest signal). A live "
                          "drone would also react to the change; that needs a real flight or ArduPilot's simulator.",
            "real_action": REAL_ACTION_DRONE, "card": card["id"]}


def _e6() -> dict:
    p = config.RESULTS_DIR / "E6_translators.json"
    if not p.exists():
        raise RuntimeError("Run: python eval/e6_translators.py")
    return json.loads(p.read_text())


def _plc_action() -> dict:
    from physica.act import contract

    e = _e6()["plc"]
    calib, source = plc_st.calibration(config.RESULTS_DIR)
    alarm, trip = e.get("alarm_setpoint_gmm", 100.0), e["trip_setpoint_gmm"]
    prom = contract.plc_promise(trip, e["limit_gmm"])  # written BEFORE the re-feel below
    ramp = plc_st.ramp_test(calib, alarm, trip)
    synthetic = "SYNTHETIC" in source
    j = contract.judge(prom, ramp)
    if synthetic:
        j["text"] = ("On the SYNTHETIC stand-in calibration the promise holds. It becomes a real result only after "
                     "the Fraunhofer shaft run, so it is not recorded as a card yet.")
    return {"target": "plc", "machine": "factory motor shaft (PLC, IEC 61131-3 Structured Text)",
            "file": str(config.REPO_ROOT / e["st_file"]), "promise": prom, "measured": ramp, "judgement": j,
            "data_source": source, "synthetic": synthetic,
            "how_tested": ("Python mirror of the PLC block, fed a shaft whose imbalance grows from 0 to 160 g·mm "
                           f"(alarm fired at {ramp['alarm_at_gmm']:.0f}, trip at {ramp['trip_at_gmm']:.0f}). "
                           + ("Calibration is a SYNTHETIC stand-in until the Fraunhofer shaft data is run "
                              "(python eval/e2_wobble_units.py, then eval/e6_translators.py)." if synthetic else
                              "Calibrated on the real Fraunhofer shaft (E2).")),
            "real_action": "On trip the PLC stops the motor; a technician rebalances the shaft, then Physica re-feels it.",
            "openplc": e.get("openplc")}


def _marlin_action() -> dict:
    e = _e6()["marlin_klipper"]
    p = config.RESULTS_DIR / "translations" / "input_shaping.gcode"
    return {"target": "marlin", "machine": "3D printer (Marlin G-code)", "file": str(p),
            "lines": e["lines"], "syntax_valid": e["all_valid"],
            "judgement": {"verdict": "not checked", "checks": [],
                          "text": "Format only: the command is valid Marlin G-code, but no printer data is in this demo, "
                                  "so Physica makes no promise it can't check."},
            "how_tested": e["note"],
            "real_action": "On a printer: print a ringing test before and after; Physica would re-feel the toolhead."}


def explain(result: dict) -> str:
    from physica.agents import wonder_agent

    return wonder_agent.explain(result)


TOOLS = {"observe": observe, "feel": feel, "recall": recall, "check": check, "predict": predict,
         "translate": translate, "explain": explain}


def library_summary() -> dict:
    return cards.library_counts()


def dumps(obj) -> str:
    return json.dumps(obj, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o))
