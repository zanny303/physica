"""voraus-AD: a real collaborative robot doing pick-and-place, with normal cycles and 12 kinds of anomaly
(collisions, extra weight, axis friction, lost or missed cans, cable entanglement, a wobbling station ...).
Brockmann et al., IEEE T-RO 2023. Data: CC BY-NC-SA 4.0 (non-commercial). Download the 100 Hz parquet (~1.1 GB):
https://media.vorausrobotik.com/voraus-ad-dataset-100hz.parquet  then  export PHYSICA_VORAUS_FILE=/path/to/file
Column names follow the dataset's own loader (github.com/vorausrobotik/voraus-ad-dataset, voraus_ad.py).
"""
from __future__ import annotations

import os

import numpy as np

CATEGORIES = ["axis friction", "axis weight", "collision foam", "collision cable", "collision carton", "miss can",
              "lose can", "can weight", "entangled", "invalid position", "motor commutation", "wobbling station",
              "normal operation"]
JOINTS = 6


def path() -> str:
    p = os.environ.get("PHYSICA_VORAUS_FILE")
    if not p:
        raise RuntimeError("Set PHYSICA_VORAUS_FILE to the voraus-AD 100 Hz parquet (see DATA.md)")
    return p


def load(file: str | None = None) -> list[dict]:
    """One dict per pick-and-place cycle: measured and predicted joint torques, time, labels."""
    import pandas as pd

    cols = ["time", "sample", "anomaly", "category"]
    meas = [f"motor_torque_{j}" for j in range(1, JOINTS + 1)]
    pred = [f"target_torque_{j}" for j in range(1, JOINTS + 1)]
    d = pd.read_parquet(file or path(), columns=cols + meas + pred)
    out = []
    for s, g in d.groupby("sample", sort=True):
        g = g.sort_values("time")
        out.append({"sample": int(s), "anomaly": bool(g["anomaly"].iloc[0]),
                    "category": CATEGORIES[int(g["category"].iloc[0])], "t": g["time"].to_numpy(float),
                    "measured": g[meas].to_numpy(float), "predicted": g[pred].to_numpy(float)})
    return out
