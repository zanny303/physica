# Physica v0.4 — CRATE and verified Meta interfaces (October 30, 2026)

**Preserves the original archive's prior code and examples.**

### New
- `physica/experience/causal_transport.py`: CRATE dimensionless *causal residual*, physics baseline, recipient scaling, local low-force probe adaptation, held-out source conformal bands, incompatibility and extrapolation refusal, safety probe filter.
- `physica/experience/loop_demo.py`: 28-source + 22-calibration + 24-target machine-disjoint synthetic evaluation by default; four independently implemented comparison baselines, signed predictions and reveal, a self-contained offline HTML evidence dashboard.
- `physica/experience/meta_live.py`: documentation-derived Meta Model API `responses` and model IDs, live video upload, official SAM 3.1 streaming grammar box extraction, separately calibrated pixel→metre conversion; Spark/Wonder multimodal hypothesis review with action whitelisting.
- `physica/experience/meta_fusion.py`: single live Spark→SAM→calibration/sensor cross-check→Wonder→numeric physical safety gate orchestration, with `--allow-billed-meta` required.
- `physica/experience/visual_bridge.py`: body-disjoint ridge readout for externally supplied visual world-model embeddings, independent observation calibration and leakage protection; no model checkpoints bundled.
- CLI commands: `crate-demo`, `meta-preflight`, `meta-scientist`, `sam-video`, `meta-fusion-live`, `visual-fit`, `visual-forecast`.
- `tests/test_crate_v04.py` and v0.4 documentation, updated package version and optional API client dependency.

### Boundaries
- Latest new **CRATE simulation** demonstrates implementation under controlled assumptions; no new hardware experiment.
- No live Meta Model API calls and no local V-JEPA checkpoint inference executed in the supplied environment.
- `meta-fusion-live` is a contract-grounded integration, but not independently tested against an authenticated Meta endpoint.
- Signed Python demo shows order of operations, not independently witnessed chronology.
- A novel *combination*, not proof of a newly discovered mathematical theorem or a hackathon win.
