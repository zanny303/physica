"""Build docs/touch_demo.html from eval/results (every number on the page comes from E13's results)."""
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
R = json.loads((ROOT / "eval/results/E13_touch_transform.json").read_text())
P = json.loads((ROOT / "eval/results/touch_page_data.json").read_text())
pred = np.load(ROOT / "eval/results/touch_beam_predict.npy")
step = max(1, pred.shape[1] // 700)
A, B, C = R["A_real_beam"], R["B_sim_video_touch_place"], R["C_real_guitar_video"]
summary = {
    "events": A["feel_stream"]["events"], "mass": A["where_was_the_mass"], "imagine": A["imagine_the_consequence"],
    "shaping": {k: A["act_move_without_ringing"][k] for k in ("felt_ringing_left", "added_delay_s", "marlin", "klipper", "ardupilot_notch_for_mode2")},
    "tap": {**A["act_stop_the_ringing"]["robot_action"], "ringing_left": A["act_stop_the_ringing"]["ringing_left"], "tried": A["act_stop_the_ringing"]["tried"]},
    "physics": A["physics_check"], "sim": B, "guitar": C, "speed": R["speed"],
    "words": {k: v for k, v in A["words"].items() if k.startswith("same_body")},
    "pred": {"t": (pred[0, ::step] - pred[0, 0]).round(4).tolist(), "real": pred[1, ::step].round(3).tolist(),
             "imag": pred[2, ::step].round(3).tolist()},
}
html = (ROOT / "docs/touch_demo.template.html").read_text()
html = html.replace("/*__DATA__*/null", json.dumps({"page": P, "r": summary}, separators=(",", ":")))
(ROOT / "docs/touch_demo.html").write_text(html)
print("wrote docs/touch_demo.html", len(html) // 1024, "KB")
