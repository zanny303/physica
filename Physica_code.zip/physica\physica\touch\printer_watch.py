"""Has this printer changed? Feel it against its own healthy self, from repeated films of the same G-code.

  baseline  film the healthy printer at least 3 times. The tone's spread across films is the measured noise.
  compare   film it again. Physica answers changed, no change or can't tell, sealed before you say what you did.
  reveal    say the truth for a sealed trial. score  shows every trial, misses included.

The rule uses the tone only, because tone is what repeats well (ringing amplitude depends on the camera):
  changed    the tone moved further than the baseline films can explain (95% prediction interval)
  no change  the tone moved less than half of that
  can't tell in between, or the footage or the baseline is not good enough
A falling tone means more moving mass or less stiffness and a rising tone means the reverse. The tone alone cannot say
which, so causes stay unverified until another measurement separates them. Advice only: nothing here moves a machine.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np

from physica import seal as _seal
from physica.llm import meta_client as mc
from physica.touch import printer_video as PV
from physica.touch import video

MIN_FILMS = 3
MIN_WINDOWS = 4
MIN_SD_FRACTION = 0.0015      # no baseline is trusted to be better than 0.15% of the tone
MAX_BASELINE_FRACTION = 0.02  # films disagreeing by more than 2% are not a usable baseline
MAX_FILM_SPREAD_FRACTION = 0.05
MAX_CLOCK_SHIFT = 0.15
MAX_ESTIMATE_GAP = 0.05
MAX_LOAD_GB = 3.0
SAM_CLIP_FRAMES = 450         # about one back-and-forth at 240 fps
BYTES_PER_PIXEL = 4


def parse_roi(text: str | None):
    if not text:
        return None
    parts = [int(float(x)) for x in text.split(",")]
    if len(parts) != 4 or parts[2] <= parts[0] or parts[3] <= parts[1]:
        raise ValueError("--roi must be x1,y1,x2,y2 in pixels, with x2 > x1 and y2 > y1")
    return parts


def probe(path: str | Path) -> dict:
    import cv2
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise ValueError(f"cannot open video {path}")
    d = {"width": int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), "height": int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
         "frames": int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), "stored_fps": float(cap.get(cv2.CAP_PROP_FPS) or 0)}
    cap.release()
    return d


def plan_load(path: str | Path, roi=None, max_gb: float = MAX_LOAD_GB) -> dict:
    """Decide how to read a film so a long slow-motion clip fits in memory. Every later film reuses the same plan."""
    info = probe(path)
    x1, y1, x2, y2 = roi or (0, 0, info["width"], info["height"])
    x1, y1 = max(int(x1), 0), max(int(y1), 0)
    x2, y2 = min(int(x2), info["width"]), min(int(y2), info["height"])
    if x2 - x1 < 8 or y2 - y1 < 8:
        raise ValueError(f"the crop {roi} leaves too little of the {info['width']}x{info['height']} video")
    gb = (x2 - x1) * (y2 - y1) * max(info["frames"], 1) * BYTES_PER_PIXEL / 1e9
    scale = min(1.0, math.sqrt(max_gb / gb)) if gb > max_gb else 1.0
    return {"roi": [x1, y1, x2, y2], "scale": round(scale, 4), "source_size": [info["width"], info["height"]],
            "uncropped_gb": round(info["width"] * info["height"] * max(info["frames"], 1) * BYTES_PER_PIXEL / 1e9, 2),
            "needs_crop_warning": scale < 1.0}


def load(path: str | Path, plan: dict) -> np.ndarray:
    info = probe(path)
    if list(plan["source_size"]) != [info["width"], info["height"]]:
        raise ValueError(f"this film is {info['width']}x{info['height']} but the first was "
                         f"{plan['source_size'][0]}x{plan['source_size'][1]}: use the same camera setting")
    return video.load_gray(path, roi=plan["roi"], scale=plan["scale"])


def sam_roi(path: str | Path, concept: str, pad: float = 0.25) -> dict:
    """Live SAM 3.1 finds the part in the film. The crop covers everywhere that part went, so the moves stay in frame."""
    clip, used = short_clip(path, SAM_CLIP_FRAMES)
    try:
        tracked = mc.sam_video(clip, concept, n_frames=used, task="printer_sam_locate")
    finally:
        if str(clip) != str(path):
            Path(clip).unlink(missing_ok=True)
    frames = tracked.get("frames") or {}
    per: dict[int, list] = {}
    for recs in frames.values():
        for r in recs:
            per.setdefault(r["id"], []).append(r)
    if not per:
        raise ValueError(f'SAM 3.1 did not find "{concept}" in this film; try another phrase or use --roi')
    best = max(per.values(), key=len)
    boxes = np.array([r["box"] for r in best], float)
    x1, y1 = np.quantile(boxes[:, :2], 0.02, axis=0)
    x2, y2 = np.quantile(boxes[:, 2:], 0.98, axis=0)
    info = probe(path)
    sw, sh = best[0].get("size") or (0, 0)
    sx, sy = (info["width"] / sw, info["height"] / sh) if sw and sh else (1.0, 1.0)
    dx, dy = pad * (x2 - x1), pad * (y2 - y1)
    roi = [int(max((x1 - dx) * sx, 0)), int(max((y1 - dy) * sy, 0)),
           int(min((x2 + dx) * sx, info["width"])), int(min((y2 + dy) * sy, info["height"]))]
    return {"roi": roi, "source": mc.model_id("sam"), "concept": concept, "frames_found": len(best),
            "objects_found": len(per), "frames_sent": used, "mode": tracked.get("mode")}


def short_clip(path: str | Path, frames: int = 0) -> tuple[str, int]:
    """SAM is billed per frame, and only needs one back-and-forth to see where the head goes. Send the busiest stretch."""
    import cv2
    import tempfile

    frames = frames or SAM_CLIP_FRAMES
    info = probe(path)
    if info["frames"] <= frames:
        return str(path), info["frames"]
    small = min(1.0, 160 / max(info["width"], 1))
    energy = PV.frame_energy(video.load_gray(path, scale=small))
    window = np.convolve(energy, np.ones(frames), "valid")
    start = int(np.argmax(window))
    cap = cv2.VideoCapture(str(path))
    cap.set(cv2.CAP_PROP_POS_FRAMES, start)
    handle = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False)
    handle.close()
    out = cv2.VideoWriter(handle.name, cv2.VideoWriter_fourcc(*"mp4v"), info["stored_fps"] or 30.0, (info["width"], info["height"]))
    written = 0
    while written < frames:
        ok, f = cap.read()
        if not ok:
            break
        out.write(f)
        written += 1
    cap.release()
    out.release()
    return handle.name, written


def _spectrum(V: np.ndarray, fps: float, p: dict = PV.EXCITE):
    """Every stop's spectrum added together."""
    runs = []
    for w in PV.pauses(V, fps, p):
        Y = video.motion(V[w], wavelength=6, sigma=2.5, step=2, keep=0.15, direction="horizontal")["signals"]
        if Y.shape[0] >= 20:
            u, sv, _ = np.linalg.svd(Y - Y.mean(0), full_matrices=False)
            runs.append(u[:, 0] * sv[0])
    if not runs:
        return None, None
    return spectrum_of(runs, fps)


def spectrum_of(runs: list[np.ndarray], fps: float):
    n = 8 * max(len(x) for x in runs)
    freq = np.fft.rfftfreq(n, 1 / fps)
    power = np.zeros(len(freq))
    for x in runs:
        x = x - x.mean()
        power += np.abs(np.fft.rfft(x * np.hanning(len(x)), n=n)) ** 2
    return freq, power


def _peak(freq: np.ndarray, power: np.ndarray, i: int) -> float:
    a, b, c = np.log(power[i - 1:i + 2] + 1e-30)
    return float((i + 0.5 * (a - c) / (a - 2 * b + c + 1e-12)) * (freq[1] - freq[0]))


def tone_from(freq, power, fps: float, band=(10.0, None)) -> float | None:
    keep = np.flatnonzero((freq >= band[0]) & (freq <= (band[1] or 0.45 * fps)))
    if not len(keep):
        return None
    return _peak(freq, power, int(keep[np.argmax(power[keep])]))


def find_modes(freq, power, fps: float, low: float = 10.0, most: int = 4, floor: float = 0.05) -> list[dict]:
    """The separate resonances in a film, strongest first. A real printer usually has more than one."""
    from scipy.signal import find_peaks
    keep = np.flatnonzero((freq >= low) & (freq <= 0.45 * fps))
    if len(keep) < 5:
        return []
    window = power[keep]
    spacing = max(int(4.0 / (freq[1] - freq[0])), 1)
    idx, _ = find_peaks(window, height=window.max() * floor, distance=spacing)
    ranked = sorted(idx, key=lambda i: -window[i])[:most]
    return [{"hz": round(_peak(freq, power, int(keep[i])), 3), "relative_power": round(float(window[i] / window.max()), 3)} for i in ranked]


def pooled_tone(V: np.ndarray, fps: float, p: dict = PV.EXCITE, band=(10.0, None)) -> float | None:
    """The tone from every stop's spectrum added together. Far steadier than fitting each stop alone, which matters
    when small tone differences carry the answer (in simulated MP4s, about 0.03% repeatability against 0.2-0.8%)."""
    freq, power = _spectrum(V, fps, p)
    return None if freq is None else tone_from(freq, power, fps, band)


def match_modes(healthy: list[dict], loaded: list[dict], added_g: float, tolerance_hz: float = 0.5) -> list[dict]:
    """Which resonance moves when a known weight goes on? A moving-mass mode falls; a frame mode mostly stays put."""
    out = []
    for h in healthy:
        below = [m["hz"] for m in loaded if m["hz"] < h["hz"] - tolerance_hz and m["hz"] > 0.6 * h["hz"]]
        same = [m["hz"] for m in loaded if abs(m["hz"] - h["hz"]) <= tolerance_hz]
        if same:
            out.append({**h, "with_weight_hz": same[0], "responds": False,
                        "reading": f"stays near {h['hz']:.1f} Hz under {added_g:g} g, so likely not this moving mass"})
        elif below:
            nearest = max(below)
            out.append({**h, "with_weight_hz": nearest, "responds": True,
                        "reading": f"falls to about {nearest:.1f} Hz under {added_g:g} g, so it behaves like a moving-mass mode"})
        else:
            out.append({**h, "with_weight_hz": None, "responds": None, "reading": "couldn't be matched in the loaded films"})
    return out


def film_summary(V: np.ndarray, axis: str = "X", mode_hz: float | None = None) -> dict:
    """One film's tone. With mode_hz, follow that resonance (within 25%) instead of the strongest peak."""
    r = PV.tune(V, axis)
    if "error" in r:
        return {"ok": False, "reason": r["error"]}
    f = r["felt"]
    fps = r["clock"]["fps"]
    freq, power = _spectrum(V, fps)
    if freq is None:
        return {"ok": False, "reason": "no clear stops in this film"}
    modes = find_modes(freq, power, fps)
    if mode_hz:
        tone = tone_from(freq, power, fps, (0.75 * mode_hz, 1.25 * mode_hz))
    else:
        tone = tone_from(freq, power, fps)
        if tone is None or abs(tone - f["freq_hz"]) / f["freq_hz"] > MAX_ESTIMATE_GAP:
            return {"ok": False, "reason": "the two tone estimates disagree, so this film may be reading the wrong motion",
                    "modes": modes}
    if tone is None:
        return {"ok": False, "reason": "no resonance found near the chosen mode", "modes": modes}
    return {"ok": True, "tone_hz": tone, "damping": float(f["damping"]), "windows": int(f["windows"]), "modes": modes,
            "tone_iqr_hz": [float(x) for x in f.get("freq_iqr", [])] if not mode_hz else [], "ringing_px": f.get("ringing_px"),
            "fps": float(fps), "felt": f}


def make_baseline(films: list[dict]) -> dict:
    """films: film_summary results from the healthy printer, one per recording."""
    good = [f for f in films if f.get("ok")]
    tones = [f["tone_hz"] for f in good]
    out = {"films_given": len(films), "films_used": len(good), "tones_hz": [round(t, 3) for t in tones],
           "fps": [round(f["fps"], 2) for f in good], "rejected": [f.get("reason") for f in films if not f.get("ok")]}
    if len(good) < MIN_FILMS:
        return {**out, "usable": False, "reason": f"need at least {MIN_FILMS} films with clear ringing, got {len(good)}"}
    mean, sd = float(np.mean(tones)), float(np.std(tones, ddof=1))
    out.update(mean_hz=mean, sd_hz=sd, sd_percent=round(100 * sd / mean, 3))
    if sd / mean > MAX_BASELINE_FRACTION:
        return {**out, "usable": False, "reason": f"films disagree by {100 * sd / mean:.1f}% with nothing changed; steady "
                "the camera, film closer, add a high-contrast mark, then redo the baseline"}
    from scipy.stats import t as student
    n = len(good)
    used_sd = max(sd, MIN_SD_FRACTION * mean)
    predictive = used_sd * math.sqrt(1 + 1 / n)
    limit = float(student.ppf(0.975, n - 1) * predictive)
    payload = json.dumps({"tones": tones, "fps": out["fps"]}, sort_keys=True)
    return {**out, "usable": True, "sd_used_hz": used_sd, "predictive_sd_hz": predictive, "changed_limit_hz": limit,
            "no_change_limit_hz": limit / 2, "sha256": hashlib.sha256(payload.encode()).hexdigest()}


def judge_change(base: dict, film: dict) -> dict:
    """Three possible answers. Anything doubtful is can't tell, never a guess."""
    if not base.get("usable"):
        return {"verdict": "can't tell", "reason": base.get("reason", "no usable baseline")}
    if not film.get("ok"):
        return {"verdict": "can't tell", "reason": film.get("reason", "no ringing found")}
    if film["windows"] < MIN_WINDOWS:
        return {"verdict": "can't tell", "reason": f"only {film['windows']} clear stops in this film"}
    iqr = film.get("tone_iqr_hz") or []
    if len(iqr) == 2 and (iqr[1] - iqr[0]) / film["tone_hz"] > MAX_FILM_SPREAD_FRACTION:
        return {"verdict": "can't tell", "reason": "the tone is not steady within this film"}
    usual = float(np.median(base["fps"]))
    if abs(film["fps"] - usual) / usual > MAX_CLOCK_SHIFT:
        return {"verdict": "can't tell", "reason": "the video's timing differs from the baseline; use the same setting"}
    delta = film["tone_hz"] - base["mean_hz"]
    size = abs(delta)
    out = {"tone_now_hz": round(film["tone_hz"], 2), "tone_baseline_hz": round(base["mean_hz"], 2),
           "shift_hz": round(delta, 2), "shift_percent": round(100 * delta / base["mean_hz"], 2),
           "changed_limit_hz": round(base["changed_limit_hz"], 3), "no_change_limit_hz": round(base["no_change_limit_hz"], 3)}
    if size >= base["changed_limit_hz"]:
        way = "fell" if delta < 0 else "rose"
        why = ("more moving mass or less stiffness, such as a load on the head or a looser belt" if delta < 0 else
               "less moving mass or more stiffness, such as a load removed or a tighter belt")
        return {**out, "verdict": "changed", "direction": way, "consistent_with_unverified": why,
                "reason": f"the tone {way} {size:.2f} Hz, more than the {base['changed_limit_hz']:.2f} Hz the baseline allows"}
    if size <= base["no_change_limit_hz"]:
        return {**out, "verdict": "no change", "reason": f"the tone moved {size:.2f} Hz, within normal repeat variation"}
    return {**out, "verdict": "can't tell", "reason": f"the tone moved {size:.2f} Hz, between the two limits"}


def seal_verdict(name: str, trial: int, change: dict) -> dict:
    return _seal.seal({"trial": trial, "verdict": change["verdict"], "shift_hz": change.get("shift_hz")},
                      f"printer change verdict, trial {trial} of {name}")


def grade_trial(sealed: dict, truth: str) -> dict:
    """truth is 'changed' or 'same'. Refuses a seal that was edited."""
    if truth not in ("changed", "same"):
        raise ValueError("--truth must be changed or same")
    if not _seal.intact(sealed):
        return {"truth": truth, "verdict": "INVALID", "result": "seal was edited", "held": False}
    v = sealed["payload"]["prediction"]["verdict"]
    if v == "can't tell":
        return {"truth": truth, "verdict": v, "result": "abstained", "held": None}
    right = (v == "changed") == (truth == "changed")
    return {"truth": truth, "verdict": v, "result": "right" if right else "wrong", "held": right}


def score_trials(trials: list[dict]) -> dict:
    graded = [t for t in trials if t.get("grade")]
    res = [t["grade"]["result"] for t in graded]
    return {"trials": len(trials), "revealed": len(graded), "right": res.count("right"), "wrong": res.count("wrong"),
            "abstained": res.count("abstained"), "invalid": res.count("seal was edited"),
            "missed_changes": sum(t["grade"]["truth"] == "changed" and t["grade"]["verdict"] == "no change" for t in graded),
            "false_alarms": sum(t["grade"]["truth"] == "same" and t["grade"]["verdict"] == "changed" for t in graded)}
