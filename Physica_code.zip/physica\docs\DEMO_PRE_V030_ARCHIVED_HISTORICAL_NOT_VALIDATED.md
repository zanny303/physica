**ARCHIVED HISTORICAL DOCUMENT — DO NOT USE AS AN OPERATING PROTOCOL.** Several old fan test suggestions involve adding weights to rotating blades and may be unsafe. They are not recommended or validated. Historical claims require independent review.

# Physica demo: real machines, real problems

The video shows three things on real data: what Physica **maps** (why a machine changed), how it **acts** (machine
instructions with sealed promises it then checks), and what it **teaches** (signed cards other machines start from).
Everything runs on a laptop; Meta parts need `MOCK=0` and your `MODEL_API_KEY` in the terminal (never in the repo).
Desk experiments with a ruler, coins and clay are in [docs/DEMO_desk_experiments.md](docs/DEMO_desk_experiments.md).

## Before you film

```bash
pip install -e ".[dev,video,meta]"
python -m physica.cli verify                         # all PASS
# data (DATA.md): blade spectra, DROPBEAR beams, optional KW51 bridge
python eval/e20_wind_blade.py                        # PHYSICA_BLADE_PSD
python eval/e16_hidden_cause.py && python eval/e22_retune_beam.py   # PHYSICA_DROPBEAR2 / 8
python eval/e21_kw51_bridge.py trackedmodes.mat      # optional, 13 MB download
export MOCK=0 MODEL_API_KEY=...                      # PowerShell: $env:MOCK="0"; $env:MODEL_API_KEY="..."
python -m physica.cli meta doctor                    # receipts in meta_receipts/
python eval/e23_program_by_outcome.py                # optional toolchains (DATA.md): Klipper, matiec, ArduPilot SITL
python eval/e24_f1_feel_and_advise.py                # F1 telemetry + TUM simulator (DATA.md); writes the ghost-lap video
python eval/e25_deliberate_discover.py               # with MOCK=0 + MODEL_API_KEY: Muse proposes the laws
python -m physica.studio --open-browser
```

## The 3-minute video: one sense, three worlds

The judging weights published in the event waiver: Impact 30%, Use of Meta AI tooling 25%, Demo 25%, Technical depth
20%. The video length isn't published, so this runs 3:00, with a 2:00 cut at the end. Due 9 PM ET (8 PM CT), Nov 4.
Every segment starts the same way: something goes into one box, Meta names what it is, Physica feels it.

| Time | Show | Say |
|---|---|---|
| 0:00–0:15 | Front door: "AI can see and hear. Physica gives it feel." Then **Drop anything in**: the tiles (guitar video, F1 telemetry, turbine blade, steel beam) | "AI can see and hear. It can't feel. Drop anything into Physica: a phone video, a sensor file, race telemetry. Meta works out what it is; Physica feels the forces no sensor on it measures." |
| 0:15–0:55 | **Consumer: fix the wobble.** Your phone video of a wobbling fan → `physica auto fan.mp4 --live` (Muse names it, SAM 3.1 boxes the fan) → three 5-second clips with a coin on blade 1, 2, 3 → `physica auto --balance …` → "add 1.6 g on blade 1, 0.7 g on blade 2", sealed → tape the coins on → film again → promise graded | "My fan wobbles. Meta sees a three-blade rotating machine; Physica feels a once-per-turn wobble: imbalance, not a bent shaft. It asks for one experiment: a coin on each blade in turn. Then it tells me exactly where to put how many grams, and seals what will happen. Watch: the wobble drops by [your number]%. The same maths balances washing machines, drones and car wheels." |
| 0:55–1:35 | **Race engineer** section: felt table → the team's question → answer → TUM check → `ghost_lap.mp4` | "Same box, a different world: live timing from a real Formula 1 session. Meta says race car; Physica feels each car's power, drag and downforce from the speed trace, numbers the broadcast never shows. A team asks for a faster lap without losing speed through Maggotts–Becketts. Physica answers, and says what the answer depends on. An independent physics simulator from TU Munich grades it: [lap-time promises held / graded] on cars it never calibrated on." |
| 1:35–2:35 | **Ice, crack or just cold?** stats row; turbine refusal in the terminal; PLC code compiled; drone flight track (`sitl_track.png`) | "Now a real problem: wind turbines in winter. Icing is the top cause of cold-climate downtime, and a temperature-blind alarm cried wolf 69% of the time on this real blade. Physica learned the blade from healthy days and one 44-gram experiment, never seeing ice or a crack: 6% false alarms, ice weighed at 87 grams for a true 88. It writes the turbine's own PLC code, where the de-icing promise is enforced by the machine: four cracks that looked like ice were caught when heating didn't fix them. It writes the drone's inspection flight, flown on the real ArduPilot autopilot. And when I ask it to promise it will never run a cracked blade, it refuses: its own measurements missed 9 of 111." |
| 2:35–3:00 | Beam: `physica outcome "…31 Hz…"` → Klipper check; Meta chip LIVE; receipts | "Say the outcome; it writes the machine's code and lets reality grade it. Meta's models see, name and reason; Physica feels; reality judges. One sense, any machine." |

**Why these three.** Impact is the heaviest weight, so the real problem (turbines) gets the most time; the consumer fix
is the one every judge has lived (a wobbling fan or washer) and the only segment where a physical fix happens on
camera; F1 is the instantly recognisable "sixth sense" and shows Meta routing a completely different input through the
same box. Each one exercises a different Meta model on screen (SAM 3.1 seeing the fan, Muse Spark naming systems and
reading goals, the deliberation loop). Prior art to be ready for: video vibration measurement exists commercially
(RDI Technologies' Motion Amplification) and blade monitors exist; Physica's difference is naming the cause,
choosing the experiment, writing the machine's code and letting reality grade a sealed promise.
Stakes, with sources: icing is the No. 1 cause of turbine downtime in cold climates (Wind Systems, 2018); unplanned
downtime costs manufacturers up to $852M a week (Fluke/Censuswide, Oct 2025); about 3,800 blade failures a year at
roughly $1M each (GCube via NS Energy).

**2-minute cut:** 0:00–0:10 hook; 0:10–0:45 fan; 0:45–1:10 F1 (felt table + verdict + ghost lap); 1:10–1:50 turbine;
1:50–2:00 close.

**Before you film:** run every step once with `MOCK=0` so the Meta chip reads LIVE and `meta_receipts/` fills; film the
fan clips on a tripod at the same speed setting (desk fans: phone slow-motion, 120 fps or more; ceiling fans: normal
video is enough); keep the coin at the same radius on every blade. The fan segment has only been tested on simulated
clips (98% wobble drop): your footage is the real result, so film the after-clip whatever it shows.

Label simulation as simulation whenever it appears (the active-experiment and new-cause panels), and say whether Meta
calls are live (the chip in the top right).

## Optional: live on stage

- **Feel it live:** clamp a plastic ruler over a table edge, open *Feel it live*, flick: tone and ring time. Tape a coin
  on: "tone went DOWN, holding is ruled out". Press a finger on it: "tone went UP, mass is ruled out". The same one-way
  physics that tells ice from cracks on the blade.
- **Two-machine handoff:**
  ```bash
  python -m physica.studio --host 0.0.0.0                                    # laptop B
  python -m physica.cli cause teach cards/explanation_dropbear_support.json --to http://LAPTOP-B:8765   # laptop A
  ```
- **Ask the agent** (Muse Wonder with your key): "Blade WTG-07's tones dropped this morning at −5 °C. What happened and
  what do we do?" It calls Physica's tools and answers with numbers from them.
