"""Deliberate to discover: a model proposes laws, physics grades them, the grades come back, the model proposes again.

This is reinforcement learning in context (the way AlphaEvolve and FunSearch use language models): the model's
weights don't change; its next proposals are conditioned on every earlier proposal and the reward physics gave it.
The reward is accuracy on training units; the law that survives is then graded on units it never saw.

Laws are a small, checkable language: IF <quantity> <op> <threshold> THEN <class> ELSE <class>, optionally AND a second
condition. Muse Spark proposes them when MOCK=0 and MODEL_API_KEY are set; otherwise an exhaustive search over
one-condition laws (a decision stump, the classical baseline) stands in and says so.
"""
from __future__ import annotations

import itertools
import json

import numpy as np

SCHEMA = {"name": "laws", "strict": True, "schema": {
    "type": "object", "additionalProperties": False, "required": ["laws"],
    "properties": {"laws": {"type": "array", "items": {
        "type": "object", "additionalProperties": False, "required": ["if", "and_if", "then", "else", "why"],
        "properties": {
            "if": {"type": "object", "additionalProperties": False, "required": ["quantity", "op", "value"],
                   "properties": {"quantity": {"type": "string"}, "op": {"type": "string", "enum": ["<", ">"]},
                                  "value": {"type": "number"}}},
            "and_if": {"type": ["object", "null"], "additionalProperties": False, "required": ["quantity", "op", "value"],
                       "properties": {"quantity": {"type": "string"}, "op": {"type": "string", "enum": ["<", ">"]},
                                      "value": {"type": "number"}}},
            "then": {"type": "string"}, "else": {"type": "string"}, "why": {"type": "string"}}}}}}}


def _cond(c, row):
    v = row.get(c["quantity"])
    if v is None:
        return False
    return v < c["value"] if c["op"] == "<" else v > c["value"]


def apply(law: dict, row: dict) -> str:
    ok = _cond(law["if"], row) and (law.get("and_if") is None or _cond(law["and_if"], row))
    return law["then"] if ok else law["else"]


def score(law: dict, rows: list[dict], labels: list[str]) -> dict:
    pred = [apply(law, r) for r in rows]
    wrong = [i for i, (p, y) in enumerate(zip(pred, labels)) if p != y]
    return {"accuracy": 1 - len(wrong) / max(len(rows), 1), "wrong": wrong}


def stump_search(rows, labels, features) -> list[dict]:
    classes = sorted(set(labels))
    laws = []
    for q in features:
        vals = sorted({r[q] for r in rows if r.get(q) is not None})
        for a, b in zip(vals[:-1], vals[1:]):
            thr = round((a + b) / 2, 4)
            for op in ("<", ">"):
                for t, e in itertools.permutations(classes, 2) if len(classes) > 1 else [(classes[0], classes[0])]:
                    laws.append({"if": {"quantity": q, "op": op, "value": thr}, "and_if": None, "then": t, "else": e,
                                 "why": "exhaustive one-condition search (offline stand-in, not Muse)"})
    return laws


def deliberate(rows, labels, train_idx, test_idx, features, question: str, rounds: int = 5, k: int = 6,
               live: bool | None = None) -> dict:
    from physica.outcome import muse
    live = muse.live_enabled() if live is None else live
    tr_rows, tr_lab = [rows[i] for i in train_idx], [labels[i] for i in train_idx]
    te_rows, te_lab = [rows[i] for i in test_idx], [labels[i] for i in test_idx]
    history, curve = [], []
    if not live:
        laws = stump_search(tr_rows, tr_lab, features)
        scored = sorted(({"law": L, **score(L, tr_rows, tr_lab)} for L in laws), key=lambda s: -s["accuracy"])
        history = scored[:k]
        curve = [history[0]["accuracy"]]
        proposer = f"offline stand-in: exhaustive one-condition search ({len(laws)} laws)"
    else:
        proposer = f"{muse.model()} (live, {rounds} rounds x {k} laws)"
        sys_p = ("You are a race engineer and physicist. Propose laws that explain which class each car falls in. Use only "
                 f"these quantities: {features}. Learn from the graded history: keep what scored well, fix what failed. "
                 "Each law needs a one-sentence physical reason.")
        for r in range(rounds):
            ctx = {"question": question, "classes": sorted(set(labels)),
                   "training_cars": [{**{f: tr_rows[i][f] for f in features}, "class": tr_lab[i]} for i in range(len(tr_rows))],
                   "graded_history": [{"law": h["law"], "train_accuracy": round(h["accuracy"], 3),
                                       "wrong_on": [tr_rows[i].get("name") for i in h["wrong"]]} for h in history[-12:]]}
            out = muse.chat_json(sys_p, json.dumps(ctx, default=float), SCHEMA, task=f"deliberate_round_{r + 1}", max_tokens=1500)
            for L in out["laws"][:k]:
                if L["if"]["quantity"] in features and (L["and_if"] is None or L["and_if"]["quantity"] in features):
                    history.append({"law": L, **score(L, tr_rows, tr_lab), "round": r + 1})
            curve.append(max(h["accuracy"] for h in history) if history else 0.0)
        history.sort(key=lambda s: -s["accuracy"])
    best = history[0]
    te = score(best["law"], te_rows, te_lab)
    return {"proposer": proposer, "best_law": best["law"], "train_accuracy": round(best["accuracy"], 3),
            "test_accuracy": round(te["accuracy"], 3), "test_units": len(te_rows), "train_units": len(tr_rows),
            "majority_baseline_test": round(max(te_lab.count(c) for c in set(te_lab)) / len(te_lab), 3),
            "best_by_round": [round(c, 3) for c in curve],
            "top": [{"law": h["law"], "train_accuracy": round(h["accuracy"], 3)} for h in history[:5]]}


def say(law: dict) -> str:
    c = law["if"]
    s = f"IF {c['quantity']} {c['op']} {c['value']:g}"
    if law.get("and_if"):
        a = law["and_if"]
        s += f" AND {a['quantity']} {a['op']} {a['value']:g}"
    return s + f" THEN {law['then']} ELSE {law['else']}"
