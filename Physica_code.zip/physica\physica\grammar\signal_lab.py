"""Non-FFT-only evidence: transients, STFT, Morlet time-frequency energy, phase.

These are established methods. None on their own prove damage or causality.
"""
from __future__ import annotations
import numpy as np
from scipy.signal import stft,coherence,fftconvolve
from .signals import finite_array


def analyze_signal(times,values,*,band_hz=None):
    t=finite_array(times,'times',minimum=32)
    y=finite_array(values,'values',minimum=32)
    if len(t)!=len(y) or np.any(np.diff(t)<=0):raise ValueError('strictly increasing equal-length data')
    dt=float(np.median(np.diff(t))); jitter=float(np.max(np.abs(np.diff(t)-dt))/dt)
    if jitter>.03:raise ValueError('time base nonuniform by >3%; resample with a physical clock first')
    fs=1/dt;nperseg=min(128,len(y))
    f,ts,Z=stft(y-np.mean(y),fs=fs,nperseg=nperseg,noverlap=nperseg//2)
    powers=np.sum(np.abs(Z)**2,axis=1)
    idx=np.where(f>0)[0]
    if band_hz is not None:
        lo,hi=map(float,band_hz)
        if not(0<lo<hi<fs/2):raise ValueError('invalid band under Nyquist')
        idx=idx[(f[idx]>=lo)&(f[idx]<=hi)]
    if not idx.size:raise ValueError('no resolved frequencies')
    dominant=float(f[idx[np.argmax(powers[idx])]])
    # Narrow Morlet wavelet bank: localized phase and transient energy.
    freqs=np.geomspace(max(.5,fs/len(y)),.45*fs,num=18)
    wavelet_energy=[]
    for fc in freqs:
        sigma=5/(2*np.pi*fc)
        tw=np.arange(-min(.35,4*sigma),min(.35,4*sigma)+dt/2,dt)
        wave=np.exp(1j*2*np.pi*fc*tw)*np.exp(-.5*(tw/sigma)**2)
        wave=wave/np.sqrt(np.sum(np.abs(wave)**2))
        wavelet_energy.append(np.abs(fftconvolve(y-np.mean(y),wave,mode='same'))**2)
    w=np.asarray(wavelet_energy)
    burst=np.max(w,axis=0)
    med=float(np.median(burst));mad=float(np.median(np.abs(burst-med)))
    novelty=(burst-med)/(1.4826*mad+1e-12)
    return {'status':'signal_features_not_causal_diagnosis','sample_rate_hz':fs,
            'dominant_stft_hz':dominant,
            'max_wavelet_burst_z':float(np.max(novelty)),
            'transient_time_s':float(t[np.argmax(novelty)]),
            'wavelet_peak_hz':float(freqs[np.argmax(np.max(w,axis=1))]),
            'clock_jitter_fraction':jitter,
            'warning':'frequency and burst detection alone cannot distinguish faults and external actions'}


def cross_channel_coherence(t1,y1,t2,y2):
    t1=finite_array(t1,'t1',minimum=32);t2=finite_array(t2,'t2',minimum=32)
    y1=finite_array(y1,'y1',minimum=32);y2=finite_array(y2,'y2',minimum=32)
    if len(t1)!=len(y1) or len(t2)!=len(y2):raise ValueError('time/value sizes mismatch')
    dt=float(np.median(np.diff(t1)))
    if np.max(np.abs(np.diff(t1)-dt))>.03*dt:raise ValueError('nonuniform clock')
    lo=max(t1[0],t2[0]);hi=min(t1[-1],t2[-1]);t=t1[(t1>=lo)&(t1<=hi)]
    if len(t)<32:raise ValueError('insufficient synchronized overlap')
    v1=np.interp(t,t1,y1);v2=np.interp(t,t2,y2)
    if np.std(v1)<=1e-15 or np.std(v2)<=1e-15:
        return {'status':'insufficient_excitation','coherence':None}
    f,coh=coherence(v1,v2,fs=1/dt,nperseg=min(64,len(t)))
    i=int(np.argmax(coh[1:])+1)
    return {'status':'correlation_not_causality','peak_coherence':float(coh[i]),
            'frequency_hz':float(f[i]),
            'warning':'synchronization and common drivers can create non-causal coherence'}
