"""Evidence-gated, dimensionally annotated, restricted mechanism proposals.

This is a bounded symbolic feature grammar, NOT unconstrained equation invention.
Muse may propose term structures but cannot supply trusted parameter values.
Training and independent validation outcomes determine acceptance.
"""
from __future__ import annotations
import re
import numpy as np

FIELDS = {
    'x': ('m', 1.0), 'v': ('m/s', 1.0), 'u': ('m/s^2', 1.0),
    'temperature_delta': ('K', 8.0), 'current': ('A', 1.0),
    'magnetic': ('uT', 30.0), 'ultrasound': ('Hz', 1000.0),
}
TRANSFORMS = ('linear', 'square', 'cube', 'tanh', 'abs', 'signed_square')
BASE = [{'id':'linear_position','factors':[{'field':'x','transform':'linear'}]},
        {'id':'linear_velocity','factors':[{'field':'v','transform':'linear'}]},
        {'id':'known_acceleration','factors':[{'field':'u','transform':'linear'}]},
        {'id':'offset','factors':[]}]
CANDIDATES = [
    {'id':'cubic_stiffness','factors':[{'field':'x','transform':'cube'}]},
    {'id':'nonlinear_drag','factors':[{'field':'v','transform':'signed_square'}]},
    {'id':'temperature_slip','factors':[{'field':'temperature_delta','transform':'linear'},
                                       {'field':'v','transform':'tanh'}]},
    {'id':'current_drag','factors':[{'field':'current','transform':'linear'},
                                   {'field':'v','transform':'linear'}]},
]

def validate_term(term):
    """Validate bounded, non-executable physical-basis proposals from a model.

    The sinusoidal phase basis extends the original polynomial grammar when a
    human or Muse nominates it. Its dimensionless phase weights are structural
    hypotheses, NOT measured physical constants; numeric coefficients are fit
    exclusively from source interventions.
    """
    if not isinstance(term,dict):raise ValueError('term must be an object')
    keys=set(term)
    if keys not in ({'id','factors'},{'id','factors','basis','phase_weights'}):
        raise ValueError('term must contain bounded id, factors and optional phase basis')
    if not isinstance(term['id'],str) or not re.fullmatch('[a-z][a-z0-9_]{1,40}',term['id']):
        raise ValueError('invalid term id')
    factors=term['factors']
    if not isinstance(factors,list) or len(factors)>2:raise ValueError('at most two restricted factors')
    degree=0
    for f in factors:
        if not isinstance(f,dict) or set(f)!={'field','transform'}:raise ValueError('invalid factor structure')
        field,transform=f['field'],f['transform']
        if field not in FIELDS or transform not in TRANSFORMS:raise ValueError('unknown field or transform')
        degree += {'linear':1,'square':2,'signed_square':2,'cube':3,'tanh':1,'abs':1}[transform]
    if degree>4:raise ValueError('unbounded polynomial degree')
    if 'basis' in term:
        if term['basis']!='sin_linear_combination':raise ValueError('unsupported physical basis')
        if not factors or any(f['transform']!='linear' for f in factors):
            raise ValueError('sin phase only supports linear dimensionless measured fields')
        weights=term['phase_weights']
        if not isinstance(weights,list) or len(weights)!=len(factors):
            raise ValueError('phase weights must match measured factors')
        if any(type(w) not in (float,int) or not np.isfinite(w) or abs(w)>8 for w in weights):
            raise ValueError('unbounded or nonfinite phase weights')
        if not any(abs(w)>1e-9 for w in weights):raise ValueError('zero phase is not a physical mechanism')
    return dict(term)


def feature(rows,term):
    term=validate_term(term)
    n=len(rows);values=np.ones(n,float);columns=[]
    for f in term['factors']:
        field,kind=f['field'],f['transform']
        col=[]
        for row in rows:
            if field not in row:raise ValueError('missing independently measured field '+field)
            value=row[field]
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not np.isfinite(value):
                raise ValueError('nonfinite/unmeasured physical input')
            col.append(value)
        v=np.asarray(col,float)/FIELDS[field][1]
        if kind=='square':v=v*v
        elif kind=='cube':v=v*v*v
        elif kind=='tanh':v=np.tanh(v)
        elif kind=='abs':v=np.abs(v)
        elif kind=='signed_square':v=v*np.abs(v)
        columns.append(v)
        values*=v
    if term.get('basis')=='sin_linear_combination':
        phase=np.zeros(n,float)
        for weight,col in zip(term['phase_weights'],columns):phase+=weight*col
        return np.sin(phase)
    return values

def design(rows,terms):
    if not rows: raise ValueError('empty experiment')
    if any(r.get('intervention_type')!='controlled' for r in rows):raise ValueError('passive data is not causal intervention evidence')
    if len({t['id'] for t in terms})!=len(terms):raise ValueError('duplicate mechanism')
    return np.column_stack([feature(rows,t) for t in terms])

def fit(rows,terms,reg=1e-5):
    if len(rows)<max(8,len(terms)*2):raise ValueError('insufficient training interventions')
    if reg<=0:raise ValueError('invalid regularization')
    X=design(rows,terms); y=np.array([r['acceleration'] for r in rows],float)
    if not np.isfinite(y).all():raise ValueError('nonfinite acceleration')
    penalty=np.eye(X.shape[1])*reg
    coef=np.linalg.solve(X.T@X+penalty,X.T@y)
    residual=y-X@coef
    sigma=float(max(np.sqrt(np.mean(residual**2)),1e-4))
    covariance=(sigma*sigma)*np.linalg.inv(X.T@X+penalty)
    return {'terms':terms,'coefficients':coef.tolist(),'covariance':covariance.tolist(),
            'noise_rmse':sigma,'train_count':len(rows),'algorithm':'restricted polynomial feature ridge regression'}

def predict(rows,model):
    return design(rows,model['terms'])@np.asarray(model['coefficients'],float)

def score(rows,model):
    y=np.array([r['acceleration'] for r in rows],float)
    if not np.isfinite(y).all():raise ValueError('nonfinite verification truth')
    return float(np.sqrt(np.mean((predict(rows,model)-y)**2)))

def compare(train_rows,validation_rows,proposals, improvement=0.1):
    """A proposal must improve disjoint episodes and beat a complexity threshold."""
    if not train_rows or not validation_rows:raise ValueError('independent train and validation episodes required')
    train_ids={r['episode_id'] for r in train_rows};val_ids={r['episode_id'] for r in validation_rows}
    if train_ids&val_ids:raise ValueError('validation episode leakage')
    if {r['body_id'] for r in train_rows}!={r['body_id'] for r in validation_rows}:
        raise ValueError('evaluate mechanisms within the same measured body before transfer')
    base=fit(train_rows,BASE);baseline=score(validation_rows,base)
    tested=[];best=base;best_err=baseline;chosen=None
    for p in proposals:
        t=validate_term(p)
        if t['id'] in {item['id'] for item in BASE}:continue
        try:
            model=fit(train_rows,BASE+[t]);err=score(validation_rows,model)
            gain=(baseline-err)/max(baseline,1e-9)
            eligible=bool(err<best_err and gain>=improvement)
            if eligible:best=model;best_err=err;chosen=t['id']
            tested.append({'term':t['id'],'validation_rmse':err,'relative_gain':gain,'supported_by_holdout':eligible})
        except (ValueError,np.linalg.LinAlgError) as e:
            tested.append({'term':t['id'],'status':'NOT_IDENTIFIABLE','reason':str(e)[:180]})
    return {'status':'CANDIDATE_VALIDATED_ON_HELD_OUT_EPISODE' if chosen else 'ABSTAIN_NO_VALIDATED_NEW_MECHANISM',
            'selected':chosen,'baseline_validation_rmse':baseline,'selected_validation_rmse':best_err,
            'tests':tested,'model':best,'never_claim_new_natural_law':True}
