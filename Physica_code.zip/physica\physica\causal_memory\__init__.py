"""Research prototype: action-conditioned shared physical state and transfer."""
