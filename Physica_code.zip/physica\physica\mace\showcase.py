"""Portable OFFLINE evidence exhibit; no external requests or interactivity needed."""
from __future__ import annotations
import html
from pathlib import Path

def render(report):
    rows=[]
    for target in report.get('targets',[]):
        s=html.escape(target['body']);ch=html.escape(target['transfer_choice'])
        e=target['future_camera_rmse_m']*1000
        b=target['target_only_future_camera_rmse_m_same_local_probe_budget']*1000
        win=e<b
        rows.append(f'<tr><td>{s}</td><td>{ch}</td><td>{e:.3f} mm</td><td>{b:.3f} mm</td><td>{"Transfer improved" if win else "Target-only matched or won"}</td></tr>')
    return '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Physica MACE | Evidence Lab</title><style>
:root{color-scheme:dark}body{background:#07101b;color:#e5f3f6;font:16px/1.6 system-ui;margin:0}main{max-width:1050px;margin:auto;padding:35px 25px}.hero{padding:35px;border-radius:24px;border:1px solid #366772;background:linear-gradient(115deg,#102e3e,#102130)}h1{font-size:clamp(33px,7vw,60px);letter-spacing:-.05em;margin:0}h2{margin-top:44px}.muted{color:#a1b7c2}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:15px}.card{border:1px solid #2a4b59;padding:20px;border-radius:14px;background:#102436}.big{font-size:27px;font-weight:800;color:#99ecd2}.warning{background:#3e2b16;color:#ffe6b4;border-left:4px solid #ffc47e;padding:17px;margin:22px 0;border-radius:8px}table{border-collapse:collapse;width:100%;font-size:14px}td,th{border-bottom:1px solid #35505d;padding:13px;text-align:left}th{color:#a7c6cd}code{color:#99ecd2}small{color:#9fb4c0}</style>
<main><div class="hero"><div class="muted">PHYSICA · MACE · ACTION-CONDITIONED CAUSAL EXPERIENCE</div>
<h1>AI that learns what<br><em>the world feels like.</em></h1><p>From measured sensations to competing mechanisms to a prediction for a different body.</p>
<div class="warning"><strong>SYNTHETIC RESEARCH DEMONSTRATION</strong> · This page does not prove live hardware, real-world discovery, authenticated Meta contributions, or independent chronology.</div></div>
<h2>Act I · Mechanism discovery</h2><div class="cards"><div class="card"><div class="muted">Known linear model</div><div class="big">'''+f'{report["A_base_validation_rmse"]:.4f}'+'''</div><small>held-out acceleration RMSE</small></div>
<div class="card"><div class="muted">Proposed physical term</div><div class="big">'''+html.escape(str(report['A_missing_mechanism_selected']))+'''</div><small>validated in a separate episode</small></div>
<div class="card"><div class="muted">After mechanism fitting</div><div class="big">'''+f'{report["A_with_candidate_validation_rmse"]:.4f}'+'''</div><small>held-out acceleration RMSE</small></div></div>
<h2>Act II · Transfer and prospective feeling</h2><p>Machine A's verified candidate is offered to Machines B and C. A short target probe is allowed; future target test observations are generated only after signing the prediction.</p>
<table><thead><tr><th>Receiving body</th><th>Transfer decision</th><th>Physica future error</th><th>Local-only future error</th><th>Honest comparison</th></tr></thead><tbody>'''+''.join(rows)+'''</tbody></table>
<h2>Act III · Diagnose responsibly</h2><div class="cards"><div class="card"><h3>Everyday objects</h3><p>Camera observations and supported telemetry become candidate explanations, safe follow-up checks, and before/after comparisons.</p></div>
<div class="card"><h3>Beyond human senses</h3><p>Motor current, magnetic field, temperature, ultrasound and chemical sensors are eligible where real calibrated hardware exists. Missing-sense estimates are never disguised as measurements.</p></div>
<div class="card"><h3>Meta as scientist</h3><p>Muse can propose a new restricted mechanism and discriminating test. Physica alone fits coefficients and checks held-out evidence. No hosted API calls occurred in this exhibit.</p></div></div>
<p class="muted">Source: locally generated Physica MACE report. A validated numerical candidate in a known simulator is not a newly discovered natural law.</p></main></html>'''

def save(report,out):
    Path(out).write_text(render(report),encoding='utf-8')
