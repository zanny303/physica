"""You set the goal, Physica picks the fix. It chooses the lightest input shaper that still meets your target across every
tone the film allows, refuses if none can, and grades the result on a new film. A missed goal moves on to the next shaper.

Lighter means less corner smoothing, so the lightest shaper that works is the optimum. Shapers as in Klipper's shaper_defs.
"""
from __future__ import annotations

import math

import numpy as np

from physica import seal as _seal

# How far the tone may sit from what the film felt: the head's position and the print's load both shift it a little.
TONE_MARGIN = 0.05
LIGHTEST_FIRST = ("zv", "mzv", "zvd", "ei")
ONLY_MARLIN_M593 = ("zv",)


def impulses(kind: str, f: float, zeta: float) -> tuple[np.ndarray, np.ndarray]:
    root = math.sqrt(1 - zeta ** 2)
    td = 1 / (f * root)
    K = math.exp(-zeta * math.pi / root)
    if kind == "zv":
        return np.array([1, K]), np.array([0, .5]) * td
    if kind == "mzv":
        k = math.exp(-.75 * zeta * math.pi / root)
        a = 1 - 1 / math.sqrt(2)
        return np.array([a, (math.sqrt(2) - 1) * k, a * k * k]), np.array([0, .375, .75]) * td
    if kind == "zvd":
        return np.array([1, 2 * K, K * K]), np.array([0, .5, 1]) * td
    if kind == "ei":
        tol = .05
        a = .25 * (1 + tol)
        return np.array([a, .5 * (1 - tol) * K, a * K * K]), np.array([0, .5, 1]) * td
    raise ValueError(f"unknown shaper {kind}")


def left_over(kind: str, design_hz: float, design_z: float, true_hz: float, true_z: float) -> float:
    """Fraction of the ringing left when a shaper tuned to design_hz meets a head ringing at true_hz."""
    A, t = impulses(kind, design_hz, design_z)
    A = A / A.sum()
    w = 2 * math.pi * true_hz
    wd = w * math.sqrt(1 - true_z ** 2)
    e = A * np.exp(true_z * w * t)
    return float(math.exp(-true_z * w * t[-1]) * math.hypot((e * np.cos(wd * t)).sum(), (e * np.sin(wd * t)).sum()))


def choose(felt: dict, want_drop: float, tried: tuple[str, ...] = (), firmware: str = "klipper") -> dict:
    if not 0 < want_drop < 1:
        raise ValueError("the goal is a drop between 0 and 1, like 0.7 for 70%")
    f, z = float(felt["freq_hz"]), float(np.clip(felt["damping"], .01, .3))
    lo, hi = felt.get("freq_iqr", [f, f])
    grid = np.linspace(min(lo, f * (1 - TONE_MARGIN)), max(hi, f * (1 + TONE_MARGIN)), 21)
    rows = []
    for kind in (ONLY_MARLIN_M593 if firmware == "marlin" else LIGHTEST_FIRST):
        worst = max(left_over(kind, f, z, g, z) for g in grid)
        A, t = impulses(kind, f, z)
        rows.append({"shaper": kind, "worst_drop": round(1 - worst, 3), "smoothing_ms": round(1000 * float(t[-1]), 1), "tried": kind in tried})
    fits = [r for r in rows if not r["tried"] and r["worst_drop"] >= want_drop]
    tone_range = [round(float(grid[0]), 2), round(float(grid[-1]), 2)]
    if not fits:
        return {"status": "NO_SETTING_MEETS_GOAL", "rows": rows, "tone_range_hz": tone_range, "want_drop": want_drop,
                "say": "No untried shaper can promise that across the tone range. Lower the goal or stiffen the printer, or film again for a tighter tone."}
    pick = fits[0]
    return {"status": "CHOSEN", "shaper": pick["shaper"], "rows": rows, "tone_range_hz": tone_range, "want_drop": want_drop, "freq_hz": round(f, 2), "damping": round(z, 4),
            "promised_drop": pick["worst_drop"], "smoothing_ms": pick["smoothing_ms"]}


def ramp_ringing(accel: float, speed: float, f: float, zeta: float, travel: float | None = None) -> float:
    """Ringing left by one speed change: acceleration held for T, seen as two opposed steps. Lower acceleration means a
    gentler push, and if T is a whole number of the head's periods the two steps also partly cancel. Damping limits that
    cancelling, so most of the gain usually comes from the gentler push. On a short move the head may never reach full speed."""
    T = speed / accel
    if travel and speed * speed / accel > travel:
        T = math.sqrt(travel / accel)
    w = 2 * math.pi * f
    wd = w * math.sqrt(1 - zeta ** 2)
    return float(accel / w ** 2 * abs(math.exp(-zeta * w * T) * complex(math.cos(wd * T), math.sin(wd * T)) - 1))


def _film_acceleration(most: float, f: float, speed: float, travel: float, lowest: float = 150.0) -> float | None:
    """The highest test-motion acceleration at or below `most` whose speed-ups last a whole number of cycles."""
    for m in range(1, 200):
        a = speed * f / m
        if speed * speed / a > travel:      # the test move is too short to reach full speed
            a = travel * (f / m) ** 2
        if a < lowest:
            return None
        if a <= most:
            return a
    return None


def choose_acceleration(felt: dict, want_drop: float, wall_speed: float, current_accel: float, tried: tuple[str, ...] = (),
                        film_speed: float = 200.0, film_accel: float = 3000.0, film_travel: float = 20.0, lowest: float = 300.0) -> dict:
    """For printers with no input shaping: the fastest acceleration that still meets the goal on the wall.
    The promise counts only the gentler push (ringing scales with acceleration). Real corners don't change speed cleanly, so
    it takes no credit for cancelling, even though it uses whole-cycle speed-ups to get any that's on offer.
    The filmed test is a cleaner case, so it gets its own forecast across the tone range."""
    if not 0 < want_drop < 1:
        raise ValueError("the goal is a drop between 0 and 1, like 0.7 for 70%")
    if wall_speed <= 0 or current_accel <= 0:
        raise ValueError("wall speed and current acceleration must be positive")
    f, z = float(felt["freq_hz"]), float(np.clip(felt["damping"], .01, .3))
    lo, hi = felt.get("freq_iqr", [f, f])
    grid = np.linspace(min(lo, f * (1 - TONE_MARGIN)), max(hi, f * (1 + TONE_MARGIN)), 21)

    def worst_drop(a, speed, base, travel=None):
        # The starting ringing was really there at the true tone, so it is judged as typical across the range.
        typical = float(np.median([ramp_ringing(base, speed, g, z, travel) for g in grid]))
        return min(1 - ramp_ringing(a, speed, g, z, travel) / max(typical, 1e-12) for g in grid)
    rows = []
    for n in range(1, 41):
        wall = wall_speed * f / n
        if wall > current_accel:
            continue
        if wall < lowest:
            break
        film = _film_acceleration(film_accel * wall / current_accel, f, film_speed, film_travel)   # the same gentler push, on film
        if film is None:
            break
        key = f"accel_{n}"
        rows.append({"shaper": key, "cycles": n, "wall_accel": round(wall), "film_accel": round(film), "tried": key in tried,
                     "worst_drop": round(1 - wall / current_accel, 3), "film_forecast_drop": round(worst_drop(film, film_speed, film_accel, film_travel), 3)})
    tone_range = [round(float(grid[0]), 2), round(float(grid[-1]), 2)]
    fits = [r for r in rows if not r["tried"] and r["worst_drop"] >= want_drop]
    if not fits:
        return {"status": "NO_SETTING_MEETS_GOAL", "rows": rows, "tone_range_hz": tone_range, "want_drop": want_drop,
                "say": "No untried acceleration can promise that. Lower the goal."}
    pick = fits[0]
    return {"status": "CHOSEN", "shaper": pick["shaper"], "rows": rows, "tone_range_hz": tone_range, "want_drop": want_drop, "freq_hz": round(f, 2),
            "damping": round(z, 4), "promised_drop": pick["worst_drop"], "wall_accel": pick["wall_accel"], "film_accel": pick["film_accel"], "cycles": pick["cycles"],
            "film_forecast_drop": pick["film_forecast_drop"]}


def settings(c: dict, axis: str) -> dict:
    a = axis.lower()
    out = {"klipper": f"[input_shaper]\nshaper_freq_{a}: {c['freq_hz']:.1f}\nshaper_type_{a}: {c['shaper']}\n"}
    if c["shaper"] == "zv":
        out["marlin"] = f"M593 {axis.upper()} F{c['freq_hz']:.1f} D{c['damping']:.3f}"
    return out


def seal_goal(text: str, c: dict, axis: str) -> dict:
    extra = {k: c[k] for k in ("wall_accel", "film_accel", "cycles", "film_forecast_drop", "file_in_sha256", "file_out_sha256", "time_forecast") if k in c}
    return _seal.seal({"goal": text, "axis": axis.upper(), "want_drop": c["want_drop"], "shaper": c["shaper"], "freq_hz": c["freq_hz"],
                       "damping": c["damping"], "promised_drop": c["promised_drop"], **extra}, "the goal and the setting chosen for it, before the after film")


def grade(sealed: dict, check: dict) -> dict:
    """check: the printer-video check result on the film made with the setting on."""
    if not _seal.intact(sealed):
        return {"verdict": "INVALID", "met": False, "reason": "the sealed goal was edited"}
    if "ringing_drop_fraction" not in check:
        return {"verdict": "CAN'T TELL", "met": None, "reason": check.get("reason", "no usable after film")}
    want = sealed["payload"]["prediction"]["want_drop"]
    drop = float(check["ringing_drop_fraction"])
    low = check.get("ringing_drop_interval_95_exploratory", [drop, drop])[0]
    verdict = "GOAL MET" if low >= want else ("LOOKS MET, NOT SURE" if drop >= want else "GOAL NOT MET")
    return {"verdict": verdict, "met": low >= want, "drop": round(drop, 3), "drop_low": round(float(low), 3), "want_drop": want, "shaper": sealed["payload"]["prediction"]["shaper"]}
