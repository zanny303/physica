"""Turn video into motion signals the Touch Transform can feel (phase-based, like the visual microphone).

Each pixel's local phase under a complex Gabor filter moves when the edge under it moves, so the phase change is a
sub-pixel motion signal (Wadhwa et al. 2013; Davis et al. 2014). Only textured, high-contrast pixels are kept.
"""
from __future__ import annotations

import numpy as np


def load_gray(path: str, max_frames: int | None = None, roi=None, scale: float = 1.0) -> np.ndarray:
    """Grayscale frames. roi=(x1, y1, x2, y2) in pixels and scale < 1 are applied frame by frame, so a long slow-motion
    clip never has to fit in memory at full size."""
    import cv2

    cap, out = cv2.VideoCapture(str(path)), []
    while max_frames is None or len(out) < max_frames:
        ok, f = cap.read()
        if not ok:
            break
        if roi is not None:
            x1, y1, x2, y2 = (int(v) for v in roi)
            f = f[y1:y2, x1:x2]
        g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
        if scale < 1.0:
            g = cv2.resize(g, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
        out.append(g.astype(np.float32) / 255.0)
    cap.release()
    if not out:
        raise ValueError(f"no frames could be read from {path}")
    return np.stack(out)


def motion(V: np.ndarray, wavelength: float = 4.0, sigma: float = 2.0, direction: str = "vertical",
           step: int = 2, keep: float = 0.3) -> dict:
    """V: (T, H, W) grayscale. Returns per-pixel motion signals (T, P) in pixels, their (row, col) positions and
    contrast weights. direction: the motion direction to sense (perpendicular to the edges that move)."""
    import cv2

    k = int(4 * sigma) | 1
    yy, xx = np.mgrid[-(k // 2):k // 2 + 1, -(k // 2):k // 2 + 1]
    u = yy if direction == "vertical" else xx
    g = np.exp(-(xx ** 2 + yy ** 2) / (2 * sigma ** 2)) * np.exp(1j * 2 * np.pi * u / wavelength)
    gr, gi = g.real.astype(np.float32), g.imag.astype(np.float32)
    R = np.stack([cv2.filter2D(v, -1, gr) + 1j * cv2.filter2D(v, -1, gi) for v in V])
    ref = R.mean(0)
    ph = np.angle(R * np.conj(ref))
    amp = np.abs(ref)[::step, ::step]
    ph = ph[:, ::step, ::step]
    rows, cols = np.mgrid[0:V.shape[1]:step, 0:V.shape[2]:step]
    sel = amp > np.quantile(amp, 1 - keep)
    disp = -ph[:, sel] * wavelength / (2 * np.pi)  # phase -> pixels
    return {"signals": disp - disp.mean(0), "rows": rows[sel], "cols": cols[sel], "weight": amp[sel],
            "shape": V.shape[1:], "step": step}
