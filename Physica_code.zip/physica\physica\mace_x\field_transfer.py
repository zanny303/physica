"""Manifest-driven prospective field transfer with explicit data separation.

Usage:
  python -m physica.mace_x.field_transfer commit --manifest field.json --out forecast.json
  python -m physica.mace_x.field_transfer reveal --forecast forecast.json --outcomes future.csv --out evidence.json

Data files use named CSV columns. The forecast command never loads future.csv;
future.csv is not present in the manifest. This is a local hash commitment, NOT
an independent timestamp, real sensor calibration certificate, or causal proof.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,math
from pathlib import Path
import numpy as np
from .core import (SensorCalibration,calibrated_rows,fit_source_memory,
                   fit_target,predict,posterior_summary)


def _sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def _resolve(root,name):
    if not isinstance(name,str) or not name:raise ValueError('nonempty file path required')
    p=(root/name).resolve()
    if not p.is_relative_to(root.resolve()) or not p.is_file():
        raise ValueError('input file missing or outside manifest directory')
    return p


def _read_csv(p):
    with p.open(newline='',encoding='utf-8-sig') as f:
        rows=list(csv.DictReader(f))
    if not rows:raise ValueError('CSV has no observations')
    return rows


def _parse_sensor(entry):
    if not isinstance(entry,dict):raise ValueError('calibration object required')
    return SensorCalibration(**entry)


def _read_measurements(root,entry):
    path=_resolve(root,entry['measurements'])
    if _sha(path)!=entry['sha256']:raise ValueError('measurement file hash mismatch')
    rows=_read_csv(path)
    cal=_parse_sensor(entry['calibration'])
    out=[]
    for r in rows:
        record={k:r[k] for k in ('body_id','episode_id','modality')}
        record.update({k:float(r[k]) for k in ('x','v','u','observation')})
        if record['body_id']!=entry['id']:raise ValueError('body ID/file mismatch')
        out.append(record)
    return out,cal


def _future_queries(path):
    qs=[];ids=set();episodes=set()
    for r in _read_csv(path):
        i=r.get('query_id','')
        if not i or i in ids:raise ValueError('query IDs must be unique')
        ids.add(i)
        episode=r.get('episode_id','')
        if not episode:raise ValueError('query episode id required')
        episodes.add(episode)
        vals={k:float(r[k]) for k in ('x','v','u')}
        if not np.isfinite(list(vals.values())).all():raise ValueError('nonfinite planned action')
        qs.append({'query_id':i,'episode_id':episode,**vals})
    return qs,episodes


def commit(manifest_path, out):
    path=Path(manifest_path).resolve(); root=path.parent
    obj=json.loads(path.read_text(encoding='utf-8'))
    if obj.get('schema')!='physica.mace_x.field.v014':raise ValueError('wrong manifest schema')
    sources={};calibrations={};source_episodes=set()
    for entry in obj['source_devices']:
        if entry['id'] in sources:raise ValueError('duplicate source ID')
        rows,cal=_read_measurements(root,entry)
        sources[entry['id']]=rows;calibrations[entry['id']]=cal
        source_episodes.update(r['episode_id'] for r in rows)
    target_entry=obj['target'];target_id=target_entry['id']
    if target_id in sources:raise ValueError('target appears in source memory')
    raw_target,tcal=_read_measurements(root,target_entry)
    target=calibrated_rows(raw_target,tcal)
    local_episodes={r['episode_id'] for r in target}
    if local_episodes & source_episodes:raise ValueError('source/target episode identifiers overlap')
    if tcal.provenance != list(calibrations.values())[0].provenance:
        raise ValueError('source and target data origin mismatch')
    if len({c.provenance for c in calibrations.values()})>1:raise ValueError('mixed source origins')
    memory=fit_source_memory(sources,calibrations)
    queries_path=_resolve(root,obj['future_queries'])
    queries,episodes=_future_queries(queries_path)
    if local_episodes & episodes or source_episodes & episodes:
        raise ValueError('future test episodes overlap with fitting data')
    # All sources get a predeclared bounded physical feature library.
    mixed=fit_target(target,memory,mode='mixture',target_id=target_id)
    local=fit_target(target,None,mode='local',target_id=target_id)
    forecast_mixed=predict(mixed,queries);forecast_local=predict(local,queries)
    report={'schema':'physica.mace_x.field_forecast.v014',
            'origin_claimed':obj.get('origin','USER_SUPPLIED_UNVERIFIED'),
            'source_measurement_provenance':memory.provenance,
            'external_calibration_not_authenticated_by_this_software':True,
            'independent_timing_not_attested':True,'test_outcomes_loaded':False,
            'manifest_sha256':_sha(path),'source_memory_sha256':memory.evidence_hash,
            'target_measurements_sha256':target_entry['sha256'],
            'future_queries_sha256':_sha(queries_path),
            'target_id':target_id,'target_calibration':target_entry['calibration'],
            'n_source_devices':len(sources),'n_target_measurements':len(target),
            'target_posterior':posterior_summary(mixed),
            'forecast':[]}
    for i,q in enumerate(queries):
        report['forecast'].append({'query_id':q['query_id'],'episode_id':q['episode_id'],
                'x':q['x'],'v':q['v'],'u':q['u'],
                'mixed_predicted_acceleration':float(forecast_mixed['mean'][i]),
                'mixed_epistemic_sd':float(math.sqrt(forecast_mixed['variance'][i])),
                'target_only_predicted_acceleration':float(forecast_local['mean'][i])})
    # Save by atomic replace, and seal canonical report bytes separately.
    output=Path(out);output.parent.mkdir(parents=True,exist_ok=True)
    report['sha256_without_signature']=hashlib.sha256(json.dumps(report,sort_keys=True,allow_nan=False).encode()).hexdigest()
    from physica.library import sign as _sign
    from datetime import datetime, timezone
    report['sealed_at_utc']=datetime.now(timezone.utc).isoformat(timespec='seconds')
    report['ed25519_signature']=_sign.sign({'sha256':report['sha256_without_signature'],'sealed_at_utc':report['sealed_at_utc']})
    report['anchor']=report['sha256_without_signature'][:16]
    output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return report


def reveal(forecast_path,outcomes_path,out):
    artifact=Path(forecast_path).resolve();f=json.loads(artifact.read_text(encoding='utf-8'))
    if f.get('schema')!='physica.mace_x.field_forecast.v014':raise ValueError('wrong forecast artifact')
    digest=f['sha256_without_signature']
    if 'ed25519_signature' in f:
        from physica.library import sign as _sign
        if not _sign.verify({'sha256':digest,'sealed_at_utc':f['sealed_at_utc']},f['ed25519_signature']):
            raise ValueError('forecast signature does not verify')
    subset={k:v for k,v in f.items() if k not in ('sha256_without_signature','ed25519_signature','sealed_at_utc','anchor')}
    if hashlib.sha256(json.dumps(subset,sort_keys=True,allow_nan=False).encode()).hexdigest()!=digest:
        raise ValueError('forecast integrity mismatch')
    if f.get('test_outcomes_loaded') is not False:raise ValueError('forecast not prospective')
    cal=_parse_sensor(f['target_calibration'])
    rows=_read_csv(Path(outcomes_path))
    seen=set(); observed={}
    for row in rows:
        qid=row.get('query_id')
        if not qid or qid in seen:raise ValueError('duplicate or missing outcome query ID')
        if row.get('modality')!=cal.modality:raise ValueError('outcome modality/calibration mismatch')
        seen.add(qid)
        v=(float(row['observation'])-cal.bias)/cal.gain
        if not math.isfinite(v):raise ValueError('nonfinite outcome reading')
        observed[qid]=float(v)
    expected={q['query_id'] for q in f['forecast']}
    if seen!=expected:raise ValueError('outcomes must match each planned future query exactly')
    y=np.array([observed[p['query_id']] for p in f['forecast']])
    p1=np.array([p['mixed_predicted_acceleration'] for p in f['forecast']])
    p0=np.array([p['target_only_predicted_acceleration'] for p in f['forecast']])
    score={'schema':'physica.mace_x.field_reveal.v014',
           'origin':'USER_SUPPLIED_OUTCOMES_NOT_INDEPENDENTLY_ATTESTED',
           'forecast_file_sha256':_sha(artifact),'forecast_content_commitment_sha256':digest,
           'outcomes_file_sha256':_sha(outcomes_path),
           'n_heldout_future_queries':len(y),
           'mace_x_rmse':float(np.sqrt(np.mean((y-p1)**2))),
           'target_only_rmse':float(np.sqrt(np.mean((y-p0)**2))),
           'mace_x_better_on_this_single_trial':bool(np.mean((y-p1)**2)<np.mean((y-p0)**2)),
           'not_proof_of_new_physics_or_independent_timing':True,
           'calibration_provenance':'USER_DECLARED_IN_FORECAST',
           'no_automatic_hardware_actions':True}
    dest=Path(out);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(score,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return score


def main(argv=None):
    p=argparse.ArgumentParser(description='MACE-X prospective source-to-target field evidence')
    sub=p.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('commit');a.add_argument('--manifest',required=True);a.add_argument('--out',required=True)
    b=sub.add_parser('reveal');b.add_argument('--forecast',required=True)
    b.add_argument('--outcomes',required=True);b.add_argument('--out',required=True)
    x=p.parse_args(argv)
    if x.cmd=='commit':
        result=commit(x.manifest,x.out)
        print(json.dumps({'path':x.out,'future_outcomes_loaded':result['test_outcomes_loaded'],
                          'queries':len(result['forecast'])}))
    else:
        result=reveal(x.forecast,x.outcomes,x.out)
        print(json.dumps({'path':x.out,'mace_x_rmse':result['mace_x_rmse'],
                          'target_only_rmse':result['target_only_rmse']}))
if __name__=='__main__':main()
