# Physica v0.12.1 — Unknown physics + Meta falsification gate

- Corrects v0.12 documentation/code mismatch: **two independent validation episodes now mandatory** for the unknown-mechanism discovery method.
- CSV importer no longer requires temperature in every recording. It preserves truly measured `current`, `magnetic`, `ultrasound` columns with hashes, per-episode channel provenance and explicit missing-channel refusal.
- Residual diagnostics on validation episodes flag *unknown or misspecified dynamics* instead of accepting a merely good-fitting surrogate equation. Adds low-signal floor to avoid numerical false alarms for essentially exact linear models.
- Adds bounded sinusoidal phase candidate family to the mechanism library; Meta can nominate it but can never execute arbitrary generated equations or update physical parameters without data.
- Adds `open_world_meta` with strict official-style structured-output Muse request, secure opt-in for billable API, limited training/validation context, explicit measurement requests and abstention.
- Adds `unknown-investigate` CLI with simulated offline fixture, Meta preview, optional authenticated live Meta nomination, and clear causal validation gates.
- Adds Studio cards for offline Meta hypothesis preview and offline comparison; the Studio still cannot trigger billable model calls.
- Adds independent tests for sensor integrity, unseen-test leakage, structural input boundaries, missing modalities and out-of-grammar residuals.
- Research status: synthetic-method validation only; no authenticated Meta result or real experiment performed.
