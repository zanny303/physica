"""Hosted Meta SAM 3.1 with Meta's official Python segmentation parser.

Docs: https://dev.meta.ai/docs/sam/client-libraries
Uses typed records, not hand-written regex over SAM's mask grammar. No auth
means it fails closed; never returns fake geometry. No physical calibration here.
"""
from __future__ import annotations
from pathlib import Path
import asyncio,hashlib,os
from contextlib import aclosing


def box_tracks_from_parsed(result):
    if result.outcome.status!='completed':
        raise RuntimeError('incomplete SAM segmentation; refusal')
    if any(getattr(d,'severity','')=='error' for d in result.diagnostics):
        raise RuntimeError('SAM parser reported malformed records')
    rows=[]
    for r in result.records:
        if r.kind!='box':continue
        if r.frame is None:raise ValueError('video geometry requires a frame identity')
        coords=[float(r.left),float(r.top),float(r.right),float(r.bottom)]
        if coords[2]<=coords[0] or coords[3]<=coords[1]:raise ValueError('degenerate geometry')
        rows.append({'frame':int(r.frame.frame_index),'object_id':int(r.object_id),
                     'x_center_px':(coords[0]+coords[2])/2,
                     'y_center_px':(coords[1]+coords[3])/2,
                     'box_px':coords,
                     'confidence':getattr(r,'confidence',None)})
    if not rows:raise RuntimeError('no SAM track found; cannot invent a sensor')
    return rows


async def _events(stream):
    # Follow the current Meta official cookbook: the server can finish a text
    # part using content_part.done, while parser expects output_text.done.
    completed=set()
    async for ev in stream:
        d=ev.model_dump() if hasattr(ev,'model_dump') else dict(ev)
        lane=(d.get('item_id'),d.get('output_index'),d.get('content_index'))
        if d.get('type')=='response.output_text.done':
            if lane not in completed:
                completed.add(lane);yield d
            continue
        yield d
        part=d.get('part')
        if (d.get('type')=='response.content_part.done' and lane not in completed and
            isinstance(part,dict) and part.get('type')=='output_text' and isinstance(part.get('text'),str)):
            completed.add(lane)
            yield {'type':'response.output_text.done','item_id':d.get('item_id'),
                   'output_index':d.get('output_index'),'content_index':d.get('content_index'),
                   'text':part['text']}


async def segment_video_async(video_path,*,concept):
    if not isinstance(concept,str) or not concept.strip() or len(concept)>90 or '\n' in concept:
        raise ValueError('SAM concept must be short object noun phrase')
    path=Path(video_path)
    if not path.is_file() or path.suffix.lower() not in ('.mp4','.mov'):
        raise FileNotFoundError('expected existing .mp4/.mov video')
    key=os.getenv('MODEL_API_KEY')
    if not key:raise RuntimeError('MODEL_API_KEY missing; cannot call real Meta API')
    try:
        from openai import AsyncOpenAI
        from meta_sam_parser import parse_responses_stream,video_segmentation_format
    except ImportError as e:
        raise RuntimeError('pip install -e ".[meta]" to use SAM parser') from e
    async with AsyncOpenAI(base_url='https://api.meta.ai/v1',api_key=key) as api:
        import mimetypes
        uploaded=await api.files.create(file=(path.name,path.read_bytes(),mimetypes.guess_type(path.name)[0]),purpose='user_data')
        stream=await api.responses.create(model='sam-3.1',stream=True,input=[{'type':'message','role':'user','content':[
            {'type':'input_text','text':concept.strip()}, {'type':'input_video','file_id':uploaded.id}]}])
        async with stream,aclosing(_events(stream)) as ev:
            parsed=parse_responses_stream(ev,video_segmentation_format())
            async with parsed:
                # Drain event iterator before requesting final_result.
                async for _ in parsed:pass
                result=await parsed.final_result()
    tracks=box_tracks_from_parsed(result)
    return {'model_id':'sam-3.1','mode':'LIVE_META_API_OFFICIAL_PARSER',
           'concept':concept,'video_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
           'boxes':tracks,'segmentation_records':len(result.records),
           'parser_diagnostics':[{'code':d.code,'severity':d.severity} for d in result.diagnostics],
           'warning':'pixel tracks only; independently calibrated camera geometry and clock required'}


def sam_video_official(video_path,*,concept):
    return asyncio.run(segment_video_async(video_path,concept=concept))
