# Physica — Meta Global AI Developer Hackathon 2026

## Submission title
**Physica: A Language for Physical Experience**

**Tagline:** One machine learns from a physical intervention. Another machine understands the consequence through a different sense—and tests it before trusting it.

**Track focus:** Push the Frontier: give machines a new physical capability; reduce experiments needed to identify dynamics and make safe decisions.

## Accurate claim to make on submission day

Physica integrates calibration-grounded sensing, causal hypothesis checks, candidate cross-body transport, signed predictions and physically meaningful refusals. In an offline reproducible simulation, a machine with acoustic/IMU observations teaches a second machine to predict visual response; a third receives an updated physical prior. The program demonstrates its safety/uncertainty limits. A **real hardware experiment and a live Meta Model API execution are not included** unless the developer independently runs, documents and records them before submitting.

## The 3-minute demo script (requires real footage if presented as real)

**0:00–0:15 — The question:** "AI can describe what a camera sees. But can it discover what force did to an object, then teach another machine what that would feel like?"

**0:15–0:38 — Machine A:** show source video, audio and IMU with calibration; Spark identifies which components and confounders matter. SAM tracks the component and the independent instrument confirms optical motion. In current offline build, show the red **SYNTHETIC** label instead of pretending to have live footage.

**0:38–1:05 — Physical words:** overlay action, measured consequences, confidence, evidence hashes and boundaries. Compare FFT-only view to Physica's mechanistic innovation/causal hypothesis view. Mention that novelty is NOT FFT or a known modal residual formula.

**1:05–1:32 — Machine B:** change body calibration and sensing from acoustic to optical. Show PEL normalizing A's response; B's forecast appears, hashed before B's experiment. Do the experiment safely and independently, then reveal measurements and errors. In offline mode this scene is simulator-only.

**1:32–1:52 — Muse as scientist:** Spark contextualizes; SAM measures geometry; Wonder proposes rival causes and an authorized reversible probe. Physica decides with a hard numerical gate. Show a deliberately ambiguous example and **UNKNOWN / cannot translate** when necessary.

**1:52–2:18 — Machine C:** B becomes a new source of evidence. Compare the candidate A+B memory against nearest-source, physics-only, local-only and A-only baselines. Display honest shifted-dynamics failures and rejection.

**2:18–2:40 — Every sense is a physics channel:** six tiles: sight, hearing, touch, proprioception, smell, taste. Demonstrate working mechanical operators, while labelling chemical representation **typed-only** rather than pretending a functional electronic nose/tongue.

**2:40–3:00 — Why it matters:** "The long-term prize isn't machines that chat about physics. It's machines that experimentally discover physical relationships and teach each other those relationships with evidence and uncertainty."

## Creative use of Meta AI must be demonstrable, not decorative

1. Spark changes the set of relevant hypotheses in a deliberately ambiguous scene. Evaluate hypothesis recall/precision with/without Spark on an independently labeled set; do not report assumed model advantage.
2. SAM produces tracked geometry which enters the *numeric* CSG sensor model ONLY if calibrated and independently cross-checked. Compare part localization and physical prediction error with/without SAM.
3. Wonder proposes safe, discriminating experiments from the confirmed physical facts. Compare experiments-to-identification and refusal quality with/without Wonder.
4. V-JEPA 2 provides candidate visual-world futures only through a separate deployment and a held-out numerical readout. Measure its incremental information gain; don't use it as an invented force meter.
5. Muse Glimmer/Voice/Image are optional additions for local descriptions, audio transcription and art—not required for a numerically grounded contribution. No unvalidated "five hosted models working" assertion.

## Judge-facing evidence checklist

- Publish one independently witnessed, *real* A→B→C prediction chain with timestamps and complete raw measurements.
- Include calibration report and a test where the physical language correctly refuses an incompatible machine.
- Include same-body different-sensor ablations, cross-body leave-one-out evaluation, hidden-dynamics shift tests and a fair stronger baseline.
- Include Meta output hashes and model IDs from actual paid API calls; use the owner-managed API key and private environment variable.
- Include failures and outside-distribution examples. Do not call synthetic-only improvements "real-world results."
- Show at least one genuinely hardware-verified improvement in experiment count, prediction error, or controlled system setup.

## Beyond the hackathon: research roadmap

**Research question:** Can an intervention-conditioned representation be simultaneously (a) physically identifiable across different sensors, (b) transportable between calibrated bodies, (c) uncertainty-aware under distribution shift, and (d) data-efficient relative to strong classical and deep baselines?

The present code provides a falsifiable first benchmark and field protocol. Breakthrough status requires held-out real measurements, much more variety in physical mechanisms, error/coverage improvements under domain shift, formal identifiability work, and external replication. Neither winning the hackathon nor publishing original mathematical results can be guaranteed.
