"""CIRTE v0.5: Causal Interventional Representation & Transfer of Experience.

New RESEARCH COMPOSITION (not a new physical theorem). Separate: mechanistic
response, calibrated sensor, signed prior experience, applicability + abstention.
Acts on a *prediction* only; never drives motors or treats LLM prose as physics.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib,json
from physica.library import sign as _sign
from math import isfinite
import numpy as np
from scipy.interpolate import CubicSpline
from .observation import CalibratedSensor
from .language import ExperienceEnvelope,verify_record,unsupported_translation
from .signals import MechanicalContext

@dataclass(frozen=True)
class TransferPolicy:
    frequency_ratio_min: float=.5
    frequency_ratio_max: float=2.
    damping_absolute_max: float=.025
    maximum_normalized_error: float=.15
    sigma_probe_threshold: float=3.
    max_normalized_uncertainty: float=.25
    local_probe_required: bool=True
    def __post_init__(self):
        v=[self.frequency_ratio_min,self.frequency_ratio_max,self.damping_absolute_max,
           self.maximum_normalized_error,self.sigma_probe_threshold,self.max_normalized_uncertainty]
        if any(not isfinite(x) or x<=0 for x in v) or self.frequency_ratio_min>=self.frequency_ratio_max:
            raise ValueError('invalid transfer policy')


def transfer_validity(envelope, target:MechanicalContext, observer:CalibratedSensor|None,
                      *, probe_normalized_error=None,probe_sigma=None,
                      target_calibration_verified=True,policy=TransferPolicy(),
                      probe_evidence_sha256=None,probe_origin="simulation"):
    """'transfer' / 'probe_first' / 'refuse'. Compatible is NOT proven safe.

    Physical mismatch is checked against signed PEL. Probe evidence, when
    supplied, is an INDEPENDENT, predeclared low-energy target observation.
    """
    if not verify_record(envelope):return {'status':'refuse','reason':'invalid_source_provenance'}
    s=ExperienceEnvelope.model_validate(envelope).word
    if target.provenance=='real_sensor' and s.provenance!='real_sensor':
        return {'status':'refuse','reason':'simulation_cannot_authorize_real_machine_transfer'}
    if s.claim_status!='verified_local_intervention':return {'status':'refuse','reason':'source_not_verified'}
    if not target_calibration_verified or observer is None or not observer.calibration_id:
        return {'status':'refuse','reason':'missing_independent_target_calibration'}
    if target.boundary_class!=s.boundary_class or target.action_family!=s.action_family:
        return {'status':'refuse','reason':'different_causal_intervention_domain'}
    ratio=target.fundamental_hz/s.natural_frequency_hz
    if (not policy.frequency_ratio_min<=ratio<=policy.frequency_ratio_max or
        abs(target.damping_ratio-s.damping_ratio)>policy.damping_absolute_max):
        return {'status':'refuse','reason':'outside_mechanical_transfer_domain'}
    if probe_normalized_error is None:
        return {'status':'probe_first','reason':'matched_approximations_cannot_exclude_hidden_dynamics',
                'local_probe_mandatory':True}
    if probe_sigma is None or not all(isfinite(x) for x in (probe_normalized_error,probe_sigma)) or probe_sigma<=0:
        return {'status':'refuse','reason':'untrusted_probe_error_or_uncertainty'}
    z=abs(probe_normalized_error)/probe_sigma
    if z>policy.sigma_probe_threshold or abs(probe_normalized_error)>policy.maximum_normalized_error:
        return {'status':'refuse','reason':'low_force_probe_detected_domain_shift',
                'standardized_disagreement':float(z)}
    if target.provenance!='simulation' and (not isinstance(probe_evidence_sha256,str) or
            len(probe_evidence_sha256)!=64 or any(c not in '0123456789abcdef' for c in probe_evidence_sha256) or
            probe_origin!='independent_low_force_measurement'):
        return {'status':'probe_first','reason':'real_hardware_requires_recomputed_raw_probe'}
    if probe_sigma>policy.max_normalized_uncertainty:
        return {'status':'probe_first','reason':'probe_too_uncertain_to_validate_transfer',
                'standardized_disagreement':float(z)}
    # Bind the decision to the *exact* source body, target, sensor,
    # measured-probe digest and numeric policy. A forged status cannot pass.
    facts={'source_sha256':envelope['word_sha256'],
           'target':asdict(target),'sensor':asdict(observer),
           'policy':asdict(policy),'probe_error':float(probe_normalized_error),
           'probe_sigma':float(probe_sigma),'probe_evidence_sha256':probe_evidence_sha256,
           'probe_origin':probe_origin}
    digest=hashlib.sha256(_sign.canonical(facts)).hexdigest()
    return {'status':'transfer','reason':'conditional_transfer_after_independent_low_force_check',
            'standardized_disagreement':float(z),'not_guaranteed_safe':True,
            'bound_facts':facts,'bound_digest':digest,
            'signature_ed25519':_sign.sign({'bound_digest':digest,'facts':facts})}


def predict_target_sense(envelope,target:MechanicalContext,observer:CalibratedSensor,times_s,
                         *,transfer_decision):
    """Prediction in calibrated target sensor units from dimensionless source.

    Mechanistic (x,v) action response is transported; target sensor's independently
    calibrated H then maps it into camera displacement, microphone pressure, etc.
    This is *not* text translation and not uncalibrated multisensory inference.
    """
    # Never trust a plain caller-provided 'transfer' status. Verify the
    # signing key AND recompute compatibility for this exact target and sensor.
    if not isinstance(transfer_decision,dict) or transfer_decision.get('status')!='transfer':
        return unsupported_translation('transfer_not_authorized_by_validity_gate')
    facts=transfer_decision.get('bound_facts')
    if not isinstance(facts,dict):return unsupported_translation('unsigned_or_unbound_transfer_authorization')
    digest=hashlib.sha256(_sign.canonical(facts)).hexdigest()
    if (digest!=transfer_decision.get('bound_digest') or
        not _sign.verify({'bound_digest':digest,'facts':facts},transfer_decision.get('signature_ed25519',''))):
        return unsupported_translation('invalid_transfer_authorization_signature')
    if (facts.get('source_sha256')!=envelope.get('word_sha256') or
        facts.get('target')!=asdict(target) or facts.get('sensor')!=asdict(observer)):
        return unsupported_translation('transfer_authorization_not_bound_to_this_target')
    try:
        regate=transfer_validity(envelope,target,observer,
          probe_normalized_error=facts['probe_error'],probe_sigma=facts['probe_sigma'],
          probe_evidence_sha256=facts.get('probe_evidence_sha256'),
          probe_origin=facts.get('probe_origin','simulation'),
          policy=TransferPolicy(**facts['policy']))
    except (ValueError,TypeError,KeyError):
        return unsupported_translation('invalid_transfer_policy_or_probe')
    if regate.get('status')!='transfer' or regate.get('bound_digest')!=digest:
        return unsupported_translation('transfer_compatibility_recomputed_as_refuse')
    if not verify_record(envelope):return unsupported_translation('source_hash_invalid')
    word=ExperienceEnvelope.model_validate(envelope).word
    t=np.asarray(times_s,dtype=float)
    if t.ndim!=1 or len(t)<5 or not np.all(np.isfinite(t)) or t[0]<0 or np.any(np.diff(t)<=0):
        return unsupported_translation('invalid_target_time_axis')
    tau=t*target.fundamental_hz
    src_tau=np.asarray(word.normalized_time,dtype=float)
    if tau[0]<src_tau[0]-1e-9 or tau[-1]>src_tau[-1]+1e-9:
        return unsupported_translation('extrapolation_outside_experiment')
    spline=CubicSpline(src_tau,np.asarray(word.normalized_response),bc_type='natural')
    # S = F/k is displacement scale; d/dt = f * d/dtau.
    scale=target.applied_force_n/target.stiffness_n_m
    displacement=scale*spline(tau)
    velocity=scale*target.fundamental_hz*spline(tau,1)
    lo,hi=observer.validated_state_range
    vlo,vhi=observer.validated_velocity_range
    if (np.any(displacement<lo) or np.any(displacement>hi) or
        np.any(velocity<vlo) or np.any(velocity>vhi)):
        return unsupported_translation('forecast_beyond_target_sensor_calibration')
    H=np.asarray(observer.state_gains)
    values=H[0]*displacement+H[1]*velocity+observer.offset
    if not np.all(np.isfinite(values)):return unsupported_translation('numeric_overflow')
    # Important: source posterior over physical dynamics is not calibrated for
    # sensor-domain derivative; sensor noise is a lower bound, NOT a 90% interval.
    return {'status':'conditional_sensor_prediction','sensor_id':observer.sensor_id,
            'target_body':target.body_id,'source_body':word.source_body_id,
            'observable_unit':observer.output_unit,'time_s':t.tolist(),
            'expected_values':values.tolist(),
            'observer_noise_std':observer.noise_std,
            'full_prediction_interval':None,'full_interval_status':'UNCALIBRATED_MISMATCH',
            'source_hash':envelope['word_sha256'],
            'requires_signed_prospective_verification':True,
            'hardware_actuation_allowed':False}


def unknown_mechanism_test(observed,known_predictions,*,noise_std,
                           reference_calibration_errors,quantile=.99):
    """Open-world mismatch test calibrated by independent residual examples.

    Returns UNKNOWN when best known mechanism fits worse than held-out
    reference scores. Does not discover new laws nor pretend an LLM did.
    """
    y=np.asarray(observed,dtype=float)
    ref=np.asarray(reference_calibration_errors,dtype=float)
    if y.ndim!=1 or len(y)<5 or not np.all(np.isfinite(y)) or ref.ndim!=1 or len(ref)<20 or not np.all(np.isfinite(ref)) or np.any(ref<0):
        raise ValueError('need finite held-out reference errors and observed trace')
    if not isfinite(noise_std) or noise_std<=0 or not .5<=quantile<1:
        raise ValueError('invalid noise reference')
    if not known_predictions:raise ValueError('at least one known physical mechanism')
    distances={}
    for name,v in known_predictions.items():
        x=np.asarray(v,dtype=float)
        if x.shape!=y.shape or not np.all(np.isfinite(x)):
            raise ValueError('known candidate prediction mismatch')
        distances[name]=float(np.sqrt(np.mean(((y-x)/noise_std)**2)))
    min_error=min(distances.values());threshold=float(np.quantile(ref,quantile))
    return {'status':'unknown_mechanism_or_sensor_failure' if min_error>threshold else 'known_mechanism_not_rejected',
            'best_candidate':min(distances,key=distances.get),
            'best_standardized_rms':min_error,'heldout_threshold':threshold,
            'calibration_reference_size':len(ref),'candidate_scores':distances,
            'next_step':'inspect sensor and request new independently testable model' if min_error>threshold else 'further experiments still required',
            'limitation':'holdout mismatch detector; cannot distinguish sensor fault vs novel physics without independent test',
            'hardware_actuation_allowed':False}


def executable_contract(envelope,*,action_semantics,accepted_action_families,
                        sensor_contract_ids,hardware_limits):
    """Hardware-neutral decision contract, no code execution or actuator IO."""
    if not verify_record(envelope):raise ValueError('unsigned or tampered source contract')
    if not isinstance(action_semantics,str) or not action_semantics:raise ValueError('effect semantics required')
    if not accepted_action_families or not sensor_contract_ids:raise ValueError('approved action+sensor capabilities required')
    if not isinstance(hardware_limits,dict) or not hardware_limits:
        raise ValueError('independent numeric hardware limit required')
    for k,v in hardware_limits.items():
        if not isinstance(k,str) or not k or not isinstance(v,(int,float)) or isinstance(v,bool) or not np.isfinite(v) or v<=0:
            raise ValueError('invalid hard hardware limit')
    word=ExperienceEnvelope.model_validate(envelope).word
    return {'schema':'physica.cirte/0.5','status':'abstract_action_contract',
            'desired_physical_effect':action_semantics,'source_experience_sha256':envelope['word_sha256'],
            'requires_action_family':word.action_family,
            'available_approved_families':list(accepted_action_families),
            'available_calibrated_sensors':list(sensor_contract_ids),
            'external_hard_limits':hardware_limits,
            'action_permitted':False,'requires_local_probe':True,
            'rule':'no control commands are generated; an independent hardware safety layer must authorize actions'}
