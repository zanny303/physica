"""Physically separate chemical sensing from modal vibration analysis.

Minimal validated-data interface for e-nose concentration and electrochemical
measurement time series. A first order *sensor response* is not proof of
chemical identity. No simulated chemistry is described as actual sensing.
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import least_squares
from .signals import Channel

def chemical_step_response(channels,*,step_at_s,observable='gas_concentration'):
    channels=list(channels)
    if not channels or any(c.observable!=observable for c in channels):
        raise ValueError('requires same calibrated chemical observable (no mixing pH and VOC)')
    if observable not in ('gas_concentration','conductivity'):
        raise ValueError('this time-constant model requires concentration or conductivity')
    if not np.isfinite(step_at_s):raise ValueError('finite experiment step time')
    reports=[]
    for c in channels:
        t=np.asarray(c.time_s);v=np.asarray(c.values)
        if sum(t<step_at_s)<5 or sum(t>step_at_s)<8:
            raise ValueError('requires baseline and post-step samples')
        t0=t-step_at_s;before=v[t0<0]
        baseline=float(np.median(before));after_t=t0[t0>=0];after=v[t0>=0]
        # Transparent 2-parameter sensor-lag fit: baseline + change*(1-exp(-t/tau)).
        def residual(params):
            amplitude,tau=params
            return (baseline+amplitude*(-np.expm1(-after_t/tau))-after)/c.sigma
        x0=[float(np.median(after[-5:])-baseline),max(float(np.median(np.diff(t)))*3,1e-4)]
        upper=max(float(after_t[-1])*20,1e-3)
        res=least_squares(residual,x0=x0,bounds=([-np.inf,1e-5],[np.inf,upper]))
        amplitude,tau=res.x
        reports.append({'sensor_id':c.sensor_id,'modality':c.modality,'observable':c.observable,
            'unit':c.unit,'baseline':baseline,'step_amplitude':float(amplitude),
            'apparent_sensor_tau_s':float(tau),'residual_rms_sigma':float(np.sqrt(np.mean(res.fun**2))),
            'source_sha256':c.source_sha256,'calibration_id':c.calibration_id,
            'warning':'sensor response time, not uniquely material or gas identity'})
    return {'status':'calibrated_chemical_dynamics_unidentified_species','measurements':reports,
            'no_molecule_identification':True,'no_cross_physics_modal_analogy':True}
