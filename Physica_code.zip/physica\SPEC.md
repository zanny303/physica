# Physica: build spec

**Physica: how AI feels the world.**
For the Meta Global AI Developer Hackathon 2026, Indie track ("Push the Frontier").
Built Oct 26 – Nov 4, 2026. Submit by **3:00 PM CT, Nov 4** (official deadline 8:00 PM CT).

This file is the single source of truth for the build. Build in priority order: **P0 → P1 → P2**. A P0 that works end to end beats ten half-built P2s.

---

## 0. What Physica is (read this first)

**One line:** Point Physica at any machine's signals. It learns what that machine *should* feel, then feels everything it didn't cause: damage, imbalance, touch, wear. It proves each claim against reality, saves it as signed knowledge other machines can check and reuse, and translates it into the machine's own language (ArduPilot settings, PLC code, G-code).

**The core insight (efference copy):** you can't tickle yourself because your brain predicts the touch your own movement causes and cancels it. Physica gives machines the same trick:
- A proven self-model predicts the machine's self-caused signals.
- The leftover is what it **feels**.
- Every proven model becomes a new sense.

**The core algorithm is the Feel Transform** (§3). It's the "FFT for feeling": any sensor stream becomes a **feelogram**, which is feelings over time in physical units, separating self from world.

**Hero use case:** **Feel Check**, a 30-second test for anything mechanical, before you buy it, fly it or fix it. Line: "Looks fine isn't works fine." Shown on **real public data**: drone flights with damaged propellers, and a motor shaft with known imbalances.

**Pitch lines:**
- "AlphaEvolve needs an automatic judge. Physica turns reality into one."
- "No machine should have to break to learn what breaking feels like."
- "Knowledge that compounds, and checks itself."
- "One discovery, every machine's language."

---

## 1. Hard rules (break these and we can lose)

1. **Repo:** public on GitHub, Apache-2.0 licence, Python 3.12. The README's first line is: "Built Oct 26 – Nov 4, 2026 for the Meta Global AI Developer Hackathon." Commit early and often; history proves the dates.
2. **Secrets:** no API keys in the repo, ever. Use `.env` (gitignored) plus `.env.example`.
3. **Meta Model API:**
   - Wrap every call in `physica/llm/meta_client.py`.
   - Read model IDs from `.env`. **Do not invent endpoints or model IDs.** Ask Zanea for the official docs if unsure.
   - Provide a `MOCK=1` mode so everything runs offline.
   - Add a **cost meter that hard-stops at $120 total** (spend alerts don't stop billing).
4. **Muse Spark Open is never used on anything that commands hardware** (licence restriction). Glimmer (Apache-2.0) and the API models are fine.
5. **LLM-written code** (theories, sensor programs) runs only in a sandbox:
   - subprocess, 10 s timeout, no network
   - an AST denylist (`os`, `subprocess`, `socket`, `eval`, `exec`, `open` outside a temp dir, `__import__`)
   - inputs and outputs as numpy arrays only
6. **Honesty in every output:**
   - Only numbers produced by this repo's `eval/` scripts appear in the README or video.
   - Say "to our knowledge", never "first".
   - Label pilot results as pilot.
   - Feel Check output says "advice, not a safety certification."
7. **Datasets:** don't commit raw data. Document download steps and check each licence in `DATA.md`.
8. **Reproducibility:**
   - Fixed seeds and fixed train/test splits written to `eval/splits.json`.
   - Every reported number has a bootstrap 95% confidence interval (use `rliable` interquartile mean where it applies).
9. **Prediction commits:** before each demo reveal, commit the prediction (`predictions/*.json`, with timestamp) *then* run the reveal.

---

## 2. Data (P0 needs PADRE and Fraunhofer)

### 2.1 PADRE: real drone flights with damaged propellers (P0)
- **Source:** https://github.com/AeroLabPUT/UAV_measurement_data
  - Clone with `GIT_LFS_SKIP_SMUDGE=1 git clone --depth 1 …` (about 6.8 GB).
- **Use `Parrot_Bebop_2/Raw_data/Bebop2_16g_1kdps_raw_ABCD.csv`.** (The 3DR_Solo raw files are undocumented binary; skip them.)
- **Filename code `ABCD`:** one digit per rotor A, B, C, D.
  - 0 = OK, 1 = chipped edge, 2 = bent tip, 3 = cut-off tip, 4 = bent + cut.
  - Rotor layout (from the README): A front-right, B rear-right, C front-left, D rear-left.
- **Format:**
  - Each line is 96 hex characters = 48 bytes = **24 big-endian int16 values**.
  - Order: for arm A, then B, C, D: `[acc_x, acc_y, acc_z, gyro_x, gyro_y, gyro_z]`. There is one IMU per arm.
  - **500 Hz**; 86,016 lines ≈ 172 s per file.
- **Files present:** 0000; single-rotor faults (1000–4000, 0100–0400, 0010–0040, 0001–0004); plus combinations (0022, 0102, 0120, 0122, 1002, 1020, 1022, 1100, 1102, 1120, 1122).
- **Splits:**
  - Healthy file 0000: first half = calibration ("arrival"), second half = held-out healthy test.
  - Use 5 s windows.
- **Pilot results to reproduce, not to quote until reproduced:**
  - Narrowband rise on the damaged rotor's own arm: +8 to +19 dB around 125–150 Hz.
  - A self-model (log peak power vs peak frequency, quadratic, per arm, fitted on healthy calibration only) flagged damage on rotors B, C and D in ~76% of windows, with 0 false alarms on held-out healthy.
  - A random forest trained on rotor-A damage scored ~81%.
- **Known limit:** passive localisation of *which* rotor was unreliable (~38%). The flight controller changes the other rotors' speeds, and there's no motor-RPM data. Physica must *say* this ("I can't localise from flight data; run a single-motor spin test or provide ESC RPM telemetry").

### 2.2 Fraunhofer unbalance dataset: real shaft, known imbalances (P0)
- **Source:** Fordatis (Fraunhofer IIS/EAS), "Vibration measurements on a rotating shaft at different unbalance strengths". Paper: arXiv 2005.12742. Zanea downloads it.
- **Contents:**
  - EC DC motor driving a shaft through a roller bearing; vibration at **4096 Hz**.
  - Files `0D–4D` (development, about 107 min each, ~630–2330 rpm) and `0E–4E` (evaluation, 28 min each, ~1060–1900 rpm).
- **Unbalance levels:** 0 = none; 1 = 3.281 g at 14 mm; 2 = 3.281 g at 18.5 mm; 3 = 3.281 g at 23 mm; 4 = 6.614 g at 23 mm.
  - So m·r ≈ **0, 45.9, 60.7, 75.5, 152.1 g·mm**: the ground truth for the wobble axis.
- Inspect the README and CSV headers first. Column names (including any speed signal) must be read from the files, not assumed.

### 2.3 Optional (P2)
- **MAFAULDA:** real rotor rig with imbalance weights, plus accelerometers, microphone and tachometer. Gated on Hugging Face (AI4Manufacturing).
- **Live phone sensing:** the free **phyphox** app's remote-access HTTP interface (`http://<phone-ip>:8080/get`, Android default port) for a live Feel Check on a desk fan.
- **Real ArduPilot `.bin` flight logs:** only with the owner's permission, for the filter-replay beat.

---

## 3. The Feel Transform (P0, the core algorithm)

`physica/feel/feel_transform.py`

```
FeelTransform(sense_cards, self_model=None).fit(calib_streams, calib_commands=None)
FeelTransform.transform(streams, commands=None, clock=None) -> Feelogram
```

**Input:** a dict of channels (numpy arrays plus sample rate plus units from sense cards); optional machine commands `u(t)` (the efference copy); optional clock or phase signal.

**Step 1: Unify** (`senses/`)
- Resample to a common rate, apply units and known delays, and record noise floors.
- A **sense card** (JSON) stores: channel, units, sample rate, delay, noise, calibration source.

**Step 2: Self-cancel** (`feel/selfmodel.py`, `feel/dmd.py`)
- Predict the self-caused signal and output the residual `r = y − ŷ`. Three modes, in order of preference:
  - (a) A **proven self-model** from the library or the discover loop (§4) → physics prediction.
  - (b) **DMD with control** (DMDc, Proctor/Brunton/Kutz) on delay-embedded (Hankel) data, fitted on healthy calibration data, when commands `u` exist. Use `pydmd` (pin the version) or a ~60-line numpy implementation.
  - (c) **Operating-point self-model** when no commands exist (PADRE): per channel, predict the band level at the current operating point (e.g. dominant-peak frequency), fitted on healthy data only. This is what the pilot used.
- Output a per-channel **z-score** with a threshold calibrated on held-out healthy data. Target: ≤1% false-alarm windows.

**Step 3: Re-time to the machine's clock** (`feel/order.py`)
- If a speed or phase signal exists (Fraunhofer speed column, a tachometer, or a tracked rotation peak), resample to the angle domain (orders). This makes feelings speed-invariant.
- If none exists, skip and set `speed_invariant=false` in the output.

**Step 4: Modes** (`feel/dmd.py`)
- Windowed Hankel-DMD on the residual and on the full signal.
- Each mode has: frequency (Hz or order), damping ratio, growth rate (per second), shape vector across channels, amplitude.
- Keep the top-k modes by energy.

**Step 5: Read as feelings** (`feel/axes.py`)
- Map modes and residuals onto **7 feel axes**. Each value has units and a confidence interval, or is marked `"uncalibrated"` and shown in sensor units.
- **P0 must deliver at least `wobble_gmm` (calibrated) plus `touch_impact` and `wear_drift`.** Others are P1/P2.

| axis | meaning | P0 implementation |
|---|---|---|
| `weight` | inertia / added mass | P2 (needs proven rig model) |
| `stiffness` | hardness | P2 |
| `damping` | softness | P1: from mode damping ratio |
| `friction` | roughness / stick-slip | P2 |
| `wobble_gmm` | imbalance in **g·mm** | **P0** (below) |
| `touch_impact` | outside events | **P0**: residual transients over threshold |
| `wear_drift` | slow change of any axis or mode | **P0**: trend of mode frequency/damping/level vs healthy baseline, with growth rate |

**Wobble in physical units:**
- Unbalance force F = (m·r)·ω².
- The 1× (order-1) vibration amplitude is a₁ ≈ (m·r)·ω²·|H(ω)|, where H is the structure's response.
- Calibrate |H| from healthy data plus **one** known level. **Use only Fraunhofer level 1 (45.9 g·mm) for calibration.** Then predict levels 2–4 and report error in g·mm on the evaluation files. Also report against the speed range (dev vs eval).

**Display bands** (like the mel scale for hearing): optional "skin bands" mimic human mechanoreceptors:
- static pressure (<5 Hz)
- flutter/slip (~10–60 Hz)
- vibration (~100–500 Hz, clipped to Nyquist)

**Output:** the `Feelogram` object holds: time × axes matrix, modes per window, z-scores, flags, and a JSON export. Also add `plot_feelogram()` (matplotlib): the signature graph. Colour = strength; healthy band shaded; events marked.

---

## 4. Discover and prove: the Physica Loop (P0 core, P1 extras)

`physica/discover/`

1. **Relatives** (`library/recall.py`): retrieve similar cards by machine type, sensor set and mode signature.
2. **Propose** (`theories.py`, Muse Spark):
   - Given data summaries, plots and modes, ask for 3–5 **rival theories as Python functions** `simulate(params, inputs) -> outputs`, plus parameter ranges.
   - Also ask for candidate **sensor programs** `sense(streams) -> value` (§5).
   - All run in the sandbox.
3. **Probe** (`probe.py`):
   - With recorded data: choose which recordings or windows to request next, maximising disagreement between surviving theories (Box–Hill style) weighted by whether the answer changes the decision.
   - Stop when the remaining theories give the same decision ("refusal": log *"I won't run that test, it can't change the answer"*).
   - If theories can't be separated with the data available: emit a **"can't tell" verdict** naming the experiment or sensor needed (e.g. single-motor spin test, RPM telemetry).
4. **Prove** (`proof.py`): a theory or sense passes only if all of these hold:
   - (a) It predicts **held-out** data within threshold (three splits: fit / select / prove).
   - (b) It passes physics checks (energy/power balance where applicable, non-negative damping, units consistent).
   - (c) Its error bars come from split-conformal intervals on the prove split.
   - Store failures as **negative knowledge**.
5. **Recycle:** refit with any new data and repeat until the proof passes or the "can't tell" verdict fires.

---

## 5. Sense Evolution: AI invents new senses (P1, signature algorithm)

`physica/discover/evolve.py`

- **Target:** a quantity not directly measured (`prop_health`, `wobble_gmm`, `which_rotor`).
- **Borrowed reference:** labels available briefly. Fraunhofer known levels; PADRE healthy-vs-damage labels on *training rotors only*.
- **Loop**, AlphaEvolve-style but **scored by reality**:
  1. Spark writes N=12 candidate `sense()` programs.
  2. Score each on the select split. The score is held-out error + calibration + simplicity penalty + physics-consistency checks.
  3. Keep the top 4.
  4. Prompt Spark with the top programs and their scores to mutate or combine.
  5. Repeat for 5 generations.
- Final scoring is on the prove split only.
- **Report:** generation-1 best vs generation-5 best vs a hand-written baseline vs a plain spectrogram + threshold. Include confidence intervals.
- The winner becomes a signed **sense card**.

---

## 6. Imagine: train on failures that never happened (P1)

`physica/imagine/`

- From the self-model proven on **healthy Fraunhofer data only**, synthesise unbalance signals by adding F=(m·r)·ω² through the calibrated response, at many m·r values and speeds, with measured noise.
- Train a simple detector/regressor on the **synthetic** data only.
- Test on the **real** levels 1–4 (evaluation files).
- **Compare** against:
  - a detector trained on real fault data (upper bound)
  - an anomaly detector trained on healthy data only
- Headline if the numbers support it: "trained on failures that never happened, detects real ones."

---

## 7. Knowledge record and compounding (P0)

`physica/library/`

**Card types:** proof, sense, fault, skill (P2), experiment record, negative knowledge.

**Card = folder** `cards/<id>/`:
- `card.json`
- `model.py` (if any)
- `evidence/` (plots, metrics, split hashes)
- `signature.sig`

**`card.json` fields:**
`id, type, claim, units, machine{type,model,id}, sensors[], context{operating range, speed range, conditions}, proven_range, metrics{heldout_error, ci95}, lineage{parent, changed}, track_record[{date, check, pass}], created, author="physica", version`

**Signing:**
- Ed25519 via `cryptography`. The key lives in `~/.physica/key` and is never committed; the public key is in the repo.
- `verify_card()` refuses unsigned or tampered cards.
- **A signature proves origin and integrity, not truth.**

**Storage:** cards are git-versioned. `recall(query)` searches cards.

**Compounding / prior** (`prior.py`):
- A new machine's self-model starts from the library (shape from relatives) and **gives way to its own evidence**: a ridge/Bayesian shrinkage toward the library coefficients.
- Never use library knowledge as fixed truth.
- **Pilot to reproduce** (PADRE, leave-one-rotor-out): about 2–4× less healthy data needed to reach ≤5% false alarms. Report the full curve (data seconds vs false alarms vs detection).

**Arrival check** (`arrival.py`):
- Before a card is used on a new machine, run a short check on that machine's healthy data.
- If the card's predictions fall outside its conformal interval → verdict **"doesn't fit here"** → re-learn only the failing part → new version linked to the parent.

**Library counter** for the UI: machines, rotors/units and cards.

---

## 8. Translators: one discovery, every machine's language (P0: 2 targets)

`physica/translate/`

- **P0 `ardupilot.py`:**
  - From a vibration mode (frequency, bandwidth or damping) write a `.param` file with the harmonic notch settings: `INS_HNTCH_ENABLE`, `INS_HNTCH_FREQ`, `INS_HNTCH_BW`, `INS_HNTCH_REF`, `INS_HNTCH_MODE`, `INS_HNTCH_HMNCS`. Check names and allowed values against current ArduPilot docs before finalising.
  - Validate by applying the equivalent notch to recorded data in Python and reporting the vibration reduction in that band.
  - If a permitted real ArduPilot log exists, also check in ArduPilot's web **Filter Review Tool**.
- **P0 `plc_st.py`:**
  - Generate an IEC 61131-3 **Structured Text** function block, `FB_PhysicaFeel`.
  - Inputs: band levels / order-1 amplitude, speed.
  - Outputs: `wobble_gmm`, `ALARM`, `TRIP` (trip before the predicted limit).
  - Run it in **OpenPLC**, replaying the Fraunhofer data (Modbus or the simplest feed OpenPLC supports). Record a screen capture.
- **P1 `gcode.py`:** Marlin input shaping `M593 F<freq> D<damping>` (and Klipper `[input_shaper]` text) from a resonance mode. Syntax-checked.
- **P2:** URDF/MJCF parameters; FMU export (roadmap only).

---

## 9. Agents, voice and the Meta models (P0/P1)

**Model roles (label them on screen in the video):**

| Model | Role |
|---|---|
| **SAM 3.1** | Feel Check camera: segment the item or prop; confirm each guided step happened (P1) |
| **Muse Spark 1.3** | The physicist: rival theories, sensor programs, edits only the part a failed test points to |
| **Muse Wonder** | The agent: answers questions by running Physica's tools ("Is this drone safe to fly?"); explains verdicts |
| **Voice Transcribe** | Spoken questions in the app |
| **Muse Glimmer** (open weights, Apache-2.0) | Local safety/intent check on every tool call that would change a machine or translator output; runs on a Modal GPU or locally. Makes us eligible for Best Open Weight |
| **Muse Code** | Optional: one visible generated adapter or test |

**MCP server** (`agents/mcp_server.py`, official `mcp` package; pin the version). Tools:
- `observe(source)` → streams summary
- `feel(source)` → feelogram summary plus flags
- `learn(source)` → runs the Physica Loop → cards
- `predict(card, what_if)` → counterfactual (pre-mortem)
- `check(card, source)` → arrival check verdict
- `recall(query)`
- `translate(card, target)` → file
- `explain(verdict)`

**Wonder agent** (`agents/wonder_agent.py`): a scripted demo question plus free questions; it must cite the card and evidence for every answer.

---

## 10. Feel Check app (P0)

`physica/app/` (Gradio or FastAPI + a single HTML page; whichever is faster)

- **Pick a source:** "Used drone (PADRE flight)", "Motor shaft (Fraunhofer)", optional "Live: phone on my fan (phyphox)".
- **Replay mode** (default; no hardware or API key needed, uses cached LLM outputs) so judges can run it.
- **Flow:**
  1. Identify the item.
  2. Run the guided 30 s check.
  3. Show the feelogram (healthy band vs this item).
  4. Give the verdict with confidence: "Rotor B feels damaged", "Wobble 76 ± 9 g·mm", or "I can't tell which rotor; spin-test each motor".
  5. Produce a **signed Feel Certificate** (card).
  6. **Fix / translate** buttons (ArduPilot `.param`, PLC ST, `M593`).
- **Library panel:** counter plus a lineage graph (cards → parents).
- **Footer:** "Advice, not a safety certification."

---

## 11. Evaluation (`eval/`, every number in README and video comes from here)

| ID | Claim | Protocol | Report |
|---|---|---|---|
| E1 | Feel damage with **no damage training** | PADRE: self-model on healthy calibration half → test rotors B/C/D damage windows + held-out healthy | Detection rate, false alarms, CI; vs RF trained on rotor-A damage; vs spectrogram + threshold |
| E2 | Wobble in **physical units** | Fraunhofer: calibrate on level 1 only → predict levels 2–4 on eval files | g·mm error, correlation, by speed range |
| E3 | Imagine | Train on synthetic faults only → real levels | Detection/regression vs real-trained vs healthy-only anomaly |
| E4 | Compounding | PADRE leave-one-rotor-out, data budget 5–85 s | Seconds to ≤5% false alarms; detection curve; library vs cold vs fixed-truth |
| E5 | Sense Evolution | Gen-1 vs Gen-5 vs hand-written vs spectrogram | Prove-split error, CI |
| E6 | Translators work | ArduPilot notch replay; OpenPLC trip before limit; M593 syntax | Band reduction (dB); trip timing |
| E7 | Arrival check | Card from one rotor/dataset applied to another; include a known mismatch | Verdicts, false accepts/rejects |
| E8 | Honest limit | PADRE passive localisation (expect weak) → "can't tell" verdict fires | Localisation accuracy; verdict rate |

**Statistics:** windows → bootstrap 95% CI (1000 resamples); IQM where several seeds/configs exist. All splits are in `eval/splits.json`.

---

## 12. The 3-minute video (Zanea records; build what these beats need)

| Time | Beat |
|---|---|
| 0:00 | "Why can't you tickle yourself? Your brain cancels what you cause. We gave machines the same trick." |
| 0:15 | Feel Check on a **real used-drone flight**: committed prediction → feelogram → "Rotor B feels damaged" (E1). Honest line: "3 passive methods couldn't say *which* rotor. Physica asks for the one test that can" (E8) |
| 0:55 | **Motor shaft:** "Wobble 76 g·mm", and the true value appears (E2). "Trained on failures that never happened" (E3) |
| 1:25 | **Sense Evolution:** generation 1 fails, generation 5 passes; reality is the judge (E5) |
| 1:50 | **Translate:** the same card becomes ArduPilot settings (vibration drops) and PLC code tripping in OpenPLC (E6) |
| 2:15 | **Knowledge record:** library counter, lineage, "new rotor trustworthy in 15 s instead of 40–60" (E4), arrival check rejecting a wrong card (E7) |
| 2:35 | Wonder via MCP: "Is this drone safe to fly?" Model-role labels on screen |
| 2:45 | Vision: Feel Check on Marketplace and glasses; robots that feel you; fleets that teach each other; "the physical world gets an API" |

Separate 25–30 s vertical X clip, posted Nov 4–5.

---

## 13. Repo layout

```
physica/
  README.md  SPEC.md  DATA.md  LICENSE  pyproject.toml  .env.example
  physica/
    llm/meta_client.py          # API wrapper, MOCK mode, cost meter ($120 hard stop), cache
    senses/                     # sense cards, unify
    data/padre.py fraunhofer.py phyphox_live.py(P2)
    feel/feel_transform.py selfmodel.py dmd.py order.py axes.py feelogram.py
    discover/theories.py probe.py proof.py evolve.py sandbox.py
    imagine/synth_faults.py train_detector.py
    library/cards.py sign.py store.py recall.py prior.py arrival.py
    translate/ardupilot.py plc_st.py gcode.py
    agents/mcp_server.py wonder_agent.py voice.py glimmer_gate.py
    app/                        # Feel Check UI + replay mode
  eval/ E1…E8 scripts, splits.json, results/*.json, figures/
  cards/                        # generated, signed
  predictions/                  # timestamped prediction commits
  tests/                        # unit tests per module
```

---

## 14. Schedule and priorities

| Day | P0 (must) | P1 (should) | Zanea's own tasks |
|---|---|---|---|
| **Oct 30** | Repo + rules setup; `meta_client` (mock + cost stop); PADRE loader; Feel Transform steps 1, 2c and 4; E1 | Fraunhofer loader | API key, $120 cap, Modal, Discord questions (AI-code disclosure? submission fields? video length?), download datasets, email Baylor AVIA lab for a drone log + permission + quote |
| **Oct 31** | Wobble axis + E2; cards + signing + store; arrival check + E7 | Physica Loop with Spark (theories, proof) | First real Spark run; review code |
| **Nov 1** | Prior/compounding + E4; translators (ArduPilot, PLC ST in OpenPLC) + E6 | Sense Evolution + E5; Imagine + E3 | Review; test OpenPLC |
| **Nov 2** | MCP server + Wonder agent; Feel Check app + replay mode; E8. **FEATURE FREEZE 23:59** | Voice; Glimmer gate; SAM step-confirm; `M593` | Rehearse demo |
| **Nov 3** | README (numbers from `eval/` only, limits, related work, one-command run); final figures | P2 only if everything else passes | Record and edit video; X clip |
| **Nov 4** | Bug fixes only | | **Submit by 3 PM CT**; post on X |

**Cut order if behind** (first to cut): live phone (P2) → `M593` → SAM step-confirm → Imagine (E3) → Sense Evolution (E5) → Glimmer gate.

**Never cut:** Feel Transform, E1/E2, cards + arrival check, ArduPilot + PLC translators, Feel Check app with replay, README honesty.

---

## 15. Related work (README section; cite, don't overclaim)

- **Efference copy:** Blakemore, Wolpert & Frith 1998; Wolpert, Miall & Kawato 1998.
- **DMD / DMDc:** Schmid 2010; Proctor, Brunton & Kutz 2016. DMD for damage from video: arXiv 2605.02803 (no localisation).
- **Visual vibrometry:** Davis et al. CVPR 2015.
- **Haptic exploratory procedures:** Lederman & Klatzky 1987.
- **Indirect tyre-pressure monitoring:** a sense from a model, hand-engineered.
- **AlphaEvolve, AlphaGeometry, AlphaQubit, GNoME:** propose-and-check; synthetic pretraining; active learning loops.
- **LLM physical exploration failures:** arXiv 2610.37649 (Oct 27, 2026).
- **Sensorless force:** FACTR 2 (2026).
- **Knowledge transfer:** RoboEarth, TuneNet, Liveline.
- **LLM fault diagnosis on recorded datasets:** e.g. arXiv 2606.16684.
- **Datasets:** PADRE; Fraunhofer unbalance (arXiv 2005.12742).

**Novelty sentence:** "To our knowledge, no prior open system combines a self-cancelling Feel Transform with physical-unit feel axes, reality-scored sensor evolution, signed transferable knowledge with arrival checks, and translation into native machine languages." (Never write "first".)
