# Why Physica matters, what is new, and what we do not claim

## 1. What the frontier labs actually did (as of 1 November 2026)

- **Navier–Stokes.** On 8 September 2026 OpenAI said an unreleased internal model, running as many autonomous
  agents (reported as about 10,000, exchanging millions of messages over roughly 88 hours), produced a blow-up result
  that would resolve the Navier–Stokes Millennium Prize Problem, and that the proof was checked in the Lean proof
  assistant in a further 17 hours. The Clay Mathematics Institute said the problem "has apparently been settled" but
  that its process is deliberately unhurried (publication, two years, general acceptance). Experts have asked for a
  human audit that the Lean statement matches the original problem, and some argue the construction needs a force
  near the singularity. Human mathematicians (Córdoba and Martínez-Zoroa) supplied the strategy the agents completed;
  Buckmaster and Alpöge announced related forced-Euler results the same day. **Claimed, formally checked, not yet
  accepted.**
- **Riemann hypothesis.** In August 2026 Anthropic reported that Claude raised the proportion of zeta zeros proven to
  lie on the critical line from 41.6% to 67.2%, formalized in Lean, and said it does not expect those techniques to
  prove the hypothesis.
- **Other Millennium problems.** Further claims (special cases of Hodge and Birch–Swinnerton-Dyer, Yang–Mills
  existence without the mass gap, fast 3-SAT refuting the Exponential Time Hypothesis) were unconfirmed at the end of
  October. No AI solution has been recognised by the Clay Institute.

Sources: [Quanta Magazine](https://www.quantamagazine.org/ai-has-solved-one-of-maths-1-million-millennium-prize-problems-20260908/),
[Simon Willison's notes on OpenAI's post](https://simonwillison.net/2026/Sep/8/on-navier-stokes/),
[CNN](https://www.cnn.com/2026/09/09/business/openai-millennium-problems-navier-stokes-hnk),
[Papex status of all seven problems, Oct 2026](https://papex.org/blog/has-ai-solved-a-millennium-prize-problem),
[The Neuron: open problems AI has solved](https://www.theneuron.ai/explainer-articles/from-erdos-to-axiom-the-open-problems-ai-has-actually-solved/).

**The pattern.** Every one of these results is *many model proposals, filtered by a strict automatic judge*. The
model is the generator; Lean is the judge. Without the judge, thousands of agents produce thousands of plausible,
mostly wrong arguments. With it, a correct one can be found and trusted.

## 2. Can Meta models do the same through Physica? What can a video prove?

**The same pattern is missing in the physical world, and that is exactly what Physica supplies.** Physics and
engineering have no Lean. When a model proposes "the clamp is loosening", "a crack at 40 mm", or "a better way to
sense this beam", the only judge is reality, and asking reality is slow, costly and easy to fool yourself with.
Physica turns reality into an automatic judge:

| Lean in mathematics | Physica in the physical world |
|---|---|
| a formal statement | a sealed prediction (SHA-256 + Ed25519 + time), written before the measurement |
| a proof checker | held-out measurements the proposer never saw, on a machine it never trained on |
| type errors rule out nonsense | one-way physical laws rule out whole classes of causes before anything is fitted |
| a checked lemma can be reused | a signed explanation card another machine can verify and use |

And Physica calls Meta models in exactly that way:

- `physica meta evolve --swarm N` runs N Muse Wonder proposers in parallel per generation. Each writes new sensing
  programs; Physica runs them in a sandbox and scores them in millimetres against a lab position sensor on beam A's
  first half only. The champion must then beat Physica's own sense on A's unseen half **and** on beam B, a different
  machine, or it is rejected (E19). Offline, the proposer is a labelled stand-in; with a key it is Meta.
- `physica meta scientist` asks Muse Spark for new causes when none of Physica's own fit, as structured physics
  (never code), fits them on half the data and accepts only what explains the other half better than every built-in
  cause (E18).
- `physica meta ask` lets Muse Wonder run the whole loop with tool calls: find the cause, plan the experiment, seal,
  grade (agent.py).

**What a video can honestly prove:** that this loop runs live with Meta models, that the judge is real (ground truth
the proposer never saw, on a second machine), that a proposal which only fits one machine is rejected, and that a
sealed promise can break in public. The demo script ([DEMO.md](../DEMO.md)) records exactly that, with the
`meta_receipts/` files on screen as proof of which calls were live.

## 3. What value, exactly, and why it is needed

The scarce thing is no longer ideas; it is trustworthy contact with the physical world. Concretely:

1. **Fewer experiments to a decision.** In simulation, one experiment chosen by Physica identified the right cause
   about as often as two random ones (78% vs 80%), and two chosen ones reached 88%; every prediction was sealed first
   and 89% of the 90% promises held (E17). Each avoided experiment is a machine hour, a test rig, or a part not broken.
2. **A new machine that starts from understanding instead of from zero.** A second, different beam tracked its hidden
   support with no labels at all (r = 0.83), and with one or two labels beat a tracker learning from that beam's own
   labels (7.1 vs 25.7 mm; 3.3 vs 5.0 mm) (E16). Carrying the first machine's raw curve instead failed (26.9 mm).
3. **Nothing tuned to the machine.** On a real lab beam, Physica located the hidden support at 2.40 mm median
   error from the beam's measured dimensions and textbook physics alone; the dataset authors' published real-time
   finite-element model-updating method scored 3.37 mm on the same recording (E16). Theirs answers in milliseconds;
   Physica's answers 0.35 s later.
4. **Model ideas you can trust, because they were judged, not believed.** E18 and E19 accept a proposal only when it
   holds up on reality it never saw; E19's judge rejected a sense that was 2.5× better on one beam but worse on the
   other.

Where this is needed: structural health monitoring (is that frequency drop damage, or just load or temperature?),
wind turbine blades and aircraft parts, robot grippers and arms (what did I touch, and where?), machine
commissioning and tuning (from a phone video), lab automation (which experiment next?), and fleets of machines that
should share what one of them learned without sharing its raw data.

## 4. What is new in how it senses (to our knowledge)

Most machine sensing reports **what** is there: a spectrum, a pixel, a label from a classifier trained on examples.
Model updating (the classical engineering approach) fits a pre-built model of one specific structure with one cause
type chosen in advance. Physica's sense reports **why**:

- **A sense of cause, not of signal.** It holds rival physical explanations and rules them out with one-way laws
  (adding mass or weakening can only lower natural frequencies; holding can only raise them; temperature moves them a
  few percent) before fitting anything. No damage data, no training labels.
- **A sense that knows its own certainty.** It judges from its own answers whether the hidden change is holding still
  or moving, and carries separate, calibrated error bars for each (96% coverage on unseen data for a 90% bar).
- **A sense that chooses its own stimulus.** It picks the experiment (where to put a known mass) whose result will
  split its remaining explanations most, and seals what it expects to feel first. That is active, causal sensing:
  it changes the world to find out, rather than waiting for the world to change.
- **A sense that can be handed over.** What it learned is written as an explanation (cause, how to feel it, where it
  holds, how wrong it tends to be) in dimensionless form, signed, so a different machine with different sensors can
  verify it and use it on day zero.
- **A sense that can be extended by other minds, safely.** New causes and new sensing programs can come from Meta
  models (or anyone), and are adopted only if reality agrees on data they never saw.

None of the ingredients is new on its own (Rayleigh's principle, subspace system identification, Bayesian
experimental design, conformal error bars, digital signatures). What we believe is new is putting them together as
one sense that a machine, or an AI agent, can use to find out *why* the physical world changed and to prove it.

## 5. How important is it, honestly?

It is a working prototype with real evidence on a small number of real systems (two DROPBEAR beams, one more lab
beam, a guitar video, two drone models) and simulations for the parts that need a physical experiment we could not
run here. Its importance is that it attacks the
bottleneck that will matter more as models get better at proposing: **verifying ideas against the physical world,
cheaply and without fooling yourself.** If AI scientists are going to work on physical problems the way they now
work on mathematics, they need a judge that is as hard to fool as Lean. Physica is a first version of that judge for
vibrating structures and machines.

## 6. What we do not claim

- E17 (active experiments) and E18 (new causes) are simulations; E19's proposer is an offline stand-in unless you run
  it with a key. They are labelled everywhere they appear.
- Physica's tracker answers 0.35 s after the moment it describes; the DROPBEAR authors' method answers in
  milliseconds. On beam B, the strain-gauge channel tracked poorly (median r ≈ 0.50) and the sealed promise about B
  broke.
- Advice, not a safety certification.
