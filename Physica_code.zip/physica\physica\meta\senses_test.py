"""Does giving Muse Physica's senses improve its answers? The with-and-without test, on real blade cases.

Each case is asked twice, in separate fresh calls, with the same physics background and the same raw measurements:
  muse_alone    raw tones, temperature and the session 1 reference tables
  muse_senses   the same, plus what Physica felt (weather removed, change score, mode pattern, mass equivalent)
Physica's own verdict is scored as a third arm and costs nothing. By default Muse does NOT see that verdict, so a good
score means it read the sense itself rather than copying an answer (--include-verdict shows it).

Scoring is fixed here, before any run. An answer is right if it leads to the right action:
  healthy -> "weather only"; ice -> "ice"; crack -> "crack", "structural" or "can't tell" (all stop and inspect).
Also reported: dangerous misses (a crack called weather or ice), false stops (healthy not called weather), and ice missed.
Every failed or malformed reply stays in the score as "no answer". Nothing is dropped.

Prompts never include the truth or the blade's case letter. Results are only as good as the live run: a preview has no
Muse numbers at all, and an incomplete run is reported as incomplete.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np

from physica import config
from physica.llm import meta_client as mc

CASES = config.REPO_ROOT / "eval" / "results" / "E28_blade_cases.json"
RESULTS = config.REPO_ROOT / "eval" / "results" / "E28_muse_senses.json"
CONFIRM = config.REPO_ROOT / "eval" / "results" / "E28_muse_senses_confirm.json"
VERDICTS = ["weather only", "ice", "crack", "structural", "can't tell"]
ARMS = ("muse_alone", "muse_senses")
RIGHT = {"healthy": {"weather only"}, "ice": {"ice"}, "crack": {"crack", "structural", "can't tell"}}

BACKGROUND = """You are judging a 1.75 m, 5 kg composite wind turbine blade, clamped at the root, shaken with white noise \
in a climate chamber. Decide what is happening to it from the numbers you are given.

Physics that applies:
- Natural frequencies (tones) fall as temperature rises, by several percent across the range, so a change in tone can be \
weather alone.
- Added mass such as ice can only lower tones, and it lowers most the modes that move most where the mass sits. For ice \
near the outer blade that is the slow swinging mode, listed first.
- A crack removes stiffness where the blade bends, so it lowers the bending modes (later in the list) and can leave the \
slow mode almost unchanged.
- A tone clearly rising is not explained by added mass: treat it as a structural change.

Choose exactly one verdict, knowing what each one causes:
- "weather only": no action, the blade keeps running.
- "ice": heat the blade and pause.
- "crack": stop and inspect.
- "structural": a tone went up or the pattern is rearranged; stop and inspect.
- "can't tell": changed, but the pattern is unclear; stop and inspect.
A missed crack is the costliest error, and a needless stop also costs money. Use only the numbers given and do not \
invent any. Reply with the JSON the schema asks for."""

SENSE_NOTE = """What Physica felt, computed from the same measurements using only its session 1 learning:
- residual_pct: each tone's change after removing what temperature explains
- z: that change in units of normal day-to-day scatter
- change_score: how far the whole pattern sits from normal; above change_threshold it is more than weather
- slow_mode_lead: how much the slow mode dropped relative to the bending modes (a known 44 g mass gave {lead})
- mass_equivalent_g: the mass that would explain the slow mode's drop, whether or not mass is the cause"""


def schema() -> dict:
    props = {"verdict": {"type": "string", "enum": VERDICTS}, "confidence": {"type": "number"},
             "reason": {"type": "string"}}
    return {"type": "json_schema", "json_schema": {"name": "PhysicaBladeVerdictV032", "strict": True, "schema": {
        "type": "object", "properties": props, "required": list(props), "additionalProperties": False}}}


def load_cases(path: str | Path = CASES) -> dict:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"{p} not found; build it with eval/e28_blade_cases.py (needs PHYSICA_BLADE_PSD)")
    return json.loads(p.read_text())


def select(cases: list[dict], per_class: int = 12, seed: int = 2028) -> list[dict]:
    """A fixed, balanced sample: same number per truth class, spread across the blade's cases. Set before any answer."""
    rng = np.random.default_rng(seed)
    chosen = []
    for truth in RIGHT:
        pool = {}
        for c in cases:
            if c["truth"] == truth:
                pool.setdefault(c["truth_case"], []).append(c)
        for v in pool.values():
            rng.shuffle(v)
        names = sorted(pool)
        got, i = [], 0
        while len(got) < per_class and any(pool.values()):
            name = names[i % len(names)]
            if pool[name]:
                got.append(pool[name].pop())
            i += 1
        chosen += got
    return [chosen[k] for k in rng.permutation(len(chosen))]


def messages(case: dict, data: dict, arm: str, include_verdict: bool = False) -> list[dict]:
    if arm not in ARMS:
        raise ValueError(f"unknown arm {arm}")
    ref = data["reference"]
    shown = {"group_id": case["id"], "temperature_c": case["temp_c"], "tests_averaged": case["n_tests"],
             "tones_hz_in_mode_order": case["raw_tones_hz"], "mode_order": data["mode_order"],
             "reference_healthy_tones_hz_by_temperature_c": ref["healthy_tones_by_temp_c"],
             "reference_with_known_44g_mass_tones_hz_by_temperature_c": ref["with_44g_mass_tones_by_temp_c"]}
    user = "Measurements:\n" + json.dumps(shown)
    if arm == "muse_senses":
        note = SENSE_NOTE.format(lead=data["sense_rules"]["slow_mode_lead_44g_mass"])
        felt = dict(case["felt"])
        if include_verdict:
            felt["physica_verdict"] = case["physica_verdict"]
        user += "\n\n" + note + "\nFelt:\n" + json.dumps(felt)
    return [{"role": "system", "content": BACKGROUND}, {"role": "user", "content": user}]


def _parse(content) -> dict:
    if not isinstance(content, str) or not content.strip():
        raise ValueError("empty reply")
    text = content.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:]).strip()
    d = json.loads(text)
    if not isinstance(d, dict) or d.get("verdict") not in VERDICTS:
        raise ValueError("verdict is not one of the allowed options")
    return {"verdict": d["verdict"], "confidence": d.get("confidence"), "reason": str(d.get("reason", ""))[:600]}


def ask_muse(case: dict, data: dict, arm: str, role: str, include_verdict: bool, max_tokens: int = 16000) -> dict:
    """Up to two fresh calls. A bad reply is retried once; an HTTP error is not swallowed, it stops the run."""
    from physica.frontier.meta_council_v026 import _verified
    task = f"physica_v032_senses_{arm}"
    last = "no reply"
    for _ in range(2):
        r = mc.complete(role, messages(case, data, arm, include_verdict), task, response_format=schema(),
                        max_completion_tokens=max_tokens, require_fresh=True)
        proof = _verified(r, expected_role=role, task=task)
        try:
            return {**_parse(r["content"]), "receipt_sha256": proof["receipt_sha256"]}
        except (ValueError, TypeError, json.JSONDecodeError) as e:
            last = f"{type(e).__name__}: {e} (finish_reason: {r.get('finish_reason')})"
    return {"verdict": None, "error": last}


def outcome(truth: str, verdict: str | None) -> dict:
    return {"right_action": verdict in RIGHT[truth], "exact": verdict == {"healthy": "weather only"}.get(truth, truth),
            "dangerous_miss": truth == "crack" and verdict in ("weather only", "ice"),
            "false_stop": truth == "healthy" and verdict != "weather only",
            "ice_missed": truth == "ice" and verdict == "weather only", "no_answer": verdict is None}


SAFETY_ORDER = {"weather only": 0, "ice": 1, "crack": 2, "structural": 2, "can't tell": 2}


def safer_verdict(physica: str | None, muse: str | None) -> str | None:
    """The same system with Muse as a reviewer: if the two disagree, take the safer action. This rule was fixed before any
    case-by-case answer was looked at. If Muse gives no usable reply, Physica's verdict stands."""
    if muse is None or SAFETY_ORDER.get(physica, 0) >= SAFETY_ORDER[muse]:
        return physica
    return muse


def with_review(report: dict) -> dict:
    """Physica alone against Physica with Muse reviewing, on the same cases, from answers already saved. No new calls."""
    done = [r for r in report.get("rows", []) if "muse_senses" in r.get("answers", {})]
    pairs = [(r["truth"], r["physica_verdict"], safer_verdict(r["physica_verdict"], r["answers"]["muse_senses"].get("verdict"))) for r in done]
    report.setdefault("scores", {})["physica_plus_muse"] = score_arm([(t, m) for t, _, m in pairs])
    fixed = sum(outcome(t, m)["right_action"] and not outcome(t, p)["right_action"] for t, p, m in pairs)
    broke = sum(outcome(t, p)["right_action"] and not outcome(t, m)["right_action"] for t, p, m in pairs)
    report["review"] = {"muse_changed_the_action": sum(p != m for _, p, m in pairs), "fixed": int(fixed), "broke": int(broke),
                        "rule": "if Physica and Muse disagree, take the safer action; fixed before row-level answers were seen"}
    return report


def pooled(first: dict | None, confirm: dict | None) -> dict | None:
    """Both runs together: every case answered, with no case counted twice. The reviewer rule was fixed before either was read case by case."""
    runs = [r for r in (first, confirm) if r and r.get("status") == "COMPLETE" and r.get("rows")]
    if not runs:
        return None
    rows = {x["id"]: x for r in runs for x in r["rows"]}
    done = [x for x in rows.values() if all(a in x.get("answers", {}) for a in ARMS)]
    report = {"status": "COMPLETE", "cases_done": len(done), "rows": done, "model": runs[0].get("model"), "runs_combined": len(runs),
              "scores": {"physica_alone": score_arm([(r["truth"], r["physica_verdict"]) for r in done]),
                         **{a: score_arm([(r["truth"], r["answers"][a].get("verdict")) for r in done]) for a in ARMS}},
              "paired": compare(done)}
    return with_review(report)


def score_arm(pairs: list[tuple[str, str | None]]) -> dict:
    rows = [outcome(t, v) for t, v in pairs]
    n = len(rows)
    count = lambda k: int(sum(r[k] for r in rows))  # noqa: E731
    per = {t: f"{sum(outcome(t, v)['right_action'] for x, v in pairs if x == t)}/{sum(x == t for x, _ in pairs)}"
           for t in RIGHT}
    return {"n": n, "right_action": count("right_action"), "right_action_rate": round(count("right_action") / max(n, 1), 3),
            "exact_label": count("exact"), "dangerous_misses": count("dangerous_miss"), "false_stops": count("false_stop"),
            "ice_missed": count("ice_missed"), "no_answer": count("no_answer"), "right_action_by_truth": per}


def compare(rows: list[dict]) -> dict:
    """Paired test on the same cases. Groups from one blade are related, so treat the p-value as a guide only."""
    from scipy.stats import binomtest
    done = [r for r in rows if all(a in r["answers"] for a in ARMS)]
    alone = [outcome(r["truth"], r["answers"]["muse_alone"].get("verdict"))["right_action"] for r in done]
    senses = [outcome(r["truth"], r["answers"]["muse_senses"].get("verdict"))["right_action"] for r in done]
    gained = sum(s and not a for a, s in zip(alone, senses))
    lost = sum(a and not s for a, s in zip(alone, senses))
    p = float(binomtest(gained, gained + lost, 0.5).pvalue) if gained + lost else None
    agree = sum(r["answers"]["muse_senses"].get("verdict") == r["physica_verdict"] for r in done)
    return {"senses_right_where_alone_wrong": int(gained), "alone_right_where_senses_wrong": int(lost),
            "mcnemar_exact_p": p, "muse_senses_agrees_with_physica": f"{agree}/{len(done)}",
            "p_value_caveat": "Groups come from one blade and are not independent; this is one test, not a general proof."}


def summarise(rows: list[dict], planned: int, meta: dict) -> dict:
    done = [r for r in rows if all(a in r["answers"] for a in ARMS)]
    complete = len(done) == planned
    out = {**meta, "status": "COMPLETE" if complete else f"INCOMPLETE_{len(done)}_OF_{planned}_NOT_A_RESULT",
           "cases_planned": planned, "cases_done": len(done),
           "scores": {"physica_alone": score_arm([(r["truth"], r["physica_verdict"]) for r in done]),
                      **{a: score_arm([(r["truth"], r["answers"][a].get("verdict")) for r in done]) for a in ARMS}},
           "paired": compare(rows), "rows": rows}
    return with_review(out)


def _table(s: dict) -> str:
    names = {"muse_alone": "Muse alone", "muse_senses": "Muse + senses", "physica_alone": "Physica alone", "physica_plus_muse": "Physica + Muse"}
    lines = [f"{'':15}{'right action':>14}{'crack missed':>14}{'false stop':>12}{'ice missed':>12}{'no answer':>11}"]
    for k in ("muse_alone", "muse_senses", "physica_alone", "physica_plus_muse"):
        a = s["scores"].get(k)
        if not a:
            continue
        lines.append(f"{names[k]:15}{a['right_action']:>9}/{a['n']:<4}{a['dangerous_misses']:>14}{a['false_stops']:>12}"
                     f"{a['ice_missed']:>12}{a['no_answer']:>11}")
    return "\n".join(lines)


def estimate_usd(data: dict, chosen: list[dict], role: str) -> float:
    pin, pout, _ = mc._price(role)
    chars = sum(len(json.dumps(messages(c, data, a))) for c in chosen for a in ARMS)
    return round(chars / 4 * pin / 1e6 + len(chosen) * 2 * 16000 * pout / 1e6, 2)


def run(per_class: int = 12, seed: int = 2028, role: str = "spark", include_verdict: bool = False,
        allow_billed_meta: bool = False, out: str | Path = RESULTS, resume: bool = False, cases_path=CASES,
        retry_no_answer: bool = False, exclude: set[str] | None = None) -> dict:
    data = load_cases(cases_path)
    chosen = select([c for c in data["cases"] if c["id"] not in (exclude or set())], per_class, seed)
    meta = {"LABEL": "REAL blade cases; Muse answers are live calls with receipts",
            "model": mc.model_id(role), "seed": seed, "per_class": per_class, "include_verdict": include_verdict,
            "data": data["source"], "scoring": "fixed in physica/meta/senses_test.py before any run"}
    cost = estimate_usd(data, chosen, role)
    if not allow_billed_meta:
        physica = score_arm([(c["truth"], c["physica_verdict"]) for c in chosen])
        return {"status": "PREVIEW_NO_MUSE_CALLS", "calls_needed": len(chosen) * 2, "upper_bound_usd": cost,
                "physica_alone_on_this_sample": physica, "selected_ids": [c["id"] for c in chosen],
                "sample_prompt_alone": messages(chosen[0], data, "muse_alone", include_verdict),
                "sample_prompt_senses": messages(chosen[0], data, "muse_senses", include_verdict)}
    if mc.is_mock():
        raise mc.NotConfigured("Set MODEL_API_KEY and MOCK=0 for the live test")
    target = Path(out)
    rows: dict[str, dict] = {}
    if resume and target.exists():
        old = json.loads(target.read_text())
        if (old.get("seed"), old.get("per_class"), old.get("model"), old.get("include_verdict")) == (
                seed, per_class, meta["model"], include_verdict):
            rows = {r["id"]: r for r in old["rows"]}
            if retry_no_answer:   # same prompts and cases, more room to reply. The first run stays on file and is reported
                first = target.with_name(target.stem + "_first_run.json")
                if not first.exists():
                    first.write_text(target.read_text())
                for r in rows.values():
                    for arm in ARMS:
                        if r["answers"].get(arm, {}).get("verdict") is None and arm in r["answers"]:
                            r.setdefault("first_try_failed", {})[arm] = r["answers"].pop(arm).get("error")
    report = {}
    error = None
    try:
        for i, c in enumerate(chosen):
            row = rows.setdefault(c["id"], {"id": c["id"], "truth": c["truth"], "truth_case": c["truth_case"],
                                            "temp_c": c["temp_c"], "physica_verdict": c["physica_verdict"], "answers": {}})
            for arm in ARMS:
                if arm not in row["answers"]:
                    row["answers"][arm] = ask_muse(c, data, arm, role, include_verdict)
            report = summarise([rows[k["id"]] for k in chosen if k["id"] in rows], len(chosen), meta)
            target.write_text(json.dumps(report, indent=1))
            print(f"  {i + 1}/{len(chosen)} {c['id']}", flush=True)
    except (RuntimeError, OSError, mc.NotConfigured) as e:
        error = str(e)[:500]
    report = summarise([rows[k["id"]] for k in chosen if k["id"] in rows], len(chosen), meta)
    report["retried_no_answer"] = bool(retry_no_answer)
    if error:
        report["stopped_by_error"] = error
    report["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, indent=1))
    return report


def show(report: dict) -> None:
    if report["status"] == "PREVIEW_NO_MUSE_CALLS":
        print(f"PREVIEW: no Muse calls made. A live run needs {report['calls_needed']} calls, "
              f"at most about ${report['upper_bound_usd']} at the conservative prices.")
        a = report["physica_alone_on_this_sample"]
        print(f"Physica alone on this sample: {a['right_action']}/{a['n']} right action, "
              f"{a['dangerous_misses']} cracks missed, {a['false_stops']} false stops.")
        print("Run it with: physica meta senses --allow-billed-meta")
        return
    print(report["status"])
    if report.get("stopped_by_error"):
        print("Stopped by:", report["stopped_by_error"])
        print("Fix that, then rerun with --resume to keep the answers you already paid for.")
    print(_table(report))
    print(json.dumps(report["paired"], indent=1))
    if report.get("review"):
        print(f"Muse as reviewer changed the action in {report['review']['muse_changed_the_action']} cases: fixed {report['review']['fixed']}, broke {report['review']['broke']}.")
