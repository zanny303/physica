# Physica v0.8.5 — Causal Experience Memory

## What actually runs

Shared state z=(position, velocity). Two independently calibrated sensors observe y_m=h_m z+noise. Controlled action a predicts acceleration through five candidate mechanism terms: x, v, a, x³, v|v|. Train a regularized mechanism on source interventions; evaluate mechanism selection on distinct source interventions; use a target probe to decide whether a source lesson can be transferred. Perform prospective simulation using initial state and preselected future action sequence, not future measured target trajectory.

This is a research **prototype**, not an unconstrained learned representation. The sensor maps are calibrated, the hidden state has a human-designed two-dimensional interpretation and the nonlinear terms are predefined. Dimensional physics parameters are not invariant without calibration. Mechanism selection uses a holdout that shares source machine; independent target/machine evaluation remains essential.

## Reproducible synthetic benchmark

`python -m physica.causal_memory.benchmark --out demo/causal_memory.json --trials 24`

Reports per-body error for a source model, a fully local target fit using 16 target controlled samples, a conservative source-plus-local model using the *same* 16 target samples, and a source linear-only model. Source training has additional trials; this is a transfer advantage only when appropriately noted. Reports both wins and losses. This benchmark measures acceleration regression not open-loop trajectory performance; test prospective motion separately for a true future-sensation claim.

## Real-data next steps

1. Download Paderborn data and use `remote_bench` for passive multi-sensor forecast only. Official data: https://mb.uni-paderborn.de/en/kat/research/bearing-datacenter/data-sets-and-download
2. Capture sensor calibration, consent/licensing, raw data hashes and explicit source/body IDs.
3. Collect controlled approved interventions with timestamps and precommitted action plans in Physica Lab. Assemble rows with calibrated state, action, next acceleration and `intervention_type=controlled`.
4. Freeze target machine holdout IDs before model selection; use a separate target adaptation probe and a prospective test, compare against equally calibrated system ID, ridge, sparse-regression and world-model baselines.
5. Use Muse for rival hypotheses, confounders, reasoning and reviewed machine-specific instruction proposals; save actual authenticated API responses and run with/without Muse trials. Never let generative code actuate equipment without independent verification.

## Remote execution

Cloud Colab starter `examples/cloud_v083/PHYSICA_REMOTE_TRAINING.ipynb` is retained. Running locally or in a remote Colab runtime requires downloading real recordings and executing jobs in that runtime; it is not a claim that this archive itself was trained remotely. Internet access in the release-builder execution environment was unavailable.

## Studio usage

`python -m physica.studio --open-browser` then **Lab → Causal Experience Memory**. Uses no API credits and executes simulated learning only.

## Supervised real CSV importer

`python -m physica.causal_memory.real PATH_TO_CONTROLLED_ACTIONS.csv --out demo/real_causal.json`

CSV columns: `body_id,split,position,velocity,action,acceleration,intervention_type`. Each record needs a real controlled and logged action and independently calibrated units; mark `intervention_type` as `controlled`. Train and test body IDs must not overlap. The command cannot prove that a user-declared file is physically genuine. Do not label passive Paderborn motor current as controlled intervention.
