"""Ed25519 signing for cards. A signature proves origin and integrity, NOT truth.

Private key: ~/.physica/key (never committed). Public key: keys/physica_pub.pem (committed).
"""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from physica import config

PUB_PATH = config.REPO_ROOT / "keys" / "physica_pub.pem"


def _key_path() -> Path:
    return config.STATE_DIR / "key"


def _list_public(k: Ed25519PrivateKey) -> None:
    """Make sure this install's public key is in keys/ (so anything it signs can be checked), without touching
    keys other installs' cards depend on."""
    pem = k.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    PUB_PATH.parent.mkdir(parents=True, exist_ok=True)
    files = [PUB_PATH] + sorted(PUB_PATH.parent.glob(f"{PUB_PATH.stem}_*.pem"))
    if any(q.exists() and q.read_bytes() == pem for q in files):
        return
    target = PUB_PATH if not PUB_PATH.exists() else PUB_PATH.with_name(f"{PUB_PATH.stem}_{hashlib.sha256(pem).hexdigest()[:8]}.pem")
    target.write_bytes(pem)


def load_or_create_key() -> Ed25519PrivateKey:
    p = _key_path()
    if p.exists():
        k = serialization.load_pem_private_key(p.read_bytes(), password=None)
        _list_public(k)
        return k
    p.parent.mkdir(parents=True, exist_ok=True)
    k = Ed25519PrivateKey.generate()
    p.write_bytes(k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                  serialization.NoEncryption()))
    p.chmod(0o600)
    pem = k.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    PUB_PATH.parent.mkdir(parents=True, exist_ok=True)
    # never overwrite a key someone else's cards depend on: a new install adds its own public key next to it
    target = PUB_PATH if not PUB_PATH.exists() else PUB_PATH.with_name(
        f"{PUB_PATH.stem}_{hashlib.sha256(pem).hexdigest()[:8]}.pem")
    target.write_bytes(pem)
    return k


def trusted_keys() -> list[Ed25519PublicKey]:
    """Every public key in keys/ (the original install plus any added later)."""
    if not PUB_PATH.exists():
        load_or_create_key()
    if not _key_path().exists():  # make sure this install's own key is listed too
        load_or_create_key()
    files = [PUB_PATH] + sorted(PUB_PATH.parent.glob(f"{PUB_PATH.stem}_*.pem"))
    return [serialization.load_pem_public_key(q.read_bytes()) for q in files if q.exists()]


def public_key(path: Path | None = None) -> Ed25519PublicKey:
    p = path or PUB_PATH
    if not p.exists():
        load_or_create_key()
    return serialization.load_pem_public_key(p.read_bytes())


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def digest_files(paths: list[Path]) -> dict[str, str]:
    return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


def sign(payload: dict) -> str:
    return base64.b64encode(load_or_create_key().sign(canonical(payload))).decode()


def verify(payload: dict, sig_b64: str, pub: Ed25519PublicKey | None = None) -> bool:
    """True if any trusted key (or the given one) signed this payload. A signature proves origin, not truth."""
    for k in ([pub] if pub else trusted_keys()):
        try:
            k.verify(base64.b64decode(sig_b64), canonical(payload))
            return True
        except (InvalidSignature, ValueError):
            continue
    return False
