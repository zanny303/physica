"""The Feel Transform: any sensor stream -> a feelogram (feelings over time), separating self from world.

Steps (SPEC section 3):
  1 unify       -> physica.senses.cards.unify (units, common rate, delays, noise)
  2 self-cancel -> a self-model predicts what the machine itself causes; residual z = what it feels
  3 re-time     -> physica.feel.order (when a speed/phase signal exists)
  4 modes       -> physica.feel.dmd (frequency, growth/decay, shape across sensors)
  5 feelings    -> physica.feel.axes (units + error bars, or 'uncalibrated')
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from physica.feel.axes import damping_from_modes, drift_per_hour, subwindow_energy_stats, touch_impact_z
from physica.feel.dmd import dmd_modes
from physica.feel.feelogram import Feelogram
from physica.feel.selfmodel import OperatingPointSelfModel
from physica.feel.spectra import band_peak, window_psd

DISCLAIMER = "Advice, not a safety certification."


@dataclass
class FeelConfig:
    band: tuple[float, float] = (95.0, 200.0)  # where the machine's own rotation peaks live
    win_s: float = 5.0
    nperseg: int = 512
    q: float = 0.99
    margin: float = 0.5
    dmd_rank: int = 12
    dmd_delays: int = 16
    n_modes: int = 6
    localize_min_votes: float = 0.7
    localize_min_margin: float = 1.0
    unit_word: str = "rotor"
    localize_experiment: str = "spin each motor alone for 3 s on the ground, or provide per-motor RPM telemetry"


def windows(n: int, fs: float, seconds: float) -> list[tuple[int, int]]:
    w = int(round(seconds * fs))
    return [(s, s + w) for s in range(0, n - w + 1, w)]


class FeelTransform:
    def __init__(self, unit_names: list[str], cfg: FeelConfig | None = None,
                 self_model: OperatingPointSelfModel | None = None):
        self.unit_names = list(unit_names)
        self.cfg = cfg or FeelConfig()
        self.self_model = self_model
        self.touch_base: list[tuple[float, float]] | None = None
        self.fs: float | None = None

    # ---- features for the operating-point self-model ----
    def features(self, x: np.ndarray, fs: float):
        wins = windows(len(x), fs, self.cfg.win_s)
        f, psd = window_psd(x, fs, wins, self.cfg.nperseg)
        op, lvl = band_peak(psd, f, self.cfg.band)
        return wins, f, psd, op, lvl

    def fit(self, x: np.ndarray, fs: float, prior: OperatingPointSelfModel | None = None, lam: float = 0.0,
            window_idx: np.ndarray | None = None) -> "FeelTransform":
        """Learn 'what healthy feels like' from healthy data only. x: (N, units, axes)."""
        wins, f, psd, op, lvl = self.features(x, fs)
        if window_idx is not None:
            op, lvl = op[window_idx], lvl[window_idx]
            wins = [wins[i] for i in window_idx]
        sm = OperatingPointSelfModel(unit_names=self.unit_names)
        sm.fit(op, lvl, prior=prior, lam=lam)
        sm.calibrate_threshold(op, lvl, self.cfg.q, self.cfg.margin)
        self.self_model, self.fs = sm, fs
        seg = np.concatenate([x[s:e] for s, e in wins])
        self.touch_base = [subwindow_energy_stats(seg[:, u], fs) for u in range(len(self.unit_names))]
        return self

    def transform(self, x: np.ndarray, fs: float, t0: float = 0.0, with_modes: bool = True,
                  source: str = "") -> Feelogram:
        if self.self_model is None:
            raise RuntimeError("call fit() on healthy data first")
        wins, f, psd, op, lvl = self.features(x, fs)
        z = self.self_model.z(op, lvl)
        t = [t0 + (s + e) / 2 / fs for s, e in wins]
        touch, damping, modes_all = [], [], []
        for s, e in wins:
            seg = x[s:e]
            touch.append(None if self.touch_base is None else
                         max(touch_impact_z(seg[:, u], fs, *self.touch_base[u]) for u in range(seg.shape[1])))
            if with_modes:
                mag = np.linalg.norm(seg - seg.mean(axis=0), axis=-1) if seg.ndim == 3 else seg
                mag = mag - mag.mean(axis=0)
                m = dmd_modes(mag, fs, rank=self.cfg.dmd_rank, delays=self.cfg.dmd_delays,
                              n_channels=mag.shape[1])[: self.cfg.n_modes]
                modes_all.append(m)
                damping.append(damping_from_modes(m, self.cfg.band))
        felt_level = z.max(axis=1)
        axes = {"touch_impact": touch, "damping": damping if with_modes else None,
                "wobble_gmm": None, "weight": None, "stiffness": None, "friction": None, "wear_drift": None}
        verdict = self.verdict(z)
        verdict["wear_drift"] = drift_per_hour(np.array(t), felt_level)
        rng = self.self_model.op_range
        outside = ([] if rng is None else
                   [bool(((op[i] < rng[0]) | (op[i] > rng[1])).any()) for i in range(len(op))])
        return Feelogram(t=t, unit_names=self.unit_names, z=z.tolist(), threshold=self.self_model.threshold,
                         axes=axes, modes=modes_all, verdict=verdict,
                         meta={"source": source, "fs": fs, "band_hz": self.cfg.band, "win_s": self.cfg.win_s,
                               "speed_invariant": False, "self_model": "operating_point_poly",
                               "outside_proven_range": outside, "proven_op_range_hz": rng})

    def verdict(self, z: np.ndarray) -> dict:
        thr = self.self_model.threshold
        z = np.asarray(z)
        felt = z.max(axis=1) > thr
        n = len(z)
        frac = float(felt.mean()) if n else 0.0
        out = {"windows": n, "felt_windows": int(felt.sum()), "felt_fraction": frac, "disclaimer": DISCLAIMER}
        if felt.sum() == 0:
            out.update(status="healthy", text="Feels like its healthy self.")
            return out
        zf = z[felt]
        top = zf.argmax(axis=1)
        counts = np.bincount(top, minlength=z.shape[1])
        best = int(counts.argmax())
        share = float(counts[best] / felt.sum())
        srt = np.sort(zf, axis=1)
        margin = float(np.median(srt[:, -1] - srt[:, -2])) if z.shape[1] > 1 else np.inf
        out.update(status="felt", strongest_unit=self.unit_names[best], vote_share=share, median_margin_z=margin)
        confident = share >= self.cfg.localize_min_votes and margin >= self.cfg.localize_min_margin
        # Nothing counts until proven: only name a unit if localisation passed a held-out proof on this
        # machine type (a proven localisation card). Otherwise say what we can't tell, and how to find out.
        if confident and self.localization_proven:
            out["localized"] = True
            out["text"] = (f"Feels wrong near {self.cfg.unit_word} {self.unit_names[best]} "
                           f"({felt.sum()}/{n} windows felt).")
        else:
            out["localized"] = False
            why = ("locating it from this kind of data has not passed a held-out test for this machine"
                   if not self.localization_proven else "the evidence is split between units")
            out["text"] = (f"Feels wrong ({felt.sum()}/{n} windows felt). Strongest signal on arm "
                           f"{self.unit_names[best]}, but I can't tell which {self.cfg.unit_word} is damaged: {why}. "
                           f"To find out: {self.cfg.localize_experiment}.")
        return out

    localization_proven: bool = False
