"""Physica Sentinel: evidence-first condition monitoring and inquiry (v0.30).

Retrospective bearing warnings are NOT proof of avoided downtime, certified
remaining useful life, causal diagnosis, or a safe machine-control decision.
"""
