"""Write a self-contained hackathon evidence browser for a completed synthetic run."""
from __future__ import annotations
from pathlib import Path
import json


def render_demo(root: str|Path) -> Path:
    root=Path(root)
    data=json.loads((root/"demo_results.json").read_text())
    from .consequence import consequence_path
    bundle=json.dumps({"run":data,"bracket":consequence_path()},separators=(",",":"),ensure_ascii=False).replace("<","\\u003c")
    # One file, no network, no external assets. Numeric readouts reflect actual generated simulation files.
    html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Physica // Physical Experience Lab</title><style>
:root{font-family:Inter,ui-sans-serif,system-ui,-apple-system,sans-serif;color:#f3f5fe;background:#070b17;color-scheme:dark}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 15% 0%,#1d2749 0%,transparent 35%),radial-gradient(ellipse at 92% 15%,#122b39 0%,transparent 26%),#070b17}
main{max-width:1160px;margin:auto;padding:24px 28px 100px}.nav{display:flex;gap:15px;align-items:center;justify-content:space-between;padding:12px 0 34px}
.logo{letter-spacing:.27em;font-size:14px;font-weight:800}.logo b{color:#7ddaca}.version{font-size:11px;font-weight:700;border:1px solid #637ba0;padding:8px 11px;border-radius:50px;color:#9aabc9}
header{margin:38px 0}h1{font-size:clamp(38px,5.6vw,74px);line-height:1.03;max-width:900px;letter-spacing:-.065em;margin:18px 0}
h1 span{color:#a5f9d4}p{color:#b4c1dc;line-height:1.7;max-width:820px}.eyebrow{font-size:12px;letter-spacing:.22em;color:#7ddaca;text-transform:uppercase;font-weight:800}
.banner{border-left:3px solid #ffb965;background:#30241e;padding:16px 20px;border-radius:0 12px 12px 0;font-size:13px;line-height:1.6;color:#f8d0a0;margin:25px 0 35px}
nav.tabs{display:flex;flex-wrap:wrap;gap:10px;margin:20px 0}button{border:1px solid #3a4b67;color:#d8e9ff;border-radius:9px;padding:12px 17px;background:#121b31;cursor:pointer;font-weight:700}
button[aria-selected=true],button:hover{border-color:#62d6b3;background:#153a3e;color:#d9ffea}.panel{display:none}.panel.active{display:block}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:17px}.card{padding:23px;background:linear-gradient(145deg,#15213aee,#0d162aee);border:1px solid #263b55;border-radius:17px;min-width:0}
.card h2{font-size:20px;margin:3px 0 15px}.muted{color:#8a9ab6;font-size:12px}.metric{font-size:34px;font-weight:800;letter-spacing:-.03em;color:#a5f9d4}
.code{word-break:break-all;white-space:pre-wrap;font-family:ui-monospace,monospace;font-size:12px;color:#b3dbfa;background:#0a1428;border-radius:8px;padding:14px;overflow:auto}
.bar{height:10px;background:#303b50;border-radius:30px;overflow:hidden;margin-top:8px}.fill{height:100%;background:linear-gradient(90deg,#57b2d2,#83eec2)}
.prob{display:flex;justify-content:space-between;font-size:12px;margin-top:14px}.row{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid #29354d;gap:20px}
.tag{display:inline-block;border-radius:12px;background:#27454b;color:#96f4e6;font-size:10px;font-weight:800;padding:6px 9px;letter-spacing:.08em}
.warning{color:#ffc68e}canvas{width:100%;height:180px;background:#091529;border-radius:12px;margin-top:15px}footer{border-top:1px solid #303d55;margin-top:65px;padding-top:26px;color:#8c9baf;font-size:12px}
@media(max-width:740px){.grid{grid-template-columns:1fr}main{padding:18px}.nav{flex-wrap:wrap}button{font-size:12px}}
</style></head><body><main>
<div class="nav"><div class="logo">PHYSICA <b>// PACER</b></div><span class="version">v0.2 • OFFLINE LAB</span></div>
<header><div class="eyebrow">The language of physical experience</div><h1>Machines don’t just see. <span>They anticipate consequences.</span></h1>
<p>A numerical experiment in how one machine predicts, observes, updates and teaches another. Every action is risk-gated; every prediction can be cryptographically sealed.</p></header>
<div class="banner"><b>TRANSPARENCY:</b> This interactive lab is generated from SYNTHETIC NUMBERS. There are no real fan measurements, bracket fractures, V-JEPA runs or live Muse calls in these specific results. The original Physica repository has separate real-data analysis and experiments.</div>
<nav class="tabs"><button aria-selected="true" data-tab="sense">01 · FEEL</button><button aria-selected="false" data-tab="sealed">02 · SEAL & VERIFY</button><button aria-selected="false" data-tab="transfer">03 · TEACH MACHINE B</button><button aria-selected="false" data-tab="whatif">04 · CONSEQUENCE SANDBOX</button></nav>
<section id="sense" class="panel active"><div class="grid"><div class="card"><span class="tag">MACHINE A</span><h2>Physical words • normalized body signature</h2>
<div class="row"><span>Body class</span><b>Small guarded fan</b></div><div class="row"><span>Boundary</span><b>Bolted mount</b></div><div class="row"><span>Mode ratio</span><b>1.00 : 2.12</b></div><div class="row"><span>Measured action</span><b>Mount compliance check</b></div>
<p class="muted">A physical 'word' includes units, excitation level, calibration, sampling rate and provenance—not just a learned embedding.</p></div>
<div class="card"><span class="tag">CAUSAL HYPOTHESES</span><h2>Machine A after one synthetic action</h2><div id="pA"></div>
<p class="muted">The posterior is an inferred likelihood given this simulator, not certified hardware truth.</p></div></div>
<div class="card" style="margin-top:18px"><h2>Ghost motion: expected vs observed</h2><canvas id="wave" width="1050" height="180"></canvas><p class="muted">Illustrative harmonic traces; a visualization, not tracked video pixels.</p></div></section>
<section id="sealed" class="panel"><div class="grid"><div class="card"><span class="tag">SEALED PREDICTION</span><h2>Prediction committed before reveal</h2><div class="metric">2.42</div><p>Predicted normalized mount response · assumed σ = 0.45</p><div class="muted">SHA256 commitment</div><div class="code" id="hash"></div><p class="muted">Ed25519 signature verification is performed by the Python CLI, not by this read-only HTML file.</p></div>
<div class="card"><span class="tag">REVEALED OBSERVATION</span><h2>Simulator generated a consequence</h2><div class="metric" id="obs"></div><p id="residual"></p><div class="row"><span>Seal valid?</span><b id="validSeal"></b></div><div class="row"><span>Reveal signature valid?</span><b id="validReveal"></b></div><div class="row"><span>Outcome</span><b>See reveal artifact</b></div></div></div></section>
<section id="transfer" class="panel"><div class="grid"><div class="card"><span class="tag">BODY BANK</span><h2>Machine B receives an experience</h2><div class="row"><span>First mode, A</span><b>23.4 Hz</b></div><div class="row"><span>First mode, B</span><b>20.7 Hz</b></div><div class="row"><span>Mode-ratio match</span><b>1 : 2.12</b></div><div class="row"><span>Allowed to compare?</span><b id="comparable"></b></div><div class="row"><span>Source episode verified?</span><b>Yes (simulator)</b></div><p class="muted">Matching units, boundary conditions, sensor calibration and excitation are required.</p></div>
<div class="card"><span class="tag">KNOWLEDGE TRANSFER</span><h2>Machine B’s prior changes</h2><div class="muted">Before: uniform prior</div><div id="pPrior"></div><div class="muted" style="margin-top:25px">After receiving A’s signed episode</div><div id="pTransferred"></div></div>
<div class="card"><span class="tag">SAFE EXPERIMENT SELECTOR</span><h2>Next experiment</h2><div class="metric" style="font-size:25px" id="chosen"></div><p>Chosen numerically by expected information gain minus risk and cost.</p><div class="row"><span>Destructive test</span><b class="warning">REJECTED</b></div></div>
<div class="card"><span class="tag">OBSERVE & UPDATE</span><h2>Machine B tests the prediction</h2><div class="muted">Posterior with prior from A</div><div id="pAfter"></div><div class="muted" style="margin-top:20px">Same observation without A’s knowledge</div><div id="pNoBank"></div><p class="muted">This single illustrative seed shows prior influence, not a statistically validated transfer improvement.</p></div></div></section>
<section id="whatif" class="panel"><div class="grid"><div class="card"><span class="tag">COUNTERFACTUAL</span><h2>What if the next load broke a bracket?</h2><p>Explore an explicitly assumed coupon model. This sandbox never actuates hardware.</p>
<label for="load">Proposed load: <b id="loadLabel">4 N</b></label><input style="width:100%;accent-color:#73deb9" id="load" type="range" min="2" max="12" step="1" value="4">
<div class="row"><span>Predicted deflection</span><b id="deflection"></b></div><div class="row"><span>Probability of irreversible break</span><b id="failprob"></b></div><div class="row"><span>Risk gate (5% maximum)</span><b id="gate"></b></div>
<p class="warning">Not an engineering safety calculation. Failure prior is hypothetical until real destructive coupon tests establish it.</p></div>
<div class="card"><span class="tag">LEARNED CONSEQUENCES</span><h2>Prediction → surprise → new experience</h2><p>Physica treats "feeling" operationally: it predicts a sensor response, compares it with actual observations, updates hypotheses, and creates a transferable signed physical episode.</p>
<div class="row"><span>Model</span><b>Linear elastic & Gaussian failure load</b></div><div class="row"><span>Mean failure load</span><b>10 N (assumed)</b></div><div class="row"><span>Uncertainty</span><b>1.5 N (assumed)</b></div><div class="row"><span>Physical break experiment</span><b class="warning">NOT PERFORMED</b></div></div></div></section>
<footer>Physica © • This demo is an educational simulation. Original Feel Transform and hardware experiments are part of the same source repository. No performance claims imply generalization to unobserved machines. Advice, not a safety certification.</footer>
<script type="application/json" id="data">__DATA__</script><script>
const D=JSON.parse(document.getElementById('data').textContent),r=D.run;
const labels={imbalance:'Rotor imbalance',loose_mount:'Loose mounting',bearing_wear:'Bearing wear'};
function bars(id,values){let html='';Object.entries(values).sort((a,b)=>b[1]-a[1]).forEach(([k,v])=>{html+=`<div class="prob"><span>${labels[k]||k}</span><b>${(v*100).toFixed(1)}%</b></div><div class="bar"><div class="fill" style="width:${(100*v).toFixed(4)}%"></div></div>`});document.getElementById(id).innerHTML=html}
function init(){bars('pA',r.machine_A_posterior);bars('pPrior',{imbalance:1/3,loose_mount:1/3,bearing_wear:1/3});bars('pTransferred',r.machine_B_transfer.prior);bars('pAfter',r.machine_B_posterior_with_bank);bars('pNoBank',r.machine_B_posterior_without_bank);
 document.getElementById('comparable').textContent=r.machine_B_transfer.comparison.status.toUpperCase();document.getElementById('chosen').textContent=r.safe_experiment_with_bank.chosen.replace(/_/g,' ');
 document.getElementById('validSeal').textContent=String(r.seal_valid).toUpperCase();document.getElementById('validReveal').textContent=String(r.reveal_valid).toUpperCase();
 document.getElementById('obs').textContent=r.machine_B_observation.toFixed(3);document.getElementById('residual').textContent='Machine B test outcome, normalized response. This is a synthetic observation.';
 document.getElementById('hash').textContent='SHA-256 + Ed25519 commitments are in sealed_before_observation.json and revealed_consequence.json';
 draw();risk();}
const c=document.getElementById('wave'),ctx=c.getContext('2d');function draw(){ctx.clearRect(0,0,c.width,c.height);for(const [color,p,amp] of [['#70dfbd',0,30],['#eab476',.26,31]]){ctx.beginPath();ctx.strokeStyle=color;ctx.lineWidth=2;for(let i=0;i<1050;i++){let t=i/1050;let y=90+Math.sin(2*Math.PI*25*t+p)*Math.exp(-4*t)*amp+Math.sin(2*Math.PI*53*t)*Math.exp(-4*t)*10;if(i===0)ctx.moveTo(i,y);else ctx.lineTo(i,y)}ctx.stroke()}ctx.font='14px system-ui';ctx.fillStyle='#70dfbd';ctx.fillText('Predicted',20,25);ctx.fillStyle='#eab476';ctx.fillText('Observed (illustrative)',110,25)}
function risk(){let load=Number(document.getElementById('load').value);let records=D.bracket;let row=records.find(r=>r.force_n===load)||records[0];document.getElementById('loadLabel').textContent=`${load} N`;document.getElementById('deflection').textContent=`${(row.predicted_deflection_m*1000).toFixed(2)} mm`;document.getElementById('failprob').textContent=`${(row.probability_irreversible_break*100).toFixed(2)}%`;let gate=document.getElementById('gate');gate.textContent=row.decision.includes('STOP')?'STOP: unacceptable assumed risk':'SIMULATION BELOW ASSUMED LIMIT';gate.style.color=row.decision.includes('STOP')?'#ffc68e':'#a5f9d4'}
document.getElementById('load').addEventListener('input',risk);document.querySelectorAll('nav.tabs button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('nav.tabs button').forEach(x=>x.setAttribute('aria-selected',String(x===b)));document.querySelectorAll('.panel').forEach(x=>x.classList.toggle('active',x.id===b.dataset.tab))}));init();
</script></main></body></html>'''.replace('__DATA__',bundle)
    dest=root/"experience_lab.html";dest.write_text(html)
    return dest
