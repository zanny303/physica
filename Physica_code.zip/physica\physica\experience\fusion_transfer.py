"""Optional billed live Meta A-side scientific review -> CRATE B-side sealed forecast.

The source camera/CSV must depict the ALREADY COMPLETED source experiment,
never the unknown B outcome. Muse proposes explanations, SAM provides optical
geometry, and a deterministic numeric safety gate controls eligibility. Only
an explicitly confirmed action can enter the sealed B forecast. No actuation.
"""
from __future__ import annotations
import json
from pathlib import Path
from .meta_fusion import run as run_meta
from .field_protocol import file_hash,read_calibration
from .causal_transport import select_safe_probe
from .crate_field import prepare


def run(source_video,source_sensor_csv,experiment_request_json,
        sources_manifest,target_calibration,target_times_csv,*,concept,
        bbox_track_id,meters_per_pixel,fps,expected_action,output,
        explicit_bill_permission=False):
    if not explicit_bill_permission:
        raise PermissionError('Explicit --allow-billed-meta required for hosted model calls')
    if not expected_action or not isinstance(expected_action,str):
        raise ValueError('explicit expected action ID required')
    out=Path(output)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError('refuse overwrite of existing precommitted experiment')
    raw=json.loads(Path(experiment_request_json).read_text())
    chosen_candidates=[x for x in raw['actions'] if x['action_id']==expected_action]
    if len(chosen_candidates)!=1:
        raise ValueError('expected action must appear exactly once in experiment whitelist')
    candidate=chosen_candidates[0]
    target=read_calibration(target_calibration)
    gate=select_safe_probe([{'id':expected_action,'force_n':target.applied_step_force_n,
        'risk':candidate['risk'],'approved':candidate['safety_approved'],
        'irreversible':candidate['irreversible'],'cost':candidate.get('cost',0.)}],target)
    if gate['chosen']!=expected_action:
        raise ValueError('target calibration/action failed independent physical safety gate')
    # Preflight first to avoid unnecessary billing when source files absent.
    for p in (source_video,source_sensor_csv,sources_manifest,target_calibration,target_times_csv):
        if not Path(p).is_file():raise FileNotFoundError(p)
    out.mkdir(parents=True,exist_ok=False)
    meta_path=out/'01_live_source_meta_review.json'
    # Spark/SAM/Wonder actually execute, with real source-video measurement
    # cross-check. Model outputs cannot supply unmeasured target displacements.
    fusion=run_meta(source_video,source_sensor_csv,experiment_request_json,
        concept=concept,bbox_track_id=bbox_track_id,meters_per_pixel=meters_per_pixel,
        fps=fps,output=meta_path,explicit_bill_permission=True)
    if fusion.get('selected_experiment')!=expected_action:
        raise ValueError('physical experiment selector did not choose the expected action; no B prediction sealed')
    pred=prepare(sources_manifest,target_calibration,target_times_csv,out/'02_B_pretest',
        upstream_meta_sha256=file_hash(meta_path),chosen_action_id=expected_action,
        risk_evidence={'meta_fusion_selected':expected_action,'physical_probe_gate':gate,
                       'operator_approved_whitelist':candidate['safety_approved']})
    return {'status':'LIVE_META_A_SOURCE_AND_CRATE_B_PREPARED',
            'meta_source_review':str(meta_path),'meta_sha256':file_hash(meta_path),
            'target_precommit_dir':str(out/'02_B_pretest'),
            'prediction_sha256':pred['prediction_sha256'],
            'no_hardware_actuation':True,
            'warning':'Real-model responses and signed predictions are not real B verification; record B separately.'}
