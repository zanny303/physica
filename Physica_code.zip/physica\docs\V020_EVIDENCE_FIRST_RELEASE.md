# Physica v0.20 — Evidence First, Before Prediction or Action

## The hypothesis worth testing

**Can a physical agent reduce incorrect diagnoses and unnecessary interventions by knowing when a measurement is insufficient, requesting the smallest *goal-relevant* experiment, and conditionally transferring only the verified result to a different machine?**

v0.20 adds one small experimental component to the existing MACE algorithms: **ESAI (Evidence Sufficiency and Active Inquiry)**. ESAI is not a previously unknown mathematical discovery. Gaussian Bayesian information gain and value-of-information are established. The combination with a strict model-template contract, evidence provenance, physical safety gates and the existing outcome/transfer systems is an **engineering and research hypothesis**. The relevant comparator is a standard Bayesian experimental designer with equal data/costs, not only a random probe.

## Execute locally

```powershell
cd C:\Users\budhw\Downloads\physicanew\physica
$env:PYTHONUTF8 = '1'
..\.venv\Scripts\python.exe -m pip install -e ".[dev,video]"
..\.venv\Scripts\python.exe -m physica.studio --open-browser
```

Click **Try your own physical evidence** → choose CSV or a short MP4 → optionally describe the device. Unknown is a successful scientific outcome when the input cannot identify the mechanism. The file and numerical measurements remain local unless you explicitly approve a Meta request. Studio is localhost-only by default.

Command line:

```powershell
..\.venv\Scripts\python.exe -m physica.auto ".\my_sensor.csv"
..\.venv\Scripts\python.exe -m pytest -q tests\test_v020_evidence_and_meta.py
```

For a controlled simulator example:

```powershell
..\.venv\Scripts\python.exe -m physica.fan_sim .\demo\lab_rotor
```

Create the output directory first. This uses simulated videos; a real balancing experiment requires a **guarded and manufacturer-rated training rig**, a tachometer, a trained operator, and an independent safety review. Never improvise weights on operating household fans, propellers or turbines.

## Why the old demonstration failed

The previous video pipeline switched from phase-derived displacement to optical-flow velocity according to each recording's motion amplitude. It could therefore compare incomparable spectral amplitudes, and select a strong third harmonic as the fundamental. v0.20 forces all balancing recordings through the same optical-flow velocity pathway and uses a robust common-frequency choice. It still requires independent rotational-speed confirmation before actionable advice. The after-clip verifier must use `consistent_video_signal` as well.

## What the active acquisition planner actually proves

`physica.investigation.expected_information_gain(prior,candidates)` and `goal_directed_value_of_information(prior,candidates,goal_payoffs)` are **numerical decision methods**. Both require predeclared numerical predictions, noise assumptions and allowed experiments. They do not hallucinate those inputs from a video, a language model, or arbitrary text. Their included synthetic test distinguishes a nuisance feature from a measurement that changes which goal-oriented action is best. This is not an empirical generalization guarantee.

The research target is to learn robust observation likelihoods on independent real hardware, select a safe test, and prospectively demonstrate fewer experiments than matched classical and hierarchical baselines. The full discovery/transfer pipeline is retained but is not shown to be superior by this release.

## Meta deployment

The code uses Meta Model API's existing structured Chat Completions path (`muse-spark-1.3` default), and the existing SAM 3.1 Responses adapter. Meta may nominate a recognized system or visual object. **Compatibility is checked again after the model output**: F1 requires a real F1 stream schema, blade analysis requires a recognized blade schema, and structural models require supported measurements. Unsupported nominations are refused. For a real paid request, set both `MODEL_API_KEY` and `MOCK=0`, enable the billing checkbox in Studio, and acknowledge the browser confirmation. Meta spending reservations are now serialized across processes, but estimated requests and provider bills can differ; monitor the provider billing dashboard.

Official references: https://dev.meta.ai/docs/overview, https://dev.meta.ai/docs/sam/client-libraries, https://dev.meta.ai/docs/sam/overview.

## Three-minute demo plan

**0:00–0:20:** Open the new Physica front page. Say: "AI can see and hear. Physica attempts to infer how the world *behaves*, and knows when it doesn't know." Drop a real supported video/CSV; show actual measured spectral peaks.

**0:20–0:55:** Supply an ambiguous 12 Hz recording. Physica detects 12 Hz but refuses to call it a fan or guitar. Ask which measurement matters to a concrete outcome; show the safe tachometer/reference request. A judge can see that the model does not hallucinate a physical identity.

**0:55–1:40:** Show *one* predeclared real evidence analysis—beam or F1 telemetry—with its original observation, independent comparator and known limitations. If using F1, say these are model-conditional effective forces and a simulator check, not measured downforce or track-verified wing improvement.

**1:40–2:20:** Demonstrate outcome planning and a signed prediction. Show a machine-code draft with review-only and explicit refusals, not an unattended actuator.

**2:20–2:50:** Show Lab/Discover/Lens and a supervised **simulated** A→B transferable experience. Show when it refuses an incompatible transfer. If authenticated Meta inference has been run locally, include its genuine receipt and a no-Meta comparison; otherwise clearly label the offline fallback.

**2:50–3:00:** "Physica doesn't just name the object. It measures, reasons about uncertainty, asks the right question, and only then makes a testable promise."

Never claim that a successful emulator check is proof of real-world hardware safety, or that real-world scientific discovery/novelty has been demonstrated.

## Safety, privacy and real-evidence limitations

- No autonomous household fan balancing. No drone, blade, turbine or PLC execution without external authorization and independent safety engineering.
- Distinguish direct measured vibrations/frequencies from inferred effective physical parameters.
- Signed local forecasts ensure integrity of committed bytes but cannot establish chronology independently without an external witness.
- Data labeling in prior releases includes simulated F1 adjustments, simulated fan clips and archived real-data reports not re-executed here.
- Large or arbitrary files may be refused because local video and numeric processing are bounded by resource limits.
