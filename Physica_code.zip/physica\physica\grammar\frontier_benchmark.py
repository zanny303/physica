"""Reproducible synthetic benchmark of identifiability and context gates.
Not a validated Meta model, not a physical machine. Explicit OOD challenge.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .discovery import SafeProbe,probe_options,measured_update,calibrated_meta_prior
from .simulator import cal
from .world_readout import fit_readout


def run(seed=43,n=32):
    if n<8 or n>500:raise ValueError('8..500 independent simulations')
    rng=np.random.default_rng(seed)
    t=np.linspace(0,.28,80)
    # Same fixture, rival *mechanistic* hypotheses. The source set is declared.
    c0=cal('fixture',4.1,125,z=.05)
    c1=cal('fixture',5.2,190,z=.06)
    hypotheses={'mount_ok':c0,'mount_changed':c1}
    priors={'mount_ok':.5,'mount_changed':.5}
    experiments=[SafeProbe('quiet_visual',.05,.02,.1,'vision',.00008),
                 SafeProbe('hear_tap',.14,.04,.2,'hearing',.0015),
                 SafeProbe('inertial_probe',.22,.09,.1,'proprioception',.08),
                 SafeProbe('destructive',10,.95,0.,'touch',.01,False)]
    selection=probe_options(priors,hypotheses,experiments,t,max_risk=.12,min_separation=.01,max_force_n=.3)
    selected=next(p for p in experiments if p.action_id==selection['chosen_action_id'])
    # Our true hidden cause is sampled AFTER probe plan is fixed. No target leakage.
    from .discovery import prediction
    good=[];random_choice=[]
    for _ in range(n):
        truth=int(rng.integers(0,2));which=list(hypotheses)[truth]
        yy=prediction(hypotheses[which],selected,t)+rng.normal(0,selected.sigma_si,len(t))
        update=measured_update(priors,hypotheses,selected,t,yy,correlated_sample_factor=.25)
        good.append(update['posterior_under_model'][which])
        choice=experiments[int(rng.integers(0,3))]
        yy2=prediction(hypotheses[which],choice,t)+rng.normal(0,choice.sigma_si,len(t))
        upd2=measured_update(priors,hypotheses,choice,t,yy2,correlated_sample_factor=.25)
        random_choice.append(upd2['posterior_under_model'][which])
    # World latent artifact: simulated feature->SI calibration, not real V-JEPA
    tx=rng.normal(size=(80,6));cx=rng.normal(size=(30,6));vx=rng.normal(size=(20,6))
    ty=.01*tx[:,0]+.003*tx[:,1]+rng.normal(0,.001,len(tx))
    cy=.01*cx[:,0]+.003*cx[:,1]+rng.normal(0,.001,len(cx))
    vy=.01*vx[:,0]+.003*vx[:,1]+rng.normal(0,.001,len(vx))
    readout=fit_readout(tx,ty,cx,cy,train_body_ids=[f't{i}' for i in range(len(tx))],
      cal_body_ids=[f'c{i}' for i in range(len(cx))],model_id='SYNTHETIC_FEATURES_NOT_VJEPA',
      observable='displacement',unit='m')
    forecast=readout.predict(vx,body_ids=[f'v{i}' for i in range(len(vx))])
    in_domain=[(i,f) for i,f in enumerate(forecast) if f['interval'] is not None]
    cover=sum(f['interval'][0]<=vy[i]<=f['interval'][1] for i,f in in_domain)
    shifted=readout.predict(np.full((3,6),60.),body_ids=['d0','d1','d2'])
    meta_uncal=calibrated_meta_prior(priors,['mount_changed'])
    return {'provenance':'SIMULATION_ONLY','seed':seed,'n_experiments':n,
       'selected_safe_probe':selection['chosen_action_id'],'probe_ranking':[{
           k:v for k,v in p.items() if k!='model_curves'} for p in selection['ranking']],
       'mean_posterior_true_cause_optimal':float(np.mean(good)),
       'mean_posterior_true_cause_random':float(np.mean(random_choice)),
       'note':'Gaussian simulated data from exact candidate model. No Meta model called; not proof of causal identifiability or generalization.',
       'uncalibrated_meta_prior_unchanged':meta_uncal['prior']==priors,
       'synthetic_embedding_split_conformal_accepted':len(in_domain),
       'synthetic_embedding_split_conformal_coverage':float(cover/len(in_domain)) if in_domain else None,
       'synthetic_embedding_shift_rejected':sum(x['status']=='abstain_latent_out_of_domain' for x in shifted),
       'limit':'Latent OOD novelty can miss hidden dynamics shift, and conditional coverage is NOT guaranteed'}

def write(path,*,seed=43,n=32):
    result=run(seed,n);p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');return result
