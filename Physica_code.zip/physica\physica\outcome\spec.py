"""Outcome specs: the goal, written so a machine can check it.

`parse_goal(text, machine)` asks Muse Spark (live, when MOCK=0 and
MODEL_API_KEY are set) to fill the JSON schema below. Without a key it uses a
small offline parser for the demo phrasings and says so in `source`.
Either way the spec is only a proposal: the engineer and the physics decide.
"""
from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field

MACHINES = ("beam", "turbine", "drone", "pendulum", "f1")

SCHEMA = {
    "name": "outcome_spec",
    "strict": True,
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["machine", "objective", "constraints", "context", "unclear"],
        "properties": {
            "machine": {"type": "string", "enum": list(MACHINES)},
            "objective": {"type": "string", "enum": [
                "min_move", "max_clearance", "max_energy", "min_settle_time", "min_flight_time", "min_lap_time"]},
            "constraints": {"type": "array", "items": {
                "type": "object", "additionalProperties": False,
                "required": ["quantity", "op", "value"],
                "properties": {
                    "quantity": {"type": "string"},
                    "op": {"type": "string", "enum": ["outside_band_pct", "<=", ">=", "never"]},
                    "value": {"type": "number"}}}},
            "context": {"type": "object", "additionalProperties": False,
                        "required": ["forcing_hz", "temp_c", "hours", "target", "deadline_s"],
                        "properties": {k: {"type": ["number", "null"]} for k in
                                       ("forcing_hz", "temp_c", "hours", "target", "deadline_s")}},
            "unclear": {"type": "array", "items": {"type": "string"}},
        },
    },
}


@dataclass
class OutcomeSpec:
    machine: str
    goal_text: str
    objective: str
    constraints: list = field(default_factory=list)
    context: dict = field(default_factory=dict)
    unclear: list = field(default_factory=list)
    source: str = "offline parser"

    def get(self, quantity: str, op: str | None = None):
        for c in self.constraints:
            if c["quantity"] == quantity and (op is None or c["op"] == op):
                return c["value"]
        return None

    def to_json(self) -> dict:
        return asdict(self)


_NUM = r"(-?\d+(?:\.\d+)?)"


def _find(pattern: str, text: str):
    m = re.search(pattern, text, re.I)
    return float(m.group(1)) if m else None


def offline_parse(text: str, machine: str | None = None) -> OutcomeSpec:
    """Deterministic parser for the demo phrasings. It refuses to guess what it can't read."""
    t = text.lower()
    m = machine or next((k for k, words in {
        "f1": ("f1", "formula", "lap", "silverstone", "race car", "racecar", "top speed", "downforce"),
        "turbine": ("turbine", "blade", "wind"), "drone": ("drone", "fly", "inspect"),
        "pendulum": ("pendulum", "motor", "settle", "remote lab"),
        "beam": ("beam", "bridge", "resonan", "support", "pump", "hz")}.items()
        if any(w in t for w in words)), None)
    unclear = []
    if m is None:
        return OutcomeSpec("unknown", text, "min_move", [], {}, ["which machine?"])
    ctx = {"forcing_hz": None, "temp_c": None, "hours": None, "target": None, "deadline_s": None}
    cons = []
    if m == "beam":
        ctx["forcing_hz"] = _find(_NUM + r"\s*hz", t)
        pct = _find(_NUM + r"\s*%", t)
        if ctx["forcing_hz"] is None:
            unclear.append("what frequency should the beam avoid?")
        cons.append({"quantity": "tone_hz", "op": "outside_band_pct",
                     "value": pct if pct is not None else 5.0})
        if pct is None:
            unclear.append("no margin given; using 5%")
        obj = "max_clearance" if "far" in t or "clearance" in t else "min_move"
    elif m == "turbine":
        ctx["temp_c"] = _find(_NUM + r"\s*(?:°|deg|degrees)?\s*c\b", t)
        ctx["hours"] = _find(_NUM + r"\s*(?:h|hours)\b", t) or 12.0
        cons.append({"quantity": "cracked_blade_running", "op": "never", "value": 0})
        obj = "max_energy"
    elif m == "drone":
        ctx["target"] = _find(r"blade[^0-9]*" + _NUM + r"\s*m", t)
        cons.append({"quantity": "standoff_m", "op": ">=", "value": _find(_NUM + r"\s*m\s*(?:away|standoff|clear)", t) or 12.0})
        obj = "min_flight_time"
    elif m == "f1":
        loss = _find(_NUM + r"\s*km/?h", t)
        corner = any(w in t for w in ("maggotts", "becketts", "corner", "chapel"))
        if loss is not None:
            cons.append({"quantity": "corner_speed_loss_kmh" if corner else "top_speed_loss_kmh", "op": "<=", "value": loss})
        else:
            unclear.append("no speed budget given: unconstrained")
        drv = re.search(r"\b(?:car|#)\s*(\d{1,2})\b", text, re.I) or re.search(r"\b([A-Z]{3})\b", text)
        ctx["target"] = None
        if drv:
            ctx["car"] = drv.group(1)
        obj = "min_lap_time"
    else:
        ctx["target"] = _find(r"(?:to|reach)\s*" + _NUM + r"\s*(?:rad|radians?)", t)
        ctx["deadline_s"] = _find(r"(?:within|under|in)\s*" + _NUM + r"\s*s", t)
        os_ = _find(_NUM + r"\s*%\s*overshoot", t) or _find(r"overshoot[^0-9]*" + _NUM + r"\s*%", t)
        cons.append({"quantity": "overshoot_pct", "op": "<=", "value": os_ if os_ is not None else 5.0})
        if ctx["deadline_s"]:
            cons.append({"quantity": "settle_s", "op": "<=", "value": ctx["deadline_s"]})
        obj = "min_settle_time"
    return OutcomeSpec(m, text, obj, cons, ctx, unclear, "offline parser")


def parse_goal(text: str, machine: str | None = None, live: bool | None = None) -> OutcomeSpec:
    from . import muse
    if live is None:
        live = muse.live_enabled()
    if not live:
        return offline_parse(text, machine)
    sys_prompt = ("You turn an operator's goal for a physical machine into a strict JSON spec. "
                  "Never invent numbers the operator did not give; put missing ones in `unclear` "
                  "and use null. Machines: beam (a structure whose support can move), turbine "
                  "(wind turbine with blade sense), drone (inspection flight), pendulum (remote-lab motor).")
    user = json.dumps({"goal": text, "machine_hint": machine})
    out = muse.chat_json(sys_prompt, user, SCHEMA, task="outcome_spec")
    return OutcomeSpec(out["machine"], text, out["objective"], out["constraints"],
                       out["context"], out.get("unclear", []), f"{muse.model()} (live)")
