"""Drop anything in. Physica (with Meta) works out what physical system it is, which physics applies, and what it can
feel there that no sensor on it measures. No separate app per domain: one router over one library of senses.

    physica auto <video | sensor file | telemetry folder> [--fps 600] [--live]

1. INSPECT  the input: file signatures (F1 live timing, turbine-blade spectra, DROPBEAR trials, phone CSVs, video) and,
            for any signal or video, its motion spectrum: tones, harmonic families, ringing vs steady.
2. IDENTIFY the system. Live: Muse Spark reads the evidence and the template library and names the system, the
            template, what to watch (a SAM 3.1 concept) and what to ask the user, as strict JSON; Physica checks the
            choice fits the input. Offline: a signature + spectrum matcher, labelled as such.
3. SEE      (video, live): SAM 3.1 finds the named part; motion is read inside its box.
4. MAP      the senses with the template's physics: each felt quantity with an error bar, what measures it today
            (usually nothing), and the goals and experiments it unlocks.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np

VIDEO = {".mp4", ".mov", ".avi", ".mkv", ".m4v", ".webm"}

TEMPLATES = {
    "race_car": {"system": "a race car on track", "needs": "live-timing telemetry (speed, throttle, position)",
                 "feels": ["power", "drag area", "DRS drag cut", "downforce"],
                 "goals": ["faster lap within a corner-speed or top-speed budget"], "next": "eval/e24_f1_feel_and_advise.py"},
    "turbine_blade": {"system": "a wind-turbine blade", "needs": "vibration spectra with temperature",
                      "feels": ["temperature law of each mode", "added mass (ice) in grams", "stiffness loss (crack)"],
                      "goals": ["monitor icing versus other possible damage; manual inspection before restarting"], "next": "eval/e20_wind_blade.py"},
    "beam_support": {"system": "a structure whose support moves", "needs": "accelerometer + actuator position",
                     "feels": ["where the support sits", "tone vs support position (a map with error bars)"],
                     "goals": ["stay clear of a forcing frequency, moving as little as possible"], "next": "physica outcome"},
    "strings": {"system": "vibrating strings (an instrument, cables, stays)", "needs": "high-speed video or a contact sensor",
                "feels": ["each string's frequency", "relative tuning (tension needs length and linear mass density)", "which note / how far out of tune"],
                "goals": ["retension to a target pitch"], "next": "physica auto"},
    "rotating_machine": {"system": "a rotating machine (fan, washer drum, rotor, pump)", "needs": "video or phone accelerometer",
                         "feels": ["speed (rpm)", "imbalance (once per turn)", "misalignment (twice per turn)",
                                   "looseness (many harmonics)"],
                         "goals": ["stop the wobble: where to add how many grams"],
                         "next": "physica auto --balance as_is.mp4 coin_blade1.mp4 coin_blade2.mp4 coin_blade3.mp4"},
    "ringing_structure": {"system": "a structure that rings (beam, ruler, shelf, bridge deck)", "needs": "video or accelerometer",
                          "feels": ["its tones and damping", "what kind of body", "mass vs stiffness changes"],
                          "goals": ["what changed it, where; move a support to retune"], "next": "physica cause plan"},
    "unknown": {"system": "not identified", "needs": "-", "feels": [], "goals": [], "next": "say what it is"},
}


# ---------------------------------------------------------------------------------------------- 1. inspect
def _peaks(Y: np.ndarray, fs: float, fmin: float = 1.0, k: int = 8):
    from scipy.signal import find_peaks, welch
    Y = np.asarray(Y, float)
    Y = Y[:, None] if Y.ndim == 1 else Y
    Y = Y - Y.mean(0)
    f, P = welch(Y, fs=fs, nperseg=min(len(Y), max(int(fs * 2), 64)), axis=0)
    p = P.sum(1)
    m = f >= fmin
    f, p = f[m], p[m]
    idx, _ = find_peaks(np.log10(p + 1e-30), prominence=0.5)
    idx = idx[np.argsort(p[idx])[::-1][:k]]
    return [(float(f[i]), float(p[i] / p.max())) for i in sorted(idx)], f, p


def _harmonic_families(peaks, tol: float = 0.04):
    """Group peaks into families f0, 2f0, 3f0 ... (strong peaks first)."""
    fams, used = [], set()
    for f0, a0 in sorted(peaks, key=lambda x: -x[1]):
        if f0 in used:
            continue
        fam = [f0]
        for f, a in peaks:
            if f != f0 and f not in used:
                r = f / f0
                if r > 1.5 and abs(r - round(r)) < tol * round(r):
                    fam.append(f)
        used.update(fam)
        fams.append(sorted(fam))
    return fams


def inspect(path: str | Path, fps: float | None = None, region=None) -> dict:
    p = Path(path)
    ev = {"name": p.name, "is_dir": p.is_dir()}
    if p.is_dir():
        names = sorted(x.name for x in p.iterdir())[:40]
        ev["files"] = names
        if "car_data.raw" in names and "position.raw" in names and all(
                (p / name).is_file() and (p / name).stat().st_size >= 128
                for name in ("car_data.raw", "position.raw")):
            ev["signature"] = "f1_live_timing"
        elif any(n.startswith("Case_") and n.endswith(".npz") for n in names):
            ev["signature"] = "blade_spectra_folder"
        return ev
    suf = p.suffix.lower()
    if suf == ".npz" and p.name.startswith("Case_") and p.is_file():
        from physica.data import blade_eth
        if blade_eth._NAME.match(p.name) and p.stat().st_size > 100:
            ev["signature"] = "blade_spectrum"
            return ev
    if suf == ".txt":
        head = p.read_text(errors="replace")[:600]
        if "Low G Accel" in head and "PinLoc" in head:
            ev["signature"] = "dropbear_trial"
            return ev
    if not p.exists():
        raise ValueError('Input file is missing')
    if p.suffix.lower() not in VIDEO | {'.csv', '.tsv', '.txt', '.npy'}:
        raise ValueError('Unsupported file type. Supply a video, numeric CSV/TSV, NPY signal, or known dataset folder.')
    if p.stat().st_size > 150 * 1024 * 1024:
        raise ValueError('Input exceeds 150 MB inspection limit; supply a representative sample.')
    if p.suffix.lower() in VIDEO:
        import cv2
        cap=cv2.VideoCapture(str(p))
        try:
            frames=cap.get(cv2.CAP_PROP_FRAME_COUNT)
            height=cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            width=cap.get(cv2.CAP_PROP_FRAME_WIDTH)
        finally: cap.release()
        if frames > 1200 or frames*width*height > 48_000_000:
            raise ValueError('Video exceeds local motion-analysis budget. Trim to a short clip or resize to 640x480.')
    from physica.sense import load_source
    try:
        src = load_source(p, fps, region)
        Y, fs = np.asarray(src["Y"], float), float(src["fs"])
    except (ValueError, IndexError, TypeError, OSError) as ex:
        raise ValueError('Cannot parse this as a calibrated numeric signal or supported video; check the file format.') from ex
    if Y.ndim not in (1, 2) or Y.size < 128 or not np.isfinite(Y).all() or not np.isfinite(fs) or fs <= 0:
        raise ValueError('Signal must have at least 128 finite samples and a valid sampling rate.')
    Y = Y[:, None] if Y.ndim == 1 else Y
    pc = (Y - Y.mean(0)) @ np.linalg.svd((Y - Y.mean(0))[:: max(len(Y) // 3000, 1)], full_matrices=False)[2][0]
    thirds = np.array_split(pc ** 2, 3)
    peaks, f, P = _peaks(Y, fs)
    peakiness = float(np.max(P) / max(np.median(P), 1e-20)) if len(P) else 0.0
    concentration = float(np.max(P) / max(np.sum(P), 1e-20)) if len(P) else 0.0
    ev.update({'spectral_peak_to_median': round(peakiness, 3),
               'spectral_peak_fraction': round(concentration, 5),
               'measurement_status': 'observed signal; device identity and causal mechanism unverified',
               "kind": src["kind"], "fs": fs, "seconds": round(len(Y) / fs, 2), "channels": int(Y.shape[1]),
               "peaks_hz": [round(a, 2) for a, _ in peaks], "peak_strength": [round(b, 3) for _, b in peaks],
               "families_hz": [[round(x, 2) for x in fam] for fam in _harmonic_families(peaks)],
               "decay_ratio": float(np.mean(thirds[0]) / max(np.mean(thirds[2]), 1e-30)), "measure": src["measure"]})
    if src["kind"] == "video":
        ev["fps_note"] = ("frame rate read from the file" if fps is None else f"frame rate given: {fps:g} fps "
                          "(high-speed footage is often stored at 30 fps)")
    return ev


# ---------------------------------------------------------------------------------------------- 2. identify
def _unknown(reason: str, questions=None, source='offline matcher') -> dict:
    return {'template': 'unknown', 'why': reason, 'watch': None,
            'ask_user': questions or ['What physical device produced this recording?',
                                      'Can you supply a measured speed, action, or synchronized second sensor?'],
            'source': source, 'confidence': 'insufficient evidence',
            'provenance': 'classification withheld; frequencies do not uniquely identify an object'}


def identify_offline(ev: dict) -> dict:
    """Conservative *phenomenon* matching. A tone does not uniquely name an object."""
    sig = ev.get('signature')
    by_sig = {'f1_live_timing': ('race_car', 'F1 telemetry folder with required raw streams'),
              'blade_spectra_folder': ('turbine_blade', 'recognized blade spectra dataset folder'),
              'blade_spectrum': ('turbine_blade', 'recognized blade experiment file'),
              'dropbear_trial': ('beam_support', 'recognized DROPBEAR experiment structure')}
    if sig in by_sig:
        t, why = by_sig[sig]
        return {'template': t, 'why': why, 'watch': None, 'ask_user': [],
                'source': 'offline signature', 'confidence': 'recognized input schema'}
    peaks = ev.get('peaks_hz') or []
    fams = ev.get('families_hz') or []
    if not peaks:
        return _unknown('No clear periodic peaks; this may be noise, missing motion or unsupported data.')
    if ev.get('spectral_peak_to_median', float('inf')) < 12 or ev.get('spectral_peak_fraction', 1.0) < .055:
        return _unknown('No sufficiently dominant, reproducible periodic structure to name a system.')
    ringing = ev.get('decay_ratio', 1) > 3
    # Multiple independently visible harmonic families in high-speed footage is an
    # observable *string-like motion* signature; it does NOT establish the object identity.
    hi = [f for f in fams if f[0] >= 40 and len(f) >= 2]
    if ev.get('kind') == 'video' and len(hi) >= 2:
        return {'template': 'strings', 'why': 'multiple separate harmonic tone families in video; string-like motion, not confirmed instrument',
                'watch': 'vibrating strings', 'ask_user': ['Confirm these are strings and supply the actual video frame rate.'],
                'source': 'offline phenomenology', 'confidence': 'requires visual confirmation'}
    # A periodic low-frequency signal without object context is not evidence of rotation.
    low = [f for f in fams if f[0] < 60 and len(f) >= 2]
    if low:
        return {'template': 'unknown', 'why': 'periodic harmonic motion; could be a rotating machine, a struck nonlinear structure, or a drive signal',
                'watch': None, 'ask_user': ['Confirm a rotor is present and supply a measured rotation rate (tachometer).'],
                'source': 'offline phenomenology', 'confidence': 'periodicity only', 'suggested_template': 'rotating_machine'}
    if ringing and len(peaks) >= 2:
        return {'template': 'ringing_structure', 'why': 'measured decaying vibration, but structure and boundary conditions unverified',
                'watch': None, 'ask_user': ['What was struck and how was it supported?'],
                'source': 'offline phenomenology', 'confidence': 'requires object confirmation'}
    return _unknown('A tone is present but it does not identify a physical object or causal mechanism.')


def template_compatible(template: str, ev: dict, hint: str | None = None) -> tuple[bool, str]:
    """Enforce physical data prerequisites for EVERY model-nominated template."""
    if template not in TEMPLATES:
        return False, 'unknown template'
    if template == 'unknown':
        return True, 'explicit unknown'
    sig = ev.get('signature')
    known = {'race_car': {'f1_live_timing'}, 'beam_support': {'dropbear_trial'},
             'turbine_blade': {'blade_spectra_folder', 'blade_spectrum'}}
    if template in known:
        return (sig in known[template], f'{template} requires its recognized structured dataset; generic CSV/video is insufficient')
    if sig:
        return False, 'signature identifies a different schema; cannot reinterpret it'
    if template == 'strings':
        ok = ev.get('kind') == 'video' and len([x for x in ev.get('families_hz', []) if x[0] >= 40 and len(x) >= 2]) >= 2
        return ok, 'strings require distinct harmonic families and independently confirmed object'
    if template == 'rotating_machine':
        ok = bool(hint and any(x in hint.lower() for x in ('rotor', 'fan', 'washing machine', 'rotating', 'motor', 'spindle')))
        return ok, 'a rotor requires user-confirmed device context or a measured tachometer signal'
    if template == 'ringing_structure':
        return ev.get('decay_ratio', 1) > 3 and len(ev.get('peaks_hz', [])) >= 2, 'need decaying multimode ringing'
    return False, 'template not independently supported'


SCHEMA = {"name": "identify", "strict": True, "schema": {
    "type": "object", "additionalProperties": False,
    "required": ["template", "system", "why", "watch", "ask_user"],
    "properties": {"template": {"type": "string", "enum": list(TEMPLATES)}, "system": {"type": "string"},
                   "why": {"type": "string"}, "watch": {"type": ["string", "null"]},
                   "ask_user": {"type": "array", "items": {"type": "string"}}}}}


def identify(ev: dict, live: bool | None = None, hint: str | None = None) -> dict:
    from physica.outcome import muse
    live = muse.live_enabled() if live is None else live
    off = identify_offline(ev)
    # An explicit user report of a rotor can select *provisional* rotor analysis.
    # It must not be misrepresented as identification by video or by Muse.
    if not live:
        if off['template']=='unknown' and hint and template_compatible('rotating_machine', ev, hint)[0]:
            if any(fam[0] < 60 and len(fam)>=2 for fam in ev.get('families_hz', [])):
                return {'template':'rotating_machine','why':'User states this is a rotor; measured harmonics are consistent but not proof',
                        'watch':None,'ask_user':['Confirm rotational frequency using a tachometer before any correction'],
                        'source':'user-declared + offline signal measurement','confidence':'provisional, not diagnosed'}
        return off
    sys_p = ("You are Physica's perception lead. From the evidence about an input file (signatures, motion spectrum, "
             "harmonic families, ringing vs steady) and the user's hint, pick the physical template that fits, name the "
             "system in plain words, give a short physical reason, give a 1-3 word SAM concept to watch in a video "
             "(or null), and list what to ask the user. Templates: " + json.dumps(
                 {k: {kk: v[kk] for kk in ("system", "needs", "feels")} for k, v in TEMPLATES.items()}))
    out = muse.chat_json(sys_p, json.dumps({"evidence": ev, "hint": hint}, default=float), SCHEMA, task="auto_identify")
    # A language model may propose a template; it cannot overrule data contracts.
    compatible, why = template_compatible(out.get('template', 'unknown'), ev, hint)
    if not compatible:
        bad = out.get('template')
        out = {**_unknown('Muse proposed '+str(bad)+' but Physica rejected the incompatible evidence: '+why),
               'overruled': f'Unsupported Muse template: {bad}; {why}', 'meta_proposal': bad}
    out["source"] = f"{muse.model()} (live)"
    out["offline_matcher_agrees"] = off["template"] == out["template"]
    return out


# ---------------------------------------------------------------------------------------------- 3 + 4. see and map
NOTES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]


def note_of(f: float) -> dict:
    m = 69 + 12 * np.log2(f / 440.0)
    n = int(round(m))
    return {"note": f"{NOTES[n % 12]}{n // 12 - 1}", "cents_off": round(float(100 * (m - n)), 1), "hz": round(f, 2)}


def _fine_tone(Y, fs, f_guess, rel=0.06):
    """ESPRIT refinement of one tone (sub-bin accuracy) on the strongest channels."""
    from scipy.signal import butter, sosfiltfilt
    from physica.cause.track import esprit
    Y = np.asarray(Y, float)
    Y = Y[:, None] if Y.ndim == 1 else Y
    sos = butter(4, [f_guess * (1 - rel), min(f_guess * (1 + rel), fs * 0.45)], "bandpass", fs=fs, output="sos")
    Z = sosfiltfilt(sos, Y - Y.mean(0), axis=0)
    top = np.argsort(Z.var(0))[::-1][:20]
    fs_list = []
    for c in top:
        f, z, a = esprit(Z[:, c], fs, order=4)
        k = np.abs(f - f_guess) < rel * f_guess
        if k.any():
            fs_list.append(float(f[k][np.argmax(a[k])]))
    if not fs_list:
        return f_guess, None
    return float(np.median(fs_list)), float(np.percentile(fs_list, 90) - np.percentile(fs_list, 10)) / 2


def map_senses(template: str, path: str | Path, ev: dict, fps: float | None = None, region=None, extra=None) -> dict:
    p = Path(path)
    out = {"template": template, **{k: TEMPLATES[template][k] for k in ("system", "feels", "goals", "next")}}
    if template == "strings":
        from physica.sense import load_source
        src = load_source(p, fps, region)
        fams = [fam for fam in ev["families_hz"] if fam[0] >= 40]
        rows = []
        for fam in fams[:6]:
            f, half = _fine_tone(src["Y"], src["fs"], fam[0])
            rows.append({**note_of(f), "spread_hz": None if half is None else round(half, 2), "harmonics_seen": len(fam)})
        out["felt"] = rows
        out["say"] = "; ".join(f"{r['hz']} Hz = {r['note']} ({r['cents_off']:+} cents)" for r in rows)
        if len(rows) >= 2:  # intervals between strings do not depend on the frame rate
            iv = [round(float(1200 * np.log2(b["hz"] / a["hz"])), 1) for a, b in zip(rows[:-1], rows[1:])]
            out["intervals_cents"] = iv
            out["say"] += (f". Intervals between neighbouring strings: {iv} cents (standard tuning: 500 between E-A-D-G). "
                           "If every string reads off by the same amount, the frame rate is off, not the strings.")
    elif template == "rotating_machine":
        low_fams = [fam for fam in ev["families_hz"] if fam[0] < 60]
        if not low_fams:
            return {**out, 'felt': [], 'say': 'No reliable measured rotation frequency; obtain a tachometer reading first.'}
        fam = low_fams[0]
        amps = dict(zip(ev["peaks_hz"], ev["peak_strength"]))
        a1 = amps.get(fam[0], 0)
        a2 = max((a for f, a in amps.items() if abs(f / fam[0] - 2) < 0.08), default=0.0)
        many = sum(1 for f in amps if f > fam[0] * 2.5 and abs(f / fam[0] - round(f / fam[0])) < 0.08)
        diag = ("imbalance (once per turn dominates)" if a1 >= 2 * a2 and many < 3 else
                "misalignment or a bent shaft (twice per turn is strong)" if a2 > 0.5 * a1 else "looseness (many harmonics)")
        out["felt"] = [{"rpm": round(fam[0] * 60), "once_per_turn_hz": fam[0], "twice_per_turn_rel": round(a2 / max(a1, 1e-9), 2),
                        "harmonics_above_2x": many, "most_likely": diag}]
        out["say"] = f"{fam[0] * 60:.0f} rpm; most likely {diag}."
        out["experiment"] = ('Use a manufacturer-approved balancing fixture or a supervised laboratory rotor, '
                             'with rated attachments and a measured tachometer. Never add improvised weights to a spinning household fan.')
    elif template == "ringing_structure":
        from physica.sense import body_type
        tones = [f for f in ev["peaks_hz"]][:4]
        out["felt"] = [{"tones_hz": tones, "body": body_type(tones)}]
        out["say"] = f"rings at {tones} Hz; looks like {body_type(tones)['type']}."
    elif template == "race_car":
        out.update(extra or {})
        out["say"] = out.get("say", "Felt each car's power, drag, DRS and downforce from its telemetry (see felt).")
    elif template == "turbine_blade":
        from physica.cause.blade import SEED_HZ, BladeSense
        from physica.data import blade_eth
        if p.is_dir():
            tests = blade_eth.load(str(p))
            t = next((x for x in tests if x.case == "R"), None)
            if t is None:raise ValueError('blade reference case missing')
        else:
            m = blade_eth._NAME.match(p.name)
            if m is None:raise ValueError('not a supported blade case filename')
            with np.load(p, allow_pickle=False) as arrays:
                if not arrays.files:raise ValueError('no blade spectral measurements')
                first = np.asarray(arrays[arrays.files[0]])
            t = blade_eth.Test(m.group(1), int(m.group(2)), int(m.group(3)), m.group(4), first)
        bs = BladeSense()
        tones = bs.tones(t.psd, t.temp_c)
        out["felt"] = [{"temp_c": t.temp_c, "modes_hz": np.round(tones, 2).tolist(), "seed_hz": list(SEED_HZ)}]
        out["say"] = (f"Seven blade modes felt at {t.temp_c:+d} degC. Learned over temperature, they tell ice (added mass) from "
                      "cracks (lost stiffness) from cold (E20).")
    elif template == "beam_support":
        from physica.outcome.worlds.beam import _points
        _, rows = _points(str(p))
        ok = [(v, f) for v, f, *_ in rows if np.isfinite(f)]
        out["felt"] = [{"support_v": round(v, 3), "tone_hz": round(f, 2)} for v, f in ok[:12]]
        out["say"] = f"{len(ok)} still stretches felt; the tone climbs as the support moves out (the map behind physica outcome)."
    else:
        out["felt"] = []
        out["say"] = "Not a system I can feel yet. Tell me what it is and what it should do."
    return out


def _race_car_extra(path) -> dict:
    """Feel every car in an F1 live-timing folder (same code as E24; one shared tyre grip for the field)."""
    raise ValueError("F1 isn't part of this repository")
    import pickle
    from physica.f1 import feel as F
    from physica.f1 import lapsim as S
    from physica.f1 import telemetry as T
    line = T.raceline()
    step = float(np.hypot(*(line[1] - line[0])))
    kap = S.curvature(line)
    cache = Path.home() / ".cache" / "physica" / f"auto_f1_{abs(hash(str(Path(path).resolve()))) % 10**8}.pkl"
    if cache.exists():
        ff, dr = pickle.loads(cache.read_bytes())
    else:
        car, pos = T.load_raw(str(path))
        k = max(pos, key=lambda k: len(pos[k]))
        L = T.laps(car, pos, line, T.align(pos[k][:, 1:], line))
        Q = {}
        for num, laps in L.items():
            best = min(x.lap_time for x in laps)
            q = [x for x in laps if x.lap_time <= 1.015 * best]
            Q[num] = q if len(q) >= 2 else sorted(laps, key=lambda x: x.lap_time)[:3]
        ff, dr = F.feel_field(Q, kap, step, n_boot=10), T.drivers(str(path))
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_bytes(pickle.dumps((ff, dr)))
    rho = T.weather(str(path))["air_density"]
    rows = []
    for num, c in ff["cars"].items():
        ph = F.physical_car(c["car"], c["k_drag_drs"], rho)
        rows.append({"car": num, "driver": dr.get(num, {}).get("tla"), "power_kw": round(ph["power_kw"]),
                     "drag_m2": round(ph["CdA_m2"], 2), "downforce_250kmh_kN": round(ph["downforce_at_250kmh_kN"], 1),
                     "drs_drag_cut_pct": round(ph["drs_drag_cut_pct"], 1)})
    rows.sort(key=lambda r: -r["downforce_250kmh_kN"])
    return {"felt": rows, "say": f"{len(rows)} cars felt; most downforce: {rows[0]['driver']}, least: {rows[-1]['driver']}; "
            f"shared tyre grip {ff['mu']:.2f}."}


def run(path: str | Path, fps: float | None = None, live: bool | None = None, hint: str | None = None, extra=None) -> dict:
    from physica.investigation import next_evidence
    try:
        ev = inspect(path, fps)
    except (ValueError, IndexError, OSError, TypeError, FloatingPointError) as exc:
        reason = str(exc)[:240]
        ident = _unknown('Cannot inspect the supplied evidence: '+reason)
        return {'input':Path(path).name,'status':'unsupported_or_unreadable',
                'evidence':{'format':Path(path).suffix.lower(), 'error':reason},
                'identified': ident, 'seen_by_sam': None,
                'sense_map': {**{k:TEMPLATES['unknown'][k] for k in ('system','feels','goals','next')},'template':'unknown', 'felt':[], 'say':'Cannot identify; no measurements were inferred'},
                'investigation': next_evidence({},ident,hint)}
    ident = identify(ev, live, hint)
    if ident["template"] == "race_car" and extra is None:
        try:
            extra = _race_car_extra(path)
        except Exception as exc:  # External dataset parsers are not a trust boundary.
            previous = ident['template']
            ident = {**_unknown('F1 telemetry files failed content-level validation; please supply genuine recorded data'),
                     'overruled':f'{previous} parser refused data: {type(exc).__name__}'}
    region, seen = None, None
    if ident.get("source", "").endswith("(live)") and ev.get("kind") == "video" and ident.get("watch"):
        try:
            from physica.llm import meta_client as mc
            from physica.meta.sam import object_boxes
            tr = mc.sam_video(path, ident["watch"], task="auto_see")
            boxes = object_boxes(tr["frames"])
            if boxes:
                region = list(boxes.values())[0]
                seen = {"concept": ident["watch"], "box": region, "objects": len(boxes)}
                ev = inspect(path, fps, region)
        except Exception as e:  # noqa: BLE001
            seen = {"concept": ident["watch"], "error": repr(e)[:200], "fallback": "motion read from the whole frame"}
    # All choices, including signature matches and Meta responses, pass the same gate.
    compatible, why = template_compatible(ident['template'], ev, hint)
    if not compatible:
        ident = {**_unknown('Insufficient evidence for specialized analysis: '+why),
                 'overruled': f'{ident["template"]} rejected by input contract'}
    try:
        mapped = map_senses(ident['template'], path, ev, fps, region, extra)
    except Exception as exc:  # Fail closed for malformed specialized datasets.
        # A signature may be forged or schema may be incomplete. Refuse it,
        # rather than allow a low-level parser crash to masquerade as diagnosis.
        previous=ident['template']
        ident={**_unknown('Physical analysis refused for '+previous+': incomplete or incompatible data'),
               'overruled':f'{previous} parser could not validate required evidence: {type(exc).__name__}'}
        mapped={**{k:TEMPLATES['unknown'][k] for k in ('system','feels','goals','next')}, 'template':'unknown','felt':[], 'say':'No physical quantity inferred from this input'}
    inquiry=next_evidence(ev,ident,hint)
    return {'input':str(Path(path).name),'status':inquiry['status'],
            'evidence':ev,'identified':ident, 'seen_by_sam':seen,
            'sense_map':mapped,'investigation':inquiry}


def balance_from_videos(paths: list[str], trial_g: float, blades: int = 3, fps: float | None = None) -> dict:
    """Consumer fix from four phone clips: as-is, then a coin on blade 1, 2, 3. Amplitude-only four-run balancing."""
    from physica.experiment import balance
    from physica.sense import load_source
    from physica.experiment.balance import consistent_video_signal
    if len(paths) != 4 or trial_g <= 0 or blades != 3:
        raise ValueError('Requires four measurements and a 3-position, calibrated lab balancing fixture')
    video = [Path(q).suffix.lower() in VIDEO for q in paths]
    if any(video) and not all(video):
        raise ValueError('Do not mix video displacement/velocity with accelerometer signals')
    if all(video):
        runs = [consistent_video_signal(q, fps=fps) for q in paths]
    else:
        runs = []
        for q in paths:
            s = load_source(q, fps)
            runs.append((np.asarray(s['Y'], float), float(s['fs'])))
    result = balance.run(*runs, trial_g=trial_g, blades=blades)
    result['measurement'] = 'consistent optical-flow velocity' if all(video) else 'accelerometer'
    result['advisory_only'] = True
    result['safety'] = ('SIMULATED or supervised rated balancing fixture only. Never tape coins, loose weights, '
                       'or improvised attachments to operating consumer fans, propellers or blades.')
    return result


def main(argv=None):
    import argparse
    import sys
    ap = argparse.ArgumentParser(prog="physica auto", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", nargs="+")
    ap.add_argument("--fps", type=float)
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--hint", help="what you think it is, in words (optional)")
    ap.add_argument("--balance", action="store_true", help="four clips: as-is, coin on blade 1, 2, 3")
    ap.add_argument("--trial-g", type=float, default=1.0, dest="trial_g")
    ap.add_argument("--blades", type=int, default=3)
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    if a.balance:
        print(json.dumps(balance_from_videos(a.path, a.trial_g, a.blades, a.fps), indent=1, default=float))
        return
    r = run(a.path[0], a.fps, a.live or None, a.hint)
    i, m = r["identified"], r["sense_map"]
    print(f"\nWHAT IT IS ({i['source']}): {m['system']}\n  why: {i['why']}")
    if r.get("seen_by_sam"):
        print(f"  SAM 3.1: {r['seen_by_sam']}")
    print(f"\nMEASURED SIGNALS AND MODEL-CONDITIONAL INFERENCES: {', '.join(m['feels'])}")
    print(f"  {m.get('say', '')}")
    for row in m.get("felt", [])[:8]:
        print("  ", json.dumps(row, default=float))
    if m.get("experiment"):
        print(f"\nEXPERIMENT IT ASKS FOR: {m['experiment']}")
    print(f"\nGOALS YOU CAN SAY: {'; '.join(m['goals'])}\nNEXT: {m['next']}")
    if r.get('investigation', {}).get('recommended_next_measurement'):
        print('NEXT MEASUREMENT:',r['investigation']['recommended_next_measurement'].get('request'))
    if i.get('ask_user'):
        print(f"QUESTIONS: {'; '.join(i['ask_user'])}")


if __name__ == "__main__":
    main()
