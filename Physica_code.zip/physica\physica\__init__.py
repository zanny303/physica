"""Physica: how AI feels the world.

Built Oct 26 - Nov 4, 2026 for the Meta Global AI Developer Hackathon.
"""

__version__ = "0.48.0"
