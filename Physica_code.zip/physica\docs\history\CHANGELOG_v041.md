# Physica v0.4.1 — CRATE audit & prospective transfer release

- **Fixed:** CRATE now enforces boundary/action/modal/damping compatibility in the public forecast call; stores source calibration anchors inside trained memory; rejects unanchored memories.
- **Fixed:** safe low-force probe selection fails closed on NaN, infinity, negative cost/risk, overflow and invalid global thresholds; no invalid numeric scores are emitted.
- **New:** `crate-field-prepare` and `crate-field-check` CLI commands with at least two signed, hash-linked source experiences, held-out calibration support, target prediction sealed before B's outcome, source-memory integrity and follow-up candidate-learning record.
- **New:** `meta-crate-prepare` linked execution path for live Spark/SAM/Wonder **source A** inspection, calibrated cross-sensor evidence, physical action selection and precommitted CRATE B prediction. Requires a key privately and explicit billing permission; not executed live in this release.
- **New:** `crate-followup-prepare` uses B's signed, hash-linked *whole candidate memory* update to precommit a distinct C machine's prediction, preserving prospective chronology.
- **New:** `crate-probe-gate` tests signed lower-force B observations against held-out source-like experience, requiring separate sensor-noise calibration; a passing statistical gate never authorizes actuation.
- **New:** `crate-stress` evaluates deliberate hidden-dynamics domain shift and 0/1-probe synthetic sample-efficiency counts; reports severe OOD coverage collapse rather than hiding it.
- **New:** explicit research safety/validation instructions in `docs/V041_AUDIT_AND_FIELD.md` and regression tests in `tests/test_crate_v041_audit.py`.
- **Unchanged limitation:** no real hardware tests, no authenticated Meta runs, no actual V-JEPA inference, no proof of a novel universal algorithm and no automatic actuation.
