# Physica v0.4.2 — Causal Sensory Grammar Edition

Extends **v0.4.1** in place (no original source modules removed):

- New `physica/grammar` package: calibrated sensory channels, physical event tokens, validated interventional dimensionless transfer, sensor-specific observation operators, mechanistic state estimation, uncertain hypothesis ranking, STFT/Morlet/coherence diagnostics, PEL v3 schema, chemistry type/refusal support and strict provenance.
- New **synthetic-only** A→B→C cross-sensor benchmark and self-contained offline web demo. Includes strong nearest-source baseline and shifted-dynamics stress evidence; no fraudulent live/synthetic conflation.
- New **prospective CSV** signed A→B→C source/prepare/check/learn-next workflow; target times-only file cannot contain measurements and all observed outcomes are read only in the post-commit step.
- New optional paid Meta `meta-csg-live`: Spark contextual hypotheses, SAM tracked image geometry with independent sensor agreement, Wonder constrained critique; SAM becomes a calibrated source measurement before PEL transfer. No key or hardware media were available for a live call in the development environment.
- Strict `cannot_translate` for mismatched boundary, action family, missing support, unsafe or incompatible modality, and invalid/tampered physical word; derived modality derivatives marked uncalibrated.
- Added test suite, example source manifests, experimental protocol and hackathon materials.

**What is NOT done:** universal five-sense AI; broad chemical sensor calibration; independently verified hardware experiments; authenticated Meta API run; validated V-JEPA weights; proof of scientific novelty; full original repository test suite; certified autonomous actuator control.
