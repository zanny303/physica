"""Selective source-to-target mechanism transport under an independent target probe."""
from __future__ import annotations
import numpy as np
from .mechanisms import design,fit,score

def _regularized(rows,terms,source=None,strength=0.):
    X=design(rows,terms);y=np.array([r['acceleration'] for r in rows],float)
    reg=np.eye(X.shape[1])*1e-5
    rhs=X.T@y
    if source is not None:
        if source['terms']!=terms:raise ValueError('incompatible mechanism grammar')
        prior=np.asarray(source['coefficients'],float)
        reg+=np.eye(len(prior))*strength
        rhs+=strength*prior
    w=np.linalg.solve(X.T@X+reg,rhs)
    return {'terms':terms,'coefficients':w.tolist(),'train_count':len(rows)}

def adapt(source_model,local_rows,probe_rows,*,strength=.8,tolerance=-.10,mismatch_limit=.12):
    if not local_rows or not probe_rows:raise ValueError('target local/probe evidence required')
    if {r['episode_id'] for r in local_rows}&{r['episode_id'] for r in probe_rows}:
        raise ValueError('target probe must be a separate controlled episode')
    if len({r['body_id'] for r in local_rows+probe_rows})!=1:raise ValueError('single target body required')
    terms=source_model['terms']
    local=_regularized(local_rows,terms);transferred=_regularized(local_rows,terms,source_model,strength)
    local_err=score(probe_rows,local);transfer_err=score(probe_rows,transferred)
    mismatch=min(local_err,transfer_err)>mismatch_limit
    # A future horizon is scored only on a completed LOCAL PROBE, never the sealed test.
    from .simulation import forecast_without_truth
    dt=float(probe_rows[1]['t']-probe_rows[0]['t'])
    probe_plan={'dt':dt,'u':[r['u'] for r in probe_rows[:-1]],
                'temperature_delta':[r['temperature_delta'] for r in probe_rows[:-1]]}
    initial=(probe_rows[0]['x'],probe_rows[0]['v'])
    truth=np.asarray([r['x'] for r in probe_rows[1:]],float)
    try:
        local_forecast=forecast_without_truth(local,initial,probe_plan)
        transfer_forecast=forecast_without_truth(transferred,initial,probe_plan)
        rollout_local=float(np.sqrt(np.mean((np.asarray([p['x'] for p in local_forecast])-truth)**2)))
        rollout_transfer=float(np.sqrt(np.mean((np.asarray([p['x'] for p in transfer_forecast])-truth)**2)))
    except ValueError:
        rollout_local=rollout_transfer=float('inf')
    use=(transfer_err<=local_err*(1+tolerance) and
         rollout_transfer<=rollout_local*.94 and not mismatch)

    refitted=_regularized(local_rows+probe_rows,terms,source_model if use else None,strength if use else 0.)
    target_only=_regularized(local_rows+probe_rows,terms)
    return {'choice':'REFUSE_MECHANISM_MISMATCH' if mismatch else ('SOURCE_PRIOR' if use else 'LOCAL_ONLY'),
            'source_accepted':bool(use),'probe_rmse_local':local_err,'probe_rmse_transfer':transfer_err,
            'probe_rollout_local_m':rollout_local,'probe_rollout_transfer_m':rollout_transfer,
            'model':refitted,'target_only_model':target_only,'target_probe_held_out_for_selection':True,
            'independent_future_test_outcomes_used':False}
