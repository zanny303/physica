"""Run LLM-written code safely-ish (SPEC 1.5): AST denylist + separate process + timeout + numpy-only I/O.

Limits (stated honestly): this is a guard against accidents and casual misuse, not a hardened jail.
The child runs with `python -I`, an empty environment (no proxy variables), a temp working directory,
restricted builtins and a 10 s timeout. Code that fails the AST check never runs.
"""
from __future__ import annotations

import ast
import json
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np

DENY_NAMES = {"eval", "exec", "compile", "open", "__import__", "globals", "locals", "vars", "getattr", "setattr",
              "delattr", "input", "breakpoint", "exit", "quit", "help", "memoryview", "type"}
ALLOWED_IMPORTS = {"numpy", "math"}


class Rejected(ValueError):
    pass


def check_ast(code: str) -> None:
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        raise Rejected(f"syntax error: {e}") from e
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name.split(".")[0] not in ALLOWED_IMPORTS:
                    raise Rejected(f"import of {a.name} not allowed")
        elif isinstance(node, ast.ImportFrom):
            if (node.module or "").split(".")[0] not in ALLOWED_IMPORTS:
                raise Rejected(f"import from {node.module} not allowed")
        elif isinstance(node, ast.Name) and node.id in DENY_NAMES:
            raise Rejected(f"use of {node.id} not allowed")
        elif isinstance(node, ast.Attribute) and node.attr.startswith("__"):
            raise Rejected(f"dunder attribute {node.attr} not allowed")
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            raise Rejected("global/nonlocal not allowed")


RUNNER = r'''
import json, math, sys
import numpy as np
SAFE = {k: __builtins__[k] if isinstance(__builtins__, dict) else getattr(__builtins__, k) for k in
        ["abs","all","any","bool","dict","enumerate","float","int","len","list","max","min","range","round",
         "sorted","sum","tuple","zip","map","filter","isinstance","ValueError","ZeroDivisionError","Exception",
         "print","reversed","pow","divmod","set","str","slice"]}
def _imp(name, *a, **k):
    if name.split(".")[0] not in ("numpy", "math"):
        raise ImportError(name)
    return __import__(name, *a, **k)
SAFE["__import__"] = _imp
code = open("code.py").read()
inp = dict(np.load("in.npz", allow_pickle=False))
spec = json.load(open("spec.json"))
g = {"__builtins__": SAFE, "np": np, "math": math}
exec(compile(code, "llm_code", "exec"), g)
fn = g[spec["func"]]
if spec["mode"] == "call":
    out = fn(**inp)
    np.savez("out.npz", out=np.asarray(out, dtype=float))
elif spec["mode"] == "fit":
    from scipy.optimize import least_squares
    names = spec["param_names"]; lo = np.array(spec["lo"]); hi = np.array(spec["hi"])
    x, y, fitm = inp["x"], inp["y"], inp["fit_mask"].astype(bool)
    def res(p):
        params = dict(zip(names, p))
        return (np.asarray(fn(params, x[fitm]), float) - y[fitm])
    best = None
    rng = np.random.default_rng(0)
    for s in range(spec.get("starts", 4)):
        p0 = lo + (hi - lo) * (0.5 if s == 0 else rng.uniform(0.1, 0.9, len(lo)))
        try:
            r = least_squares(res, p0, bounds=(lo, hi), max_nfev=400)
            if best is None or r.cost < best.cost:
                best = r
        except Exception:
            pass
    if best is None:
        raise RuntimeError("fit failed")
    params = dict(zip(names, best.x))
    np.savez("out.npz", params=best.x, pred=np.asarray(fn(params, x), float))
'''


def run(code: str, func: str, inputs: dict[str, np.ndarray], mode: str = "call", timeout: float = 10.0,
        extra: dict | None = None) -> dict:
    check_ast(code)
    with tempfile.TemporaryDirectory() as d:
        dp = Path(d)
        (dp / "code.py").write_text(code)
        (dp / "runner.py").write_text(RUNNER)
        np.savez(dp / "in.npz", **{k: np.asarray(v) for k, v in inputs.items()})
        (dp / "spec.json").write_text(json.dumps({"func": func, "mode": mode, **(extra or {})}))
        try:
            p = subprocess.run([sys.executable, "-I", "runner.py"], cwd=d, env={"PATH": "/usr/bin:/bin"},
                               capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired as e:
            raise Rejected(f"timed out after {timeout} s") from e
        if p.returncode != 0:
            raise Rejected("runtime error: " + (p.stderr.strip().splitlines() or ["?"])[-1][:300])
        out = dict(np.load(dp / "out.npz"))
    return out
