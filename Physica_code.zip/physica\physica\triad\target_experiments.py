"""Target-directed experiment design for transferable physical knowledge.

Linear-Gaussian approximation: source intervention a yields y = phi_a.T theta + epsilon.
Target distributions define risk tr(Q_target Sigma_theta). Choose a source
intervention that most reduces expected *target* risk, rather than source
entropy alone. Known Bayesian A-optimal design math; originality unproven.
Does NOT actuate hardware.
"""
from __future__ import annotations
import numpy as np


def rank_transfer_experiments(prior_covariance, target_features, candidates, *, target_weights=None, risk_penalty=0.0, cost_penalty=0.0):
    cov=np.asarray(prior_covariance,dtype=float)
    tgt=np.asarray(target_features,dtype=float)
    if cov.ndim!=2 or cov.shape[0]!=cov.shape[1] or cov.shape[0]<1 or not np.all(np.isfinite(cov)):
        raise ValueError('finite square prior covariance required')
    d=len(cov)
    if tgt.ndim!=2 or tgt.shape[1]!=d or not len(tgt) or not np.all(np.isfinite(tgt)):
        raise ValueError('finite target feature matrix required')
    if np.linalg.eigvalsh(cov).min() < -1e-10:
        raise ValueError('prior covariance not positive semidefinite')
    weights=np.ones(len(tgt))/len(tgt) if target_weights is None else np.asarray(target_weights,dtype=float)
    if weights.shape!=(len(tgt),) or not np.all(np.isfinite(weights)) or np.any(weights<0) or weights.sum()<=0:
        raise ValueError('invalid target weights')
    weights=weights/weights.sum()
    q=tgt.T@(weights[:,None]*tgt)
    if not candidates: raise ValueError('need candidate experiments')
    if not np.isfinite(risk_penalty) or not np.isfinite(cost_penalty) or risk_penalty<0 or cost_penalty<0:
        raise ValueError('invalid penalties')
    results=[]
    for c in candidates:
        ident=str(c.get('id',''))
        phi=np.asarray(c.get('source_features',[]),dtype=float)
        sigma=float(c.get('sensor_noise_std',float('nan')))
        risk=float(c.get('risk',float('nan')))
        cost=float(c.get('cost',float('nan')))
        approved=c.get('approved',False) is True
        reversible=c.get('reversible',False) is True
        finite=phi.shape==(d,) and np.all(np.isfinite(phi)) and all(np.isfinite(x) for x in (sigma,risk,cost))
        eligible=bool(ident and finite and sigma>0 and 0<=risk<=1 and cost>=0 and approved and reversible)
        if not eligible:
            results.append({'id':ident,'status':'REFUSE_INVALID_OR_UNAPPROVED','target_risk_reduction':None,'score':None})
            continue
        # Exact conditional covariance update for scalar linear Gaussian observation
        v=cov@phi
        denom=float(sigma*sigma+phi@v)
        reduction=float(v@q@v/denom)
        info=float(.5*np.log1p(phi@v/(sigma*sigma)))
        score=reduction-risk_penalty*risk-cost_penalty*cost
        results.append({'id':ident,'status':'ELIGIBLE_SUPERVISED','target_risk_reduction':reduction,
                        'source_information_gain_nats':info,'score':float(score),'risk':risk,'cost':cost})
    ranked=sorted(results,key=lambda r: -r['score'] if r['score'] is not None else float('inf'))
    eligible=[r for r in ranked if r['score'] is not None]
    return {'status':'SUGGEST_ONLY_NO_ACTUATION' if eligible else 'ABSTAIN_NO_SAFE_EXPERIMENT',
            'chosen_id':eligible[0]['id'] if eligible else None,
            'source_baseline_target_bayes_risk':float(np.trace(q@cov)),
            'candidates':ranked,'assumptions':['linear Gaussian parameter response',
                  'independently calibrated source features and sensor noise',
                  'target distribution specified before action selection',
                  'approved and reversible probes only; human supervision required']}
