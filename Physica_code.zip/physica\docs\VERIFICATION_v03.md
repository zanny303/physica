# Physica v0.3 — Verification record

Run performed on 2026-10-30 in the packaging environment, Python 3.13.

```
python -m pytest -q \
  tests/test_core.py tests/test_touch.py tests/test_experiments.py \
  tests/test_frontier.py tests/test_experience.py
32 passed (selected suites, v0.3 final verification)
```

The standalone v0.3 demo executed with the exact command:

```
PHYSICA_STATE_DIR=<temporary-path-outside-archive> \
python -m physica.cli experience frontier-demo --out examples/frontier_showcase
```

It generated signed A/B commitments and reveals, a physical token,
B forecast, a refusal for incompatible body C, an HTML demo and JSON metrics.
The source result is a constructed damped-oscillator simulator, not hardware.

The 30-seed synthetic ablation was generated with:

```
python -m physica.cli experience frontier-ablation \
 --out examples/frontier_ablation --seeds 30
```

- Mean dimensionless-transfer RMSE: about **0.0000716 m**.
- Mean naive raw-copy RMSE: about **0.001766 m**.
- Fraction with lower error than raw-copy: **30/30**.
- Local verification fraction under assumed synthetic tolerance: **30/30**.

**This is NOT evidence of performance on physical machines:** both bodies were
sampled from the same second-order model family with known calibrated forces,
stiffnesses and frequencies. The naive baseline is a weak comparison.

All existing tests were not run as a single completed suite. Meta services
were not called. Credentials and physical hardware were not available.
Cryptographic signatures authenticate content only; test files can be generated
with a local signing key, and there are no independent trusted timestamps.

`tests/test_frontier.py` includes fake labeled real-sensor fixtures to test the
optional CSV code path; those fixtures are **synthetic unit tests only**.
