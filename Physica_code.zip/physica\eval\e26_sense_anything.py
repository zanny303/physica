"""E26 - Drop anything in: one router, many physical systems. Meta (or the offline matcher) names the system and the
physics; Physica maps what it feels there.

REAL inputs:
  1. guitar.mp4 - MIT's high-speed guitar video (600 fps, from the Eulerian Video Magnification work; copy in
     github.com/flyingzhao/PyEVM). Truth: a guitar's lowest strings are E2, A2, D3, a perfect fourth (500 cents) apart.
  2. F1 live timing, 2020 Silverstone FP2 (PHYSICA_F1_SESSION).
  3. One ETH wind-turbine blade spectrum at +20 degC (PHYSICA_BLADE_PSD).
  4. One DROPBEAR trial (PHYSICA_DROPBEAR8).
SIMULATED input (labelled): four phone-style clips of a wobbling fan (as-is, coin on blade 1, 2, 3) -> where to add
how many grams -> an after clip with the fix -> the sealed promise (wobble drops >= 50%) graded.
Set PHYSICA_GUITAR_VIDEO to the guitar file.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica import auto  # noqa: E402

OUT = ROOT / "eval" / "results"


def main():
    res = {"LABEL": "Real inputs except the fan clips (SIMULATED, labelled)", "runs": []}
    inputs = [("guitar (real high-speed video)", os.environ.get("PHYSICA_GUITAR_VIDEO"), 600.0),
              ("F1 live timing (real)", os.environ.get("PHYSICA_F1_SESSION"), None),
              ("wind-turbine blade spectrum (real)", os.path.join(os.environ.get("PHYSICA_BLADE_PSD", ""),
                                                                 "Case_R_(+20)_layout_02_white_noise_12.npz"), None),
              ("beam trial (real)", os.path.join(os.environ.get("PHYSICA_DROPBEAR8", ""), "Standard Index Set", "test0.txt"), None)]
    for label, path, fps in inputs:
        if not path or not os.path.exists(path):
            res["runs"].append({"label": label, "skipped": "input not found"})
            continue
        r = auto.run(path, fps, live=None)
        r.pop("evidence", None) if r["identified"]["template"] == "race_car" else None
        res["runs"].append({"label": label, **r})
        print(label, "->", r["identified"]["template"], "|", r["sense_map"].get("say", "")[:160])
    g = next((x for x in res["runs"] if x["label"].startswith("guitar") and "sense_map" in x), None)
    if g:
        rows = g["sense_map"]["felt"]
        res["guitar_check"] = {"notes_named": [r["note"] for r in rows], "expected_lowest_strings": ["E2", "A2", "D3"],
                               "intervals_cents": g["sense_map"].get("intervals_cents"), "expected_interval_cents": 500}
    with tempfile.TemporaryDirectory() as t:
        from physica import fan_sim
        from physica.experiment import balance
        from physica.experiment.balance import consistent_video_signal
        clips = fan_sim.four_clips(t)
        ident = auto.run(clips[0], None, live=False)
        fix = auto.balance_from_videos(clips, trial_g=1.0)
        after = fan_sim.after_clip(t, fix["correction_g"], fix["correction_angle_deg"])
        s = consistent_video_signal(after)
        chk = balance.check(fix, s)
        truth_g, truth_deg = 1 / fan_sim.T, (np.degrees(np.angle(fan_sim.A0)) + 180) % 360
        res["fan_SIMULATED"] = {"identified": ident["identified"]["template"], "say": ident["sense_map"]["say"],
                                "fix": {k: fix[k] for k in ("correction_g", "correction_angle_deg", "text", "verdict")},
                                "truth": {"grams": round(truth_g, 3), "angle_deg": round(truth_deg, 1)},
                                "check": chk}
        print("fan:", fix["text"], "| truth", round(truth_g, 2), "g at", round(truth_deg, 1), "| check:", json.dumps(chk, default=float)[:200])
    (OUT / "E26_sense_anything.json").write_text(json.dumps(res, indent=1, default=float))


if __name__ == "__main__":
    main()
