"""Physica MACE-X v0.14: probabilistic cross-sensory experience transfer.

This is a research candidate, not verified real-world transfer or consciousness.
"""
from .core import (ExperienceMemory, SensorCalibration, calibrated_rows,
                   fit_source_memory, fit_target, predict, rank_probes,
                   posterior_summary, FEATURES, fit_sensor_observation_map, fuse_calibrated_modalities)
__all__ = ['ExperienceMemory','SensorCalibration','calibrated_rows',
           'fit_source_memory','fit_target','predict','rank_probes',
           'posterior_summary','FEATURES','fit_sensor_observation_map','fuse_calibrated_modalities']
