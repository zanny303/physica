"""Physica Twin: a falsifiable *hypothesis* linked to observed motion.

The model is a calibrated, modest second-order surrogate when supported by
measurements. Video pixels can only establish *relative image motion*; no
force, absolute length, material, physical break threshold or fault can be
inferred from one uncalibrated clip. Interventions are simulations ONLY.
"""
from __future__ import annotations
import csv
import hashlib
import io
import json
import math
import tempfile
from pathlib import Path
import numpy as np
from scipy.signal import savgol_filter

MAX_PREVIEW = 500
MAX_ROWS = 60_000


def _finite_float(x, name):
    v = float(x)
    if not math.isfinite(v): raise ValueError(f'{name} must be finite')
    return v


def _series_csv(data, *, pixels_per_metre=None):
    if len(data) > 12_000_000:raise ValueError('CSV exceeds 12 MB analysis limit')
    text=data.decode('utf-8-sig', errors='strict')
    reader=csv.DictReader(io.StringIO(text),delimiter='\t' if '\t' in text.splitlines()[0] else ',')
    keys=reader.fieldnames or []
    if not keys:raise ValueError('CSV has no header')
    colmap={str(k).strip().lower():k for k in keys}
    timekey=next((colmap[k] for k in ('t_s','time_s','timestamp_s','t','time') if k in colmap),None)
    xkey=next((colmap[k] for k in ('displacement_m','position_m','x_m','displacement_mm','position_mm','x_mm','position_px','displacement_px') if k in colmap),None)
    if timekey is None or xkey is None:
        return None, None, None, 'Need explicit time and displacement columns, e.g. t_s,displacement_m. A frequency or accelerometer column alone is not a calibrated position trace.'
    ukey=next((colmap[k] for k in ('applied_force_n','force_n','u','command') if k in colmap),None)
    t=[];x=[];u=[]
    for i,row in enumerate(reader):
        if i>=MAX_ROWS:raise ValueError('CSV exceeds analysis row limit')
        try:
            t.append(_finite_float(row[timekey],'timestamp'))
            x.append(_finite_float(row[xkey],'position'))
            if ukey:u.append(_finite_float(row[ukey],'action'))
        except (ValueError,TypeError) as exc:raise ValueError(f'Invalid numeric data on CSV row {i+2}: {exc}') from exc
    scale=1.
    if xkey.lower().endswith('_mm'):scale=.001
    if xkey.lower().endswith('_px'):
        if pixels_per_metre is not None:
            ppm=_finite_float(pixels_per_metre,'pixels_per_metre')
            if not 1<=ppm<=1e8:raise ValueError('pixels_per_metre outside supported range')
            scale=1./ppm
        else:scale=1.
    unit='pixel' if xkey.lower().endswith('_px') and pixels_per_metre is None else 'metre'
    return np.asarray(t), np.asarray(x)*scale, np.asarray(u) if ukey else None, unit


def _video_motion(data, *, roi=None, frame_rate_override=None, max_frames=420):
    try:import cv2
    except ImportError as e:raise ValueError('Video requires pip install -e ".[video]"') from e
    # Local temp file; no network, no remote Meta upload.
    with tempfile.TemporaryDirectory(prefix='physica_twin_') as d:
        path=Path(d)/'clip.mp4';path.write_bytes(data)
        cap=cv2.VideoCapture(str(path))
        if not cap.isOpened():raise ValueError('Cannot decode video; MP4/H264 is recommended')
        fps=float(frame_rate_override or cap.get(cv2.CAP_PROP_FPS))
        if not math.isfinite(fps) or not 1<=fps<=1000:
            cap.release();raise ValueError('Valid measured frame rate required for video')
        if roi is None:roi=[.26,.20,.48,.60]
        if len(roi)!=4 or any(not isinstance(q,(int,float)) or not math.isfinite(q) for q in roi):
            raise ValueError('ROI must contain 4 finite normalized coordinates')
        rx,ry,rw,rh=[float(q) for q in roi]
        if min(rx,ry)>=0 and min(rw,rh)>.05 and rx+rw<=1 and ry+rh<=1:pass
        else:raise ValueError('Invalid selected ROI; choose an object region inside the frame')
        t=[];position=[];tracked=[]; refshift=[]
        prev=None;points=None;prevref=None;refpoints=None
        cumulative=0.;refcum=0.
        for frame_idx in range(max_frames):
            ok,frame=cap.read()
            if not ok:break
            h,w=frame.shape[:2]
            if w>900:
                frame=cv2.resize(frame,(900,round(h*900/w)))
                h,w=frame.shape[:2]
            gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
            mask=np.zeros_like(gray); xa=int(rx*w);xb=int((rx+rw)*w);ya=int(ry*h);yb=int((ry+rh)*h)
            mask[ya:yb,xa:xb]=255
            other=cv2.bitwise_not(mask)
            if prev is None:
                points=cv2.goodFeaturesToTrack(gray,65,.01,5,mask=mask)
                refpoints=cv2.goodFeaturesToTrack(gray,100,.015,8,mask=other)
                if points is None or len(points)<5:
                    cap.release();return None,'No stable visual feature tracks in the selected object region. Try contrast markers, steady camera, or SAM object tracking.'
                prev=gray;t.append(0.);position.append(0.);tracked.append(int(len(points)));refshift.append(0.);continue
            if points is None or len(points)<5:
                cap.release();return None,'Visual tracking lost. Use a steadier camera or visible tracking markers.'
            new,st,_=cv2.calcOpticalFlowPyrLK(prev,gray,points,None,winSize=(19,19),maxLevel=3)
            valid=st.flatten()>0 if st is not None else np.zeros(len(points),dtype=bool)
            if new is None or valid.sum()<5:
                cap.release();return None,'Visual tracking failed before a usable trajectory was recorded.'
            delta=np.median((new[valid]-points[valid]).reshape(-1,2),axis=0)
            cumulative+=float(delta[0])
            points=new[valid].reshape(-1,1,2)
            if refpoints is not None and len(refpoints)>=7:
                newref,sr,_=cv2.calcOpticalFlowPyrLK(prev,gray,refpoints,None,winSize=(19,19),maxLevel=3)
                if sr is not None and newref is not None:
                    good=sr.flatten()>0
                    if good.sum()>=7:
                        refcum+=float(np.median((newref[good]-refpoints[good]).reshape(-1,2),axis=0)[0]);refpoints=newref[good].reshape(-1,1,2)
                    else:refpoints=None
            t.append(float(frame_idx/fps));position.append(cumulative-refcum);refshift.append(refcum);tracked.append(int(valid.sum()))
            prev=gray
            if frame_idx%25==0:
                points=cv2.goodFeaturesToTrack(gray,65,.01,5,mask=mask)
                refpoints=cv2.goodFeaturesToTrack(gray,100,.015,8,mask=other)
        cap.release()
    if len(t)<22:return None,'Video too short for tracking. Try a longer steady clip with visible motion.'
    if np.max(np.abs(refshift))>15:
        return None,'Background motion exceeded 15 pixels; camera drift or background instability makes the video ambiguous.'
    return {'t':np.asarray(t),'x':np.asarray(position),'median_tracks':int(np.median(tracked)),
            'background_drift_px':round(float(np.max(np.abs(refshift))),3),
            'fps':fps,'roi':list(roi)},None


def _observed_trace(t,x, u=None):
    idx=np.unique(np.rint(np.linspace(0,len(t)-1,min(MAX_PREVIEW,len(t)))).astype(int))
    return [{'t':round(float(t[i]-t[0]),6),'x':round(float(x[i]),7),
            **({'u':round(float(u[i]),7)} if u is not None else {})} for i in idx]


def _fit(t,x,u,unit):
    """Measured position -> conditional acceleration model, hold out LAST 25%."""
    if len(t)<55:return None,'Need at least 55 synchronized motion observations for model fitting.'
    dt=np.diff(t)
    if not np.isfinite(dt).all() or np.min(dt)<=0:return None,'Timestamps must be strictly increasing.'
    median=float(np.median(dt))
    if np.max(np.abs(dt-median))>max(.08*median,1e-5):return None,'Uneven time intervals: resample with documented timing calibration.'
    if np.std(x)<1e-5:return None,'No sufficiently large motion was measured.'
    window=max(9,min(19,len(x)//25*2+1))
    if window>=len(x):window=len(x)-1 if len(x)%2==0 else len(x)-2
    v=savgol_filter(x,window_length=window,polyorder=3,deriv=1,delta=median)
    a=savgol_filter(x,window_length=window,polyorder=3,deriv=2,delta=median)
    # Model x''=-omega2*x-damping*v+gain*u+intercept. Unit changes
    # *never* identify physical stiffness/mass separately.
    act=np.std(u)>1e-7 if u is not None else False
    xn=x-np.mean(x[:max(4,len(x)//4)])
    X=np.stack([-xn,-v,*([u] if act else []),np.ones(len(x))],axis=1)
    trim=window//2
    usable=np.arange(trim,len(x)-trim)
    split=int(.72*len(x));train=usable[usable<split];test=usable[usable>=split]
    if len(train)<25 or len(test)<10:return None,'Too little independent held-out time for prospective testing.'
    if np.linalg.cond(X[train].T@X[train]+np.eye(X.shape[1])*1e-8)>1e11:
        return None,'Cannot identify a stable second-order model: columns are nearly indistinguishable.'
    beta=np.linalg.lstsq(X[train],a[train],rcond=None)[0]
    predicted=X[test]@beta
    err=float(np.sqrt(np.mean((predicted-a[test])**2)))
    null=float(np.sqrt(np.mean((np.mean(a[train])-a[test])**2)))
    if not np.isfinite(beta).all() or err >= .96*null:
        return None,'The held-out predictions were not convincingly better than a constant-acceleration baseline.'
    # Stronger abstention when dynamics nonphysical or unstable over data.
    omega2,damping=float(beta[0]),float(beta[1])
    if not (0.0001<omega2<5e6 and -.001<=damping<2500):
        return None,'This recording does not support a stable passive spring-damper hypothesis.'
    if damping<0:damping=0.
    return {'status':'CONDITIONAL_SURROGATE_NOT_CAUSAL_IDENTIFICATION',
       'family':'linear_second_order_motion',
       'parameters':{'stiffness_per_mass_per_s2':omega2,'damping_per_mass_per_s':damping,
        'action_gain':float(beta[2]) if act else None,'offset_acceleration':float(beta[-1])},
       'units':'SI length' if unit=='metre' else 'relative image pixels',
       'action_logged_and_variable':bool(act),
       'heldout_acceleration_rmse':round(err,7),
       'heldout_constant_baseline_rmse':round(null,7),
       'training_rows':int(len(train)),'test_rows':int(len(test)),
       'estimated_frequency_hz':round(math.sqrt(omega2)/(2*math.pi),5),
       'limitations':['Mass and stiffness cannot be identified separately from the motion trace.',
          'This is a local second-order surrogate, not a verified hidden mechanism.',
          'Unmeasured forces, camera motion, and control policies can invalidate the fit.',
          'The test samples occur later in the same recording; independent interventions are still required.']},None


def reconstruct(name: str, content: bytes, *, pixels_per_metre=None, fps=None, roi=None):
    if not isinstance(content,bytes) or len(content)<12:raise ValueError('Empty or invalid evidence file')
    if len(content)>60_000_000:raise ValueError('File exceeds Twin 60 MB limit')
    safe_name=Path(name).name[:120]
    ext=Path(safe_name).suffix.lower()
    source_hash=hashlib.sha256(content).hexdigest()
    uncertainties=[]; details={}
    if ext in ('.csv','.tsv'):
        t,x,u,unit=_series_csv(content,pixels_per_metre=pixels_per_metre)
        if t is None:return _abstain(safe_name,source_hash,unit,{'extension':ext})
        details={'signal':'explicit displacement observations','file_type':ext,
                 'pixels_per_metre_provided':pixels_per_metre is not None}
    elif ext in ('.mp4','.mov','.avi','.mkv','.webm'):
        trace,error=_video_motion(content,roi=roi,frame_rate_override=fps)
        if error:return _abstain(safe_name,source_hash,error,{'extension':ext})
        t,x=trace['t'],trace['x'];u=None;unit='pixel'
        if pixels_per_metre is not None:
            scale=_finite_float(pixels_per_metre,'pixels_per_metre')
            if not 1<=scale<=1e8:raise ValueError('Invalid pixels_per_metre scale')
            x=x/scale;unit='metre'
        details={'signal':'video optical flow relative to background','video':{k:v for k,v in trace.items() if k not in ('t','x')},
                 'pixels_per_metre_provided':pixels_per_metre is not None}
        uncertainties.append('Frame-rate, scale, camera geometry, and background stability must be independently checked.')
    elif ext == '.json':
        try:js=json.loads(content)
        except (ValueError,UnicodeDecodeError):return _abstain(safe_name,source_hash,'Invalid JSON evidence',{'extension':ext})
        if not isinstance(js,dict) or not isinstance(js.get('samples'),list):
            return _abstain(safe_name,source_hash,'JSON requires samples [{t_s,displacement_m}] or verified exported tracking samples.',{'extension':ext})
        if len(js['samples'])>MAX_ROWS:raise ValueError('Too many JSON samples')
        try:
            t=np.asarray([_finite_float(q['t_s'],'time') for q in js['samples']]);x=np.asarray([_finite_float(q['displacement_m'],'position') for q in js['samples']])
        except (KeyError,TypeError,ValueError):return _abstain(safe_name,source_hash,'JSON samples need finite t_s and displacement_m values',{'extension':ext})
        u=None;unit='metre';details={'signal':'declared displacement samples','exported_sensor_claim':js.get('status','user_supplied'),
                                 'metadata_is_not_independent_provenance':True}
    else:
        return _abstain(safe_name,source_hash,'Unsupported format: provide CSV with t_s and displacement_m, calibrated tracking JSON, or a trackable video.',{'extension':ext})
    if len(t)<8:return _abstain(safe_name,source_hash,'Not enough observations for a motion trace',details)
    if len(t)!=len(x) or not np.isfinite(t).all() or not np.isfinite(x).all() or np.any(np.diff(t)<=0):
        return _abstain(safe_name,source_hash,'Time and motion must be synchronized, finite and strictly ordered',details)
    model,issue=_fit(t,x,u,unit)
    if issue:uncertainties.append(issue)
    if unit=='pixel':uncertainties.append('No independently verified length scale: motion is pixels only, not metres.')
    if u is None:uncertainties.append('No logged controlled action; causal response to interventions is NOT identified.')
    amplitude=float((np.percentile(x,95)-np.percentile(x,5))/2)
    dt=float(np.median(np.diff(t)))
    main_frequency=0.
    if len(x)>12:
        spec=abs(np.fft.rfft((x-np.mean(x))*np.hanning(len(x))))
        freq=np.fft.rfftfreq(len(x),dt);spec[0]=0
        main_frequency=float(freq[np.argmax(spec)])
    result={'schema':'physica.digital_twin.observational.v1','status':'CONDITIONAL_MODEL' if model else 'OBSERVATION_ONLY',
      'evidence':{'filename':safe_name,'sha256':source_hash,'origin':'USER_SUPPLIED_NOT_EXTERNALLY_VERIFIED',
           'modality':ext,'n_samples':len(t),'duration_s':round(float(t[-1]-t[0]),3),
           'length_unit':unit,**details},
      'scene':{'nodes':[{'id':'frame','label':'Reference / world','role':'assumed_stationary'},
                  {'id':'body','label':'Observed moving region','role':'directly_measured_image_or_position'},
                  {'id':'restraint','label':'Effective restraint','role':'HYPOTHESIZED_NOT_VISUALLY_OBSERVED'}],
               'edges':[{'from':'frame','to':'body','meaning':'observed motion'},
                        {'from':'body','to':'restraint','meaning':'model hypothesis ONLY'}]},
      'measurement':{'amplitude':round(amplitude,7),'dominant_frequency_hz':round(main_frequency,5),
                     'frame_time_s':round(dt,8),'trace':_observed_trace(t,x,u)},
      'model':model,
      'scenarios':[],
      'limits':uncertainties + ['Intervention sliders simulate hypotheticals only; never alter actual equipment.',
           'A measured video is NOT an observed internal spring, crack, force, failure threshold or repair.'],
      'next_measurement':'Record a safe controlled input and synchronous sensor observations, with an independent stationary reference, known scale and second episode.',
      'meta':{'sam':'OPTIONAL_EXTERNAL_TRACKING_ROUTE_NOT_INVOKED','muse':'NOT_CALLED'},
      'outcome_program':{'status':'REVIEW_ONLY','can_apply_to_hardware':False}}
    if model:
        for scenario in ('as_observed','stiffness_reduction','damping_loss','damping_increase'):
            result['scenarios'].append(simulate_intervention(result,scenario=scenario))
    return result


def _abstain(name,digest,reason,details=None):
    return {'schema':'physica.digital_twin.observational.v1','status':'ABSTAIN_UNSUPPORTED',
      'evidence':{'filename':name,'sha256':digest,'origin':'USER_SUPPLIED_NOT_EXTERNALLY_VERIFIED',**(details or {})},
      'scene':{'nodes':[],'edges':[]},'measurement':{'trace':[]},'model':None,
      'scenarios':[],'limits':[reason],
      'next_measurement':'Supply time-stamped motion (t_s,displacement_m), or a steady video with a visible moving region and known frame rate.',
      'meta':{'sam':'NOT_CALLED','muse':'NOT_CALLED'},
      'outcome_program':{'status':'REFUSED','can_apply_to_hardware':False}}


def simulate_intervention(twin, *, scenario='as_observed', stiffness_scale=1., damping_scale=1., force=0., horizon_s=3., dt=.02):
    """Never an actuator command. Scenarios are model edits, NOT predictions of failure thresholds."""
    model=twin.get('model')
    if not model:raise ValueError('No identifiable model; refuse hypothetical physical claims')
    if scenario not in ('as_observed','stiffness_reduction','damping_loss','damping_increase','custom'):
        raise ValueError('Unsupported intervention')
    if scenario=='stiffness_reduction':stiffness_scale=.6
    elif scenario=='damping_loss':damping_scale=.25
    elif scenario=='damping_increase':damping_scale=2.
    for n,v,lo,hi in [('stiffness_scale',stiffness_scale,.1,2.),('damping_scale',damping_scale,0.,4.),('force',force,-1.,1.),('horizon_s',horizon_s,.2,6.)]:
        v=_finite_float(v,n)
        if not lo<=v<=hi:raise ValueError(f'{n} outside simulation-only permitted bounds')
    p=model['parameters']; omega2=float(p['stiffness_per_mass_per_s2'])*stiffness_scale
    damp=float(p['damping_per_mass_per_s'])*damping_scale
    gain=p.get('action_gain')
    if abs(force)>1e-12 and gain is None:
        raise ValueError('Input-to-motion gain was not measured; cannot simulate forced intervention')
    vals=twin['measurement']['trace'];x=float(vals[-1]['x']);
    xprev=float(vals[-2]['x']);dtprev=float(vals[-1]['t']-vals[-2]['t']);v=(x-xprev)/dtprev
    steps=min(600,int(horizon_s/dt));points=[]
    for i in range(steps+1):
        if i%max(1,steps//150)==0:points.append({'t':round(i*dt,4),'x':round(x,7)})
        a=-omega2*x-damp*v+float(p['offset_acceleration'])+float(gain or 0)*float(force)
        v+=dt*a;x+=dt*v
        if not np.isfinite(x+v) or abs(x)>1e8:raise ValueError('Model trajectory unstable/out of range')
    return {'scenario':scenario,'status':'SIMULATED_CONDITIONAL_NOT_CERTIFIED',
        'parameters':{'stiffness_scale':stiffness_scale,'damping_scale':damping_scale,'force':force},
        'trace':points,'warning':'What-if within local surrogate only; NOT a verified break threshold, diagnosis, repair guarantee, or hardware instruction.'}


def demo_twin():
    """Synthetic seeded signal for UI exploration, never presented as real data."""
    rng=np.random.default_rng(77)
    t=np.arange(0,10,.02);x=np.zeros(len(t));v=0.;x[0]=.023
    u=np.sin(2*np.pi*.8*t)*.14
    for i in range(1,len(t)):
        a=-38*x[i-1]-1.4*v+float(u[i-1])
        v+=.02*a;x[i]=x[i-1]+.02*v
    csvdata='t_s,displacement_m,command\n'+'\n'.join(f'{tt:.5f},{xx+rng.normal(0,.00003):.7f},{uu:.5f}' for tt,xx,uu in zip(t,x,u))
    result=reconstruct('SIMULATED_mechanical_trace.csv',csvdata.encode())
    result['evidence']['origin']='SYNTHETIC_GENERATED_INSIDE_PHYSICA'
    result['evidence']['scenario']='forced second-order oscillator with camera-like position noise'
    return result
