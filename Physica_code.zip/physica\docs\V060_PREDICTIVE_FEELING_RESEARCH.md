# Physica v0.6 — Giving AI the ability to feel (engineering prototype)

**What is actually implemented:** a *simulated*, action-conditioned multisensory model that predicts calibrated sensor outputs, compares them against observations, learns a bounded contact mechanism from held-out actions, exports signed Physical Experience lessons, and conditionally transports them to different bodies and senses. An incremental online state/parameter estimator and an executable two-stage CLI for later independent recordings are also implemented. The full earlier Physica architecture is retained.

**What this is not:** consciousness, subjective pain, an autonomously actuated robot, a general-purpose world-model foundation model, a laboratory validation, a demonstrated published research breakthrough, or a 9+/10 independently judged hackathon entry. No Meta API credentials were used and no authenticated Muse or SAM output was generated. A signed local timestamp is **not** independently witnessed chronology.

## The meaning of *feeling*

A simple sensor detects a physical quantity. Physica's proposed **predictive physical feeling** closes a different loop:

1. An identified body with known calibration receives an approved force history `u(t)`.
2. The physical twin forecasts its state (displacement and velocity) and *the sensation expected at each calibrated sensor*, using each sensor's own observation equation.
3. The difference between predicted and actual sensations is the sensory **innovation**. It is normalized by the independently calibrated sensor noise. Unexplained surprise must **not** automatically be labeled damage or a causal discovery.
4. Multiple training interventions support a candidate missing mechanism. Entirely distinct held-out interventions test whether adding that mechanism improves prediction.
5. A verified local result becomes a signed Physical Experience lesson; compatible receivers translate the **dimensionless** interaction ratio into their own force scale, mechanics, and sensor units.
6. A low-force target probe is sealed and measured separately. Its signed raw trace is checked **inside** the transfer gate. Only then can a main target forecast be sealed and subsequently checked.
7. The receiving body can adapt the same physical parameter and offer another lesson for another body, under another local probe.

For a candidate smooth contact-friction model, the implemented mechanistic differential equation is

\[
 m\ddot q+c\dot q+kq+F_{\rm contact}\tanh(\dot q/v_0)=F_{\rm applied}(t).
\]

Sensor `m` is modeled independently as

\[y_m(t)=h_{m,q}q(t)+h_{m,v}\dot q(t)+b_m+\epsilon_m(t).\]

There is **no universal identity equating microphone pressure to velocity**, or touch to acceleration: a measured transfer function is necessary, and the current prototype assumes one *local linear* observation operator. Real microphone impulse responses often require frequency-dependent operators, acoustic propagation, phase/time alignment, and calibration against an independent reference. The present simulator intentionally does **not** prove those conditions on any particular microphone.

The error called *feeling* is simply `observed_sensor - predicted_sensor_given_known_action`, not an emotion. `FeelingSession` assimilates streaming observations using a bounded augmented-state EKF, with innovation rejection and no motor commands. Parameter estimates are **provisional** until validated on interventions that were not used for fitting.

## What transfers, and what does not

A's fitted contact-force parameter is normalized by A's independently measured reference force:

\[\pi_A=F_{{\rm contact},A}/F_{{\rm reference},A}.\]

A candidate receiver B reconstructs `F_contact,B = pi_A * F_reference,B`, simulates its independently calibrated dynamics, and maps predicted physical state to B's calibrated sensor. This is **conditional** similarity: mechanical families and boundaries must match; frequencies must fall inside the supported range; a supervised low-force measurement of B must not contradict A's lesson. Source and target provenance must match. Simulation signatures cannot authorize real hardware.

This is *not* proof of universal cross-embodiment generalization. It is a deliberately narrow, falsifiable first mechanism family. Both force scales are known and target calibration exists **before** B's response; hence “zero-shot” applies only to B's full-force target experiment, **not** to any target measurement or calibration.

### Security boundaries

- `verify_lesson` checks a signed teaching record; a mutated normalized force ratio fails.
- `prepare_low_force_probe` rejects forces above 35% of the target reference; no actuation occurs.
- `check_low_force_probe` calculates disagreement from the entire independently supplied measured interaction, not from a JSON score.
- `transfer_check` recomputes the disagreement from signed probe + signed prediction + measurement trace. Missing/tampered/calibration-changed data refuse.
- `signed_forecast` binds target body, target sensor calibration, times, force history, predicted sensations, and source-memory digest.
- `verify_consequence` rejects later observations whose body, sensor calibration, action, or time axis differs from the commitment.
- Ed25519 signatures establish integrity of records signed by the local installation; they **do not** establish that the measurement or its timestamp was genuine. Independent witnesses/timestamps and real hardware provenance are needed for public claims.
- All action selection is **recommendation-only**, reversible and subject to physical force/operating boundaries. The system never drives motors or applies force.

## Run the v0.6 exhibit

```bash
python -m pip install -e '.[dev,video]'
python -m physica.feeling.cli demo --out demo/feeling_v06
python -m physica.feeling.cli benchmark --out demo/feeling_benchmark.json --trials 20
pytest -q tests/test_predictive_feeling_v060.py
```

Open `demo/feeling_v06/experience_lab.html`. The complete pre-generated simulation is in `examples/feeling_v060/simulated_lab`.

The CLI also has **separate prospective stages**, accepting physical data from later user-supplied recording workflows:

```bash
# Source memory: fit on A's labeled calibrated training interventions;
# test on distinct held-out interventions (do not re-use training actions).
python -m physica.feeling.cli learn source_train.json source_validation.json --out source_lesson.json

# B's requested action and calibrated body/senses are known, but not the outcome.
python -m physica.feeling.cli prepare-probe source_lesson.json B_probe_request.json --out B_probe_prediction.json
# Collect authorized low-force B measurement *after* the prediction is sealed.
python -m physica.feeling.cli check-probe source_lesson.json B_probe_prediction.json B_probe_recording.json --out B_probe_verified.json

# Main B forecast uses only source memory, target calibration, and checked probe.
python -m physica.feeling.cli prepare source_lesson.json B_main_request.json B_probe_verified.json --out B_main_prediction.json
# Collect independent measurement and reveal truth only after the commitment.
python -m physica.feeling.cli check B_main_prediction.json B_main_recording.json --out B_verified.json
```

JSON schema for `B_main_request.json`: `body` is `asdict(Body)`, `senses` maps sensor ID to `asdict(Sense)`, `time_s`, `force_n`, and `initial_state` are calibrated **before** the main action. `B_main_recording.json` adds `intervention_id`, `observations`, `origin`, `evidence_sha256`, and `human_authorized`; examples are in `simulated_lab`. **Do not claim real-data support is scientifically validated simply because a JSON field says `origin: real_measurement`.** Force, clock, initial state and each sensor transfer function must genuinely have been independently calibrated. A cryptographic hash cannot prove a fabricated input is physical.

## The six sensory pathways, honestly

| Channel | v0.6 | Required physical validation |
|---|---|---|
| Sight | Recorded-video optical flow, separate SAM 3.1 parser adapter, calibrated box-motion bridge, physical state prediction | Actual authenticated SAM call, reference target, scale and clock, held-out motion measurement |
| Hearing | WAV analysis from earlier CSG, v0.6 calibrated acoustic observation in independent physical units | Real microphone transfer function, acoustic propagation, noise, synchronization |
| Touch | Bounded force-response model, simulated strain observations, supported tactile/force representations | Real transducer, force fixture, safe contact test, independent ground truth |
| Proprioception | Sensor-domain model for encoder velocity, online state estimator | Motor/IMU/encoder calibration and controlled action loop |
| Smell | Earlier `grammar.chemical` handles calibrated concentration and sensor-lag traces, separately from vibration | Electronic-nose hardware, independent gas references, drift and environmental testing |
| Taste | Earlier conductivity and chemistry-oriented representations | Electrochemical probes, liquid calibration, cleaning, drift controls, chemical identification limits |

No module claims that a gas sensor identifies a molecule by magic or that ordinary video provides pressure/force directly. Physical causality needs interventions or other sufficient identification assumptions.

## Why Meta matters, as a measurable scientific tool

Retained **genuine, optional, billable adapters** in `physica.experience.meta_live`, `physica.grammar.meta_sam_official`, `physica.grammar.meta_cirte`, and `physica.triad.cli`. v0.6 adds `physica.feeling.context` and `physica.feeling.meta_bridge` to hand off evidence without trusting text as physics.

- **Muse Spark:** supplies grounded object/context/confounder hypotheses before experiments. Does not invent Newtons, newtons per meter, or sensor calibration.
- **SAM 3.1:** tracks a moving part **and a fixed reference**; `sam_tracks_to_calibrated_camera` requires independently measured meters-per-pixel and visual-noise floor, removes common camera motion, returns candidate displacement observations, and refuses incomplete tracks.
- **Muse Wonder:** can propose a supported mechanism (currently the only bounded v0.6 mechanism is `smooth_contact_friction`) and a discriminating reversible experiment. Source context must be tied to the hashed scene; `contextual_hypotheses` filters unapproved suggestions. `evaluate_contextual_hypothesis` requires held-out physical interventions to accept the candidate.
- **V-JEPA 2:** separate weights and compute needed. Existing calibrated latent readout modules can evaluate embeddings, but **actual V-JEPA inference is not performed**. V-JEPA latent vectors are not SI-unit physical measurements.
- **Physica/CIRTE:** the numeric gate remains authoritative; actions from any model are merely proposals requiring an independent safety review and human approval.

**Necessary ablation before claiming “Meta made Physica discover a new mechanism”:** preregister the same clips/fixtures and experiment budget; compare no Meta/hand-selected ROI, SAM-only, Spark/Wonder-only, and full Physica on held-out physical outcomes. Metrics: hypothesis recall, measured sensor accuracy, #target interventions to an error target, uncertainty calibration, false transfers, and latency/API spending. Offline authored mock replies or the synthetic showcase cannot demonstrate those gains. No model key was supplied or executed here.

## Connecting all three experiences

- **Physica Lab**: v0.6 predictive feeling demo, then replace synthetic trials with calibrated, consented machines at Moody Makerspace. A hears and feels; B sees; C receives the updated physical lesson.
- **Physica Discover**: retained prefix-only video forecast and independent external recording ingestion from v0.5.2 (`physica.triad.cli`). A predicted future frame is **indirect observation**, never equivalent to direct pressure/force experience. Show when physical cause is unidentifiable from a single video.
- **Physica Lens**: retained local phone-video browser application (`python -m physica.triad.cli lens-serve --port 8765`); it uses the same evidence/prognosis boundaries, not a separate scripted persona. Near-term example: safely investigate wobbling furniture, not diagnose dangerous machinery from a clip. No native Meta glasses integration has been authenticated or tested.

### Comparison to earlier work

The constituent mathematics—state-space estimation, innovations, system identification, smooth Coulomb friction, intervention design, cross-system parameter scaling and sensor fusion—has strong prior art. The proposed **engineering research hypothesis** is that *a shared, appropriately calibrated action→sensation→consequence language with local validation and principled refusal may improve cross-sensory and cross-body learning sample efficiency.* Test against classical system ID, independent fit per target, no-transfer physics, nearest-source transfer, Koopman/shared-latent transfer where data permit, and Meta-off. Do not describe this module as an established new theorem, a fundamental transform, or a documented global first.

### Evaluation limitations

The simulation deliberately uses the same contact-friction family for A/B/C and a different coefficient for its shifted group. Baselines lack that coefficient, making the task favorable for transfer. The `benchmark` reports exact units and failure examples, not out-of-family results disguised as blind predictions. Low-force probes **consume an intervention** and must count in adaptation budgets. No confidence bands in v0.6 are calibrated for real-world coverage. The streaming estimator's parameter sigma is conditional on its assumed dynamics and Gaussian observation model.

## Highest-value next real experiment

On **two different clamped metal strips**, independently measure applied force (with approved fixture), camera motion (with fixed reference), and at least one acoustic or strain response. Change a **reversible** boundary/friction contact that the initial baseline omits. Train A on at least two action types, independently test a third, preseal B's low-force probe, then preseal B's new action and compare its result against physics-only and a locally calibrated model with the *same total experimental budget*. Collect negative trials and human-approved actions. Do not attempt destructive breakage or motor control for the first test. Add independent timestamp/witness for public evidence. Include real authenticated Meta calls only after calibrations are ready, and always save both metadata and failure cases.

### Live Meta context path (local API key, optional)

```sh
export MODEL_API_KEY='YOUR_KEY_ON_YOUR_OWN_COMPUTER'
# Authenticated Spark and Wonder, for recorded OBSERVED video context only.
# Requires explicit permission for billable calls. No default mock output.
python -m physica.feeling.cli meta-feel setup.mp4 --allow-billed-meta --out live_context.json
# For physical SAM geometry, additionally specify all independent measurements:
python -m physica.feeling.cli meta-feel setup.mp4 --allow-billed-meta \
  --sam-concept 'moving beam tip' --moving-id 1 --reference-id 2 \
  --meters-per-pixel 0.0004 --fps 60 --sensor-noise-m 0.00003 \
  --calibration-id independently_measured_fixture_scale \
  --out live_context_and_geometry.json
# Test the proposed bounded mechanism against A's measured interventions:
python -m physica.feeling.cli learn source_train.json source_validation.json \
  --meta-context live_context.json --out source_lesson_if_supported.json
```

The numerical scales above are **example placeholders**; do not supply fabricated calibration constants to actual physical interpretation. The supplied `meta-feel` implementation was **not called with an authenticated API key** in this release. Its geometry path uses the retained official SAM 3.1 streaming parser and will refuse missing tracked objects. Live Meta latency and billed costs must be measured in your own account. Even a genuine model response that says `smooth_contact_friction` remains an unverified hypothesis until separate experiments support it.
