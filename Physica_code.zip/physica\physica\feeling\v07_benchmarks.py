"""Reproducible, predeclared, SIMULATION-ONLY v0.7 evaluations.

Reports successful and negative results, strong target-probe comparator,
multisensory gating, and causal-mechanism candidate transport.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .core import Body,Sense,simulate
from .reliable_fusion import TrustedFeelingFilter
from .fair_benchmark import evaluate as fair_evaluate
from .mechanism_transfer import (feature,discover_and_sign,make_target_probe_certificate,
                                 predict_target_acceleration)


def _new_filter(body,senses,prior,P):
    return TrustedFeelingFilter(body,senses,np.asarray(prior,float).copy(),P.copy())


def fusion_experiment(trials=60,seed=2026):
    """Camera estimates x, microphone observes velocity via INDEPENDENT gain.

    This is deliberately a complementary-sensor family. A correlated or biased
    camera/mic can have worse results; joint conflict must be reported.
    """
    rng=np.random.default_rng(seed)
    B=Body('fusion_mechanics',.1,20.,.12,.2,.3)
    sensors={'camera':Sense('camera','sight','mm',(1000.,0.),0.,.08,'separate_scale'),
             'mic':Sense('mic','hearing','Pa',(0.,150.),0.,.08,'separate_acoustic_calibration')}
    errors={name:[] for name in ('camera_only','mic_only','both')}
    counts={name:0 for name in errors};corrupt_refusals=0
    dt=.01
    for i in range(trials):
        # Unknown state deviation is sampled independently of measurements.
        true_initial=np.array([.002,.05])+rng.normal(0,[.0007,.01])
        assumed_initial=np.array([.002,.05]);cov=np.diag([.0007**2,.01**2])
        target=simulate(B,[0.,dt],[0.,0.],initial_state=true_initial)[-1]
        obs={k:float(np.array(s.state_gains)@target+rng.normal(0,s.noise_std)) for k,s in sensors.items()}
        for name,keys in (('camera_only',['camera']),('mic_only',['mic']),('both',['camera','mic'])):
            filt=_new_filter(B,sensors,assumed_initial,cov)
            result=filt.step(dt,0.,{k:obs[k] for k in keys})
            if result['status']=='CONDITIONAL_MULTISENSORY_UPDATE':
                err=np.sum(((filt.state-target)/[.0007,.01])**2)
                errors[name].append(float(err));counts[name]+=1
        damaged=_new_filter(B,sensors,assumed_initial,cov)
        corrupt=damaged.step(dt,0.,{'camera':obs['camera'],'mic':obs['mic']+5.})
        corrupt_refusals+=corrupt['status']=='ABSTAIN_SENSOR_CONFLICT'
    return {'origin':'SYNTHETIC','trials':trials,'seed':seed,
            'mean_normalized_state_error_on_accepted':{k:float(np.mean(v)) if v else None for k,v in errors.items()},
            'accepted_per_method':counts,'microphone_corruption_abstained':corrupt_refusals,
            'assumptions':['independent white Gaussian sensor noise','independently known sensor gains',
                           'complementary camera-position and microphone-velocity observation operators',
                           'no learned sensor bias or live Meta model',
                           'accepted-only errors exclude abstained cases; report coverage alongside accuracy']}


def _ep(body,ident, *, beta=.22, reference=.01, amplitude=.008, freq=9.4, phase=0., seed=0,
        candidate='cubic_elasticity',noise_n=.00025):
    rng=np.random.default_rng(seed);t=np.linspace(0,1.15,145)
    w=freq
    x=amplitude*np.sin(w*t+phase)+.2*amplitude*np.cos(1.7*w*t+.6)
    v=amplitude*w*np.cos(w*t+phase)-.34*amplitude*w*np.sin(1.7*w*t+.6)
    a=-amplitude*w*w*np.sin(w*t+phase)-.578*amplitude*w*w*np.cos(1.7*w*t+.6)
    f=body.mass_kg*a+body.damping_n_s_m*v+body.stiffness_n_m*x+beta*feature(body,x,v,candidate,reference)
    f=f+rng.normal(0,noise_n,len(t))
    return {'intervention_id':ident,'displacement_m':x.tolist(),'velocity_m_s':v.tolist(),
            'acceleration_m_s2':a.tolist(),'force_n':f.tolist(),
            'origin':'SYNTHETIC','measurement_noise_force_n':noise_n}


def mechanism_experiment(seed=2026):
    A=Body('A_source_mechanism',.12,22.,.13,.25,1.)
    B=Body('B_unseen_mechanism',.14,24.,.15,.28,1.)
    train=[_ep(A,f'A_train_{i}',amplitude=.006+.001*i,freq=8.3+i,phase=.2*i,seed=seed+i) for i in range(2)]
    validation=[_ep(A,'A_independent_validation',amplitude=.0085,freq=11.,phase=.6,seed=seed+10)]
    discovered=discover_and_sign(A,train,validation,displacement_reference_m=.01)
    if discovered['status']!='CANDIDATE_SIGNED_REQUIRES_TARGET_PROBE':
        return {'status':'SOURCE_DISCOVERY_FAILED','source':discovered}
    probe=_ep(B,'B_low_force_measured',amplitude=.005,freq=8.1,phase=.2,seed=seed+21)
    cert=make_target_probe_certificate(discovered,B,probe,displacement_reference_m=.01)
    unseen=_ep(B,'B_unseen_main',amplitude=.010,freq=9.7,phase=.7,seed=seed+31)
    forecast_request={k:v for k,v in unseen.items() if k!='acceleration_m_s2'}
    outcome=predict_target_acceleration(discovered,B,forecast_request,displacement_reference_m=.01,probe_certificate=cert)
    no_lesson=(np.asarray(unseen['force_n'])-B.damping_n_s_m*np.asarray(unseen['velocity_m_s'])-
               B.stiffness_n_m*np.asarray(unseen['displacement_m']))/B.mass_kg
    truth=np.asarray(unseen['acceleration_m_s2'])
    inferred=np.asarray(outcome['predicted_acceleration_m_s2']) if outcome['status']=='MODEL_CONDITIONAL_TARGET_FORECAST' else no_lesson
    # No sensor-corruption or signed chronology is inferred from these synthetic equations.
    unknown_train=[_ep(A,f'unknown_train_{i}',candidate='quadratic_drag',beta=.6,
                       amplitude=.008+.001*i,seed=seed+50+i) for i in range(2)]
    unknown_validation=[_ep(A,'unknown_heldout',candidate='quadratic_drag',beta=.6,
                            amplitude=.013,freq=10.3,seed=seed+60)]
    unknown=discover_and_sign(A,unknown_train,unknown_validation,displacement_reference_m=.01,
                              allowed_mechanisms=('cubic_elasticity',),minimum_heldout_gain=.8)
    return {'status':outcome['status'],'origin':'SYNTHETIC',
            'identified_candidate':discovered['record']['payload']['mechanism'],
            'estimated_dimensionless_coefficient':discovered['record']['payload']['dimensionless_coefficient'],
            'probe_status':cert['status'],'source_sha256':discovered['record']['sha256'],
            'target_acceleration_rmse_m_s2':float(np.sqrt(np.mean((inferred-truth)**2))),
            'known_physics_rmse_m_s2':float(np.sqrt(np.mean((no_lesson-truth)**2))),
            'unrepresented_mechanism_status':unknown['status'],
            'note':'Target acceleration is conditioned on observed target x,v,F; this is NOT an unopened full trajectory forecast',
            'candidate_evaluations':discovered['candidates']}


def run_all(trials=12,seed=2026):
    return {'schema':'physica.feeling.v07.evaluation','origin':'SYNTHETIC',
            'same_budget_friction':fair_evaluate(seed,trials),
            'sensor_reliability':fusion_experiment(max(30,trials*3),seed),
            'missing_mechanism_transfer':mechanism_experiment(seed),
            'live_meta_calls':0,'independently_measured_hardware_trials':0,
            'subjective_feeling_claimed':False}


def save(path, trials=12, seed=2026):
    data=run_all(trials,seed);p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,indent=2)+'\n');return data
