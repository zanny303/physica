"""Real-time touch for robots and machines: feed one sample at a time, get touch events as they happen.

Uses a body learned beforehand (TouchTransform.fit on a few seconds of normal motion). Each update is one step of
the body's own observer (a few small matrix-vector products), so it runs at sensor rate on a laptop or a robot's
computer. An event fires when the push is far above what the body was just doing; with many sensors (video, a
skin of IMUs) it also says where.
"""
from __future__ import annotations

from collections import deque

import numpy as np

from physica.touch.transform import TouchTransform


class TouchStream:
    def __init__(self, body: TouchTransform, threshold: float = 15.0, window_s: float = 0.5, refractory_s: float = 0.5,
                 warmup_s: float = 1.0):
        self.b, self.thr = body, threshold ** 2
        self.x = np.zeros(body.n)
        self.hist = deque(maxlen=max(int(window_s * body.fs), 4))
        self.ref, self.warm = int(refractory_s * body.fs), int(warmup_s * body.fs)
        self.t, self.last = 0, -10 ** 9
        lam = body.lam[body.sel]
        self.sk = body.s[body.sel]
        self.cs = body.c[body.sel]
        self.Q = body.Q[:, body.sel]
        self.z_prev = np.zeros(len(lam), complex)
        self.lam = lam

    def update(self, y: np.ndarray) -> dict | None:
        b = self.b
        yr = (np.atleast_1d(np.asarray(y, float)) - b.mean) @ b.W
        xp = b.F @ self.x
        self.x = xp + b.K @ (yr - b.C @ xp)
        z = self.x @ self.Q
        e = (z - self.z_prev * self.lam) * self.cs
        self.z_prev = z
        v = 2j * self.sk.imag * e
        if b.measure == "velocity":
            v = v / self.sk
        elif b.measure == "acceleration":
            v = v / self.sk ** 2
        g = float(np.sum(np.abs(v) ** 2))
        base = np.mean(self.hist) if self.hist else g
        self.hist.append(g)
        self.t += 1
        if self.t < self.warm or self.t - self.last < self.ref or g < self.thr * max(base, 1e-30):
            return None
        self.last = self.t
        ev = {"t": self.t / b.fs, "strength": float(np.sqrt(g / max(base, 1e-30)))}
        if b.P >= 8:
            L = b.localize(v)
            ev.update(point=L["point"], fit=L["fit"])
        return ev

    def run(self, Y: np.ndarray) -> list[dict]:
        return [e for y in np.asarray(Y) for e in [self.update(y)] if e]
