"""Dynamic Mode Decomposition (DMD) and DMD with control (DMDc), in plain numpy.

DMD generalises Fourier analysis to dynamics: each mode has a frequency, a growth/decay rate
(damping) and a shape across channels. DMDc (Proctor, Brunton & Kutz) separates the effect of the
machine's own commands from its underlying dynamics: the efference-copy idea in matrix form.
"""
from __future__ import annotations

import numpy as np


def hankel(x: np.ndarray, delays: int) -> np.ndarray:
    """x: (T, C) -> (C*delays, T-delays+1); row block j holds x shifted by j samples."""
    x = np.asarray(x, float)
    if x.ndim == 1:
        x = x[:, None]
    T, C = x.shape
    cols = T - delays + 1
    if cols < 2:
        raise ValueError("signal too short for this many delays")
    return np.vstack([x[j:j + cols].T for j in range(delays)])


def _truncated_svd(X: np.ndarray, rank: int):
    U, s, Vh = np.linalg.svd(X, full_matrices=False)
    r = min(rank, int(np.sum(s > s[0] * 1e-10)))
    return U[:, :r], s[:r], Vh[:r]


def dmd_modes(x: np.ndarray, fs: float, rank: int = 20, delays: int = 16, n_channels: int | None = None) -> list[dict]:
    """Exact DMD on a delay-embedded signal. Returns modes sorted by energy (non-negative frequencies only).

    Each mode: freq_hz, growth_per_s, damping_ratio, amplitude, shape (per original channel, normalised).
    """
    H = hankel(x, delays)
    C = H.shape[0] // delays if n_channels is None else n_channels
    X, Y = H[:, :-1], H[:, 1:]
    U, s, Vh = _truncated_svd(X, rank)
    Atil = U.T @ Y @ Vh.T / s
    lam, W = np.linalg.eig(Atil)
    Phi = Y @ Vh.T / s @ W
    b = np.linalg.lstsq(Phi, X[:, 0], rcond=None)[0]
    dt = 1.0 / fs
    with np.errstate(divide="ignore"):
        omega = np.log(lam.astype(complex)) / dt
    modes = []
    for k in range(len(lam)):
        f = float(np.abs(omega[k].imag) / (2 * np.pi))
        if omega[k].imag < -1e-9:  # keep one of each conjugate pair
            continue
        growth = float(omega[k].real)
        mag = float(np.abs(omega[k]))
        shape = np.abs(Phi[:C, k])
        amp = float(np.abs(b[k]) * np.linalg.norm(Phi[:, k]))
        modes.append({
            "freq_hz": f, "growth_per_s": growth,
            "damping_ratio": float(-growth / mag) if mag > 0 else 0.0,
            "amplitude": amp,
            "shape": (shape / (shape.max() + 1e-30)).tolist(),
        })
    modes.sort(key=lambda m: -m["amplitude"])
    return modes


class DMDc:
    """x_{k+1} = A x_k + B u_k fitted from healthy data (delay-embedded). Predicts the self-caused response."""

    def __init__(self, rank: int = 20, delays: int = 8):
        self.rank, self.delays = rank, delays
        self.A = self.B = None

    def _embed(self, x, u):
        Hx = hankel(x, self.delays)
        Hu = hankel(u, self.delays)
        return Hx, Hu

    def fit(self, x: np.ndarray, u: np.ndarray) -> "DMDc":
        Hx, Hu = self._embed(x, u)
        X, Y, Uc = Hx[:, :-1], Hx[:, 1:], Hu[:, :-1]
        Om = np.vstack([X, Uc])
        Ut, s, Vh = _truncated_svd(Om, self.rank + Uc.shape[0])
        G = Y @ Vh.T @ np.diag(1 / s) @ Ut.T
        n = X.shape[0]
        self.A, self.B = G[:, :n], G[:, n:]
        self._nx = x.shape[1] if np.ndim(x) > 1 else 1
        return self

    def residual(self, x: np.ndarray, u: np.ndarray) -> np.ndarray:
        """One-step-ahead residual for the current (newest-delay) samples: (T-delays, channels)."""
        Hx, Hu = self._embed(x, u)
        pred = self.A @ Hx[:, :-1] + self.B @ Hu[:, :-1]
        err = Hx[:, 1:] - pred
        c = self._nx
        return err[-c:].T  # last block = most recent sample
