# Physica v0.2 — PACER Physical Experience Language (PEL v1)

## Why this matters

Original Physica already contains the Feel Transform, Body Map, Order Feel, a signed Body Bank, discovery/experiments, machine translators, Meta agent adapters, and real-data evaluation scripts. This update **preserves** those capabilities and adds an interoperable, typed **action → prediction → observed consequence → learned hypothesis → cross-machine transfer** protocol.

The "physical words" are not English sentences, an arbitrary learned vector, or unqualified resonance peaks. A Physical Episode (`physica.episode/v1`) contains:

* **Identity:** body ID, observing machine ID, boundary class and body class.
* **Observations:** sensor modality, sampling rate in Hz, calibration ID/status, body coordinate frame and optional rigid transform.
* **Units and uncertainty:** `Quantity(value, unit, sigma, calibration_id)` is used for all newly represented inferred numeric physical quantities.
* **Modal words:** frequency, damping ratio, excitation magnitude and unit, optional mode shape and its frame, confidence. Modes are never made comparable merely because they have nearby frequencies.
* **Action/response:** physical intervention name, typed parameters, human approval, risk and irreversibility classification; predicted and observed scalar response with a common unit and outcome.
* **Causal alternatives:** candidate hypotheses, a normalized posterior and an explicit identifiability flag. Passive observations must not be automatically labelled a unique cause.
* **Provenance:** source hash, code/model version, origin (`simulation`, `real_sensor`, `derived`, `manual`) and evidence note.
* **Lineage and trust:** parent SHA256, cryptographic Ed25519 commitment of an immutable prediction, linked signed reveal and a verified-only transfer store.

Generate the machine-readable JSON Schema:

```bash
physica experience schema --out experience.schema.json
```

`examples/experience/physical_episode.json` is a complete **simulated example**, not real experimental evidence. The schema is implemented in `physica/experience/schema.py` using Pydantic v2. Unknown calibration, uncertainty, and provenance are represented explicitly rather than invented.

## PACER — Physical Active Causal Experience Representation

1. **Feel:** extract states and one-step innovation residuals `E[t,k] = Z[t,k] - μ[k] Z[t-1,k]` from Physica's existing modal transform. This is a known AR/innovation operation, **not claimed as a newly invented transform**.
2. **Attribute:** compute the posterior over competing causes from a declared Gaussian observation model. Do not confuse high numeric posterior with identifiability.
3. **Ask:** compute expected information gain of each candidate action, integrate over its possible outcomes and reject unapproved, irreversible or excessive-risk actions.
4. **Imagine:** a calibrated simulator/twin generates a response and its uncertainty; an LLM may critique but cannot alter the numeric likelihoods.
5. **Seal:** commit prediction with SHA256 + Ed25519 *before* running the physical experiment. Note: local timestamps are **not** independent proof of chronology.
6. **Feel the consequence:** ingest actual measurements and compare with the sealed prediction; classify compatibility or contradiction; do not imply consciousness.
7. **Learn and share:** create a new signed episode linking previous evidence, then query the bank from a different machine.
8. **Verify arrival:** only transfer a prior when body class, boundary class, intervention family, sensor calibration and excitation range are comparable. A local test is needed before calling transfer successful.

**Mathematical core:** For hypothesis `H` and scalar observation `y`, posterior is `p(H|y,a) ∝ p(y|H,a)p(H)`. `expected_information_gain(a) = H(p(H)) - E_{y|a}[H(p(H|y,a))]`; candidate utility subtracts risk and cost. Gaussian likelihoods and trapezoidal quadrature are implemented in `pacer.py`. This is a compact **research prototype**, not state-of-the-art system-identification theory.

## The honest transfer contract

`compare(A,B)` returns either `comparable` with a dimensionless modal-ratio distance, a frequency scale estimate and similarity, or `refused` with reasons. The prototype **refuses** records with missing/unequal body or boundary classes, missing calibration, unknown/mismatched excitation, incompatible interventions or large modal signature shift. Comparable **does not mean identical**: different absolute frequencies can be normalized, but this approximation needs experimental validation.

`transfer_prior(A,B)` only accepts a source with a `verified` outcome. It geometrically mixes Machine A's posterior with Machine B's original prior, scaled by physical comparability, and sets `requires_local_verification=true`. Cross-machine ability is not asserted from nearest-neighbor retrieval alone.

An episode may be "verified" by the numeric interval rule while still being **synthetic**. Its provenance must remain visible and should never be used as real-world proof. Production should demand independent holdouts, trustworthy calibration, versioned measurement methods and stricter cryptographic trust governance.

## Example workflow

```bash
# All of this is runnable offline; the demo is *synthetic*.
physica experience demo --out demo
open demo/experience_lab.html   # on Windows: start demo/experience_lab.html
physica experience verify demo/sealed_before_observation.json
physica experience verify demo/revealed_consequence.json

# A measured clip / CSV uses existing Physica sensing. It will not automatically claim a cause.
physica experience ingest ./clip.mp4 --fps 240 --out sensed.json

# After specifying a calibrated, real-world physical episode with predicted consequence:
physica experience seal planned_episode.json --out signed_prediction.json
# Perform a supervised action, collect external observation file and hash it yourself.
physica experience reveal signed_prediction.json --value 4.2 --unit '1' --sigma 0.25 --out signed_reveal.json
physica experience bank-add signed_reveal.json --bank ./my_physical_bank
physica experience bank-query target.json --bank ./my_physical_bank
```

The `reveal` command records the number supplied by the operator; it **does not physically measure the outcome** or certify that an experiment occurred after sealing. Connect hardware, video/CSV data hashes, witness timestamps and verification measurement scripts before making independent experiment claims. The current source includes legacy `physica sense` and physical experiment commands, but they are not automatically closed-loop-connected to the new protocol.

### Serialisation/security limits

The existing Physica signature module uses deterministic sorted-key JSON, **not complete RFC 8785 JCS canonicalisation**; multi-language signers must normalize to the exact same byte format or use a certified JCS implementation. Signatures attest to integrity of content, not physical truth, independent chronology, or trustworthiness of the signer. Python's `~/.physica/key` must remain private. The ZIP contains no private keys.

### Scientific novelty boundary

Modal analysis, innovations, Bayesian inference, active experimental design and digital twins are established. The **research contribution proposed for Physica** is their particular combination with physical-language typed action-response-consequence episodes, explicit refusal to transfer incomparable experience, cryptographic commitments and local arrival checks. A publication-grade novelty or "breakthrough" claim would require stronger ablations, original datasets and review.
