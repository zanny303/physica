"""Batch-innovation gating for action-conditioned multimodal feeling (v0.7).

Calibrated linear sensing of mechanical state [position, velocity]. The physics
prediction precedes any observation. Contradictory or OOD measurements cause
abstention rather than arbitrary sensor averaging. The chi-square thresholds
are *model conditional*, not validated empirical hazard thresholds.

Inspired by classical innovation gating and linear-Gaussian state estimation;
not a new Kalman filter. No automatic actuation, no consciousness claim.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Mapping
import numpy as np
from scipy.stats import chi2
from .core import Body, Sense, simulate


def _array(a, shape, name):
    v=np.asarray(a,dtype=float)
    if v.shape!=shape or not np.all(np.isfinite(v)):
        raise ValueError(f'{name} has wrong shape or non-finite values')
    return v


@dataclass
class TrustedFeelingFilter:
    body: Body
    senses: Mapping[str,Sense]
    state: np.ndarray
    covariance: np.ndarray
    time_s: float=0.
    friction_ratio: float=0.
    false_alarm_probability: float=.01

    def __post_init__(self):
        if not self.senses or any(k!=s.sensor_id for k,s in self.senses.items()):
            raise ValueError('each sensor must be independently identified')
        self.state=_array(self.state,(2,),'state')
        self.covariance=_array(self.covariance,(2,2),'covariance')
        if np.linalg.eigvalsh(self.covariance).min()<=0:
            raise ValueError('covariance must be positive definite')
        if not (math.isfinite(self.friction_ratio) and 0<=self.friction_ratio<=.8 and
                math.isfinite(self.false_alarm_probability) and .00001<=self.false_alarm_probability<=.2):
            raise ValueError('invalid inference policy')
        if not math.isfinite(self.time_s) or self.time_s<0:
            raise ValueError('invalid initial timestamp')

    def _prediction(self,dt,force_n):
        if not math.isfinite(dt) or dt<=0 or dt*math.sqrt(self.body.stiffness_n_m/self.body.mass_kg)>.35:
            raise ValueError('unresolved or invalid sample interval')
        if not math.isfinite(force_n) or abs(force_n)>self.body.max_authorized_force_n:
            raise ValueError('action outside permitted model envelope')
        def f(z):
            return simulate(self.body,[0.,dt],[force_n,force_n],
                            friction_force_n=self.friction_ratio*self.body.force_reference_n,
                            initial_state=z)[-1]
        z=f(self.state)
        J=np.column_stack([(f(self.state+np.eye(2)[i]*h)-f(self.state-np.eye(2)[i]*h))/(2*h)
                           for i,h in enumerate((1e-6,1e-5))])
        # Fixed, conservative process noise. Must be re-estimated on real equipment.
        P=J@self.covariance@J.T+np.diag([1e-9**2,1e-6**2])
        return z,P

    def step(self,time_s,force_n,measurements:Mapping[str,float]):
        if not math.isfinite(time_s) or time_s<=self.time_s:
            raise ValueError('timestamps must increase')
        if not isinstance(measurements,Mapping) or any(k not in self.senses for k in measurements):
            raise ValueError('unrecognized sensor')
        if any(not math.isfinite(float(v)) for v in measurements.values()):
            raise ValueError('nonfinite measurement')
        forecast,P=self._prediction(time_s-self.time_s,force_n)
        self.time_s=float(time_s)
        # Use *one joint update* to avoid order dependence and false precision.
        rows=[]; observed=[]; noises=[]; labels=[]; diagnostics={}
        for key,val in measurements.items():
            s=self.senses[key]
            if not(s.state_range_m[0]<=forecast[0]<=s.state_range_m[1] and
                   s.velocity_range_m_s[0]<=forecast[1]<=s.velocity_range_m_s[1]):
                diagnostics[key]={'accepted':False,'reason':'outside_independent_calibration_domain'}
                continue
            h=np.asarray(s.state_gains,float)
            predicted=float(h@forecast+s.offset)
            innov=float(val-predicted)
            sigma=math.sqrt(float(h@P@h+s.noise_std**2))
            z=innov/sigma
            rows.append(h);observed.append(innov);noises.append(s.noise_std**2);labels.append(key)
            diagnostics[key]={'accepted':False,'innovation_z':z,'predicted':predicted,
                              'observed':float(val),'unit':s.unit}
        # Prediction still advances even when data are missing. Do not pretend updated.
        self.state=forecast;self.covariance=P
        if not rows:
            return {'status':'NO_TRUSTED_SENSATION','observations':diagnostics,
                    'state_m_m_s':self.state.tolist(),'hardware_actuation_allowed':False}
        H=np.vstack(rows); residual=np.asarray(observed,float);R=np.diag(noises)
        S=H@P@H.T+R
        nis=float(residual@np.linalg.solve(S,residual))
        limit=float(chi2.ppf(1-self.false_alarm_probability,len(rows)))
        # NIS and individual gates are assessed BEFORE fitting. An incompatible
        # measurement set is never used to update the state or sensor noise.
        individual_limit=math.sqrt(float(chi2.ppf(1-self.false_alarm_probability/len(rows),1)))
        if nis>limit or any(abs(diagnostics[k]['innovation_z'])>individual_limit for k in labels):
            for k in labels:diagnostics[k]['reason']='joint_sensor_innovation_conflict'
            return {'status':'ABSTAIN_SENSOR_CONFLICT','observations':diagnostics,
                    'normalized_innovation_squared':nis,'conditional_gate':limit,
                    'state_m_m_s':self.state.tolist(),'hardware_actuation_allowed':False}
        gain=np.linalg.solve(S,H@P).T
        posterior=forecast+gain@residual
        if any(not(s.state_range_m[0]<=posterior[0]<=s.state_range_m[1] and
                    s.velocity_range_m_s[0]<=posterior[1]<=s.velocity_range_m_s[1])
               for s in self.senses.values()):
            return {'status':'ABSTAIN_CALIBRATION_DOMAIN','observations':diagnostics,
                    'state_m_m_s':self.state.tolist(),'hardware_actuation_allowed':False}
        M=np.eye(2)-gain@H
        self.state=posterior
        self.covariance=M@P@M.T+gain@R@gain.T
        self.covariance=(self.covariance+self.covariance.T)/2
        for k in labels:diagnostics[k]['accepted']=True
        return {'status':'CONDITIONAL_MULTISENSORY_UPDATE','observations':diagnostics,
                'normalized_innovation_squared':nis,'conditional_gate':limit,
                'state_m_m_s':self.state.tolist(),
                'conditional_state_sigma':np.sqrt(np.diag(self.covariance)).tolist(),
                'hardware_actuation_allowed':False,
                'note':'statistical assumptions not yet calibrated on real hardware'}
