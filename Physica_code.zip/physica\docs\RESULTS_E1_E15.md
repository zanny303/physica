# Physica: how AI feels the world

**Machines that feel what's wrong, prove why, and act on it in their own language.**

You can't tickle yourself. Your brain predicts the touch your own hand will cause and cancels it, so you only feel what the world does to you (Blakemore, Wolpert & Frith, 1998). Physica gives machines the same trick:

1. It learns what a machine causes by itself.
2. It cancels that.
3. It feels only what's left.

Then it works out **where** the feeling comes from using a body map it learned from itself. It proves what the feeling means, tells the machine what to change in the machine's own language, and checks that the change worked.

**Touch Transform (new, E13):** like the FFT for feeling. It splits any motion (video, accelerometer) into what an object *is* (its modes) and what *touched* it (when, where, how hard), tells a touch from a change of body, imagines the consequence of a touch before making one, and writes the result as machine code.

**World Sense (E12):** Physica also senses how part of the physical world works from real experiments. It runs its own experiments inside what it learned, says what the data can't tell apart, writes the machine instructions (G-code) for an outcome you ask for, and learns from the real result.

**Three algorithms for sensing machines, all learned from healthy data only:**
- **Feel Transform:** cancel what the machine causes itself (E1).
- **Body map:** each part's fingerprint, learned from its own healthy vibration, attributes a feeling to the part that caused it (E11).
- **Order Feel:** senses written in the machine's own rhythm, so a skill can move to a different machine (E9).
- Every action carries a promise that is checked by feeling again (E6).

The hero use case is **Feel Check: looks fine isn't works fine.** A used drone can look perfect and still fly on a damaged propeller. Physica tells the difference from the drone's real flight vibration, without ever having seen damage data.

![Feel Check on a real damaged flight](docs/feel_check.png)

## The loop: physical → digital → physical

| Step | What happens | Proven on real data |
|---|---|---|
| **1 · Feel** | The **Feel Transform** cancels what the machine causes itself (a self-model of "healthy" fitted on healthy flight only) and draws what's left as a **feelogram**. | 76.0% of damage windows felt, 0/17 false alarms, no damage data used (E1) |
| **2 · Discover** | Rival theories, written as code, compete. Each is fitted on one split, chosen on another and judged only on windows it never saw. Physica asks for the experiment that could change a decision, refuses tests that can't, and says **"can't tell"** when the data can't decide. | 2 of 4 arms proven, 2 honestly not proven; "can't tell" which rotor in 15/15 felt flights (E8, discover) |
| **3 · Translate** | The finding is written in the language each machine already speaks: ArduPilot parameters (drone), IEC 61131-3 Structured Text (PLC), Marlin G-code (3D printer). A safety gate checks every file first. | ArduPilot on 11 real flights; PLC on a labelled synthetic stand-in until the Fraunhofer run; G-code format only (E6) |
| **4 · Act & re-feel** | **Action contracts.** Before acting, Physica writes down what the machine should feel afterwards, fingerprinted so the bar can't move. Then it acts, feels again and compares. The change is kept if the promise holds and rolled back if not. | Promise held 11/11; a deliberately wrong setting was caught and rolled back 11/11 (E6) |
| **5 · Remember** | Every proven finding becomes a **signed card** (Ed25519) with where it holds and its track record. New machines start from relatives' cards, and an **arrival check** tests whether a card still fits. **Skills** are cards that hold a *way of feeling* rather than numbers, so they can move to a different machine. | New arm quiet after 5–30 s instead of 30–60 s (E4); arrival check 4/4, 11/12, 15/16, 10/11 (E7); a skill carried from one drone model to another (E9) |

Step 4 turns the "you can't tickle yourself" idea on Physica's own actions. A brain predicts the feeling its movement will cause. Physica predicts the feeling its action should cause, then lets reality grade it. To our knowledge, linking a self-cancelling sense to promise-checked actions across several machine languages is new. We don't claim more than that.

## Results (every number comes from `eval/results/*.json`)

All results are on **PADRE**: real Parrot Bebop 2 flights at 500 Hz, with damaged propellers on known rotors (AeroLab, Poznan University of Technology).
- **Healthy data:** one flight (0000), split in time. The first 17 five-second windows calibrate Physica; the last 17 are held out.
- **Damage flights:** used only for testing.

### E1 · Feel without damage data (`eval/e1_feel_without_damage.py`)

Results on the 12 single-rotor damage flights on rotors B, C and D:

| Method | Uses damage data? | Damage windows felt | False alarms on held-out healthy |
|---|---|---|---|
| **Physica self-model** | no | **76.0%** (95% CI 52.9–95.1, bootstrap by flight) | **0/17** (exact CI 0–19.5%) |
| Spectrogram threshold, no self-model | no | 50.0% (CI 25.0–75.0) | 0/17 |
| Random forest trained on rotor-A damage | yes | 82.1% (CI 63.9–97.1) | 2/17 (CI 1.5–36.4%) |

- **Per flight (Physica / spectrogram):**
  - Chipped edge: B 94/0, C **0**/0, D 85/0.
  - Bent tip: B 91/0, C 29/0, D 12/0.
  - Cut-off tip and both faults: 100/100 on every rotor.
- **Rotor A flights** (excluded above because the random forest trains on them): Physica 83.1%.
- **Known miss:** a chipped edge on rotor C (flight 0010) is not felt at all. It is in the app as used drone #4.

### E8 · "Can't tell" is an answer (`eval/e8_localization_limit.py`)

- **The test:** name the damaged rotor by picking the arm that shakes most.
- **Result:** right in 45.2% of felt windows (exact CI 40.3–50.0; chance 25%). That isn't good enough to name a rotor.
- **Why:** the flight controller speeds up the other rotors to compensate, and PADRE has no motor-RPM data.
- **What Physica did with loudness alone:** every verdict refused to name a rotor (15/15 felt flights) and asked for an experiment: *spin each motor alone for 3 s on the ground, or provide per-motor RPM telemetry.* That failure led to the body map (E11).

### E11 · Body map: WHERE does the feeling come from? (`eval/e11_body_map.py`)

**The problem:** E8 showed that loudness can't locate a damaged rotor on the Bebop. The flight controller spreads the fault and the frame carries vibration everywhere.

**The algorithm (Physica's body map):**
1. In healthy flight each rotor spins at a slightly different speed, so its own vibration line can be told apart.
2. At that line, the 12 sensor channels (4 arms × 3 axes) move in a fixed pattern set by where the rotor sits on the frame. Physica stores that pattern (the principal eigenvector of the cross-spectral matrix) as the rotor's **fingerprint**, learned from **healthy flight only**.
3. A damaged propeller adds a once-per-turn force at the same hub, so a felt shake is matched to the fingerprint it fits.

It uses no damage data, no motor-speed telemetry and no drone model. The idea mirrors how infants learn a body map from self-touch: your own actions teach you where your parts are. The method was frozen before its first run on damage data, and these are first-run numbers.

| | Parrot Bebop 2 (15 felt flights, 423 windows) | 3DR Solo (8 flights, 264 windows) |
|---|---|---|
| Loudest arm is the damaged rotor | 45.2% (exact CI 40.3–50.0) | **99.2%** |
| **Body map picks the damaged rotor** | **76.6%** (exact CI 72.3–80.6; by-flight CI 59.1–90.0) | 86.4% (CI 81.6–90.3) |
| Flights right by majority vote | 11/15 | 7/8 |
| Both cues agree → right | 78.7% (on 54% of windows) | 100% (on 85% of windows; CI 98.4–100) |

- **Where it helps:** on the drone where loudness fails, the body map is right 31 points more often.
- **Where it's weaker:** on the Solo, where loudness already works, the body map is weaker. Three of the Solo's fingerprints look alike (overlap up to 0.86), and Physica knows this from healthy data alone. It names a single rotor in 38% of windows (97% right when it does) and otherwise answers "B, C or D".
- **The Feel Check verdict now uses both cues.** If they agree, it names the rotor; if not, it names both and asks for the spin test. Ground truth is hidden until "Reveal".
- **Closest prior work we found:** Baldini et al. (JINT 2026) isolate the faulty propeller with 95% accuracy. Their method needs motor commands, battery voltage and a powertrain model, a classifier trained on labelled simulated faults, and it was tested in simulation. To our knowledge, isolating the faulty rotor on real flights from vibration alone, with no labels, model or telemetry, is new. It is not a solved problem: 76.6% leaves room, and the spin test stays the confirmation.

### E15 · One command for every use case (`eval/e15_sense_all.py`)

Everything above, behind one command:
`physica sense <any video or sensor file>` (add `watch` to keep watching, `--twin` to export a digital twin,
`--stream` to replay it sample by sample as a robot would). It returns a physical fact sheet:
- **Body:** each object's modes (pitch, fade, how hard it was shaken).
- **What kind of object it physically behaves like:** read from frequency ratios alone (a clamped beam rings at
  1 : 6.27 : 17.5; a string at 1 : 2 : 3).
- **How many separate objects are moving:** modes that live in different places are different objects; motion that
  covers the whole frame is the camera or the scene.
- **Every touch, and every change of body** (with *where* and *how much* for beams).
- **The fix in machine languages:** Marlin, Klipper, ArduPilot, and an impulse schedule any controller can use.

**Real beam, no settings given** (`physica watch Vibration_measurement.txt`):

| When | What it felt |
|---|---|
| 10.99 s | touch |
| 21.63 s | body changed (confirmed by the next push) |
| 23.91 s | touch (on the new body) |

- **New body:** after the change it behaves like a clamped beam.
- **The change:** mass removed at **30%** of the length from the clamp (90% range
  27–33%), about 1.86× the beam's mass. The photo marks 35%.
- **Digital twin** (`physica/twin.py`): a few numbers per mode, exported as JSON. Shown a real tap it never saw, it
  feels 50 ms and predicts the next 2.0 s with **R² = 0.68** (correlation 0.90).
- **Robot touch stream** (`physica/touch/stream.py`): fed one sample at a time, it fired at
  10.995, 21.626, 23.915 s, the three real events, at **38 µs per sample** in plain Python.

**Real guitar video, no settings except the capture rate:**
- **Separate objects:** "3 separate objects are moving" (the three strings, at
  80.9, 108.5, 143.3 Hz).
- **Camera motion:** a 6.2 Hz motion covering most of the frame is set aside as the camera or the scene. (This
  appears in the unprompted CLI run; the E15 run sets a 60–295 Hz band and doesn't see it.)

**The Body Bank** (`physica/bank.py`, `bank/bodies.jsonl`): a signed, searchable record of how real things behave.
It is seeded with 3 real bodies: the cantilever with its mass, the same cantilever after release, and the guitar's
three strings. All signatures verify.
- **"What feels like this?":** a quiet late stretch of the beam is matched first to *"same cantilever after the mass
  was released"* (3.4% apart). The honest verdict is "can't compare", because it was shaken much more gently.
- **Another lookup:** 108.5 Hz finds the guitar's A string.

**Honest machine-to-machine words** (`transform.compare_words`):
- **With the mass vs. after, both strongly shaken:** "different" (5.84 -> 6.41 Hz).
- **Strong vs. quiet stretch of the same beam:** "can't compare". This used to be a false "different".

**Limits:**
- **One mode isn't enough for a body type.** The guitar strings show one mode each, and recognising an object's type
  needs two.
- **Beams only for "where":** locating a change assumes a clamped uniform beam.
- **Small bank:** it holds 3 real bodies so far. Its value grows with every recording added
  (`physica bank add file --label ... --licence ...`).

### E14 · Jaw-droppers you can film (`eval/e14_jawdroppers.py`)

Two demos built on the Touch Transform. Each one feels with a camera, decides, acts, and checks itself.

**1. A camera that weighs things.** Film a clamped ruler ringing three times (empty, with a coin, with the object).
- **What it says:** "About 36 g (90% range 22–59 g), 55% of the way from the clamp to the tip."
- **How:**
  - The Touch Transform reads the ruler's modes from the pixels (optical flow).
  - Beam physics turns the frequency drop into a mass.
  - The coin sets the scale in grams.
- **Why the phone's frame rate doesn't matter:** everything is a ratio against the empty ruler, so slow-motion
  files that store the wrong frame rate don't change the answer.
- **Sight and touch are fused.** The image says roughly where the object sits; each felt mode's drop says where the
  mass is and how heavy. Across random scenes they mostly agreed. Touch moved the place closer to the truth in
  1 scene and further in 0, so touch rarely corrects sight yet. An image that misplaces an object near the tip is
  still the main source of error.
- **Physics guards against fooling itself:**
  - A clamped ruler's 2nd mode sits about 6.3× above its 1st, so 2× and 3× copies created by optical flow are
    ignored as echoes.
  - With a mass on, each mode must stay above the empty ruler's next-lower mode (interlacing).
  - Where the image puts the object and how far mode 1 dropped predict where mode 2 must be; only a felt mode near
    that prediction is used.
  - The empty ruler's own mode ratio is checked against 6.27; if it's off, the clamp is loose.

**2. Tune a 3D printer by filming it.** No accelerometer on the printer.
- **Steps:**
  1. Physica writes an excitation G-code.
  2. You film the head in slow motion.
  3. The printer's own G-code is the clock: the move-and-pause rhythm gives the video's true frame rate.
  4. The Touch Transform feels the ringing in every stop.
  5. Physica writes `M593` and Klipper `[input_shaper]` with a promise.
  6. You film again with the shaper on; Physica keeps or rolls back the change.

**Checked where the truth is known (rendered phone videos, LABELLED SIMULATION; random scenes):**

| | Result |
|---|---|
| Weighing: error | median **10%**; 36% of objects within 10%, 73% within 20% (11/12 scenes ran) |
| Weighing: honest range | the 90% range held the true weight in **100%** of scenes |
| Touch vs sight on place | the vibration moved the place closer to the truth in 1 scenes and further in 0 |
| Printer: video clock | frame rate read from the G-code within **0.0%** in every scene |
| Printer: ringing frequency | median error **0.6%** |
| Printer: damping | felt at 0.57× the true value (median), so it reads low |
| Printer: the shaper it wrote | true ringing in pauses dropped by a median **87%**; promise kept in 4/6 |
| Printer: a deliberately wrong shaper (1.5×) | true drop 46% (median); rolled back in 6/6 |

**Limits:**
- **Simulated only so far:** these are rendered videos with known answers. Real phone videos add blur, rolling
  shutter, lighting flicker and wobbly clamps; the real numbers come from your recordings.
- **Weighing is not yet precise:** median error 10%, and some objects are 20–30% off. The coin
  calibration reads the ruler a little heavy, and the image sometimes misplaces an object near the tip.
- **Heavy objects:** they ring too slowly for a 3 s clip, so film 5 s.
- **Ranges are wide**, mostly from calibrating with one coin. Two coins at two places would tighten them.
- **Conservative re-feel:** the printer check's camera noise makes it under-report how much the ringing dropped.
- **Damping reads low.**

**Film it yourself**

*Camera that weighs (about 10 minutes):*
- **You need:**
  - a steel ruler (30 cm) or a thin wooden slat;
  - a heavy book;
  - tape;
  - one US nickel (5.000 g) or quarter (5.670 g);
  - the thing to weigh (5–100 g on a steel ruler: keys, an earbuds case, a candy bar);
  - a kitchen scale for the reveal;
  - a phone with slow motion (240 fps) propped on a stand or a stack of books.
- **Set up:**
  - Clamp the ruler flat under the book at the table edge, with 20–25 cm sticking out.
  - Put the phone at ruler height, looking from the side, with the whole free part in frame and steady light.
  - **The phone must not move between the three clips.**
- **Record three clips:**
  1. Ruler alone: start slow motion, flick the tip down about 1 cm, let it ring 5 s.
  2. Coin taped flat near the tip: the same flick.
  3. Coin removed, object taped anywhere (not right at the clamp): the same flick.
- **Run:** `physica weigh empty.mov coin.mov object.mov --coin-g 5.0`
- **Reveal:** put the object on the kitchen scale, on camera.

*Tune a printer by filming it (about 15 minutes):*
1. `physica printer-video excite --axis X > excite_x.gcode`
2. Put a small piece of patterned tape on the print head for texture.
3. Stand the phone on the table, not touching the printer, 15–30 cm from the head, with the head's whole travel in
   frame. Film the G-code in slow motion.
4. `physica printer-video tune excite.mov --axis X`, then enable the `M593` line (or the Klipper block) it prints.
5. Film the same G-code again: `physica printer-video check after.mov`.
6. For the video, print the same test part before and after, and film the ringing ripples on its surface.

### E13 · The Touch Transform: feel what an object is and what touched it (`eval/e13_touch_transform.py`)

The FFT splits a sound into pitches. The **Touch Transform** splits any motion signal (video pixels, accelerometers,
microphones) into two things: **the object's body** (its modes: how it rings, how fast it stops, what shape it moves
in) and **the touches** that drove them (when, where, how hard). It is the "you can't tickle yourself" idea applied to
every mode at once:
- **Feel (analysis):** `e_k[t] = z_k[t] − μ_k·z_k[t−1]`. Each mode's own ringing is predicted one step ahead; what the
  prediction misses is the push from the world.
- **Imagine (synthesis):** `z_k[t] = μ_k·z_k[t−1] + e_k[t]`. Any imagined push becomes the motion it would cause,
  everywhere, at a few multiplications per mode. The two directions are inverses within the modal subspace.
- **Where was I touched?** For a tap at x0, physics gives `2i·ω_k·Δa_k = φ_k(x0)·F/m`, so the jump the tap causes in
  the body's modal state is the column of mode shapes at the touched point. Matching it against every point gives a
  touch map.
- **Was I touched, or did I change?** A touch leaves the body the same. A change (mass lost, a crack) makes the old
  self-model keep being surprised. Physica relearns a fresh body after each push and compares their surprise on data
  neither model saw.
- **Act:** it tries every candidate action in its head, feels each result, and writes the best one as machine code
  with a promise.

Interactive demo: `python eval/build_touch_page.py` writes `docs/touch_demo.html` (tap the real beam, feel the guitar). It is not committed, because it embeds a frame of the third-party guitar clip.

**A. Real beam.** ARTS-Lab cantilever, 757 mm, one accelerometer at the tip, 46 s (CC BY-SA 4.0). The settings were
chosen on this recording, then frozen for B and C.

| When | What it felt |
|---|---|
| 10.99 s | touch |
| 21.63 s | body changed (confirmed by the next push) |
| 23.91 s | touch (on the new body) |

- **Ground truth:** the raw signal shows taps at about 10.99 s and 23.92 s, and the mass released at about 21.62 s. The
  drop was only "maybe" at first, because the beam rang too faintly to be sure (surprise ×2.7). It was confirmed at the next tap
  (×113).
- **Body after the drop:** 6.41, 41.01, 115.14 Hz. Uniform-beam physics plus the sensor's own tip mass (5.4% of the
  beam) explains all three within 0.4%.
- **Where did the mass come off?** It used only the frequency shifts from the tip sensor, a beam model, and the rule
  that adding a point mass lowers each mode but never below the next-lower mode of the plain beam (interlacing).
  - **Felt:** **227 mm** from the clamp (90% range 204–250 mm); mass about 1.86× the beam.
  - **Photo:** the dataset's photo marks **268 mm**. That's 41 mm off (5.4% of the length), just outside the stated range.
- **Imagined consequence:** it felt the 23.9 s tap for 60 ms, then imagined the next 2 s.
  - With the right body: **R² = 0.54** (correlation 0.86) against the real recording.
  - With its old body, from before the mass dropped, it can't predict it at all (R² ≈ 0).
- **Act, moving the beam without ringing:** input shaping from the felt modes leaves 0.8% of the ringing, for
  90 ms of delay.
  - Written as `M593 X F6.4 D0.012`, Klipper `[input_shaper]`, and an ArduPilot notch for the 41 Hz mode.
- **Act, stopping the ringing:** after the tap, it tried 30,300 counter-taps in its head. The best is a tap 712 mm from
  the clamp, 0.41 s later, pushing against the motion. It predicts 2.7% of the ringing left.
  - **Imagined only:** no robot has tried it yet.

**B. Where was it tapped? Simulated video (LABELLED SIMULATION).** A rendered clamped bar was tapped 60 times at known
places; the AI learned its body from the video itself.
- **Felt:** 50/60 taps.
- **Place error:** median **7.1%** of the length (95% CI 5.0–9.6); 64% within 10%.
- **Baseline:** "wherever moves most" (always near the free tip) scores 33%, with 10% within 10%.
- **Missed taps:** these were near the clamp, where a tap barely moves the bar.

**C. Real video: feel a guitar.** MIT's guitar clip, 600 fps capture per the paper, 0.5 s. Motion is read from pixel
phase.

| Felt pitch | Nearest note | First half / second half |
|---|---|---|
| 80.92 Hz | E2 (-32 cents) | 80.89 / 80.94 |
| 108.51 Hz | A2 (-24 cents) | 108.28 / 108.55 |
| 143.25 Hz | D3 (-43 cents) | 142.55 / — |

- **Which string is which:** each pitch lives on its own string, and the felt top-to-bottom order is
  **E2, A2, D3**, the real order of those strings. Nobody told it what a guitar is.
- **Precision:** E2 and A2 agree between halves to 0.27 Hz. A plain FFT of this clip moves in 2 Hz steps. The third
  string shows in one half only.
- **Interval:** E to A is 508 cents (in tune: 500). This doesn't depend on the exact frame rate.

**Honest limits:**
- **Too little data:** one real beam, one short real video, and touch *place* tested only in simulation.
- **Tuned on the test:** the touch/change settings were tuned on the beam they were tested on.
- **Settings matter:** identifying modes depends on the model settings. Stabilisation across model sizes and a cap
  that keeps every fit overdetermined made it robust in our tests. An earlier, ill-posed guitar fit reported tighter
  agreement (0.13 Hz), and we no longer use it.
- **"Same body" is still too strict:** two stretches of the same beam read as different words, because the quieter one
  rings at a higher first mode and its 115 Hz mode has faded. Words need to carry how hard the object was shaken.
- **Speed:** the FFT is about 504× faster per sample. The gain is meaning, not speed.

**Is it new?**
- **Relatives:** modal identification (ERA/DMD), Kalman innovations, structural force identification, Davis et al.'s
  image-space modal bases (2015), and 2026 touch-from-video models trained on glove sensors.
- **What's different, to our knowledge:** no earlier method does all of this with one invertible pair from a single
  uncalibrated recording:
  - feels the body and the touches;
  - tells a touch from a change of body;
  - places the change;
  - imagines consequences;
  - writes machine code.

### E12 · World Sense: sense how part of the world works, experiment inside, act through G-code (`eval/e12_world_sense.py`)

Every algorithm above senses a machine. **World Sense** senses how a piece of the physical world works, here how
printed plastic carries load. It then runs its own experiments inside what it learned and writes the instructions
a machine executes to get an outcome you ask for.

**The algorithm:**
1. **Sense.** Fit a physical law to real experiments. Physics fixes the law's shape (rule of mixtures for walls and
   infill, layer bonding, material). The real prints fix its numbers. It keeps two kinds of uncertainty: what it
   doesn't know (parameter uncertainty) and how much real prints scatter.
2. **Know what it can't know.** It finds settings that always changed together in the data (aliased), so it can't
   credit an effect to one of them. It also records where it has never been, so anything outside that range counts
   as imagination, not knowledge.
3. **Imagine.** It runs thousands of experiments inside the law, including on objects it never measured: tensile
   tests in, a bar in bending out, using beam physics.
4. **Decide what to do, or what to test.** It picks the action that meets the goal with the confidence asked for.
   When rival explanations would change that action, it designs the real experiment that tells them apart. If they
   wouldn't change it, it refuses to waste a print.
5. **Act and learn.** It writes the G-code, checks it the way a printer would read it, and writes down its promise
   before anyone prints. The real break test then measures what it had to assume, and the next design uses that
   measurement.

**Real data:** 50 tensile prints from Selcuk University (Ultimaker S5, PLA and ABS; see `DATA.md`). No damage
data and no labels beyond the measured strength.

**What it sensed** (95% CIs):
- **Solid printed PLA:** 41.5 MPa (23.1–60.0). **Solid printed ABS:** 27.5 MPa (15.5–39.5).
- **Layer height:** strength scales as layer^0.27 (0.18–0.36), so thicker layers were stronger. In this
  data print speed was fixed by layer height, so this is "layer height and its print speed" together.
- **ABS, hotter nozzle/bed/fan group:** each +1 °C of the group changes strength by -3.0% (-3.9 to
  -2.1%). Across the data's 30 °C range that's about 59% weaker. **Which of the three causes it is not
  knowable from this data:** bed_temperature, fan_speed, nozzle_temperature always changed together. Physica says so.
- **Roughness:** grows as layer^0.83 (0.76–0.89). The simple staircase geometry predicts 1.0. The measured
  exponent is lower, consistent with a texture floor that doesn't depend on layer height. That's a finding to test,
  not a law.

**Does its inner world predict real prints it never saw?** Leave-one-out, mean error in MPa (95% CI):

| World Sense (physics law) | Linear | Random forest | Gaussian process | Predict the average |
|---|---|---|---|---|
| **3.9** (3.1–4.7) | 5.5 | 4.9 | 4.5 (3.5–5.6) | 7.8 |

- **Accuracy:** slightly better than the black boxes, but the confidence intervals overlap, so this alone isn't a
  clear win.
- **Honest uncertainty:** its 90% ranges contained 88% of real prints. The Gaussian process's contained 74%.

**Understanding vs memorising: predicting prints outside the range it learned from.** Mean error in MPa:

| Learn on → predict | **World Sense** | Linear | Random forest | Gaussian process | Train average | World Sense 90% range held |
|---|---|---|---|---|---|---|
| infill <=50% -> predict 60-90% (29 → 21 prints) | **5.6** (4.1–7.2) | 9.6 | 8.5 | 9.8 | 10.1 | 90% |
| walls <=5 mm -> predict 6-10 mm (26 → 24 prints) | **4.0** (3.0–5.1) | 13.6 | 6.1 | 6.1 | 7.0 | 100% |
| layers <=0.1 mm -> predict 0.15-0.2 mm (30 → 20 prints) | **5.2** (3.4–6.8) | 44.2 | 8.5 | 11.2 | 8.8 | 95% |

Outside the data, the black boxes were no better than the training average (often worse). The physics-shaped
sense stayed accurate, and its ranges still held.

**Experimenting: fewest real prints to find a strong one.** The 50 real prints are the answer key. Each method
starts from 4 random prints that all miss the goal and picks which real print to make next. The table shows extra
prints needed (mean, 95% CI) and how often the goal was found within 3 extra prints (300 starts):

*Goal ≥ 30 MPa (7 of 50 prints qualify):*

| Method | Extra prints | Found within 3 |
|---|---|---|
| **World Sense** | 3.54 (3.3–3.8) | 57% |
| Gaussian-process Bayesian optimisation | 4.83 (4.4–5.3) | 48% |
| Random forest, pick the best guess | 5.14 (4.8–5.5) | 39% |
| Random | 5.47 (5.0–6.0) | 43% |

*Goal ≥ 33 MPa (6 of 50 qualify):*

| Method | Extra prints | Found within 3 |
|---|---|---|
| **World Sense** | 3.75 (3.4–4.1) | 60% |
| Gaussian-process Bayesian optimisation | 5.85 (5.4–6.3) | 36% |
| Random forest, pick the best guess | 5.43 (5.0–5.9) | 41% |
| Random | 6.44 (5.8–7.1) | 39% |

**Acting: "a bar spanning 100 mm that holds 5 kg at its middle, with the least plastic."**
- **Inner experiments:** it ran 113,400, covering every width, height, wall, infill, layer and temperature it
  has evidence for. 105,776 of them would hold with 95% confidence.
- **Lightest:** 6 × 6.5 × 120 mm, 1.35 mm walls, 10% infill, 0.2 mm layers, nozzle
  205 °C, bed 65 °C, fan 25%, 40 mm/s → **4.1 g of PLA**. Bed, fan and speed copy
  combinations seen in real prints, because the data can't separate their effects.
- **Promise (written before printing):** holds 5 kg for 60 s; breaks at 9.9 kg (90% range 5.0–17.9 kg).
  The range is wide on purpose. Bending strength was never measured in the data, so the bending-to-tension ratio
  is an assumption (1.0–1.7) that the first real break replaces.
- **G-code:** `eval/results/world/bar_5kg.gcode`. Read back like a printer would: all moves on the bed,
  temperatures and fan set, 4.13 g of plastic (+0.2% vs the design).

**Designing the experiment that settles a question: heat or fan?**
- **ABS: worth printing.** The rival explanations ("the nozzle", "the fan", "the bed") disagree by up to
  4.8 kg, while prints normally scatter by about 1.9 kg.
  - **The test:** four test bars (nozzle low/high × fan off/full, bed fixed); G-code in `eval/results/world/test_abs_*.gcode`.
  - **What each explanation predicts:** if the fan is the cause, both fan-on bars break near
    3.2 kg and both fan-off bars near
    8.0 kg. If the nozzle is the cause, the split is by
    temperature instead. If the bed is the cause, all four bars match.
- **PLA: not worth printing yet.** The rival explanations agree within normal print scatter (largest gap
  1.2 kg vs 2.2 kg), so the result couldn't change the design. Physica refuses the test.

**Your part (about 30 minutes plus print time):** print `bar_5kg.gcode` in PLA. Rest it on two supports 100 mm
apart, hang 5 kg from the middle for 60 s, then add water until it breaks. Then run
`physica world learn --break-kg <kg> --held`. That turns the promise into a signed record and replaces the
bending assumption with your measurement. Predictions were committed in `predictions/world_bar_5kg.json` before
any real test.

**Is it new?**
- **Not new on their own:**
  - Closed-loop Bayesian optimisation of print settings (ARES; Deneault et al., MRS Bulletin 2021).
  - Self-driving labs (e.g. A-Lab; Szymanski et al., Nature 2023).
  - Grey-box (physics + data) models.
  - Choosing experiments that tell rival models apart (Box & Hill, 1967).
- **What's different here, to our knowledge:** one loop, learned from 50 public prints, that does all of these:
  - says what its data can't tell apart;
  - refuses tests that can't change the decision;
  - imagines an object type it never measured through physics, with a falsifiable promise;
  - compiles the result into checked G-code;
  - turns the real outcome into a measured constant for the next design.
- **The limits:**
  - **Small data:** 50 prints from one printer; specimen geometry and orientation undocumented.
  - **Unmeasured bending:** bending strength is assumed until your first break.
  - **The race was on recorded prints:** each method could only pick among the 50 prints that already exist, not
    invent new settings.

### Discover · rival theories on real flights (`eval/discover_padre.py`)

- **The question:** how should a healthy arm's vibration change with rotor speed?
- **The setup:** four theories run in a sandbox. Each is fitted on 12 windows, chosen on 5, and judged on 17 unseen windows.

Error on unseen windows (log power):

| Theory | Arm A | Arm B | Arm C | Arm D |
|---|---|---|---|---|
| constant level (baseline) | 0.57 | 0.46 | 0.56 | 0.42 |
| linear in rotor speed | 0.71 | 0.72 | 0.46 | 0.77 |
| **quadratic resonance shape** | **0.23** | **0.19** | **0.12** | **0.30** |
| power law in speed | 0.41 | 0.45 | 0.50 | 0.41 |
| **Verdict** | proven | proven | not proven | not proven |

- **Arms C and D are not proven.** Their winners' error bars, learned from only 5 windows, held on 47% and 76% of unseen windows (80% needed). Physica keeps those winners as hypotheses, not facts.
- **What it does next:**
  - Arms A and B: no more tests (one theory survived and it's proven).
  - Arm C: needs more healthy data.
  - Arm D: one test near 190 Hz rotor speed, where its three surviving theories still disagree.
- **Label:** the four theories are an offline stand-in for Muse Spark (`MOCK=1`). The judging is real.

### E6 · Translate, act and re-feel (`eval/e6_translators.py`)

- **ArduPilot:**
  - **What Physica writes:** on 11 damaged flights where it felt something, the felt frequency becomes a harmonic-notch `.param` file (`INS_HNTCH_*`).
  - **How it's tested:** the same notch is replayed on the recorded vibration.
  - **Result:** median **−19.2 dB** at the felt frequency and −1.3 dB elsewhere (13.3 to 22.2 dB across flights). The promise (≥ 10 dB down, < 3 dB change elsewhere) held **11/11**.
  - **Control:** a notch set 1.5× too high was caught and **rolled back 11/11**.
  - **Caveats:**
    - This is a replay on recorded data, not a live flight.
    - PADRE is 500 Hz, so verify the frequency on a full-rate ArduPilot log.
    - The notch makes the controller stop fighting the shake; it does not fix the propeller. The real action is to find the damaged prop with the spin test and replace it.
- **PLC:**
  - **What Physica writes:** `FB_PhysicaFeel` turns vibration into imbalance (g·mm), raises an alarm, then trips.
  - **Result:** the Python mirror of the block stays quiet when balanced and trips at 130 g·mm, before the 152.1 g·mm limit.
  - **Label:** calibration is a **synthetic stand-in** until E2 runs on the Fraunhofer shaft data.
- **Marlin/Klipper:** `M593` input-shaping lines are format-checked only. There's no printer data here, so Physica makes no promise it can't check.

### E4 · Knowledge that compounds (`eval/e4_compounding.py`)

Each arm in turn is treated as a "new" arm. Below: seconds of healthy flight it needs before false alarms stay at 5% or less (40 repeats per budget):

| | Arm A | Arm B | Arm C | Arm D |
|---|---|---|---|---|
| Learning from scratch | 30 s | 40 s | 30 s | 60 s |
| **Starting from siblings' cards** | **10 s** | **30 s** | **5 s** | **5 s** |

- **Detection after 85 s is about the same either way** (siblings vs scratch: A 66 vs 68%, B 94 vs 95%, C 17 vs 17%, D 49 vs 49%).
- **Copying siblings' cards as fixed truth** is also quiet quickly, but misses more damage (A 54%, B 46%, C 2%, D 47%). That's why cards are a starting point, never a verdict.

### E7 · Arrival check (`eval/e7_arrival_check.py`)

Split-conformal intervals with a binomial coverage test:
- **4/4:** an arm's own card fits it later in the flight.
- **11/12:** a different arm's card is flagged "doesn't fit here".
- **15/16:** damaged flights are flagged (the miss is again 0010).
- **10/11:** after relearning only the failing self-model, it fits.

### E9 · Skills that travel to a different machine (`eval/e9_skill_transfer.py`)

**The setup:**
- Learned on the Parrot Bebop 2, then carried to the **3DR Solo**. That's a bigger PADRE drone with different motors and two-blade propellers: 9 real flights, never used before this test.
- On the Solo, each skill gets **zero damage data**. It relearns its numbers from the first half of one healthy flight.
- It's judged on the second half of that flight (false alarms) and on 8 damaged Solo flights.

| Skill (learned on the Bebop) | Bebop: damage felt · false alarms | Solo: damage felt · false alarms · flights caught |
|---|---|---|
| **Order Feel**: orders 0.25–1.25× of the machine's own main line | 49.8% · 0/17 | **100% · 0/17 · 8/8** |
| Plain-frequency self-model, 95–200 Hz (the E1 sense) | **76.0%** · 0/17 | 100% · **4/17** (exact CI 6.8–49.9%) · 8/8 |
| Narrow Order Feel, 0.85–1.15× (where Bebop damage showed) | 4.4% · 0/17 | 82.0% · 0/17 · 7/8 |
| Baseline: plain band power, 95–200 Hz | 50.0% · 0/17 | 100% · 0/17 · 8/8 |

What this shows:
- **Writing a sense in the machine's own rhythm** made it stay quiet on a new machine where the plain-frequency one raised false alarms.
- **Discovery on arrival:** on the Solo, Order Feel placed the damage at **0.49–0.60× the main line** (median 0.53×) across all 8 damaged flights. The Solo's main line is its two-blade propellers passing, so about 0.5× is once per propeller turn, consistent with an unbalanced propeller. Nobody told it where to look.
- **Over-fitting the source is the main danger.** The narrow skill, tuned to where damage showed on the Bebop, is the worst on both machines. Its card is marked "retired".
- **The arrival check catches a misfit:**
  - The Bebop's numbers, copied to the Solo unchanged: "doesn't fit here". The Solo's main line is 201 Hz, outside the card's proven 98–158 Hz.
  - After relearning from half a healthy Solo flight: "fits", with 16/17 unseen healthy windows inside.
  - *Honest note:* a first version checked only the leftover size and wrongly said "fits". We fixed it by adding the proven-range rule Physica uses everywhere else.

**Limits:**
- **No single skill wins everywhere.** On the Bebop the plain-frequency self-model is best.
- **Solo damage is strong** (100–1000× the healthy power at once per turn), so even the plain baseline catches it there.
- **Speed conditioning didn't help.** A speed-conditioned variant, tried after a first look at these results, did worse on both drones (29.4% on the Bebop, 1/17 false alarms on the Solo), so it's reported and not used.
- **A truly fresh test needs a third machine.** The skill cards are signed now, before that run:
  - the factory shaft (E2 data), or
  - the robot arm (E10).

### E10 · A robot arm feels touch without a touch sensor (`eval/e10_robot_touch.py`, run on your machine)

- **The sense:** the controller of a real cobot (voraus-AD: pick-and-place, 12 anomaly kinds including collisions, extra weight, axis friction, lost cans and cable entanglement) already predicts the torque its own motion needs.
- **How Torque Feel works:**
  1. It cancels that prediction.
  2. It cancels what the robot always has at each moment of its task (learned from normal cycles only).
  3. It flags what's left and says which joint and when.
- **Status:** the pipeline runs on the dataset's own 4-cycle sample. Results need the 1.1 GB file (see `DATA.md`; CC BY-NC-SA 4.0, non-commercial). The dataset authors report that their own method should reach AUROC above 0.9; E10 reports AUROC per anomaly kind for comparison.

### The gap this bridges (research, Oct 2026)

- **Cross-machine "zero-shot" fault diagnosis** still trains on labelled faults from source machines and stays within one component type. For example, YOTOnet ([arXiv 2605.04528](https://arxiv.org/abs/2605.04528)):
  - covers bearings only;
  - reaches F1 ≈ 0.3 on a dataset that's far from its training data;
  - lists interpretability and reliability as future work.
- **A review of 212 physics-informed health-monitoring studies** ([arXiv 2608.10047](https://arxiv.org/abs/2608.10047)) finds the field problem-specific. It calls for transferable design patterns and uncertainty-aware, lightweight models, and notes that healthy-only methods are rarely benchmarked.
- **Physica's bridge:**
  - senses written in each machine's own coordinates (rotor orders, task phase);
  - learned from healthy data only, on every machine;
  - carried as signed skills with a per-machine record and an arrival check;
  - honest "can't tell" outside proven ranges.
- **On the robot side,** residual-based collision detection is classic (momentum observers). Physica treats the controller's own torque prediction as the efference copy and learns what's left from normal cycles.

### Pending (code and tests are in the repo; not yet results)

- **E2 · wobble in grams on the Fraunhofer shaft:** calibrated from healthy data plus one known imbalance, then predicts the rest. Needs the 3 GB dataset, run locally.
- **E3 · Imagine:** train on simulated failures. Needs the same data.
- **E5 · Sense Evolution:** an AlphaEvolve-style loop where Muse Spark writes new senses as code and reality scores them by the worst unit. Needs a live Muse Spark run. The mock run is saved as `E5_sense_evolution_MOCK.json` and is **not** a result.

## Live experiments: find out what to do, then check it in the real world

Recorded data can only *suggest* what to do. Discovering it takes experiments. These two loops run with a phone and the free **phyphox** app (Acceleration (without g) → Export CSV). Physica:
1. asks for specific recordings;
2. works out the change that makes the outcome better;
3. writes down its promise before you act;
4. feels again;
5. keeps or rolls back the change;
6. remembers the result as a signed action record.

Each record pairs an action with its felt consequence. A library of these records is the action → consequence data that physical AI is missing.

**Fan balancing (any wobbling fan: ceiling, desk, PC, a propeller)**
- **The method:** four 30 s recordings (the fan as it is, then a coin taped on blade 1, 2 and 3). Physica finds the once-per-turn line itself: it's the line that changes when *you* move the weight.
- **The output:** an amplitude-only four-run balancing solution, for example "add 1.46 g on blade 3 and 0.40 g on blade 1". If the four runs disagree, it says "can't tell, repeat the runs".
```bash
physica balance plan --trial-g 1                     # what to record
physica balance solve run_O.csv run_T0.csv run_T120.csv run_T240.csv --trial-g 1 --name myfan
physica balance check run_after.csv --name myfan     # re-feel: kept or rolled back, signed record
```

**3D printer ringing → G-code**
- **The method:** Physica writes a short excitation G-code. You tape the phone to the moving part and record. Physica finds the resonance frequency and damping and writes Marlin `M593` (ZV input shaper) plus the Klipper `[input_shaper]` equivalent.
- **The check:** it predicts how much ringing remains, then re-feels the same excitation with shaping on.
```bash
physica printer excite --axis X > excite_x.gcode     # run it on the printer while phyphox records
physica printer solve before.csv --axis X --name myprinter
physica printer check after.csv --name myprinter
```
Honest notes:
- The phone's mass lowers the printer's resonance a little. The re-feel compares like with like.
- Both loops are tested here only on physics simulations (`tests/test_experiments.py`). In the fan simulation the fix removed 99% of the wobble. **Real results come from your runs.**

## Run it

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev,agents]"
python -m pytest -q                      # all tests
python -m physica.app --replay           # open http://127.0.0.1:8000 (no data, no API key needed)
```

Replay mode serves results precomputed from the real flights (`replay/`). To run live on the data:

```bash
export PHYSICA_PADRE_DIR=/path/to/UAV_measurement_data      # see DATA.md
python eval/e1_feel_without_damage.py && python eval/e8_localization_limit.py
python eval/e4_compounding.py && python eval/e7_arrival_check.py
python eval/build_library.py            # signs the library with this install's key (~/.physica/key)
python eval/discover_padre.py && python eval/e6_translators.py
python eval/e9_skill_transfer.py && python eval/build_skills.py   # skills carried Bebop 2 -> 3DR Solo
python eval/e11_body_map.py             # body map: which rotor (signs the body-map cards)
export PHYSICA_PRINT_DATA=/path/to/data.csv && python eval/e12_world_sense.py   # World Sense on 50 real prints
export PHYSICA_BEAM_FILE=/path/to/Vibration_measurement.txt PHYSICA_GUITAR_VIDEO=/path/to/guitar.mp4
python eval/e13_touch_transform.py && python eval/build_touch_page.py           # Touch Transform + demo page
python eval/e14_jawdroppers.py                                                 # weigh-by-camera and printer-by-video, rendered tests
python eval/e15_sense_all.py                                                   # one command for every use case, real data; seeds the Body Bank
export PHYSICA_VORAUS_FILE=/path/to/voraus-ad-dataset-100hz.parquet && python eval/e10_robot_touch.py  # optional
python -m physica.app.build_replay      # refresh replay/
python -m physica.app                   # live mode
```

Command line:
- `physica feel padre:0100`
- `physica ask padre:0100`
- `physica commit-prediction padre:0100` (records a verdict in git before the reveal)
- `physica library`
- `physica sense FILE` / `physica watch FILE` (any video or sensor file: body, object type, touches, changes, fixes; `--twin twin.json`, `--stream`)
- `physica bank add|find|list` (the Body Bank)
- `physica weigh empty.mov coin.mov object.mov --coin-g 5.0` (a camera that weighs things)
- `physica printer-video excite|tune|check` (tune a 3D printer by filming it)
- `physica world design --goal-kg 5` (lightest bar for 5 kg → G-code + promise), then `physica world learn --break-kg <kg> --held`

MCP server: `python -m physica.agents.mcp_server`. It exposes the tools observe, feel, recall, check, predict and translate.

## Meta models: what each one does

| Model | Role in Physica | Status |
|---|---|---|
| **Muse Spark** | Proposes rival theories and new senses as code (run only in the sandbox) | Offline stand-in until a key is set |
| **Muse Wonder** | The agent behind "Is it safe to fly?": calls Physica's tools and cites signed cards | Offline stand-in until a key is set |
| **Muse Glimmer** (open weights, self-served) | Second opinion in the safety gate on every action; hard rules always apply first | Rules-only until `GLIMMER_BASE_URL` is set |
| SAM 3.1, Voice Transcribe | Planned: video vibration senses and spoken questions | Not built yet |

Set up `.env` from `.env.example` with your own key and the model IDs **from the official docs** (never commit `.env`). The client stops at a hard **$120** budget and caches every response so the demo replays offline.

## Safety and honesty rules in the code

- **Advice, not a safety certification.** This is on every Feel Check.
- **Actions only come from signed, proven cards inside their proven range**, through the safety gate. Each one writes a settings file for a human to review; nothing is sent to a machine.
- **Model-written code runs only in a sandbox:** AST denylist, isolated subprocess, empty environment, numpy only, 10 s timeout.
- **A signature proves origin and integrity, not truth.** New installs add their own public key in `keys/` without invalidating existing cards.
- **Mock results are labelled as mock.** Raw data and private keys are never committed.

## Repo map

```
physica/feel      Feel Transform: self-model, Order Feel (skills that travel), Torque Feel (robots), DMD, feelogram
physica/discover  sandbox, rival theories + proof, probe (next experiment / refuse / can't tell), Sense Evolution
physica/act       action contracts (promise → act → re-feel → keep or roll back)
physica/translate ArduPilot notch, PLC Structured Text, Marlin/Klipper
physica/sense.py  one entry point: any file -> fact sheet (body, object type, touches, changes, fixes)
physica/bank.py   Body Bank: signed, searchable record of how real things behave
physica/twin.py   checkable digital twin export, simulate, predict-after-touch
physica/touch     Touch Transform: modes + touches (analysis/synthesis), touch vs body change, video motion, beam physics, imagined actions
physica/world     World Sense: physical laws learned from real experiments, aliasing map, inner experiments, bar design, checked G-code
physica/library   signed cards, library-as-prior, arrival check
physica/agents    tools, Wonder agent, Glimmer safety gate, MCP server
physica/app       Feel Check web app (standard library only) with replay mode
eval/             every experiment behind every number; results in eval/results
```

## Related work and credits

- **Efference copy:** Blakemore, Wolpert & Frith 1998; Wolpert, Miall & Kawato 1998.
- **Dynamic mode decomposition with control:** Proctor, Brunton & Kutz 2016.
- **Conformal prediction:** Vovk et al.; Angelopoulos & Bates 2021.
- **AlphaEvolve:** Novikov et al. 2025, for evolving programs against a scorer.
- **Visual vibrometry:** Davis et al. 2015.
- **Indirect tyre-pressure monitoring:** a long-standing "sense from a model" in cars.
- **ArduPilot:** harmonic notch documentation.
- **Data:**
  - **PADRE**, AeroLab, Poznan University of Technology (JINT 2024, doi 10.1007/s10846-024-02101-7). No licence file is stated; see `DATA.md`.
  - **Fraunhofer** unbalance dataset (Mey et al. 2020).

**AI assistance:** built with help from AI coding assistants. Every result is produced by the scripts in `eval/` and can be rerun.

**Licence:** Apache-2.0. © 2026 Zanea Ali.

## Optional field CSV workflow

To perform an actual two-stage instrumented A→B prediction (without automatic
hardware actuation), use `physica experience frontier-prepare` followed by
`physica experience frontier-check`. Calibration and signed real-source evidence
are mandatory; see `docs/FRONTIER_v03.md`. No such hardware test is claimed to
have been completed in this project update.

## Example numeric model comparison

```bash
python -m physica.cli experience dual-rank examples/dual_rank_request.json --out dual_rank_result.json
```

The example is deliberately labeled *synthetic*, not live Meta.


