"""One page for the video: what was measured, what was predicted, what Muse said, and what reality answered, misses included."""
from __future__ import annotations

import html
import json
from pathlib import Path

STYLE = """:root{--bg:#07090d;--panel:#0d1219;--line:#222c38;--text:#e8edf4;--muted:#9aa7b6;--good:#4fe3c1;--warn:#f2b84b;--bad:#ff7a7a}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.5 system-ui,sans-serif}
main{max-width:980px;margin:auto;padding:32px 16px 64px}h1{font-size:34px;line-height:1.15;margin:8px 0 6px}h2{font-size:20px;margin:0 0 10px}
.sub{color:var(--muted);margin:0 0 22px}section{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:18px;margin:14px 0}
.tag{display:inline-block;font:700 12px ui-monospace,monospace;padding:4px 9px;border-radius:7px;border:1px solid var(--warn);color:var(--warn)}
.real{border-color:var(--good);color:var(--good)}table{width:100%;border-collapse:collapse;font-size:14px}th,td{text-align:left;padding:7px 8px;border-bottom:1px solid var(--line);vertical-align:top;overflow-wrap:anywhere}
th{color:var(--muted);font-weight:600}.big{font-size:28px;font-weight:750}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}
.right{color:var(--good)}.wrong{color:var(--bad)}.open{color:var(--warn)}.note{color:var(--muted);font-size:14px;margin:8px 0 0}ul{margin:6px 0 0;padding-left:20px}"""


LABELS = {"physica": "Physica", "no_model_same_tone": "assuming no change", "no_lesson_full_head_mass": "no lesson"}


def _load(path: Path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def _e(v) -> str:
    return html.escape("" if v is None else str(v))


def _hypotheses(inquiry: dict | None) -> str:
    review = (inquiry or {}).get("meta_scientific_review") or {}
    if review.get("status") != "META_COUNCIL_PROPOSALS_UNVERIFIED":
        return '<p class="note">No live Muse review is included in this report.</p>'
    hyps = "".join(f"<li><b>{_e(h.get('name'))}</b>: {_e(h.get('claim'))}</li>" for h in (review.get("revised") or {}).get("hypotheses", []))
    doubt = (review.get("critic") or {}).get("reason_to_doubt")
    return (f"<p><b>Muse Wonder's revised explanations</b>, {review.get('successful_authenticated_calls', 0)} live calls with receipts. "
            f"These are unverified.</p><ul>{hyps}</ul>" + (f'<p class="note"><b>Muse Spark\'s doubt:</b> {_e(doubt)}</p>' if doubt else ""))


def build(name: str, sessions: Path, simulated: bool = False, inquiry: str | None = None) -> str:
    base = (_load(sessions / f"{name}_baseline.json") or {}).get("baseline") or {}
    model = (_load(sessions / f"{name}_model.json") or {}).get("model") or {}
    trials = _load(sessions / f"{name}_trials.json") or []
    preds = _load(sessions / f"{name}_predictions.json") or []
    label = ('<span class="tag">SIMULATED FILMS</span>' if simulated else '<span class="tag real">RECORDED FILMS</span>')
    parts = [f"<h1>{_e(name)}: what Physica felt</h1><p class=\"sub\">Every sealed trial is listed, including misses. Advice only: a person ran every step.</p>{label}"]
    stats = []
    if base.get("mean_hz"):
        stats.append(f'<div><div class="big">{base["mean_hz"]:.2f} Hz</div>healthy tone from {base.get("films_used")} films</div>')
    if model.get("usable"):
        stats.append(f'<div><div class="big">{model["m_g"]:.0f} g</div>effective moving mass (+/- {2 * model["m_sd_g"]:.0f} g)</div>')
        stats.append(f'<div><div class="big">{model["k_n_per_m"] / 1000:.1f} kN/m</div>stiffness (+/- {2 * model["k_sd"] / 1000:.1f})</div>')
    if stats:
        parts.append(f'<section><h2>The printer it learned</h2><div class="grid">{"".join(stats)}</div></section>')
    rows = ""
    for t in trials:
        g = t.get("grade") or {}
        result = g.get("result", "hidden")
        cls = {"right": "right", "wrong": "wrong"}.get(result, "open")
        cause = _load(sessions / f"{name}_cause_{t['trial']}.json") or {}
        truth = _e(g.get("truth", "hidden"))
        if g.get("truth_cause"):
            truth += f" ({_e(g['truth_cause'])}" + (f", {g['truth_g']:g} g" if g.get("truth_g") else "") + ")"
        rows += (f"<tr><td>{t['trial']}</td><td>{_e(t['change'].get('verdict'))}<br><span class=\"note\">{_e(t['change'].get('shift_hz'))} Hz</span></td>"
                 f"<td>{_e(cause.get('verdict', 'not tested'))}<br><span class=\"note\">{_e(cause.get('reason', ''))}</span></td>"
                 f"<td>{truth}</td><td class=\"{cls}\">{_e(result)}</td></tr>")
    if rows:
        parts.append("<section><h2>Blind trials</h2><table><tr><th>#</th><th>Sealed answer</th><th>Cause test</th><th>Truth</th><th>Change call</th></tr>"
                     f"{rows}</table></section>")
    parts.append(f"<section><h2>What Muse proposed</h2>{_hypotheses(_load(Path(inquiry)) if inquiry else None)}</section>")
    rows = ""
    for r in preds:
        p = r["sealed"]["payload"]["prediction"]
        g = r.get("grade") or {}
        cls = {"held": "right", "broken": "wrong"}.get(g.get("verdict"), "open")
        errors = ", ".join(f"{LABELS.get(k, _e(k))}: {v} Hz" for k, v in (g.get("error_hz") or {}).items())
        rows += (f"<tr><td>{r['pred']}</td><td>{_e(p['source'])}<br><span class=\"note\">{p['added_g']:g} g added</span></td><td>{p['tone_hz']:.2f} Hz</td>"
                 f"<td>{_e(g.get('measured_hz', 'not filmed'))}</td><td class=\"{cls}\">{_e(g.get('verdict', 'open'))}</td><td>{errors}</td></tr>")
    if rows:
        parts.append("<section><h2>Sealed predictions</h2><table><tr><th>#</th><th>From</th><th>Forecast</th><th>Measured</th><th>Result</th><th>Errors</th></tr>"
                     f"{rows}</table></section>")
    parts.append('<p class="note">A seal shows a forecast wasn\'t edited, not when it was made. Publish its code somewhere timestamped before the reveal to prove that.</p>')
    return f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Physica evidence</title><style>{STYLE}</style></head><body><main>{"".join(parts)}</main></body></html>'
