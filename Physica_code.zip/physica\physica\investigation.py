"""Evidence Sufficiency and Active Inquiry (ESAI) -- bounded proposal, not a novel proven law.

A model's system label is not measurement evidence. This module separates typed
signal observations from inferences, prerequisites, and next-action suggestions.
The small Gaussian discrimination planner calculates a *hypothetical* EIG based
on explicit, externally supplied predictions; it never invents physical values.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import log
import numpy as np


@dataclass(frozen=True)
class CandidateMeasurement:
    name: str
    means: tuple[float, ...]
    noise_sd: float
    cost: float = 0.0
    risk: float = 0.0
    approved: bool = True


def expected_information_gain(prior: list[float], candidates: list[CandidateMeasurement], *,
                              samples: int = 1024, seed: int = 3701) -> list[dict]:
    """Monte-Carlo EIG for Gaussian measurements, holding all hypothesis labels fixed.

    Important: means and noises must come from measured/calibrated predictions,
    not a language model's unverified guesses. The same common random numbers
    are used across candidate experiments for a stable comparison.
    """
    p=np.asarray(prior,float)
    if p.ndim != 1 or len(p)<2 or not np.isfinite(p).all() or (p < 0).any() or p.sum()<=0:
        raise ValueError('prior must be a finite nonnegative probability vector')
    p=p/p.sum()
    rng=np.random.default_rng(seed)
    latent=rng.choice(len(p),size=samples,p=p)
    standard_noise=rng.standard_normal(samples)
    h0=-float(np.sum(p*np.log(np.maximum(p,1e-300))))
    out=[]
    for c in candidates:
        mu=np.asarray(c.means,float)
        if not c.approved or mu.shape != p.shape or not np.isfinite(mu).all() or not np.isfinite(c.noise_sd) or c.noise_sd<=0 or c.risk<0 or c.cost<0:
            out.append({'name':c.name, 'status':'refuse', 'why':'not approved or invalid calibrated prediction'})
            continue
        y=mu[latent]+c.noise_sd*standard_noise
        scores=-.5*((y[:,None]-mu[None,:])/c.noise_sd)**2 + np.log(np.maximum(p[None,:],1e-300))
        scores-=np.max(scores,axis=1,keepdims=True)
        weights=np.exp(scores); weights/=np.sum(weights,axis=1,keepdims=True)
        posterior_entropy=-np.sum(weights*np.log(np.maximum(weights,1e-300)),axis=1)
        gain=max(0.0,h0-float(np.mean(posterior_entropy)))
        out.append({'name':c.name,'status':'eligible','expected_information_nats':round(gain,6),
                    'expected_remaining_entropy_nats':round(h0-gain,6),
                    'cost':c.cost,'risk':c.risk, 'utility':round(gain-.1*c.cost-1.0*c.risk,6),
                    'assumptions':'hypothetical calibrated Gaussian outcome; NOT a measured physical discovery'})
    return sorted(out,key=lambda d:d.get('utility',float('-inf')),reverse=True)


def next_evidence(evidence: dict, identity: dict, hint: str | None = None) -> dict:
    """Produce bounded, useful next-measurement guidance without fake certainty."""
    template=identity.get('template','unknown')
    peak=evidence.get('peaks_hz', [])
    asked=[]
    if not evidence.get('signature'):
        asked.append({'sense':'context','why':'Waveform frequency alone cannot identify a physical object',
                      'request':'Identify the device and its operating state, or provide a short video showing it',
                      'source':'requested, not measured'})
    if not evidence.get('fs'):
        asked.append({'sense':'time','why':'Harmonic frequencies depend on verified sample/frame timing',
                      'request':'Provide sample timestamps or a verified camera frame rate',
                      'source':'requested, not measured'})
    if template in ('unknown','rotating_machine') and peak:
        asked.append({'sense':'tachometer','why':'Distinguishes true 1x rotation from a 2x/3x optical harmonic',
                      'request':'If a rotor is confirmed, supply a noncontact tachometer reading',
                      'source':'requested, not measured'})
    if evidence.get('kind') == 'video':
        asked.append({'sense':'stationary reference and scale','why':'Camera movement and missing physical scale confound displacement',
                      'request':'Include a stationary reference and a known ruler scale to calibrate pixels',
                      'source':'requested, not measured'})
    if template == 'unknown' or not evidence.get('signature'):
        asked.append({'sense':'controlled low-energy comparison',
                      'why':'Before and after the same reversible change can distinguish competing physical causes',
                      'request':'Record a safe, approved baseline and matched repeat; do not modify dangerous equipment',
                      'source':'requested, not measured'})
    if template == 'turbine_blade':
        asked.append({'sense':'independent inspection','why':'Crack versus weather is safety critical',
                      'request':'Human-certified inspection required; never auto-resume turbine operation',
                      'source':'required before any actuation'})
    return {
        'status':'insufficient_evidence' if template == 'unknown' else 'conditional_analysis',
        'observations':{'peak_frequencies_hz':peak, 'sample_rate_hz':evidence.get('fs'),
                        'data_kind':evidence.get('kind'),'declared_origin':'not independently verified'},
        'hypotheses':['periodic drive','rotating body','elastic resonance'] if template == 'unknown' and peak else [],
        'missing':asked,
        'recommended_next_measurement':asked[0] if asked else None,
        'research_limit':'No causal identification or universal sensory understanding from one unconstrained recording',
        'no_hardware_action':True,
    }


def goal_directed_value_of_information(prior: list[float], candidates: list[CandidateMeasurement],
                                       goal_payoffs: list[list[float]], *, samples: int = 2048,
                                       seed: int = 2026) -> list[dict]:
    """Goal-specific experiment selection: expected benefit of *decisions*, not just EIG.

    payoffs[action][mechanism] MUST come from an independently validated goal
    model (e.g., bounded motion error) and are not inferred from descriptions.
    The result is advisory. This is a conventional Bayesian value-of-information
    estimator combined with Physica's typed evidence gate, not new mathematics.
    """
    p=np.asarray(prior,float)
    pay=np.asarray(goal_payoffs,float)
    if p.ndim!=1 or p.size<2 or not np.isfinite(p).all() or (p < 0).any() or p.sum()<=0:
        raise ValueError('invalid prior')
    if pay.ndim!=2 or pay.shape[1]!=len(p) or not np.isfinite(pay).all():
        raise ValueError('goal payoff matrix must have actions x mechanisms')
    p=p/p.sum()
    base=float(np.max(pay@p))
    rng=np.random.default_rng(seed)
    latent=rng.choice(len(p),size=samples,p=p)
    u=rng.standard_normal(samples)
    out=[]
    for c in candidates:
        m=np.asarray(c.means,float)
        if not c.approved or m.shape!=p.shape or not np.isfinite(m).all() or not np.isfinite(c.noise_sd) or c.noise_sd<=0 or c.risk<0 or c.cost<0:
            out.append({'name':c.name,'status':'refuse'});continue
        y=m[latent]+c.noise_sd*u
        logw=-.5*((y[:,None]-m[None,:])/c.noise_sd)**2+np.log(np.maximum(p,1e-300))[None,:]
        logw-=np.max(logw,axis=1,keepdims=True)
        w=np.exp(logw);w/=w.sum(axis=1,keepdims=True)
        expected=float(np.mean(np.max(w@pay.T,axis=1)))
        value=max(0.,expected-base)
        out.append({'name':c.name,'status':'eligible',
                    'prior_best_goal_value':round(base,6),
                    'expected_goal_value_after_measurement':round(expected,6),
                    'expected_value_of_information':round(value,6),
                    'net_goal_utility':round(value-.1*c.cost-c.risk,6),
                    'assumptions':'goal payoff and likelihood supplied by verified models; no actuation or guarantee'})
    return sorted(out,key=lambda r:r.get('net_goal_utility',float('-inf')),reverse=True)
