# Physica v0.21 — Discovery Observatory

- New offline/live Meta scientific discovery pipeline (`physica.mace.discovery_observatory`).
- Experimental lockbox, numerical baselines, multi-round Muse nomination, structured separate Muse critic, abstention and SHA-256 forecast integrity receipts.
- New Discovery Observatory interface at `/observatory`, available from the front door and registered in Studio task catalog; no billed Meta calls from the browser task.
- Additional specialized-input fail-closed protections for malformed turbine and F1 telemetry files.
- New dedicated regression and HTTP end-to-end tests.
- Research review and honest 24-seed synthetic comparison; no fabricated Meta advantage.
- No change to hardware actuation permissions, none granted by this release.
