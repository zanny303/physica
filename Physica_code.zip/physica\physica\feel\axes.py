"""Feel axes (SPEC 3, step 5): turn modes and residuals into feelings with units and honest error bars."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

AXES = {
    "weight": "kg",
    "stiffness": "N/m",
    "damping": "damping ratio",
    "friction": "N",
    "wobble_gmm": "g·mm",
    "touch_impact": "z (vs healthy)",
    "wear_drift": "z per hour",
}


def _bin_median(x: np.ndarray, y: np.ndarray, edges: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    c, v = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (x >= lo) & (x < hi)
        if m.sum() >= 3:
            c.append(np.median(x[m]))
            v.append(np.median(y[m]))
    return np.array(c), np.array(v)


@dataclass
class WobbleCalibrator:
    """Imbalance in g·mm from the 1x (order-1) vibration amplitude.

    Physics: unbalance force F = (m·r)·ω², so the 1x amplitude a1 ≈ |H(ω)|·ω²·(m·r) on top of the
    machine's own residual imbalance. Calibrated from healthy data plus ONE known level only.
    """
    bin_hz: float = 1.0
    speeds: np.ndarray | None = None  # bin centres (rev/s)
    gain: np.ndarray | None = None  # a1 per g·mm, per speed bin
    base: np.ndarray | None = None  # healthy a1 per speed bin
    rel_err_q90: float | None = None
    proven_range_hz: tuple[float, float] | None = None
    notes: list[str] = field(default_factory=list)

    def fit(self, speed_h, a1_h, speed_k, a1_k, mr_known: float) -> "WobbleCalibrator":
        speed_h, a1_h = np.asarray(speed_h, float), np.asarray(a1_h, float)
        speed_k, a1_k = np.asarray(speed_k, float), np.asarray(a1_k, float)
        lo = max(np.min(speed_h), np.min(speed_k))
        hi = min(np.max(speed_h), np.max(speed_k))
        both = np.concatenate([speed_h[(speed_h >= lo) & (speed_h <= hi)], speed_k[(speed_k >= lo) & (speed_k <= hi)]])
        # adaptive bins: about 8 windows per file per bin, at least 3 bins, at most hi-lo / bin_hz bins
        n_bins = int(np.clip(min(len(both) // 16, (hi - lo) / self.bin_hz), 3, 80))
        edges = np.unique(np.quantile(both, np.linspace(0, 1, n_bins + 1)))
        edges[-1] += 1e-9
        ch, bh = _bin_median(speed_h, a1_h, edges)
        ck, bk = _bin_median(speed_k, a1_k, edges)
        if len(ch) < 2 or len(ck) < 2:
            raise ValueError("not enough overlapping speeds between healthy and known-level data to calibrate")
        bh = np.interp(ck, ch, bh)
        gain = (bk - bh) / mr_known
        good = gain > 0
        if good.sum() < 2:
            raise ValueError("known level does not raise the 1x amplitude above healthy; cannot calibrate")
        self.speeds, self.gain, self.base = ck[good], gain[good], bh[good]
        self.proven_range_hz = (float(self.speeds.min()), float(self.speeds.max()))
        # calibration-set relative error (honest lower bound on error; real error comes from eval)
        pred = self.predict(np.asarray(speed_k), np.asarray(a1_k))["gmm"]
        ok = np.isfinite(pred)
        self.rel_err_q90 = float(np.quantile(np.abs(pred[ok] - mr_known) / mr_known, 0.9)) if ok.any() else None
        return self

    def predict(self, speed_hz, a1) -> dict:
        s, a = np.atleast_1d(np.asarray(speed_hz, float)), np.atleast_1d(np.asarray(a1, float))
        g = np.interp(s, self.speeds, self.gain, left=np.nan, right=np.nan)
        b = np.interp(s, self.speeds, self.base, left=np.nan, right=np.nan)
        gmm = (a - b) / g
        inside = np.isfinite(gmm)
        half = np.abs(gmm) * (self.rel_err_q90 or 0.0)
        return {"gmm": gmm, "ci_half": half, "inside_proven_range": inside}

    def to_dict(self) -> dict:
        return {"kind": "wobble_order1", "speeds": self.speeds.tolist(), "gain": self.gain.tolist(),
                "base": self.base.tolist(), "rel_err_q90": self.rel_err_q90,
                "proven_range_hz": self.proven_range_hz}

    @classmethod
    def from_dict(cls, d: dict) -> "WobbleCalibrator":
        w = cls()
        w.speeds, w.gain, w.base = np.array(d["speeds"]), np.array(d["gain"]), np.array(d["base"])
        w.rel_err_q90, w.proven_range_hz = d["rel_err_q90"], tuple(d["proven_range_hz"])
        return w


def touch_impact_z(x: np.ndarray, fs: float, base_mu: float, base_sd: float, sub_s: float = 0.25) -> float:
    """Largest short-time energy burst (high-passed) relative to healthy statistics."""
    x = np.asarray(x, float)
    if x.ndim > 1:
        x = np.linalg.norm(x - x.mean(axis=0), axis=-1)
    d = np.diff(x)
    n = max(4, int(sub_s * fs))
    e = [np.log10(np.mean(d[i:i + n] ** 2) + 1e-30) for i in range(0, len(d) - n + 1, n)]
    return float((max(e) - base_mu) / max(base_sd, 1e-6)) if e else 0.0


def subwindow_energy_stats(x: np.ndarray, fs: float, sub_s: float = 0.25) -> tuple[float, float]:
    x = np.asarray(x, float)
    if x.ndim > 1:
        x = np.linalg.norm(x - x.mean(axis=0), axis=-1)
    d = np.diff(x)
    n = max(4, int(sub_s * fs))
    e = np.array([np.log10(np.mean(d[i:i + n] ** 2) + 1e-30) for i in range(0, len(d) - n + 1, n)])
    return float(np.median(e)), float(1.4826 * np.median(np.abs(e - np.median(e))))


def drift_per_hour(t_s: np.ndarray, y: np.ndarray) -> dict:
    """OLS slope with a 95% interval: the wear/drift axis."""
    t = np.asarray(t_s, float) / 3600.0
    y = np.asarray(y, float)
    if len(t) < 3 or np.ptp(t) == 0:
        return {"slope_per_h": 0.0, "ci95": [0.0, 0.0], "significant": False}
    A = np.vstack([t, np.ones_like(t)]).T
    coef, res, *_ = np.linalg.lstsq(A, y, rcond=None)
    dof = max(len(t) - 2, 1)
    s2 = float(np.sum((y - A @ coef) ** 2) / dof)
    se = np.sqrt(s2 / np.sum((t - t.mean()) ** 2))
    lo, hi = coef[0] - 1.96 * se, coef[0] + 1.96 * se
    return {"slope_per_h": float(coef[0]), "ci95": [float(lo), float(hi)], "significant": bool(lo > 0 or hi < 0)}


def damping_from_modes(modes: list[dict], band: tuple[float, float]) -> float | None:
    d = [m["damping_ratio"] for m in modes if band[0] <= m["freq_hz"] <= band[1]]
    return float(np.median(d)) if d else None
