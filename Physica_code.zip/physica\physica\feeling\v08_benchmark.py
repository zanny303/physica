"""Deterministic, explicitly SIMULATED prospective sensory transfer evaluation.

All approaches see the SAME target initial condition and applied force series.
All target-adapted approaches get exactly one local low-force probe; the source
method additionally uses source-body experiments, accounted for explicitly.
No future target trajectory is fed to any forecasting method.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .core import Body, Sense
from .mechanism_transfer import discover_and_sign, make_target_probe_certificate, feature
from .prospective_v08 import simulate_future, seal_future_sensations, score_future_reveal
from .hierarchical_transfer_v08 import combine_source_and_probe


def produce_episode(body, ident, beta, reference, *, seed, amplitude, phase=0., noisy_force_std=.0005):
    rng=np.random.default_rng(seed)
    t=np.linspace(0., .7, 141)
    force=amplitude*(np.sin(8.3*t+phase)+.35*np.sin(19.7*t+.21))
    initial=(.0035+.0003*np.sin(phase),.012)
    z=simulate_future(body,t,force,initial,mechanism='cubic_elasticity',beta=beta,
                      displacement_reference_m=reference)
    x,v=z.T
    extra=beta*feature(body,x,v,'cubic_elasticity',reference)
    a=(force-body.stiffness_n_m*x-body.damping_n_s_m*v-extra)/body.mass_kg
    observed_force=force+rng.normal(0.,noisy_force_std,len(t))
    return {'intervention_id':ident,'times_s':t.tolist(),'displacement_m':x.tolist(),
            'velocity_m_s':v.tolist(),'acceleration_m_s2':a.tolist(),
            'force_n':observed_force.tolist(),
            'true_applied_force_n':force.tolist(),'initial_state_m_m_s':list(initial),
            'origin':'SIMULATED','measurement_noise_force_n':noisy_force_std}


def local_coefficient(body, probe, reference):
    x=np.asarray(probe['displacement_m']);v=np.asarray(probe['velocity_m_s'])
    a=np.asarray(probe['acceleration_m_s2']);force=np.asarray(probe['force_n'])
    f=feature(body,x,v,'cubic_elasticity',reference)
    residual=force-body.mass_kg*a-body.stiffness_n_m*x-body.damping_n_s_m*v
    return float(np.clip((f@residual)/max(float(f@f),1e-20),-3.,3.))


def rmse_camera(state,truth):
    return float(np.sqrt(np.mean(((state[:,0]-truth[:,0])*1000.)**2)))


def evaluate(trials=12,seed=2026):
    rng=np.random.default_rng(seed)
    reference=.01
    A=Body('A_research_source',.12,22.,.13,.25,1.)
    train=[produce_episode(A,f'A_train_{j}',.22,reference,seed=seed+j,amplitude=.075+.015*j,phase=.7*j) for j in range(2)]
    val=[produce_episode(A,'A_independent_val',.22,reference,seed=seed+51,amplitude=.097,phase=1.4)]
    lesson=discover_and_sign(A,train,val,displacement_reference_m=reference)
    if lesson['status']!='CANDIDATE_SIGNED_REQUIRES_TARGET_PROBE':
        raise RuntimeError('source candidate not independently validated under simulated intervention')
    rows=[]
    for i in range(trials):
        mass=.12+rng.uniform(0.,.045)
        stiffness=20.+rng.uniform(0.,7.)
        target=Body(f'B_holdout_{i}',mass,stiffness,.11+rng.uniform(0.,.08),.25,1.)
        true_beta=float(.22+rng.normal(0.,.012))
        # Small probe plus held-out stronger intervention: deliberately tests low-force identifiability.
        probe=produce_episode(target,f'B_probe_{i}',true_beta,reference,seed=seed+500+i,
                              amplitude=.025,phase=.4)
        cert=make_target_probe_certificate(lesson,target,probe,
                      displacement_reference_m=reference,measurement_noise_force_n=.0005)
        main=produce_episode(target,f'B_unseen_{i}',true_beta,reference,seed=seed+900+i,
                             amplitude=.105,phase=.7, noisy_force_std=.0005)
        t=np.asarray(main['times_s']);u=np.asarray(main['true_applied_force_n'])
        initial=main['initial_state_m_m_s'];truth=np.asarray([main['displacement_m'],main['velocity_m_s']]).T
        b0=simulate_future(target,t,u,initial,beta=0.)
        local_beta=local_coefficient(target,probe,reference)
        b_local=simulate_future(target,t,u,initial,beta=local_beta)
        # Raw source estimate is independent of target probe fit, except for compatibility gating.
        source_beta=float(lesson['record']['payload']['dimensionless_coefficient'])
        b_source=simulate_future(target,t,u,initial,beta=source_beta)
        combined=None
        if cert['status']=='ACCEPT_PROBE_MODEL_CONDITIONAL':
            combined=combine_source_and_probe(lesson,target,probe,reference,certificate=cert,between_machine_sigma=.02)
        b_combined=simulate_future(target,t,u,initial,beta=combined['coefficient']) if combined else None
        sensor=Sense('camera','sight','mm',(1000.,0.),0.,.15,f'calibrated_B_{i}')
        forecast=seal_future_sensations(lesson,target,{'camera':sensor},times_s=t,
            force_n=u,initial_state=initial,displacement_reference_m=reference,
            probe_certificate=cert,experiment_id=f'B_unseen_{i}')
        row={'id':f'B_unseen_{i}','true_beta':true_beta,'source_beta':source_beta,
             'local_beta_same_probe':local_beta,'probe_status':cert['status'],
             'no_friction_rmse_mm':rmse_camera(b0,truth),
             'target_only_same_probe_rmse_mm':rmse_camera(b_local,truth),
             'source_transfer_if_valid_rmse_mm':None,
             'source_plus_target_probe_rmse_mm':rmse_camera(b_combined,truth) if b_combined is not None else None,
             'source_weight_declared':combined['source_weight'] if combined else None,
             'posterior_policy_status':combined['status'] if combined else 'REFUSE_PROBE',
             'source_transfer_status':forecast['status'],
             'sealed_forecast_policy':forecast.get('payload', {}).get('adaptation', {}).get('policy'),
             'sealed_posterior_rmse_mm':None,
             'sealed_coefficient':forecast.get('payload', {}).get('dimensionless_coefficient')}
        if forecast['status']=='SEALED_FUTURE_SENSATIONS':
            sensor_truth={'camera':(truth[:,0]*1000.).tolist()}
            checked=score_future_reveal(forecast,sensor_truth,
                        measurement_origin='SIMULATED',experiment_id=f'B_unseen_{i}')
            if checked['status']!='MEASURED_AFTER_SEAL':raise RuntimeError('sealing inconsistency')
            # v0.8.1: the signed future forecast and benchmark posterior are
            # the SAME estimate, not source-only behind the scenes.
            row['sealed_posterior_rmse_mm']=checked['sensor_metrics']['camera']['rmse_native_units']
            row['source_transfer_if_valid_rmse_mm']=rmse_camera(b_source, truth)
            if combined is not None and abs(row['sealed_posterior_rmse_mm'] - rmse_camera(b_combined, truth)) > 1e-8:
                raise AssertionError('signed predictor must equal hierarchical benchmark method')
            if combined is not None and abs(row['sealed_coefficient'] - combined['coefficient']) > 1e-12:
                raise AssertionError('signed prediction did not use verified posterior')
        rows.append(row)
    eligible=[r for r in rows if r['source_transfer_if_valid_rmse_mm'] is not None]
    def mean(key, data=rows):return float(np.mean([r[key] for r in data])) if data else None
    return {'schema':'physica.v081.prospective_same_probe_benchmark',
            'origin':'SIMULATED_ONLY','seed':seed,'target_trials':trials,
            'independently_valid_source_experiments':3,
            'target_probe_experiments_per_adapted_method':1,
            'target_main_outcomes_hidden_at_forecast_time':True,
            'meta_authenticated_calls':0,'real_hardware_trials':0,
            'accepted_forecast_count':len(eligible),'refused_forecast_count':trials-len(eligible),
            'source_target_conflict_fallbacks':sum(r['posterior_policy_status']=='LOCAL_ONLY_SOURCE_CONFLICT' for r in rows),
            'mean_camera_rmse_mm':{'no_friction':mean('no_friction_rmse_mm'),
               'local_friction_equal_probe':mean('target_only_same_probe_rmse_mm'),
               'source_transfer_on_accepted_only':mean('source_transfer_if_valid_rmse_mm',eligible),
               'source_plus_target_probe_on_accepted_only':mean('source_plus_target_probe_rmse_mm',eligible),
               'actual_signed_posterior_on_accepted_only':mean('sealed_posterior_rmse_mm',eligible)},
            'rows':rows,
            'limitations':['Mechanism family cubic elasticity is fixed and source/body share that family',
               'Source has three prior interventions, local-only has one target probe: resource budgets are not identical globally',
               'Signed predictor is now hierarchical; source-only performance remains a non-sealed counterfactual baseline',
               'Approximate parameter sensitivity bands have no independent empirical coverage guarantee',
               'The target probe is low amplitude and may under-identify nonlinear dynamics',
               'The cross-machine variability prior was chosen during development and was not field calibrated',
               'Hierarchical model uses a predeclared cross-machine beta standard deviation of 0.02; this is a simulation assumption, not field calibration',
               'All forces, trajectories, calibrations and ground truth are simulated',
               'The withheld target truth is used only for post-seal evaluation',
               'Accepted-only error must be read together with prediction coverage',
               'No robustness to unspecified real-world sensing or changes of mechanism family established']}


def save(path,trials=12,seed=2026):
    obj=evaluate(trials,seed)
    out=Path(path);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(obj,indent=2)+'\n')
    return obj
