"""Loader for the ETH Zürich small-scale wind turbine blade benchmark (Ou, Tatsis, Dertimanis, Spiridonakos, Chatzi,
Struct. Control Health Monit. 28 (2021) e2660; data on Zenodo, PSD extract via github.com/josepfontm/EOVmitigation).

A 1.75 m, 5.0 kg composite blade of a Windspot 3.5 kW turbine, clamped at the root, shaken with white noise in a
climate chamber from -15 to +40 degC. Eight accelerometers. Power spectra 0-400 Hz at 0.78125 Hz resolution.
  Case R: healthy
  Cases A-C: added masses 1x, 2x, 3x 44 g (lumped masses representing ice)
  Cases D-L: cuts 4 mm deep at about 17%, 30% and 50% of the length, growing from 5 to 15 cm (cracks)
Two test sessions ("layouts") differ only in strain-gauge orientation; the accelerometers are the same.
"""
from __future__ import annotations

import glob
import os
import re
from dataclasses import dataclass

import numpy as np

DF = 0.78125
FREQ = np.arange(513) * DF
BLADE_MASS_KG = 5.0
BLADE_LENGTH_M = 1.75
TRUTH = {"R": ("healthy", 0)}
TRUTH.update({c: ("ice", 44 * (i + 1)) for i, c in enumerate("ABC")})
CRACKS = {"D": (5, 0, 0), "E": (5, 5, 0), "F": (5, 5, 5), "G": (10, 5, 5), "H": (10, 10, 5), "I": (10, 10, 10),
          "J": (15, 10, 10), "K": (15, 15, 10), "L": (15, 15, 15)}
TRUTH.update({c: ("crack", sum(v)) for c, v in CRACKS.items()})
_NAME = re.compile(r"Case_([A-Z])_\(([+-]\d+)\)_layout_(\d+)_white_noise_([\d.]+)\.npz")


@dataclass
class Test:
    case: str
    temp_c: int
    session: int
    run: str
    psd: np.ndarray  # (513 freqs, 8 accelerometers)

    @property
    def truth(self):
        return TRUTH[self.case]


def load(folder: str | None = None) -> list[Test]:
    folder = folder or os.environ["PHYSICA_BLADE_PSD"]
    out = []
    for fn in sorted(glob.glob(os.path.join(folder, "*.npz"))):
        m = _NAME.match(os.path.basename(fn))
        if not m:
            continue
        d = np.load(fn)["data"][:, :8]
        out.append(Test(m.group(1), int(m.group(2)), int(m.group(3)), m.group(4), d))
    if not out:
        raise FileNotFoundError(f"no blade PSD files in {folder} (unzip data/PSD_file.zip from the EOVmitigation repo)")
    return out
