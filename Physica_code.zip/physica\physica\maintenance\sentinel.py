"""Evidence-first run-to-failure condition monitoring with no unit/time leakage.

A *unit* is a complete physical run/machine. Train, calibration, and test units
must not overlap. The physics-conditioned residual model is a statistical
normal-behavior proxy, NOT a discovered physical differential equation.

A historical alert is NOT a prevented shutdown. This system never actuates.
"""
from __future__ import annotations
import csv
import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import numpy as np
from sklearn.linear_model import Ridge

class DataEvidenceError(ValueError):
    """Fail-closed error for unsupported or untrustworthy evidence."""

CONTEXT = ('speed_rpm','load','temperature_c','motor_current_a')
REQUIRED = ('machine_id','step','vibration_rms')

def sha256(path: str | Path) -> str:
    p=Path(path)
    h=hashlib.sha256()
    with p.open('rb') as f:
        for part in iter(lambda: f.read(1024*1024),b''):
            h.update(part)
    return h.hexdigest()

def load_csv(path: str | Path) -> tuple[dict[str,list[dict[str,float|str]]], str]:
    """Read already computed per-snapshot vibration measurements.

    This is NOT a waveform parser; see prepare_ims.py for raw snapshot handling.
    Reject unexpected values rather than silently imputing physical evidence.
    """
    p=Path(path)
    if not p.is_file() or p.stat().st_size > 64*1024*1024:
        raise DataEvidenceError('CSV missing or exceeds 64 MB; split into smaller batches')
    out:dict[str,list[dict[str,float|str]]]={}
    with p.open(newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f)
        if not reader.fieldnames or not set(REQUIRED).issubset(reader.fieldnames):
            raise DataEvidenceError(f'CSV needs columns: {REQUIRED}')
        allowed=set(REQUIRED)|set(CONTEXT)
        for i,row in enumerate(reader,2):
            if i>400_001: raise DataEvidenceError('Maximum 400000 snapshot rows')
            unit=str(row['machine_id'] or '').strip()
            if not unit or len(unit)>128:raise DataEvidenceError(f'Invalid machine_id at CSV line {i}')
            record={'machine_id':unit}
            for key in ('step','vibration_rms'):
                try: value=float(row[key])
                except (TypeError,ValueError):raise DataEvidenceError(f'Non-numeric {key} at line {i}') from None
                if not math.isfinite(value) or (key=='vibration_rms' and value<0):
                    raise DataEvidenceError(f'Invalid {key} at line {i}')
                record[key]=value
            for key in CONTEXT:
                if key in row and row[key] is not None and row[key].strip():
                    try: val=float(row[key])
                    except ValueError:raise DataEvidenceError(f'Non-numeric context {key} at line {i}') from None
                    if not math.isfinite(val):raise DataEvidenceError(f'Non-finite {key} at line {i}')
                    record[key]=val
            out.setdefault(unit,[]).append(record)
    if not out:raise DataEvidenceError('Empty CSV')
    for unit,records in out.items():
        times=np.array([r['step'] for r in records],dtype=float)
        if not np.all(np.diff(times)>0):
            raise DataEvidenceError(f'Timestamps for {unit} must be strictly increasing and grouped chronologically')
        if len(records)<12:raise DataEvidenceError(f'{unit}: need >=12 independently acquired snapshots')
    return out,sha256(p)

def _features(row: dict, keys:tuple[str,...]) -> np.ndarray:
    # log transformed positive context signals, bounded numerical features.
    x=[1.0]
    for key in keys:
        val=float(row[key])
        if key in ('speed_rpm','load','motor_current_a') and val<0:
            raise DataEvidenceError(f'{key} must be nonnegative')
        x.append(float(np.sign(val)*np.log1p(abs(val))))
    return np.array(x,dtype=float)

def _rank_threshold(scores:list[float],alpha:float) -> tuple[float,bool]:
    """Per-independent-unit normal maxima; finite-sample conformal if sufficient units.

    If n+1 rank is outside observations, threshold is infinity: abstain.
    """
    n=len(scores)
    if n<1 or not 0<alpha<1:raise DataEvidenceError('Invalid calibration group or alpha')
    k=int(math.ceil((n+1)*(1-alpha)))
    if k>n:return math.inf,False
    return sorted(scores)[k-1],True

def _stable_quantiles(xs:np.ndarray) -> tuple[float,float]:
    center=float(np.median(xs))
    scale=float(1.4826*np.median(abs(xs-center)))
    return center,max(scale,0.01)  # regularize nearly constant experimental readings

def _sequence_ewma(z:list[float],decay:float=.35) ->list[float]:
    result=[]; prev=0.
    for val in z:
        prev=decay*max(float(val),0.)+(1-decay)*prev
        result.append(float(prev))
    return result

def _first_persistent_alarm(scores:list[float],threshold:float, count:int=2) ->int|None:
    if not math.isfinite(threshold):return None
    streak=0
    for i,s in enumerate(scores):
        streak=streak+1 if s>threshold else 0
        if streak>=count:return i-count+1
    return None

def _steps_before_failure(rows:list[dict],alert_idx:int|None, failure_step:float|None):
    if alert_idx is None or failure_step is None:return None
    t=float(rows[alert_idx]['step'])
    if t>failure_step:return None
    return float(failure_step-t)

def _report_failure_truth(rows:list[dict], manifest:dict,unit:str)->dict:
    # Optional event truth is NEVER supplied during model construction or selection.
    failure=manifest.get('failure_steps',{}).get(unit)
    normal_end=manifest.get('verified_healthy_until',{}).get(unit)
    if failure is not None and not math.isfinite(float(failure)):
        raise DataEvidenceError('Invalid failure event time')
    if normal_end is not None and not math.isfinite(float(normal_end)):
        raise DataEvidenceError('Invalid verified-healthy interval')
    return {'known_run_end_or_failure_step':float(failure) if failure is not None else None,
            'verified_healthy_until':float(normal_end) if normal_end is not None else None,
            'ground_truth_is_optional_and_used_only_after_forecast':True}

def evaluate(manifest_path:str|Path, *,alpha:float=.10)->dict:
    """Unit-held-out retrospective evaluation of anomaly alarms.

    The two compared models are a scalar-vibration reference and a contextual
    normal-behavior residual. No actual downtime prevented or physical cause
    discovered is claimed. The contextual predictor may legitimately lose.
    """
    path=Path(manifest_path)
    if not path.is_file():raise DataEvidenceError('Manifest not found')
    manifest=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(manifest,dict):raise DataEvidenceError('Invalid manifest')
    if manifest.get('origin') not in ('real_recording','simulation'):
        raise DataEvidenceError('Specify origin as real_recording or simulation')
    if manifest.get('time_unit') not in ('snapshot','seconds','minutes','hours'):
        raise DataEvidenceError('Explicit time_unit required; never invent clock lead time')
    file=Path(manifest.get('measurements_csv',''))
    if not file.is_absolute():file=path.parent/file
    units,file_hash=load_csv(file)
    split=manifest.get('splits')
    if not isinstance(split,dict) or any(k not in split for k in ('train','calibration','test')):
        raise DataEvidenceError('Provide explicit disjoint train/calibration/test machine IDs')
    groups={key:split[key] for key in ('train','calibration','test')}
    if 'discovery' in split: groups['discovery']=split['discovery']
    if any(not isinstance(v,list) or not v or len(v)!=len(set(v)) for v in groups.values()):
        raise DataEvidenceError('Split groups must be non-empty unique machine IDs')
    if 'discovery' in groups and (not isinstance(groups['discovery'],list) or not groups['discovery'] or len(groups['discovery'])!=len(set(groups['discovery']))):
        raise DataEvidenceError('Discovery units must be independently grouped')
    ids=[unit for group in groups.values() for unit in group]
    if len(ids)!=len(set(ids)) or set(ids)!=set(units):
        raise DataEvidenceError('Machine IDs must be disjoint and all CSV units explicitly assigned')
    normal=manifest.get('healthy_reference_end',{})
    if not isinstance(normal,dict) or any(u not in normal for u in groups['train']+groups['calibration']):
        raise DataEvidenceError('All training and calibration units require justified healthy_reference_end')
    if not 0<alpha<1:raise DataEvidenceError('alpha must be in (0,1)')
    keys=tuple(k for k in CONTEXT if all(k in r for unit in ids for r in units[unit]))
    # Do not use unit identity or test outcomes as input features.
    train=[]
    for u in groups['train']:
        selected=[r for r in units[u] if r['step']<=float(normal[u])]
        if len(selected)<10:raise DataEvidenceError(f'{u} has <10 labeled healthy training snapshots')
        train.extend(selected)
    X=np.stack([_features(r,keys) for r in train]); y=np.log1p(np.array([r['vibration_rms'] for r in train]))
    model=Ridge(alpha=1.0,fit_intercept=False)
    model.fit(X,y)
    envelope={}
    for k in keys:
        vals=np.array([float(r[k]) for r in train])
        low,high=np.quantile(vals,[.005,.995])
        margin=max(.1*(high-low),1e-9)
        envelope[k]=[float(low-margin),float(high+margin)]
    residual=y-model.predict(X)
    center_r,scale_r=_stable_quantiles(residual)
    center_v,scale_v=_stable_quantiles(y)
    def score(records):
        x=np.stack([_features(r,keys) for r in records])
        yy=np.log1p(np.array([r['vibration_rms'] for r in records]))
        r=(yy-model.predict(x)-center_r)/scale_r
        raw=(yy-center_v)/scale_v
        return {'context_residual':_sequence_ewma(r.tolist()),
                'rms_only':_sequence_ewma(raw.tolist()),
                'physical_observation': [round(float(z),8) for z in yy],
                'predicted_log_rms': [round(float(z),8) for z in model.predict(x)]}
    # Separate calibration units, only verified normal periods. Rank by per-unit maxima.
    calibration={method:[] for method in ('context_residual','rms_only')}
    for u in groups['calibration']:
        selected=[r for r in units[u] if r['step']<=float(normal[u])]
        if len(selected)<10:raise DataEvidenceError(f'{u} has <10 normal calibration snapshots')
        sc=score(selected)
        for method in calibration:calibration[method].append(max(sc[method]))
    thresholds={}; formally_calibrated={}
    for method,scores in calibration.items():
        thresholds[method],formally_calibrated[method]=_rank_threshold(scores,alpha)
    # Optional source-discovery units are not used for fitting/calibration and
    # never counted as blind test units. Meta may inspect their past observed data.
    discovery_context=[]
    for unit in groups.get('discovery',[]):
        records=units[unit]
        curves=score(records)
        # Do not transmit ground-truth end-of-run or labels in a model proposal.
        series=[{'step':r['step'],'measured_vibration_rms':round(float(r['vibration_rms']),7),
                  'expected_log_rms':curves['predicted_log_rms'][i],
                  'residual_score':round(float(curves['context_residual'][i]),5),
                  'available_context':{k:r[k] for k in keys}}
                for i,r in enumerate(records)]
        discovery_context.append({'machine_id':unit,'training_only_chronological_sensor_observations':series,
            'not_validation_or_test_evidence':True,'raw_source_calibration_unverified':True})
    result=[]
    for unit in groups['test']:
        records=units[unit]
        curves=score(records)
        truth=_report_failure_truth(records,manifest,unit)
        # Do not extrapolate the normal model into unfamiliar loads/speeds.
        valid_context=[all(envelope[k][0] <= float(r[k]) <= envelope[k][1] for k in keys)
                       for r in records] if keys else [True]*len(records)
        coverage=sum(valid_context)/len(records) if keys else None
        in_envelope=bool(keys and coverage>=.8)
        alarms={}
        for method in ('context_residual','rms_only'):
            # Exclude all out-of-envelope samples and reset consecutive-alarm streaks.
            valid_scores=[value if valid else -math.inf for value,valid in zip(curves[method],valid_context)]
            # Vibration-only units can receive a calibrated RMS-only warning,
            # but cannot claim load-conditioned physical residual inference.
            is_eligible=in_envelope or (not keys and method=='rms_only')
            idx=(_first_persistent_alarm(valid_scores,thresholds[method]) if is_eligible else None)
            healthy_end=truth['verified_healthy_until']
            premature=(idx is not None and healthy_end is not None and records[idx]['step'] <= healthy_end)
            alarms[method]={
               'alarm_during_verified_healthy_period':premature if healthy_end is not None else None,
               'first_alarm_step':records[idx]['step'] if idx is not None else None,
               'snapshots_before_documented_run_end': _steps_before_failure(records,idx,truth['known_run_end_or_failure_step']),
               'alert_before_end':bool(idx is not None and (truth['known_run_end_or_failure_step'] is None or records[idx]['step'] <= truth['known_run_end_or_failure_step'])),
               'alert_is_not_verified_fault_diagnosis':True,
               'threshold':thresholds[method] if math.isfinite(thresholds[method]) else None,
            }
        # Return full curves ONLY for test units after threshold/model are fixed.
        result.append({'machine_id':unit,'snapshots':len(records),
            'operating_envelope_status':('WITHIN_TRAIN_RANGE' if in_envelope else
                'NO_OPERATING_CONTEXT_RMS_ONLY' if not keys else 'ABSTAIN_OUT_OF_ENVELOPE'),
            'fraction_in_training_envelope':coverage,
            'measurements':[
            {'step':r['step'], 'vibration_rms':r['vibration_rms'],
             'context_residual':round(float(curves['context_residual'][i]),5),
             'rms_only':round(float(curves['rms_only'][i]),5),
             'expected_log_rms':curves['predicted_log_rms'][i]}
            for i,r in enumerate(records)],
            'alarms':alarms,'event_truth':truth,
            'suggested_inquiry':_suggest_review_only(curves,records),
            'stages': ['FEEL','NOTICE_DISCREPANCY','INQUIRE','REQUEST_EVIDENCE','REVIEW_ONLY'],
            'mechanism_discovered':False,
            'downtime_prevented':False})
    summary={}
    for method in ('context_residual','rms_only'):
        valid=[u['alarms'][method]['snapshots_before_documented_run_end']
               for u in result if u['alarms'][method]['snapshots_before_documented_run_end'] is not None]
        false_healthy=[u['alarms'][method]['alarm_during_verified_healthy_period'] for u in result
                       if u['alarms'][method]['alarm_during_verified_healthy_period'] is not None]
        summary[method]={'units_with_pre_end_alert':len(valid),
                         'verified_healthy_units_with_premature_alert':sum(false_healthy),
                         'n_with_verified_healthy_period':len(false_healthy),
                         'n_test_units':len(result),
                         'median_snapshots_before_end':float(np.median(valid)) if valid else None}
    return {
       'schema':'physica.maintenance.sentinel.v030',
       'title':'Physica Sentinel: physical changes before downtime (retrospective warning evaluation)',
       'data_origin':manifest['origin'], 'provided_dataset_name':manifest.get('dataset_name','unspecified'),
       'raw_feature_csv_sha256':file_hash,'time_unit':manifest['time_unit'],
       'calibration_units':len(groups['calibration']), 'test_units':len(groups['test']),
       'alpha':alpha,'thresholds_finite':all(formally_calibrated.values()),
       'finite_sample_calibration_conditional_on_exchangeability':all(formally_calibrated.values()),
       'calibration_warning':('Independent normal calibration units are required; conditional on exchangeability and trustworthy healthy labels.'
            if all(formally_calibrated.values()) else 'INSUFFICIENT calibration units for finite conformal rank: no formal threshold, alerts abstain.'),
       'features_used':list(keys),'operating_envelope_training_only':envelope,
       'operating_envelope_required_for_alerts':True,
       'out_of_envelope_samples_ignored_not_interpreted_as_safe':True,
       'source_train_units':list(groups['train']),
       'muse_discovery_source_only':discovery_context,
       'blind_test_not_shared_with_meta':True,
       'calibration_machine_ids':list(groups['calibration']), 'heldout_test_machine_ids':list(groups['test']),
       'model':'Ridge-normal-behavior log-RMS residual + EWMA; not a discovered physical law',
       'baseline':'RMS-only robust reference + EWMA; fair independent-unit calibration',
       'summary':summary,'test_results':result,
       'semantic_constraints':{
          'physical_measured_vibration_rms_not_certified_calibration':True,
          'a_healthy_reference_label_must_be_defensible':True,
          'earlier_warning_is_not_prevented_downtime':True,
          'run_end_is_not_always_a_fault_time':True,
          'root_cause_not_established_from_vibration_alone':True,
          'no_automatic_machine_actuation':True,
          'meta_hypotheses_are_unverified_until_independent_testing':True,
       },'provenance':{'manifest_sha256':sha256(path), 'feature_csv_sha256':file_hash},
    }

def _suggest_review_only(curves,records):
    # A descriptive triage that requests discriminating evidence, not a root-cause label.
    a=max(curves['context_residual'])
    b=max(curves['rms_only'])
    if a>b+1:
        note='Operating-condition-adjusted vibration changed more than raw RMS; investigate sensor placement, load changes and fault history.'
    else:
        note='Vibration changes need independent load, speed and current evidence before assigning a mechanism.'
    return {'question':'Is abnormal vibration due to changing operating load, bearing wear, mounting, or sensor artifact?',
       'meta_question_context':'Treat all mechanical causes as unverified competing hypotheses.',
       'evidence_to_request':['synchronized motor current or torque','speed/load log',
                              'independent vibration channel or inspection by qualified personnel'],
       'description':note,'no_run_stop_command':True}

def write_report(manifest:str|Path,out:str|Path,alpha:float=.1)->dict:
    report=evaluate(manifest,alpha=alpha)
    p=Path(out);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
    return report
