"""Real-field prospective forecast/reveal protocol (research only; NEVER actuates).

A seal is a local integrity record, NOT a trusted independent timestamp.
Inputs must be independently calibrated and provenance reviewed by the operator.
Train and validation are distinct CSVs; the future test observations are not read
when committing the forecast. The plan is a specified control schedule, not a
recording of the eventual trajectory.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np

from physica.frontier.curious_discovery import (fit_neural_ensemble,neural_guided_symbolic_search,
    check_rows,predict_linear, known_acceleration, error)
from physica.frontier.mechanism_dsl import validate_meta_mechanism,feature

REQUIRED_COLUMNS=('x_m','v_m_s','u_m_s2','acc_m_s2')


def file_hash(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_csv(path:Path, *, require_time:bool=False) ->np.ndarray:
    if not path.is_file() or path.stat().st_size>20_000_000:raise ValueError('Missing or oversized sensor CSV')
    with path.open(encoding='utf-8-sig') as handle:
        first=handle.readline().strip().split(',')
    has_time=tuple(first)==('time_s',*REQUIRED_COLUMNS)
    if not has_time and (require_time or tuple(first)!=REQUIRED_COLUMNS):
        raise ValueError(f'Expected CSV columns {REQUIRED_COLUMNS}; reveal additionally requires time_s')
    try:data=np.loadtxt(path,delimiter=',',skiprows=1,ndmin=2)
    except (ValueError,TypeError) as exc:raise ValueError('Malformed sensor CSV') from exc
    if has_time:
        t=data[:,0]
        if not np.isfinite(t).all() or not np.all(np.diff(t)>0) or abs(float(t[0]))>1e-4:
            raise ValueError('Invalid or nonmonotonic elapsed sample timestamps')
        data=data[:,1:]
    return check_rows(data)


def load_manifest(manifest_file:Path)->tuple[dict,dict[str,list[Path]]]:
    manifest_file=manifest_file.resolve()
    payload=json.loads(manifest_file.read_text(encoding='utf8'))
    if not isinstance(payload,dict) or set(payload)!={'fixture_id','calibration_file','episodes'}:
        raise ValueError('Manifest must define fixture_id, calibration_file and episodes')
    if not isinstance(payload['fixture_id'],str) or not payload['fixture_id'].strip():
        raise ValueError('Fixture identity required')
    directory=manifest_file.parent
    def resolve_rel(s):
        if not isinstance(s,str) or not s or Path(s).is_absolute():raise ValueError('Use relative paths inside manifest folder')
        target=(directory/s).resolve()
        if not target.is_relative_to(directory):raise ValueError('Path traversal rejected')
        if not target.is_file() or target.stat().st_size>20_000_000:raise ValueError('Missing evidence file')
        return target
    calibration=resolve_rel(payload['calibration_file'])
    calib_data=json.loads(calibration.read_text(encoding='utf-8'))
    if not isinstance(calib_data,dict) or not all(calib_data.get(k) for k in ('method','operator','date_utc','units','instrument')):
        raise ValueError('Calibration provenance fields missing')
    parts=payload['episodes']
    if not isinstance(parts,dict) or set(parts)!={'train','validation'}:raise ValueError('Only train and validation evidence allowed at commitment')
    ep={}
    for name, minimum in [('train',2),('validation',1)]:
        if not isinstance(parts[name],list) or len(parts[name])<minimum:raise ValueError('Insufficient disjoint episodes')
        ep[name]=[resolve_rel(s) for s in parts[name]]
    all_paths=[p for values in ep.values() for p in values]
    if len(set(all_paths))!=len(all_paths):raise ValueError('Episode path reused across splits')
    all_hashes=[file_hash(p) for p in all_paths]
    if len(set(all_hashes))!=len(all_hashes):raise ValueError('Duplicate episode content across splits')
    payload['_calibration_hash']=file_hash(calibration)
    payload['_calibration_kind']='SYNTHETIC_DECLARED' if 'simulat' in str(calib_data['method']).lower() else 'USER_SUPPLIED_UNAUDITED'
    phys=calib_data.get('physics_baseline')
    if not isinstance(phys,dict) or set(phys)!={'stiffness_s2','damping_s1','control_gain'}:
        raise ValueError('Require independently determined physical baseline calibration coefficients')
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not np.isfinite(v) for v in phys.values()):
        raise ValueError('Invalid physical baseline calibration')
    if not (0<=phys['stiffness_s2']<=200 and 0<=phys['damping_s1']<=50 and 0.05<=phys['control_gain']<=4):
        raise ValueError('Calibrated baseline parameters outside supported range')
    payload['_physical_baseline']=phys
    return payload,ep


def physical_baseline(rows:np.ndarray,params:dict)->np.ndarray:
    rows=check_rows(rows,min_rows=1)
    x,v,u=rows[:,:3].T
    return -params['stiffness_s2']*x-params['damping_s1']*v+params['control_gain']*u


def to_reference_physics(rows:np.ndarray,params:dict)->np.ndarray:
    """Subtract the actually calibrated baseline, add an internal reference.

    Learners see only the unknown physical residual; rollout restores the real
    fixture baseline before the state is integrated.
    """
    rows=check_rows(rows).copy()
    rows[:,3]=rows[:,3]-physical_baseline(rows,params)+known_acceleration(*rows[:,:3].T)
    return rows


def read_plan(path:Path)->dict:
    p=json.loads(path.read_text(encoding='utf8'))
    if not isinstance(p,dict) or set(p)!={'fixture_id','dt_s','x0_m','v0_m_s','controls_m_s2'}:
        raise ValueError('Plan requires exact target fixture, initial state, dt and future control schedule')
    vals=(p['dt_s'],p['x0_m'],p['v0_m_s'])
    if any(isinstance(x,bool) or not isinstance(x,(int,float)) or not np.isfinite(x) for x in vals):
        raise ValueError('Non-finite physical plan')
    if not .005<=p['dt_s']<=.1 or abs(p['x0_m'])>2 or abs(p['v0_m_s'])>1:
        raise ValueError('Unsafe or unsupported starting conditions')
    us=p['controls_m_s2']
    if not isinstance(us,list) or not 18<=len(us)<=1500 or any(
        isinstance(u,bool) or not isinstance(u,(int,float)) or not np.isfinite(u) or abs(u)>1.2 for u in us):
        raise ValueError('Planned controls missing or outside permitted envelope')
    return p


def pure_ast_model(train:np.ndarray, expr:dict)->dict:
    from physica.frontier.curious_discovery import generic_basis,residual
    X=np.column_stack((np.ones(len(train)),generic_basis(train),feature(train,expr)))
    reg=np.eye(X.shape[1])*.04;reg[0,0]=0
    coef=np.linalg.solve(X.T@X+reg,X.T@residual(train))
    return {'kind':'ast','term':'meta_ast','params':None,'coefficients':coef.tolist(), 'expression':expr}


def predict_frozen(model:dict, rows:np.ndarray)->np.ndarray:
    if model['kind']=='symbolic':return predict_linear(model,rows)
    if model['kind']!='ast':raise ValueError('Unknown frozen model kind')
    from physica.frontier.curious_discovery import generic_basis
    rows=check_rows(rows,min_rows=1)
    X=np.column_stack((np.ones(len(rows)),generic_basis(rows),feature(rows,model['expression'])))
    return known_acceleration(*rows[:,:3].T)+X@np.array(model['coefficients'])


def prospective_rollout(plan:dict,model:dict,physical_params:dict)->list[dict]:
    x=float(plan['x0_m']);v=float(plan['v0_m_s']);dt=plan['dt_s']
    records=[]
    for i,u in enumerate(plan['controls_m_s2']):
        if abs(x)>5 or abs(v)>5:raise ValueError('Prediction escaped validated physical envelope; abstaining')
        row=np.array([[x,v,float(u),0.]])
        reference_acc=float(predict_frozen(model,row)[0])
        acc=float(reference_acc-known_acceleration(*row[0,:3])+physical_baseline(row,physical_params)[0])
        if not np.isfinite(acc) or abs(acc)>40:raise ValueError('Unstable numerical rollout; abstaining')
        records.append({'time_s':round(i*dt,6),'x_m':x,'v_m_s':v,'u_m_s2':u,'predicted_acc_m_s2':acc})
        v+=dt*acc;x+=dt*v
    return records


def commit(manifest_file:Path,plan_file:Path,out_file:Path,meta_proposal_file:Path|None=None)->dict:
    manifest,episodes=load_manifest(manifest_file)
    plan=read_plan(plan_file)
    if plan['fixture_id']!=manifest['fixture_id']:
        raise ValueError('Fixture identity mismatch')
    train=np.concatenate([to_reference_physics(load_csv(p),manifest['_physical_baseline']) for p in episodes['train']])
    val=np.concatenate([to_reference_physics(load_csv(p),manifest['_physical_baseline']) for p in episodes['validation']])
    ensemble=fit_neural_ensemble(train)
    discovered=neural_guided_symbolic_search(train,val,ensemble)
    base_model=discovered['chosen']['model']
    chosen=base_model
    checks={'source_blind_validation_rmse':discovered['chosen']['val_rmse']}
    meta_evidence='NO_META_USED'
    if meta_proposal_file:
        proposal=validate_meta_mechanism(json.loads(meta_proposal_file.read_text(encoding='utf8')))
        candidate=pure_ast_model(train,proposal['expression'])
        base_err=error(val[:,3],predict_frozen(base_model,val))
        cand_err=error(val[:,3],predict_frozen(candidate,val))
        checks.update({'meta_candidate_validation_rmse':cand_err,'meta_candidate_name':proposal['name']})
        if cand_err<base_err*.98:
            chosen=candidate
            meta_evidence='SELECTED_AST_UNVERIFIED_SOURCE_PROVENANCE'  # even if JSON says Meta, not authenticated receipt
        else:
            meta_evidence='META_STYLE_PROPOSAL_REJECTED_BY_VALIDATION'
    trajectory=prospective_rollout(plan,chosen,manifest['_physical_baseline'])
    inputs={'calibration_sha256':manifest['_calibration_hash'],
            'train_sha256':[file_hash(p) for p in episodes['train']],
            'validation_sha256':[file_hash(p) for p in episodes['validation']],
            'plan_sha256':file_hash(plan_file),'meta_proposal_sha256':file_hash(meta_proposal_file) if meta_proposal_file else None}
    payload={'version':'0.24','kind':'PROSPECTIVE_FORECAST_REQUIRES_FUTURE_REAL_MEASUREMENTS',
             'fixture_id':plan['fixture_id'],'model':chosen,'physical_baseline':manifest['_physical_baseline'],
             'plan':plan,'forecast':trajectory,
             'data_sha256':inputs,'model_selection_checks':checks,
             'meta_status':meta_evidence,'hardware_actuation':'PROHIBITED',
             'calibration_status':manifest['_calibration_kind'],
             'test_outcomes_seen_at_commit':False,
             'local_commit_time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
             'timestamp_limitation':'Local time and SHA256 do not prove independent chronology'}
    # Persist a digest of canonical content; no future sensor CSV accessed.
    canonical=json.dumps(payload,sort_keys=True,allow_nan=False,separators=(',',':'))
    payload['commit_sha256']=hashlib.sha256(canonical.encode()).hexdigest()
    out_file.parent.mkdir(parents=True,exist_ok=True)
    out_file.write_text(json.dumps(payload,indent=2,allow_nan=False),encoding='utf8')
    return {'status':'FORECAST_COMMITTED_BEFORE_TEST_REVEAL','out':str(out_file),
            'commit_sha256':payload['commit_sha256'],'model':chosen['term'],
            'meta_status':meta_evidence,'samples':len(trajectory)}


def reveal(commit_file:Path,observations_file:Path,out_file:Path)->dict:
    data=json.loads(commit_file.read_text(encoding='utf8'))
    h=data.pop('commit_sha256',None)
    canonical=json.dumps(data,sort_keys=True,allow_nan=False,separators=(',',':'))
    if h!=hashlib.sha256(canonical.encode()).hexdigest():raise ValueError('Committed evidence integrity mismatch')
    forecast=data['forecast'];plan=data['plan']
    observed=load_csv(observations_file,require_time=True)
    test_hash=file_hash(observations_file)
    if test_hash in data['data_sha256']['train_sha256'] or test_hash in data['data_sha256']['validation_sha256']:
        raise ValueError('Test recording reused from training or validation')
    recorded=np.loadtxt(observations_file,delimiter=',',skiprows=1,ndmin=2)
    expected_time=np.arange(len(recorded))*float(plan['dt_s'])
    if len(recorded)!=len(forecast) or np.max(np.abs(recorded[:,0]-expected_time))>plan['dt_s']*.25:
        raise ValueError('Physical observation timestamps do not match the predeclared sampling schedule')
    if len(observed)!=len(forecast):raise ValueError('Test sample count does not match committed plan')
    if any(abs(float(row[2])-float(u))>.03 for row,u in zip(observed,plan['controls_m_s2'])):
        raise ValueError('Actual actuator commands diverged from the committed experiment')
    if abs(observed[0,0]-plan['x0_m'])>.04 or abs(observed[0,1]-plan['v0_m_s'])>.04:
        raise ValueError('Starting state differs from precommitted trial')
    expected=np.array([[p['x_m'],p['v_m_s'],p['predicted_acc_m_s2']] for p in forecast])
    actual=observed[:,[0,1,3]]
    metrics={'x_rmse_m':error(actual[:,0],expected[:,0]),
             'v_rmse_m_s':error(actual[:,1],expected[:,1]),
             'acc_rmse_m_s2':error(actual[:,2],expected[:,2])}
    receipt={'status':'RETROSPECTIVE_SCORING_OF_COMMITTED_FORECAST','origin':('SYNTHETIC_REPLAY' if data['calibration_status']=='SYNTHETIC_DECLARED' else 'USER_SUPPLIED_RECORDING_NOT_INDEPENDENTLY_AUTHENTICATED'),
          'commit_sha256':h,'test_csv_sha256':file_hash(observations_file),
          'calibration_status':data['calibration_status'],'sample_count':len(observed),
          'metrics':metrics,'meta_status':data['meta_status'],'hardware_actuation':'NONE',
          'warning':'Precommitment timestamp integrity is local only. Independent externally timestamped evidence is stronger.'}
    out_file.parent.mkdir(parents=True,exist_ok=True)
    out_file.write_text(json.dumps(receipt,indent=2,allow_nan=False),encoding='utf8')
    return receipt


def main():
    p=argparse.ArgumentParser(description='Physica prospective real-field discovery, no hardware control')
    sub=p.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('commit');a.add_argument('--manifest',required=True);a.add_argument('--plan',required=True)
    a.add_argument('--meta-proposal');a.add_argument('--out',required=True)
    b=sub.add_parser('reveal');b.add_argument('--commit',required=True);b.add_argument('--observations',required=True);b.add_argument('--out',required=True)
    args=p.parse_args()
    if args.cmd=='commit':
        result=commit(Path(args.manifest),Path(args.plan),Path(args.out),Path(args.meta_proposal) if args.meta_proposal else None)
    else:result=reveal(Path(args.commit),Path(args.observations),Path(args.out))
    print(json.dumps(result,indent=2,allow_nan=False))

if __name__=='__main__':main()
