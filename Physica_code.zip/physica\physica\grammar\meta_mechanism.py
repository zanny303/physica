"""Meta context must change falsifiable candidate search, not sensor numbers.

Live Spark sees context, Wonder proposes causal mechanism basis from a fixed,
safe dictionary, mechanism_lab tests with independent raw sensor evidence.
Supports offline recorded replies but NEVER labels them authenticated Meta.
"""
from __future__ import annotations
import hashlib,json
from pathlib import Path
from .mechanism_lab import discover_residual_mechanism,FEATURE_UNITS


def ground_meta_mechanism(training,validation,physics,*,spark_reply,wonder_reply,
                          provenance='OFFLINE_UNTRUSTED_REPLY'):
    if not isinstance(spark_reply,dict) or not isinstance(wonder_reply,dict):
        raise ValueError('Meta outputs must be structured objects')
    context=str(spark_reply.get('context',''))[:1400]
    suggestions=wonder_reply.get('hypotheses',[])
    if not isinstance(suggestions,list):raise ValueError('invalid Muse hypothesis list')
    mechanisms=[]
    for item in suggestions:
        if isinstance(item,dict):
            name=item.get('mechanism_family',item.get('name'))
            if name in FEATURE_UNITS and name not in mechanisms:mechanisms.append(name)
    if not mechanisms:
        return {'status':'abstain_no_physical_candidate_from_Muse',
                'scene_context':context,'authenticated_meta':False,'hardware_actuation_allowed':False}
    result=discover_residual_mechanism(training,validation,**physics,candidates=mechanisms)
    result['candidate_provenance']=provenance
    result['model_generated_context_not_physical_evidence']=context
    result['meta_proposed_candidate_names']=mechanisms
    result['authenticated_meta']=provenance.startswith('LIVE_META_RESPONSES_')
    result['independent_validation_required']=True
    return result


def live_meta_mechanism(train,validation,physics,*,video_path,allowed_actions=(),allow_billing=False):
    """Actual billable Muse Spark/Wonder calls. No simulated Meta result or sensor values."""
    if not allow_billing:raise PermissionError('requires --allow-billed-meta')
    from physica.experience.meta_live import muse_scientist
    video=Path(video_path);digest=hashlib.sha256(video.read_bytes()).hexdigest()
    facts={'video_sha256':digest,'approved_mechanism_bases':list(FEATURE_UNITS),
           'physical_parameters_calibrated':physics,
           'sensor_channels':['externally_calibrated_displacement_m','velocity_m_s','acceleration_m_s2','force_n'],
           'warning':'candidate names only; no invented numeric values; do not alter measured evidence',
           'heldout_measurements_not_sent_to_Muse':True}
    # Only scene facts and training action metadata, NEVER validation outcomes.
    spark=muse_scientist(facts,list(allowed_actions),role='spark',video_path=str(video))
    wonder=muse_scientist({**facts,'spark_scene':spark['reply'],
                 'train_action_ids':[r.get('intervention_id') for r in train]},
                 list(allowed_actions),role='wonder',video_path=str(video))
    out=ground_meta_mechanism(train,validation,physics,spark_reply=spark['reply'],
           wonder_reply=wonder['reply'],provenance='LIVE_META_RESPONSES_'+spark['model_id']+'_'+wonder['model_id'])
    out['api_evidence']={'spark_model':spark['model_id'],'wonder_model':wonder['model_id'],
       'spark_request_sha256':spark['request_sha256'],'wonder_request_sha256':wonder['request_sha256'],
       'spark_response_sha256':hashlib.sha256(json.dumps(spark['reply'],sort_keys=True).encode()).hexdigest(),
       'wonder_response_sha256':hashlib.sha256(json.dumps(wonder['reply'],sort_keys=True).encode()).hexdigest()}
    return out
