"""Ice, crack, or just cold? Feeling a wind turbine blade through the seasons.

The question every cold-climate wind farm faces: the blade's natural frequencies dropped. Is it ice (stop or heat,
then restart as soon as it's gone), a crack (stop, inspect, repair before it becomes a $1M failure), or just the
weather (do nothing)? Temperature alone moves the blade's tones by several percent, as much as the damage does.

How Physica feels it, with no examples of ice or cracks:
  1. Learn the blade's normal self across temperatures from healthy operation only: one law per mode.
  2. Take the weather out: what's left is the change the weather can't explain.
  3. Ask for ONE deliberate experiment: tape a known mass on the blade. That teaches Physica what added mass feels
     like on THIS blade (mass lowers the modes that move most where it sits - for ice near the tip, the slow
     swinging mode). A crack is the other kind of change: it removes stiffness where the blade bends, so it pulls
     down the modes that bend hardest there and can leave the slow mode alone.
  4. Verdict for each group of tests (a few minutes of operation), safety first:
       weather only  - the change is within what temperature does to this blade                  -> no action
       structural    - a tone went UP: added mass can never do that, so it isn't ice             -> stop, inspect
       ice           - the slow swinging mode leads the drop, as the mass experiment showed      -> heat, pause
       crack         - the bending modes lead the drop, the slow mode barely moves               -> stop, inspect
       can't tell    - changed, but neither pattern clearly                                      -> stop, inspect
"""
from __future__ import annotations

import numpy as np
from scipy import stats

from physica.data.blade_eth import DF, FREQ

# Seed tones of the healthy blade at +20 degC, found by peak search on the healthy average (modes 2-8 of the
# benchmark; the ~17 Hz peak is not reliably present and is skipped).
SEED_HZ = (23.8, 29.4, 47.5, 118.7, 136.3, 209.7, 294.1)


def spectrum(psd: np.ndarray) -> np.ndarray:
    return np.log10(np.maximum(psd, 1e-12)).mean(1)


def peak_near(s: np.ndarray, f0: float, rel: float = 0.05) -> float:
    k = np.where((FREQ > f0 * (1 - rel)) & (FREQ < f0 * (1 + rel)))[0]
    if len(k) < 3:
        return np.nan
    i = int(k[np.argmax(s[k])])
    if i <= 0 or i >= len(s) - 1:
        return float(FREQ[i])
    a, b, c = s[i - 1], s[i], s[i + 1]
    d = 0.5 * (a - c) / (a - 2 * b + c + 1e-12)
    return float((i + np.clip(d, -0.5, 0.5)) * DF)


class BladeSense:
    def __init__(self, seed_hz=SEED_HZ, degree: int = 2):
        self.seed = np.asarray(seed_hz, float)
        self.degree = degree
        self.coef = None
        self.cov = None
        self.mass_fingerprint = None  # per gram, in log-frequency units

    # ---- 1. the blade's normal self across temperatures (healthy operation only) ----
    def tones(self, psd, temp_c) -> np.ndarray:
        guess = self.law(temp_c) if self.coef is not None else self.seed
        s = spectrum(psd)
        return np.array([peak_near(s, g, 0.05) for g in guess])

    def law(self, temp_c) -> np.ndarray:
        return np.exp(np.polyval(self.coef, temp_c)) if self.coef.ndim == 1 else \
            np.exp(np.array([np.polyval(c, temp_c) for c in self.coef]))

    def learn_normal(self, healthy, temps, rounds: int = 2):
        """healthy: list of psd arrays from normal operation; temps: their temperatures (degC)."""
        temps = np.asarray(temps, float)
        # bootstrap the law from the seed by tracking outward from +20 degC
        F = np.array([self._track_from_seed(p, t) for p, t in zip(healthy, temps)])
        for _ in range(rounds):
            ok = np.isfinite(F).all(1)
            self.coef = np.array([np.polyfit(temps[ok], np.log(F[ok, k]), self.degree) for k in range(F.shape[1])])
            F = np.array([self.tones(p, t) for p, t in zip(healthy, temps)])
        return F

    def _track_from_seed(self, psd, t):
        s = spectrum(psd)
        g = self.seed * (1 - 0.0011 * (t - 20))  # a generic composite softening guess to start from
        return np.array([peak_near(s, x, 0.06) for x in g])

    def residual(self, psd, temp_c) -> np.ndarray:
        """Log change of each tone that the weather can't explain (x100 = percent)."""
        return np.log(self.tones(psd, temp_c) / self.law(temp_c))

    def learn_scatter(self, healthy, temps):
        R = np.array([self.residual(p, t) for p, t in zip(healthy, temps)])
        R = R[np.isfinite(R).all(1)]
        self.cov = np.cov(R.T) + np.eye(R.shape[1]) * 1e-8
        self.n_scatter = len(R)
        return R

    def learn_scatter_groups(self, groups):
        """Noise of a group verdict (a few minutes of operation): covariance of healthy GROUP means, which also
        carries what the temperature law misses from day to day."""
        G = np.array([self._group_residual(g) for g in groups])
        G = G[np.isfinite(G).all(1)]
        self.cov = np.cov(G.T) + np.eye(G.shape[1]) * 1e-10
        self.sd = np.sqrt(np.diag(self.cov))
        self.n_groups = len(G)
        return G

    def _group_residual(self, group):
        R = np.array([self.residual(p, t) for p, t in group])
        R = R[np.isfinite(R).all(1)]
        return R.mean(0) if len(R) else np.full(len(self.seed), np.nan)

    # ---- 3. one deliberate experiment: a known mass ----
    def learn_mass(self, groups, grams: float):
        """Tape a known mass on the blade for a while. Teaches what added mass feels like on THIS blade."""
        G = np.array([self._group_residual(g) for g in groups])
        G = G[np.isfinite(G).all(1)]
        self.mass_fingerprint = G.mean(0) / grams
        self.mass_grams_used = grams
        fp = self.mass_fingerprint
        self.mass_lead = float(fp[0] / fp[3:].mean())  # how much the slow mode leads the bending modes for mass
        return fp

    # ---- 4. verdict for a group of tests ----
    def judge(self, group, alpha_change: float = 1e-3, z_up: float = 3.0, lead_ice: float = 1.4,
              lead_crack: float = 0.7) -> dict:
        """group: [(psd, temp_c), ...] from a few minutes of operation."""
        r = self._group_residual(group)
        if not np.isfinite(r).all():
            return {"verdict": "can't tell", "say": "Some tones were not found; measure again.", "action": "measure again"}
        Si = np.linalg.inv(self.cov)
        k = len(r)
        d = float(r @ Si @ r)
        thr = float(stats.chi2.ppf(1 - alpha_change, k))
        z = r / self.sd
        lead = float(r[0] / min(r[3:].mean(), -1e-6))
        fp = self.mass_fingerprint
        grams = float(r[0] / fp[0]) if fp is not None and fp[0] < 0 else None
        out = {"residual_pct": (100 * r).round(3).tolist(), "z": z.round(2).tolist(), "change_score": round(d, 2),
               "change_threshold": round(thr, 2), "slow_mode_lead": round(lead, 2),
               "temp_c": float(np.mean([t for _, t in group])), "n_tests": len(group)}
        if d <= thr:
            out.update(verdict="weather only", action="none",
                       say="Only the weather: every tone sits where this blade's temperature law puts it. No action.")
        elif z.max() > z_up:
            out.update(verdict="structural", action="stop and inspect",
                       say=(f"A tone went UP ({100 * r[int(np.argmax(z))]:+.1f}% on mode {int(np.argmax(z)) + 2}). Added "
                            "mass can only lower tones, so this is not ice: the blade's structure has changed enough to "
                            "rearrange its modes. Stop and inspect."))
        elif lead >= lead_ice:
            out.update(verdict="ice", action="heat blades and pause", ice_grams=round(grams, 0) if grams else None,
                       say=(f"Ice-like: the slow swinging mode dropped {lead:.1f}x more than the bending modes, as added "
                            f"mass on the outer blade does" + (f" (about {grams:.0f} g)." if grams else ".")))
        elif lead <= lead_crack:
            out.update(verdict="crack", action="stop and inspect",
                       say=(f"Stiffness loss (crack-like): the bending modes dropped {1 / max(lead, 1e-3):.1f}x more than the "
                            "slow mode, as a loss of stiffness inboard does. Not ice, not weather. Stop and inspect."))
        else:
            out.update(verdict="can't tell", action="stop and inspect",
                       say="Changed, but neither the ice pattern nor the crack pattern clearly: when unsure, look.")
        return out
