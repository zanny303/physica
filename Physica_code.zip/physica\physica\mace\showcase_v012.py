"""Standalone interactive *simulation-only* discovery evidence viewer."""
from __future__ import annotations
import json
from pathlib import Path
from .mechanisms import BASE, fit, predict

def render(path, report, train, test):
    path=Path(path)
    base=fit(train,BASE)
    series={'truth':[float(r['acceleration']) for r in test],
            'base':[float(v) for v in predict(test,base)],
            'candidate':[float(v) for v in predict(test,report['model'])]}
    payload=json.dumps({'metrics':{k:report[k] for k in ('status','selected','base_validation_rmse',
         'selected_validation_rmse','base_lockbox_rmse','candidate_lockbox_rmse','candidate_count','stronger_ridge_baseline')},
         'series':series},allow_nan=False)
    page='''<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Physica · Discovery Evidence</title><style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#071020;color:#eef8ff;font:15px/1.5 system-ui,Segoe UI,sans-serif}main{max-width:1050px;margin:auto;padding:35px 25px}.ey{font-size:11px;font-weight:800;letter-spacing:.2em;color:#83e9c9}.hero{border:1px solid #2c6470;background:radial-gradient(ellipse at 95% 0,#16484d,transparent 55%),#102237;padding:28px;border-radius:22px}h1{font-size:clamp(30px,6vw,59px);letter-spacing:-.05em;line-height:1.1;margin:14px 0}h2{font-size:21px}.dim{color:#aebfcc}.warning{border:1px solid #8f6942;background:#271e15;color:#f4d5a5;border-radius:10px;padding:11px 15px;margin:22px 0}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:15px;margin:20px 0}.stat{background:#12253a;border:1px solid #2a4058;border-radius:15px;padding:19px}.stat strong{font-size:29px;color:#83e9c9;display:block}.stat small{color:#aab9c8}canvas{display:block;width:100%;height:330px;background:#0b1929;border:1px solid #254352;border-radius:14px}.legend{display:flex;gap:22px;flex-wrap:wrap;margin:15px 0 24px}.legend span{display:flex;align-items:center;gap:7px}.dot{height:10px;width:10px;border-radius:100%}.foot{background:#102034;border:1px solid #2d4357;border-radius:14px;padding:18px;margin:18px 0;color:#a8bfcb}button{background:#157d73;border:0;color:white;border-radius:8px;padding:12px 20px;cursor:pointer;font-size:15px}input{width:100%}a{color:#83e9c9}</style></head><body><main><div class="hero"><div class="ey">PHYSICA · MACE RESEARCH OBSERVATORY</div><h1>When physics surprises us,<br><span style="color:#83e9c9">test a new explanation.</span></h1><p class="dim">The mechanism library omits a temperature-dependent interaction. The source machine performs controlled experiments; Physica searches measurable candidates, validates them on disjoint episodes, and freezes a model before the lockbox is scored.</p></div>
<div class="warning"><b>SIMULATED DATA ONLY.</b> The underlying physical law is coded into this generator. This proves execution of an evidence-gated search, not spontaneous discovery or a real-world breakthrough.</div>
<div class="stats"><div class="stat"><small>Baseline lockbox error</small><strong id="base">—</strong><small>Acceleration RMSE</small></div><div class="stat"><small>Proposed mechanism error</small><strong id="candidate">—</strong><small>Acceleration RMSE</small></div><div class="stat"><small>All-feature ridge baseline</small><strong id="ridge">—</strong><small>Same training/validation data</small></div><div class="stat"><small>Candidate count</small><strong id="count">—</strong><small>Restricted grammar</small></div><div class="stat"><small>Evidence status</small><strong style="font-size:21px" id="status">—</strong><small>Independent simulation episodes</small></div></div>
<h2>Held-out physical response</h2><p class="dim">The test outcome appears here only in the final saved evaluation. Drag the slider to reveal more of the 120-sample test. Source training and model selection do not use these outcomes.</p>
<canvas width="1050" height="330" id="plot" role="img" aria-label="Simulated held-out acceleration: measured response, baseline and validated mechanism"></canvas>
<div class="legend"><span><i class="dot" style="background:#eaf7ff"></i>Simulated truth</span><span><i class="dot" style="background:#ffcb7f"></i>Known-mechanism baseline</span><span><i class="dot" style="background:#82f2cb"></i>Newly selected candidate</span></div>
<label>Reveal lockbox trajectory <b id="progress">100%</b><input type="range" id="slider" min="15" max="100" value="100"></label>
<div class="foot"><b>What was discovered?</b><p id="term"></p><p>Auditable method: predeclared grammar → train numeric coefficients → replicate validation improvement across episodes → freeze candidate → score untouched lockbox. Equal measurement budget for both models. This is not open-ended law invention.</p><a href="mace_unknown_discovery.json">Open full numerical results</a></div>
<button onclick="document.getElementById('slider').value=15;document.getElementById('slider').dispatchEvent(new Event('input'))">Replay held-out reveal</button></main><script>
const DATA=__DATA__;
const $=id=>document.getElementById(id);const m=DATA.metrics;
$('base').textContent=m.base_lockbox_rmse.toFixed(4);$('candidate').textContent=m.candidate_lockbox_rmse.toFixed(4);$('count').textContent=m.candidate_count;$('ridge').textContent=m.stronger_ridge_baseline.lockbox_rmse.toFixed(4);$('status').textContent=m.status==='CANDIDATE_VALIDATED'?'VALIDATED':'ABSTAIN';$('term').textContent=m.selected?m.selected.factors.map(x=>x.field+' ('+x.transform+')').join(' × '):'No candidate cleared the independent validation gates.';
function draw(){let pct=Number($('slider').value);$('progress').textContent=pct+'%';let ctx=$('plot').getContext('2d'),w=1050,h=330;ctx.clearRect(0,0,w,h);ctx.fillStyle='#0b1929';ctx.fillRect(0,0,w,h);
let all=Object.values(DATA.series).flat(),min=Math.min(...all),max=Math.max(...all),d=max-min||1;
ctx.strokeStyle='#243e52';ctx.lineWidth=1;for(let i=0;i<=5;i++){ctx.beginPath();ctx.moveTo(0,10+i*300/5);ctx.lineTo(w,10+i*300/5);ctx.stroke()}
let n=Math.max(2,Math.ceil(DATA.series.truth.length*pct/100));[['truth','#eaf7ff'],['base','#ffcb7f'],['candidate','#82f2cb']].forEach(([k,c])=>{ctx.beginPath();ctx.strokeStyle=c;ctx.lineWidth=k==='truth'?1.8:2.5;DATA.series[k].slice(0,n).forEach((v,i)=>{let x=i/(DATA.series[k].length-1)*w,y=315-(v-min)/d*300;if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y)});ctx.stroke()})};$('slider').oninput=draw;draw();
</script></body></html>'''
    path.write_text(page.replace('__DATA__',payload.replace('</','<\\/')),encoding='utf8')
    return str(path)
