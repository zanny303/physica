"""v0.12 restricted *open-candidate* mechanism search.

This expands measured-feature combinations beyond the fixed v0.11 candidates,
selects on source validation episodes, and opens the source lockbox only after
freezing selection. It is sparse feature engineering, NOT arbitrary law discovery.
"""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from .mechanisms import BASE, FIELDS, validate_term, design, fit, score, predict
from .field import import_manifest

# Only measured fields may be candidates. The model NEVER fabricates a sensor.
GRAMMAR = {
    'x': ['square', 'cube'],
    'v': ['abs', 'square', 'signed_square', 'tanh'],
    'temperature_delta': ['linear', 'square'],
    'current': ['linear', 'square'],
    'magnetic': ['linear'],
    'ultrasound': ['linear'],
}

def generate(rows, *, max_candidates=100):
    """Deterministic pre-registered grammar, no target outcomes in search."""
    if not rows: raise ValueError('training episode required')
    fields = set.intersection(*(set(r) for r in rows))
    parts = [(k, t) for k, ts in GRAMMAR.items() if k in fields for t in ts]
    result = []
    def add(factors):
        ident = 'candidate_' + '_'.join(f['field']+'_'+f['transform'] for f in factors)
        term = validate_term({'id': ident[:41], 'factors': factors})
        if term not in result:
            result.append(term)
    for k, t in parts:
        add([{'field': k, 'transform': t}])
    # Interactions with physically meaningful motion; no cubic-by-cubic blowup.
    for k,t in parts:
        if k in ('x','v'): continue
        for moving, tf in (('v','linear'), ('v','tanh'), ('x','linear')):
            if moving in fields:
                add([{'field': k,'transform':t},{'field':moving,'transform':tf}])
    return result[:max_candidates]

def _episodes(rows):
    result={}
    for r in rows: result.setdefault(r['episode_id'], []).append(r)
    return result

def residual_diagnostics(rows, model):
    """Held-out validation residual structure; never a proof of true causality.

    Lag correlation is calculated *within* episodes only, avoiding artificial
    correlations across concatenated episode boundaries. Evidence can also be
    affected by correlated sensor errors or numerical differentiation.
    """
    report=[]
    for episode, subset in _episodes(rows).items():
        residual=np.asarray([r['acceleration'] for r in subset],float)-predict(subset,model)
        rmse=float(np.sqrt(np.mean(residual**2)))
        if len(residual)<12 or np.std(residual[:-1])<1e-12 or np.std(residual[1:])<1e-12:
            lag_corr=0.0 if rmse<1e-9 else 1.0
        else:
            lag_corr=float(np.corrcoef(residual[:-1],residual[1:])[0,1])
        if not np.isfinite(lag_corr):
            lag_corr=1.0
        report.append({'episode_id':episode,'n':len(residual),'rmse':rmse,
                       'lag1_residual_correlation':lag_corr,
                       'residual_mean':float(np.mean(residual))})
    return report


def discover(train, validation, test, *, min_gain=.12, max_candidates=100,
             measurement_noise_sd=None, max_residual_autocorr=.35, open_lockbox=True):
    """Freeze model selection on training+at least TWO validation interventions.

    A candidate may fit well without identifying the true cause. Withheld
    future TEST trajectories are touched only after selection/refusal.
    """
    for name,rows in (('training',train),('validation',validation),('test',test)):
        if not rows:raise ValueError(name+' episode required')
    ids=[{r['episode_id'] for r in group} for group in (train,validation,test)]
    if (ids[0]&ids[1]) or (ids[0]&ids[2]) or (ids[1]&ids[2]):
        raise ValueError('episode leakage is not permitted')
    if len(ids[1])<2:
        raise ValueError('at least two independent validation episodes required')
    if len({r['body_id'] for r in train+validation+test})!=1:
        raise ValueError('evaluate source physical mechanism before cross-body transport')
    if not 0<min_gain<1 or not 0<max_residual_autocorr<1:
        raise ValueError('invalid discovery thresholds')
    if measurement_noise_sd is not None and (not np.isfinite(measurement_noise_sd) or measurement_noise_sd<=0):
        raise ValueError('invalid independently calibrated noise SD')
    base=fit(train,BASE)
    base_val=score(validation,base)
    if not np.isfinite(base_val):raise ValueError('invalid baseline')
    tested=[];champion=None;champion_val=base_val
    # Only use channels measured on every training and validation row. Missing
    # channels must not be silently filled or "virtually sensed".
    available=set.intersection(*(set(r) for r in train+validation))
    source=[t for t in generate(train,max_candidates=max_candidates)
            if all(f['field'] in available for f in t['factors'])]
    for term in source:
        try:
            mat=design(train,BASE+[term])
            if np.linalg.matrix_rank(mat)<mat.shape[1]:continue
            X=mat[:,:-1];extra=mat[:,-1]
            proj=np.linalg.lstsq(X,extra,rcond=None)[0]
            if np.linalg.norm(extra-X@proj)/(np.linalg.norm(extra)+1e-10)<.025:continue
            model=fit(train,BASE+[term]);validation_rmse=score(validation,model)
            episode_gains=[]
            for subrows in _episodes(validation).values():
                b=score(subrows,base);v=score(subrows,model)
                episode_gains.append((b-v)/max(b,1e-10))
            gain=(base_val-validation_rmse)/max(base_val,1e-10)
            good_episodes=bool(all(z>=0 for z in episode_gains))
            pass_gate=bool(gain>=min_gain and good_episodes and validation_rmse<champion_val)
            tested.append({'term':term['id'],'gain':float(gain),'validation_rmse':float(validation_rmse),
                           'all_validation_episodes_improved':good_episodes})
            if pass_gate:champion=(term,model);champion_val=validation_rmse
        except (ValueError,np.linalg.LinAlgError,OverflowError,FloatingPointError):continue
    provisional_model=champion[1] if champion else base
    diagnostics=residual_diagnostics(validation,provisional_model)
    correlated=any(v['rmse']>max(3e-4, 2.0*(measurement_noise_sd or 0.0)) and abs(v['lag1_residual_correlation'])>max_residual_autocorr for v in diagnostics)
    noisy=(measurement_noise_sd is not None and
           any(v['rmse']>4.0*measurement_noise_sd for v in diagnostics))
    # Surrogate explanations are not labelled discoveries if residuals still
    # contain unexplained temporal structure or excess signal beyond known noise.
    unknown=bool(correlated or noisy)
    selected=champion[0] if champion and not unknown else None
    frozen_model=provisional_model if selected else base
    if unknown:
        status='UNKNOWN_OR_MISSPECIFIED_MECHANISM_SUSPECTED'
    elif selected:
        status='CANDIDATE_PREDICTIVE_VALIDATION_ONLY'
    else:
        status='ABSTAIN_NO_REPLICATED_VALIDATION'
    baseline_test=score(test,base) if open_lockbox else None
    candidate_test=score(test,frozen_model) if open_lockbox else None
    surrogate_test=score(test,provisional_model) if open_lockbox and unknown and champion else None
    # Stronger same-dictionary comparator, tuned on validation before opening
    # lockbox. Never claim the fixed grammar is universal law discovery.
    ridge_choices=[]
    for reg in (1e-6,1e-5,1e-4,5e-4,1e-3,1e-2,.1,1.):
        try:
            model=fit(train,BASE+source,reg=reg)
            ridge_choices.append((score(validation,model),reg,model))
        except (ValueError,np.linalg.LinAlgError):continue
    if ridge_choices:
        best_ridge=min(ridge_choices,key=lambda v:v[0])
        ridge_report={'regularization':best_ridge[1],
                      'validation_rmse':float(best_ridge[0]),
                      'lockbox_rmse':score(test,best_ridge[2]) if open_lockbox else None,
                      'method':'same-dictionary ridge regression; validation-selected regularization'}
    else:ridge_report={'status':'ABSTAIN_ALL_FEATURE_MODELS_UNSTABLE'}
    return {'schema':'physica.discovery.v0121','selected':selected,
            'provisional_surrogate':champion[0] if unknown and champion else None,
            'status':status, 'requires_new_experiment':unknown,
            'base_validation_rmse':float(base_val),
            'selected_validation_rmse':float(champion_val if selected else base_val),
            'provisional_validation_rmse':float(champion_val),
            'base_lockbox_rmse':float(baseline_test) if open_lockbox else None,
            'candidate_lockbox_rmse':float(candidate_test) if open_lockbox else None,
            'surrogate_lockbox_rmse_EXPLORATORY_ONLY':surrogate_test,
            'candidate_count':len(source),'tested_count':len(tested),
            'stronger_ridge_baseline':ridge_report,
            'hypothesis_search_precedes_lockbox':True,
            'lockbox_not_used_in_selection':True, 'lockbox_opened_after_model_selection':bool(open_lockbox),
            'candidate_terms':tested,'validation_residual_diagnostics':diagnostics,
            'measurement_noise_sd_independently_supplied':measurement_noise_sd,
            'model':frozen_model,
            'limitations':'Predictive structure only; wrong physics, correlated sensor noise, and residual aliasing can be mistaken. Real physical causality requires independent prospective interventions.'}

def evaluate_manifest(path):
    groups,provenance=import_manifest(path)
    report=discover(groups['train'],groups['validation'],groups['test'])
    report['source_provenance']=provenance
    return report

def synthetic_demo(out,seed=2026):
    from .simulation import roll
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    body={'id':'A_sound_touch','thermal':.82}
    train=roll(body,seed,'source_train',n=140)
    val=roll(body,seed+1,'source_validation',n=120)
    # second independently generated validation episode
    val+=roll(body,seed+2,'source_validation_2',n=120)
    test=roll(body,seed+3,'source_LOCKBOX_test',n=120)
    report=discover(train,val,test)
    report['origin']='SIMULATION_ONLY'
    report['meta_calls']=0
    from .showcase_v012 import render
    render(out.with_suffix('.html'),report,train,test)
    out.write_text(json.dumps(report,indent=2,allow_nan=False,ensure_ascii=False)+'\n',encoding='utf-8')
    return report
