# Physica v0.8.5 — Causal Experience Memory Research Prototype

- Preserves all v0.8.4 Studio, Lab, Discover, Lens, Feel Check, CIRTE, CRATE and Meta adapters.
- Adds `physica/causal_memory/` with shared calibrated 2-D physical state, action-conditioned acceleration model, sensory decoding, candidate mechanism selection, prospective simulation and conservative cross-machine transfer.
- Studio has a **Causal Experience Memory** research task.
- Adds a reproducible benchmark reporting matched target-data budgets and unfavorable comparisons, not just wins.
- Does not claim universal latent sensory embeddings, unconstrained mechanism invention, or authenticated Meta inference.
- Raw vibration/current Paderborn data are passive observations, not randomized interventions. Existing `remote_bench` real-data trainer retained.
- Meta Muse Spark/Wonder support reasoning and coding via the pre-existing adapters; no API calls executed in this release.
- Network-only resources could not be retrieved into this environment, so this release contains **no newly trained real dataset model**. Explicit optional real-data instructions remain in `docs/V083_CLOUD_META_TRAINING_AND_THREE_DEMOS.md`.
