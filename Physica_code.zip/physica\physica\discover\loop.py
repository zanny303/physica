"""The Physica Loop on real data: propose rival theories -> prove on held-out data -> decide the next experiment.

For the drone: 'How does a healthy arm's vibration depend on its rotor speed?' Muse Spark proposes rival
theories as code (offline stand-in in MOCK mode), each is fitted on one split, chosen on another and judged
only on held-out windows. Then Physica asks where the surviving theories still disagree enough to matter:
that is the next experiment it requests (or it refuses a test that can't change the answer).
"""
from __future__ import annotations

import numpy as np

from physica.discover import probe, theories
from physica.llm import meta_client as mc


def discover_selfmodel(op: np.ndarray, lvl: np.ndarray, unit_names: list[str], calib_idx: np.ndarray,
                       heldout_idx: np.ndarray, threshold_z: float, sigma: np.ndarray,
                       grid=(60.0, 260.0), experiment_hint: str = "", survive_ratio: float = 1.5) -> dict:
    n_fit = int(round(len(calib_idx) * 0.7))
    out = {"spark_mode": "offline stand-in (MOCK)" if mc.is_mock() else "Muse Spark", "units": {}}
    summary = {"x": "dominant rotor peak frequency per 5 s window (Hz)", "y": "log10 vibration power near the peak",
               "x_range_seen": [float(op[calib_idx].min()), float(op[calib_idx].max())], "n_windows": int(len(calib_idx))}
    th = theories.propose(summary)
    out["theories_proposed"] = [{"name": t.get("name"), "code": t.get("code")} for t in th]
    for k, u in enumerate(unit_names):
        idx = np.concatenate([calib_idx, heldout_idx])
        x, y = op[idx, k], lvl[idx, k]
        n = len(idx)
        splits = {s: np.zeros(n, bool) for s in ("fit", "select", "prove")}
        splits["fit"][:n_fit] = True
        splits["select"][n_fit:len(calib_idx)] = True
        splits["prove"][len(calib_idx):] = True
        res = theories.prove(th, x, y, splits)
        # survivors: theories still close to the winner on held-out data; the rest are falsified
        ran = [t for t in res["theories"] if t.get("status") == "ran"]
        best = min(t["rmse_prove"] for t in ran)
        ok = [t for t in ran if t["rmse_prove"] <= survive_ratio * best]
        lo, hi = float(x[splits["fit"] | splits["select"]].min()), float(x[splits["fit"] | splits["select"]].max())
        cand = np.linspace(grid[0], grid[1], 41)
        inside = (cand >= lo) & (cand <= hi)
        scale = float(sigma[k] * threshold_z)
        ct = None
        if len(ok) == 1:
            nxt = ({"action": "refuse", "text": "No more tests needed: only one theory survived and it is proven."}
                   if res["verdict"] == "proven" else
                   {"action": "more data", "text": "One theory survived, but its error bars are not proven yet "
                                                  "(too few windows to learn them). Needed: more healthy windows."})
        else:
            preds = {}
            for t in ok:
                src = next(s_ for s_ in th if s_.get("name") == t["name"])
                f = theories.fit(src, x, y, splits["fit"] | splits["select"])
                preds[t["name"]] = _eval(src, f["params"], cand)
            nxt = probe.next_test({n_: p[inside] for n_, p in preds.items()}, cand[inside], scale)
            if nxt["action"] == "test":
                nxt["text"] = (f"{len(ok)} theories survived and still disagree most near {nxt['candidate']:.0f} Hz. "
                               f"One more healthy window there separates them.")
            ct = probe.cant_tell({n_: p[inside] for n_, p in preds.items()}, {n_: p[~inside] for n_, p in preds.items()},
                                 scale, experiment_hint or f"fly a few windows with rotor peaks outside {lo:.0f}-{hi:.0f} Hz")
        for t in res["theories"]:
            if t.get("status") == "ran" and t["outcome"] != "winner":
                t["outcome"] = "survives (close to the winner)" if t in ok else "falsified (worse on held-out)"
        res["survivors"] = [t["name"] for t in ok]
        out["units"][u] = {"proof": res, "proven_range_hz": [lo, hi], "next_step_inside_range": nxt, "outside_range": ct}
    wins = [v["proof"].get("winner") for v in out["units"].values()]
    out["summary"] = {"winners": dict(zip(unit_names, wins)),
                      "proven_units": [u for u, v in out["units"].items() if v["proof"]["verdict"] == "proven"]}
    return out


def _eval(src: dict, params: dict, x: np.ndarray) -> np.ndarray:
    """Evaluate a fitted theory on new x inside the sandbox (params passed as a small array)."""
    from physica.discover import sandbox

    names = list(params)
    wrapper = src["code"] + "\n\ndef _call(p, x):\n    params = {" + ", ".join(
        f"'{n}': p[{i}]" for i, n in enumerate(names)) + "}\n    return simulate(params, x)\n"
    return sandbox.run(wrapper, "_call", {"p": np.array([params[n] for n in names]), "x": x})["out"]
