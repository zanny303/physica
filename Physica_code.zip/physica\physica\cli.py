"""Command line:  physica feel padre:0100 | ask | serve [--replay] | library | commit-prediction |
                balance plan|solve|check (fan, phone) | printer excite|solve|check (3D printer, phone)"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess

from physica import config


def commit_prediction(source: str) -> str:
    """Prediction commits (SPEC 1.9): record the verdict BEFORE the reveal, with a timestamped git commit."""
    from physica.agents import tools as T

    r = T.feel(source, plot=False)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    config.PREDICTIONS_DIR.mkdir(exist_ok=True)
    p = config.PREDICTIONS_DIR / f"{stamp}_{source.replace(':', '_')}.json"
    p.write_text(json.dumps({"source": source, "made_at_utc": stamp, "verdict": r["verdict"], "card": r["card_used"]},
                            indent=1, default=str))
    subprocess.run(["git", "add", str(p)], cwd=config.REPO_ROOT, check=False)
    subprocess.run(["git", "commit", "-q", "-m", f"prediction before reveal: {source}"], cwd=config.REPO_ROOT, check=False)
    return str(p)


SESSIONS = config.REPO_ROOT / "physica_sessions"


def _session(name: str, data: dict | None = None) -> dict:
    SESSIONS.mkdir(exist_ok=True)
    p = SESSIONS / f"{name}.json"
    if data is not None:
        p.write_text(json.dumps(data, indent=1, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o)))
        return data
    return json.loads(p.read_text())


def _record(kind: str, name: str, result: dict, chk: dict) -> str:
    """Remember the outcome: a signed action record (promise, what was felt after, kept or rolled back)."""
    from physica.library import cards

    c = cards.new_card("experiment", f"Action on {kind} '{name}': {result['promise']['action']} -> "
                       f"{chk['judgement']['verdict']}", {"type": kind, "id": name},
                       metrics={"promise": result["promise"], "judgement": chk["judgement"]},
                       context={"source": "live phone experiment"}, tags=["action record", "live"])
    cards.save(c)
    return c["id"]


def experiment_cli(a) -> None:
    from physica.data.phone import load_phyphox
    from physica.experiment import balance, printer

    if a.cmd == "balance":
        if a.step == "plan":
            print(balance.plan(a.trial_g, a.blades))
        elif a.step == "solve":
            o, t0, t120, t240 = (load_phyphox(f) for f in a.files)
            r = balance.run(o, t0, t120, t240, a.trial_g, a.blades)
            _session(a.name, {"kind": "fan", **r})
            print(r["text"])
            if r.get("promise"):
                print("Promise (written before you act):", r["promise"]["text"])
                print("Now apply the fix, record 30 s at the same speed, then: physica balance check --name", a.name, "after.csv")
        else:
            r = _session(a.name)
            c = balance.check(r, load_phyphox(a.files[0]))
            print(f"Wobble dropped {100 * c['wobble_drop_fraction']:.0f}%. {c['judgement']['text']}")
            print("Remembered as signed card", _record("fan", a.name, r, c))
    else:
        if a.step == "excite":
            print(printer.excite_gcode(a.axis))
        elif a.step == "solve":
            r = printer.run(load_phyphox(a.files[0]), a.axis)
            _session(a.name, {"kind": "3D printer", **r})
            print(f"Felt resonance on {r['axis']}: {r['freq_hz']:.1f} Hz, damping {r['damping']:.3f}")
            print("Marlin:", " | ".join(r["marlin"]), "\nKlipper:\n" + r["klipper"])
            print("Promise (written before you act):", r["promise"]["text"])
        else:
            r = _session(a.name)
            c = printer.check(r, load_phyphox(a.files[0]))
            print(f"Ringing dropped {100 * c['ringing_drop_fraction']:.0f}%. {c['judgement']['text']}")
            print("Remembered as signed card", _record("3D printer", a.name, r, c))


def world_cli(a) -> None:
    """World Sense: learn from real prints, experiment inside, write the G-code, then learn from your break test."""
    from physica.act import contract
    from physica.world import bar, data, gcode_part, laws, sense

    X = data.load(a.data)
    rows = data.original_prints(data._rows(data.default_path() if not a.data else __import__("pathlib").Path(a.data)))
    trule, srule = data.couplings(rows)
    ws = sense.WorldSense(laws.STRENGTH).fit(X, X["tension_strength"])
    if a.step == "design":
        k_flex, learned = (1.0, 1.7), sorted(SESSIONS.glob("*.json"), key=lambda q: q.stat().st_mtime) if SESSIONS.exists() else []
        for q in reversed(learned):
            r = json.loads(q.read_text())
            if r.get("kind") == "world bar" and "learned" in r:
                k_flex = tuple(r["learned"]["k_flex"]["range_90"])
                print(f"Using the bending factor measured by your break test '{q.stem}': {k_flex[0]:.2f}-{k_flex[1]:.2f}")
                break
        d = bar.design(ws, goal_kg=a.goal_kg, span=a.span, temp_rule=trule, speed_rule=srule, k_flex=k_flex)
        c = d["choice"]
        if c is None:
            print(f"No bar I have evidence for holds {a.goal_kg} kg with 95% confidence. Try a shorter span.")
            return
        p = contract.promise(f"bar for {a.goal_kg} kg", f"Holds {a.goal_kg} kg at mid-span for 60 s; breaks between "
                             f"{c['break_kg_90'][0]:.1f} and {c['break_kg_90'][1]:.1f} kg.",
                             [{"metric": "held_goal_60s", "op": ">=", "value": 1, "say": f"holds {a.goal_kg} kg"},
                              {"metric": "break_kg", "op": ">=", "value": round(c["break_kg_90"][0], 2), "say": "breaks above the low end"},
                              {"metric": "break_kg", "op": "<=", "value": round(c["break_kg_90"][1], 2), "say": "breaks below the high end"}])
        g = gcode_part.bar_gcode(c, notes=[f"promise {p['digest']}: {p['text']}"])
        out = f"{a.name}.gcode"
        open(out, "w").write(g)
        _session(a.name, {"kind": "world bar", "design": c, "promise": p})
        chk = gcode_part.check(g, c["mass_g"])
        print(f"Tried {d['inner_experiments']:,} bars inside my model of printed plastic; {d['meeting_goal']:,} would hold.")
        print(f"Lightest: {c['width_mm']:.0f} x {c['height_mm']:.1f} x {c['length_mm']:.0f} mm, {c['wall_mm']} mm walls, "
              f"{c['infill'] * 100:.0f}% infill, {c['layer_height']} mm layers, nozzle {c['nozzle_temperature']:.0f} C, "
              f"bed {c['bed_temperature']:.0f} C, fan {c['fan_speed']:.0f}% -> {c['mass_g']:.1f} g of plastic.")
        print(f"G-code: {out} (checked: {'OK' if chk['ok'] else chk['problems']}, {chk['plastic_g']:.1f} g)")
        print("Promise (written before you print):", p["text"])
        print(f"Test: rest it on two supports {c['span_mm']:.0f} mm apart, hang {a.goal_kg} kg from the middle for 60 s, "
              f"then add water until it breaks. Then: physica world learn --name {a.name} --break-kg <kg> --held")
    else:
        r = _session(a.name)
        c = r["design"]
        L = bar.learn_from_break(ws, c, a.break_kg)
        j = contract.judge(r["promise"], {"held_goal_60s": 1 if a.held else 0, "break_kg": a.break_kg})
        print(L["say"])
        print("Promise held: the design is kept as proven." if j["verdict"] == "kept" else
              "Promise broken: recorded as 'didn't work'. The measured number above replaces the assumption.")
        r.update(learned=L, judgement=j)
        _session(a.name, r)
        print("Remembered as signed card", _record("world bar", a.name, r, {"judgement": j}))


def printer_proof_cli(a) -> None:
    """The goal step, the SAM with-and-without test, and the scoreboard for the three things this project sets out to show."""
    from physica.touch import printer_compare as PC
    from physica.touch import printer_goal as G
    from physica.touch import printer_proof as PP
    from physica.touch import printer_watch as W

    if a.step == "proof":
        board = PP.board(SESSIONS, a.name, a.other, config.REPO_ROOT / "eval" / "results")
        _session(f"{a.name}_proof", board)
        print(PP.as_text(board))
        return
    if a.step == "sam-compare":
        if not a.files or not (a.sam or a.roi):
            raise SystemExit('sam-compare needs the same films and --sam "print head" (or --roi, to test the code without SAM)')
        roi = W.parse_roi(a.roi)
        located = None
        saved = _saved_crop(a.name) if a.sam else None
        if saved and saved.get("located_by"):
            located = saved["located_by"]
            print("Using the crop live SAM found for this printer's baseline. No new SAM call.")
        elif a.sam:
            located = W.sam_roi(a.files[0], a.sam)
        roi = located["roi"] if located else roi
        plan = W.plan_load(a.files[0], roi)
        plan["located_by"] = located
        graded = SESSIONS / f"{a.name}_ripple_graded.json"
        truth = json.loads(graded.read_text()).get("tone_from_part_hz") if graded.exists() else None
        r = PC.compare(a.files, plan, "SAM crop" if a.sam else "hand crop", truth)
        _session(f"{a.name}_sam_compare", r)
        print(f"{'':<12}{'whole frame':>14}{r['crop']:>14}   clear winner")
        for label, key, score in (("stops felt", "stops_felt", "stops_felt"), ("tone wander", "tone_wander_hz", "tone_wander"), ("vs calipers", "error_vs_calipers_hz", "error_vs_calipers")):
            print(f"{label:<12}{str(r['whole_frame'][key]):>14}{str(r['with_crop'][key]):>14}   {r['scores'][score]}")
        print(f"Calipers say {truth} Hz." if truth else "No caliper reading yet.")
        print(f"Result: {r['decided']}, decided by {r['decided_by']}.")
        return
    r = _session(a.name) if (SESSIONS / f"{a.name}.json").exists() else {}
    if "felt" not in r:
        raise SystemExit(f"run: physica printer-video tune your_film.mp4 --name {a.name}   first")
    muse_goal = SESSIONS / f"{a.name}_muse_goal.json"
    if a.drop is None and muse_goal.exists():
        said = json.loads(muse_goal.read_text())
        a.drop, a.goal = said["drop"], a.goal or f"Muse's goal: remove {100 * said['drop']:.0f}% of the ringing. {said.get('reason', '')}".strip()
        print(f"Using the goal Muse set: remove {100 * a.drop:.0f}% of the ringing.")
    if a.drop is None:
        raise SystemExit("goal needs --drop, the measurable target: 0.7 means ringing down at least 70%")
    path = SESSIONS / f"{a.name}_goal.json"
    state = json.loads(path.read_text()) if path.exists() else {"attempts": []}
    tried = tuple(x["sealed"]["payload"]["prediction"]["shaper"] for x in state["attempts"] if (x.get("grade") or {}).get("met") is False)
    pending = [x for x in state["attempts"] if not x.get("grade")]
    if a.firmware == "cura":
        source = None
        if a.gcode_in:
            from physica.touch import printer_file as PF
            try:
                source = PF.load_source(a.gcode_in)
                part = PF.read_part(source)
            except PF.CannotRewrite as e:
                raise SystemExit(str(e))
            a.speed = a.speed or part["wall_speed_mm_s"]
            a.current_accel = a.current_accel or part["wall_accel"]
            print(f"Read {a.gcode_in}: outer walls at {a.speed:g} mm/s and {a.current_accel:g} mm/s2, in {part['wall_sections']} sections.")
        if not a.speed or not a.current_accel:
            raise SystemExit("goal with cura needs --gcode-in part.gcode, or --speed (Outer Wall Speed) and --current-accel (Outer Wall Acceleration) from Cura's settings")
        c = G.choose_acceleration(r["felt"], a.drop, a.speed, a.current_accel, tried)
        for row in c["rows"][:8]:
            note = " (tried, missed)" if row["tried"] else ""
            print(f"  {row['cycles']:>2} cycles per speed-up: wall {row['wall_accel']} mm/s2, ringing down about {100 * row['worst_drop']:.0f}%{note}")
        if c["status"] != "CHOSEN":
            print(c["say"])
            return
        state["attempts"] = [x for x in state["attempts"] if x.get("grade")]
        text = a.goal or f"Cut ringing on {a.axis.upper()} by at least {100 * a.drop:.0f}%"
        if source is not None:
            try:
                body, report = PF.rewrite(source, c["wall_accel"])
                c["time_forecast"] = PF.time_forecast(source, c["wall_accel"])
            except PF.CannotRewrite as e:
                raise SystemExit(str(e))
            c["file_in_sha256"], c["file_out_sha256"] = hashlib.sha256(source.encode()).hexdigest(), PF.body_sha256(body)
        sealed = G.seal_goal(text, c, a.axis)
        state["attempts"].append({"sealed": sealed})
        path.write_text(json.dumps(state, indent=1, default=float))
        print(f"Goal: {text}")
        print(f"Chosen: {c['cycles']} tone cycles per speed-up, the fastest that meets your goal. Sealed: {sealed['anchor']}")
        if source is not None:
            out = Path(a.out or f"{Path(a.gcode_in).stem}_goal.gcode")
            final, _ = PF.rewrite(source, c["wall_accel"], (f"goal: {text}", f"outer walls {a.current_accel:g} to {c['wall_accel']} mm/s2. Nothing else changed.", f"sealed: {sealed['anchor']}"))
            out.write_text(final, encoding="utf-8", newline="\n")
            t = c["time_forecast"]
            print(f"Wrote {out}: {report['outer_wall_moves']} outer-wall moves slowed. All {report['moves']} moves checked: same path, same material.")
            when = f", about {t['forecast_minutes']:g} min against Cura's {t['cura_minutes']:g}" if t["forecast_minutes"] else ""
            print(f"Time forecast: at most {t['model_extra_pct']:g}% longer{when}. Slowing the whole print this way would cost {t['whole_print_extra_pct']:g}%.")
            print("Read the changed lines, copy the file to USB, and start it yourself. Time it with a stopwatch.")
        else:
            print(f"In Cura: Outer Wall Speed {a.speed:g} mm/s, Enable Acceleration Control on, Outer Wall Acceleration {c['wall_accel']} mm/s2.")
        print(f"To check it on film: make the test motion with --accel {c['film_accel']}, run and film it, then:")
        print(f"  physica printer-video check after.mp4 --name {a.name} --accel {c['film_accel']}")
        if c["film_forecast_drop"] < a.drop:
            print(f"The film may show less than your goal: about {100 * c['film_forecast_drop']:.0f}% at worst. The printed parts are still the real test.")
        return
    c = G.choose(r["felt"], a.drop, tried, a.firmware)
    for row in c["rows"]:
        note = " (tried, missed)" if row["tried"] else ""
        print(f"  {row['shaper']:<4} at worst drops ringing {100 * row['worst_drop']:.0f}%, smooths corners {row['smoothing_ms']:.1f} ms{note}")
    if c["status"] != "CHOSEN":
        print(c["say"])
        return
    if pending:
        state["attempts"] = [x for x in state["attempts"] if x.get("grade")]
    text = a.goal or f"Cut ringing on {a.axis.upper()} by at least {100 * a.drop:.0f}%"
    sealed = G.seal_goal(text, c, a.axis)
    state["attempts"].append({"sealed": sealed})
    path.write_text(json.dumps(state, indent=1, default=float))
    print(f"Goal: {text}")
    print(f"Chosen: {c['shaper']}, the lightest that meets it from {c['tone_range_hz'][0]} to {c['tone_range_hz'][1]} Hz. Sealed: {sealed['anchor']}")
    for k, v in G.settings(c, a.axis).items():
        print(f"{k.capitalize()}:\n{v}")
    print(f"You review and apply it, film the same G-code, then: physica printer-video check after.mp4 --name {a.name}")


def printer_film_cli(a) -> None:
    """Filmable views of a tune session: the shake made visible, and a sealed ripple forecast graded with calipers."""
    from physica.film import printer as FP
    from physica.touch import printer_ripple as R
    from physica.touch import printer_video as PV
    from physica.touch import printer_watch as W

    r = _session(a.name)
    if "felt" not in r:
        raise SystemExit(f"run: physica printer-video tune your_film.mp4 --name {a.name}   first")
    if a.step == "show":
        if not a.files:
            raise SystemExit("printer-video show needs the before film, and the after film if you have one")
        load = (lambda f: W.load(f, r["load"])) if r.get("load") else None
        from physica.touch import video
        load = load or video.load_gray
        before = load(a.files[0])
        after = load(a.files[1]) if len(a.files) > 1 else None
        check = None
        if after is not None:
            check = PV.check(r, after, {**PV.EXCITE, "accel": int(a.accel)} if a.accel else PV.EXCITE)
        got = FP.shake(before, a.out or f"{a.name}_shake.mp4", r["felt"], r["clock"]["fps"], after,
                       check["after_clock"]["fps"] if check and check.get("after_clock") else None,
                       check.get("ringing_drop_fraction") if check else None, a.simulated)
        print(f"Saved {got['out']}: motion shown x{got['motion_gain']} on both films, across {got['stops']} stops.")
        return
    if a.step == "ripple":
        if not a.speed:
            raise SystemExit("printer-video ripple needs --speed, your outer wall speed in mm/s. Use 80 to 100")
        sealed = R.forecast(r["felt"], a.speed, a.axis.upper())
        p = sealed["payload"]["prediction"]
        _session(f"{a.name}_ripple", sealed)
        print(f"Sealed {sealed['anchor']}: ripples {p['spacing_mm']:.2f} mm apart at {a.speed:g} mm/s "
              f"(range {p['spacing_range_mm'][0]:.2f} to {p['spacing_range_mm'][1]:.2f}).")
        print(f"Saved {FP.wall_film(sealed, a.out or a.name + '_wall.mp4')}. It's a simulation: film the real part next.")
        print(f"Print a wall running along {'Y' if a.axis.upper() == 'X' else 'X'}, skip the first ripple or two after the corner, then:")
        print(f"  physica printer-video grade-ripple --name {a.name} --distance-mm D --ripples N")
        return
    if a.distance_mm is None or a.ripples is None:
        raise SystemExit("printer-video grade-ripple needs --distance-mm and --ripples")
    if not (SESSIONS / f"{a.name}_ripple.json").exists():
        raise SystemExit(f"Nothing sealed yet. Before printing, run: physica printer-video ripple --name {a.name} --speed 100")
    g = R.grade(_session(f"{a.name}_ripple"), a.distance_mm, a.ripples)
    _session(f"{a.name}_ripple_graded", g)
    print(g["verdict"])
    if "tone_from_part_hz" in g:
        print(f"Calipers say {g['tone_from_part_hz']:.1f} Hz. The film said {g['tone_from_film_hz']:.1f} Hz ({g['difference_pct']:+.1f}%).")


def touch_cli(a) -> None:
    """Jaw-droppers from video: a camera that weighs things; tune a 3D printer by filming it."""
    from physica.touch import printer_video as PV
    from physica.touch import printer_watch as W
    from physica.touch import video, weigh

    if a.cmd == "weigh":
        Vs = [video.load_gray(f) for f in a.files]
        if len(Vs) == 2:
            Vs = [Vs[0], None, Vs[1]]
        r = weigh.weigh_videos(Vs[0], Vs[1], Vs[2], a.fps, a.coin_g, coin_place=a.coin_place, ruler_g=a.ruler_g)
        print(r["say"])
        if r.get("physics_check"):
            print(f"Physics check: mode ratio {r['physics_check']['ratio_2_to_1']:.2f} (uniform clamped ruler 6.27): {r['physics_check']['say']}")
        _session("weigh_" + a.name, r)
        return
    if a.step in ("show", "ripple", "grade-ripple"):
        return printer_film_cli(a)
    if a.step in ("goal", "sam-compare", "proof"):
        return printer_proof_cli(a)
    if a.step == "excite":
        header = None
        if a.header_from:
            try:
                from physica.touch.printer_file import load_source
                header = PV.griffin_header(load_source(a.header_from))
            except (OSError, ValueError) as e:
                raise SystemExit(f"Can't use {a.header_from}: {e}")
        print(PV.excite_gcode(a.axis, {**PV.EXCITE, "accel": int(a.accel)} if a.accel else PV.EXCITE, header), end="")
    elif a.step == "tune":
        saved_crop = None if (a.sam or a.roi) else _saved_crop(a.name)
        if saved_crop:
            print("Using the crop from this printer's baseline. No new SAM call.")
            V, plan = W.load(a.files[0], saved_crop), saved_crop
        else:
            V, plan = _open_film(a, a.files[0])
        r = PV.tune(V, a.axis, fps_hint=a.fps)
        if "error" in r:
            print(r["error"])
            return
        _session(a.name, {"kind": "printer from video", "load": plan, **r})
        print(f"Video clock from the G-code: {r['clock']['fps']:.1f} frames per real second")
        print(f"Felt ringing: {r['felt']['freq_hz']:.1f} Hz (damping {r['felt']['damping']:.3f}) in {r['felt']['windows']} stops")
        print("Marlin:", " | ".join(r["marlin"]), "\nKlipper:\n" + r["klipper"])
        print("Promise (written before you act):", r["promise"]["text"])
        print(f"Now turn it on, film the same G-code again, then: physica printer-video check --name {a.name} after.mp4")
    elif a.step == "check":
        r = _session(a.name)
        c = PV.check(r, W.load(a.files[0], r["load"]) if r.get("load") else video.load_gray(a.files[0]),
                     {**PV.EXCITE, "accel": int(a.accel)} if a.accel else PV.EXCITE)
        out = SESSIONS / f"{a.name}_check.json"
        _session(f"{a.name}_check", {"kind": "printer before/after check", "film": a.files[0], **c})
        if c.get('status') == 'CANT_TELL':
            print('Cannot verify printer change:', c.get('reason', 'insufficient evidence'))
            print("Saved:", out)
            return
        print(f"Estimated ringing change: {100 * c['ringing_drop_fraction']:.0f}% reduction (pixel-motion proxy).")
        if c.get("ringing_drop_interval_95_exploratory"):
            lo, hi = c["ringing_drop_interval_95_exploratory"]
            print(f"Exploratory range across stops: {100 * lo:.0f}% to {100 * hi:.0f}%.")
        print('Evidence assessment:',c.get('scientific_verdict','INCONCLUSIVE'))
        print('Review only: do not treat a point estimate as verified print quality.')
        goal_path = SESSIONS / f"{a.name}_goal.json"
        if goal_path.exists():
            from physica.touch import printer_goal as G
            state = json.loads(goal_path.read_text())
            if state["attempts"] and not state["attempts"][-1].get("grade"):
                g = G.grade(state["attempts"][-1]["sealed"], c)
                state["attempts"][-1]["grade"] = g
                goal_path.write_text(json.dumps(state, indent=1, default=float))
                print(f"{g['verdict']}: ringing down {100 * g.get('drop', 0):.0f}% against your {100 * g.get('want_drop', 0):.0f}%.")
                if g["met"] is False:
                    print(f"Run printer-video goal --name {a.name} --drop {g.get('want_drop')} again: it moves on to the next shaper.")
        print("Remembered as signed card", _record("3D printer (video)", a.name, r, c))
        print("Saved:", out)
        print(f"""For Muse: python -m physica.unified.cli --domain printer --input "{SESSIONS / (a.name + '.json')}" --after "{out}" """
              f"""--raw-recording "{a.files[0]}" --split train --live-meta --allow-billed-meta --out {a.name}_inquiry.json""")
    elif a.step == "baseline":
        if len(a.files) < W.MIN_FILMS:
            raise SystemExit(f"baseline needs at least {W.MIN_FILMS} films of the healthy printer, got {len(a.files)}")
        V, plan = _open_film(a, a.files[0])
        films = [W.film_summary(V, a.axis, a.mode_hz)] + [W.film_summary(W.load(f, plan), a.axis, a.mode_hz) for f in a.files[1:]]
        base = W.make_baseline(films)
        modes = next((f.get("modes") for f in films if f.get("modes")), [])
        _session(f"{a.name}_baseline", {"kind": "printer healthy baseline", "load": plan, "baseline": base, "films": list(a.files), "modes": modes, "mode_hz": a.mode_hz})
        if modes:
            print("Resonances seen (Hz):", ", ".join(f"{m['hz']:.1f}" for m in modes))
        print("Tones across the healthy films (Hz):", base["tones_hz"])
        if not base["usable"]:
            raise SystemExit("Baseline not usable: " + base["reason"])
        print(f"Healthy tone {base['mean_hz']:.2f} Hz. Changed beyond {base['changed_limit_hz']:.2f} Hz, "
              f"no change within {base['no_change_limit_hz']:.2f} Hz, can't tell in between.")
    elif a.step == "compare":
        saved = _session(f"{a.name}_baseline")
        film = W.film_summary(W.load(a.files[0], saved["load"]), a.axis, saved.get("mode_hz"))
        change = W.judge_change(saved["baseline"], film)
        log = SESSIONS / f"{a.name}_trials.json"
        trials = json.loads(log.read_text()) if log.exists() else []
        trial = len(trials) + 1
        sealed = W.seal_verdict(a.name, trial, change)
        trials.append({"trial": trial, "film": a.files[0], "change": change, "sealed": sealed})
        log.write_text(json.dumps(trials, indent=1, default=float))
        report = _compare_report(saved, film, change)
        _session(f"{a.name}_compare_{trial}", report)
        print(f"Trial {trial}: {change['verdict'].upper()}. {change['reason']}.")
        if change.get("consistent_with_unverified"):
            print("Consistent with (unverified):", change["consistent_with_unverified"])
        print("Sealed before the reveal:", sealed["sha256"][:16])
        print(f"Reveal with: physica printer-video reveal --name {a.name} --trial {trial} --truth changed|same")
        print(f"""For Muse: python -m physica.unified.cli --domain printer --input "{SESSIONS / (a.name + f'_compare_{trial}.json')}" """
              f"""--raw-recording "{a.files[0]}" --split train --live-meta --allow-billed-meta --out {a.name}_inquiry.json""")
    elif a.step == "reveal":
        log = SESSIONS / f"{a.name}_trials.json"
        trials = json.loads(log.read_text()) if log.exists() else []
        row = next((t for t in trials if t["trial"] == a.trial), None)
        if row is None:
            raise SystemExit(f"no trial {a.trial} for {a.name}")
        if row.get("grade"):
            raise SystemExit(f"trial {a.trial} was already revealed: {row['grade']['result']}")
        row["grade"] = W.grade_trial(row["sealed"], a.truth)
        if a.truth_cause:
            row["grade"]["truth_cause"] = a.truth_cause
            row["grade"]["truth_g"] = a.truth_g
        log.write_text(json.dumps(trials, indent=1, default=float))
        print(f"Trial {a.trial}: Physica said {row['grade']['verdict']}, truth {a.truth}: {row['grade']['result'].upper()}.")
    elif a.step == "wall-score":
        import cv2
        from physica.touch import printer_parts as PT
        if len(a.files) != 2:
            raise SystemExit("wall-score needs two photos: before.jpg after.jpg. Crop both to the same part of the wall, in the same light")
        before, after = (cv2.imread(x, cv2.IMREAD_GRAYSCALE) for x in a.files)
        if before is None or after is None:
            raise SystemExit("couldn't read those photos")
        r = PT.wall_ripple(before, after)
        _session(f"{a.name}_wall_score", {**r, "photos": a.files})
        if r["status"] == "MEASURED":
            print(f"Ripple in the first photo repeats every {r['period_px']} pixels. At that period, the second photo's ripple is {100 * r['drop']:.0f}% smaller.")
            print(r["limit"])
        else:
            print("Can't tell:", r["reason"])
    elif a.step == "blind-pack":
        import secrets
        from physica.touch import printer_parts as PT
        if len(a.files) < 2 or len(a.files) % 2:
            raise SystemExit("blind-pack needs photos in pairs: before1.jpg after1.jpg before2.jpg after2.jpg")
        r = PT.blind_pack([(a.files[i], a.files[i + 1]) for i in range(0, len(a.files), 2)], a.out or f"{a.name}_blind", secrets.randbelow(2 ** 31))
        _session(f"{a.name}_blind_key", r)
        print(f"Photos are in {r['folder']}. Key sealed: {r['anchor']}. {r['ask']} Don't open {a.name}_blind_key until then.")
    elif a.step in ("muse-causes", "muse-update", "muse-judge", "parts", "investigate", "investigate-part"):
        _printer_muse(a)
    elif a.step in ("calibrate", "plan-test", "test", "predict", "grade-predict", "teach", "report"):
        _printer_loop(a)
    else:  # score
        log = SESSIONS / f"{a.name}_trials.json"
        trials = json.loads(log.read_text()) if log.exists() else []
        for t in trials:
            g = t.get("grade") or {}
            print(f"  {t['trial']:>3}  said {t['change']['verdict']:<11} truth {g.get('truth', '(hidden)'):<9} {g.get('result', '')}")
        print(json.dumps(W.score_trials(trials), indent=1))


def _printer_muse(a) -> None:
    """Muse looks, proposes, is challenged and learns. SAM names the parts, and Physica feels each."""
    from physica.touch import printer_muse as M
    from physica.touch import printer_parts as PT
    from physica.touch import printer_video as PV
    from physica.touch import printer_watch as W

    if not a.allow_billed_meta:
        raise SystemExit("This step makes live Meta calls. Add --allow-billed-meta to run it.")
    saved_path = SESSIONS / f"{a.name}_baseline.json"
    saved = json.loads(saved_path.read_text()) if saved_path.exists() else {}
    try:
        if a.step == "investigate":
            from physica.touch import printer_investigate as I
            if a.trial is None:
                raise SystemExit("investigate needs --trial")
            row = _trial(a)
            cause_f = SESSIONS / f"{a.name}_cause_{a.trial}.json"
            model_f = SESSIONS / f"{a.name}_model.json"
            parts_f = SESSIONS / f"{a.name}_parts.json"
            plan_f = SESSIONS / f"{a.name}_plan_{a.trial}.json"
            result = json.loads(cause_f.read_text()) if cause_f.exists() and plan_f.exists() else None
            causes_f = SESSIONS / f"{a.name}_muse_causes_{a.trial}.json"
            prior = json.loads(causes_f.read_text()) if causes_f.exists() else {}
            round_no = prior.get("round", 1) + 1 if result else 1

            def save(kind, data):
                if kind == "plan":
                    if plan_f.exists():    # a new test replaces the old one, which stays on file
                        plan_f.rename(SESSIONS / f"{a.name}_plan_{a.trial}_round{prior.get('round', 1)}.json")
                    if cause_f.exists():
                        cause_f.rename(SESSIONS / f"{a.name}_cause_{a.trial}_round{prior.get('round', 1)}.json")
                    _session(plan_f.stem, data)
                else:
                    _session(causes_f.stem, {**prior, **data, "history": prior.get("history", []) + ([{k: prior.get(k) for k in ("rivals", "round")}] if prior else [])})
            masses = [float(x) for x in a.masses.split(",")]
            model = json.loads(model_f.read_text()).get("model") if model_f.exists() else None
            from physica.meta.scout import Film
            changed_film = row.get("film")
            film = Film(changed_film, workdir=SESSIONS / f"{a.name}_scout") if changed_film and Path(changed_film).exists() else None
            case = I.Case(_session(f"{a.name}_compare_{a.trial}"), model, masses, json.loads(parts_f.read_text()) if parts_f.exists() else None, result, round_no, save, film)
            photos = []
            for label, film in (("Photo from a healthy film:", (saved.get("films") or [None])[0]), ("Photo from the changed film:", row.get("film"))):
                if film and Path(film).exists():
                    photos.append((label, M.photo(film)))
            r = I.investigate(case, photos, film_path=changed_film if film else None)
            _session(f"{a.name}_investigation_{a.trial}_round{round_no}", r)
            print(f"\nMuse {'watched the film' if r['muse_watched_film'] else 'saw photos only'}. Tools it called: {r['tools_called']}")
            if r["explanation"]:
                print("\nMuse's conclusion so far:", r["explanation"])
            if r["numbers_not_measured"]:
                print("Numbers in that conclusion that weren't measured, so don't trust them:", r["numbers_not_measured"])
            if r["for_the_person"]:
                print("\nWhat Muse asks you to do:", r["for_the_person"])
            if r["chosen_g"]:
                print("Muse doesn't move anything. Review it first, fasten the weight securely, and film 3 times. Then:")
                print(f"  physica printer-video test t1.mp4 t2.mp4 t3.mp4 --name {a.name} --trial {a.trial} --added-g {r['chosen_g']:g}")
                print(f"  physica printer-video investigate --name {a.name} --trial {a.trial} --allow-billed-meta")
            if not r["finished"]:
                print("Muse didn't reach a conclusion in this run. It's safe to run it again.")
            return
        if a.step == "investigate-part":
            from physica.meta.scout import Film
            from physica.touch import printer_investigate as I
            from physica.touch import printer_part as PP
            if not a.files:
                raise SystemExit("investigate-part needs the film of your printer, and --photo with a picture of the part")
            if not (SESSIONS / f"{a.name}.json").exists() or not saved.get("baseline"):
                raise SystemExit(f"Film the test motion first, then run baseline and tune with --name {a.name}")
            felt = _session(a.name).get("felt")
            tests_f = SESSIONS / f"{a.name}_part_tests.json"
            model_f = SESSIONS / f"{a.name}_model.json"
            ripple_f = SESSIONS / f"{a.name}_ripple_graded.json"
            model_doc = json.loads(model_f.read_text()) if model_f.exists() else {}
            tones = model_doc.get("loaded_tones_hz") or []
            weight = {"added_g": model_doc.get("added_g"), "tone_with_weight_hz": round(float(sum(tones) / len(tones)), 2)} if tones else None
            sealed = json.loads(tests_f.read_text()) if tests_f.exists() else None
            prior = sorted(SESSIONS.glob(f"{a.name}_investigation_part_round*.json"))

            def save(kind, data):
                _session({"ripple": f"{a.name}_ripple", "part_tests": f"{a.name}_part_tests", "muse_goal": f"{a.name}_muse_goal"}[kind], data)
            speed = a.speed
            if not speed:
                raise SystemExit("investigate-part needs --speed, your outer wall speed in mm/s, from Cura")
            plan = W.plan_load(a.files[0], None)
            V = W.load(a.files[0], plan)
            clock = PV.video_clock(V)["fps"]      # the film's own rhythm, since phones store slow motion wrongly
            film = Film(a.files[0], clock, SESSIONS / f"{a.name}_scout")
            tone = float(saved["baseline"]["mean_hz"])

            def read_part(part):
                got = PT.part_ringing(V, clock, None, tone, PV.EXCITE, lambda frame: film.mask_at(part, frame, V.shape[1:]))
                return {"part": part, "felt": got["ringing_px"] is not None, "tone_hz": round(tone, 2), **got, "area_pct": film.parts[part]["area_pct"], "frames_tracked": film.parts[part]["frames_tracked"], "note": "Pixels of motion, comparable between parts in this film, not calibrated displacement", "reason": None if got["ringing_px"] is not None else "SAM's mask gave too little to read after each stop"}
            case = PP.PartCase(felt, saved["baseline"], film, speed, a.goal or "better walls on this part", [float(x) for x in a.masses.split(",")],
                               sealed, json.loads(ripple_f.read_text()) if ripple_f.exists() else None, weight, len(prior) + 1, save, read_part)
            photos = [("A photo of the part:", M.photo(a.photo))] if a.photo else []
            r = I.investigate(case, photos, film_path=a.files[0])
            _session(f"{a.name}_investigation_part_round{case.round}", r)
            print(f"\nMuse {'watched the film' if r['muse_watched_film'] else 'saw photos only'}. Tools it called: {r['tools_called']}")
            if r["explanation"]:
                print("\nMuse's conclusion so far:", r["explanation"])
            if r["numbers_not_measured"]:
                print("Numbers in that conclusion that weren't measured, so don't trust them:", r["numbers_not_measured"])
            if r["for_the_person"]:
                print("\nWhat Muse asks you to do:", r["for_the_person"])
            if case.sealed and not case.result:
                g = case.sealed["payload"]["prediction"]["grams"]
                print(f"\nReview it first, and fasten only what the staff approve. Print or find the wall, then with calipers:\n  physica printer-video grade-ripple --name {a.name} --distance-mm D --ripples N")
                print(f"Film 3 times with {g:g} g securely fastened, then:\n  physica printer-video calibrate w1.mp4 w2.mp4 w3.mp4 --name {a.name} --added-g {g:g}")
                print(f"Then run this same investigate-part step again.")
            if r.get("muse_goal"):
                print(f"\nMuse's goal: remove {100 * r['muse_goal']['drop']:.0f}% of the ringing. Now:\n  physica printer-video goal --name {a.name} --firmware cura --gcode-in part.gcode --out part_goal.gcode")
            if not r["finished"]:
                print("Muse didn't reach a conclusion in this run. It's safe to run it again.")
            return
        if a.step == "parts":
            if not a.files:
                raise SystemExit("parts needs a film of the unchanged printer")
            plan = W.plan_load(a.files[0], None)
            V = W.load(a.files[0], plan)
            fps = PV.video_clock(V)["fps"]
            f = (saved.get("baseline") or {}).get("mean_hz")
            if not f:
                raise SystemExit(f"Run printer-video baseline --name {a.name} first, so the tone is known")
            if a.parts == "auto":
                from physica.meta import scout as SC
                F = SC.Film(a.files[0], fps, SESSIONS / f"{a.name}_scout")
                seen = SC.watch(a.files[0], extra="This is a 3D printer filmed while its head makes short moves. Name the print head first. ")
                print(f"Muse watched the film: {seen['machine']}. {seen['seen']}")
                for row in seen["parts"]:
                    print(f"  Worth measuring: {row['name']}. {row['why']}")
                wanted = [row["name"] for row in seen["parts"]]
                grid = SC.point(F.still(), wanted)
                grid = {n: grid[n] for n in wanted if n in grid}
                if not grid or wanted[0] not in grid:
                    raise SystemExit("Muse couldn't point at the first part, so the others have nothing to be compared with. Run it again, or name them with --parts")
                F.pin(grid)
                masks = {n: (lambda frame, n=n: F.mask_at(n, frame, V.shape[1:])) for n in grid}
                r = {**PT.read_parts(V, fps, {}, f, wanted[0], masks=masks), "located_by": "Muse pointed, live SAM 3.1 masks", "typed_words": 0, "film": a.files[0], "muse_saw": seen["seen"], "why": {x["name"]: x["why"] for x in seen["parts"]}, "usd": round(seen["usd"] + F.usd, 4)}
                _session(f"{a.name}_parts", r)
                print(f"Motion at the head's tone, {r['tone_hz']} Hz:")
                for n, row in r["parts"].items():
                    print(f"  {n}: {row.get('ringing_px')} px, {row.get('reading', 'not read')}")
                print(r.get("limit") or r.get("reason"))
                return
            names = [n.strip() for n in a.parts.split(",") if n.strip()]
            scale, boxes = plan.get("scale", 1.0), {}
            for n in names:
                try:
                    x1, y1, x2, y2 = W.sam_roi(a.files[0], n, pad=0.0)["roi"]
                    boxes[n] = (int(x1 * scale), int(y1 * scale), int(x2 * scale), int(y2 * scale))
                    print(f"SAM 3.1 found {n}.")
                except ValueError as e:
                    print(f"SAM 3.1 didn't find {n}: {str(e)[:80]}")
            if names[0] not in boxes:
                raise SystemExit(f"SAM has to find the first part, {names[0]}, for the others to be compared with it")
            r = {**PT.read_parts(V, fps, boxes, f, names[0]), "located_by": "live SAM 3.1", "film": a.files[0], "boxes": boxes}
            _session(f"{a.name}_parts", r)
            print(f"Motion at the head's tone, {r['tone_hz']} Hz:")
            for n, row in r["parts"].items():
                print(f"  {n}: {row.get('ringing_px')} px, {row.get('reading', 'not read')}")
            print(r.get("limit") or r.get("reason"))
        elif a.step == "muse-judge":
            if len(a.files) < 2 or len(a.files) % 2:
                raise SystemExit("muse-judge needs photos in pairs: before1.jpg after1.jpg before2.jpg after2.jpg")
            import secrets
            pairs = [(a.files[i], a.files[i + 1]) for i in range(0, len(a.files), 2)]
            r = M.judge_parts(pairs, secrets.randbelow(2 ** 31))
            _session(f"{a.name}_muse_judge", r)
            for row in r["rows"]:
                word = {True: "the fixed part", False: "the unfixed part", None: "neither"}[row["picked_the_fixed_part"]]
                print(f"  Muse picked {row['picked']}, which was {word}. X {row['x_rating']}/10, Y {row['y_rating']}/10. {row['reason']}")
            print(f"Muse didn't know which was which. It picked the fixed part {r['picked_fixed']} of {r['pairs']} times, with {r['cant_tell']} can't tell.")
        else:
            if a.trial is None:
                raise SystemExit(f"{a.step} needs --trial")
            row = _trial(a)
            report = _session(f"{a.name}_compare_{a.trial}")
            path = SESSIONS / f"{a.name}_muse_causes_{a.trial}.json"
            if a.step == "muse-causes":
                parts_file = SESSIONS / f"{a.name}_parts.json"
                got = M.propose(report, ((saved.get("films") or [None])[0], row.get("film")), json.loads(parts_file.read_text()) if parts_file.exists() else None)
                _session(path.stem, got)
                print(f"Muse saw {got['photos_sent']} photos: {got['seen_in_photos']}")
                print(f"Muse proposed {got['proposed']}. {len(got['rivals'])} go to the test. These are ideas, not proof.")
                for r in got["rivals"]:
                    where = "the weight would barely change the tone" if not r["responds_to_weight"] else f"{100 * r['mass_share']:.0f}% of the fall from mass"
                    print(f"  {r['name']}: {where}. {r['story']}")
                for r in got["dropped_by_spark"]:
                    print(f"  Spark removed {r['name']}: {r['challenge']}")
                print(f"Next: physica printer-video plan-test --name {a.name} --trial {a.trial} --masses 20,50,100,200")
            else:
                plan_f, cause_f = SESSIONS / f"{a.name}_plan_{a.trial}.json", SESSIONS / f"{a.name}_cause_{a.trial}.json"
                if not (plan_f.exists() and cause_f.exists()):
                    raise SystemExit("Run plan-test and test for this trial first, so Muse has a result to learn from")
                before = json.loads(path.read_text()) if path.exists() else {"round": 1, "history": []}
                got = M.update(report, json.loads(plan_f.read_text()), json.loads(cause_f.read_text()), before.get("round", 1))
                got["history"] = before.get("history", []) + [{k: before.get(k) for k in ("rivals", "round", "explanation")}]
                _session(path.stem, got)
                print("Muse, after seeing the result:", got["explanation"])
                if got["numbers_not_measured"]:
                    print("Numbers in that explanation that weren't measured, so don't trust them:", got["numbers_not_measured"])
                print("What it would test next:", got["next_test"])
                for r in got["rivals"]:
                    print(f"  Still open: {r['name']}. {r['story']}")
                if got["rivals"]:
                    print(f"To test them, remove any extra weight, then run plan-test and test again for trial {a.trial}.")
    except (OSError, ValueError, RuntimeError) as e:
        raise SystemExit(f"That step failed: {str(e)[:300]}")


def _trial(a) -> dict:
    log = SESSIONS / f"{a.name}_trials.json"
    trials = json.loads(log.read_text()) if log.exists() else []
    row = next((t for t in trials if t["trial"] == a.trial), None)
    if row is None:
        raise SystemExit(f"no trial {a.trial} for {a.name}: run printer-video compare first")
    if row["change"].get("verdict") != "changed":
        raise SystemExit(f"trial {a.trial} said '{row['change'].get('verdict')}', so there is no change to explain")
    return row


def _printer_loop(a) -> None:
    """The cause experiment: learn mass and stiffness, test rival causes, predict a new load, teach another printer."""
    from physica.touch import printer_cause as C
    from physica.touch import printer_report as R
    from physica.touch import printer_watch as W

    def summaries(files, plan, mode_hz):
        return [W.film_summary(W.load(f, plan), a.axis, mode_hz) for f in files]

    def tones(files, plan):
        return C._tones(summaries(files, plan, saved.get("mode_hz")))

    if a.step == "report":
        out = Path(a.out or f"{a.name}_report.html")
        out.write_text(R.build(a.name, SESSIONS, simulated=a.simulated, inquiry=a.inquiry), encoding="utf-8")
        print("Report:", out)
        return
    if a.step == "teach":
        try:
            log = SESSIONS / f"{a.name}_predictions.json"
            evidence = C.verified_at_source(json.loads(log.read_text()) if log.exists() else [])
            card = C.make_card(_session(f"{a.name}_model")["model"], a.name, evidence)
        except (FileNotFoundError, ValueError) as e:
            raise SystemExit(f"Can't teach yet: {e}")
        out = Path(a.out or f"{a.name}_lesson.json")
        out.write_text(json.dumps(card, indent=1))
        print(f"Signed lesson: mass fraction {card['payload']['mass_fraction']:.2f}. Saved: {out}")
        if evidence["verified"]:
            print(f"Verified here: {evidence['held']} sealed prediction(s) held on films it had never seen, none broke.")
        else:
            print(f"NOT VERIFIED ({evidence['held']} held, {evidence['broken']} broke). It can only be a starting guess on another printer. "
                  f"To verify it: printer-video predict, then grade-predict, on {a.name}.")
        return
    if not (SESSIONS / f"{a.name}_baseline.json").exists():
        raise SystemExit(f"No baseline for {a.name}: run printer-video baseline first.")
    saved = _session(f"{a.name}_baseline")
    base, plan = saved["baseline"], saved["load"]
    if a.step == "calibrate":
        if a.added_g is None or len(a.files) < 2:
            raise SystemExit("calibrate needs --added-g and at least 2 films with that known weight fastened on")
        films = summaries(a.files, plan, saved.get("mode_hz"))
        loaded_modes = next((f.get("modes") for f in films if f.get("modes")), [])
        check = W.match_modes(saved.get("modes") or [], loaded_modes, a.added_g)
        for m in check:
            print(f"  {m['hz']:.1f} Hz: {m['reading']}.")
        model = C.calibrate(base, {a.added_g: C._tones(films)}, head_g=a.head_g)
        _session(f"{a.name}_model", {"kind": "printer mass and stiffness", "model": model, "mode_check": check, "added_g": a.added_g, "loaded_tones_hz": C._tones(films)})
        if not model["usable"] and any(m["responds"] for m in check):
            better = next(m for m in check if m["responds"])
            raise SystemExit(f"Not usable: {model['reason']}\nThe {better['hz']:.1f} Hz resonance does respond. "
                             f"Redo the baseline with --mode-hz {better['hz']:.1f} to follow it.")
        if not model["usable"]:
            raise SystemExit("Not usable: " + model["reason"])
        print(f"Effective moving mass {model['m_g']:.0f} g (+/- {2 * model['m_sd_g']:.0f} g), "
              f"stiffness {model['k_n_per_m'] / 1000:.1f} kN/m (+/- {2 * model['k_sd'] / 1000:.1f}).")
        if model.get("mass_fraction"):
            print(f"That is {model['mass_fraction']:.2f} of the head's scale weight. Belts and pulleys move too, so it won't be exactly 1.")
        return
    model = {}
    if not (a.step == "predict" and a.card) and a.step != "grade-predict":
        if not (SESSIONS / f"{a.name}_model.json").exists():
            raise SystemExit("Run printer-video calibrate first.")
        model = _session(f"{a.name}_model")["model"]
        if not model.get("usable"):
            raise SystemExit("Run printer-video calibrate again: " + model.get("reason", ""))
    if a.step in ("plan-test", "test") and a.trial is None:
        raise SystemExit(f"{a.step} needs --trial")
    if a.step == "plan-test":
        row = _trial(a)
        masses = [float(x) for x in a.masses.split(",")]
        muse_file = SESSIONS / f"{a.name}_muse_causes_{a.trial}.json"
        extra = json.loads(muse_file.read_text()).get("rivals", []) if muse_file.exists() else []
        p = C.plan_test(model, row["change"]["tone_now_hz"], masses, extra_rivals=extra)
        _session(f"{a.name}_plan_{a.trial}", p)
        for g, t in p["by_weight_g"].items():
            print(f"  {g:>5} g: more mass predicts {t['more_mass_hz']:.2f} Hz, less stiffness predicts {t['less_stiffness_hz']:.2f} Hz "
                  f"({t['separation_sd']:.1f} sd apart)")
        if not p["chosen_g"]:
            print("None of these weights separates the causes. Add a heavier one, or improve the baseline. Physica won't guess.")
            return
        for r in extra:
            f = p["muse_forecasts_by_weight_g"][f"{p['chosen_g']:g}"][r["name"]]
            note = "" if f["separation_sd"] >= C.SEPARATE_AT else ", too close to tell apart with these weights"
            print(f"  Muse's idea, {r['name']}: predicts {f['forecast_hz']:.2f} Hz with this weight{note}")
        if extra:
            before = p.get("chosen_g_without_muse")
            print(f"Without Muse it would use {before:g} g. With Muse's ideas, {p['chosen_g']:g} g." if before != p["chosen_g"] else f"Muse's ideas didn't change the weight: {p['chosen_g']:g} g either way.")
        print(f"Chosen test: fasten {p['chosen_g']:g} g securely to the head, then film the same G-code {p['films_planned']} times.")
        print("Forecasts sealed:", p["sealed"]["sha256"][:16])
        print("A person reviews and runs this. Nothing loose on a moving head.")
        print(f"Then: physica printer-video test t1.mp4 t2.mp4 t3.mp4 --name {a.name} --trial {a.trial} --added-g {p['chosen_g']:g}")
    elif a.step == "test":
        row = _trial(a)
        if a.added_g is None or not a.files:
            raise SystemExit("test needs --added-g and the films made with that weight fastened on")
        if not (SESSIONS / f"{a.name}_plan_{a.trial}.json").exists():
            raise SystemExit("Run printer-video plan-test first, so the forecasts are sealed before the weight goes on.")
        result = C.judge_cause(model, _session(f"{a.name}_plan_{a.trial}"), row["change"]["tone_now_hz"], tones(a.files, plan), a.added_g)
        _session(f"{a.name}_cause_{a.trial}", result)
        print(f"{result['verdict'].upper()}: {result['reason']}.")
        for n, r in (result.get("rivals") or {}).items():
            print(f"  {n}: forecast {r['forecast_hz']:.2f} Hz, probability {r['probability']:.0%}")
        if result.get("muse_rival_names"):
            won = result.get("top_rival") in result["muse_rival_names"]
            print(f"Closest forecast: {result['top_rival']}. " + ("That was Muse's idea, so test it again before believing it." if won else "Muse's ideas didn't beat the built-in causes this time."))
    elif a.step == "predict":
        if a.added_g is None:
            raise SystemExit("predict needs --added-g, the load you are about to try")
        film_sd = base["sd_used_hz"]
        if a.card:
            if not a.head_g:
                raise SystemExit("predicting from a lesson needs this printer's --head-g")
            try:
                st = C.from_card(json.loads(Path(a.card).read_text()), base, a.head_g)
            except (OSError, ValueError, KeyError) as e:
                raise SystemExit(f"Can't use this lesson: {e}")
            source = f"lesson from {st['from_printer']}"
            lesson_verified = st.get("verified_at_source", False)
            if not lesson_verified:
                print("This lesson wasn't verified on its source printer, so it is only a starting guess here.")
            compare = {"no_lesson_full_head_mass": base["mean_hz"] * (a.head_g / (a.head_g + a.added_g)) ** 0.5, "no_model_same_tone": base["mean_hz"]}
        elif a.trial:
            st = _session(f"{a.name}_cause_{a.trial}").get("state")
            if not st:
                raise SystemExit(f"trial {a.trial} did not settle on a cause, so there is no learned state to predict from")
            st = {**st, "tone_sd_hz": film_sd}
            source = f"learned state, trial {a.trial}"
            compare = {"no_model_same_tone": st["tone_hz"]}
        else:
            st = {"tone_hz": base["mean_hz"], "tone_sd_hz": film_sd / base["films_used"] ** 0.5, "m_g": model["m_g"], "m_sd_g": model["m_sd_g"]}
            source = "this printer's own calibration"
            compare = {"no_model_same_tone": base["mean_hz"]}
        forecast = C.predict_tone(st["tone_hz"], st["tone_sd_hz"], st["m_g"], st["m_sd_g"], a.added_g, film_sd)
        lesson_verified = lesson_verified if a.card else None
        sealed = C.seal_prediction(a.name, a.added_g, forecast, compare, source)
        log = SESSIONS / f"{a.name}_predictions.json"
        rows = json.loads(log.read_text()) if log.exists() else []
        rows.append({"pred": len(rows) + 1, "sealed": sealed, "lesson_verified_at_source": lesson_verified})
        log.write_text(json.dumps(rows, indent=1, default=float))
        print(f"Prediction {len(rows)} from {source}: {a.added_g:g} g added gives {forecast['tone_hz']:.2f} Hz "
              f"({forecast['interval_hz'][0]:.2f} to {forecast['interval_hz'][1]:.2f}). Sealed: {sealed['sha256'][:16]}")
        print(f"Setting to review before printing with this load: M593 X F{forecast['tone_hz']:.1f}")
        print(f"Then film it: physica printer-video grade-predict film.mp4 --name {a.name} --pred {len(rows)}")
    else:  # grade-predict
        log = SESSIONS / f"{a.name}_predictions.json"
        rows = json.loads(log.read_text()) if log.exists() else []
        row = next((r for r in rows if r["pred"] == a.pred), None)
        if row is None or not a.files:
            raise SystemExit("grade-predict needs --pred and the film")
        row["grade"] = C.grade_prediction(row["sealed"], tones(a.files, plan))
        if row.get("lesson_verified_at_source") is not None:
            row["lesson_status"] = C.lesson_status(row["lesson_verified_at_source"], row["grade"])
        log.write_text(json.dumps(rows, indent=1, default=float))
        print(json.dumps(row["grade"], indent=1))
        if row.get("lesson_status"):
            print(row["lesson_status"].replace("_", " "))


def _saved_crop(name: str) -> dict | None:
    """The crop this printer's baseline already paid for, so a later step doesn't call SAM again."""
    p = SESSIONS / f"{name}_baseline.json"
    return (json.loads(p.read_text()).get("load") or None) if p.exists() else None


def _open_film(a, path: str):
    """Read the first film of a session: optional SAM 3.1 or manual crop, and a memory-safe load plan for later films."""
    from physica.touch import printer_watch as W

    roi, located = W.parse_roi(a.roi), None
    if a.sam:
        if roi:
            raise SystemExit("use either --sam or --roi, not both")
        try:
            located = W.sam_roi(path, a.sam)
        except Exception as e:
            raise SystemExit(f"SAM 3.1 could not locate '{a.sam}': {e}\nFix that, or crop by hand with --roi x1,y1,x2,y2.")
        roi = located["roi"]
        print(f"SAM 3.1 found '{a.sam}' in {located['frames_found']} frames; crop {roi}.")
    plan = W.plan_load(path, roi)
    if located:
        plan["located_by"] = located
    if plan["needs_crop_warning"]:
        print(f"This film is large (about {plan['uncropped_gb']} GB uncropped), so it is being scaled to {plan['scale']:.2f}. "
              "Use --sam or --roi for sharper motion. Later films reuse these settings.")
    return W.load(path, plan), plan


def _compare_report(saved: dict, film: dict, change: dict) -> dict:
    """The shared Felt adapter reads this like a tune report, with the change against the baseline added."""
    return {"kind": "printer change check", "felt": film.get("felt") or {}, "change": change,
            "baseline": {k: saved["baseline"].get(k) for k in ("mean_hz", "sd_used_hz", "predictive_sd_hz", "changed_limit_hz",
                                                               "films_used", "sha256", "tones_hz")}}


def sense_cli(a) -> None:
    """One command for every use case: sense / watch a recording, keep it in the Body Bank, export a twin, stream."""
    from physica import bank, twin
    from physica.sense import load_source, sense

    if a.cmd == "bank":
        if a.step == "list":
            for e in bank.entries():
                print(f"{e['id']}  {e['name']}  ({len(e['bodies'])} bodies, signed: {bank.verify(e)})")
            return
        s = sense(a.files[0], fps=a.fps, watch=False)
        if a.step == "add":
            e = bank.add(s, a.label or s["source"], {"source": a.files[0], "licence": a.licence or "unknown"})
            print("Added", e["id"], e["name"])
        else:
            for q in bank.find(s["words"]):
                print(f"{q['name']} (body {q['body']}): {q['distance_pct']:.1f}% apart over {q['shared_modes']} modes; "
                      f"same shaking: {q['verdict_same_shaking']}")
        return
    s = sense(a.files[0], fps=a.fps, watch=(a.cmd == "watch") or a.watch, band=tuple(a.band) if a.band else None)
    print("\n".join(s["summary"]))
    if a.cmd == "sense" and a.twin:
        tw = twin.export(s["_tt"], {"source": a.files[0]})
        print("Twin written to", twin.save(tw, a.twin))
    if a.cmd == "sense" and a.stream:
        from physica.touch.stream import TouchStream

        src = load_source(a.files[0], a.fps)
        for e in TouchStream(s["_tt"]).run(src["Y"]):
            print(f"  live: touch at {e['t']:.3f} s (x{e['strength']:.0f})")
    _session("sense_" + Path(a.files[0]).stem, {k: v for k, v in s.items() if not k.startswith("_")})


def evidence_cli(argv) -> None:
    """Copies your real results into the repo for judges: saved results and receipts, with no films. It stops if anything looks like a key."""
    import re
    import shutil
    p = argparse.ArgumentParser(prog="physica evidence")
    p.add_argument("--name", default="printer")
    a = p.parse_args(argv)
    out = config.REPO_ROOT / "eval" / "results" / "real_run"
    out.mkdir(parents=True, exist_ok=True)
    sources = [f for f in SESSIONS.glob("*.json") if f.name.startswith((a.name, "ruler", "cables"))] if SESSIONS.exists() else []
    receipts = config.REPO_ROOT / "meta_receipts"
    sources += list(receipts.glob("*.json")) if receipts.exists() else []
    key = os.environ.get("MODEL_API_KEY") or ""
    for f in sources:
        text = f.read_text(encoding="utf-8", errors="replace")
        if (key and key in text) or re.search(r"\bLLM_[A-Za-z0-9_-]{20,}", text):
            raise SystemExit(f"{f.name} looks like it holds a key. Nothing more was copied. Tell me before going on")
        (out / ("receipts" if f.parent == receipts else "")).mkdir(exist_ok=True)
        shutil.copyfile(f, out / ("receipts" if f.parent == receipts else "") / f.name)
    print(f"Copied {len(sources)} files to {out}. No films were copied.")


def ruler_cli(a) -> None:
    """The twin you can push: learn from empty flicks, one weighed coin, then sealed forecasts checked by real coins."""
    from physica.twin import modes as T
    path = SESSIONS / f"{a.name}_twin.json"
    SESSIONS.mkdir(exist_ok=True)
    twin = json.loads(path.read_text()) if path.exists() else None

    def need():
        if not twin:
            raise SystemExit(f"run first: physica ruler learn e1.mp4 e2.mp4 e3.mp4 --fps 240 --name {a.name}")

    def need_coin():
        need()
        if not twin.get("calibration"):
            raise SystemExit(f"run first: physica ruler coin tip.mp4 --coin-g 5 --name {a.name}")
    if a.step == "learn":
        if not a.files or not a.fps:
            raise SystemExit("learn needs films and --fps, the real frame rate. Check it by filming a timer")
        twin = T.learn(a.files, a.fps)
        if twin["status"] != "MEASURED":
            raise SystemExit(f"Can't tell: {twin.get('reason')}. Flick harder, film closer, and add a high-contrast mark")
        path.write_text(json.dumps(twin, indent=1, default=float))
        print(f"Tones: {twin['tones_hz']} Hz. Between films it moved {twin['spread_pct']}%.")
        print(f"Tone {twin['tone_hz']} Hz. Damping {twin['damping']}. Shape against a textbook clamped beam: correlation {twin['shape']['vs_textbook_beam']}.")
        print(f"Next, tape a weighed coin at the tip and film it: physica ruler coin tip.mp4 --coin-g 5 --name {a.name}")
    elif a.step == "coin":
        need()
        c = T.calibrate(twin, a.files[0], a.coin_g, a.at)
        if c["status"] != "MEASURED":
            raise SystemExit(f"Can't tell: {c['reason']}")
        twin["calibration"] = c
        path.write_text(json.dumps(twin, indent=1, default=float))
        print(f"With {a.coin_g:g} g at {a.at:g} of the length: {c['tone_with_coin_hz']} Hz, {c['drop_pct']}% lower. The ruler moves like {c['modal_mass_g']} g.")
        if twin["spread_pct"] >= c["drop_pct"]:
            print(f"The empty films moved {twin['spread_pct']}%, as much as the coin did. Forecasts won't mean much. Clamp it harder, or use a heavier coin.")
    elif a.step == "predict":
        need_coin()
        s = T.seal_forecast(twin, a.g, a.at)
        twin.setdefault("sealed", []).append(s)
        path.write_text(json.dumps(twin, indent=1, default=float))
        p = s["payload"]["prediction"]
        print(f"Sealed {s['anchor']}, number {len(twin['sealed'])}: {a.g:g} g at {a.at:g} of the length gives {p['forecast_hz']} Hz, from {p['range_hz'][0]} to {p['range_hz'][1]}. Doing nothing says {p['do_nothing_hz']} Hz.")
    elif a.step == "grade":
        need_coin()
        s = twin["sealed"][a.pred - 1]
        g = T.grade(twin, s, a.files[0])
        if g["status"] != "MEASURED":
            raise SystemExit(f"Can't tell: {g.get('reason')}")
        s["grade"] = g
        path.write_text(json.dumps(twin, indent=1, default=float))
        print(f"Forecast {g['forecast_hz']} Hz, measured {g['measured_hz']} Hz: {'HELD' if g['held'] else 'MISSED'}. Off by {g['error_pct_of_tone']}% of the tone, or {g['error_pct_of_shift']}% of the shift. Doing nothing was off by {g['do_nothing_pct_of_tone']}%.")
    elif a.step == "weigh":
        need_coin()
        r = T.weigh(twin, a.files[0], a.at)
        if r["status"] != "MEASURED":
            raise SystemExit(f"Can't tell: {r['reason']}")
        twin.setdefault("weighed", []).append(r)
        path.write_text(json.dumps(twin, indent=1, default=float))
        print(f"{r['grams']} g, from {r['range_g'][0]} to {r['range_g'][1]}. Now put it on the kitchen scale.")
    else:      # show
        need()
        print(json.dumps({k: v for k, v in twin.items() if k not in ("field",)}, indent=1, default=float)[:4000])


def tone_cli(a) -> None:
    """One region of one film, with no model at all. For anything with a slow tone, like a footbridge filmed from the bank. A tone is not a safety verdict."""
    from physica.meta import scout as SC
    box = tuple(int(v) for v in a.box.split(",")) if a.box else None
    info = SC.film_info(a.film)
    V, _ = SC.load_region(a.film, box, most_frames=a.most_frames)
    from physica.touch.cables import read_cable
    r = read_cable(V, a.fps or info["fps"], lowest_hz=a.lowest)      # finds the fundamental, even when a harmonic is louder
    if r["felt"]:
        print(f"{r['tone_hz']} Hz, clear of the noise by {r['snr']:g} times, reading {len(V)} frames.")
    else:
        print(f"Can't tell: {r.get('reason')}.")
    if a.reference is not None and r["felt"]:
        print(f"Reference {a.reference:g} Hz: off by {100 * abs(r['tone_hz'] - a.reference) / a.reference:.1f}%.")
    if a.out:
        Path(a.out).write_text(json.dumps({**r, "film": a.film, "box": box, "reference_hz": a.reference}, indent=1, default=float))


def main(argv=None):
    # Delegate to the new protocol without altering legacy sense/feel/twin commands.
    if argv is None:
        import sys
        argv = sys.argv[1:]
    if argv and argv[0] == "meta":
        from physica.meta.cli import main as meta_main
        return meta_main(argv[1:])
    if argv and argv[0] == "ruler":
        p = argparse.ArgumentParser(prog="physica ruler", description="A twin you can push, from a tripod film of a clamped ruler. Sealed forecasts, checked by real coins")
        p.add_argument("step", choices=["learn", "coin", "predict", "grade", "weigh", "show"])
        p.add_argument("files", nargs="*")
        p.add_argument("--name", default="ruler")
        p.add_argument("--fps", type=float)
        p.add_argument("--coin-g", type=float, default=5.0)
        p.add_argument("--g", type=float, default=5.0, help="predict: grams")
        p.add_argument("--at", type=float, default=1.0, help="where along the free length, from 0 at the clamp to 1 at the tip")
        p.add_argument("--pred", type=int, default=1)
        return ruler_cli(p.parse_args(argv[1:]))
    if argv and argv[0] == "cables":
        from physica.touch.cables_cli import main as cables_main
        return cables_main(argv[1:])
    if argv and argv[0] == "make-film":
        from physica.studio.runner import main as make_film
        return make_film()
    if argv and argv[0] == "speak":
        from physica.outcome.speak import main as speak_main
        return speak_main(argv[1:])
    if argv and argv[0] == "evidence":
        return evidence_cli(argv[1:])
    if argv and argv[0] == "tone":
        p = argparse.ArgumentParser(prog="physica tone", description="The tone in one region of one film. No model. Not a safety verdict")
        p.add_argument("film")
        p.add_argument("--box", default=None, help="x1,y1,x2,y2 in the film's pixels")
        p.add_argument("--fps", type=float)
        p.add_argument("--lowest", type=float, default=1.0)
        p.add_argument("--reference", type=float)
        p.add_argument("--most-frames", type=int, default=3600)
        p.add_argument("--out", default=None)
        return tone_cli(p.parse_args(argv[1:]))
    if argv and argv[0] == "cause":
        from physica.cause.cli import main as cause_main
        return cause_main(argv[1:])
    if argv and argv[0] == "auto":
        from physica.auto import main as auto_main
        return auto_main(argv[1:])
    if argv and argv[0] == "outcome-loop":
        from physica.outcome.closed_loop_v031 import main as loop_main
        return loop_main(argv[1:])
    if argv and argv[0] == "outcome":
        from physica.outcome.cli import main as outcome_main
        return outcome_main(argv[1:])
    if argv and argv[0] == "verify":
        from physica.verify import main as verify_main
        raise SystemExit(verify_main(argv[1:]))
    if argv and argv[0] == "grammar":
        from physica.grammar.cli import main as grammar_main
        return grammar_main(argv[1:])
    if argv and argv[0] == "experience":
        from physica.experience.cli import main as experience_main
        return experience_main(argv[1:])
    ap = argparse.ArgumentParser(prog="physica")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("feel", "ask", "commit-prediction"):
        s = sub.add_parser(name)
        s.add_argument("source")
    s = sub.add_parser("serve")
    s.add_argument("--replay", action="store_true")
    s.add_argument("--port", type=int, default=8000)
    sub.add_parser("library")
    for name in ("balance", "printer"):
        s = sub.add_parser(name, help="live phone experiment: " + ("fan balancing" if name == "balance" else "printer G-code"))
        s.add_argument("step", choices=["plan", "solve", "check"] if name == "balance" else ["excite", "solve", "check"])
        s.add_argument("files", nargs="*", help="phyphox CSV exports")
        s.add_argument("--name", default="my" + ("fan" if name == "balance" else "printer"))
        s.add_argument("--trial-g", type=float, default=1.0)
        s.add_argument("--blades", type=int, default=3)
        s.add_argument("--axis", default="X")
    for name in ("sense", "watch"):
        s = sub.add_parser(name, help="any video or sensor file -> body, what kind of object, touches, changes, fixes"
                           if name == "sense" else "learn the healthy self, then report every touch and change (and where)")
        s.add_argument("files", nargs=1)
        s.add_argument("--fps", type=float, default=None)
        s.add_argument("--watch", action="store_true")
        s.add_argument("--twin", default=None, help="write a checkable digital twin JSON here")
        s.add_argument("--stream", action="store_true", help="also replay it sample by sample, as a robot would")
        s.add_argument("--band", type=float, nargs=2, default=None, help="only feel between these frequencies (Hz)")
    s = sub.add_parser("bank", help="the Body Bank: add a recording, find what feels like it, list")
    s.add_argument("step", choices=["add", "find", "list"])
    s.add_argument("files", nargs="*")
    s.add_argument("--fps", type=float, default=None)
    s.add_argument("--label", default=None)
    s.add_argument("--licence", default=None)
    s = sub.add_parser("weigh", help="a camera that weighs things: empty.mp4 [coin.mp4] object.mp4")
    s.add_argument("files", nargs="+")
    s.add_argument("--fps", type=float, default=240.0, help="capture frame rate (ratios make the answer barely depend on it)")
    s.add_argument("--coin-g", type=float, default=5.0, help="coin mass in grams (US nickel 5.000, quarter 5.670)")
    s.add_argument("--coin-place", type=float, default=None, help="coin place, 0 = clamp, 1 = tip (else read from the image)")
    s.add_argument("--ruler-g", type=float, default=None, help="the ruler's own mass, if you know it (then no coin video)")
    s.add_argument("--name", default="ruler")
    s = sub.add_parser("printer-video", help="tune a 3D printer by filming it")
    s.add_argument("step", choices=["excite", "tune", "check", "baseline", "compare", "reveal", "score", "calibrate", "plan-test",
                                    "test", "predict", "grade-predict", "teach", "report", "show", "ripple", "grade-ripple", "goal", "sam-compare", "proof", "muse-causes", "muse-update", "muse-judge", "parts", "investigate", "investigate-part", "wall-score", "blind-pack"])
    s.add_argument("files", nargs="*")
    s.add_argument("--axis", default="X")
    s.add_argument("--fps", type=float, default=None)
    s.add_argument("--name", default="myprinter_video")
    s.add_argument("--sam", default=None, help='live SAM 3.1 finds this part and crops to it, e.g. "print head"')
    s.add_argument("--roi", default=None, help="crop by hand instead: x1,y1,x2,y2 in pixels")
    s.add_argument("--trial", type=int, default=None, help="reveal: which sealed trial")
    s.add_argument("--truth", choices=["changed", "same"], default=None, help="reveal: what you actually did")
    s.add_argument("--truth-cause", choices=["mass", "stiffness", "other"], default=None, help="reveal: what caused it")
    s.add_argument("--truth-g", type=float, default=None, help="reveal: the mass added, from a kitchen scale")
    s.add_argument("--added-g", type=float, default=None, help="the known weight fastened on, in grams")
    s.add_argument("--mode-hz", type=float, default=None, help="baseline: follow the resonance near this frequency")
    s.add_argument("--masses", default="20,50,100,200", help="plan-test: weights you have, in grams")
    s.add_argument("--head-g", type=float, default=None, help="the print head's weight on a scale, in grams")
    s.add_argument("--card", default=None, help="predict: a lesson from another printer")
    s.add_argument("--pred", type=int, default=None, help="grade-predict: which sealed prediction")
    s.add_argument("--out", default=None, help="teach or report: output file")
    s.add_argument("--inquiry", default=None, help="report: Muse inquiry file to include")
    s.add_argument("--simulated", action="store_true", help="report or show: label the films as simulated")
    s.add_argument("--speed", type=float, default=None, help="ripple: outer wall speed you will print at, mm/s")
    s.add_argument("--distance-mm", type=float, default=None, help="grade-ripple: distance measured with calipers")
    s.add_argument("--ripples", type=int, default=None, help="grade-ripple: how many ripples that distance spans")
    s.add_argument("--goal", default=None, help='goal: your goal in words, e.g. "Cut ringing on X by at least 70%%"')
    s.add_argument("--drop", type=float, default=None, help="goal: the measurable target, e.g. 0.7 for a 70%% drop in ringing")
    s.add_argument("--firmware", choices=["klipper", "marlin", "cura"], default="klipper", help="goal: which fix your printer can use. cura means acceleration settings only")
    s.add_argument("--accel", type=float, default=None, help="excite, check or show: the acceleration in the test motion, if you changed it")
    s.add_argument("--photo", default=None, help="investigate-part: a photo of the part, under low light from the side")
    s.add_argument("--gcode-in", default=None, help="goal with cura: the part Cura sliced. Physica writes a copy with slower outer walls, ready for USB")
    s.add_argument("--current-accel", type=float, default=None, help="goal with cura: the Outer Wall Acceleration Cura uses now")
    s.add_argument("--header-from", default=None, help="excite: a file Cura sliced for your Ultimaker, to copy its required header")
    s.add_argument("--other", default=None, help="proof: the second printer's name, for the transfer")
    s.add_argument("--allow-billed-meta", action="store_true", help="muse steps and parts: make the live Meta calls")
    s.add_argument("--parts", default="auto", help='parts: what SAM should find, comma separated. The first is the reference')
    s = sub.add_parser("world", help="sense printed plastic from real prints, experiment inside, write G-code")
    s.add_argument("step", choices=["design", "learn"])
    s.add_argument("--goal-kg", type=float, default=5.0)
    s.add_argument("--span", type=float, default=100.0, help="distance between the two supports, mm")
    s.add_argument("--break-kg", type=float, default=None)
    s.add_argument("--held", action="store_true", help="it held the goal weight for 60 s")
    s.add_argument("--name", default="bar_5kg")
    s.add_argument("--data", default=None, help="3D-printer dataset (else PHYSICA_PRINT_DATA)")
    a = ap.parse_args(argv)
    if a.cmd == "world":
        return world_cli(a)
    if a.cmd == "printer-video":
        need = {"tune": 1, "check": 1, "compare": 1}.get(a.step, 0)
        if len(a.files) < need:
            ap.error(f"printer-video {a.step} needs a video file")
        if a.step == "reveal" and (a.trial is None or a.truth is None):
            ap.error("printer-video reveal needs --trial and --truth")
    if a.cmd in ("weigh", "printer-video"):
        return touch_cli(a)
    if a.cmd in ("sense", "watch", "bank"):
        return sense_cli(a)
    if a.cmd in ("balance", "printer"):
        return experiment_cli(a)
    if a.cmd == "feel":
        from physica.agents import tools as T

        r = T.feel(a.source)
        print(r["verdict"]["text"], "\n", r["verdict"]["disclaimer"], "\nfeelogram:", r.get("feelogram_png"))
    elif a.cmd == "ask":
        from physica.agents import wonder_agent as W

        r = W.ask("Is this drone safe to fly?", a.source)
        print(r["answer"], "\ncites:", r["cites"])
    elif a.cmd == "commit-prediction":
        print("committed", commit_prediction(a.source))
    elif a.cmd == "serve":
        from physica.app.server import main as serve

        serve((["--replay"] if a.replay else []) + ["--port", str(a.port)])
    elif a.cmd == "library":
        from physica.library import cards

        print(json.dumps(cards.library_counts(), indent=1))


if __name__ == "__main__":
    main()
