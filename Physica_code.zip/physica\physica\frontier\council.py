"""Evidence-bound Muse multi-agent protocol, no autonomous equipment execution.

Meta services produce *proposals*, never observational evidence. Offline replay
allows verifiable tests without claiming any hosted models were run.
"""
from __future__ import annotations
import json, math, hashlib

ROLES=('observer','hypothesis_generator','adversarial_critic','experiment_designer','numerical_verifier','decision_reviewer')


def verify_proposal(proposal, observation):
    if not isinstance(proposal,dict) or not isinstance(observation,dict):
        raise ValueError('Structured proposal and evidence required')
    allowed={'mechanism','supporting_measurements','falsification_test','assumptions','confidence'}
    if set(proposal)-allowed:raise ValueError('Unexpected proposed fields')
    if not isinstance(proposal.get('mechanism'),str) or not proposal['mechanism'].strip():raise ValueError('Mechanism required')
    if not isinstance(proposal.get('falsification_test'),str) or not proposal['falsification_test'].strip():raise ValueError('Falsification test required')
    confidence=proposal.get('confidence')
    if isinstance(confidence,bool) or not isinstance(confidence,(int,float)) or not math.isfinite(confidence) or not 0<=confidence<=1:
        raise ValueError('Confidence must be 0..1')
    measurements=proposal.get('supporting_measurements',[])
    if not isinstance(measurements,list) or any(not isinstance(x,str) for x in measurements):raise ValueError('Measurements must be names')
    present=set(observation.get('measured_channels',[]))
    unsupported=sorted(set(measurements)-present)
    return {'status':'NEEDS_MEASUREMENT' if unsupported else 'HYPOTHESIS_UNVERIFIED',
            'unsupported_channels':unsupported,'mechanism':proposal['mechanism'],
            'note':'Never validate a physical law from a language model agreement. Run prospective numeric/physical evaluation.'}


def council_plan(observation,goal,max_rounds=2):
    if not isinstance(observation,dict) or not isinstance(goal,dict):raise ValueError('Evidence and goal objects required')
    if not 1<=max_rounds<=3:raise ValueError('Review rounds must be 1..3')
    digest=hashlib.sha256(json.dumps(observation,sort_keys=True,allow_nan=False).encode()).hexdigest()
    prompts=[]
    roles=[('observer','muse-spark-1.3'),('hypothesis_generator','muse-wonder-1.0'),
        ('adversarial_critic','muse-spark-1.3'),('experiment_designer','muse-spark-1.3'),
        ('decision_reviewer','muse-wonder-1.0')]
    for role,model in roles:
        prompts.append({'role':role,'suggested_model':model,'evidence_sha256':digest,
            'instruction':f'Role: {role}. Use ONLY grounded measured channels. Label all mechanisms as hypotheses. '
             'Propose discriminating safe, review-only tests. Never fabricate observed outcomes. '
             'Return structured JSON. Do not issue device controls.',
            'context':{'evidence':observation,'goal':goal,'previous_scientific_claims':'Not verified; a critic must challenge proposals.'}})
    return {'status':'OFFLINE_PLAN_NOT_LIVE_META','max_rounds':max_rounds,'roles':prompts,
        'numerical_verifier':'Local deterministic model fitting on independently held-out evidence; cannot be replaced by an LLM.',
        'execution':'NO_AUTONOMOUS_DEVICE_ACTIONS','requires':'MODEL_API_KEY and explicit paid-call authorization for actual hosted exchanges'}


def live_council(observation, goal, *, allow_billed=False):
    """Bounded live inter-model dialogue: hypothesis -> critic -> revision.

    All outputs remain scientific proposals; no automatic experiments/actuation.
    Meta budget reservations and receipts are handled by the existing client.
    """
    import os
    if not allow_billed:raise PermissionError('Explicit paid Meta authorization required')
    if not os.environ.get('MODEL_API_KEY') or os.environ.get('MOCK')!='0':
        raise PermissionError('Set MODEL_API_KEY and MOCK=0 for live Meta calls')
    from physica.llm.meta_client import complete
    plan=council_plan(observation,goal)
    frozen=json.dumps({'observation':observation,'goal':goal},sort_keys=True,allow_nan=False)
    def call(role,model,system,user):
        result=complete(model,[{'role':'system','content':system},{'role':'user','content':user}],
           'frontier_v023_'+role,max_completion_tokens=850,response_format={'type':'json_object'})
        if result.get('mode') not in ('live','replay of live'):raise RuntimeError('Meta inference not authenticated')
        try: obj=json.loads(result.get('content') or '')
        except (ValueError,TypeError):raise ValueError('Meta reply is not valid JSON') from None
        if not isinstance(obj,dict):raise ValueError('Meta reply must be a JSON object')
        return {'role':role,'model':result.get('model'),'mode':result['mode'],'proposal':obj}
    ground=call('observer','spark','List only measured channels, units and uncertainty. Respond JSON. No inferred measurements.',frozen)
    hypo=call('hypothesis','wonder','Propose at most 3 falsifiable physical hypotheses. JSON only. No unsupported evidence claims.',frozen+'\nObserver: '+json.dumps(ground['proposal']))
    critic=call('critic','spark','Attack these hypotheses on identifiability and evidence. Return JSON with counterexamples and missing tests.',frozen+'\nHypotheses: '+json.dumps(hypo['proposal']))
    revision=call('revision','wonder','Revise or abstain based on critique. Return JSON with hypotheses, uncertainty and permitted *review-only* tests.',frozen+'\nInitial: '+json.dumps(hypo['proposal'])+'\nCritique: '+json.dumps(critic['proposal']))
    return {'status':'LIVE_META_PROPOSALS_UNVERIFIED','evidence_sha256':plan['roles'][0]['evidence_sha256'],
            'interactions':[ground,hypo,critic,revision],
            'physical_result':'NOT_VALIDATED_REQUIRES_PROSPECTIVE_EXPERIMENT',
            'hardware_execution':'PROHIBITED','numerical_verification':'not automatically implied by multi-agent agreement'}


def main():
    import argparse
    from pathlib import Path
    p=argparse.ArgumentParser(description='Review-only Meta multi-agent scientific council')
    p.add_argument('--context',required=True,help='JSON containing observation and goal')
    p.add_argument('--out',default='demo/frontier_council.json')
    p.add_argument('--live',action='store_true')
    p.add_argument('--acknowledge-billing',action='store_true')
    args=p.parse_args();data=json.loads(Path(args.context).read_text(encoding='utf8'))
    obs=data['observation'];goal=data['goal']
    result=live_council(obs,goal,allow_billed=args.acknowledge_billing) if args.live else council_plan(obs,goal)
    out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2,allow_nan=False))
    print(json.dumps({'status':result['status'],'output':str(out)}))
if __name__=='__main__':main()
