"""Falsifiable open-world residual-mechanism search (SINDy-inspired).

Numerical physics, never LLM numerology: each proposed mechanism is a bounded
feature of an independently measured force balance. Selection uses experiment-
DISJOINT heldout interventions. Parameters do NOT generalize without target tests.
"""
from __future__ import annotations
import hashlib
import numpy as np

FEATURE_UNITS={'cubic_stiffness':'N/m^3','quadratic_drag':'N*s^2/m^2',
               'coulomb_friction':'N','position_velocity_coupling':'N*s/m^2'}

def _basis(name,x,v):
    if name=='cubic_stiffness':return x**3
    if name=='quadratic_drag':return np.abs(v)*v
    if name=='coulomb_friction':return np.tanh(v/.003)
    if name=='position_velocity_coupling':return x*v
    raise ValueError('unregistered, non-executable physical mechanism')

def _frame(ep):
    names=('displacement_m','velocity_m_s','acceleration_m_s2','applied_force_n')
    x=[np.asarray(ep[k],dtype=float) for k in names]
    if any(z.ndim!=1 or len(z)<16 or not np.all(np.isfinite(z)) for z in x):
        raise ValueError('calibrated x,v,a,force arrays required; do not differentiate uncalibrated audio')
    if any(len(z)!=len(x[0]) for z in x):raise ValueError('sensor synchronization mismatch')
    return x

def discover_residual_mechanism(train_episodes, validation_episodes, *,
             mass_kg, stiffness_n_m, damping_n_s_m,
             candidates=None, min_relative_improvement=.15,
             min_excitation_fraction=.002):
    """Find nonstandard force term verified on HELD-OUT action episodes.

    Requires independently calibrated acceleration and synchronized force; no
    claim of physical causality merely from observational fit. Test action needs
    to alter candidate mechanisms, and further prospective experiment required.
    """
    if not (len(train_episodes)>=2 and len(validation_episodes)>=1):
        raise ValueError('at least two training actions and one independent validation action')
    for z in (mass_kg,stiffness_n_m,damping_n_s_m,min_relative_improvement,min_excitation_fraction):
        if not np.isfinite(z) or z<0:raise ValueError('invalid physics or policy')
    if mass_kg<=0 or stiffness_n_m<=0 or min_relative_improvement>=1:raise ValueError('bad physical regime')
    names=list(candidates or FEATURE_UNITS)
    if not names or any(k not in FEATURE_UNITS for k in names):raise ValueError('unapproved candidate basis')
    train=[_frame(v) for v in train_episodes];test=[_frame(v) for v in validation_episodes]
    # residual force m a + c v + k x - F = - additional force term;
    # heldout episodes must be from entirely distinct intervention identifiers.
    trainids=[e.get('intervention_id') for e in train_episodes]
    validids=[e.get('intervention_id') for e in validation_episodes]
    if any(not x for x in trainids+validids) or len(set(trainids+validids))!=len(trainids+validids):
        raise ValueError('heldout experimental intervention IDs must be disjoint')
    def r(rows):
        return np.concatenate([mass_kg*a+stiffness_n_m*x+damping_n_s_m*v-f
                               for x,v,a,f in rows])
    rtrain=r(train);rtest=r(test);floor=max(float(np.sqrt(np.mean(rtest*rtest))),1e-10)
    results=[]
    for name in names:
        bt=np.concatenate([_basis(name,x,v) for x,v,_,_ in train])
        bv=np.concatenate([_basis(name,x,v) for x,v,_,_ in test])
        norm=float(np.linalg.norm(bt))
        if norm<1e-14 or np.std(bt) < min_excitation_fraction*max(np.max(np.abs(bt)),1e-20):
            results.append({'mechanism':name,'status':'not_identifiable_under_excitations'});continue
        coef=float(np.dot(bt,rtrain)/max(np.dot(bt,bt),1e-30))
        # No complicated neural oracle: one coefficient fitted on training
        # actions, assessed on *different* held-out action trajectories.
        pred=bv*coef
        error=float(np.sqrt(np.mean((rtest-pred)**2)))
        improve=1-error/floor
        results.append({'mechanism':name,'status':'candidate_testable' if improve>=min_relative_improvement else 'not_supported_on_heldout',
                        'coefficient':coef,'unit':FEATURE_UNITS[name],
                        'heldout_force_residual_rmse_n':error,
                        'heldout_improvement_vs_known_physics':float(improve),
                        'train_interventions':trainids,'validation_interventions':validids})
    eligible=[q for q in results if q['status']=='candidate_testable']
    win=max(eligible,key=lambda d:d['heldout_improvement_vs_known_physics']) if eligible else None
    return {'status':'novel_mechanism_candidate_requires_prospective_intervention' if win else 'unknown_or_no_verified_mechanism',
            'best_candidate':win,'candidates':results,
            'known_physics_validation_force_rmse_n':floor,
            'independent_heldout_intervention_count':len(test),
            'note':'SINDy-inspired dictionary fit; not discovery of a new physical law; separate prospective test required',
            'hardware_actuation_allowed':False}
