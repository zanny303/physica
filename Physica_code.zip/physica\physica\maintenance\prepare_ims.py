"""Optional NASA IMS timestamped waveform snapshots -> per-snapshot feature CSV.

NASA IMS is historical physical bearing run-to-failure recording data. A bearing
channel, dataset split, sampling rate, calibration and any failure event truth
must be specified independently. Do not treat the last snapshot as proven
failure for every channel or infer vibration units from the raw text alone.
"""
from __future__ import annotations
import csv
import math
from pathlib import Path
import numpy as np
from .sentinel import DataEvidenceError


def prepare_ims(source_dir:str|Path, out_csv:str|Path, *, machine_id:str,
                channel:int, sample_rate_hz:float=20000.) ->dict:
    root=Path(source_dir)
    if not root.is_dir():raise DataEvidenceError('NASA IMS snapshot folder missing')
    if channel<0 or channel>=8:raise DataEvidenceError('IMS channel 0–7 required')
    if not math.isfinite(sample_rate_hz) or sample_rate_hz<=0:
        raise DataEvidenceError('Physical sample rate must be supplied')
    files=sorted(p for p in root.iterdir() if p.is_file() and not p.name.startswith('.'))
    if len(files)<12:raise DataEvidenceError('At least 12 snapshot files required')
    if len(files)>10000:raise DataEvidenceError('Excessive snapshot count')
    rows=[]
    for idx,p in enumerate(files):
        if p.stat().st_size>20*1024*1024:raise DataEvidenceError(f'Oversized snapshot {p.name}')
        try:
            x=np.loadtxt(p,delimiter=None,ndmin=2)
        except (ValueError,OSError) as exc:
            raise DataEvidenceError(f'Invalid vibration snapshot {p.name}: {type(exc).__name__}') from None
        if x.ndim!=2 or x.shape[0]<100 or x.shape[1]<=channel:
            raise DataEvidenceError(f'Snapshot {p.name} lacks channel {channel} or samples')
        s=np.asarray(x[:,channel],dtype=float)
        if not np.all(np.isfinite(s)):raise DataEvidenceError(f'Non-finite snapshot {p.name}')
        # RMS in source units. No conversion to m/s² without equipment provenance.
        rms=float(np.sqrt(np.mean((s-np.mean(s))**2)))
        rows.append({'machine_id':machine_id,'step':idx,'vibration_rms':rms})
    out=Path(out_csv);out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['machine_id','step','vibration_rms']);w.writeheader();w.writerows(rows)
    return {'status':'PREPARED_FROM_WAVEFORM_SNAPSHOTS','source_dir':str(root),
        'n_snapshots':len(rows),'channel_index':channel,'sample_rate_hz':sample_rate_hz,
        'vibration_rms_units':'original_source_amplitude_units_NOT_SI_CALIBRATED',
        'failure_truth_inferred':False,'machine_repaired':False,
        'output_csv':str(out)}


def prepare_xjtu(source_dir:str|Path, out_csv:str|Path, *, machine_id:str,
                 axis:int=0, speed_rpm:float, load_kn:float) ->dict:
    """XJTU-SY per-minute two-axis CSVs, naturally ordered by numeric filename.

    The original is run-to-failure. Exact bearing failure events, healthy
    intervals, and unit split must come from independent study metadata.
    """
    root=Path(source_dir)
    if not root.is_dir():raise DataEvidenceError('XJTU-SY bearing folder missing')
    if axis not in (0,1):raise DataEvidenceError('Axis must be 0 (horizontal) or 1 (vertical)')
    if not all(math.isfinite(float(x)) and float(x)>0 for x in (speed_rpm,load_kn)):
        raise DataEvidenceError('Specify measured/metadata operating speed and load')
    files=list(root.glob('*.csv'))
    if not files or len(files)>10000:raise DataEvidenceError('Missing or excessive XJTU snapshot CSVs')
    if any(not p.stem.isdigit() for p in files):
        raise DataEvidenceError('Expected numbered XJTU snapshots: 1.csv, 2.csv, etc')
    files.sort(key=lambda p:int(p.stem))
    if len(files)<12:raise DataEvidenceError('Need at least 12 snapshots')
    rows=[]
    for i,p in enumerate(files):
        if p.stat().st_size>20*1024*1024:raise DataEvidenceError(f'Oversized snapshot {p.name}')
        import pandas as pd
        try:
            # Original XJTU CSV files have a header line followed by two axes.
            x=pd.read_csv(p)
            if x.shape[1]<2 or x.shape[0]<100:
                raise DataEvidenceError(f'Invalid XJTU two-axis snapshot {p.name}')
            signal=pd.to_numeric(x.iloc[:,axis],errors='raise').to_numpy(dtype=float)
        except (OSError,ValueError,TypeError) as exc:
            raise DataEvidenceError(f'Invalid snapshot {p.name}: {type(exc).__name__}') from None
        if not np.all(np.isfinite(signal)):raise DataEvidenceError(f'Non-finite {p.name}')
        rms=float(np.sqrt(np.mean((signal-np.mean(signal))**2)))
        rows.append({'machine_id':machine_id,'step':i,'vibration_rms':rms,
                     'speed_rpm':float(speed_rpm),'load':float(load_kn)})
    dest=Path(out_csv);dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    return {'status':'PREPARED_XJTU_REAL_SNAPS_NOT_VALIDATED',
        'bearing_id':machine_id,'n_snapshots':len(rows),
        'axis':axis,'source_hz':25600,'period_between_snapshots_minutes':1,
        'vibration_rms_units':'original_csv_units_not_independently_calibrated',
        'true_failure_step_supplied':False,'operating_conditions_source':'user-supplied study metadata',
        'output_csv':str(dest)}


def merge_machine_features(files:list[str|Path], out_csv:str|Path) ->dict:
    """Merge distinct per-machine snapshot CSV files, preserving unit boundaries."""
    from .sentinel import load_csv
    if not files:raise DataEvidenceError('Specify source per-bearing files')
    all_rows=[];unit_ids=set()
    for file in files:
        records,_=load_csv(file)
        if unit_ids & records.keys():raise DataEvidenceError('Repeated machine_id across sources')
        unit_ids.update(records)
        for unit,rows in records.items():all_rows.extend(rows)
    columns=['machine_id','step','vibration_rms']+[
        key for key in ('speed_rpm','load','temperature_c','motor_current_a')
        if any(key in r for r in all_rows)]
    dest=Path(out_csv);dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore')
        writer.writeheader();writer.writerows(all_rows)
    return {'status':'MERGED_PHYSICAL_FEATURES_NO_LABEL_INFERENCE',
            'machines':sorted(unit_ids),'rows':len(all_rows),'output':str(dest)}
