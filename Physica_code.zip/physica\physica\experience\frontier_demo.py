"""Reproducible, offline Physica v0.3 dual-world + machine teaching demo.

Every value is from a constructed damped-oscillator simulator. This is NOT
real fan-to-fan transfer or live SAM/V-JEPA inference.
"""
from __future__ import annotations
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import numpy as np
from .transport import (BodyCalibration, encode, decode_forecast, local_verify)
from .dual_world import CalibratedForecast, rank_actions, outcome_score
from .pacer import Experiment
from .seal import seal, reveal, verify_seal, verify_reveal, write_json
from .schema import Action, Consequence, ModalWord, PhysicalEpisode, Provenance, Quantity, Sensor


def step_response(t, f_hz, damping, step_force_n, stiffness_n_per_m):
    """Analytic underdamped 2nd-order response to a force step."""
    t = np.asarray(t,dtype=float)
    omega = 2*np.pi*f_hz
    d=np.sqrt(1-damping**2)
    return step_force_n/stiffness_n_per_m*(1-np.exp(-damping*omega*t)*(
        np.cos(d*omega*t)+damping/d*np.sin(d*omega*t)))


def configs():
    a=BodyCalibration("strip-A", "clamped_strip", "calibrated_step_force", 23.4, 850., 1.0,
                      (1.0,2.10),(.032,.04), "simulation-cal-A", True)
    b=BodyCalibration("strip-B", "clamped_strip", "calibrated_step_force", 20.7, 560., 1.50,
                      (1.0,2.11),(.034,.042),"simulation-cal-B",True)
    c=replace(b,machine_id="strip-C",boundary_class="free_free")
    return a,b,c


def _episode(body:BodyCalibration, prediction:float, sigma:float):
    return PhysicalEpisode(
        episode_id=f"frontier-sim-{body.machine_id}-prediction",body_id=body.machine_id,
        machine_id=body.machine_id,body_class="flexural_strip",boundary_class=body.boundary_class,
        sensors=[Sensor(sensor_id="simulation-displacement",modality="displacement",
                        sampling_rate_hz=Quantity(value=2000,unit="Hz"),calibrated=True,
                        calibration_id=body.calibration_id,frame="strip_tip")],
        action=Action(action_id="step_force",action_type=body.action_class,
                      parameters={"force":Quantity(value=body.applied_step_force_n,unit="N")},
                      safety_approved=True,risk_score=.01),
        modal_words=[ModalWord(mode_id=str(i),frequency=Quantity(value=body.fundamental_hz*r,unit="Hz"),
                         damping_ratio=Quantity(value=z,unit="1"),
                         excitation_level=Quantity(value=body.applied_step_force_n,unit="N"))
                     for i,(r,z) in enumerate(zip(body.mode_ratios,body.damping_ratios))],
        consequence=Consequence(observable="tip_step_response_at_index_320",predicted=Quantity(
            value=prediction,unit="m",sigma=sigma),outcome="pending",reversible=True),
        provenance=Provenance(origin="simulation",source_uri="physica/experience/frontier_demo.py",
                   evidence_note="All measurements are simulator values, not real camera data; live Meta not called."))


def demo_actions():
    return [
        Experiment("passive_listen",{"loose":.00060,"healthy":.00061},sigma=.00016,
                   unit="m",risk=.0),
        Experiment("calibrated_step",{"loose":.00150,"healthy":.00090},sigma=.00015,
                   unit="m",risk=.02),
        Experiment("break_coupon",{"loose":.0035,"healthy":.005},sigma=.00001,
                   unit="m",risk=.96,irreversible=True,safety_approved=False),
    ]


def demo_forecasts():
    def f(action,mean_p,mean_v,sig=.00014):
        return (CalibratedForecast("tip_displacement", "m",mean_p,sig,"modal_twin", "synthetic",
                                   "simulated-noise-calibration"),
                CalibratedForecast("tip_displacement", "m",mean_v,sig,"v-jepa-style-surrogate_NOT_VJEPA",
                                   "synthetic","simulated-noise-calibration"))
    return {"passive_listen":f("passive_listen",.00061,.00060),
            "calibrated_step":f("calibrated_step",.00150,.00095)}


def run_frontier_demo(output_dir:str|Path, *, seed:int=24) -> dict:
    root=Path(output_dir);root.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(seed)
    a,b,c=configs()
    t_a=np.linspace(0,.36,800)
    # TauA = fA*tA = fB*tB: compare identical *dimensionless* time.
    t_b=t_a*a.fundamental_hz/b.fundamental_hz
    a_clean=step_response(t_a,a.fundamental_hz,a.damping_ratios[0],a.applied_step_force_n,a.stiffness_n_per_m)
    a_obs=a_clean+rng.normal(0,0.000008,len(t_a))
    idx=320
    a_sealed=seal(_episode(a,float(a_clean[idx]),0.00004))
    a_reveal=reveal(a_sealed,Quantity(value=float(a_obs[idx]),unit="m",sigma=.000008))
    if not verify_reveal(a_reveal) or a_reveal["result"]!="verified":
        raise ValueError("source could not be verified by simulation protocol")
    src_hash=hashlib.sha256(np.asarray(a_obs,dtype="<f8").tobytes()).hexdigest()
    token=encode(a,t_a,a_obs,provenance="simulation",source_outcome_verified=True,
                 source_evidence_sha256=src_hash)
    future=decode_forecast(token,b,t_b)
    refused=decode_forecast(token,c,t_b)
    assert refused["status"]=="refused" and future["status"]=="unverified_forecast"

    # Seal a *specific numerical prediction* before the simulator generates B's observation.
    pred_at_idx=float(future["displacement_m"][idx])
    b_sealed=seal(_episode(b,pred_at_idx,0.00008))
    write_json(root/"01_machine_A_sealed_before_outcome.json",a_sealed)
    write_json(root/"02_machine_A_revealed.json",a_reveal)
    write_json(root/"03_transferable_physical_token.json",token)
    write_json(root/"04_machine_B_forecast_before_outcome.json",future)
    write_json(root/"05_machine_B_sealed_before_outcome.json",b_sealed)
    # Only now produce the held-out B synthetic sensor response.
    b_clean=step_response(t_b,b.fundamental_hz,b.damping_ratios[0],b.applied_step_force_n,b.stiffness_n_per_m)
    b_obs=b_clean+rng.normal(0,0.000025,len(t_b))
    b_reveal=reveal(b_sealed,Quantity(value=float(b_obs[idx]),unit="m",sigma=.000025))
    local=local_verify(future,t_b,b_obs,max_normalized_rmse=.06)
    write_json(root/"06_machine_B_revealed.json",b_reveal)
    write_json(root/"07_rejected_incompatible_machine.json",refused)
    # Ablation: blind copy of A's response in raw meters (time-resampled); not a fair
    # best possible physical baseline, but exposes why dimensional scaling matters.
    naive=np.interp(t_b,t_a,a_obs)
    rmse_naive=float(np.sqrt(np.mean((naive-b_obs)**2)))
    prior={"loose":.5,"healthy":.5}
    dw=rank_actions(prior,demo_actions(),demo_forecasts())
    if dw["chosen"]!="calibrated_step":
        raise RuntimeError("expected safe informative action was not chosen")
    outcomes={"physics":outcome_score(demo_forecasts()["calibrated_step"][0],float(b_obs[idx]),"m"),
              "visual_surrogate":outcome_score(demo_forecasts()["calibrated_step"][1],float(b_obs[idx]),"m")}
    report={"evidence":"100_PERCENT_SYNTHETIC", "seed":seed,
            "main_capability":"Machine A learns a normalized causal step response; Machine B predicts its own response with calibrated scales and performs one local verification",
            "source_signed":verify_reveal(a_reveal),"target_prediction_signed":verify_seal(b_sealed),
            "target_reveal_signed":verify_reveal(b_reveal),
            "machine_B_local_verification":local,"incompatible_machine_C":refused,
            "dual_world_experiment_ranking":dw,"dual_world_posthoc_scores":outcomes,
            "raw_copy_baseline_rmse_m":rmse_naive,
            "dimensionless_transport_rmse_m":local["rmse_m"],
            "rmse_improvement_factor_vs_raw_copy":rmse_naive/max(local["rmse_m"],1e-12),
            "meta_model_execution":"NONE: visual output is labelled a synthetic surrogate",
            "hardware_experiment":"NOT PERFORMED",
            "chronology":"Code executes seal before simulator B; signatures alone do not prove independent timestamps",
            "notes":"All findings limited to this constructed linear oscillator simulator; never a claim of zero-shot robot transfer."}
    write_json(root/"08_results_and_limitations.json",report)
    from .frontier_ui import render
    render(root,report,t_a,a_obs,t_b,b_obs,np.asarray(future["displacement_m"]),naive)
    return report


def synthetic_ablation(output_dir:str|Path,*,seeds:int=30) -> dict:
    """Repeated synthetic parameter-shift trials; no human-selected target outcomes."""
    if not 2 <= seeds <= 10000: raise ValueError("seeds must be 2..10000")
    root=Path(output_dir);root.mkdir(parents=True,exist_ok=True)
    a,b,_=configs(); rng=np.random.default_rng(20261030)
    rows=[]
    for i in range(seeds):
        bs=replace(b,fundamental_hz=float(b.fundamental_hz*rng.uniform(.91,1.09)),
                   stiffness_n_per_m=float(b.stiffness_n_per_m*rng.uniform(.80,1.2)),
                   applied_step_force_n=float(b.applied_step_force_n*rng.uniform(.8,1.2)),
                   damping_ratios=(float(a.damping_ratios[0]+rng.uniform(-.008,.008)),.04))
        t=np.linspace(0,.36,800)
        y_a=step_response(t,a.fundamental_hz,a.damping_ratios[0],a.applied_step_force_n,a.stiffness_n_per_m)
        y_a+=rng.normal(0,.000008,len(t))
        token=encode(a,t,y_a,provenance="simulation",source_outcome_verified=True,
                     source_evidence_sha256=hashlib.sha256(np.asarray(y_a,dtype="<f8").tobytes()).hexdigest())
        tb=t*a.fundamental_hz/bs.fundamental_hz
        forecast=decode_forecast(token,bs,tb)
        if forecast["status"]!="unverified_forecast":raise AssertionError("unexpected model compatibility")
        y_b=step_response(tb,bs.fundamental_hz,bs.damping_ratios[0],bs.applied_step_force_n,bs.stiffness_n_per_m)
        y_b+=rng.normal(0,.000025,len(tb))
        transport_rmse=float(np.sqrt(np.mean((np.asarray(forecast["displacement_m"])-y_b)**2)))
        naive_rmse=float(np.sqrt(np.mean((np.interp(tb,t,y_a)-y_b)**2)))
        rows.append({"trial":i,"transport_rmse_m":transport_rmse,"naive_raw_copy_rmse_m":naive_rmse,
                     "transfer_better_than_raw_copy":transport_rmse<naive_rmse,
                     "local_status":local_verify(forecast,tb,y_b,max_normalized_rmse=.06)["status"]})
    report={"evidence":"SYNTHETIC_ONLY","trials":seeds,
            "mean_transport_rmse_m":float(np.mean([r["transport_rmse_m"] for r in rows])),
            "mean_raw_copy_rmse_m":float(np.mean([r["naive_raw_copy_rmse_m"] for r in rows])),
            "fraction_transport_better":float(np.mean([r["transfer_better_than_raw_copy"] for r in rows])),
            "fraction_local_verified":float(np.mean([r["local_status"]=="locally_verified" for r in rows])),
            "baselines_not_yet_included":["PACER prior transfer", "nearest-neighbour feature scaling",
                                         "Koopman/shared latent transfer", "matched system-ID twin"],
            "limitation":"Simulator uses the same response family for A and B; evidence of correctness within assumptions only.",
            "rows":rows}
    write_json(root/"frontier_synthetic_ablation.json",report)
    return report
