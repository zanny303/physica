# Physica v0.25 — Unknown Mechanism → Designed Probe → Frozen Target Prediction

- Added `physica.frontier.discovery_milestone_v025`: evidence-gated source hypothesis validation, optional authenticated Muse Wonder nomination, bounded numeric parameter tuning, review-only target probing, probe evidence checks, and a sealed four-method target prediction/reveal study.
- Added source-blind original-library transfer and a target-only frozen neural residual baseline; all see identical target training and probe measurements.
- Added `physica.frontier.synthetic_milestone_v025` for clearly labeled **offline synthetic** positive and negative controls and a multi-seed ablation benchmark.
- Added 11 integrity and failure-case tests, real source/target calibration manifests, and a detailed field protocol.
- Added an offline v0.25 task to the MACE Studio catalog.
- No authenticated Meta API requests and no real machine A→B experimental measurements were executed during development. This release is a *research protocol plus controlled synthetic evidence*, not a proven discovery or independent breakthrough.
