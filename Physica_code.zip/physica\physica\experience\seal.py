"""Tamper-evident pre-intervention commitment and post-intervention reveal.

Uses the existing Physica Ed25519 trust store. A signature provides integrity,
NOT proof of when the physical experiment was executed. Use externally
witnessed timestamps for independent preregistration.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from physica.library import sign as S
from .schema import PhysicalEpisode, Quantity


def _canonical(payload: dict) -> bytes:
    # Deterministic Python encoding. NOT claimed to be fully RFC 8785/JCS compatible.
    return S.canonical(payload)


def seal(ep: PhysicalEpisode) -> dict:
    if ep.consequence.observed is not None or ep.consequence.outcome != "pending":
        raise ValueError("cannot seal after observation is present")
    payload=ep.model_dump(mode="json",exclude_none=True)
    digest=hashlib.sha256(_canonical(payload)).hexdigest()
    return {"protocol":"physica.seal/v1","prediction":payload,"sha256":digest,
            "signature_ed25519":S.sign({"sha256":digest,"prediction":payload}),
            "sealed_at_utc":datetime.now(timezone.utc).isoformat(),
            "caveat":"signature authenticates content, not timestamp or experiment chronology"}


def verify_seal(committed:dict) -> bool:
    try:
        p=committed["prediction"]
        return (committed["protocol"]=="physica.seal/v1" and
            committed["sha256"]==hashlib.sha256(_canonical(p)).hexdigest() and
            S.verify({"sha256":committed["sha256"],"prediction":p},committed["signature_ed25519"]))
    except (KeyError,TypeError,ValueError):
        return False


def reveal(committed:dict, actual:Quantity, *, tolerance_sigma:float=2.,
           raw_observation_sha256:str|None=None) -> dict:
    if not verify_seal(committed): raise ValueError("invalid or tampered prediction seal")
    ep=PhysicalEpisode.model_validate(committed["prediction"])
    pred=ep.consequence.predicted
    if pred is None: raise ValueError("sealed prediction lacks predicted quantity")
    if actual.unit!=pred.unit: raise ValueError("unit mismatch: cannot compare")
    if raw_observation_sha256 is not None and (len(raw_observation_sha256)!=64 or
            any(x not in "0123456789abcdef" for x in raw_observation_sha256)):
        raise ValueError("invalid observation hash")
    residual=actual.value-pred.value
    spread=((pred.sigma or 0.)**2+(actual.sigma or 0.)**2)**.5
    if spread==0:
        verdict="verified" if abs(residual)<1e-12 else "contradicted"
    else:
        verdict="verified" if abs(residual)<=tolerance_sigma*spread else "contradicted"
    ep.consequence.observed=actual
    ep.consequence.outcome=verdict
    record={"protocol":"physica.reveal/v1","seal":committed,"observation":actual.model_dump(mode="json"),
            "observation_sha256":raw_observation_sha256,"residual":residual,
            "standardized_error":(residual/spread if spread else None),"result":verdict,
            "revealed_at_utc":datetime.now(timezone.utc).isoformat(),
            "episode":ep.model_dump(mode="json",exclude_none=True)}
    # Sign both the prior commitment and observation as one new linked result.
    record["reveal_signature_ed25519"]=S.sign({k:v for k,v in record.items() if k!="reveal_signature_ed25519"})
    return record


def verify_reveal(record:dict) -> bool:
    if not verify_seal(record.get("seal",{})):return False
    sig=record.get("reveal_signature_ed25519","")
    return bool(sig) and S.verify({k:v for k,v in record.items() if k!="reveal_signature_ed25519"},sig)


def write_json(path:str|Path, obj:dict):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n")
