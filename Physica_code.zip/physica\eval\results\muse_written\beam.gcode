; Pump 31 Hz, support starts at 84.5 mm, need 5 percent clearance (avoid 29.45-32.55 Hz)
; Chose felt 79.8 mm at 28.58-29.02 Hz as closest safe position
MANUAL_STEPPER STEPPER=support ENABLE=1
MANUAL_STEPPER STEPPER=support SET_POSITION=84.5
MANUAL_STEPPER STEPPER=support MOVE=79.8 SPEED=10 ACCEL=50
G4 P5000