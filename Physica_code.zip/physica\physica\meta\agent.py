"""Muse Wonder as the agent that runs Physica: real tool calling over Physica's own instruments.

The agent can look up evidence, find the cause of a tone change, plan the next experiment (with a sealed promise),
grade a promise after the experiment, and look bodies up in the Body Bank. Every number in its answer must come
from a tool result; Physica's tools do the physics, the model does the asking and explaining.

No key: an offline planner makes the same tool calls in a fixed order, labelled as not Meta.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from physica import config
from physica import seal as _seal
from physica.cause import discover as D
from physica.cause import intervene as I
from physica.cause.fe import Beam
from physica.llm import meta_client as mc

SYSTEM = ("You are Muse, investigating real physical machines. You can see and reason but you can't feel, so Physica is your sense: "
          "it feels bodies through how they vibrate, finds what changed them, plans experiments that settle doubt, and seals predictions "
          "before acting. Use the tools, and lead the investigation yourself. Never invent a number: every number you state must come from a "
          "tool result. If the evidence doesn't settle it, say so. When you plan an experiment, say what Physica sealed (the anchor) and what "
          "it expects. End with what you recommend a person does next, since a person makes the decision.")

BEAM = {"type": "object", "description": "the body, measured with a ruler", "additionalProperties": False,
        "required": ["length_mm", "width_mm", "thickness_mm", "material"],
        "properties": {"length_mm": {"type": "number"}, "width_mm": {"type": "number"},
                       "thickness_mm": {"type": "number"}, "material": {"type": "string",
                                                                       "enum": ["steel", "aluminium", "wood"]}}}


def _fn(name, desc, props, req):
    return {"type": "function", "function": {"name": name, "description": desc, "parameters": {
        "type": "object", "properties": props, "required": req, "additionalProperties": False}}}


TOOLS = [
    _fn("list_evidence", "List Physica's saved results (real and simulated) with one-line summaries.", {}, []),
    _fn("get_result", "Read one saved result by name (e.g. E16_hidden_cause).",
        {"name": {"type": "string"}}, ["name"]),
    _fn("find_cause", "Given a body and its felt tones over time, rule causes in or out by physics and locate the change.",
        {"beam": BEAM, "tone1_hz": {"type": "array", "items": {"type": "number"}},
         "tone2_hz": {"type": "array", "items": {"type": "number"}}}, ["beam", "tone1_hz"]),
    _fn("plan_experiment", "Given a changed body's first three tones, return Physica's belief, the most informative next "
        "experiment (tape a coin somewhere, or measure again) and a SEALED promise of what it will feel.",
        {"beam": BEAM, "felt_hz": {"type": "array", "items": {"type": "number"}}, "coin_g": {"type": "number"}},
        ["beam", "felt_hz", "coin_g"]),
    _fn("grade_promise", "After doing the experiment, grade the sealed promise against the tones actually felt.",
        {"anchor": {"type": "string"}, "felt_hz": {"type": "array", "items": {"type": "number"}}}, ["anchor", "felt_hz"]),
    _fn("feel_blade", "Physica's sense on a real wind turbine blade group, e.g. blade_group_017: the temperature, tones and "
        "what Physica felt (weather removed, change score, slow-mode lead, mass equivalent, verdict). No ground truth.",
        {"group_id": {"type": "string"}}, ["group_id"]),
    _fn("feel_bearing", "Physica's sense on a real bearing part-way through a run to failure, up to a given minute only. Test bearings are Bearing1_3 to "
        "Bearing1_7, Bearing2_3 to Bearing2_7, and Bearing3_3. You don't get to see the end of the run.",
        {"bearing": {"type": "string"}, "minute": {"type": "number"}}, ["bearing", "minute"]),
]


class Session:
    def __init__(self):
        self.seals: dict[str, dict] = {}

    def _beam(self, b):
        return Beam(b["length_mm"] / 1e3, b["width_mm"] / 1e3, b["thickness_mm"] / 1e3, b.get("material", "steel"),
                    n_el=40)

    def list_evidence(self):
        out = []
        for p in sorted((config.RESULTS_DIR).glob("E*.json")):
            try:
                d = json.loads(p.read_text())
            except Exception:
                continue
            label = d.get("LABEL", "real data" if "provenance" in json.dumps(d)[:4000] else "")
            out.append({"name": p.stem, "label": label[:80]})
        return out

    def get_result(self, name):
        p = Path(config.RESULTS_DIR) / f"{Path(name).stem}.json"
        if not p.exists():
            return {"error": f"no result named {name}"}
        txt = p.read_text()
        return json.loads(txt) if len(txt) < 12000 else {"truncated": True, "head": txt[:12000]}

    def find_cause(self, beam, tone1_hz, tone2_hz=None):
        r = D.discover(self._beam(beam), np.asarray(tone1_hz, float), None if not tone2_hz else np.asarray(tone2_hz, float))
        where = r.get("where_mm")
        return {"verdict": r["verdict"], "rivals": r["rivals"],
                "where_mm": None if where is None else [None if not np.isfinite(w) else round(float(w), 1) for w in where]}

    def plan_experiment(self, beam, felt_hz, coin_g):
        b = self._beam(beam)
        inv = I.Investigation(b, coin_g / 1e3 / b.mass_kg)
        inv.observe(felt_hz)
        iv, menu = inv.next_experiment(np.random.default_rng(0))
        s = inv.promise(iv)
        self.seals[s["anchor"]] = s
        return {"belief": inv.belief(), "options": menu[:4], "do_next": iv.say(b), "sealed_anchor": s["anchor"],
                "promise": s["payload"]["prediction"]["intervals"]}

    def grade_promise(self, anchor, felt_hz):
        s = self.seals.get(anchor)
        if s is None:
            return {"error": "unknown anchor"}
        return _seal.reveal(s, {f"tone{k + 1}_hz": float(v) for k, v in enumerate(felt_hz)}, _seal.interval_grade)

    def feel_blade(self, group_id):
        from physica.meta import senses_test as ST
        data = ST.load_cases()
        case = next((c for c in data["cases"] if c["id"] == group_id), None)
        if case is None:
            return {"error": f"no blade group named {group_id}"}
        return {"group_id": group_id, "temperature_c": case["temp_c"], "tones_hz": case["raw_tones_hz"],
                "mode_order": data["mode_order"], "felt": case["felt"], "physica_verdict": case["physica_verdict"],
                "evidence": "real blade in a climate chamber, session 2; learned from session 1 only"}

    def feel_bearing(self, bearing, minute):
        import numpy as np
        from physica import config
        from physica.maintenance import feel_bearing as FB
        files = np.load(config.REPO_ROOT / "eval" / "results" / "E32_femto_features.npz")
        if bearing not in files or bearing in FB.LEARNING:
            return {"error": f"no test bearing named {bearing}"}
        rows = FB.timed(files[bearing])
        rows = rows[rows[:, 0] <= float(minute) * 60]
        if len(rows) < 70:
            return {"error": "too early: this bearing learns its normal in its first 10 minutes"}
        s = FB.scores(rows)["feel"]
        level = json.loads((config.REPO_ROOT / "eval" / "results" / "E32_bearing_downtime.json").read_text())["thresholds"]["feel"]
        idx = FB.first_alarm(s, level, rows[:, 0])
        base = rows[rows[:, 0] <= FB.BASE_MIN * 60]
        return {"bearing": bearing, "minutes_seen": round(float(rows[-1, 0] / 60), 1), "rms_g_normal": round(float(np.median(base[:, 1])), 3), "rms_g_last_minute": round(float(np.median(rows[-6:, 1])), 3),
                "peak_g_so_far": round(float(rows[:, 2].max()), 2), "added_evidence": round(float(s[-1]), 1), "alarm_level": round(level, 1), "physica_alarm_rang_at_minute": None if idx is None else round(float(rows[idx, 0] / 60), 1),
                "evidence": "real bearing on a lab rig, overloaded so it wears out in hours. A fixed 10 g alarm is the usual comparison"}

    def call(self, name, args):
        fn = getattr(self, name, None)
        if fn is None or name.startswith("_"):
            return {"error": f"no tool {name}"}
        try:
            return fn(**args)
        except Exception as e:  # tool errors go back to the model, not up the stack
            return {"error": f"{type(e).__name__}: {e}"}


@mc.register_mock("wonder_agent")
def _offline_planner(messages):
    """Fixed plan with the same tools (NOT Meta): evidence -> E16 -> plan an experiment from the question's tones."""
    calls = [m for m in messages if m.get("role") == "tool"]
    q = next(m["content"] for m in messages if m["role"] == "user")
    if len(calls) == 0:
        return json.dumps({"tool_calls": [{"id": "c1", "type": "function", "function": {"name": "list_evidence", "arguments": "{}"}}]})
    if len(calls) == 1:
        return json.dumps({"tool_calls": [{"id": "c2", "type": "function", "function": {
            "name": "get_result", "arguments": json.dumps({"name": "E16_hidden_cause"})}}]})
    if len(calls) == 2 and "Hz" in q:
        nums = [float(t) for t in q.replace(",", " ").split() if t.replace(".", "", 1).isdigit()][-3:]
        return json.dumps({"tool_calls": [{"id": "c3", "type": "function", "function": {
            "name": "plan_experiment", "arguments": json.dumps({"beam": {"length_mm": 250, "width_mm": 25,
                                                                         "thickness_mm": 1, "material": "steel"},
                                                                "felt_hz": nums, "coin_g": 5})}}]})
    e16 = json.loads(calls[1]["content"])
    txt = "OFFLINE PLANNER (not Meta). "
    try:
        a = e16["A"]["comparison_same_recording"]
        txt += (f"On the real DROPBEAR beam Physica located the hidden support with {a['physica_live']['median']:.1f} mm median "
                f"error (published method {a['published_model_updating_downey2020']['median']:.1f} mm). ")
    except Exception:
        pass
    if len(calls) >= 3:
        p = json.loads(calls[2]["content"])
        txt += (f"For your ruler, Physica believes: {p['belief']['cause']} (confidence {p['belief']['confidence']:.2f}). "
                f"Next: {p['do_next']}. Sealed promise anchor {p['sealed_anchor']}. ")
    return txt + "Advice, not a safety certification."


def ask(question: str, max_steps: int = 8, session: Session | None = None) -> dict:
    s = session or Session()
    msgs = [{"role": "system", "content": SYSTEM}, {"role": "user", "content": question}]
    trace = []
    for _ in range(max_steps):
        r = mc.complete("wonder", msgs, task="wonder_agent", tools=TOOLS, tool_choice="auto",
                        max_completion_tokens=16000)
        calls = r.get("tool_calls") or []
        if not calls:
            return {"answer": r.get("content"), "trace": trace, "mode": r["mode"], "model": r["model"]}
        msgs.append({"role": "assistant", "content": r.get("content") or "", "tool_calls": calls})
        for c in calls:
            name = c["function"]["name"]
            try:
                args = json.loads(c["function"].get("arguments") or "{}")
            except json.JSONDecodeError:
                args = {}
            out = s.call(name, args)
            trace.append({"tool": name, "args": args, "result_preview": json.dumps(out, default=float)[:300]})
            msgs.append({"role": "tool", "tool_call_id": c.get("id", name), "content": json.dumps(out, default=float)[:20000]})
    return {"answer": "(stopped after max steps)", "trace": trace, "mode": r["mode"], "model": r["model"]}
