"""The engineer: search the knobs, keep only actions whose whole error bar meets the spec, pick the cheapest.

Works with any world that offers candidates / outcome / feasible / cost / describe.
If nothing meets the spec it says so and shows the closest miss, instead of guessing.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass
class Plan:
    status: str  # "already meets the goal" | "act" | "no action meets the goal" | "refused: the goal is incomplete"
    action: dict | None
    predicted: dict | None
    say: str
    alternatives: list = field(default_factory=list)
    considered: int = 0
    rejected: int = 0
    refused_out_of_range: int = 0

    def to_json(self) -> dict:
        return asdict(self)


def plan(spec, world, state: dict, use_error_bar: bool = True, n_alt: int = 2) -> Plan:
    from .contract import check
    problems = check(spec)
    if problems:
        return Plan("refused: the goal is incomplete", None, None, "I won't act on this yet: " + "; ".join(problems), [], 0, 0, 0)
    here = world.outcome(_as_action(world, state))
    ok_here, why_here = world.feasible(spec, here, use_error_bar) if not here.get("refused") else (False, here.get("why"))
    if ok_here:
        return Plan("already meets the goal", None, here, f"Stay. Right now the {why_here}.", [], 1, 0, 0)
    rows, rejected, refused = [], 0, 0
    cands = world.candidates(spec, state)
    for a in cands:
        pred = world.outcome(a)
        if pred.get("refused"):
            refused += 1
            continue
        ok, why = world.feasible(spec, pred, use_error_bar)
        if not ok:
            rejected += 1
            continue
        rows.append((world.cost(spec, a, pred, state), a, pred, why))
    if not rows:
        return Plan("no action meets the goal", None, None,
                    "No reachable setting keeps the whole error bar inside the goal. Loosen the goal, or let me "
                    "run an experiment to narrow the error bar.", [], len(cands), rejected, refused)
    rows.sort(key=lambda r: r[0])
    _, a, pred, why = rows[0]
    alts = [{"action": r[1], "predicted": r[2], "say": world.describe(r[1], r[2], state)} for r in rows[1:1 + n_alt]]
    return Plan("act", a, pred, world.describe(a, pred, state) + f" ({why}).", alts, len(cands), rejected, refused)


def _as_action(world, state):
    key = {"beam": "support_v"}.get(world.machine)
    return {key: state[key]} if key else dict(state)
