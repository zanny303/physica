"""Documentation-grounded Meta Model API adapters (unvalidated without credentials).

Meta Model API: https://api.meta.ai/v1; bearer MODEL_API_KEY; /responses.
Muse Spark 1.3 (multimodal context); Muse Wonder 1.0 (causal scientist);
SAM 3.1 video segmentation uses file upload + SSE special-token text.
No image/video/model outputs can authorize actuation or become an observed
physical quantity without independent geometric/calibration checks.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from math import isfinite
import base64, hashlib, json, mimetypes, os, re, urllib.request

API='https://api.meta.ai/v1'
DEFAULTS={'spark':'muse-spark-1.3','wonder':'muse-wonder-1.0','sam':'sam-3.1'}

class ModelNotConfigured(RuntimeError):pass


def model_id(role):
    if role not in DEFAULTS:raise ValueError('unknown role')
    return os.getenv('MODEL_'+role.upper()) or DEFAULTS[role]


def client():
    key=os.getenv('MODEL_API_KEY') or os.getenv('META_API_KEY')
    if not key:raise ModelNotConfigured('MODEL_API_KEY missing; offline means no Meta model executed')
    try:
        from openai import OpenAI
    except ImportError as e:
        raise ModelNotConfigured('pip install -e ".[meta]" for official OpenAI-compatible SDK') from e
    return OpenAI(base_url=API,api_key=key,timeout=90.,max_retries=1)


def extract_text(result):
    if isinstance(result,dict):
        if result.get('status') not in ('completed',None): raise ValueError('response not completed')
        if isinstance(result.get('output_text'),str):return result['output_text']
        return '\n'.join(p['text'] for n in result.get('output',[]) for p in n.get('content',[])
                         if p.get('type')=='output_text' and isinstance(p.get('text'),str))
    if getattr(result,'status',None)!='completed':raise ValueError('response not completed')
    return result.output_text


def sha(payload):return hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()


def _prompt(facts,allowed):
    return ('You are a physical scientific advisor, NOT a sensor or a safety controller. '
            'Answer as a compact JSON object with fields context, hypotheses (max 3; each '
            'name, rationale, discriminating_observation), suggested_action, limitations. '
            'Use ONLY action IDs in allowed_actions. Express measurements ONLY from the '
            'supplied facts, with units and provenance. Unknowns stay unknown. No action '
            'is authorized by your response.\n'+json.dumps({'facts':facts,'allowed_actions':allowed},sort_keys=True))


def _validated_reply(raw,allowed):
    text=extract_text(raw)
    try:
        p=json.loads(text)
    except json.JSONDecodeError:
        # Refuse action rather than infer one from potentially malformed language.
        return {'context':text[:1800], 'hypotheses':[], 'suggested_action':None,
                'limitations':['Malformed/non-JSON Muse reply; no experimental action selected']}
    if not isinstance(p,dict):raise ValueError('Muse response must be an object')
    h=p.get('hypotheses',[])
    if not isinstance(h,list):h=[]
    return {'context':str(p.get('context',''))[:1800],
            'hypotheses':[{'name':str(x.get('name',''))[:100],
                          'rationale':str(x.get('rationale',''))[:800],
                          'discriminating_observation':str(x.get('discriminating_observation',''))[:500]}
                          for x in h[:3] if isinstance(x,dict)],
            'suggested_action':p.get('suggested_action') if p.get('suggested_action') in allowed else None,
            'limitations':p.get('limitations',[]) if isinstance(p.get('limitations',[]),list) else []}


# Strict Responses-format schema per Meta Model API structured-output guide.
SCIENTIST_SCHEMA={'type':'json_schema','name':'physica_scientific_context',
 'strict':True,'schema':{'type':'object','additionalProperties':False,
 'properties':{
  'context':{'type':'string'},
  'hypotheses':{'type':'array','items':{'type':'object','additionalProperties':False,
    'properties':{'name':{'type':'string'},'rationale':{'type':'string'},
                  'discriminating_observation':{'type':'string'}},
    'required':['name','rationale','discriminating_observation']}},
  'suggested_action':{'type':['string','null']},
  'limitations':{'type':'array','items':{'type':'string'}}},
 'required':['context','hypotheses','suggested_action','limitations']}}


def muse_scientist(facts:dict,allowed_actions:list[str],*,role='wonder',image_path=None,video_path=None):
    """Live grounded multi-modal advisor; NEVER simulates a successful call.

    Muse image scene recognition and physical numbers must be kept separate.
    Images are sent as input_image data URLs; videos as uploaded input_file IDs.
    """
    if role not in ('spark','wonder'):raise ValueError('Muse role')
    if image_path and video_path:raise ValueError('use either a video or an image')
    c=client(); contents=[{'type':'input_text','text':_prompt(facts,allowed_actions)}]
    if image_path:
        data=Path(image_path).read_bytes()
        mime=mimetypes.guess_type(str(image_path))[0]
        if mime not in ('image/png','image/jpeg','image/webp'):raise ValueError('unsupported image MIME')
        contents.append({'type':'input_image','image_url':f'data:{mime};base64,'+base64.b64encode(data).decode()})
    if video_path:
        with Path(video_path).open('rb') as f:
            uploaded=c.files.create(file=f,purpose='user_data')
        contents.append({'type':'input_file','file_id':uploaded.id})
    payload=[{'type':'message','role':'user','content':contents}]
    raw=c.responses.create(model=model_id(role),input=payload,
                           text={'format':SCIENTIST_SCHEMA})
    output=_validated_reply(raw,allowed_actions)
    return {'provider':'meta_model_api','mode':'LIVE_UNVERIFIED_EXPERIMENTALLY',
            'model_id':model_id(role),'request_sha256':sha(payload),
            'reply':output,'numeric_authority':False,'actuation_authority':False}


# SAM's documented text grammar: <7f>1<|box;x1=...;...|><|mask;...|> .
# Parse boxes only; masking should use official meta_sam_parser (optional).
FRAME=re.compile(r'<(\d+)f>')
BOX=re.compile(r'(\d+)<\|box;x1=([\d.]+);y1=([\d.]+);x2=([\d.]+);y2=([\d.]+);w=(\d+);h=(\d+)(?:;c=([\d.]+))?\|>')


def parse_sam_boxes(raw):
    """Extract geometric tracks from official SAM 3.1 special-token text.

    Bboxes are PIXELS not meters. Masks are deliberately NOT decoded here.
    A zero-match completed output is an empty list, not a detection failure.
    """
    if not isinstance(raw,str):raise TypeError('SAM raw output must be text')
    spans=list(FRAME.finditer(raw)); tracks=[]
    for i,match in enumerate(spans):
        frame=int(match.group(1))
        block=raw[match.end():spans[i+1].start() if i+1<len(spans) else len(raw)]
        for m in BOX.finditer(block):
            id,x1,y1,x2,y2,w,h,conf=m.groups()
            coords=list(map(float,(x1,y1,x2,y2)));w=int(w);h=int(h)
            if w<=0 or h<=0 or not(0<=coords[0]<=coords[2]<=w and 0<=coords[1]<=coords[3]<=h):
                raise ValueError('invalid SAM box/frame geometry')
            tracks.append({'frame':frame,'object_id':int(id),'x_center_px':.5*(coords[0]+coords[2]),
                           'y_center_px':.5*(coords[1]+coords[3]),'box_px':coords,
                           'width_px':w,'height_px':h,
                           'confidence':float(conf) if conf is not None else None})
    if not spans and raw.strip():raise ValueError('unrecognized SAM response; use official parser')
    return tracks


def calibrated_track_displacement(tracks,*,object_id,meters_per_pixel,frames_per_second,
                                 min_frames=8):
    """Derive calibrated optical displacement from SAM tracked BOUNDING BOX center.

    Requires independent in-plane camera scale + fixed reference frame;
    no inference if camera moves, depth changes, or box tracks the wrong part.
    """
    if not isfinite(meters_per_pixel) or meters_per_pixel<=0 or not isfinite(frames_per_second) or frames_per_second<=0:
        raise ValueError('physical camera calibration and frame rate required')
    arr=sorted([x for x in tracks if x['object_id']==object_id],key=lambda x:x['frame'])
    if len(arr)<min_frames:raise ValueError('insufficient consecutive tracked frames')
    if len({x['frame'] for x in arr})!=len(arr):raise ValueError('duplicated frame track')
    import numpy as np
    t=np.asarray([x['frame'] for x in arr],dtype=float)/frames_per_second
    y=np.asarray([x['y_center_px'] for x in arr],dtype=float)
    return {'time_s':(t-t[0]).tolist(),'displacement_m':((y-y[0])*meters_per_pixel).tolist(),
            'origin':'SAM31_boxes_plus_EXTERNAL_calibration','sensor':'tracked_bbox_center',
            'warning':'Not suitable when perspective/camera motion violates calibration; NOT yet a force measurement'}


def sam_video(video_path,*,concept:str):
    """Verified-output geometry through Meta's official SAM Python parser.

    No regex-based geometry trust: fail on incomplete parser or zero tracks.
    This function needs credentials, network and meta-sam-parser installed.
    """
    from physica.grammar.meta_sam_official import sam_video_official
    return sam_video_official(video_path,concept=concept)


def preflight():
    return {'meta_model_api_base':API,'credentials_available':bool(os.getenv('MODEL_API_KEY') or os.getenv('META_API_KEY')),
            'sdk_installed':__import__('importlib').util.find_spec('openai') is not None,
            'models':DEFAULTS,'endpoints':['POST /v1/responses','POST /v1/files'],
            'live_tested_here':False,'v_jepa_2':'Official github checkpoint local; optional external environment, NOT hosted forecast API',
            'glimmer':'optional local on-device controller, no numerical physics authority'}
