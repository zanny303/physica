"""Translate a resonance mode into 3D-printer input-shaping settings (Marlin M593, Klipper [input_shaper])."""
from __future__ import annotations

import re


def marlin_m593(freq_hz: float, damping_ratio: float, axes: str = "XY") -> list[str]:
    """Marlin input shaping: M593 [X|Y] F<frequency Hz> D<damping ratio 0..1>."""
    if not (0 < damping_ratio < 1):
        raise ValueError("damping ratio must be between 0 and 1")
    if not (1 <= freq_hz <= 200):
        raise ValueError("input-shaping frequency outside the usual printer range (1-200 Hz)")
    return [f"M593 {a} F{freq_hz:.1f} D{damping_ratio:.3f}" for a in axes]


def klipper_input_shaper(freq_x: float, freq_y: float, shaper: str = "mzv") -> str:
    if shaper not in {"zv", "mzv", "ei", "2hump_ei", "3hump_ei"}:
        raise ValueError("unknown Klipper shaper type")
    return f"[input_shaper]\nshaper_freq_x: {freq_x:.1f}\nshaper_type_x: {shaper}\nshaper_freq_y: {freq_y:.1f}\nshaper_type_y: {shaper}\n"


M593_RE = re.compile(r"^M593 [XY] F\d+(\.\d+)? D0?\.\d+$")


def valid_m593(line: str) -> bool:
    return bool(M593_RE.match(line.strip()))
