"""Field-readiness verification. No hardware control and no proof of accuracy."""
from .readiness import validate_field_trial, meta_contract_preflight
__all__ = ['validate_field_trial', 'meta_contract_preflight']
