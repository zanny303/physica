"""One executable scientific path: controlled data → Meta nomination → numerical
falsification → held-out evaluation → review-only next experiment.

The remote model is NEVER accepted as evidence or allowed to actuate hardware.
All API calls require explicit opt-in; field data and physical units must be
provided by the researcher and verified independently outside this program.
"""
from __future__ import annotations
import hashlib,json
from pathlib import Path
import numpy as np
from .field import import_manifest
from .mechanisms import BASE,CANDIDATES,compare,fit,score
from .experiments import rank
from .meta import live_nomination,parse_reply,request_preview
from .consumer import diagnose

def investigate(manifest_path, *, nomination=None, use_live_meta=False, allow_billed=False,
                meta_model='muse-spark-1.3', device=None):
    if use_live_meta and nomination is not None:raise ValueError('choose live Meta or a supplied nomination, never both')
    groups,source=import_manifest(manifest_path)
    train,validation,test=(groups[x] for x in ('train','validation','test'))
    if len({r['body_id'] for r in train+validation+test})!=1:
        raise ValueError('field investigation trains and evaluates one body; cross-body transfer is separate')
    baseline=fit(train,BASE)
    baseline_val=score(validation,baseline)
    # Limited training / validation aggregate only. No test trajectories or labels in Meta request.
    context={'problem':'Unexplained acceleration after controlled interventions',
             'available_measured_channels':['x','v','u','temperature_delta','acceleration'],
             'calibrated_units':{'x':'m','v':'m/s','u':'m/s^2','temperature_delta':'K','acceleration':'m/s^2'},
             'train_residual_rmse':baseline['noise_rmse'],
             'baseline_validation_rmse':baseline_val,
             'mechanisms_already_tested':[t['id'] for t in BASE],
             'safe_observation_options':['review controlled low-force interventions with calibrated sensors']}
    meta={'status':'META_NOT_USED','authenticated':False}
    candidate=None
    if use_live_meta:
        proposed=live_nomination(context,model=meta_model,allow_billed=allow_billed)
        meta={k:v for k,v in proposed.items() if k!='candidate'}
        meta['authenticated']=proposed.get('origin')=='LIVE_META_AUTHENTICATED_REQUEST'
        candidate=proposed.get('candidate')
    elif nomination is not None:
        if isinstance(nomination,dict) and 'candidate' in nomination:
            if nomination.get('status') not in ('META_PROPOSED_UNVERIFIED','USER_PROPOSED_UNVERIFIED'):
                raise ValueError('supplied candidate has no accepted proposal status')
            candidate=nomination['candidate'];meta={'status':'USER_SUPPLIED_NOT_AUTHENTICATED','authenticated':False}
        else:
            parsed=parse_reply(nomination)
            candidate=parsed['candidate'];meta={'status':'OFFLINE_PROPOSED_NOT_AUTHENTICATED','authenticated':False}
    known=compare(train,validation,CANDIDATES[:2],improvement=.08)
    proposed=compare(train,validation, CANDIDATES[:2]+([candidate] if candidate else []),improvement=.08)
    # The same sealed test is only read AFTER model selection on validation.
    known_test=score(test,known['model'])
    proposed_test=score(test,proposed['model'])
    baseline_test=score(test,baseline)
    probes=[]
    # Experimental candidates are copied from TRAIN features. Never use the
    # held-out test outcomes for experiment ranking.
    for row in train[::max(1,len(train)//12)]:
        probes.append({k:v for k,v in row.items() if k!='acceleration'} | {
            'approved_reversible':True,'risk':.05,'cost':.05,'expected_goal_progress':0.})
    planner=rank(probes,[baseline,proposed['model']],
                 [{k:v for k,v in row.items() if k!='acceleration'} for row in validation[:20]])
    # Create an independent record of what data are used and what is not proven.
    result={'schema':'physica.mace.field_investigation.v011',
            'status':'HELDOUT_FIELD_EVALUATION_NOT_INDEPENDENT_PHYSICAL_ATTESTATION',
            'evidence_origin_claimed':source['origin'],
            'raw_recording_hashes':source['recording_hashes'],
            'independent_chronology_verified':False,
            'meta':meta,'meta_candidate_tested':candidate is not None,
            'candidate_accepted_by_validation':proposed['selected'],
            'heldout_test_rows_available_to_nomination':False,
            'heldout_test_rows_available_to_model_selection':False,
            'baseline_heldout_acceleration_rmse_m_s2':baseline_test,
            'fixed_library_heldout_acceleration_rmse_m_s2':known_test,
            'nomination_heldout_acceleration_rmse_m_s2':proposed_test,
            'meta_assisted_single_holdout_improvement_observed':bool(meta['authenticated'] and candidate is not None and
                                          proposed['selected']==candidate['id'] and
                                          proposed_test<known_test),
            'meta_gain_demonstrated':False,
            'candidate_search':{k:v for k,v in proposed.items() if k!='model'},
            'next_safe_measurement_candidates':planner,
            'caution':'Any single-holdout Meta improvement is preliminary. Demonstrated Meta gain requires replication and matched nomination/experiment budgets. No hardware action is executed.'}
    if device is not None:
        result['consumer_review_only']=diagnose(device,evidence={})
    result['evidence_manifest_sha256']=hashlib.sha256(Path(manifest_path).read_bytes()).hexdigest()
    return result
