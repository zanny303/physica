"""Saves the per-group outcomes behind E20, so the turbine clip can replay them without the raw data."""
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "eval"))
import e20_wind_blade as E  # noqa: E402
from physica.cause.blade import BladeSense  # noqa: E402
from physica.data import blade_eth as B  # noqa: E402

tests = B.load()
bs, rows = E.run(tests)
h = [t for t in tests if t.session == 1 and t.case == "R"]
ref_bs = BladeSense()
ref_bs.learn_normal([t.psd for t in h], [t.temp_c for t in h])
ref = ref_bs.law(20)
out, i = [], 0
for (c, tc), g in E.groups([t for t in tests if t.session == 2]):
    f = np.nanmean([ref_bs.tones(p, t) for p, t in g], 0)
    r = rows[i]
    assert r["case"] == c and r["temp_c"] == tc
    i += 1
    out.append({"case": c, "temp_c": tc, "truth": r["truth"], "verdict": r["verdict"], "ice_grams": r.get("ice_grams"),
                "old_alarm": bool(np.nanmax(np.abs(np.log(f / ref))) > 0.02), "tone1_hz": round(float(f[0]), 3)})
temps = list(range(-15, 41, 5))
law = {str(t): round(float(ref_bs.law(t)[0]), 3) for t in temps}
(ROOT / "eval/results/E20b_blade_groups.json").write_text(json.dumps(
    {"LABEL": "REAL DATA: per-group outcomes from E20", "tone1_law_hz_by_temp_c": law, "tone1_at_20c": round(float(ref[0]), 3), "groups": out}, indent=0))
hs = [g for g in out if g["truth"] == "healthy"]
print(len(out), len(hs), sum(g["old_alarm"] for g in hs), sum(g["verdict"] != "weather only" for g in hs), {c: sum(1 for g in out if g["case"] == c) for c in "ABC"})
print({c: [g["ice_grams"] for g in out if g["case"] == c and g["verdict"] == "ice"] for c in "ABC"})
