# Physica v0.14 — MACE-X Probabilistic Causal Experience Transfer

Built on uploaded v0.13. All previous modules and the Unified Studio are retained.

- New bounded PEL experience memory with empirical source-machine parameter distributions, sensor calibrations, source identifiers, operating range, hash-bound source evidence and failure cases.
- Bayesian mixture adaptation with an evidence-weighted source prior and broad local fallback; explicit out-of-domain refusal, new sensor-conflict refusal and source/target ID isolation.
- Target-dependent safe experimental-design ranking by approximate reduction of future target predictive uncertainty; human review required.
- Cross-sensory calibrated acceleration-proxy mappings (including optional learned linear maps with independent calibration-validation episodes) for audio, motor current, inertial and visual-kinematics measurements; no raw video-to-force fabrication.
- Authentic Meta strategist code behind a private API key + explicit billing consent; structured bounded probe choices; no model-controlled actuation or weight editing. Offline request/replay support for matched single-probe ablations.
- Three-regime learning-curve benchmark with separate source/target machines, 0/1/2/4/8/16/32 B observations, local Bayesian, local active, STLSQ-like sparse, hierarchical source and MACE-X alternatives; bootstrap confidence intervals.
- Prospective file-based real-recording manifest, SHA256 checks, forecast commitment and separate outcome reveal/scoring (NOT independent chronology attestation).
- Added Studio cards for memory, few-shot learning curves, and Meta strategy request preview. All existing three-demo software remains available.

**Evidence boundary:** New results are synthetic. No real Meta call, new hardware trial or scientific novelty claim is provided with this release. Read `docs/V014_PROBABILISTIC_EXPERIENCE_TRANSFER.md`.
