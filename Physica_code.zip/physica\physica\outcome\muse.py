"""Live Muse Spark calls for outcome specs and engineer briefings.

Goes through physica.llm.meta_client.post_raw, so it shares the key from your
terminal (MOCK=0, MODEL_API_KEY), the $ hard stop and the receipts with every
other Meta call. Request shape: /chat/completions with max_completion_tokens
and response_format json_schema.
"""
from __future__ import annotations

import json

from physica.llm import meta_client as mc

MODEL_ROLE = "spark"


def live_enabled() -> bool:
    return not mc.is_mock()


def model() -> str:
    return mc.model_id(MODEL_ROLE)


MODEL = "muse-spark-1.3"


def chat_json(system: str, user: str, schema: dict, task: str, max_tokens: int = 800) -> dict:
    body = {"model": model(), "max_completion_tokens": max_tokens,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "response_format": {"type": "json_schema", "json_schema": schema}}
    out = mc.post_raw("chat/completions", body, task=task, est_usd=0.02)
    return json.loads(out["choices"][0]["message"]["content"])


def brief(plan_json: dict, task: str = "outcome_brief") -> str:
    """Race-engineer briefing written from the plan. Numbers come only from the plan."""
    body = {"model": model(), "max_completion_tokens": 400, "messages": [
        {"role": "system", "content": "You are a race engineer briefing an operator. Use only numbers present "
         "in the plan JSON. Three short sentences: what to do, what it buys, what could go wrong."},
        {"role": "user", "content": json.dumps(plan_json, default=float)}]}
    return mc.post_raw("chat/completions", body, task=task, est_usd=0.01)["choices"][0]["message"]["content"]
