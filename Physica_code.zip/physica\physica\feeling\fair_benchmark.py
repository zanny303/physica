"""Fairer v0.7 synthetic comparison: same target-probe information budget.

All target-adapted methods receive exactly the same measured low-force probe;
no method can see the target main episode while fitting. The target-only model
fits a conventional smooth Coulomb friction coefficient (not a straw man).
"""
from __future__ import annotations
from pathlib import Path
import json
import math
import numpy as np
from scipy.optimize import minimize_scalar
from .core import Interaction,predict_senses
from .demo import make_lab


def estimate_local_friction(probe:Interaction, *, prior_ratio=None, prior_sigma=None):
    """Fit a classical 1-parameter friction law from one target probe.

    The optional transfer prior is a Gaussian *penalty*; zero-prior is an
    independently calibrated target-only mechanistic identification baseline.
    """
    if (prior_ratio is None)!=(prior_sigma is None):raise ValueError('prior requires scale')
    if prior_ratio is not None and (not 0<=prior_ratio<=.8 or not math.isfinite(prior_sigma) or prior_sigma<=0):
        raise ValueError('invalid transferred prior')
    def loss(ratio):
        out=predict_senses(probe.body,probe.times_s,probe.applied_force_n,
                           probe.initial_state_m_m_s,probe.senses,
                           friction_force_n=ratio*probe.body.force_reference_n)
        accum=0.
        for k,s in probe.senses.items():
            error=(np.asarray(probe.observations[k])-out['sensations'][k])/s.noise_std
            accum+=float(np.mean(error**2))
        if prior_ratio is not None:
            accum+=((ratio-prior_ratio)/prior_sigma)**2
        return accum
    fitted=minimize_scalar(loss,bounds=(0.,.8),method='bounded',options={'xatol':1e-5,'maxiter':40})
    if not fitted.success or not math.isfinite(float(fitted.x)):
        raise RuntimeError('friction fitting failed')
    return float(fitted.x)


def evaluate(seed=2026,trials=12):
    if not isinstance(trials,int) or not 1<=trials<=50:raise ValueError('trials 1..50')
    records=[]
    for idx in range(trials):
        d=make_lab(seed+idx)
        target=d['B_main_trial'];probe=d['B_probe_trial']
        source=float(d['source_estimate']['normalized_friction_ratio'])
        target_local=estimate_local_friction(probe)
        mixed=estimate_local_friction(probe,prior_ratio=source,prior_sigma=.15)
        methods={'no_friction':0.,'source_only':source,'target_only_same_probe':target_local,
                 'source_plus_same_probe':mixed}
        actual=np.asarray(target.observations['camera'],float)
        scores={}
        for name,ratio in methods.items():
            y=predict_senses(target.body,target.times_s,target.applied_force_n,
                        target.initial_state_m_m_s,target.senses,
                        friction_force_n=ratio*target.body.force_reference_n)['sensations']['camera']
            scores[name]=float(np.sqrt(np.mean((y-actual)**2)))
        records.append({'seed':seed+idx,'rmse_camera_sensor_units':scores,
                        'target_local_ratio':target_local,'source_ratio':source,
                        'source_plus_probe_ratio':mixed,
                        'probe_interventions_each_target_adapted_method':1})
    keys=list(records[0]['rmse_camera_sensor_units'])
    means={k:float(np.mean([r['rmse_camera_sensor_units'][k] for r in records])) for k in keys}
    return {'schema':'physica.feeling.fair-benchmark.v07','origin':'SYNTHETIC',
            'trials':trials,'average_camera_rmse':means,'unit':'mm',
            'probe_budget_note':'target-only and source-plus-target fit use identical B low-force probe; source-only does not fit on B; target calibration is pre-supplied to all',
            'source_transfer_beats_strong_target_only_count':sum(r['rmse_camera_sensor_units']['source_only']<r['rmse_camera_sensor_units']['target_only_same_probe'] for r in records),
            'caveats':['same smooth friction law generates and fits target data',
                      'one simulated target low-force probe counts toward target adaptation',
                      'these are simulated camera measurements, not Meta or real hardware',
                      'the stronger same-budget model may outperform source transfer'],
            'rows':records}


def save(path,trials=12,seed=2026):
    data=evaluate(seed,trials)
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,indent=2)+'\n');return data
