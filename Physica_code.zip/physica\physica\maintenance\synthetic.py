"""Conspicuously labelled *simulated* test data for a smoke test only."""
from __future__ import annotations
import csv
import json
from pathlib import Path
import numpy as np


def generate(out_dir:str|Path,seed:int=33)->Path:
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(seed)
    train=[f'TRAIN_{i:02d}' for i in range(12)]
    cal=[f'CAL_{i:02d}' for i in range(12)]
    discovery=['SOURCE_DISCOVERY_00']
    test=[f'TEST_{i:02d}' for i in range(6)]
    records=[]
    failure={}; normal_end={}
    for unit in train+cal+discovery+test:
        is_test=unit.startswith('TEST') or unit.startswith('SOURCE_DISCOVERY')
        # Vary load and RPM independently: raw RMS confounds speed with damage.
        machine_jitter=float(rng.normal(0,.012))
        for t in range(90 if is_test else 45):
            speed=1100+180*np.sin(t/12+float(rng.uniform(-.05,.05)))+rng.normal(0,35)
            current=2.5+speed/1800+rng.normal(0,.08)
            # Damage begins late on test machines, never before declared normal_end.
            fatigue=(max(0,t-54)/36)*(.35+.22*(int(unit[-2:])%3)) if is_test else 0.
            amplitude=1+.0009*speed + .17*current+machine_jitter+fatigue+rng.normal(0,.018)
            records.append({'machine_id':unit,'step':t,'vibration_rms':max(.0001,amplitude),
                            'speed_rpm':max(0,speed),'motor_current_a':max(0,current)})
        if is_test:
            failure[unit]=89  # synthetic run-end, not real industrial downtime
            normal_end[unit]=54
        else:normal_end[unit]=44
    csv_path=out/'SIMULATED_MACHINE_SNAPSHOTS.csv'
    with csv_path.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    manifest={'dataset_name':'SYNTHETIC bearing-like signals (not a real dataset)',
         'origin':'simulation','time_unit':'snapshot','measurements_csv':csv_path.name,
         'splits':{'train':train,'calibration':cal,'discovery':discovery,'test':test},
         'healthy_reference_end':{u:normal_end[u] for u in train+cal},
         'failure_steps':failure,'verified_healthy_until':normal_end,
         'failure_event_note':'Synthetic run end only; not real downtime.'}
    p=out/'MANIFEST_SIMULATED.json';p.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return p
