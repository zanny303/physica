"""Predictive physical feeling *while observing* a measured system.

Sequential augmented-state EKF: [displacement, velocity, contact friction ratio].
This is bounded online state/parameter *adaptation*, not autonomous actuation,
causal discovery, human emotion, or a proven estimator for arbitrary machines.
"""
from __future__ import annotations
import numpy as np
from .core import Body,Sense,simulate,_finite


class FeelingSession:
    def __init__(self,body:Body,senses:dict[str,Sense],*,initial_state=(0.,0.),
                 initial_ratio=0.,initial_sigma=(.002,.05,.12),max_surprise_sigma=6.):
        if not senses or any(k!=s.sensor_id for k,s in senses.items()):
            raise ValueError('calibrated sensors must have matching identifiers')
        if not _finite(*initial_state,initial_ratio,*initial_sigma,max_surprise_sigma):
            raise ValueError('nonfinite live estimator initialization')
        if not 0<=initial_ratio<=.8 or min(initial_sigma)<=0 or max_surprise_sigma<=0:
            raise ValueError('invalid live prior')
        self.body=body;self.senses=senses
        self.state=np.array([*initial_state,initial_ratio],dtype=float)
        self.cov=np.diag(np.asarray(initial_sigma)**2)
        self.time_s=0.;self.event_count=0;self.rejection_count=0
        self.max_surprise_sigma=max_surprise_sigma

    def _dynamics_step(self,z,dt,force):
        physics=simulate(self.body,[0.,dt],[force,force],initial_state=z[:2],
                        friction_force_n=z[2]*self.body.force_reference_n)
        return np.array([*physics[-1],z[2]])

    def observe_after_action(self,time_s,applied_force_n,measurements:dict[str,float]):
        if not _finite(time_s,applied_force_n) or time_s<=self.time_s:
            raise ValueError('timestamps must increase; actions and sensor clocks must be synchronized')
        if abs(applied_force_n)>self.body.max_authorized_force_n:
            raise ValueError('applied force outside approved measurement envelope')
        if not isinstance(measurements,dict) or any(k not in self.senses for k in measurements):
            raise ValueError('unknown sensor identifier')
        if not all(_finite(v) for v in measurements.values()):
            raise ValueError('nonfinite sensor values')
        dt=time_s-self.time_s
        if dt*np.sqrt(self.body.stiffness_n_m/self.body.mass_kg)>.35:
            raise ValueError('observations are too sparse for the calibrated model')
        previous=self.state.copy()
        predicted=self._dynamics_step(previous,dt,applied_force_n)
        jac=np.zeros((3,3))
        for i in range(3):
            eps=[1e-6,1e-5,1e-4][i]
            hi=previous.copy();lo=previous.copy()
            hi[i]+=eps;lo[i]-=eps
            # Avoid testing impossible negative contact-force coefficients.
            if i==2 and lo[i]<0:lo[i]=previous[i];denom=eps
            else:denom=2*eps
            jac[:,i]=(self._dynamics_step(hi,dt,applied_force_n)-
                      self._dynamics_step(lo,dt,applied_force_n))/denom
        self.state=predicted
        process=np.diag([1e-8**2,1e-5**2,0.])
        self.cov=jac@self.cov@jac.T+process
        reports={};accepted=0;unexpected=False
        for key,observed in measurements.items():
            sensor=self.senses[key]
            q,v=self.state[:2]
            if not (sensor.state_range_m[0]<=q<=sensor.state_range_m[1] and
                    sensor.velocity_range_m_s[0]<=v<=sensor.velocity_range_m_s[1]):
                self.rejection_count+=1
                reports[key]={'accepted':False,'reason':'outside_independently_calibrated_state_domain'}
                continue
            H=np.array([*sensor.state_gains,0.],dtype=float)
            expected=float(H@self.state+sensor.offset)
            difference=float(observed-expected)
            S=float(H@self.cov@H+sensor.noise_std**2)
            z=float(difference/np.sqrt(S))
            report={'modality':sensor.modality,'unit':sensor.unit,
                    'predicted_sensation':expected,'observed_sensation':float(observed),
                    'prediction_error':difference,'normalized_surprise':z}
            if abs(z)>self.max_surprise_sigma:
                self.rejection_count+=1;unexpected=True
                reports[key]={**report,'accepted':False,
                              'reason':'unexplained_or_corrupted_observation; no parameter update'}
                continue
            K=self.cov@H/S
            posterior=self.state+K*difference
            if not 0<=posterior[2]<=.8 or not (sensor.state_range_m[0]<=posterior[0]<=sensor.state_range_m[1] and sensor.velocity_range_m_s[0]<=posterior[1]<=sensor.velocity_range_m_s[1]):
                self.rejection_count+=1;reports[key]={**report,'accepted':False,'reason':'posterior_outside_physical_domain'}
                continue
            self.state=posterior
            M=np.eye(3)-np.outer(K,H)
            self.cov=M@self.cov@M.T+np.outer(K,K)*sensor.noise_std**2
            self.cov=(self.cov+self.cov.T)*.5
            accepted+=1
            reports[key]={**report,'accepted':True}
        self.time_s=float(time_s);self.event_count+=1
        return {'status':'ABSTAIN_SENSOR_CONFLICT' if unexpected else ('STATE_UPDATED_NOT_YET_VERIFIED' if accepted else 'PREDICTED_WITHOUT_NEW_MEASUREMENT'),
                'time_s':self.time_s,'senses':reports,
                'state_m_m_s':self.state[:2].tolist(),
                'conditional_friction_ratio_estimate':float(self.state[2]),
                'approximate_ratio_sigma':float(np.sqrt(max(self.cov[2,2],0.))),
                'cannot_transfer_parameter_without_heldout_intervention_validation':True,
                'hardware_actuation_allowed':False}
