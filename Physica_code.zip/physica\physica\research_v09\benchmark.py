"""Predeclared group-heldout synthetic study. Never describe as hardware validation.

Scenarios: source-family targets, shifted targets, omitted nonlinear mechanism.
Equal target evidence; ALL source trials disclosed. Reports negative cases.
"""
import argparse,json
from pathlib import Path
import numpy as np
from physica.causal_memory.benchmark import rows
from physica.causal_memory.core import features,prospective,Sensor
from .transfer import build_source_prior,adapt,_rmse

BASE=np.array([-1.2,-.3,1.,-.7,-.08])

def _body(rng,offset=.0,kind='normal'):
    coef=BASE+rng.normal(0,[.006,.008,.006,.12,.012],5)
    coef[3]+=offset
    return coef

def _make_rows(rng,coef,n,body,unknown=0):
    result=rows(rng,coef,n,body,scale=2.0)
    for r in result:
        x,v=r['state']
        r['acceleration']+=unknown*np.sin(4*x)
    return result

def evaluate(seed=900,trials=36,source_bodies=12,source_rows=48):
    if trials<3 or source_bodies<4:raise ValueError('insufficient samples')
    rng=np.random.default_rng(seed)
    sources={f'S{i}':_make_rows(rng,_body(rng),source_rows,f'S{i}') for i in range(source_bodies)}
    prior=build_source_prior(sources,noise_sd=.02)
    outcomes=[]
    for idx in range(trials):
        scenario=['source_family','parameter_shift','unknown_mechanism'][idx%3]
        offset=0. if scenario!='parameter_shift' else float(rng.choice([-1.3,1.3]))
        extra=0. if scenario!='unknown_mechanism' else .65
        target=_body(rng,offset)
        train=_make_rows(rng,target,10,f'T{idx}',extra)
        probe=_make_rows(rng,target,10,f'T{idx}',extra)
        test=_make_rows(rng,target,140,f'T{idx}',extra)
        decision=adapt(prior,train,probe)
        ours=_rmse(test,np.asarray(decision['coefficients']))
        local=_rmse(test,np.asarray(decision['local_coefficients']))
        source=_rmse(test,np.asarray(prior.mean))
        # Separate action-conditioned prospective sensation test: only initial
        # state, planned actions and estimated coefficients are supplied to
        # each model. Neither target receives any future target observations.
        initial=[float(rng.uniform(-.3,.3)),float(rng.uniform(-.15,.15))]
        planned=rng.normal(0,.25,80).tolist();dt=.02
        sensors=[Sensor('camera',1.,0.,.01),Sensor('acoustic',.1,1.,.02)]
        def _trajectory(coef,unknown_term=0.):
            state=np.asarray(initial,float).copy();out=[]
            for action in planned:
                acc=features(state,action)@coef+unknown_term*np.sin(4*state[0])
                state=np.array([state[0]+dt*(state[1]+dt*acc),state[1]+dt*acc])
                out.append([state[0]+.1*state[1],state[1]])
            return np.asarray(out)
        future_truth=_trajectory(target,extra)
        future_ours=_trajectory(np.asarray(decision['coefficients']))
        future_local=_trajectory(np.asarray(decision['local_coefficients']))
        future_error={'selective_transfer':float(np.sqrt(np.mean((future_ours-future_truth)**2))),
                      'local_only':float(np.sqrt(np.mean((future_local-future_truth)**2)))}
        outcomes.append({'target_id':f'T{idx}','scenario':scenario,'decision':decision['choice'],
                         'transfer_accepted':decision['transfer_accepted'],
                         'errors':{'selective_transfer':ours,'local_only':local,'source_only':source},
                         'future_sensation_rmse':future_error,
                         'test_n':len(test)})
    def aggregate(rows):
        if not rows:return {}
        return {'n':len(rows),'rmse_mean':{k:float(np.mean([r['errors'][k] for r in rows])) for k in outcomes[0]['errors']},
                'transfer_wins':int(sum(r['errors']['selective_transfer']<r['errors']['local_only'] for r in rows)),
                'prospective_sensation_rmse':{k:float(np.mean([r['future_sensation_rmse'][k] for r in rows])) for k in ('selective_transfer','local_only')},
                'accepted':int(sum(r['transfer_accepted'] for r in rows)),
                'refused_or_local':int(sum(not r['transfer_accepted'] for r in rows))}
    result={'schema':'physica.research_v09.synthetic.v1','origin':'SIMULATED', 'seed':seed,
            'source_body_count':source_bodies,'source_experiment_count':source_bodies*source_rows,
            'target_fit_experiments_per_body':20,'test_experiments_per_body':140,
            'target_body_holdout':True,'target_test_holdout':True,'selected_using_disjoint_probe':True,
            'model_family':'known five-term physics model; unknown sinusoidal shift intentionally omitted',
            'assumptions':['Source population has nearly shared coefficients for linear terms',
               'Target parameter shift changes primarily the cubic term','Synthetic noise is independent Gaussian',
               'True latent state and accelerations supplied in training; camera/acoustic future forecasts are simulated observation operators',
               'Conventional Bayesian hierarchy and ridge, NOT established novel method'],
            'aggregate':aggregate(outcomes),
            'by_scenario':{s:aggregate([o for o in outcomes if o['scenario']==s]) for s in ('source_family','parameter_shift','unknown_mechanism')},
            'outcomes':outcomes}
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--seed',type=int,default=900);p.add_argument('--trials',type=int,default=36);a=p.parse_args()
    result=evaluate(a.seed,a.trials);path=Path(a.out);path.parent.mkdir(exist_ok=True,parents=True);path.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'origin':'SIMULATED','aggregate':result['aggregate'],'by_scenario':result['by_scenario']},indent=2))
if __name__=='__main__':main()
