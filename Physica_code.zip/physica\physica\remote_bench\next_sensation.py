"""Train an actual next-sensation forecaster on synchronized measured channels.

MOTOR CURRENT IS NOT A CONTROLLED ACTION. This task is prediction conditional on
passive measurements, NOT causal prediction under do(action). Hold out full bodies.
"""
from __future__ import annotations
import hashlib,json
from pathlib import Path
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error
from .train import read_manifest,grouped_split,_load_mat_field,_finite_vector


def _read_raw(row,root):
    path=root/row['path'];fields=row['channels']
    if path.suffix=='.mat':
        vib=np.asarray(_load_mat_field(path,fields['vibration']),float).ravel()
        cur=np.asarray(_load_mat_field(path,fields['current']),float).ravel()
    elif path.suffix=='.csv':
        import csv
        with path.open(newline='') as f: records=list(csv.DictReader(f))
        vib=np.array([float(x[fields['vibration']]) for x in records]);cur=np.array([float(x[fields['current']]) for x in records])
    else:raise ValueError('unsupported extension')
    if len(vib)!=len(cur):raise ValueError('misaligned channels')
    return _finite_vector(vib),_finite_vector(cur)


def windows(vib,cur,*,history=64,horizon=12,max_windows=100):
    if len(vib)<history+horizon+10:raise ValueError('recording too short')
    endpoints=np.unique(np.linspace(history,len(vib)-horizon-1,min(max_windows,len(vib)-history-horizon-1),dtype=int))
    Xv=[];Xc=[];Y=[]
    # Strictly past data only, no future target samples included in any feature vector.
    for t in endpoints:
        Xv.append(vib[t-history:t:4])
        Xc.append(cur[t-history:t:4])
        Y.append(vib[t+horizon])
    return np.array(Xv),np.array(Xc),np.array(Y)


def train_next(manifest_path,out_dir,seed=21):
    from .train import read_manifest
    obj,_,labels,groups,_=read_manifest(manifest_path)
    a,b,gtrain,gtest=grouped_split(labels,groups,seed)
    root=Path(manifest_path).resolve().parent
    sets={'train':{'vibration':[],'current':[],'truth':[]},'test':{'vibration':[],'current':[],'truth':[]}}
    for row,is_train in zip(obj['recordings'],a):
        va,cu=_read_raw(row,root)
        Xv,Xc,Y=windows(va,cu)
        dst=sets['train' if is_train else 'test']
        for name,arr in [('vibration',Xv),('current',Xc),('truth',Y)]:dst[name].append(arr)
    for data in sets.values():
        for k in data:data[k]=np.concatenate(data[k],axis=0)
    train,test=sets['train'],sets['test']
    output=Path(out_dir);output.mkdir(parents=True,exist_ok=True)
    report={'schema':'physica.remote.next_sensation.v1','origin':obj['origin'],
            'train_bodies':gtrain,'test_bodies':gtest,
            'forecast_task':'predict vibration at t+12 samples from strictly prior t-64:t vibration/current histories',
            'current_is_observed_not_randomized_intervention':True,'causal_discovery_verified':False,
            'model':'Ridge regression (linear baseline; NOT Muse or V-JEPA)',
            'metrics':{},'source_sha256':hashlib.sha256(Path(manifest_path).read_bytes()).hexdigest(),
            'units':'RAW SENSOR UNITS; must be calibrated separately for SI claims'}
    for name in ('vibration','current','fusion'):
        if name=='fusion': A=np.column_stack([train['vibration'],train['current']]);B=np.column_stack([test['vibration'],test['current']])
        else:A=train[name];B=test[name]
        normalizer=StandardScaler().fit(A)
        model=Ridge(alpha=5.0).fit(normalizer.transform(A),train['truth'])
        predicted=model.predict(normalizer.transform(B))
        error=float(np.sqrt(mean_squared_error(test['truth'],predicted)))
        report['metrics'][name]={'heldout_rmse_native_units':error,'test_windows':int(len(predicted)),
                 'test_bodies':gtest}
        np.savez_compressed(output/f'{name}_next_weights.npz',coef=model.coef_,intercept=model.intercept_,
                            mean=normalizer.mean_,scale=normalizer.scale_)
    # Untrained equal information persistence baseline.
    persist=test['vibration'][:,-1]
    report['metrics']['persistence']={'heldout_rmse_native_units':float(np.sqrt(mean_squared_error(test['truth'],persist)))}
    (output/'next_sensation_report.json').write_text(json.dumps(report,indent=2)+'\n')
    return report

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('manifest');p.add_argument('--out',required=True)
    a=p.parse_args();print(json.dumps(train_next(a.manifest,a.out)['metrics'],indent=2))
