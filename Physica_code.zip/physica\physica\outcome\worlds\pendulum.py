"""A remote-lab motor (e.g. a CloudPendulum 'DoubleIntegrator' cell at Chalmers): one joint under an impedance
controller, torque = Kp (target - angle) - Kd * speed.

Physica first feels the joint with one gentle probe step at known gains, fits inertia J and friction b from the
response, then picks the gains for the operator's goal (overshoot and settling time), checking every candidate at the
corners of its uncertainty about J and b, so the sealed interval covers the joint it is unsure about.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import least_squares


def simulate(J: float, b: float, kp: float, kd: float, target: float, T: float = 3.0, dt: float = 0.002,
             delay_s: float = 0.0, tau_max: float | None = None) -> tuple[np.ndarray, np.ndarray]:
    n = int(T / dt)
    t = np.arange(n) * dt
    th, w = 0.0, 0.0
    lag = max(int(round(delay_s / dt)), 0)
    hist = [0.0] * (lag + 1)
    out = np.zeros(n)
    for i in range(n):
        th_seen = hist[0]
        tau = kp * (target - th_seen) - kd * w
        if tau_max is not None:
            tau = float(np.clip(tau, -tau_max, tau_max))
        w += dt * (tau - b * w) / J
        th += dt * w
        hist = hist[1:] + [th]
        out[i] = th
    return t, out


def metrics(t: np.ndarray, y: np.ndarray, target: float, band: float = 0.02) -> dict:
    over = max(0.0, (y.max() - target) / abs(target) * 100)
    outside = np.where(np.abs(y - target) > band * abs(target))[0]
    settle = float(t[outside[-1] + 1]) if len(outside) and outside[-1] + 1 < len(t) else (0.0 if not len(outside) else float("inf"))
    return {"overshoot_pct": float(over), "settle_s": settle}


def identify(t: np.ndarray, y: np.ndarray, kp: float, kd: float, target: float) -> dict:
    """Fit J and b to one probe response (log-parameters keep them positive)."""
    t = np.asarray(t, float)
    y = np.asarray(y, float)

    def res(p):
        J, b = np.exp(p)
        ts, ys = simulate(J, b, kp, kd, target, T=float(t[-1]) + 0.01, dt=0.001)
        return np.interp(t, ts, ys) - y  # fine integration, compared at the (possibly uneven) sample times
    r = least_squares(res, x0=np.log([0.01, 0.01]))
    J, b = np.exp(r.x)
    rms = float(np.sqrt(np.mean(r.fun ** 2)))
    return {"J": float(J), "b": float(b), "fit_rms_rad": rms}


@dataclass
class PendulumWorld:
    J: float
    b: float
    target: float
    J_unc: float = 0.15
    b_unc: float = 0.30
    tau_max: float = 0.5
    delay_s: float = 0.01
    machine: str = "pendulum"
    knob: str = "impedance gains"

    def corners(self):
        return [(self.J * (1 + sj * self.J_unc), self.b * (1 + sb * self.b_unc)) for sj in (-1, 0, 1) for sb in (-1, 0, 1)]

    def candidates(self, spec, state):
        return [{"kp": float(kp), "kd": float(kd)} for kp in np.geomspace(0.05, 5.0, 18)
                for kd in np.geomspace(0.002, 0.5, 18)]

    def outcome(self, a):
        if "kp" not in a:
            return {"refused": True, "why": "no gains set yet"}
        rows = []
        for J, b in self.corners():
            t, y = simulate(J, b, a["kp"], a["kd"], self.target, delay_s=self.delay_s, tau_max=self.tau_max)
            rows.append(metrics(t, y, self.target))
        ov = [r["overshoot_pct"] for r in rows]
        st = [r["settle_s"] for r in rows]
        return {"refused": False, "overshoot_pct": ov[4], "settle_s": st[4], "overshoot_hi": max(ov), "settle_hi": max(st),
                "overshoot_lo": min(ov), "settle_lo": min(st)}

    def feasible(self, spec, pred, use_error_bar: bool = True):
        if pred.get("refused"):
            return False, pred["why"]
        ov_max = spec.get("overshoot_pct", "<=")
        st_max = spec.get("settle_s", "<=")
        ov = pred["overshoot_hi"] if use_error_bar else pred["overshoot_pct"]
        st = pred["settle_hi"] if use_error_bar else pred["settle_s"]
        ok = (ov_max is None or ov <= ov_max) and (st_max is None or st <= st_max)
        return ok, f"worst case {ov:.1f}% overshoot, settles by {st:.2f} s"

    def cost(self, spec, a, pred, state):
        return (pred["settle_hi"], a["kp"])

    def describe(self, a, pred, state):
        return (f"set Kp={a['kp']:.3f} Nm/rad, Kd={a['kd']:.4f} Nm s/rad: settles in {pred['settle_s']:.2f} s "
                f"(sealed {pred['settle_lo']:.2f}-{pred['settle_hi']:.2f} s), overshoot {pred['overshoot_pct']:.1f}% "
                f"(sealed {pred['overshoot_lo']:.1f}-{pred['overshoot_hi']:.1f}%)")
