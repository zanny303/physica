"""Selective hierarchical physical experience transfer (research candidate).

Learn a distribution of action-conditioned physical mechanisms from MANY SOURCE
BODIES. Regularize the small target-data fit toward only empirically stable
source relationships. Select transfer on a disjoint target probe, then refit
on all authorized target observations. Fallback to local when source fails.

This is empirical Bayes / regularized system ID, not a claimed novel theorem.
All observations MUST be controlled interventions with physical calibration.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from physica.causal_memory.core import features

@dataclass(frozen=True)
class SourcePrior:
    mean: tuple[float, ...]
    variance: tuple[float, ...]
    body_count: int
    source_observations: int


def _design(rows):
    if len(rows)<6: raise ValueError('at least six controlled observations required')
    if any(r.get('intervention_type')!='controlled' for r in rows):
        raise ValueError('passive data cannot be labelled causal')
    X=np.stack([features(r['state'],r['action']) for r in rows])
    y=np.asarray([r['acceleration'] for r in rows],float)
    if not np.isfinite(y).all() or np.linalg.norm(X)>1e8: raise ValueError('invalid observations')
    return X,y


def _posterior(rows,prior=None, noise_sd=.02, floor=1e-5):
    if noise_sd<=0 or not np.isfinite(noise_sd):raise ValueError('invalid measurement noise')
    X,y=_design(rows)
    # stable, fully specified Bayesian linear regression; no hidden test access
    precision=np.eye(X.shape[1])*floor
    rhs=X.T@y/noise_sd**2
    precision+=X.T@X/noise_sd**2
    if prior is not None:
        mu=np.asarray(prior.mean,float);var=np.asarray(prior.variance,float)
        if mu.shape!=(5,) or var.shape!=(5,) or np.any(var<=0) or not np.isfinite(mu).all() or not np.isfinite(var).all():
            raise ValueError('invalid source prior')
        inv=1/var
        precision+=np.diag(inv);rhs+=mu*inv
    try: coef=np.linalg.solve(precision,rhs)
    except np.linalg.LinAlgError as exc:raise ValueError('unidentifiable dynamics') from exc
    if not np.isfinite(coef).all():raise ValueError('unstable parameter estimate')
    return coef


def build_source_prior(source_bodies,noise_sd=.02, min_variance=0.0004):
    """Hierarchical prior learned only from different source bodies.

    Includes epistemic estimation noise in source-fit variance; prevents exact
    zero variance (false certainty) and avoids data from any target machine.
    """
    if len(source_bodies)<4:raise ValueError('need >=4 separate source bodies')
    estimates=[];n=0
    for body_id,body_rows in source_bodies.items():
        if len(body_rows)<15:raise ValueError('source body has too few experiments')
        if any(r.get('body_id')!=body_id for r in body_rows):raise ValueError('source-body identity mismatch')
        estimates.append(_posterior(body_rows,noise_sd=noise_sd))
        n+=len(body_rows)
    E=np.stack(estimates)
    mean=E.mean(axis=0)
    # Between-body variance + conservative variance floor.
    var=np.maximum(E.var(axis=0,ddof=1), min_variance)
    # Mechanism-specific conservative floors: variable nonlinear effects should
    # not be over-transported even when source bodies look deceptively similar.
    var[3]=max(var[3]*25, 0.5)
    var[4]=max(var[4]*10, 0.12)
    return SourcePrior(tuple(mean.tolist()),tuple(var.tolist()),len(E),n)


def _rmse(rows,coef):
    X,y=_design(rows)
    return float(np.sqrt(np.mean((X@coef-y)**2)))


def adapt(prior,local_rows,probe_rows,noise_sd=.02,relative_tolerance=.04):
    """Target-only and source-regularized estimates use the SAME target data.

    Select policy using the probe BEFORE adding probe to final fit. Candidate
    fits initially use local_rows only. Selection is not used to tune a model
    on final held-out target trials. Reports source failure and refuses when
    neither model explains the probe within a conservative noise threshold.
    """
    if relative_tolerance<0:raise ValueError('invalid tolerance')
    local_X,ly=_design(local_rows);px,py=_design(probe_rows)
    all_rows=local_rows+probe_rows
    local_pre=_posterior(local_rows,noise_sd=noise_sd)
    transfer_pre=_posterior(local_rows,prior,noise_sd=noise_sd)
    local_probe=float(np.sqrt(np.mean((px@local_pre-py)**2)))
    transfer_probe=float(np.sqrt(np.mean((px@transfer_pre-py)**2)))
    # No automatic transfer when the prior is contradicted by independent probe.
    allow_transfer=transfer_probe<=local_probe*(1+relative_tolerance)
    selected=prior if allow_transfer else None
    final=_posterior(all_rows,selected,noise_sd=noise_sd)
    local_final=_posterior(all_rows,noise_sd=noise_sd)
    # Unmodelled dynamics: refuse strong claims; report diagnostic only.
    gross_mismatch=min(local_probe,transfer_probe)>max(.12,6*noise_sd)
    if gross_mismatch:
        final=local_final  # never let a rejected source contaminate a fallback
    return {'coefficients':final.tolist(),'local_coefficients':local_final.tolist(),
            'choice':'probe_first_model_mismatch' if gross_mismatch else ('source_prior' if allow_transfer else 'local_only'),
            'transfer_accepted':bool(allow_transfer and not gross_mismatch),
            'probe_rmse_transfer':transfer_probe,'probe_rmse_local':local_probe,
            'source_bodies':prior.body_count,'source_experiments':prior.source_observations,
            'target_experiments':len(all_rows), 'probe_was_held_out_during_model_choice':True,
            'calibration_noise_sd':noise_sd}


def predict_future(model,initial_state,planned_actions,dt,sensors):
    """No future measurements accepted. Reuses prospective physical integrator."""
    from physica.causal_memory.core import prospective
    if model.get('choice')=='probe_first_model_mismatch':
        raise ValueError('mechanism mismatch: refuse prospective forecast')
    return prospective(initial_state,planned_actions,dt,model['coefficients'],sensors)
