"""Offline benchmark and memory export; no unapproved network or hardware work."""
from __future__ import annotations
import argparse,json
from pathlib import Path
from .benchmark import run,save,task
from .core import fit_target,rank_probes,posterior_summary


def main(argv=None):
    p=argparse.ArgumentParser(description='Physica v0.14 source-to-target probabilistic experience transfer')
    sub=p.add_subparsers(dest='cmd',required=True)
    b=sub.add_parser('benchmark');b.add_argument('--seeds',type=int,default=12)
    b.add_argument('--out',required=True)
    d=sub.add_parser('example');d.add_argument('--seed',type=int,default=1234)
    d.add_argument('--out',required=True)
    m=sub.add_parser('meta-advise');m.add_argument('--seed',type=int,default=1234)
    m.add_argument('--out',required=True)
    m.add_argument('--model',choices=('muse-spark-1.3','muse-wonder-1.0'),default='muse-wonder-1.0')
    m.add_argument('--allow-billed-meta',action='store_true')
    m.add_argument('--preview-only',action='store_true')
    r=sub.add_parser('meta-replay');r.add_argument('--seed',type=int,default=1234)
    r.add_argument('--nomination',required=True);r.add_argument('--out',required=True)
    args=p.parse_args(argv)
    if args.cmd=='benchmark':
        result=run(args.seeds)
        save(result,args.out)
        print(json.dumps({'path':args.out,'source':'SIMULATION_ONLY',
                          'target_machines':result['target_machine_count'],
                          'budgets':result['budgets']}))
    else:
        if args.cmd=='meta-replay':
            from .meta_strategy import replay_one_probe
            path=Path(args.nomination)
            raw=json.loads(path.read_text(encoding='utf-8'))
            # A real Meta advice artifact wraps the proposed structured choice.
            reply=raw.get('proposal',raw)
            result=replay_one_probe(reply,task(args.seed),
                 origin='SAVED_LIVE_META_REPLY_UNVERIFIED' if raw.get('origin','').startswith('AUTHENTICATED_META')
                 else 'OFFLINE_USER_SUPPLIED')
            save(result,args.out)
            print(json.dumps({'path':args.out,'meta_status':result['meta_status']}))
            return
        if args.cmd=='meta-advise' and not args.preview_only and not args.allow_billed_meta:
            raise PermissionError('explicit --allow-billed-meta required to run actual Meta inference')
        sim=task(args.seed)
        posterior=fit_target([],sim['memory'],mode='mixture',target_id=sim['target_id'])
        decision=rank_probes(posterior,sim['candidates'],sim['queries'])
        if args.cmd=='meta-advise':
            from .meta_strategy import request_preview,live_advise
            if args.preview_only:
                preview,options=request_preview(decision,sim['candidates'],model=args.model)
                result={'schema':'physica.mace_x.meta_preview.v014','origin':'OFFLINE_PREVIEW_NO_API',
                        'request':preview,'offered_approved_candidates':options,
                        'note':'Meta would be offered only these human-review candidate probes. No response has been obtained.'}
            else:
                result=live_advise(decision,sim['candidates'],model=args.model,allow_billed=args.allow_billed_meta)
            save(result,args.out)
            print(json.dumps({'path':args.out,'status':result.get('status','OFFLINE_PREVIEW_NO_API')}))
            return
        result={'schema':'physica.mace_x.example.v014','origin':'SIMULATION_ONLY',
                'PEL_probabilistic_experience_memory':sim['memory'].to_dict(),
                'target_initial_posterior':posterior_summary(posterior),
                'first_requested_probe':decision['ranked'][0],
                'probe_executed':False,'Meta_called':False,
                'interpretation':'Probe proposal only; human approval and measured outcome required.'}
        save(result,args.out)
        print(json.dumps({'path':args.out,'first_probe':decision['ranked'][0]['index']}))
if __name__=='__main__':main()
