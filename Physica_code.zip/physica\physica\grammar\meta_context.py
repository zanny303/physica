"""Meta's grounded SCIENTIST role, with a hard boundary to calibrated evidence.

Live calls require the owner's own MODEL_API_KEY. Offline recorded responses may
exercise parsing, NEVER claim to be real Meta observations or numeric authority.
"""
from __future__ import annotations
import hashlib,json
from pathlib import Path
from .signals import MechanicalContext
from .fusion import rank_hypotheses


def curate_context_reply(reply,*,candidate_labels,allowed_actions,evidence_hash):
    """Sanitize untrusted Muse text into candidate hints, not physical truths."""
    if len(evidence_hash)!=64:raise ValueError('source media SHA256 required')
    if not isinstance(reply,dict):raise ValueError('Muse reply object needed')
    hints=[]
    for item in reply.get('hypotheses',[]):
        if not isinstance(item,dict):continue
        label=item.get('name')
        if label in candidate_labels and label not in hints:hints.append(label)
    proposal=reply.get('suggested_action')
    if proposal not in allowed_actions:proposal=None
    return {'model_claims_not_sensor_data':True,
            'candidate_hypotheses':hints,
            'suggested_action':proposal,
            'scene_context_unverified':str(reply.get('context',''))[:700],
            'evidence_sha256':evidence_hash,
            'risk_authority':False,'numeric_measurement_authority':False,
            'requires_independent_context_calibration':True}


def fuse_context_and_physics(channels,candidates,context_hints=None):
    """Hypotheses always scored by sensor likelihood. Context hints do not
    alter priors without a separately validated reliability study.
    """
    numerical=rank_hypotheses(channels,candidates)
    return {'physical_ranking':numerical,
            'meta_context_hints':context_hints or None,
            'note':'Muse context is hypothesis proposal, not a replacement for calibrated observations',
            'hardware_actuation_allowed':False}


def live_muse_scientist(facts,allowed_actions,*,video_path=None,role='wonder'):
    from physica.experience.meta_live import muse_scientist
    if video_path is not None:
        p=Path(video_path)
        if not p.exists():raise FileNotFoundError(p)
    return muse_scientist(facts,allowed_actions,role=role,video_path=video_path)


def safe_experiment_choice(prior,experiments,muse_hint=None):
    from physica.experience.pacer import choose_experiment
    choice=choose_experiment(prior,experiments,max_risk=.12)
    # Physica's causal numeric selection and safety whitelist are authoritative.
    # Meta can explain or propose but cannot change the winning action.
    return {'selection':choice,
            'meta_suggested_action':muse_hint,
            'meta_matched':muse_hint==choice.get('chosen'),
            'no_unattended_actuation':True}


def model_status():
    from physica.experience.meta_live import preflight
    status=preflight()
    status['physics_bridge']='context-hypotheses-only until calibrated intervention/grounding evaluation'
    status['sam_role']='pixel mask/track; independent camera scale and clock mandatory'
    status['v_jepa_role']='latent dynamics; independent heldout readout required for SI predictions'
    status['glimmer_role']='optional local scene descriptions; never a physical sensor'
    return status
