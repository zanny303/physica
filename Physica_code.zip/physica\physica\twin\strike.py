"""A digital twin of a real struck beam, from high-speed film alone. It sees only the first moments after the hit, then forecasts the rest of the ringing, and the raw pixels grade it."""
from __future__ import annotations

import numpy as np
from scipy.signal import hilbert

SECTIONS = 20


def _grey(film) -> np.ndarray:
    import cv2
    cap = cv2.VideoCapture(str(film))
    out = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        out.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY))
    cap.release()
    return np.stack(out).astype(np.float32)


def motion(grey: np.ndarray, before: int = 6) -> np.ndarray:
    """Up-and-down motion of each section along the beam, in pixels, by brightness gradient, measured against the frames before the hit."""
    T, h, w = grey.shape
    width = w // SECTIONS
    rest = grey[:before].mean(axis=0)
    rows = []
    for i in range(SECTIONS):
        a, b = i * width, (i + 1) * width
        g = np.gradient(rest[:, a:b], axis=0)
        rows.append(((grey[:, :, a:b] - rest[:, a:b]) * g).sum(axis=(1, 2)) / max(float((g ** 2).sum()), 1e-6))
    return np.array(rows).T


def _fit(y: np.ndarray, step: int = 5) -> dict:
    """The simplest ringing model: one decaying tone, found by ESPRIT from the samples given. Nothing later in the film is used."""
    x = y[::step]
    N, L = len(x), len(x) // 2
    H = np.array([x[i:i + L] for i in range(N - L + 1)])
    U = np.linalg.svd(H, full_matrices=False)[0][:, :2]
    z = np.linalg.eigvals(np.linalg.pinv(U[:-1]) @ U[1:])
    z = z[np.abs(z) < 1]
    V = np.vander(z, N, increasing=True).T
    c = np.linalg.lstsq(V, x.astype(complex), rcond=None)[0]
    return {"z": z, "c": c, "step": step, "hz": float(abs(np.angle(z[0])) * 10000.0 / step / (2 * np.pi)), "decay": float(-np.log(abs(z[0])) * 10000.0 / step)}


def predict(fit: dict, n: int) -> np.ndarray:
    k = np.arange(n) / fit["step"]
    return np.real(sum(ci * zi ** k for ci, zi in zip(fit["c"], fit["z"])))


def read(film, fps: float = 10000.0, learn_s: float = 0.03, grade_s: float = 0.05) -> dict:
    grey = _grey(film)
    m = motion(grey)
    u, s, vt = np.linalg.svd(m - m[:6].mean(axis=0), full_matrices=False)
    y = u[:, 0] * s[0]
    if abs(y.min()) > abs(y.max()):
        y, vt = -y, -vt
    hit = int(np.argmax(np.abs(y) > .15 * np.abs(y).max()))
    y = y[hit:]
    n1, n2 = int(learn_s * fps), int((learn_s + grade_s) * fps)
    learned = _fit(y[:n1])
    guess = predict(learned, n2)
    r = float(np.corrcoef(guess[n1:n2], y[n1:n2])[0, 1])
    err = float(np.sqrt(((guess[n1:n2] - y[n1:n2]) ** 2).mean()))
    rest = float(np.sqrt(((y[n1:n2] - y[n1:n2].mean()) ** 2).mean()))
    full = _fit(y[:n2])
    shape = np.abs(vt[0]) / np.abs(vt[0]).max()
    gw, gh = SECTIONS, 8
    return {"status": "MEASURED", "tone_hz": round(full["hz"], 2), "damping": round(full["decay"] / (2 * np.pi * full["hz"]), 4), "decay_per_s": round(full["decay"], 1), "direction": "vertical", "fps": fps,
            "field": {"w": gw, "h": gh, "data": [round(float(v), 3) for v in np.tile(shape, (gh, 1)).ravel()]},
            "holdout": {"learned_on_s": learn_s, "predicted_s": grade_s, "learned_hz": round(learned["hz"], 2), "learned_decay_per_s": round(learned["decay"], 1), "match_r": round(r, 2), "closer_than_stopping_pct": round(100 * (1 - err / rest))},
            "biggest_motion_px": round(float(np.abs(y).max()), 2), "trace": {"real": [round(float(v), 3) for v in y[:n2]], "forecast": [round(float(v), 3) for v in guess], "learned_samples": n1, "fps": fps}, "shape": [round(float(v), 3) for v in shape]}
