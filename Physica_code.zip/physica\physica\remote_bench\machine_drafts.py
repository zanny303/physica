"""Muse suggests an action; Physica emits machine-specific code only from verified units.

No model-generated code is executed. All outputs are OFFLINE, NON-EXECUTING DRAFTS
for supervised review, not flight, printer, or PLC authorization.
"""
from __future__ import annotations
from pathlib import Path
import hashlib, json, math
from physica.translate.gcode import marlin_m593,klipper_input_shaper
from physica.translate.ardupilot import notch_params

ALLOWED=('marlin_input_shaper','klipper_input_shaper','ardupilot_harmonic_notch')


def draft(evidence, model_reply=None, *, approved_target=None):
    if not isinstance(evidence,dict):raise ValueError('evidence must be a record')
    if evidence.get('status')!='verified_sensor_fit' or evidence.get('independent_calibration') is not True:
        raise ValueError('independently calibrated measured evidence required; text or simulated evidence cannot authorize a machine draft')
    if evidence.get('origin') not in ('external_recorded','supervised_physical_experiment'):
        raise ValueError('source must be recorded real data')
    freq=evidence.get('resonance_frequency_hz');damp=evidence.get('damping_ratio')
    if not all(isinstance(x,(int,float)) and math.isfinite(x) for x in (freq,damp)):
        raise ValueError('physical frequency and damping must be finite measured numbers')
    if not (2<=freq<=180 and .001<=damp<.8):raise ValueError('out of calibrated domain')
    allowed=set(evidence.get('approved_draft_targets',[])) & set(ALLOWED)
    if not allowed:raise ValueError('no approved machine target')
    suggestion=(model_reply or {}).get('suggested_action')
    selection=approved_target or suggestion
    if selection not in allowed:raise ValueError('requested machine action not in independently approved draft whitelist')
    explanation=str((model_reply or {}).get('context',''))[:350]
    if selection=='marlin_input_shaper':
        commands='\n'.join(marlin_m593(freq,damp,axes='XY'))
        suffix='.gcode'
    elif selection=='klipper_input_shaper':
        commands=klipper_input_shaper(freq,freq,'mzv')
        suffix='.cfg'
    else:
        # Drone controls are flight-critical. Draft only, never auto-flash.
        params=notch_params(freq, bandwidth_hz=max(1,freq/2),mode=0)
        commands='\n'.join(f'{k},{v}' for k,v in params.items())
        suffix='.param'
    ev_hash=hashlib.sha256(json.dumps(evidence,sort_keys=True).encode()).hexdigest()
    response={'schema':'physica.machine_review_draft.v1','status':'REVIEW_REQUIRED_NOT_ACTUATED',
              'draft_target':selection,'suffix':suffix,
              'grounded_in_verified_physical_evidence_sha256':ev_hash,
              'model_supplied_context_not_measurement':explanation,
              'measurements':{'resonance_frequency_hz':freq,'damping_ratio':damp},
              'instructions':commands,
              'safety_requirements':['Do not apply automatically','Check exact target firmware and hardware',
                  'Bench-test with a qualified supervisor','Require remeasurement and rollback plan'],
              'muse_generated_raw_code_executed':False}
    return response


def save_draft(report,out_dir):
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    (out/'proposal.json').write_text(json.dumps(report,indent=2)+'\n')
    # Explicit NON-ACTUATING prefix; never silently turn a model answer into commands.
    (out/f'DRAFT_REVIEW_ONLY{report["suffix"]}').write_text(
        '# PHYSICA DRAFT — MANUAL REVIEW REQUIRED; NOT ACTUATED\n'
        +report['instructions']+'\n')
    return out
