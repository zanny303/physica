"""Embeddings -> *measured physical quantities* with independent calibration.

V-JEPA 2/2-AC are latent video world models, NOT displacement estimators.
This bridge consumes embeddings EXPORTED by an external documented encoder and
separate sensor ground truth, splitting by body ID to prevent train/test leakage.
A live V-JEPA 2 checkpoint inference is not claimed here.
"""
from __future__ import annotations
from dataclasses import dataclass
import json
from pathlib import Path
import numpy as np
from .dual_world import CalibratedForecast


@dataclass
class VisualReadout:
    observable:str
    unit:str
    source_model_id:str
    coefficient:list[float]
    bias:float
    sigma:float
    calibration_evidence:str
    training_bodies:list[str]
    calibration_bodies:list[str]
    features:int

    def forecast(self,embedding,*,body_id:str):
        if body_id in self.training_bodies or body_id in self.calibration_bodies:
            raise ValueError('held-out body required for trustworthy evaluation')
        v=np.asarray(embedding,dtype=float)
        if v.shape!=(self.features,) or not np.all(np.isfinite(v)):
            raise ValueError('bad encoder embedding')
        return CalibratedForecast(self.observable,self.unit,float(v@self.coefficient+self.bias),
                                  float(self.sigma),self.source_model_id,'model',
                                  self.calibration_evidence)


def _rows(path):
    x=json.loads(Path(path).read_text())
    if not isinstance(x,list) or not x:raise ValueError('nonempty list of embedding/observation records required')
    for r in x:
        if not all(k in r for k in ('body_id','embedding','measured_value','unit','observable','embedding_model_id')):
            raise ValueError('missing ground-truth or provenance field')
        if not np.all(np.isfinite(r['embedding'])) or not np.isfinite(r['measured_value']):
            raise ValueError('nonfinite sensor data')
    return x


def fit_readout(training_json,calibration_json,*,ridge=1.,min_calibration_bodies=8):
    train=_rows(training_json);cal=_rows(calibration_json)
    attrs={(r['unit'],r['observable'],r['embedding_model_id']) for r in train+cal}
    if len(attrs)!=1:raise ValueError('incommensurate units or incompatible embedding models')
    ids1={r['body_id'] for r in train};ids2={r['body_id'] for r in cal}
    if ids1 & ids2:raise ValueError('leakage across calibration split')
    if len(ids2)<min_calibration_bodies:raise ValueError('insufficient independent calibration machines')
    X=np.asarray([r['embedding'] for r in train],dtype=float)
    Xc=np.asarray([r['embedding'] for r in cal],dtype=float)
    if X.ndim!=2 or Xc.ndim!=2 or X.shape[1]!=Xc.shape[1]:raise ValueError('embedding sizes differ')
    if ridge<=0:raise ValueError('positive ridge required')
    y=np.asarray([r['measured_value'] for r in train]);yc=np.asarray([r['measured_value'] for r in cal])
    means=X.mean(axis=0); ym=y.mean()
    # ridge with centered features; intercept not regularized
    w=np.linalg.solve((X-means).T@(X-means)+ridge*np.eye(X.shape[1]),(X-means).T@(y-ym))
    bias=float(ym-means@w)
    diffs=np.abs(Xc@w+bias-yc)
    # finite sample conservative quantile for nominal 90% single-point prediction
    n=len(diffs);idx=int(np.ceil(.90*(n+1)))-1
    sigma=float(np.partition(diffs,min(idx,n-1))[min(idx,n-1)]/1.645)
    if idx>=n or sigma<=0:raise ValueError('unable to establish calibration; more independent bodies required')
    observable,unit,mid=next(iter(attrs))[1],next(iter(attrs))[0],next(iter(attrs))[2]
    evidence=f'heldout-body-split:{Path(calibration_json).name}:n={len(ids2)}; nominal90 absolute residual'
    return VisualReadout(observable,unit,mid,w.tolist(),bias,sigma,evidence,
                         sorted(ids1),sorted(ids2),X.shape[1])


def export_forecast(readout:VisualReadout,embedding_path,*,body_id,out):
    vec=json.loads(Path(embedding_path).read_text())
    e=vec['embedding'] if isinstance(vec,dict) else vec
    forecast=readout.forecast(e,body_id=body_id)
    data=forecast.__dict__
    Path(out).write_text(json.dumps(data,indent=2)+'\n')
    return data
