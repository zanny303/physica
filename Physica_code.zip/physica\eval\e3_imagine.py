"""E3: Imagine. Train on failures that never happened, test on real ones (Fraunhofer rig).

The proven wobble model (healthy 0D + one known level 1D) synthesises once-per-turn amplitudes for many
imbalance sizes and speeds, with noise measured on healthy data. A detector/regressor is trained on these
SYNTHETIC windows only, then tested on the REAL evaluation files 0E-4E.
Compared with: (a) a model trained on real dev data at every level (upper bound, needs real failures),
(b) a healthy-only anomaly threshold (no imbalance size, just 'unusual').
"""
from __future__ import annotations

import argparse

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor

from common import SEED, save_result
from physica.data import fraunhofer as FH
from physica.feel.axes import WobbleCalibrator


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-rows", type=int, default=None)
    ap.add_argument("--root", default=None)
    a = ap.parse_args(argv)
    rng = np.random.default_rng(SEED)
    load = lambda n: FH.order1_windows(FH.load(n, a.root, a.max_rows))
    h, k = load("0D"), load("1D")
    cal = WobbleCalibrator().fit(h["speed_hz"], h["a1_combined"], k["speed_hz"], k["a1_combined"], FH.LEVELS_GMM[1])
    base_h = np.interp(h["speed_hz"], cal.speeds, cal.base)
    rel_noise = (h["a1_combined"] - base_h) / np.maximum(base_h, 1e-12)
    # imagine: many imbalance sizes x observed speeds, with real healthy noise
    n = 20000
    sp = rng.choice(h["speed_hz"], n)
    sp = sp[(sp >= cal.speeds.min()) & (sp <= cal.speeds.max())]
    mr = rng.uniform(0, 200, len(sp))
    a1 = np.interp(sp, cal.speeds, cal.base) * (1 + rng.choice(rel_noise, len(sp))) + np.interp(sp, cal.speeds, cal.gain) * mr
    syn = GradientBoostingRegressor(random_state=SEED).fit(np.c_[sp, a1], mr)
    # upper bound: trained on REAL dev data, every level
    Xr, yr = [], []
    for lv in range(5):
        try:
            d = load(f"{lv}D")
        except FileNotFoundError:
            continue
        Xr.append(np.c_[d["speed_hz"], d["a1_combined"]]); yr.append(np.full(len(d["speed_hz"]), FH.LEVELS_GMM[lv]))
    real = GradientBoostingRegressor(random_state=SEED).fit(np.vstack(Xr), np.concatenate(yr))
    thr = np.quantile(rel_noise, 0.99)
    rows = {}
    for lv in range(5):
        try:
            d = load(f"{lv}E")
        except FileNotFoundError:
            continue
        X = np.c_[d["speed_hz"], d["a1_combined"]]
        inside = (d["speed_hz"] >= cal.speeds.min()) & (d["speed_hz"] <= cal.speeds.max())
        rel = (d["a1_combined"] - np.interp(d["speed_hz"], cal.speeds, cal.base)) / np.interp(d["speed_hz"], cal.speeds, cal.base)
        rows[f"{lv}E"] = {"true_gmm": FH.LEVELS_GMM[lv],
                          "imagined_trained_median_gmm": float(np.median(syn.predict(X[inside]))),
                          "real_trained_median_gmm": float(np.median(real.predict(X))),
                          "healthy_only_anomaly_rate": float(np.mean(rel[inside] > thr))}
    t = np.array([r["true_gmm"] for r in rows.values()])
    summary = {}
    for key in ("imagined_trained_median_gmm", "real_trained_median_gmm"):
        e = np.array([r[key] for r in rows.values()])
        summary[key.replace("_median_gmm", "_mean_abs_err_gmm")] = float(np.mean(np.abs(e - t)))
    out = {"note": "Imagined model saw healthy data + one known level only; real model saw real data at every level.",
           "rows": rows, "summary": summary, "max_rows": a.max_rows}
    save_result("E3_imagine", out)
    for n_, r in rows.items():
        print(n_, {k: round(v, 3) for k, v in r.items()})
    print("summary:", summary)


if __name__ == "__main__":
    main()
