"""E21 - A real railway bridge: is it winter, or did the structure change? (KW51, Leuven; REAL DATA, run locally)

KW51 is a steel bowstring arch railway bridge monitored by KU Leuven from Oct 2018 to Jan 2020 (Maes & Lombaert,
J. Bridge Eng. 26(3) 2021; data doi:10.5281/zenodo.3745914, CC BY 4.0). During monitoring, damage was found at
connections and the bridge was strengthened: works from 15 May 2019; the "after" period starts 27 Sep 2019.
Physica learns each mode's law with the steel temperature (with a freezing knot) from the months BEFORE the works
only, then judges every day: weather only, or changed - and in which direction, which tells which causes are possible.
Download `trackedmodes.zip` (13 MB) from the Zenodo record, unzip, and set PHYSICA_KW51=<path to trackedmodes.mat>.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import sys
from collections import Counter
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica.cause.monitor import Monitor  # noqa: E402

OUT = ROOT / "eval" / "results"
WORKS, AFTER = np.datetime64("2019-05-15"), np.datetime64("2019-09-27")
MODES = (3, 5, 6, 9, 13)  # tracked at least 80% of the time in every period (as in prior work on this bridge)


def load(path):
    import scipy.io as sio
    m = sio.loadmat(path, squeeze_me=True, struct_as_record=False)["modes"]
    t = np.array([np.datetime64(dt.datetime.fromordinal(int(x)) + dt.timedelta(days=float(x) % 1) - dt.timedelta(days=366), "m")
                  for x in np.atleast_1d(m.sdn)])
    labels = [str(s) for s in np.atleast_1d(m.labels_env)]
    env = np.atleast_2d(m.env)
    temp = env[:, labels.index("tBD31A")] if "tBD31A" in labels else env[:, 0]
    F = np.atleast_2d(m.f)[:, [k - 1 for k in MODES]]
    return t, F, temp


def main(path=None):
    t, F, T = load(path or os.environ["PHYSICA_KW51"])
    day = t.astype("datetime64[D]")
    month = t.astype("datetime64[M]")
    before = t < WORKS
    mon = Monitor()
    models = mon.learn(F[before], T[before], month[before])
    R = mon.residual(F, T)
    mon.learn_noise(R[before], day[before])
    days, M = mon.daily(R, day)
    verdicts = [mon.judge_day(r) for r in M]
    v = [x["verdict"] for x in verdicts]
    bdays = days < WORKS
    adays = days >= AFTER
    first = mon.first_persistent(days[days >= WORKS], [x for x, d in zip(v, days) if d >= WORKS])
    # temperature-blind baseline: residual against the mean before-period frequency, same daily noise rule
    raw = np.log(F) - np.nanmean(np.log(F[before]), 0)
    dr, Mr = mon.daily(raw, day)
    bl = Monitor()
    bl.cov = np.cov(Mr[(dr < WORKS) & np.isfinite(Mr).all(1)].T)
    bl.sd = np.sqrt(np.diag(bl.cov))
    vb = [bl.judge_day(r)["verdict"] for r in Mr]
    res = {"LABEL": "REAL DATA: KW51 railway bridge, Leuven (Maes & Lombaert 2021)", "modes": MODES,
           "temperature_laws": [{"mode": k, "freezing_knot_C": m["knot"], "cv_rmse_pct": round(m["cv_rmse_pct"], 3)}
                                for k, m in zip(MODES, models)],
           "before_days": int(bdays.sum()),
           "false_alarm_days_before": {"physica": int(sum(x != "weather only" for x, b in zip(v, bdays) if b)),
                                       "temperature_blind": int(sum(x != "weather only" for x, b in zip(vb, bdays) if b))},
           "after_days_flagged": {"physica": float(np.mean([x != "weather only" for x, a in zip(v, adays) if a])),
                                  "temperature_blind": float(np.mean([x != "weather only" for x, a in zip(vb, adays) if a]))},
           "after_days_verdicts": dict(Counter(x for x, a in zip(v, adays) if a)),
           "first_persistent_change_after_works_began": str(first) if first is not None else None,
           "works_began": "2019-05-15",
           "after_shift_pct_per_mode": dict(zip([f"mode{k}" for k in MODES],
                                                np.round(100 * np.nanmean(M[adays], 0), 2).tolist()))}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "E21_kw51_bridge.json").write_text(json.dumps(res, indent=1, default=float))
    print(json.dumps(res, indent=1, default=float))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else None)
