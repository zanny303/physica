"""Prepare a Paderborn-style grouped manifest from separately acquired MAT recordings.

Body labels always come from user verified metadata CSV; filenames are NOT used as fault truth.
"""
from __future__ import annotations
import argparse,csv,json,re
from pathlib import Path


def build(root,labels_csv,vibration_field,current_field,sample_rate_hz,output):
    root=Path(root).resolve();labels={}
    with Path(labels_csv).open(newline='') as f:
        for row in csv.DictReader(f):
            body=row['body_id'].strip();label=int(row['label'])
            if label not in (0,1):raise ValueError('only verified 0/1 labels')
            if body in labels:raise ValueError('duplicate metadata bearing')
            labels[body]=label
    if not labels:raise ValueError('empty metadata')
    rows=[]
    for path in sorted(root.rglob('*.mat')):
        name=path.stem.split('_')
        if len(name)<5:continue
        body=name[-2]
        if body not in labels:continue
        rows.append({'path':str(path.relative_to(root)),'body_id':body,'label':labels[body],
             'sample_rate_hz':sample_rate_hz,
             'channels':{'vibration':vibration_field,'current':current_field},
             'operating_condition':'_'.join(name[:-2]),
             'units':'UNVERIFIED_PHYSICAL_SCALING_CHECK_SOURCE_METADATA'})
    obj={'schema':'physica.remote.signals.v1','origin':'external_recorded',
         'source':'Paderborn Bearing DataCenter — researcher supplied raw data',
         'label_provenance':str(Path(labels_csv).resolve()),
         'licensing':'CC-BY-NC-4.0; noncommercial attribution required; no data redistributed',
         'recordings':rows}
    out=Path(output).resolve()
    if out.parent!=root:raise ValueError('write manifest to dataset root so relative paths work')
    out.write_text(json.dumps(obj,indent=2)+'\n')
    return obj

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('labels_csv')
    p.add_argument('--vibration-field',required=True);p.add_argument('--current-field',required=True)
    p.add_argument('--sample-rate',type=float,required=True);p.add_argument('--out',required=True)
    a=p.parse_args();result=build(a.root,a.labels_csv,a.vibration_field,a.current_field,a.sample_rate,a.out)
    print(f'Indexed {len(result["recordings"])} files; field and unit conventions must be verified before training')
