"""Cause: what is changing a body, where, and how sure Physica is - discovered from felt tones, checked against
physics, carried to other bodies as a signed explanation, and probed with experiments chosen to settle doubt."""
