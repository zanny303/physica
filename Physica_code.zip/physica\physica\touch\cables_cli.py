"""Steps for feeling force: setup, known, read, reveal, twin, twin-grade, balance, test, show. Each result is saved, and each answer sealed, before the truth is known."""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np

from physica import cli as CLI
from physica import config, seal as _seal
from physica.llm import meta_client as mc
from physica.meta import scout as SC
from physica.touch import cables as C

OUT = config.REPO_ROOT / "eval" / "results" / "E34_cable_test.json"
WITHIN = 10.0
WATCH_EXTRA = "These are cables, cords or belts under load. Name each one, left to right, by what it holds, like 'cord holding the left bottle'. List only those, as parts. "
BALANCE = """You're helping a person with real loads hanging from cables. Physica measured these from a phone film. The sealed readings, in grams: {rows}. The person's goal: "{goal}".
Choose the load each cable should carry to meet the goal. Don't change any measured number. If the readings aren't enough to decide, say so. Reply as JSON: {{"target_g": <one number or null>, "why": "<one sentence>", "check_first": "<one thing to check by eye before moving anything>"}}."""
ASK_GRAMS = """Watch this film of bottles hanging from cords. Estimate how many grams each cord is holding, left to right. Give your best numbers, even if unsure. Reply as JSON: {{"grams": [<number>, ...], "why": "<one sentence>"}}."""
RULES = [
    {"claim": "Separating the cables matters", "must_hold": "the full system reads at least 2 more cables within 10% than a reading of the whole frame", "otherwise": "On this film, a whole-frame reading did as well."},
    {"claim": "Muse replaces the typing", "must_hold": "the full system types 0 words and reads at least as many cables within 10% as a person typing one word for SAM", "otherwise": "A typed word did as well, or better."},
    {"claim": "Physica is needed", "must_hold": "Muse alone reads at least 2 fewer cables within 10% than the full system", "otherwise": "Muse read the loads unaided on this film."}]


def _path(name: str) -> Path:
    return CLI.SESSIONS / f"{name}_cables.json"


def _load(name: str) -> dict:
    if not _path(name).exists():
        raise SystemExit(f"run first: python -m physica.cli cables setup film.mp4 --fps 240 --name {name}")
    return json.loads(_path(name).read_text())


def _save(name: str, d: dict) -> None:
    CLI.SESSIONS.mkdir(exist_ok=True)
    _path(name).write_text(json.dumps(d, indent=1, default=float))


def _boxes_arg(text: str) -> dict:
    """a:x1,y1,x2,y2;b:x1,y1,x2,y2 in the film's pixels. Without names, they're numbered left to right."""
    out = {}
    for i, part in enumerate(text.split(";")):
        name, _, nums = part.rpartition(":")
        v = [int(x) for x in nums.split(",")]
        if len(v) != 4 or v[2] <= v[0] or v[3] <= v[1]:
            raise SystemExit(f"this box isn't x1,y1,x2,y2: {part}")
        out[name or f"cable {i + 1}"] = v
    return out


def _masks_file(name: str) -> Path:
    return CLI.SESSIONS / f"{name}_cable_masks.npz"


def _masks(name: str) -> dict:
    """SAM's masks from setup, so later films read the same pixels. The camera must not move."""
    f = _masks_file(name)
    if not f.exists():
        return {}
    import cv2
    data = np.load(f)

    def fit(arr):
        return lambda hw: cv2.resize(arr.astype(np.uint8), (hw[1], hw[0]), interpolation=cv2.INTER_NEAREST).astype(bool)
    return {k: fit(data[k]) for k in data.files}


def _read(sess: dict, name: str, film: str) -> dict:
    return C.read_boxes(film, float(sess["fps"]), {k: tuple(v) for k, v in sess["boxes"].items()}, _masks(name))


def _say_read(rows: dict) -> None:
    for k, r in rows.items():
        print(f"  {k}: {r['tone_hz']} Hz (clear by {r['snr']:g} times)" if r.get("felt") else f"  {k}: can't tell. {r.get('reason')}")


def setup(a) -> None:
    """Muse finds the cables and SAM pins them, or you draw the boxes yourself."""
    film = a.files[0]
    fps = float(a.fps or SC.film_info(film)["fps"])
    d = {"film": film, "fps": fps, "known": [], "readings": [], "forecasts": []}
    if a.boxes:
        d.update(boxes=_boxes_arg(a.boxes), located_by="a person drew the boxes", typed_words=None)
        print(f"Using your {len(d['boxes'])} boxes.")
    else:
        if not a.allow_billed_meta:
            raise SystemExit("Finding the cables uses Muse and SAM. Add --allow-billed-meta, or draw them with --boxes")
        F = SC.Film(film, fps, CLI.SESSIONS / f"{a.name}_scout")
        seen = SC.watch(film, extra=WATCH_EXTRA, most=8)
        print(f"Muse watched the film: {seen['machine']}. {seen['seen']}")
        names = [p["name"] for p in seen["parts"]]
        for p in seen["parts"]:
            print(f"  {p['name']}: {p['why']}")
        grid = SC.point(F.still(), names)
        grid = {n: grid[n] for n in names if n in grid}
        if not grid:
            raise SystemExit("Muse couldn't point at any cable, so nothing was saved. Draw them with --boxes instead")
        F.pin(grid)
        c = F._clip()
        sx, sy = c["film_w"] / c["w"], c["film_h"] / c["h"]
        boxes, keep = {}, {}
        for n in grid:
            m = F.parts[n]["mask"]
            b = SC._box_of(m, pad=0.05)
            if b is None:
                print(f"  SAM found nothing for {n}, so it's left out")
                continue
            boxes[n] = [int(b[0] * sx), int(b[1] * sy), int(np.ceil(b[2] * sx)), int(np.ceil(b[3] * sy))]
            keep[n] = m[b[1]:b[3], b[0]:b[2]]
        if not boxes:
            raise SystemExit("SAM didn't pin any cable. Draw them with --boxes instead")
        CLI.SESSIONS.mkdir(exist_ok=True)
        np.savez_compressed(_masks_file(a.name), **keep)
        d.update(boxes=boxes, located_by="Muse pointed, live SAM 3.1 masks", typed_words=0, muse_saw=seen["seen"], muse_named=names, overlay=SC.overlay(F), usd=round(seen["usd"] + F.usd, 4))
        print(f"Pinned {len(boxes)} cables. Cost ${d['usd']}. Words typed: 0.")
        SC.masks_film(F, f"{a.name}_masks.mp4")
        print(f"Saved {a.name}_masks.mp4 for the video.")
    rows = _read(d, a.name, film)
    _say_read(rows)
    d["directions"] = {k: r.get("direction", "horizontal") for k, r in rows.items()}
    _save(a.name, d)
    if sum(1 for r in rows.values() if r.get("felt")) < len(rows):
        print("At least one cable gave no clear tone. Fix this before going on: pluck harder, film closer, plain background.")


def known(a) -> None:
    """A film with known loads, weighed on the scale first."""
    d = _load(a.name)
    rows = _read(d, a.name, a.files[0])
    names = list(d["boxes"])
    loads = [float(x) for x in str(a.loads).split(",")]
    if len(loads) == 1:
        loads = loads * len(names)
    if len(loads) != len(names):
        raise SystemExit(f"give one load, or one for each of the {len(names)} cables, in this order: {names}")
    d["known"].append({"film": a.files[0], "loads": dict(zip(names, loads)), "rows": rows})
    _say_read(rows)
    per = {}
    for n in names:
        pts = [(k["loads"][n], k["rows"].get(n, {})) for k in d["known"]]
        per[n] = C.calibrate([(g, {n: r}) for g, r in pts])[n] if len({g for g, _ in pts}) >= 2 else {"usable": False, "reason": "needs a second known load"}
    d["calibration"] = per
    _save(a.name, d)
    for n, c in per.items():
        if c.get("usable"):
            print(f"  {n}: ready. {c['grams_per_hz2']:.4f} g per Hz squared")
        else:
            print(f"  {n}: not ready. {c['reason']}")


def read(a) -> None:
    """The answer, sealed before the scale says anything."""
    d = _load(a.name)
    if not any(c.get("usable") for c in (d.get("calibration") or {}).values()):
        raise SystemExit("Film two different known loads first, with the known step")
    rows = _read(d, a.name, a.files[0])
    s = C.seal_reading(d["calibration"], rows, a.files[0])
    d["readings"].append({"sealed": s, "rows": rows})
    d.pop("graded", None)
    _save(a.name, d)
    print(f"SEALED {s['anchor']}")
    for k, r in s["payload"]["prediction"]["cables"].items():
        print(f"  {k}: {r['grams']} g, from {r['range_g'][0]} to {r['range_g'][1]}" if r["status"] == "READ" else f"  {k}: can't tell. {r['reason']}")
    print("Now weigh each load on the scale, on camera, then run reveal.")


def reveal(a) -> None:
    d = _load(a.name)
    if not d["readings"]:
        raise SystemExit("run read first, so an answer is sealed")
    names = list(d["boxes"])
    vals = [float(x) for x in a.truth.split(",")]
    if len(vals) != len(names):
        raise SystemExit(f"give one scale reading for each cable, in this order: {names}")
    g = C.grade(d["readings"][-1]["sealed"], dict(zip(names, vals)))
    d["readings"][-1]["graded"] = g
    d["graded"] = g
    _save(a.name, d)
    for k, r in g["cables"].items():
        print(f"  {k}: Physica {r.get('physica_g', 'cannot tell')}, scale {r['scale_g']:g} g" + (f", off by {r['error_pct']}%" if "error_pct" in r else ""))
    print(f"Read {g['read']} of {g['of']}. Median error {g['median_error_pct']}%. Sharing the total equally: {g['equal_share_error_pct']}%.")


def forecast(a) -> None:
    d = _load(a.name)
    c = (d.get("calibration") or {}).get(a.cable)
    if not c or not c.get("usable"):
        raise SystemExit(f"that cable isn't calibrated. Cables: {list(d['boxes'])}")
    s = C.seal_forecast(c, a.cable, a.g)
    d["forecasts"].append(s)
    _save(a.name, d)
    p = s["payload"]["prediction"]
    print(f"SEALED {s['anchor']}, number {len(d['forecasts'])}: {a.g:g} g on {a.cable} gives {p['forecast_hz']} Hz, from {p['range_hz'][0]} to {p['range_hz'][1]}. Now put that load on, weigh it first, and film it.")


def twin_grade(a) -> None:
    d = _load(a.name)
    s = d["forecasts"][a.pred - 1]
    if not _seal.intact(s):
        raise SystemExit("that seal was edited")
    p = s["payload"]["prediction"]
    r = _read(d, a.name, a.files[0]).get(p["cable"], {})
    if not r.get("felt"):
        raise SystemExit(f"Can't tell: {r.get('reason')}")
    s["grade"] = {"measured_hz": r["tone_hz"], "forecast_hz": p["forecast_hz"], "held": bool(p["range_hz"][0] <= r["tone_hz"] <= p["range_hz"][1]), "error_pct": round(100 * abs(r["tone_hz"] - p["forecast_hz"]) / r["tone_hz"], 2)}
    _save(a.name, d)
    print(f"Forecast {p['forecast_hz']} Hz, measured {r['tone_hz']} Hz: {'HELD' if s['grade']['held'] else 'MISSED'}. Off by {s['grade']['error_pct']}%.")


def balance(a) -> None:
    """Muse chooses the target from the person's goal. Code works out each move from the sealed reading."""
    d = _load(a.name)
    if not d["readings"]:
        raise SystemExit("run read first")
    rows = d["readings"][-1]["sealed"]["payload"]["prediction"]["cables"]
    target, why, check = a.target, None, None
    if a.allow_billed_meta and target is None:
        said = {k: r.get("grams") for k, r in rows.items()}
        r = mc.respond("wonder", [{"role": "user", "content": [{"type": "input_text", "text": BALANCE.format(rows=json.dumps(said), goal=a.goal)}]}], "physica_cable_balance", effort="medium")
        got = SC.parse_json(r["content"])
        target, why, check = got.get("target_g"), got.get("why"), got.get("check_first")
    plan = C.balance(rows, target)
    if plan["status"] != "PLAN":
        raise SystemExit(f"Can't tell: {plan['reason']}")
    plan.update(goal=a.goal, muse_why=why, muse_check_first=check)
    d["plan"] = plan
    _save(a.name, d)
    if why:
        print(f"Muse: {why}")
    if check:
        print(f"Check first: {check}")
    print(f"Target {plan['goal_g']} g on each. Spread now {plan['spread_now_g']} g.")
    for k, m in plan["moves_g"].items():
        print(f"  {k}: {'add' if m >= 0 else 'remove'} {abs(m)} g of water")
    print("Do this on the scale, film again, then run read and reveal again.")


def _within(g, t) -> bool:
    return g is not None and abs(g - t) / t * 100 <= WITHIN


def test(a) -> None:
    """The same film with one part removed at a time. A failed or empty reply counts as a miss, and a first run stays frozen."""
    d = _load(a.name)
    names = list(d["boxes"])
    truth = dict(zip(names, [float(x) for x in a.truth.split(",")]))
    film, fps = a.files[0], float(d["fps"])
    cal = d["calibration"]
    if OUT.exists() and not a.again:
        raise SystemExit(f"{OUT.name} already holds a run. A first run stays frozen.")
    print("Rules, fixed before any call:")
    for r in RULES:
        print(f"  {r['claim']}: {r['must_hold']}.")
    if not a.allow_billed_meta:
        print("Nothing was sent. Add --allow-billed-meta to run it. Expect under $1.")
        return
    sealed = _seal.seal({"rules": RULES, "within_pct": WITHIN, "boxes": d["boxes"], "film": film}, "the test and how it will be scored, before any model call")
    arms: dict[str, dict] = {}

    def score(row_grams: dict, words: int, usd: float = 0.0, note: str | None = None) -> dict:
        return {"right": sum(1 for k in names if _within(row_grams.get(k), truth[k])), "of": len(names), "grams": row_grams, "typed_words": words, "usd": round(usd, 4), "note": note}
    V, _ = SC.load_region(film, None, most_frames=2048, long_side=320)
    whole = C.read_cable(V, fps)
    arms["Physica on the whole frame"] = score({k: round(C.to_grams(cal[k], whole["tone_hz"])) for k in names if cal[k].get("usable")} if whole.get("felt") else {}, 0, note="One tone for every cable")
    try:
        F = SC.Film(film, fps, CLI.SESSIONS / f"{a.name}_scout")
        F.pin_noun(a.noun)
        mask = F.parts[a.noun]["mask"]
        c = F._clip()
        sx, sy = c["film_w"] / c["w"], c["film_h"] / c["h"]
        got = {}
        for k in names:
            x1, y1, x2, y2 = d["boxes"][k]
            if mask[int(y1 / sy):int(y2 / sy), int(x1 / sx):int(x2 / sx)].any():
                r = C.read_boxes(film, fps, {k: tuple(d["boxes"][k])})[k]
                if r.get("felt") and cal[k].get("usable"):
                    got[k] = round(C.to_grams(cal[k], r["tone_hz"]))
        arms["A person types a word, then SAM, then Physica"] = score(got, len(a.noun.split()), F.usd)
    except Exception as e:
        arms["A person types a word, then SAM, then Physica"] = {**score({}, len(a.noun.split())), "failed": str(e)[:200]}
    rows = C.read_boxes(film, fps, {k: tuple(v) for k, v in d["boxes"].items()}, _masks(a.name))
    arms["Muse, SAM and Physica"] = score({k: round(C.to_grams(cal[k], r["tone_hz"])) for k, r in rows.items() if r.get("felt") and cal[k].get("usable")}, d.get("typed_words") or 0, d.get("usd", 0), note=d.get("located_by"))
    try:
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            part = mc.video_part(SC.muse_clip(film, Path(td) / "w.mp4"))
        r = mc.respond(SC.SPARK, [{"role": "user", "content": [{"type": "input_text", "text": ASK_GRAMS}, part]}], "physica_cable_muse_alone", media_usd=0.1, effort="medium")
        vals = SC.parse_json(r["content"]).get("grams") or []
        arms["Muse alone"] = score(dict(zip(names, [float(v) for v in vals])), 0, r["usd"])
    except Exception as e:
        arms["Muse alone"] = {**score({}, 0), "failed": str(e)[:200]}
    g = lambda n: arms[n]["right"]  # noqa: E731
    checks = [g("Muse, SAM and Physica") - g("Physica on the whole frame") >= 2, arms["Muse, SAM and Physica"]["typed_words"] == 0 and g("Muse, SAM and Physica") >= g("A person types a word, then SAM, then Physica"), g("Muse, SAM and Physica") - g("Muse alone") >= 2]
    res = {"label": "LIVE META MODEL API, one rig and one operator", "protocol_sealed": sealed, "truth": truth, "arms": arms, "verdicts": [{**r, "held": bool(c)} for r, c in zip(RULES, checks)], "at": time.strftime("%Y-%m-%d %H:%M")}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(res, indent=1, default=float))
    show_test(res)


def show_test(res: dict) -> None:
    print(f"\n{'':<48}{'within 10%':>12}{'words typed':>13}{'cost':>9}")
    for n, r in res["arms"].items():
        print(f"{n:<48}{str(r['right']) + '/' + str(r['of']):>12}{r['typed_words']:>13}{'$' + str(r['usd']):>9}")
    for v in res["verdicts"]:
        print(f"{'HELD  ' if v['held'] else 'FAILED'} {v['claim']}: {v['must_hold']}." + ("" if v["held"] else f" Say: {v['otherwise']}"))


def main(argv) -> None:
    p = argparse.ArgumentParser(prog="physica cables", description="Feel how hard each cable is pulling, from one phone film")
    p.add_argument("step", choices=["setup", "known", "read", "reveal", "twin", "twin-grade", "balance", "test", "show"])
    p.add_argument("files", nargs="*")
    p.add_argument("--name", default="cables")
    p.add_argument("--fps", type=float)
    p.add_argument("--boxes", default=None, help="draw them yourself: a:x1,y1,x2,y2;b:x1,y1,x2,y2")
    p.add_argument("--loads", default=None, help="known: grams, one for all or one per cable")
    p.add_argument("--truth", default=None, help="reveal and test: scale grams, one per cable")
    p.add_argument("--cable", default=None)
    p.add_argument("--g", type=float)
    p.add_argument("--pred", type=int, default=1)
    p.add_argument("--target", type=float)
    p.add_argument("--goal", default="every cable carries the same load")
    p.add_argument("--noun", default="cord")
    p.add_argument("--again", action="store_true")
    p.add_argument("--allow-billed-meta", action="store_true")
    a = p.parse_args(argv)
    if a.step in ("setup", "known", "read", "twin-grade", "test") and not a.files:
        raise SystemExit(f"{a.step} needs a film")
    if a.step == "known" and not a.loads:
        raise SystemExit("known needs --loads, the grams you weighed")
    if a.step in ("reveal", "test") and not a.truth:
        raise SystemExit(f"{a.step} needs --truth, the scale readings")
    if a.step == "twin" and (not a.cable or not a.g):
        raise SystemExit("twin needs --cable and --g")
    if a.step == "show":
        if OUT.exists():
            show_test(json.loads(OUT.read_text()))
        print(json.dumps({k: v for k, v in _load(a.name).items() if k not in ("overlay",)}, indent=1, default=float)[:5000])
        return
    {"setup": setup, "known": known, "read": read, "reveal": reveal, "twin": forecast, "twin-grade": twin_grade, "balance": balance, "test": test}[a.step](a)
