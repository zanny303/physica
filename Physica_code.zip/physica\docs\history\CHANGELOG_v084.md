# Physica v0.8.4 — One-Place Studio

A local, integrated GUI layer over the v0.8.3 research implementations. **This is a product integration release, not a new physical intelligence algorithm or external validation.**

- Single localhost-only dashboard at `http://127.0.0.1:8765`: Lab, Discover, Lens, Transfer/PEL, original Feel Check, Meta/System.
- Runs pre-approved, non-actuating commands through the app; streams job status and makes generated HTML/JSON reports clickable.
- Embeds the pre-existing Lens upload/ROI/holdout forecast tool at `/lens/` without requiring a second server or port.
- Embeds the original drone Feel Check replay with saved original real-flight results at `/feel-check/`.
- Provides the synthetic real-training pilot, prospective-replay, transfer-design, benchmark, reliability and Meta offline preflight tasks.
- Accepts user-supplied MAT/CSV + `manifest.json` recordings locally for existing real-signal classifiers and next-sensation regression. Source origin and calibration remain user-declared; no automatic downloads.
- Fixes the Windows cp1252 Unicode failure for Studio-launched jobs using UTF-8-enabled subprocesses.
- Security: localhost binding only, random in-memory origin token, origin check on POST, fixed task allowlist, no arbitrary shell/paths, no automated hardware instructions and **no billable Meta calls from dashboard**.
- Added focused HTTP and behavior regressions `tests/test_studio_v084.py`.

The original v0.8.3 Meta adapters, raw-data scripts and specialized research commands remain available in the CLI. Unimplemented features are not presented as demonstrated hardware functionality. Recording-video holdouts do not prove independent prediction chronology.
