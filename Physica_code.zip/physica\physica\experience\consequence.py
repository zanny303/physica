"""A sandbox for 'feeling' possible irreversible consequences.

Analytical toy coupon only: first-order elastic bending and an *assumed* Normal
failure-load distribution. The assumptions MUST be calibrated on sacrificial
coupons before suggesting real load limits. No actuator control is provided.
"""
from __future__ import annotations
import math


def simulate_bracket(force_n:float,stiffness_n_per_m:float,mean_failure_n:float,
                     std_failure_n:float,max_allowed_failure_probability:float=.05) -> dict:
    if force_n<0 or stiffness_n_per_m<=0 or mean_failure_n<=0 or std_failure_n<=0:
        raise ValueError("invalid force/stiffness/failure distribution")
    # Prob(Failure_threshold <= proposed force). Distribution must be fitted, not assumed in production.
    z=(force_n-mean_failure_n)/std_failure_n
    chance=.5*math.erfc(-z/math.sqrt(2))
    return {"predicted_deflection_m":force_n/stiffness_n_per_m,
            "probability_irreversible_break":chance,
            "decision":"SIMULATE_ONLY_STOP" if chance>max_allowed_failure_probability else "SIMULATE_ONLY_WITHIN_ASSUMED_LIMIT",
            "grounding":"synthetic illustrative prior, NOT a hardware safety limit",
            "model":"linear stiffness; assumed Gaussian failure-load uncertainty"}


def consequence_path():
    return [{"force_n":float(f),**simulate_bracket(float(f),800.,10.,1.5)}
            for f in (2,4,6,7,8,9,10,11,12)]
