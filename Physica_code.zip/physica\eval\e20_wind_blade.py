"""E20 - Ice, crack, or just cold? A real wind turbine blade through -15 to +40 degC (REAL DATA).

ETH Zurich small-scale blade benchmark (Windspot 3.5 kW blade, 1.75 m, 5 kg; Ou et al. 2021, CC BY-NC 4.0 article;
data via the EOVmitigation repository). Eight accelerometers, white-noise shaking, climate chamber in 5 degC steps.
Truth: R healthy; A-C added masses of 44/88/132 g standing in for ice; D-L cuts at ~17/30/50% span growing to 15 cm.

Protocol (no examples of ice or cracks are ever used):
  learn   session 1: healthy tests at every temperature  -> the blade's temperature law + group noise
          session 1: ONE deliberate experiment, a known 44 g mass taped on (case A) -> what mass feels like here
  judge   session 2 (a separate test campaign, a stand-in for a sister turbine): every case at every temperature,
          in groups of 5 tests ("a few minutes of operation")
  act     ice -> pause + heat with a SEALED promise ("after de-icing it feels healthy again"), graded on what the
          blade actually felt; cracks/structural/can't tell -> stop + an ArduPilot inspection mission
  teach   everything learned goes into one signed card; session 2 uses only that card
Baselines: a temperature-blind alarm (any tone more than 2% from its +20 degC value), and "every drop is damage".
Honest note: the two pattern thresholds (slow-mode lead 1.4 / 0.7) and the 3-sigma "tone went up" rule were set while
looking at session 1, including its damaged cases. Nothing was set on session 2, which is the only data scored.
Set PHYSICA_BLADE_PSD to the folder of unzipped PSD .npz files.
"""
from __future__ import annotations

import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica.act import turbine  # noqa: E402
from physica.cause.blade import BladeSense  # noqa: E402
from physica.data import blade_eth as B  # noqa: E402
from physica.library import sign as _sign  # noqa: E402

OUT = ROOT / "eval" / "results"
CLASS = {"healthy": "weather only", "ice": "ice", "crack": "crack"}


def groups(tests, size=5):
    G = defaultdict(list)
    for t in tests:
        G[(t.case, t.temp_c)].append(t)
    out = []
    for (c, tc), ts in sorted(G.items()):
        for i in range(0, len(ts), size):
            g = ts[i:i + size]
            if len(g) >= 3:
                out.append(((c, tc), [(t.psd, t.temp_c) for t in g]))
    return out


def run(tests, law_temps=None, tag="all temperatures"):
    s1 = [t for t in tests if t.session == 1]
    s2 = [t for t in tests if t.session == 2]
    healthy1 = [t for t in s1 if t.case == "R" and (law_temps is None or t.temp_c in law_temps)]
    bs = BladeSense()
    bs.learn_normal([t.psd for t in healthy1], [t.temp_c for t in healthy1])
    bs.learn_scatter_groups([g for _, g in groups(healthy1)])
    bs.learn_mass([g for _, g in groups([t for t in s1 if t.case == "A"])], grams=44.0)
    rows = []
    for (c, tc), g in groups(s2):
        j = bs.judge(g)
        rows.append({"case": c, "temp_c": tc, "truth": B.TRUTH[c][0], "size": B.TRUTH[c][1], **j})
    return bs, rows


def score(rows):
    conf = defaultdict(Counter)
    for r in rows:
        conf[r["truth"]][r["verdict"]] += 1
    by_case = defaultdict(Counter)
    for r in rows:
        by_case[r["case"]][r["verdict"]] += 1
    healthy = [r for r in rows if r["truth"] == "healthy"]
    damaged = [r for r in rows if r["truth"] != "healthy"]
    return {
        "confusion": {k: dict(v) for k, v in conf.items()},
        "by_case": {k: dict(v) for k, v in sorted(by_case.items())},
        "healthy_false_alarm": float(np.mean([r["verdict"] != "weather only" for r in healthy])),
        "detected": {c: float(np.mean([r["verdict"] != "weather only" for r in rows if r["case"] == c]))
                     for c in sorted(set(r["case"] for r in damaged))},
        "dangerous_crack_called_ice": int(sum(r["truth"] == "crack" and r["verdict"] == "ice" for r in rows)),
        "crack_groups": int(sum(r["truth"] == "crack" for r in rows)),
        "ice_called_ice": int(sum(r["truth"] == "ice" and r["verdict"] == "ice" for r in rows)),
        "ice_sent_to_inspection": int(sum(r["truth"] == "ice" and r["verdict"] in ("crack", "structural", "can't tell") for r in rows)),
        "ice_groups": int(sum(r["truth"] == "ice" for r in rows)),
    }


def naive(tests):
    """Temperature-blind alarm: any tone more than 2% away from its value at +20 degC (healthy, session 1)."""
    bs = BladeSense()
    h = [t for t in tests if t.session == 1 and t.case == "R"]
    bs.learn_normal([t.psd for t in h], [t.temp_c for t in h])
    ref = bs.law(20)
    out = defaultdict(list)
    for (c, tc), g in groups([t for t in tests if t.session == 2]):
        f = np.nanmean([bs.tones(p, t) for p, t in g], 0)
        out[c].append(bool(np.nanmax(np.abs(np.log(f / ref))) > 0.02))
    return {"healthy_false_alarm": float(np.mean(out["R"])),
            "detected": {c: float(np.mean(v)) for c, v in sorted(out.items()) if c != "R"},
            "false_alarm_by_temp": None}


def main():
    tests = B.load()
    bs, rows = run(tests)
    res = {"LABEL": "REAL DATA: ETH Zurich wind turbine blade, climate chamber -15..+40 degC",
           "blade": {"length_m": B.BLADE_LENGTH_M, "mass_kg": B.BLADE_MASS_KG, "tones_hz_at_20C": bs.law(20).round(2).tolist()},
           "temperature_law_pct_per_degC_at_20C": (100 * np.array([np.polyval(np.polyder(c), 20) for c in bs.coef])).round(3).tolist(),
           "temperature_swing_pct_minus15_to_40": (100 * (bs.law(-15) / bs.law(40) - 1)).round(2).tolist(),
           "mass_experiment": {"grams": 44, "fingerprint_pct_per_44g": (100 * 44 * bs.mass_fingerprint).round(2).tolist(),
                               "slow_mode_lead": round(bs.mass_lead, 2)},
           "groups_judged": len(rows), "score": score(rows)}
    # ice size estimates
    res["ice_grams"] = {c: float(np.median([r["ice_grams"] for r in rows if r["case"] == c and r["verdict"] == "ice"]))
                        for c in "ABC" if any(r["case"] == c and r["verdict"] == "ice" for r in rows)}
    # act and re-feel: every group called ice gets a sealed promise, graded on what the blade feels after heating.
    # Heating removes ice, not cracks: for true ice the "after" state is the healthy blade at that temperature
    # (a held-out healthy group); for anything else it is the same damaged blade.
    healthy_after = defaultdict(list)
    for r in rows:
        if r["case"] == "R":
            healthy_after[r["temp_c"]].append(r)
    loop = []
    for r in rows:
        if r["verdict"] != "ice":
            continue
        p = turbine.ice_promise(r, r["change_threshold"])
        if r["truth"] in ("ice", "healthy"):  # heating leaves a healthy blade: another healthy group, same temperature
            after = next(h for h in healthy_after[r["temp_c"]] if h is not r)
        else:  # heating does not mend a crack: the blade still feels the same
            after = r
        g = turbine.grade_ice_promise(p, after)
        loop.append({"case": r["case"], "truth": r["truth"], "temp_c": r["temp_c"], "held": g["held"], "verdict": g["verdict"]})
    res["act_refeel"] = {"ice_calls": len(loop), "promises_held_true_ice": sum(x["held"] for x in loop if x["truth"] == "ice"),
                         "true_ice_calls": sum(x["truth"] == "ice" for x in loop),
                         "cracks_caught_by_broken_promise": sum((not x["held"]) for x in loop if x["truth"] == "crack"),
                         "crack_called_ice": sum(x["truth"] == "crack" for x in loop),
                         "healthy_called_ice": sum(x["truth"] == "healthy" for x in loop),
                         "restarted_with_a_crack": sum(x["held"] for x in loop if x["truth"] == "crack")}
    res["baseline_temperature_blind"] = naive(tests)
    res["baseline_every_drop_is_damage"] = {"ice_sent_to_inspection": res["score"]["ice_groups"]
                                            - sum(1 for r in rows if r["truth"] == "ice" and r["verdict"] == "weather only")}
    # learned in the warm season only, judged in all weather
    _, rows_w = run(tests, law_temps=set(range(10, 45, 5)), tag="warm only")
    sw = score(rows_w)
    cold = [r for r in rows_w if r["truth"] == "healthy" and r["temp_c"] < 10]
    res["learned_warm_only"] = {"healthy_false_alarm_all": sw["healthy_false_alarm"],
                                "healthy_false_alarm_below_10C": float(np.mean([r["verdict"] != "weather only" for r in cold])),
                                "dangerous_crack_called_ice": sw["dangerous_crack_called_ice"]}
    # actions written for one example of each verdict
    ex = {}
    for v in ("weather only", "ice", "crack", "structural"):
        r = next((x for x in rows if x["verdict"] == v and x["truth"] != "healthy" or (v == "weather only" and x["verdict"] == v)), None)
        if r:
            ex[v] = {"case": r["case"], "temp_c": r["temp_c"], "say": r["say"], "commands": turbine.commands(r, "WTG-07")}
    res["examples"] = ex
    mission = turbine.inspection_mission(56.0, 10.0, 270.0, hub_height_m=100.0, blade_length_m=60.0)
    (OUT / "world").mkdir(parents=True, exist_ok=True)
    (OUT / "world" / "blade_inspection.waypoints").write_text(mission)
    res["inspection_mission"] = {"file": "eval/results/world/blade_inspection.waypoints", "waypoints": mission.count("\n") - 1,
                                 "example": "utility turbine: 100 m hub, 60 m blade, 12 m stand-off, photo every 2 m"}
    # teach: the signed card a sister turbine starts from
    card = {"schema": "physica.blade_card.v1", "claim": "how this blade model feels weather, ice and stiffness loss",
            "blade": res["blade"], "law_coef_logHz_vs_degC": bs.coef.tolist(), "group_cov": bs.cov.tolist(),
            "mass_fingerprint_per_g": bs.mass_fingerprint.tolist(), "rules": {"alpha_change": 1e-3, "z_up": 3.0,
                                                                              "lead_ice": 1.4, "lead_crack": 0.7},
            "validity": {"temp_c": [-15, 40], "learned_from": "session 1 healthy + one 44 g mass experiment"},
            "provenance": {"dataset": "ETH Zurich small-scale wind turbine blade (Ou et al. 2021)",
                           "doi": "10.1002/stc.2660"}}
    signed = {"payload": card, "signature": _sign.sign(card)}
    (ROOT / "cards" / "blade_windspot_card.json").write_text(json.dumps(signed, default=float))
    res["card"] = {"file": "cards/blade_windspot_card.json", "verifies": _sign.verify(card, signed["signature"])}
    res["rows"] = [{k: r[k] for k in ("case", "temp_c", "truth", "verdict", "slow_mode_lead", "change_score")} for r in rows]
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "E20_wind_blade.json").write_text(json.dumps(res, indent=1, default=float))
    s = res["score"]
    print("temperature law %/degC:", res["temperature_law_pct_per_degC_at_20C"])
    print("mass experiment (44 g):", res["mass_experiment"])
    print("healthy false alarms: Physica %.0f%% | temperature-blind %.0f%%" % (100 * s["healthy_false_alarm"], 100 * res["baseline_temperature_blind"]["healthy_false_alarm"]))
    print("detected:", {k: round(v, 2) for k, v in s["detected"].items()})
    print("temperature-blind detected:", {k: round(v, 2) for k, v in res["baseline_temperature_blind"]["detected"].items()})
    print("confusion:", s["confusion"])
    print("ice grams:", res["ice_grams"])
    print("dangerous (crack called ice):", s["dangerous_crack_called_ice"], "of", s["crack_groups"], "| after act+re-feel restarted with a crack:", res["act_refeel"]["restarted_with_a_crack"])
    print("act/re-feel:", res["act_refeel"])
    print("warm-only law:", res["learned_warm_only"])


if __name__ == "__main__":
    main()
