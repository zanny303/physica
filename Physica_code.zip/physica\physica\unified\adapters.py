"""Adapters to the same evidence schema; they DO NOT pretend domains share laws.

`source_ref`, raw SHA256, and calibration references must be supplied by the
caller. Retrospective archived reports are not falsely labeled prospective.
"""
from __future__ import annotations
import hashlib
import math
from pathlib import Path
from typing import Mapping

from .schema import FeltChannel, FeltComparison, FeltExperience, EvidenceError


def sha256_file(path: Path) -> str:
    import hashlib
    h=hashlib.sha256()
    with path.open('rb') as fp:
        for chunk in iter(lambda: fp.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()


def _origin(raw_hash: str | None, simulated: bool) -> str:
    return 'simulation' if simulated else 'real_recording' if raw_hash else 'unknown'


def _provenance(raw_hash: str | None, calibration_ref: str | None, extra: dict | None = None) -> dict:
    return {'raw_recording_sha256': raw_hash, 'calibration_ref': calibration_ref, **(extra or {})}


def _chan(name: str, value, unit: str, *, source: str, calibrated: str | None = None,
          derived: bool = True, simulated: bool = False, sigma: float | None = None):
    if not isinstance(value, (int, float)) or isinstance(value,bool) or not math.isfinite(value):
        return None
    return FeltChannel(name, float(value), unit,
         'simulated' if simulated else 'inferred' if derived or calibrated is None else 'measured',
         source, calibrated, sigma)


def from_printer(before: Mapping, *, after: Mapping | None = None, system_id: str = 'printer',
                 source_ref: str = 'printer_video', raw_sha256: str | None = None,
                 calibration_ref: str | None = None, simulated: bool = False,
                 evidence_split: str = 'unknown') -> FeltExperience:
    """Adapter for touch.printer_video.tune() and check() reports.

    The legacy `ringing_px` is NOT a physical displacement without scale.
    A computed ringing frequency is an inferred signal feature, not a direct
    independently calibrated force or acceleration measurement.
    """
    felt = before.get('felt') or {}
    channels = []
    for name,key,unit in [('ring_frequency','freq_hz','Hz'),('damping','damping','1'),
                          ('ringing_amplitude','ringing_px','pixels')]:
        c = _chan(name, felt.get(key), unit, source=f'{source_ref}:touch.printer_video',
                  derived=True, simulated=simulated)
        if c: channels.append(c)
    comparison=[]
    notes=['Video pixel ringing is not a calibrated displacement, acceleration, or force measurement',
           'Printer settings remain review-only; repeat the same controlled motion before and after']
    verdict='baseline_only' if after is None else 'cant_tell'
    change=before.get('change') if isinstance(before.get('change'),Mapping) else None
    if change is not None:
        base=before.get('baseline') or {}
        verdict={'changed':'changed_from_healthy_baseline','no change':'no_change_from_healthy_baseline'}.get(
            change.get('verdict'),'cant_tell')
        notes.append(f"Against this printer's healthy films: {change.get('reason','no reason given')}")
        if change.get('consistent_with_unverified'):
            notes.append('Consistent with, not proven: '+str(change['consistent_with_unverified']))
        c=_chan('ring_frequency_shift',change.get('shift_hz'),'Hz',source=f'{source_ref}:healthy_baseline',
                derived=True,simulated=simulated)
        if c: channels.append(c)
        # A can't-tell answer carries no calibrated comparison. Otherwise the limit is expressed so that
        # the shared engine's z >= 3 trigger is the same decision as "changed".
        limit=base.get('changed_limit_hz')
        if change.get('verdict') in ('changed','no change') and isinstance(limit,(int,float)) and limit>0:
            comparison.append(FeltComparison('ring_frequency',float(base['mean_hz']),float(change['tone_now_hz']),'Hz',
                'healthy_baseline_films','new_film',observed_sigma=float(limit)/3,predicted_sigma=0.0,
                calibration_ref=base.get('sha256')))
    if after is not None:
        after_felt = after.get('after') or after.get('felt_after') or after
        c = _chan('ringing_amplitude_after',after_felt.get('ringing_px'),'pixels',
                  source=f'{source_ref}:after_video',derived=True,simulated=simulated)
        if c: channels.append(c)
        before_amp=felt.get('ringing_px');after_amp=after_felt.get('ringing_px')
        if isinstance(before_amp,(int,float)) and isinstance(after_amp,(int,float)) and before_amp>0 and after_amp>=0:
            drop=1-after_amp/before_amp
            ci=after.get('ringing_drop_interval_95_exploratory') if isinstance(after,Mapping) else None
            if (isinstance(ci,list) and len(ci)==2 and all(isinstance(x,(float,int)) and math.isfinite(x) for x in ci)):
                verdict=('ringing_reduced' if ci[0]>0 else
                    'ringing_not_reduced' if ci[1]<0 else 'ringing_change_uncertain')
            else:
                verdict='ringing_reduced_point_estimate_only' if drop>0 else 'ringing_not_reduced_point_estimate_only'
            channels.append(FeltChannel('observed_ring_drop_fraction',float(drop),'1',
                            'simulated' if simulated else 'inferred',f'{source_ref}:before_after'))
            # No numerical surprise z without independent uncertainty and matching time window.
            if isinstance(before.get('predicted_ringing_left'),(int,float)):
                comparison.append(FeltComparison('ringing_left_fraction',float(before['predicted_ringing_left']),
                    float(after_amp/before_amp),'1','input_shaper_model','before_after_video_comparison'))
        else: notes.append('Before/after signal magnitude missing or invalid')
    return FeltExperience('printer',system_id,_origin(raw_sha256,simulated),source_ref,
       tuple(channels),tuple(comparison),verdict,'reduce ringing without violating printer constraints',
       provenance=_provenance(raw_sha256,calibration_ref),notes=tuple(notes),evidence_split=evidence_split)


def from_turbine(verdict: Mapping, *, system_id: str = 'turbine',
                 source_ref: str = 'blade_frequency_report',raw_sha256: str | None = None,
                 calibration_ref: str | None = None,simulated: bool = False,
                 evidence_split: str = 'unknown') -> FeltExperience:
    """Accept a BladeSense.judge() result; never allow a verdict to clear a turbine."""
    channels=[]
    for name,key,unit in [('temperature','temp_c','degC'),('change_score','change_score','1'),
                          ('change_threshold','change_threshold','1'),('slow_mode_lead','slow_mode_lead','1')]:
        c=_chan(name,verdict.get(key),unit,source=f'{source_ref}:blade_judge',derived=True,simulated=simulated)
        if c:channels.append(c)
    for i,x in enumerate(verdict.get('residual_pct',[])[:20]):
        c=_chan(f'frequency_mode_{i+1}_residual',x,'percent',source=f'{source_ref}:blade_judge',derived=True,simulated=simulated)
        if c:channels.append(c)
    for i,x in enumerate(verdict.get('z',[])[:20]):
        c=_chan(f'frequency_mode_{i+1}_reference_z',x,'1',source=f'{source_ref}:blade_judge',derived=True,simulated=simulated)
        if c:channels.append(c)
    original=str(verdict.get('verdict','unknown'))
    status={'weather only':'no_detected_change_within_baseline', 'ice':'possible_ice',
            'crack':'suspected_structural_damage','structural':'suspected_structural_damage',
            "can't tell":'cant_tell'}.get(original,'cant_tell')
    return FeltExperience('turbine',system_id,_origin(raw_sha256,simulated),source_ref,
          tuple(channels),(),status,'diagnose abnormal blade behavior, prevent unsafe operations',
          safety_class='industrial_advisory',provenance=_provenance(raw_sha256,calibration_ref,
               {'legacy_verdict': original, 'legacy_action_ignored':verdict.get('action')}),
          notes=('False negatives for cracked blades have occurred in earlier evaluations',
                 'NO model verdict permits turbine restart, de-icing, or autonomous control',
                 'Maintenance and safety decisions require qualified personnel and site procedures'),
          evidence_split=evidence_split)


def from_f1(report: Mapping, *, system_id: str = 'f1', source_ref: str = 'f1_telemetry',
            car_id: str | None = None, raw_sha256: str | None = None,
            calibration_ref: str | None = None, simulated: bool = False,
            evidence_split: str = 'unknown') -> FeltExperience:
    """Adapter for f1.feel() estimate dict or E24 report's list of inferred cars."""
    entries=report.get('felt')
    if isinstance(entries,list):
        item=next((x for x in entries if str(x.get('car'))==str(car_id)),None) if car_id else (entries[0] if entries else None)
        if item is None:raise EvidenceError('F1 car ID missing from report')
        values=item
    else:values=report.get('est',report)
    channels=[]
    specs={'power_kw':'kW','p_per_kg':'m^2/s^3','k_drag':'1/m','k_down':'1/m',
           'CdA_m2':'m^2','ClA_m2':'m^2','mu':'1',
           'downforce_250kmh_kN':'kN','trace_rmse_kmh':'km/h','best_lap_s':'s',
           'lap_time_error_s_median':'s','n_laps':'count'}
    for key,unit in specs.items():
        c=_chan(key,values.get(key),unit,source=f'{source_ref}:f1_physics_inference',derived=True,simulated=simulated)
        if c:channels.append(c)
    check=report.get('feel_check_held_out_laps') or {}
    if isinstance(check,dict):
        model=check.get('physica') or {}
        for key,unit in [('lap_time_error_s_median','s'),('speed_trace_rmse_kmh_median','km/h')]:
            c=_chan(f'heldout_{key}',model.get(key),unit,source=f'{source_ref}:archived_evaluation',derived=True,simulated=simulated)
            if c:channels.append(c)
    return FeltExperience('f1', str(car_id or values.get('car') or system_id),
        _origin(raw_sha256,simulated),source_ref,tuple(channels),(),
        'dynamics_estimated_not_causally_identified',
        'reduce lap time while satisfying safety and corner-speed constraints',
        provenance=_provenance(raw_sha256,calibration_ref,{'assumed_mass_if_used':True}),
        notes=('Drag/downforce/tyre grip are estimates, not directly measured forces',
               'Retrospective lap-fit errors alone do not establish causality or prospective setup improvement',
               'Wing-change effects remain model-dependent; no automatic vehicle configuration changes'),
        evidence_split=evidence_split)
