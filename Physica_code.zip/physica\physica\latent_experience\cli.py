"""Train an action-conditioned sensory latent model on CSV or reproducible SIMULATED pilot.
CSV columns: timestamp, action, sense_cam, sense_audio, sense_touch etc.
Each row's action applies during transition TO THE NEXT row.
"""
import argparse,csv,json
from pathlib import Path
import numpy as np
from .model import train,evaluate

def demo(seed=86,n=420):
    r=np.random.default_rng(seed);st=np.zeros((n,2));actions=r.normal(0,.3,n-1)
    for t,a in enumerate(actions):
        st[t+1]=np.array([.97*st[t,0]+.08*st[t,1]+.055*a,-.16*st[t,0]+.91*st[t,1]+.09*a])
    sensors=st@np.array([[1.2,.1,0.45],[.05,1.,-.7]])+r.normal(0,.012,(n,3))
    return sensors,actions

def load_csv(path):
    with open(path,encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    if not rows:raise ValueError('empty CSV')
    keys=[k for k in rows[0] if k.startswith('sense_')]
    if len(keys)<2 or not {'action','timestamp'}<=set(rows[0]): raise ValueError('required timestamp, action and >=2 sense_* columns')
    t=np.array([float(r['timestamp']) for r in rows]);
    if not np.all(np.diff(t)>0):raise ValueError('timestamps must increase')
    return np.array([[float(r[k]) for k in keys] for r in rows]),np.array([float(r['action']) for r in rows[:-1]])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--csv');ap.add_argument('--out',required=True);ap.add_argument('--seed',type=int,default=86);ap.add_argument('--rank',type=int,default=2)
    args=ap.parse_args();Y,A=load_csv(args.csv) if args.csv else demo(args.seed)
    cutoff=int(len(Y)*.7)
    # Every matrix parameter learned from prefix only; no future test samples seen.
    model=train(Y[:cutoff+1],A[:cutoff],rank=args.rank)
    scores=evaluate(model,Y,A,cutoff)
    report={'origin':'USER_SUPPLIED_UNVERIFIED' if args.csv else 'SIMULATED','algorithm':'learned action-conditioned PCA/SVD latent dynamics',
            'trained_samples':cutoff+1,'test_samples':len(Y)-cutoff-1,'metrics':scores,'model':model,
            'limitations':['No learned nonlinear universal physical state','No confidence calibration on unknown bodies',
            'Observational action columns do not prove intervention provenance','Scores are for the supplied sequential split; independent-machine test requires extra datasets']}
    path=Path(args.out);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'origin':report['origin'],'metrics':scores,'output':str(path)},indent=2))
if __name__=='__main__':main()
