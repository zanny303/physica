# Physica Dual-World Residuals: mathematics, units, and Meta boundaries

For each safe candidate action `a` and physical hypothesis `H`, PACER computes
expected information gain `I(H;Y|a)` from a calibrated Gaussian likelihood.
A mechanistic twin and a learned visual predictor independently return
`p_physics(y|a)` and `p_visual(y|a)` on **the same** measured physical
observable `y` (for example tip displacement in metres), with calibrated
predictive uncertainty. A V-JEPA latent embedding is **not** automatically a
metric physical quantity.

For `p=N(mu_p,sigma_p²)`, `q=N(mu_v,sigma_v²)`:

```
D = 1/2 [ KL(p||q) + KL(q||p) ]
  = 1/4 [ (sigma_p²/sigma_v²) + (sigma_v²/sigma_p²) - 2
          + (mu_p-mu_v)²(1/sigma_p²+1/sigma_v²) ]
U(a) = I(H;Y|a) + lambda*(1-exp(-D)) - alpha*risk(a) - beta*cost(a)
a* = argmax U(a) subject to safety and calibration gates
```

When either forecast is absent, uncalibrated, or in incomparable units, the
**default** action result is a refusal—not a fabricated vision estimate. An
unsafe/irreversible action is refused before calculating its utility.
After the measured intervention, each model receives a separate standardized
residual and Gaussian NLL. A large disagreement means informative model conflict,
not a guarantee of causal identifiability or calibrated accuracy. Bounded `D`
prevents infinite preference for numerical model-conflict artifacts.

## The physical token (dimensionless step-response example)

`tau=f_A*t_A`, `q(tau)=x_A(t_A)*k_A/F_A`.
With independently measured B calibration, `t_B=tau/f_B` and
`x_B(t_B)=q(tau)*F_B/k_B`. The source experience also carries action/boundary
classes, mode ratios/damping, units, calibration, evidence hash, origin and a
hash over the portable token. Local B verification is mandatory. Assumptions:
linear time-invariant response in operating region, known step force, stiffness,
comparable modes and boundary class. This is dimensional analysis + system
identification, **not universal embodied knowledge transfer**.

## The Meta model roles

| Model / tool | Intended job | Current implementation status |
| --- | --- | --- |
| Muse Wonder/Spark | ground hypothesis proposals and narrative explanations in sensor results; suggest only whitelisted safe actions | Existing constrained reviewer in `experience/meta.py`; configurable HTTP gateway in `meta_world.py`, not live validated |
| SAM 3.1 | segment/track regions in measured video to produce raw feature tracks | NOT wired into v0.3; video-to-metric calibration and adapter work needed |
| V-JEPA 2 | provide action-conditioned visual/world priors and forecast into comparable observation space | NOT wired or trained; example `visual_surrogate` is explicitly **synthetic, not V-JEPA** |
| Muse Image | presentation graphics only; not measurement evidence | optional, not wired |
| Physica mechanistic twin | calibrated physical values, uncertainty, safety checks, signed consequences | v0.3 synthetic implementation, original Physica legacy evaluations preserved |

## Real model connections

`python -m physica.cli experience meta-status` shows only configuration status.
`MetaGateway.from_env(role='WONDER')` requires user-supplied `META_API_BASE_URL`,
`META_API_KEY`, `MODEL_WONDER`, and an endpoint path (`META_RESPONSES_PATH`,
by default `/responses`). Confirm currently supported model IDs, API request
fields, endpoint routes, rights, pricing and data handling **against Meta's live
official documentation** before making calls. It makes a real HTTPS request
only when explicitly invoked; **it never silently substitutes mock evidence**.
Current project does not assert an official SAM/V-JEPA hosted endpoint exists.

If a locally run V-JEPA predictor is calibrated against held-out measured
quantities, export its scalar forecast to JSON and pass through
`meta_world.load_calibrated_visual_forecast()`. Required keys: `observable`,
`unit`, `mean`, `sigma`, `model_id`, `origin`, `calibration_evidence`.
`calibration_evidence` is a caller-supplied string; the loader tests presence
and typing, not scientific authenticity. Real studies must audit the linked
calibration dataset.

## `dual-rank` CLI JSON contract

```
{
  "prior": {"healthy": 0.5, "loose": 0.5},
  "actions": [
    {"action_id": "safe_step", "means": {"healthy": 0.0008, "loose": 0.0013},
     "sigma": 0.0002, "unit": "m", "risk": 0.02}
  ],
  "paired_forecasts": {
    "safe_step": [
      {"observable": "tip_displacement", "unit": "m", "mean": 0.0012,
       "sigma": 0.0001, "model_id": "mechanistic-v1", "origin": "mechanistic",
       "calibration_evidence": "measured-calibration-run-id"},
      {"observable": "tip_displacement", "unit": "m", "mean": 0.0009,
       "sigma": 0.0002, "model_id": "learned-visual-model-id", "origin": "model",
       "calibration_evidence": "held-out-calibration-run-id"}
    ]
  }
}
```

Run `python -m physica.cli experience dual-rank request.json --out result.json`.
User-supplied forecasts must be real, independently calibrated data for real
scientific claims. The CLI is not an authorization to actuate hardware.

### Configuring Muse review through the modern gateway

The `experience muse-review` command now uses the configurable Responses-style
path (`META_API_PROTOCOL=responses`) in live mode, rather than assuming a
`/chat/completions` route. Set `MOCK=0`, plus `META_API_BASE_URL`,
`META_API_KEY`, `MODEL_WONDER` (or `MODEL_SPARK` for `--role spark`), and
optionally `META_RESPONSES_PATH`. Then run:

```bash
python -m physica.cli experience muse-review facts.json --allowed safe_step --role wonder
```

The returned JSON action is **strictly checked** against `--allowed`; no
numeric value or physical safety gate can be changed by Muse. Live endpoint
compatibility has not been tested here. A legacy chat-completions request is
available only by explicitly setting `META_API_PROTOCOL=chat_completions_legacy`.
The default with `MOCK=1` is an explicitly labeled deterministic mock.
