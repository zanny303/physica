# How Physica uses Meta's models

**Newest design, tested on a local stand-in until your first live run:** Muse watches a real film through the Responses API, points at parts on a 0 to 1000 grid, and chooses what gets measured through tools (`segment_and_feel`, `look_closer`). One SAM request carries all its points, and Physica keeps the masks to choose which pixels to read. If the film path is refused, Muse falls back to photos, and the record says so. `python -m physica.cli meta preflight` tests each step. See `physica/meta/scout.py` and `physica/touch/printer_part.py`.

# How Physica uses Meta's models

Physica feels and measures. Muse sees and reasons. SAM finds and separates. Reality decides.

**Muse runs the investigation.** With `printer-video investigate`, Muse Wonder calls Physica as its tools: it looks at the films, feels the machine and its parts, proposes causes, asks Physica for a test, and tells a person what to do. After the test, it reads the result, says what it supports, and proposes what's next. Muse can't move the machine, and every number comes from a tool.

| Step | Model | What it does | What stops it overreaching |
|---|---|---|---|
| Locate | SAM 3.1 | Finds the print head in the film, so the motion reader looks in the right place | `sam-compare` scores the same films with and without it |
| Separate | SAM 3.1 | Finds each named part, so Physica can feel the head, gantry and frame separately | Readings are measured pixel motion, not model output |
| Look and propose | Muse Wonder | Sees photos from the healthy and changed films, plus the measured numbers, and proposes causes Physica's test doesn't cover | Each cause must give a mass share, or say a weight won't matter, so it becomes a forecast. Muse never sees the blind truth |
| Challenge | Muse Spark | Removes ideas that contradict the measurements | It can't remove an idea just for being unlikely. If it fails, the ideas still go to the test |
| Test | Physica | Seals every forecast, picks the weight that separates them, and judges the films | A heavier weight is only chosen from the list you give |
| Learn | Muse Wonder | Sees the result, explains it, and proposes the next test | Any number it uses that wasn't measured is flagged |
| Judge | Muse Spark | Compares photos of the before and after parts, not knowing which is which | The order is random and set before the call |
| Review | Muse Spark | Gives a second verdict on blade cases. If it disagrees with Physica, the safer action is taken | The rule was fixed before case-by-case answers were seen. `--confirm` tests it on new cases |

Every live call leaves a receipt in `meta_receipts/`, with no key and no inline images, only their fingerprints. Run `python -m physica.cli printer-video proof` to see what has been shown so far, including what failed.

## Why this design

- **Hypotheses steer experiments.** LLM-AutoSciLab alternates hypotheses and experiments, and reports being 2 to 5 times more sample-efficient than its strongest baselines on its benchmarks ([arXiv:2605.24043](https://arxiv.org/abs/2605.24043)). That's on its benchmarks, not on printers. Physica's version is smaller: a human runs the test, and the physics is known.
- **Numbers stay out of the model's hands.** The ViLM vibration model computes key figures and fills them into its reports, rather than letting the model generate them ([ViLM](https://ojs.istp-press.com/dmd/article/view/1588)).
- **Vision on print quality works, with limits.** LLM-3D Print had GPT-4o inspect each layer and adjust settings. It matched experts on major defects, but missed some subtle ones, and its comparisons were largely qualitative ([arXiv:2408.14307](https://arxiv.org/abs/2408.14307)).
- **Having a tool isn't the same as using it.** Another hackathon project reports that its agent never called SAM in its SAM runs, and says so plainly ([nerve-muse-sam](https://github.com/LincForge/nerve-muse-sam)). That's why Physica's scoreboard counts what each model changed.

## Prices

From Meta's [pricing page](https://dev.meta.ai/docs/pricing-rate-limits), checked 2 Nov 2026, standard mode: Spark 1.3 $1.25 in and $4.25 out per million tokens, Wonder 1.0 $4 and $20, SAM 3.1 video $0.0002 per frame, with at least 50 frames billed per request. Reasoning counts against the output limit, per Meta's [reasoning guide](https://dev.meta.ai/docs/reasoning), which is why replies were cut off at low limits.
