"""A check the camera can't fake: from the tone felt in a film, seal how far apart the ripples on a printed wall will be.

A head ringing at f Hz while printing at v mm/s leaves ripples v/f mm apart. So a pair of calipers on the finished part
gives a second measurement of the tone, with no camera involved. This is the standard printed ringing test
(see Klipper's Resonance_Compensation docs), used here as a sealed forecast.
On a bed-slinger or Cartesian printer, ringing on X shows on walls running along Y. Skip the first ripple or two after the corner.
"""
from __future__ import annotations

from physica import seal as _seal

# Allowed for reading ripples on a real part: about 0.5 mm across a 12 mm span, plus the printer not quite holding speed.
READING_ALLOWANCE = 0.08


def forecast(felt: dict, speed_mm_s: float, axis: str = "X") -> dict:
    """felt: the tune step's result (freq_hz, freq_iqr, damping)."""
    f = float(felt["freq_hz"])
    if speed_mm_s <= 0:
        raise ValueError("speed must be positive")
    lo, hi = felt.get("freq_iqr", [f, f])
    f_lo, f_hi = min(lo, f * (1 - READING_ALLOWANCE)), max(hi, f * (1 + READING_ALLOWANCE))
    return _seal.seal({"claim": f"ripples on the wall that shows {axis} ringing", "felt_hz": round(f, 2), "damping": round(float(felt["damping"]), 4),
                       "wall_speed_mm_s": float(speed_mm_s), "spacing_mm": round(speed_mm_s / f, 3),
                       "spacing_range_mm": [round(speed_mm_s / f_hi, 3), round(speed_mm_s / f_lo, 3)], "tone_range_hz": [round(f_lo, 2), round(f_hi, 2)]},
                      "ripple spacing on a printed part, before printing it")


def grade(sealed: dict, distance_mm: float, ripples: int) -> dict:
    """distance_mm: measured across this many ripples, by calipers."""
    if distance_mm <= 0 or ripples < 2:
        raise ValueError("measure across at least 2 ripples")

    def judge(pred, meas):
        spacing = meas["distance_mm"] / meas["ripples"]
        tone = pred["wall_speed_mm_s"] / spacing
        lo, hi = pred["spacing_range_mm"]
        held = lo <= spacing <= hi
        return {"held": held, "spacing_mm": round(spacing, 3), "tone_from_part_hz": round(tone, 2),
                "tone_from_film_hz": pred["felt_hz"], "difference_pct": round(100 * (tone / pred["felt_hz"] - 1), 1),
                "verdict": "HELD: the part agrees with the film" if held else "MISSED: the part disagrees with the film"}
    return _seal.reveal(sealed, {"distance_mm": float(distance_mm), "ripples": int(ripples)}, judge)
