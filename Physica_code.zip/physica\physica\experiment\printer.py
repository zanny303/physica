"""3D printer: feel the ringing, write the G-code that cancels it, then check the fix by feeling again.

1. Physica writes a short excitation G-code: sharp back-and-forth moves with pauses (each stop makes the
   machine ring at its resonance).
2. You record with a phone fixed to the moving part (phyphox, 'Acceleration (without g)').
3. Physica finds the resonance frequency and damping (half-power bandwidth of the ringing line), writes Marlin
   input shaping (M593, a ZV shaper) and the Klipper equivalent, and predicts how much ringing remains.
4. You enable the G-code, run the same excitation again with the phone in the same place, and Physica re-feels.

Honest note: the phone's own mass lowers the resonance a little. The re-feel compares like with like (phone on
both times); for printing without the phone, the true frequency is slightly higher.
"""
from __future__ import annotations

import numpy as np
from scipy.signal import welch

from physica.act import contract
from physica.translate import gcode


def excite_gcode(axis: str = "X", center: float = 110.0, travel: float = 20.0, feed: int = 12000,
                 accel: int = 3000, repeats: int = 10, pause_ms: int = 700) -> str:
    a = axis.upper()
    lines = ["; Physica ringing excitation. Tape the phone firmly to the part that moves on this axis.",
             "; Start phyphox 'Acceleration (without g)' BEFORE running. Advice, not a safety certification.",
             "G28", "G90", "G1 Z20 F600", f"G1 X{center:.0f} Y{center:.0f} F6000", f"M204 P{accel} T{accel}", "G4 P2000"]
    for _ in range(repeats):
        lines += [f"G1 {a}{center + travel:.0f} F{feed}", f"G4 P{pause_ms}", f"G1 {a}{center:.0f} F{feed}", f"G4 P{pause_ms}"]
    return "\n".join(lines + ["M84", ""])


def resonance(acc: np.ndarray, fs: float, band=(10.0, 150.0)) -> dict:
    x = acc.reshape(acc.shape[0], -1)
    x = x - x.mean(0)
    f, p = welch(x, fs=fs, nperseg=min(len(x), int(fs * 4)), axis=0)
    p = p.sum(1)
    m = (f >= band[0]) & (f <= min(band[1], 0.45 * fs))
    i = np.where(m)[0][np.argmax(p[m])]
    half = p[i] / 2
    lo = i
    while lo > 0 and p[lo] > half:
        lo -= 1
    hi = i
    while hi < len(p) - 1 and p[hi] > half:
        hi += 1
    zeta = float(np.clip((f[hi] - f[lo]) / (2 * f[i]), 0.02, 0.3))
    return {"freq_hz": float(f[i]), "damping": zeta}


def zv_residual(f: float, zeta: float, fs_hz: float, zs: float) -> float:
    """Fraction of ringing left by a ZV shaper tuned to (fs_hz, zs) on a mode (f, zeta). 0 = all gone, 1 = none."""
    K = np.exp(-zs * np.pi / np.sqrt(1 - zs ** 2))
    A, t = np.array([1 / (1 + K), K / (1 + K)]), np.array([0.0, 0.5 / (fs_hz * np.sqrt(1 - zs ** 2))])
    w, wd = 2 * np.pi * f, 2 * np.pi * f * np.sqrt(1 - zeta ** 2)
    e = np.exp(zeta * w * t)
    return float(np.exp(-zeta * w * t[-1]) * np.hypot((A * e * np.cos(wd * t)).sum(), (A * e * np.sin(wd * t)).sum()))


def ringing(acc: np.ndarray, fs: float, f0: float, rel: float = 0.06) -> float:
    x = acc.reshape(acc.shape[0], -1)
    x = x - x.mean(0)
    f, p = welch(x, fs=fs, nperseg=min(len(x), int(fs * 4)), axis=0)
    p = p.sum(1)
    m = np.abs(f - f0) <= rel * f0
    return float(np.sqrt(p[m].sum() * (f[1] - f[0])))


def run(rec, axis: str = "X") -> dict:
    acc, fs = rec
    r = resonance(acc, fs)
    lines = gcode.marlin_m593(r["freq_hz"], r["damping"], axes=axis.upper())
    left = zv_residual(r["freq_hz"], r["damping"], r["freq_hz"], r["damping"])
    out = {**r, "axis": axis.upper(), "marlin": lines, "valid_gcode": all(gcode.valid_m593(l) for l in lines),
           "klipper": f"[input_shaper]\nshaper_freq_{axis.lower()}: {r['freq_hz']:.1f}\nshaper_type_{axis.lower()}: zv\n",
           "predicted_ringing_left": left, "before_ringing": ringing(acc, fs, r["freq_hz"])}
    out["promise"] = contract.promise(
        f"Marlin {' '.join(lines)}",
        f"With the shaper on, ringing at {r['freq_hz']:.1f} Hz on {axis.upper()} drops by at least half "
        f"(Physica predicts {100 * (1 - left):.0f}% if the mode is exactly as felt).",
        [{"metric": "ringing_drop_fraction", "op": ">=", "value": 0.5, "say": "ringing drops ≥ 50%"}])
    return out


def check(result: dict, after) -> dict:
    a = ringing(after[0], after[1], result["freq_hz"])
    drop = 1 - a / result["before_ringing"]
    return {"after_ringing": a, "ringing_drop_fraction": drop,
            "judgement": contract.judge(result["promise"], {"ringing_drop_fraction": drop})}
