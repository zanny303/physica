"""Feeling force. A taut cable's tone rises with how hard it's pulled: T = C f^2 + b, the method engineers use on stay cables and drive belts.

One film can hold several cables. Each is read from its own pixels, so they don't blur into one tone. Two known loads calibrate each cable, then Physica states the load on any other film,
and the answer is sealed before the kitchen scale says anything. C holds only while the cable, its length and its ends stay the same.
"""
from __future__ import annotations

import numpy as np

from physica import seal as _seal
from physica.meta import scout as SC
from physica.touch import video

FELT_SNR = 12.0


def strongest_ladder(f: np.ndarray, p: np.ndarray, lowest: float, highest: float) -> dict | None:
    """A plucked cable rings at a fundamental and its multiples, and a multiple can be the loudest. Choose the lowest tone that explains the ladder of peaks."""
    from scipy.signal import find_peaks
    band = (f >= lowest) & (f <= highest)
    idx = np.where(band)[0]
    if len(idx) < 8:
        return None
    logp = np.log(p[idx] + 1e-30)
    floor = float(np.median(logp))
    spread = float(np.median(np.abs(logp - floor))) + 1e-9
    peaks, _ = find_peaks(logp, height=floor + 3.5 * spread, distance=2)
    if not len(peaks):
        return None
    pf = f[idx][peaks]
    pl = logp[peaks] - floor
    top = float(pl.max())
    strong = pl >= top - np.log(1000)
    pf, pl = pf[strong], pl[strong]
    df = float(f[1] - f[0])
    best = None
    for f0, l0 in zip(pf, pl):
        ok_multiples = [m for m in range(2, 7) if m * f0 <= highest and np.min(np.abs(pf - m * f0)) <= max(1.5 * df, 0.02 * m * f0)]
        # A peak with no multiples can still be the tone. Explaining stronger peaks above it is what makes a lower peak the fundamental.
        score = float(l0) + sum(float(pl[np.argmin(np.abs(pf - m * f0))]) for m in ok_multiples)
        if best is None or score > best[0]:
            best = (score, float(f0), float(l0), len(ok_multiples))
    _, hz, level, n = best
    i = int(np.argmin(np.abs(f - hz)))
    if 0 < i < len(p) - 1:
        a, b, c = np.log(p[i - 1:i + 2] + 1e-30)
        hz = float(f[i]) + float(np.clip(0.5 * (a - c) / (a - 2 * b + c - 1e-12), -0.5, 0.5)) * df
    return {"tone_hz": round(hz, 2), "snr": round(float(np.exp(level)), 1), "multiples_seen": n}


def read_cable(V: np.ndarray, fps: float, pixels: np.ndarray | None = None, lowest_hz: float = 12.0) -> dict:
    """The cable's fundamental tone from these pixels, in both directions of motion. Says it can't tell if no tone stands clear."""
    from scipy.signal import welch
    best = None
    for direction in ("horizontal", "vertical"):
        M = video.motion(V, wavelength=6, sigma=2.0, step=2, keep=0.6, direction=direction)
        Y = M["signals"]
        if pixels is not None:
            inside = pixels[M["rows"], M["cols"]]
            if inside.sum() < 4:
                continue
            Y = Y[:, inside]
        if Y.shape[1] < 2:
            continue
        if Y.shape[1] > 1200:
            Y = Y[:, np.linspace(0, Y.shape[1] - 1, 1200).astype(int)]
        Y = SC._without_keyframes(Y.astype(np.float64))
        U, sv, _ = np.linalg.svd(Y, full_matrices=False)
        C = U[:, :5] * sv[:5]
        f, P = welch(C, fs=fps, nperseg=min(len(C), 1024), axis=0, detrend="linear")
        spectrum = P.sum(1) / Y.shape[1]
        got = strongest_ladder(f, spectrum, max(lowest_hz, 4 * fps / len(C)), 0.45 * fps)
        if got:
            got["motion_px"] = round(float(np.sqrt(spectrum[int(np.argmin(np.abs(f - got["tone_hz"])))] * (f[1] - f[0]))), 4)
            # A cord swings one way. Compression can leave a tiny, very clean false tone in the other, so the larger motion wins.
            if best is None or got["motion_px"] > best["motion_px"]:
                best = {**got, "direction": direction, "pixels": int(Y.shape[1])}
    if best is None:
        return {"felt": False, "reason": "no tone in these pixels. Pluck harder, film closer, and use a plain background"}
    best["felt"] = best["snr"] >= FELT_SNR
    if not best["felt"]:
        best["reason"] = "no tone stands clear of the noise. Pluck harder, or film closer"
    return best


def read_boxes(film, fps: float, boxes: dict[str, tuple[int, int, int, int]], masks: dict | None = None, most_frames: int = 2048, long_side: int = 256) -> dict[str, dict]:
    out = {}
    for name, box in boxes.items():
        V, _ = SC.load_region(film, box, most_frames=most_frames, long_side=long_side)
        out[name] = read_cable(V, fps, masks.get(name)(V.shape[1:]) if masks and name in masks else None)
    return out


def calibrate(readings: list[tuple[float, dict[str, dict]]]) -> dict:
    """Each cable gets its own line from at least two known loads, in grams against tone squared. Loads must differ."""
    if len({g for g, _ in readings}) < 2:
        raise ValueError("calibration needs two different known loads")
    out = {}
    for name in readings[0][1]:
        pts = [(g, r[name]["tone_hz"]) for g, r in readings if r.get(name, {}).get("felt")]
        if len({g for g, _ in pts}) < 2:
            out[name] = {"usable": False, "reason": f"only {len(pts)} of the known films gave a clear tone for this cable"}
            continue
        grams, tone = np.array([p[0] for p in pts], float), np.array([p[1] for p in pts], float)
        slope, intercept = np.polyfit(tone ** 2, grams, 1)
        if slope <= 0:
            out[name] = {"usable": False, "reason": "the tone didn't rise with load, so it may not be the cable's own tone"}
            continue
        worst = float(np.max(np.abs(np.polyval([slope, intercept], tone ** 2) - grams))) if len(pts) > 2 else None
        out[name] = {"usable": True, "grams_per_hz2": float(slope), "offset_g": float(intercept), "points": pts, "worst_fit_g": worst}
    return out


def to_grams(cal: dict, hz: float) -> float:
    return float(cal["grams_per_hz2"] * hz ** 2 + cal["offset_g"])


def margin_g(cal: dict, hz: float, tone_err_pct: float = 1.5) -> float:
    """A 1% tone error is a 2% force error, since force goes with the square of the tone."""
    return float(abs(cal["grams_per_hz2"]) * hz ** 2 * 2 * tone_err_pct / 100)


def seal_reading(cals: dict, felt: dict[str, dict], film: str) -> dict:
    rows = {}
    for name, r in felt.items():
        cal = cals.get(name) or {}
        if not r.get("felt") or not cal.get("usable"):
            rows[name] = {"status": "CANT_TELL", "reason": r.get("reason") or cal.get("reason")}
            continue
        g = to_grams(cal, r["tone_hz"])
        m = margin_g(cal, r["tone_hz"])
        rows[name] = {"status": "READ", "tone_hz": r["tone_hz"], "grams": round(g), "range_g": [round(g - m), round(g + m)]}
    return _seal.seal({"film": str(film), "cables": rows}, "how hard each cable is pulling, before anything goes on the scale")


def grade(sealed: dict, truth: dict[str, float]) -> dict:
    """Against the kitchen scale. The baseline knows the total and shares it equally, which is more than any camera-free guess could know."""
    if not _seal.intact(sealed):
        return {"status": "INVALID", "reason": "the seal was edited"}
    rows = sealed["payload"]["prediction"]["cables"]
    known = [k for k in rows if k in truth]
    even = float(np.mean([truth[k] for k in known])) if known else 0.0
    out, errs, base = {}, [], []
    for k in known:
        r, t = rows[k], float(truth[k])
        if r["status"] != "READ":
            out[k] = {"scale_g": t, "said": "can't tell"}
            continue
        e = abs(r["grams"] - t)
        errs.append(100 * e / t)
        base.append(100 * abs(even - t) / t)
        out[k] = {"scale_g": t, "physica_g": r["grams"], "error_g": round(e), "error_pct": round(100 * e / t, 1), "in_range": bool(r["range_g"][0] <= t <= r["range_g"][1])}
    order_true = sorted(known, key=lambda k: truth[k])
    order_said = sorted([k for k in known if rows[k]["status"] == "READ"], key=lambda k: rows[k]["grams"])
    return {"status": "GRADED", "cables": out, "median_error_pct": round(float(np.median(errs)), 1) if errs else None, "equal_share_error_pct": round(float(np.median(base)), 1) if base else None, "read": len(errs), "of": len(known),
            "lightest_right": bool(order_said and order_said[0] == order_true[0]), "heaviest_right": bool(order_said and order_said[-1] == order_true[-1]), "anchor": sealed["anchor"]}


def twin(cal: dict, grams_list: list[float]) -> list[dict]:
    """What the tone will be at each load. Only for this cable, at this length."""
    rows = []
    for g in grams_list:
        sq = (g - cal["offset_g"]) / cal["grams_per_hz2"]
        if sq > 0:
            rows.append({"grams": g, "tone_hz": round(float(np.sqrt(sq)), 2)})
    return rows


def seal_forecast(cal: dict, name: str, grams: float, also: float | None = None) -> dict:
    row = twin(cal, [grams])
    if not row:
        raise ValueError("that load is below what this calibration covers")
    hz = row[0]["tone_hz"]
    return _seal.seal({"cable": name, "grams": grams, "forecast_hz": hz, "range_hz": [round(hz * 0.985, 2), round(hz * 1.015, 2)], "unchanged_hz": also}, "the tone this load will give, before it goes on")


def balance(rows: dict, target_g: float | None = None) -> dict:
    """How much water to move so every cable carries the same. Grams only come from the sealed reading."""
    read = {k: r["grams"] for k, r in rows.items() if r.get("status") == "READ"}
    if len(read) < 2:
        return {"status": "CANT_TELL", "reason": "fewer than two cables were read"}
    goal = float(target_g) if target_g else float(np.mean(list(read.values())))
    moves = {k: round(goal - g) for k, g in read.items()}
    return {"status": "PLAN", "goal_g": round(goal), "moves_g": moves, "spread_now_g": round(max(read.values()) - min(read.values())), "skipped": [k for k in rows if k not in read]}


def main_signal(V: np.ndarray, direction: str, pixels: np.ndarray | None = None) -> np.ndarray:
    """The cable's motion over time, for the line drawn on the film."""
    M = video.motion(V, wavelength=6, sigma=2.0, step=2, keep=0.6, direction=direction)
    Y = M["signals"]
    if pixels is not None:
        inside = pixels[M["rows"], M["cols"]]
        if inside.sum() >= 4:
            Y = Y[:, inside]
    Y = SC._without_keyframes(Y[:, np.linspace(0, Y.shape[1] - 1, min(Y.shape[1], 800)).astype(int)].astype(np.float64))
    U, sv, _ = np.linalg.svd(Y, full_matrices=False)
    return U[:, 0] * sv[0]
