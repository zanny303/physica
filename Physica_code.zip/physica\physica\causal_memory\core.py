"""Cross-sensory causal experience learner (prototype).

A source and target share a physically calibrated latent state [position, velocity].
Different bodies have different mass/stiffness/damping and sensor maps. This
prototype does NOT learn arbitrary visual/audio embeddings: calibration and
2-D physical state are explicit. Controlled actions are REQUIRED for causal claims.

Conditional dynamics: acceleration = alpha*x + beta*v + gamma*action +
                            delta*x**3 + epsilon*v*abs(v)
Fit with ridge regularization, select corrections by held-out intervention,
then make prospective forecasts with no future observations in the arguments.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import numpy as np

FEATURE_NAMES=('position','velocity','action','cubic_position','quadratic_drag')

@dataclass(frozen=True)
class Sensor:
    name: str
    position_gain: float
    velocity_gain: float
    noise_sd: float
    def __post_init__(self):
        if not self.name or self.noise_sd <= 0 or not all(np.isfinite(v) for v in (self.position_gain,self.velocity_gain,self.noise_sd)):
            raise ValueError('invalid sensor calibration')

def features(state,action):
    x,v=np.asarray(state,dtype=float)
    if not np.isfinite(action) or not np.all(np.isfinite((x,v))):raise ValueError('nonfinite state/action')
    return np.array([x,v,action,x**3,v*abs(v)],float)

def sense(state,sensors):
    x,v=np.asarray(state,dtype=float)
    return {s.name:float(s.position_gain*x+s.velocity_gain*v) for s in sensors}

def decode(observations,sensors,prior=None):
    """Weighted least squares calibrated cross-sensor decoding. No future data."""
    known={s.name:s for s in sensors}
    if not observations or any(k not in known for k in observations):raise ValueError('unknown or absent sensors')
    h=np.array([[known[k].position_gain,known[k].velocity_gain] for k in observations]);
    y=np.array(list(observations.values()),float)
    if not np.all(np.isfinite(y)):raise ValueError('nonfinite observation')
    sd=np.array([known[k].noise_sd for k in observations]);H=h/sd[:,None];Y=y/sd
    if np.linalg.matrix_rank(H)<2:
        if prior is None:raise ValueError('not observable: two independent calibrations required')
        state=np.asarray(prior,dtype=float)
        if state.shape!=(2,) or not np.all(np.isfinite(state)):raise ValueError('bad prior')
        H=np.vstack([H,np.eye(2)/1e-2]);Y=np.r_[Y,state/1e-2]
    return np.linalg.lstsq(H,Y,rcond=None)[0]

def fit(rows, alpha=1e-4, allow_nonlinear=True, prior=None, prior_strength=0.):
    """Fits supervised intervention-labelled acceleration. Never sees holdout."""
    if alpha<0 or prior_strength<0:raise ValueError('regularization must be nonnegative')
    F=[];Y=[]
    for r in rows:
        if r.get('intervention_type') != 'controlled':raise ValueError('causal fitting requires controlled actions')
        f=features(r['state'],r['action']);y=float(r['acceleration'])
        if not np.isfinite(y):raise ValueError('invalid acceleration')
        F.append(f);Y.append(y)
    if len(F)<6:raise ValueError('need six or more controlled observations')
    A=np.stack(F);y=np.asarray(Y)
    if not allow_nonlinear:A=A[:,:3]
    size=A.shape[1];base=np.zeros(size) if prior is None else np.asarray(prior,dtype=float)[:size]
    if base.shape!=(size,) or not np.all(np.isfinite(base)):raise ValueError('bad prior')
    lhs=A.T@A+np.eye(size)*(alpha+prior_strength)
    rhs=A.T@y+prior_strength*base
    theta=np.linalg.solve(lhs,rhs)
    if size==3:theta=np.r_[theta,0.,0.]
    return theta

def error(rows,coef):
    if not rows:return float('nan')
    pred=np.array([features(r['state'],r['action'])@coef for r in rows]);true=np.array([r['acceleration'] for r in rows])
    return float(np.sqrt(np.mean((true-pred)**2)))

def choose_mechanism(train,validation,prior=None):
    """Compare linear and nonlinear models using SEPARATE controlled holdout trials."""
    linear=fit(train,allow_nonlinear=False,prior=prior)
    nonlinear=fit(train,allow_nonlinear=True,prior=prior)
    el=error(validation,linear);en=error(validation,nonlinear)
    # guard against overfit: minimum 5% relative gain, strict holdout
    use_nonlinear=bool(en<el*0.95)
    return {'coefficients':(nonlinear if use_nonlinear else linear).tolist(),
            'candidate':'nonlinear-library' if use_nonlinear else 'linear',
            'validation_linear_rmse':el,'validation_nonlinear_rmse':en,
            'unseen_mechanism_invented':False}

def prospective(initial,actions,dt,coef,sensors):
    """Sealed-ready forecast; outputs depend only on initial, planned actions and model."""
    if dt<=0 or dt>0.05:raise ValueError('dt outside validated numerical range')
    s=np.asarray(initial,float);c=np.asarray(coef,float)
    if s.shape!=(2,) or c.shape!=(5,) or not np.all(np.isfinite(s)) or not np.all(np.isfinite(c)):raise ValueError('invalid initial/model')
    ans=[]
    for a in actions:
        acc=features(s,a)@c
        # velocity Verlet-like semi-implicit step
        s=np.array([s[0]+dt*(s[1]+dt*acc),s[1]+dt*acc])
        if np.max(np.abs(s))>1e6 or not np.all(np.isfinite(s)):raise ValueError('unstable extrapolation: refuse')
        ans.append({'state':s.tolist(),'senses':sense(s,sensors)})
    return ans

def hash_json(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest()

def transfer(source_coef,local_rows,probe_rows,compatibility_tolerance=0.15):
    """Equal-budget target probe estimates and conservative source/target choice.
    Local fit uses same probe as target-only baseline. No response outcomes here.
    """
    if not probe_rows:raise ValueError('target probe required')
    source=np.asarray(source_coef,float)
    local=fit(local_rows+probe_rows,allow_nonlinear=True)
    pe_source=error(probe_rows,source);pe_local=error(probe_rows,local)
    scale=max(.005,float(np.std([r['acceleration'] for r in probe_rows])))
    disagreement=pe_source/scale
    if disagreement>compatibility_tolerance:
        return {'coefficients':local.tolist(),'choice':'local-only','source_probe_normalized_error':disagreement}
    # bounded blending, local probe remains authoritative in high disagreement
    weight=float(np.clip(1.0-disagreement/compatibility_tolerance,0,0.75))
    coef=weight*source+(1-weight)*local
    return {'coefficients':coef.tolist(),'choice':'blended','source_weight':weight,'source_probe_normalized_error':disagreement}
