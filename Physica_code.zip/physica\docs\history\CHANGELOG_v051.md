# v0.5.1 audit + research release

- Signed source-target-sensor-probe-bound CIRTE authorization; recomputed inside forecast.
- Recompute real low-force raw probe from CSV; simulated JSON claims remain only in explicitly marked simulation fixture.
- Reject simulator source authorization for real devices.
- Independently validated displacement and velocity calibration ranges checked before filter assimilation and during prediction.
- Official Meta SAM 3.1 parser adapter and strict Muse JSON schema (`text.format`).
- Heldout, cross-intervention residual-force candidate mechanism discovery; untrusted Muse nominations, parameter estimation from physical evidence only.
- Reproducible synthetic research exhibit and tests; read full evidence limits in `docs/V051_DEEP_RESEARCH_META_BREAKTHROUGH.md`.

No real Meta calls, real-world A→B→C, or new physical-law discovery is claimed.
