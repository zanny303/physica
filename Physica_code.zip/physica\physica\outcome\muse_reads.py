"""Muse reads what was felt in each real use case and says what to do next, live. Its reply can't add numbers: any number that wasn't measured means the reply isn't used."""
from __future__ import annotations

import json
import re

from physica import config
from physica.llm import meta_client as mc

RES = config.REPO_ROOT / "eval" / "results"
OUT = RES / "E38_muse_reads.json"
ASK = """You are the reasoning layer of a system that feels machines from real recordings. A person acts on what you say.
Use case: {title}
What was measured, from {source}:
{facts}
In one or two plain sentences each, say what you'd do next, and what you'd check first. Use only the numbers given above, and add no new ones.
Reply as JSON: {{"do_next": "<...>", "check_first": "<...>"}}"""
SHAPE = {"title": "Decision", "type": "object", "properties": {"do_next": {"type": "string"}, "check_first": {"type": "string"}}, "required": ["do_next", "check_first"]}


def cases() -> dict:
    def load(name):
        return json.loads((RES / name).read_text())
    b = load("E32_bearing_downtime.json")
    su = b["summary"]["feel"]
    hero = next(u for u in b["units"] if u["bearing"] == "Bearing1_6")
    e20 = load("E20_wind_blade.json")
    from physica.studio.demo import recordings
    all_rows = recordings()
    rows = {r.get("clip"): r for r in all_rows}
    by_unit = {r.get("unit"): r for r in all_rows}
    out = {"downtime": {"title": "Machine downtime: a bearing running until it fails", "clip": "downtime", "source": "real lab bearings run to failure (FEMTO)",
                        "facts": f"Warned before failure on {su['alarmed']} of 11 bearings. Typical warning {su['median_warning_min']:.0f} minutes. This bearing: warned {hero['feel']['warning_min']:.0f} minutes before the run ended, after {hero['feel']['at_min']:.0f} minutes of running."},
           "turbine": {"title": "Wind turbine blade through the cold", "clip": "turbine", "source": "a real lab blade", "facts": rows["turbine"]["line"]}}
    del e20
    if "mm" in by_unit:
        out["beam"] = {"title": "A hidden support inside a steel beam", "clip": "", "source": "a real sensor recording", "facts": by_unit["mm"]["line"]}
    if "drone" in by_unit:
        out["drone"] = {"title": "Propeller damage on a real drone", "clip": "", "source": "real flight data", "facts": by_unit["drone"]["line"]}
    try:
        from physica.twin import strike
        h = strike.read(config.REPO_ROOT / "clips" / "beam_hit.mp4")
        out["twin"] = {"title": "A digital twin of a struck beam", "clip": "", "source": "real film at 10,000 frames a second", "facts": f"Tone {h['tone_hz']} Hz. Learned from the first {int(h['holdout']['learned_on_s'] * 1000)} ms, the twin forecast the next {int(h['holdout']['predicted_s'] * 1000)} ms of raw pixels: match {h['holdout']['match_r']}, and {h['holdout']['closer_than_stopping_pct']}% closer than assuming the beam just stops."}
    except Exception:
        pass
    return out


def _numbers(text: str) -> set[str]:
    return {n.rstrip(".") for n in re.findall(r"\d+(?:\.\d+)?", text)}


def ask(key: str) -> dict:
    from physica.meta import scout as SC
    if mc.is_mock():
        raise ValueError("Muse isn't connected in this window, so it can't read this yet")
    c = cases()[key]
    r = mc.respond("spark", [{"role": "user", "content": [{"type": "input_text", "text": ASK.format(**c)}]}], f"physica_reads_{key}", effort="low", schema=SHAPE)
    said = SC.parse_json(r["content"])
    added = _numbers(f"{said.get('do_next', '')} {said.get('check_first', '')}") - _numbers(c["facts"])
    row = {**c, "do_next": said.get("do_next"), "check_first": said.get("check_first"), "numbers_ok": not added, "added_numbers": sorted(added), "model": r["model"], "usd": r["usd"], "live_meta": True}
    saved = json.loads(OUT.read_text()) if OUT.exists() else {"label": "MUSE'S REAL WORDS, READING WHAT WAS FELT", "cases": {}}
    saved["cases"][key] = row
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(saved, indent=1, default=float))
    return row


def main() -> None:
    for k in cases():
        try:
            r = ask(k)
            print(f"{r['title']}\n  Muse: {r['do_next']}\n  Check first: {r['check_first']}" + ("" if r["numbers_ok"] else f"\n  Not used, because it added numbers: {r['added_numbers']}"))
        except Exception as e:
            print(f"{k}: this one failed: {str(e)[:200]}")


if __name__ == "__main__":
    main()
