"""E32: real bearings run to failure (FEMTO/PRONOSTIA, IEEE PHM 2012). Features come from eval/e32_prepare_femto.py."""
import json
from pathlib import Path

import numpy as np

from physica.maintenance.feel_bearing import evaluate

ROOT = Path(__file__).resolve().parents[1] / "eval" / "results"
r = evaluate(dict(np.load(ROOT / "E32_femto_features.npz")))
r = {"LABEL": "REAL DATA: FEMTO/PRONOSTIA bearings run to failure in a lab, IEEE PHM 2012. A lab warning is not prevented downtime.",
     "source": "Nectoux et al. 2012, IEEE PHM Prognostic Challenge; copy at github.com/wkzs111/phm-ieee-2012-data-challenge-dataset", **r}
(ROOT / "E32_bearing_downtime.json").write_text(json.dumps(r, indent=1))
print(json.dumps(r["summary"], indent=0), r["feel_earlier_than_plain"], r["plain_earlier_than_feel"])
for u in r["units"]:
    print(u["bearing"], u["life_min"], "feel", u["feel"] and u["feel"]["warning_min"], "plain", u["plain"] and u["plain"]["warning_min"], "10g", u["fixed_10g"] and u["fixed_10g"]["warning_min"], "feel life", u["feel"] and u["feel"]["life_used"])
