"""physica sense: any video or sensor recording in, a physical fact sheet out.

  body      - the modes (pitch, how fast each fades, how hard it was shaken), grouped into separate objects when
              the modes live in different places (video), and WHAT KIND of object each one physically behaves like,
              read from its frequency ratios alone (a clamped beam rings at 1 : 6.27 : 17.5, a string at 1 : 2 : 3)
  events    - every push: a touch, or a change of body (with 'where' for beams), or 'maybe' when the signal is weak
  fixes     - the same felt body written in machine languages: input shaping (Marlin M593 / Klipper), an
              ArduPilot notch, and a plain impulse schedule any controller can apply
  words     - what one machine can send another about this body (see transform.compare_words)
Advice, not a safety certification.
"""
from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

from physica.touch import act, beam
from physica.touch.transform import TouchTransform, feel_stream

VIDEO = {".mp4", ".mov", ".avi", ".mkv", ".m4v", ".webm"}

# Frequency ratios f_k / f_1 of textbook bodies (Blevins, Formulas for Natural Frequency and Mode Shape)
BODY_TYPES = {
    "clamped beam (cantilever, ruler, diving board, robot finger, drone arm)": [1, 6.267, 17.547, 34.386],
    "free or clamped-clamped beam (bar, rail, bridge deck between rigid ends)": [1, 2.756, 5.404, 8.933],
    "simply supported beam or plate strip (shelf on two supports)": [1, 4, 9, 16],
    "string or air column (instrument string, cable, pipe)": [1, 2, 3, 4, 5],
    "circular membrane (drum head, speaker cone)": [1, 1.594, 2.136, 2.296, 2.653],
}


# ---------------- load anything ----------------
def load_source(path: str | Path, fps: float | None = None, region: tuple | None = None) -> dict:
    """Video -> per-pixel motion; text/CSV -> numeric columns (first column time if it increases evenly).
    region: (x1, y1, x2, y2) pixels to read motion from (e.g. a SAM 3.1 box), else the whole frame."""
    path = Path(path)
    if path.suffix.lower() in VIDEO:
        from physica.touch import video

        V = video.load_gray(str(path))
        if region is not None:
            x1, y1, x2, y2 = (int(round(v)) for v in region)
            V = V[:, max(y1, 0):max(y2, y1 + 8), max(x1, 0):max(x2, x1 + 8)]
        if fps is None:
            import cv2

            fps = float(cv2.VideoCapture(str(path)).get(cv2.CAP_PROP_FPS)) or 30.0
        mo = video.motion(V, wavelength=6, sigma=2.5, step=2, keep=0.25)
        if np.abs(mo["signals"]).max() > 2.5:  # big swings wrap the phase: use optical flow instead
            from physica.touch.weigh import flow_motion

            mo = flow_motion(V)
            measure = "velocity"
        else:
            measure = "displacement"
        return {"kind": "video", "Y": mo["signals"], "fs": fps, "measure": measure, "rows": mo["rows"], "cols": mo["cols"],
                "shape": mo["shape"], "name": path.name}
    if path.suffix.lower() == ".npy":
        A = np.load(path)
    else:
        A = _read_table(path)
    if A.ndim != 2 or A.shape[0] < 8 or A.shape[1] < 1 or not np.isfinite(A).all():
        raise ValueError('File has no usable finite numeric time series; provide CSV with numeric columns.')
    t = A[:, 0]
    if A.shape[1] > 1 and np.all(np.diff(t) > 0) and np.std(np.diff(t)) < 0.05 * np.mean(np.diff(t)):
        fs, Y = 1 / float(np.median(np.diff(t))), A[:, 1:]
    else:
        fs, Y = fps or 1000.0, A
    Y = Y - np.median(Y, 0)
    if fs > 4000:  # long, fast recordings: keep up to ~1/3 of the rate in content
        from scipy.signal import decimate

        q = int(fs // 1000)
        Y = decimate(Y, q, axis=0, zero_phase=True)
        fs = fs / q
    return {"kind": "signal", "Y": Y, "fs": fs, "measure": "acceleration", "name": path.name}


def _read_table(path: Path) -> np.ndarray:
    rows = []
    with open(path, newline="", errors="ignore") as fh:
        for line in fh:
            parts = [p for p in line.replace(";", "\t").replace(",", "\t").split("\t") if p.strip()]
            try:
                vals = [float(p) for p in parts]
            except ValueError:
                continue
            if vals and (not rows or len(vals) == len(rows[0])):
                rows.append(vals)
    return np.array(rows, float)


# ---------------- what kind of object is it? ----------------
def body_type(freqs: list[float]) -> dict:
    """Match the felt frequency ratios to textbook bodies. Felt modes may skip modes a camera can't see."""
    f = np.sort(np.asarray(freqs, float))
    if len(f) < 2:
        return {"type": "unknown (one mode felt: need two to tell the shape of the physics)", "fit_pct": None}
    r = f / f[0]
    scores = []
    for name, ref in BODY_TYPES.items():
        ref = np.asarray(ref, float)
        err = [min(abs(np.log(x / ref[1:]))) for x in r[1:]]
        scores.append((float(np.sqrt(np.mean(np.square(err)))), name))
    scores.sort()
    best, second = scores[0], scores[1]
    clear = best[0] < 0.03 and second[0] > 2 * best[0]
    return {"type": best[1] if best[0] < 0.06 else "none of the textbook bodies", "fit_pct": 100 * best[0],
            "runner_up": second[1], "clear": bool(clear), "ratios": r.round(3).tolist()}


def spread(shape: np.ndarray) -> float:
    """Share of the sensed points a mode really moves (participation ratio, 0..1)."""
    a2 = np.asarray(shape, float) ** 2
    return float(a2.sum() ** 2 / (len(a2) * (a2 ** 2).sum() + 1e-30))


def scene_motion(tt: TouchTransform, limit: float = 0.25) -> list[int]:
    """Modes that move most of the frame together: the camera or the whole scene shaking, not an object."""
    return [k for k, m in enumerate(tt.modes) if tt.P >= 8 and spread(m.shape) > limit]


def group_bodies(tt: TouchTransform, overlap: float = 0.35) -> list[list[int]]:
    """Modes that live in different places are different objects (video): group by where they move."""
    K = len(tt.modes)
    if K == 0:
        return []
    if tt.P < 8:
        return [list(range(K))]
    A = np.stack([np.abs(m.shape) / (np.linalg.norm(m.shape) + 1e-12) for m in tt.modes])
    sim = A @ A.T
    groups: list[list[int]] = []
    skip = set(scene_motion(tt))
    for k in range(K):
        if k in skip:
            continue
        for g in groups:
            if max(sim[k, j] for j in g) > overlap:
                g.append(k)
                break
        else:
            groups.append([k])
    return groups


# ---------------- fixes in machine languages ----------------
def fixes(modes: list[dict]) -> dict:
    from physica.translate import ardupilot, gcode

    if not modes:
        return {}
    m1 = min(modes, key=lambda m: m["freq_hz"])
    strongest = max(modes, key=lambda m: m.get("amp", 0) or 0)
    out = {"avoid_hz": [round(m["freq_hz"], 2) for m in modes]}
    if 1 <= m1["freq_hz"] <= 200:
        out["marlin"] = gcode.marlin_m593(m1["freq_hz"], float(np.clip(m1["damping"], 0.01, 0.3)), axes="XY")
        out["klipper"] = gcode.klipper_input_shaper(m1["freq_hz"], m1["freq_hz"], shaper="zv")
    if 10 <= strongest["freq_hz"] <= 500:
        out["ardupilot_notch"] = ardupilot.notch_params(strongest["freq_hz"], strongest["freq_hz"] / 2)
    A, T = act.zv(m1["freq_hz"], float(np.clip(m1["damping"], 0.001, 0.3)))
    out["any_controller"] = {"say": "replace every step command u by sum_i a_i * u(t - t_i)",
                             "a": A.round(4).tolist(), "t_s": T.round(5).tolist()}
    return out


# ---------------- the fact sheet ----------------
def first_ringing(Y: np.ndarray, fs: float, learn_s: float = 8.0) -> tuple[float, float]:
    """Learn the body where it first rings clearly: from just after the first strong push to the next one."""
    e = (np.asarray(Y) ** 2).sum(1) if np.ndim(Y) > 1 else np.asarray(Y) ** 2
    w = max(int(0.05 * fs), 1)
    env = np.sqrt(np.convolve(e, np.ones(w) / w, "same"))
    on = np.where(env > 0.25 * env.max())[0]  # the first STRONG ringing (a faint wobble is not a body to learn)
    if len(on) == 0 or len(Y) / fs < 2:
        return 0.0, len(Y) / fs
    t0 = on[0] / fs + 0.2
    later = np.where(env[int((t0 + 0.5) * fs):] > 1.5 * env[int(t0 * fs)])[0]
    t1 = min(t0 + learn_s, (t0 + 0.5 + later[0] / fs - 0.05) if len(later) else np.inf, len(Y) / fs)
    return float(t0), float(t1)


def sense(path: str | Path | dict, fps: float | None = None, n_modes: int = 4, band: tuple | None = None,
          learn: tuple[float, float] | None = None, watch: bool = True, region: tuple | None = None) -> dict:
    src = load_source(path, fps, region) if not isinstance(path, dict) else path
    Y, fs = np.asarray(src["Y"], float), src["fs"]
    Y = Y[:, None] if Y.ndim == 1 else Y
    band = band or (max(1.0, 3 * fs / len(Y)), 0.45 * fs)
    t0, t1 = learn or first_ringing(Y, fs)
    kw = dict(n_modes=n_modes, band=band, measure=src["measure"], max_damping=0.15, merge=0.04)
    if Y.shape[1] == 1:
        kw.update(delays=max(int(0.3 * fs), 40), order=40)
    else:
        kw.update(order=24, space_rank=6, delays=max(int(0.027 * fs), 6))
    tt = TouchTransform(fs, **kw).fit(Y[int(t0 * fs):int(t1 * fs)])
    modes = [{**w, "where": None} for w in tt.words()]
    groups = group_bodies(tt)
    if src["kind"] == "video" and "rows" in src:
        for k, m in enumerate(tt.modes):
            a = np.abs(m.shape)
            top = a > np.quantile(a, 0.9)
            modes[k]["where"] = {"row_px": float(np.average(src["rows"][top], weights=a[top])),
                                 "col_px": float(np.average(src["cols"][top], weights=a[top]))}
    bodies = [{"modes": [modes[k] for k in g], **body_type([modes[k]["freq_hz"] for k in g])} for g in groups]
    scene = [modes[k] for k in scene_motion(tt)]
    sheet = {"source": src["name"], "kind": src["kind"], "fs": fs, "learned_from_s": [t0, t1],
             "bodies": bodies, "scene_motion": scene, "words": tt.words(), "fixes": fixes(modes), "events": [],
             "disclaimer": "Advice, not a safety certification."}
    if watch and len(Y) / fs > 4:
        ev = feel_stream(Y, tt, start_s=1.0)
        sheet["events"] = [{k: v for k, v in e.items() if k != "shifts"} for e in ev]
        sheet["changes"] = locate_changes(sheet, tt, Y)
    sheet["summary"] = summary(sheet)
    sheet["_tt"] = tt
    return sheet


def beam_set(freqs: list[float], tol: float = 0.06) -> list[float]:
    """From felt modes, the subset that forms a clamped beam's 1 : 6.27 : 17.5 pattern (best fit, within tol)."""
    from itertools import combinations

    f = sorted(freqs)
    ref = np.array(BODY_TYPES["clamped beam (cantilever, ruler, diving board, robot finger, drone arm)"])
    best = None
    for n in (3, 2):
        for c in combinations(f, n):
            r = np.array(c) / c[0]
            err = float(np.sqrt(np.mean(np.log(r[1:] / ref[1:n]) ** 2)))
            if err < tol and (best is None or (n > len(best[1]) and err < tol) or (n == len(best[1]) and err < best[0])):
                best = (err, list(c))
        if best:
            break
    return best[1] if best else []


def locate_changes(sheet: dict, tt: TouchTransform, Y: np.ndarray) -> list[dict]:
    """For each body change on a clamped beam with 2+ modes either side: where did mass come or go, how much."""
    out = []
    for e in sheet["events"]:
        if not e["kind"].startswith("body changed") or "confirmed_at" not in e and "new_modes_hz" not in e:
            continue
        before = sorted(e["modes_hz"])
        after_ev = next((x for x in sheet["events"] if x["t"] >= e.get("confirmed_at", e["t"]) and "new_modes_hz" in x), e)
        after = sorted(after_ev.get("new_modes_hz", []))
        if len(before) < 2 or len(after) < 2:
            continue
        lighter = after[0] > before[0]
        plain, loaded = (after, before) if lighter else (before, after)
        plain = beam_set(plain)  # the plain beam's own bending modes (drop strays: supports, other objects)
        if len(plain) < 2:
            continue
        edges = [0.0] + plain
        pick = []
        for k in range(len(plain)):
            c = [f for f in loaded if edges[k] < f < edges[k + 1]]
            if not c:
                break
            pick.append(c[0] if len(c) == 1 else min(c, key=lambda f: abs(np.log(f / plain[k]))))
        if len(pick) < 2:
            continue
        r = beam.feel_mass_change(pick, plain[:len(pick)])
        out.append({"at_s": e["t"], "what": "mass removed" if lighter else "mass added",
                    "place_from_clamp": r["position"], "place_90": r["position_90"],
                    "mass_vs_beam": r["mass_fraction"], "assumes": "a clamped uniform beam (see body type)"})
    return out


def summary(sheet: dict) -> list[str]:
    lines = []
    for i, b in enumerate(sheet["bodies"], 1):
        fs_ = ", ".join(f"{m['freq_hz']:.2f} Hz (fades in {m['ring_s']:.2f} s)" for m in b["modes"])
        lines.append(f"Body {i}: {fs_}. Behaves like: {b['type']}" + (f" (ratios fit within {b['fit_pct']:.1f}%)" if b.get("fit_pct") is not None and b["type"] != "none of the textbook bodies" else "") + ".")
    if len(sheet["bodies"]) > 1:
        lines.append(f"{len(sheet['bodies'])} separate objects are moving in this recording.")
    for m in sheet.get("scene_motion", []):
        lines.append(f"Also {m['freq_hz']:.2f} Hz moving most of the frame together: the camera or the whole scene, not counted as an object.")
    for e in sheet["events"]:
        extra = ""
        if e.get("new_modes_hz"):
            bt = body_type(beam_set(e["new_modes_hz"]) or e["new_modes_hz"])
            extra = f" New body: {', '.join(f'{f:.2f}' for f in sorted(e['new_modes_hz']))} Hz; behaves like: {bt['type']}"
        lines.append(f"{e['t']:.2f} s: {e['kind']}.{extra}")
    for c in sheet.get("changes", []):
        lines.append(f"At {c['at_s']:.2f} s: {c['what']} at {100 * c['place_from_clamp']:.0f}% of the length from the clamp "
                     f"(90%: {100 * c['place_90'][0]:.0f}-{100 * c['place_90'][1]:.0f}%), about {c['mass_vs_beam']:.2f}x the beam's mass.")
    if sheet["fixes"].get("marlin") and len(sheet["bodies"]) == 1:
        lines.append("If a machine moves this object, shape its moves (no ringing): " + " | ".join(sheet["fixes"]["marlin"]))
    lines.append(sheet["disclaimer"])
    return lines
