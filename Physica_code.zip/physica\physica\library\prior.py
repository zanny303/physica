"""Compounding: a new machine starts from its relatives and gives way to its own evidence (SPEC 7).

Never use library knowledge as fixed truth: the prior only shrinks the *shape* of the self-model;
the level (intercept) is always this machine's own, and more data overrides the prior.
"""
from __future__ import annotations

import numpy as np

from physica.feel.selfmodel import OperatingPointSelfModel


def relatives_prior(models: list[OperatingPointSelfModel], units: list[int] | None = None) -> OperatingPointSelfModel:
    """Pool the curve shape of relatives (same machine type) into one prior self-model."""
    coefs, sig = [], []
    for m in models:
        idx = units if units is not None else range(m.coef.shape[0])
        for k in idx:
            coefs.append(m.coef[k])
            sig.append(m.sigma[k])
    p = OperatingPointSelfModel(degree=models[0].degree, unit_names=["prior"])
    p.coef = np.mean(coefs, axis=0, keepdims=True)
    p.sigma = np.array([float(np.mean(sig))])
    p.x_center, p.x_scale = models[0].x_center, models[0].x_scale
    p.threshold = models[0].threshold
    return p


def fit_with_library(op: np.ndarray, lvl: np.ndarray, prior: OperatingPointSelfModel | None,
                     lam: float = 4.0) -> OperatingPointSelfModel:
    """op, lvl: (n_windows, 1) for one new unit. lam ~ how many windows' worth of trust the prior gets."""
    m = OperatingPointSelfModel(unit_names=["new"])
    if prior is None:
        return m.fit(op, lvl)
    return m.fit(op, lvl, prior=prior, lam=lam)
