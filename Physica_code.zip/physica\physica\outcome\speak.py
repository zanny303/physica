"""Muse writes the machine's own language from what was felt, and code checks every file. A file that fails goes back to Muse with the exact errors. Nothing is sent to any machine: a person reviews what comes out."""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from physica import config, seal as _seal
from physica.llm import meta_client as mc

RES = config.REPO_ROOT / "eval" / "results"
OUT = RES / "E36_muse_writes.json"
FILES = RES / "muse_written"
ROUNDS = 3
ANSWER = {"title": "MachineFile", "type": "object", "properties": {"file": {"type": "string"}, "why": {"type": "string"}}, "required": ["file", "why"]}


def _e23() -> dict:
    return json.loads((RES / "E23_program_by_outcome.json").read_text())


def records() -> dict:
    """What was felt, in one shared form: the quantity, its value, its unit, and how it was measured. Muse reads this, not raw sensors."""
    e = _e23()
    table = [{"support_mm": x["to_mm"], "tone_hz_low": x["sealed"][0], "tone_hz_high": x["sealed"][1]} for x in e["A_beam"]["examples"]]
    return {
        "beam": {"title": "Steel beam beside a pump", "language": "Klipper G-code", "ext": "gcode", "source": "DROPBEAR real recordings",
                 "goal": "A pump beside this beam runs at 31 Hz. The support is at 84.5 mm. Keep the beam's tone at least 5% away from the pump, and move the support as little as possible.",
                 "felt": [{"quantity": "beam tone with the support here", "value": t, "unit": "support mm and Hz", "how": "felt from real vibration recordings"} for t in table],
                 "rules": ["Only MANUAL_STEPPER STEPPER=support ... lines, G4 pauses and ; comments", "Enable the stepper, SET_POSITION to the start, then one MOVE", "SPEED 10 or less, ACCEL 50 or less", "Move only to a support position in the felt table", "End with a pause so the tone can be measured"]},
        "turbine": {"title": "Wind turbine through a freeze", "language": "IEC 61131-3 Structured Text", "ext": "st", "source": "ETH Zurich real lab blade",
                    "goal": e["B_turbine"]["goal"]["goal_text"],
                    "felt": [{"quantity": "highest change score a healthy blade reaches", "value": e["B_turbine"]["plc"]["promise_threshold"], "unit": "score", "how": "felt from real blade recordings. Arrives on the PLC multiplied by 100"},
                             {"quantity": "verdict codes from the blade sense", "value": {"0": "weather only", "1": "ice", "2": "crack", "3": "structural", "4": "can't tell"}, "unit": "code", "how": "from the blade sense"}],
                    "rules": ["Write one FUNCTION_BLOCK named PHYSICA_BLADE_GUARD", "VAR_INPUT: VERDICT : INT; SCORE_X100 : INT; RESET_BY_INSPECTOR : BOOL;", "VAR_OUTPUT: RUN_PERMIT : BOOL; HEATERS_ON : BOOL; BRAKE : BOOL; DISPATCH_INSPECTION : BOOL; STATE : INT;", "VAR: HEAT_TIMER : TON; and any INT or BOOL you need", "Use only CASE, IF, := and HEAT_TIMER(IN := ..., PT := T#45m), reading HEAT_TIMER.Q", "Ice: stop, heat until the timer ends, then restart only if the score is at or under the felt limit. Otherwise stop", "Crack, structural or can't tell: stop, brake, dispatch inspection, and stay stopped until RESET_BY_INSPECTOR", "No PROGRAM or CONFIGURATION block"]},
        "drone": {"title": "Drone inspecting a suspect blade", "language": "ArduPilot mission (QGC WPL 110)", "ext": "waypoints", "source": "real turbine geometry, ArduPilot's own format",
                  "goal": "The feel flagged a blade. Inspect it with a drone, stopping for a photo about every 4 m along it, and land.",
                  "felt": [{"quantity": "tower", "value": {"lat": 56.2, "lon": 9.5}, "unit": "degrees", "how": "site record"}, {"quantity": "hub height", "value": 60, "unit": "m", "how": "site record"},
                           {"quantity": "blade, parked straight down from the hub", "value": 30, "unit": "m long", "how": "site record"}],
                  "rules": ["First line QGC WPL 110, then tab-separated rows: index current frame command p1 p2 p3 p4 lat lon alt autocontinue", "Row 0 is home, at least 10 m from the tower", "Use commands 22 takeoff, 16 waypoint, 203 photo, 21 land only", "Every point on the flight stays at least 10 m from the tower and blade line, and no higher than 120 m", "Photos must cover 31 m to 58 m altitude, with no gap over 5 m", "Finish with command 21 land"]},
    }


# ---------- checks

def _c(name: str, ok, detail: str = "") -> dict:
    return {"check": name, "ok": bool(ok), "detail": detail}


def check_beam(text: str, rec: dict) -> list[dict]:
    lines = [ln.split(";")[0].strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]
    odd = [ln for ln in lines if not re.fullmatch(r"(MANUAL_STEPPER\s+STEPPER=support(\s+[A-Z_]+=[-\d.]+)+|G4\s+P\d+)", ln)]
    moves = [re.search(r"\bMOVE=([-\d.]+)", ln) for ln in lines]
    moves = [float(m.group(1)) for m in moves if m]
    out = [_c("only allowed commands", not odd, "; ".join(odd[:3])), _c("exactly one move", len(moves) == 1, f"{len(moves)} moves")]
    start = [re.search(r"SET_POSITION=([-\d.]+)", ln) for ln in lines]
    start = [float(m.group(1)) for m in start if m]
    out.append(_c("starts from where the support is", start == [84.5], str(start)))
    fast = [ln for ln in lines if (m := re.search(r"SPEED=([\d.]+)", ln)) and float(m.group(1)) > 10] + [ln for ln in lines if (m := re.search(r"ACCEL=([\d.]+)", ln)) and float(m.group(1)) > 50]
    out.append(_c("speed and acceleration within limits", not fast, "; ".join(fast[:2])))
    out.append(_c("ends with a pause", bool(lines) and lines[-1].startswith("G4"), ""))
    if len(moves) == 1:
        table = [x["value"] for x in rec["felt"]]
        hit = next((t for t in table if abs(t["support_mm"] - moves[0]) <= 0.1), None)
        out.append(_c("moves only to a position that was felt", hit, f"{moves[0]} mm"))
        low, high = 31.0 * .95, 31.0 * 1.05
        safe = [t for t in table if t["tone_hz_high"] < low or t["tone_hz_low"] > high]
        out.append(_c("the felt tone stays clear of the pump", hit in safe if hit else False, f"danger band {low:.2f} to {high:.2f} Hz"))
        best = min(safe, key=lambda t: abs(t["support_mm"] - 84.5))
        out.append(_c("the smallest safe move", hit == best, f"smallest safe move is to {best['support_mm']} mm"))
    return out


_TOK = re.compile(r"\s*(T#\w+|[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_]+)?|\d+\.?\d*|:=|<=|>=|<>|[=<>+\-*/(),;:])")


def _tokens(src: str) -> list[str]:
    src = re.sub(r"\(\*.*?\*\)", " ", src, flags=re.S)
    out, i = [], 0
    while i < len(src):
        if src[i:].strip() == "":
            break
        m = _TOK.match(src, i)
        if not m:
            raise ValueError(f"can't read this near: {src[i:i + 30]!r}")
        out.append(m.group(1))
        i = m.end()
    return out


class _ST:
    """A small reader for the Structured Text these files use. It walks the file itself and runs nothing else, so model text is never executed as Python."""
    def __init__(self, src: str):
        m = re.search(r"FUNCTION_BLOCK\s+PHYSICA_BLADE_GUARD(.*?)END_FUNCTION_BLOCK", src, flags=re.S)
        if not m:
            raise ValueError("no FUNCTION_BLOCK named PHYSICA_BLADE_GUARD")
        body = m.group(1)
        self.init: dict = {}
        for block in re.findall(r"VAR\w*(.*?)END_VAR", body, flags=re.S):
            for line in re.sub(r"\(\*.*?\*\)", " ", block, flags=re.S).split(";"):
                d = re.match(r"\s*(\w+)\s*:\s*(\w+)\s*(?::=\s*([\w.]+))?", line)
                if d:
                    self.init[d.group(1)] = (d.group(3) == "TRUE") if d.group(2) == "BOOL" and d.group(3) else (float(d.group(3)) if d.group(3) else (False if d.group(2) == "BOOL" else 0))
        code = re.sub(r"VAR\w*.*?END_VAR", " ", body, flags=re.S)
        self.t, self.i = _tokens(code), 0
        self.prog = self._block(())
        if self.i < len(self.t):
            raise ValueError(f"can't read past {self.t[self.i]}")

    def _peek(self):
        return self.t[self.i] if self.i < len(self.t) else None

    def _take(self, want=None):
        tok = self._peek()
        if tok is None or (want and tok != want):
            raise ValueError(f"expected {want}, found {tok}")
        self.i += 1
        return tok

    def _block(self, stops):
        out = []
        while self._peek() is not None and self._peek() not in stops:
            if self._peek() in ("ELSIF", "ELSE", "END_IF", "END_CASE"):
                break
            if len(self.t) > self.i + 1 and re.fullmatch(r"\d+", self._peek()) and self.t[self.i + 1] == ":":
                break
            out.append(self._stmt())
        return out

    def _stmt(self):
        tok = self._take()
        if tok == ";":
            return ("nop",)
        if tok == "IF":
            arms, other = [], []
            cond = self._expr()
            self._take("THEN")
            arms.append((cond, self._block(())))
            while self._peek() == "ELSIF":
                self._take()
                cond = self._expr()
                self._take("THEN")
                arms.append((cond, self._block(())))
            if self._peek() == "ELSE":
                self._take()
                other = self._block(())
            self._take("END_IF")
            self._take(";")
            return ("if", arms, other)
        if tok == "CASE":
            sel = self._expr()
            self._take("OF")
            arms, other = {}, []
            while self._peek() not in ("END_CASE", "ELSE"):
                n = int(self._take())
                self._take(":")
                arms[n] = self._block(())
            if self._peek() == "ELSE":
                self._take()
                other = self._block(())
            self._take("END_CASE")
            self._take(";")
            return ("case", sel, arms, other)
        if self._peek() == ":=":
            self._take()
            val = self._expr()
            self._take(";")
            return ("set", tok, val)
        if self._peek() == "(":
            self._take()
            args = {}
            while self._peek() != ")":
                k = self._take()
                self._take(":=")
                args[k] = self._expr()
                if self._peek() == ",":
                    self._take()
            self._take(")")
            self._take(";")
            return ("call", tok, args)
        raise ValueError(f"can't read a statement starting {tok}")

    def _expr(self):
        return self._bin(0)

    _LEVELS = (("OR",), ("AND",), ("=", "<>", "<=", ">=", "<", ">"), ("+", "-"), ("*", "/"))

    def _bin(self, n):
        if n == len(self._LEVELS):
            return self._atom()
        left = self._bin(n + 1)
        while self._peek() in self._LEVELS[n]:
            op = self._take()
            left = ("op", op, left, self._bin(n + 1))
        return left

    def _atom(self):
        tok = self._take()
        if tok == "NOT":
            return ("not", self._atom())
        if tok == "(":
            e = self._expr()
            self._take(")")
            return e
        if tok == "TRUE" or tok == "FALSE":
            return ("num", tok == "TRUE")
        if tok.startswith("T#"):
            return ("num", tok)
        if re.fullmatch(r"\d+\.?\d*", tok):
            return ("num", float(tok))
        if re.fullmatch(r"[A-Za-z_]\w*(\.[A-Za-z_]+)?", tok):
            return ("var", tok)
        raise ValueError(f"can't read {tok}")

    def fresh(self) -> dict:
        return {**{k: v for k, v in self.init.items()}, "_timer": 0, "HEAT_TIMER.Q": False}

    def _val(self, e, env):
        kind = e[0]
        if kind == "num":
            return e[1]
        if kind == "var":
            if e[1] not in env:
                raise ValueError(f"{e[1]} was never declared")
            return env[e[1]]
        if kind == "not":
            return not self._val(e[1], env)
        a, b = self._val(e[2], env), self._val(e[3], env)
        return {"OR": lambda: a or b, "AND": lambda: a and b, "=": lambda: a == b, "<>": lambda: a != b, "<=": lambda: a <= b, ">=": lambda: a >= b, "<": lambda: a < b, ">": lambda: a > b,
                "+": lambda: a + b, "-": lambda: a - b, "*": lambda: a * b, "/": lambda: a / b}[e[1]]()

    def _run(self, stmts, env):
        for s in stmts:
            if s[0] == "set":
                if s[1] not in env:
                    raise ValueError(f"{s[1]} was never declared")
                env[s[1]] = self._val(s[2], env)
            elif s[0] == "if":
                for cond, body in s[1]:
                    if self._val(cond, env):
                        self._run(body, env)
                        break
                else:
                    self._run(s[2], env)
            elif s[0] == "case":
                self._run(s[2].get(int(self._val(s[1], env)), s[3]), env)
            elif s[0] == "call":
                if s[1] != "HEAT_TIMER":
                    raise ValueError(f"only HEAT_TIMER can be called, not {s[1]}")
                on = self._val(s[2]["IN"], env) if "IN" in s[2] else True
                env["_timer"] = env["_timer"] + 1 if on else 0
                env["HEAT_TIMER.Q"] = bool(on and env["_timer"] >= 3)

    def scan(self, env: dict, verdict: int, score: float, reset: bool = False) -> dict:
        env.update(VERDICT=verdict, SCORE_X100=score, RESET_BY_INSPECTOR=reset)
        self._run(self.prog, env)
        return dict(env)


def scenarios(st: _ST, limit_x100: int) -> list[dict]:
    """The goal, run as situations, scan by scan."""
    def run(seq):
        env = st.fresh()
        return [st.scan(env, *x) for x in seq]
    out = []
    a = run([(0, 500)] * 6)
    out.append(_c("just weather: it keeps running", all(x["RUN_PERMIT"] and not x["BRAKE"] for x in a)))
    for name, code in (("crack", 2), ("structural", 3), ("can't tell", 4)):
        b = run([(0, 500)] + [(code, 3000)] * 3 + [(0, 500)] * 3)
        out.append(_c(f"{name}: stops, brakes, sends inspection, and stays stopped", all(not x["RUN_PERMIT"] and x["BRAKE"] and x["DISPATCH_INSPECTION"] for x in b[2:])))
    c = run([(0, 500)] + [(code2, 500) for code2 in (2, 2)] + [(0, 500, True)] + [(0, 500)] * 3)
    out.append(_c("only the inspector's reset restarts it", c[2]["RUN_PERMIT"] is False and c[-1]["RUN_PERMIT"]))
    d = run([(0, 500), (1, limit_x100)] + [(0, limit_x100)] * 8)
    out.append(_c("ice, promise kept: heats, then restarts", any(x["HEATERS_ON"] and not x["RUN_PERMIT"] for x in d) and d[-1]["RUN_PERMIT"] and not d[-1]["BRAKE"]))
    e = run([(0, 500), (1, limit_x100 + 1)] + [(0, limit_x100 + 1)] * 8)
    out.append(_c("ice, promise broken: never restarts", any(x["HEATERS_ON"] for x in e) and not e[-1]["RUN_PERMIT"] and e[-1]["BRAKE"] and e[-1]["DISPATCH_INSPECTION"]))
    return out


def check_turbine(text: str, rec: dict) -> list[dict]:
    from physica.outcome import check
    from physica.outcome.compile import plc
    limit = int(round(rec["felt"][0]["value"] * 100))
    try:
        st = _ST(text)
    except ValueError as e:
        return [_c("the file can be read", False, str(e)[:200])]
    out = [_c("the file can be read", True)]
    try:
        out += scenarios(st, limit)
    except (ValueError, KeyError, TypeError) as e:
        out.append(_c("the logic runs through every situation", False, str(e)[:200]))
    tail = plc.blade_guard(24.32, "x").split("END_FUNCTION_BLOCK", 1)[1]
    r = check.matiec(text.split("END_FUNCTION_BLOCK", 1)[0] + "END_FUNCTION_BLOCK" + tail)
    if r.get("ran"):
        out.append(_c("compiled by matiec", r.get("passed"), "; ".join(map(str, r.get("errors", [])))[:200]))
    return out


def _metres(lat, lon, lat0, lon0):
    return (lat - lat0) * 111320.0, (lon - lon0) * 111320.0 * math.cos(math.radians(lat0))


def check_drone(text: str, rec: dict, hub: float = 60.0, blade: float = 30.0, step: float = 4.0) -> list[dict]:
    from physica.outcome import check
    lines = [ln for ln in text.strip().splitlines() if ln.strip()]
    if not lines or not lines[0].startswith("QGC WPL 110"):
        return [_c("QGC WPL 110 file", False, "first line must be QGC WPL 110")]
    rows, bad = [], []
    for ln in lines[1:]:
        p = ln.split()
        if len(p) != 12:
            bad.append(ln[:40])
            continue
        try:
            rows.append({"cmd": int(p[3]), "lat": float(p[8]), "lon": float(p[9]), "alt": float(p[10])})
        except ValueError:
            bad.append(ln[:40])
    out = [_c("QGC WPL 110 file", not bad and rows, "; ".join(bad[:2]))]
    if not rows:
        return out
    odd = sorted({r["cmd"] for r in rows if r["cmd"] not in (16, 22, 203, 21, 195, 197)})
    out.append(_c("only allowed commands", not odd, str(odd)))
    path, alt = [], 0.0
    photos = []
    home = rows[0]
    x, y = _metres(home["lat"], home["lon"], 56.2, 9.5)
    path.append((x, y, 0.0))
    for r in rows[1:]:
        if r["cmd"] == 203:
            photos.append(path[-1][2])
        elif r["cmd"] == 22:
            path.append((path[-1][0], path[-1][1], r["alt"]))
        elif r["cmd"] == 16:
            x, y = _metres(r["lat"], r["lon"], 56.2, 9.5)
            path.append((x, y, r["alt"]))
        elif r["cmd"] == 21:
            path.append((path[-1][0], path[-1][1], 0.0))
    near, top = 1e9, 0.0
    for a, b in zip(path[:-1], path[1:]):
        for k in range(21):
            f = k / 20
            px, py, pz = a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f
            top = max(top, pz)
            if pz <= hub + 2:
                near = min(near, math.hypot(px, py))
    out.append(_c("stays at least 10 m from the tower and blade", near >= 10, f"closest {near:.1f} m"))
    out.append(_c("stays at or under 120 m", top <= 120, f"highest {top:.1f} m"))
    shots = sorted(photos)
    gap = max((b - a for a, b in zip(shots[:-1], shots[1:])), default=99)
    top, bottom = hub - 1.5, max(hub - 1.5 - blade, 5.0)
    out.append(_c(f"photos cover the blade with no gap over {step + 1:g} m", shots and shots[0] <= bottom + 2.5 and shots[-1] >= top - 1 and gap <= step + 1, f"{len(shots)} photos, from {shots[0] if shots else '?'} to {shots[-1] if shots else '?'} m"))
    out.append(_c("finishes by landing", rows[-1]["cmd"] == 21, ""))
    r = check.mavlink_mission(text)
    if r.get("ran"):
        out.append(_c("loads in pymavlink", r.get("passed"), str(r.get("error", ""))[:160]))
    return out


CHECKS = {"beam": check_beam, "turbine": check_turbine, "drone": check_drone}
PROMPT = """You are writing a real machine file. A person reviews it before anything runs. Nothing you write reaches a machine directly.
Goal: {goal}

What was felt, as measured. Use these numbers. Don't invent others:
{felt}

Write it in {language}. Rules:
{rules}

Reply as JSON: {{"file": "<the complete file>", "why": "<one sentence: which felt number decided your choice>"}}"""


def _reply_in(text: str) -> dict | None:
    """Muse Code prints events as JSON lines. Its answer is somewhere in the last ones, so look through every string, newest first."""
    from physica.meta import scout as SC

    def strings(v):
        if isinstance(v, str):
            yield v
        elif isinstance(v, dict):
            for x in v.values():
                yield from strings(x)
        elif isinstance(v, list):
            for x in v:
                yield from strings(x)
    for line in reversed(text.splitlines()):
        try:
            found = list(strings(json.loads(line)))
        except ValueError:
            found = [line]
        for s in reversed(found):
            if '"file"' not in s:
                continue
            try:
                got = SC.parse_json(s)
            except Exception:
                continue
            if isinstance(got, dict) and got.get("file"):
                return got
    return None


def muse_code(prompt: str, machine: str) -> dict:
    """Muse Code, Meta's coding agent, run with `muse exec`. It answers in text and we check it here, so it needs no approval to run tools. Never run with --yolo, which turns off its sandbox."""
    exe = shutil.which("muse")
    if not exe:
        raise ValueError("The muse command isn't installed here. Reports say it needs Linux, macOS, or WSL2 on Windows. Use --engine spark, which needs nothing extra")
    env = dict(os.environ)
    if mc.api_key() and not env.get("META_API_KEY"):
        env["META_API_KEY"] = mc.api_key()
    with tempfile.TemporaryDirectory() as d:
        task = Path(d) / "task.md"
        task.write_text(prompt)
        r = subprocess.run([exe, "exec", "--json", "--disable-web-tools", "--no-foreign-personal-context", "--max-model-steps", "12", "--reasoning-effort", "medium", "--prompt-file", str(task)],
                           cwd=d, env=env, capture_output=True, text=True, timeout=420)
    if r.returncode:
        raise ValueError(f"muse exec stopped with code {r.returncode}: {(r.stderr or r.stdout)[-300:]}")
    return _reply_in(r.stdout) or {"why": "no file in Muse Code's reply"}


def write(machine: str, on_step=print, rounds: int = ROUNDS, engine: str = "spark") -> dict:
    """Muse writes, code checks, and failures go back with the exact errors. Stops after a few rounds and says so."""
    from physica.meta import scout as SC
    if engine == "spark" and mc.is_mock():
        raise ValueError("Muse needs your Meta key for this. Set MODEL_API_KEY and MOCK=0 in this window")
    rec = records()[machine]
    prompt = PROMPT.format(goal=rec["goal"], felt=json.dumps(rec["felt"], indent=1), language=rec["language"], rules="\n".join("- " + r for r in rec["rules"]))
    tries, prev, usd = [], None, 0.0
    first = prompt
    for n in range(1, rounds + 1):
        if engine == "muse-code":
            said = muse_code(prompt, machine)
            text = str(said.get("file") or "")
            checks = CHECKS[machine](text, rec)
            failed = [c for c in checks if not c["ok"]]
            tries.append({"round": n, "file": text, "why": said.get("why"), "checks": checks})
            on_step(f"{machine}, Muse Code round {n}: " + ("every check passed" if not failed else f"{len(failed)} failed: " + "; ".join(c["check"] for c in failed)))
            if not failed:
                break
            prompt = f"{first}\n\nYour last file:\n{text}\n\nIt failed these checks. Fix it and send the complete file again as the same JSON.\n" + "\n".join(f"- {c['check']}: {c['detail']}" for c in failed)
            continue
        r = mc.respond("spark", [{"role": "user", "content": [{"type": "input_text", "text": prompt}]}], f"physica_speak_{machine}", previous_response_id=prev, effort="medium", schema=ANSWER)
        usd += float(r.get("usd") or 0)
        prev = r.get("response_id") or prev
        try:
            said = SC.parse_json(r["content"])
            text = str(said.get("file") or "")
        except Exception as e:
            said, text = {"why": f"unreadable reply: {str(e)[:100]}"}, ""
        checks = CHECKS[machine](text, rec)
        failed = [c for c in checks if not c["ok"]]
        tries.append({"round": n, "file": text, "why": said.get("why"), "checks": checks})
        on_step(f"{machine}, round {n}: " + ("every check passed" if not failed else f"{len(failed)} failed: " + "; ".join(c["check"] for c in failed)))
        if not failed:
            break
        errors = "Your file failed these checks. Fix it and send the complete file again as the same JSON.\n" + "\n".join(f"- {c['check']}: {c['detail']}" for c in failed)
        prompt = errors if prev else f"{prompt}\n\nYour last file:\n{text}\n\n{errors}"
    passed = not failed
    out = {"machine": machine, "title": rec["title"], "language": rec["language"], "goal": rec["goal"], "felt": rec["felt"], "source": rec["source"], "passed": passed, "rounds": len(tries), "tries": tries, "usd": round(usd, 4) if engine == "spark" else None, "model": mc.model_id("spark") if engine == "spark" else "Muse Code", "engine": engine, "live_meta": True}
    if passed:
        FILES.mkdir(parents=True, exist_ok=True)
        (FILES / f"{machine}.{rec['ext']}").write_text(text)
        out["sealed"] = _seal.seal({"sha256_of_file": hashlib.sha256(text.encode()).hexdigest(), "machine": machine}, "the file Muse wrote and code checked")["anchor"]
    saved = json.loads(OUT.read_text()) if OUT.exists() else {"label": "MUSE WROTE THESE. CODE CHECKED THEM. A PERSON REVIEWS THEM", "machines": {}}
    saved["machines"][machine] = out
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(saved, indent=1, default=float))
    return out


def main(argv: list[str]) -> None:
    import argparse
    ap = argparse.ArgumentParser(prog="physica speak", description="Muse writes the machine's language from what was felt, and code checks it.")
    ap.add_argument("--machine", choices=[*CHECKS, "all"], default="all")
    ap.add_argument("--engine", choices=["spark", "muse-code"], default="spark", help="spark uses your API key. muse-code runs Meta's muse command, if it's installed")
    ap.add_argument("--check", metavar="FILE", help="check a file you already have, written by anything. Needs one --machine. No model is called")
    ap.add_argument("--allow-billed-meta", action="store_true")
    a = ap.parse_args(argv)
    if a.check:
        if a.machine == "all":
            raise SystemExit("Say which machine: --machine beam, turbine or drone")
        rows = CHECKS[a.machine](Path(a.check).read_text(), records()[a.machine])
        for c in rows:
            print(("PASS " if c["ok"] else "FAIL ") + c["check"] + (f": {c['detail']}" if c["detail"] else ""))
        raise SystemExit(0 if all(c["ok"] for c in rows) else 1)
    if not a.allow_billed_meta:
        raise SystemExit("This uses Muse. Add --allow-billed-meta to go ahead")
    for m in (CHECKS if a.machine == "all" else [a.machine]):
        print(f"\n{records()[m]['title']}: {records()[m]['language']}")
        r = write(m, engine=a.engine)
        print(f"{'Passed' if r['passed'] else 'Not passed'} after {r['rounds']} round(s)" + (f", ${r['usd']}." if r["usd"] is not None else "."))
