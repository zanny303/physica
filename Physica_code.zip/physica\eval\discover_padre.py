"""The Physica Loop on real PADRE flights: rival theories for 'what a healthy arm feels like', proven on
held-out windows, plus the next experiment Physica asks for. Writes eval/results/discover_padre.json."""
from __future__ import annotations

import json

import numpy as np

from common import CFG, healthy_split, padre_features, save_result
from physica.discover.loop import discover_selfmodel
from physica.feel.selfmodel import OperatingPointSelfModel


def main():
    split = healthy_split()
    h = padre_features("0000")
    cal, ho = np.array(split["calib"]), np.array(split["heldout"])
    sm = OperatingPointSelfModel(unit_names=list("ABCD")).fit(h["op"][cal], h["lvl"][cal])
    thr = sm.calibrate_threshold(h["op"][cal], h["lvl"][cal], CFG.q, CFG.margin)
    res = discover_selfmodel(h["op"], h["lvl"], list("ABCD"), cal, ho, thr, sm.sigma)
    save_result("discover_padre", res)
    for u, v in res["units"].items():
        p = v["proof"]
        print(u, p["verdict"], "winner:", p.get("winner"), "| held-out RMSE:",
              {t["name"]: round(t.get("rmse_prove", float("nan")), 3) for t in p["theories"] if t.get("status") == "ran"})
        print("   next:", v["next_step_inside_range"]["action"], "| outside range:", (v["outside_range"] or {}).get("verdict"))
    print(res["spark_mode"])


if __name__ == "__main__":
    main()
