"""Generate a tiny SYNTHETIC PILOT for testing the training implementation only.

NEVER use this result as proof of public dataset performance or machine sensing.
"""
from __future__ import annotations
import csv, json
from pathlib import Path
import numpy as np
from .train import train_manifest


def generate(out_dir,seed=21):
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(seed)
    fs=2048;n=2048;t=np.arange(n)/fs
    rows=[]
    for label in (0,1):
        for group_index in range(10):
            body_id=f'SIM_{"DAMAGED" if label else "HEALTHY"}_{group_index:02}'
            base_freq=42+rng.normal(0,3)
            offset=rng.normal(0,1.2)
            for j in range(2):
                phase=rng.uniform(-np.pi,np.pi)
                vibration=.35*np.sin(2*np.pi*(base_freq+offset)*t+phase)+rng.normal(0,.10,n)
                current=.45*np.sin(2*np.pi*base_freq*t+.7*phase)+rng.normal(0,.12,n)
                if label:
                    vibration+=.29*np.sin(2*np.pi*(base_freq*2.7)*t)+.10*np.sin(2*np.pi*120*t+phase)
                    current+=.22*np.sin(2*np.pi*base_freq*1.4*t + phase)
                name=f'{body_id}_{j}.csv'
                with (out/name).open('w',newline='') as f:
                    w=csv.writer(f);w.writerow(['vibration','current'])
                    w.writerows(zip(vibration,current))
                rows.append({'path':name,'body_id':body_id,'label':label,'sample_rate_hz':fs,
                             'channels':{'vibration':'vibration','current':'current'},
                             'operating_condition':f'condition_{j}',
                             'units':'SYNTHETIC_ARBITRARY_UNITS'})
    manifest={'schema':'physica.remote.signals.v1','origin':'SIMULATED_TRAINING_PILOT',
              'source':'GENERATED_BY_PHYSICA_SIMULATOR_NOT_REAL',
              'recordings':rows}
    f=out/'manifest.json';f.write_text(json.dumps(manifest,indent=2)+'\n')
    return f


def run(out_dir,seed=21):
    manifest=generate(out_dir,seed)
    from .next_sensation import train_next
    trained=train_manifest(manifest,Path(out_dir)/'trained_weights',seed)
    train_next(manifest,Path(out_dir)/'next_sensation_weights',seed)
    return trained

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--seed',type=int,default=21)
    args=p.parse_args();print(json.dumps(run(args.out,args.seed)['baselines'],indent=2))
