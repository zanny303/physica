"""Physica's bounded *internal imagination* of physical sensation.

Approved, reversible candidate actions are scored by anticipated sensor
response and preference. Outputs only recommendations, NEVER actuator commands.
"""
from __future__ import annotations
import math
import numpy as np
from .core import Body,Sense,predict_senses


def rank_counterfactual_actions(body:Body,senses,times,initial_state,actions,*,friction_force_n,
                                target_sensor_id,target_value=0.,max_cost=1.,max_risk=.2):
    if target_sensor_id not in senses:raise ValueError('target sensation missing calibrated sensor')
    if not all(math.isfinite(x) for x in (friction_force_n,target_value,max_cost,max_risk)) or max_cost<0 or not 0<=max_risk<=1:
        raise ValueError('invalid counterfactual preferences')
    out=[]
    for c in actions:
        id_=str(c.get('id',''))
        try:
            cost=float(c['cost']);risk=float(c['risk']);force=c['force_n']
            if not c.get('approved') is True or not c.get('reversible') is True or not 0<=risk<=max_risk or not 0<=cost<=max_cost:
                raise ValueError('unapproved/irreversible/costly action')
            if not math.isfinite(cost) or not math.isfinite(risk):raise ValueError('non-finite')
            predicted=predict_senses(body,times,force,initial_state,senses,
                            friction_force_n=friction_force_n)
            vals=predicted['sensations'][target_sensor_id]
            rms=float(np.sqrt(np.mean((vals-target_value)**2)))
            if not math.isfinite(rms):raise ValueError('non-finite forecast')
            out.append({'id':id_,'status':'SAFE_SIMULATION_ONLY','expected_sensory_rmse':rms,
                        'sensor_unit':senses[target_sensor_id].unit,'score':rms+cost*.1+risk*.1})
        except (KeyError,ValueError,TypeError,OverflowError):
            out.append({'id':id_,'status':'REFUSE','score':None})
    eligible=[v for v in out if v['status']=='SAFE_SIMULATION_ONLY']
    eligible.sort(key=lambda v:v['score'])
    return {'status':'RECOMMEND_SUPERVISED_PROBE_NO_ACTUATION' if eligible else 'ABSTAIN',
            'recommended_id':eligible[0]['id'] if eligible else None,
            'evaluated':out,
            'warning':'A simulated sensor preference is not a safety certification or physical actuator command.'}
