"""Optional authenticated Muse transfer strategist with constrained experimental role.

Meta receives only pre-reveal descriptions and candidate indices, can nominate a
safe probe or request a new sensor, and never sets weights, verifies evidence,
or actuates machines. Selection is subject to independent numerical score gates.
"""
from __future__ import annotations
import hashlib
import json
import os
import urllib.request

PROMPT=('You are an experimental design ADVISOR, not a sensor or scientific verifier. '
        'A machine has a calibrated posterior from target observations and source experience. '
        'Choose at most ONE approved reversible probe from the provided indexed candidate list; '
        'or request a missing measurement; or abstain. Your text is never evidence. '
        'Do not invent sensor values or submit equations, code, device commands, or hidden ground truth. '
        'You may consider embodiment differences and plausible confounders. '
        'Your choice will be rejected unless it meets a numerical information-value gate. '
        'No automatic physical actuation is permitted.')
SCHEMA={'type':'object','additionalProperties':False,'properties':{
   'mode':{'type':'string','enum':['choose_probe','request_sensor','abstain']},
   'candidate_index':{'type':'integer'},
   'measurement_needed':{'type':'string'},
   'rationale':{'type':'string'},
   'possible_confounds':{'type':'array','items':{'type':'string'},'maxItems':5},
   'falsification_criterion':{'type':'string'}},
   'required':['mode','candidate_index','measurement_needed','rationale','possible_confounds','falsification_criterion']}
MODELS=('muse-spark-1.3','muse-wonder-1.0')


def request_preview(rank_result, candidate_rows, *, model='muse-wonder-1.0', top=12):
    if model not in MODELS:raise ValueError('unsupported Meta model')
    ranked=rank_result.get('ranked',[])[:top]
    allowed=[]
    for r in ranked:
        j=r['index'];c=candidate_rows[j]
        allowed.append({'candidate_index':j,'state':{k:float(c[k]) for k in ('x','v','u')},
                        'numerical_target_information_gain':float(r['expected_target_variance_reduction']),
                        'risk':float(r['risk']),'cost':float(r['cost'])})
    if not allowed:raise ValueError('no safe candidates to offer')
    context={'available_safe_candidates':allowed,
             'objective':'choose the most informative safe physical probe for receiving machine future task',
             'allowed_evidence':'context, predeclared probe geometry and predicted information value only',
             'not_provided':'unseen target responses, hidden coefficients or real-world proof',
             'sensor_access':'none; request separate independent measurement if necessary'}
    return {'model':model,
       'messages':[{'role':'developer','content':PROMPT},
                   {'role':'user','content':json.dumps(context,sort_keys=True,allow_nan=False)}],
       'response_format':{'type':'json_schema','json_schema':{'name':'physica_transfer_strategy_v014',
                                                'strict':True,'schema':SCHEMA}}},allowed


def parse_reply(response):
    if isinstance(response,str):response=json.loads(response)
    if not isinstance(response,dict) or set(response)!=set(SCHEMA['required']):
        raise ValueError('unexpected Meta reply fields')
    if response['mode'] not in ('choose_probe','request_sensor','abstain'):
        raise ValueError('unrecognized recommendation mode')
    if type(response['candidate_index']) is not int:
        raise ValueError('candidate index must be integer')
    for k in ('measurement_needed','rationale','falsification_criterion'):
        if not isinstance(response[k],str) or len(response[k])>700:raise ValueError('invalid text field')
    if not isinstance(response['possible_confounds'],list) or len(response['possible_confounds'])>5 or any(
        not isinstance(v,str) or len(v)>180 for v in response['possible_confounds']):
        raise ValueError('invalid confounds')
    return response


def gated_choice(reply,rank_result,candidates, *, relative_min_gain=.7):
    """Meta influences choice only among numerically admissible safe probes.

    Relative gain gate prevents the LLM from discarding task-specific benefits.
    All outputs remain human-review-only, even when a candidate is accepted.
    """
    reply=parse_reply(reply)
    if not 0<=relative_min_gain<=1:raise ValueError('invalid information gate')
    if reply['mode']!='choose_probe':
        return {'status':'REQUEST_ADDITIONAL_SENSOR' if reply['mode']=='request_sensor' else 'ABSTAIN',
                'meta_selected_index':None,'approved_for_hardware':False,
                'measurement_needed':reply['measurement_needed']}
    permissible={entry['index']:entry for entry in rank_result['ranked']}
    selected=permissible.get(reply['candidate_index'])
    if selected is None or reply['candidate_index']>=len(candidates):
        return {'status':'META_UNSAFE_OR_UNKNOWN_CANDIDATE_REJECTED','meta_selected_index':None,
                'approved_for_hardware':False}
    top=rank_result['ranked'][0]
    if (selected['expected_target_variance_reduction'] <
        relative_min_gain*top['expected_target_variance_reduction']):
        return {'status':'META_PROBE_INFORMATION_GATE_REFUSED','meta_selected_index':None,
                'recommended_numerical_index':top['index'],'approved_for_hardware':False}
    return {'status':'META_PROBE_NUMERICALLY_ADMISSIBLE_REQUIRES_HUMAN_APPROVAL',
            'meta_selected_index':reply['candidate_index'],'recommended_numerical_index':top['index'],
            'estimated_target_variance_reduction':selected['expected_target_variance_reduction'],
            'approved_for_hardware':False,'candidate_influenced_by_meta':True,
            'scientific_verification':False}


def live_advise(rank_result,candidates,*,model='muse-wonder-1.0',allow_billed=False):
    if not allow_billed:raise PermissionError('explicit --allow-billed-meta required')
    key=os.getenv('MODEL_API_KEY')
    if not key:raise RuntimeError('MODEL_API_KEY missing')
    request,options=request_preview(rank_result,candidates,model=model)
    payload=json.dumps(request,allow_nan=False).encode()
    from physica.llm import meta_client as mc
    data=mc.post_raw('chat/completions',json.loads(payload),task='mace_x_strategy')
    choice=data['choices'][0]
    if choice.get('finish_reason') in ('length','content_filter'):
        raise ValueError('incomplete Meta response')
    proposal=parse_reply(choice['message']['content'])
    gate=gated_choice(proposal,rank_result,candidates)
    return {'status':gate['status'],'gate':gate,'proposal':proposal,
            'request_sha256':hashlib.sha256(payload).hexdigest(),
            'response_sha256':hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest(),
            'provider_response_id':data.get('id'),'model':data.get('model',model),
            'origin':'AUTHENTICATED_META_NOT_INDEPENDENT_PHYSICAL_EVIDENCE',
            'candidate_offered_count':len(options),'no_actuation':True}


def replay_one_probe(nomination,world,*,origin='OFFLINE_USER_SUPPLIED'):
    """Score an unverified suggestion on a newly revealed simulated B probe.

    The nomination is a frozen external input. Test labels never enter the
    proposal/ranking stage. The same one-target-observation budget is used for
    Meta-suggested and numerical-only probes; source data are shared.
    """
    from .core import fit_target,rank_probes,calibrated_rows,predict
    import numpy as np
    mem=world['memory'];target=world['target_id']
    before=fit_target([],mem,mode='mixture',target_id=target)
    ranking=rank_probes(before,world['candidates'],world['queries'])
    gate=gated_choice(nomination,ranking,world['candidates'])
    no_meta=ranking['ranked'][0]['index']
    chosen=gate.get('meta_selected_index')
    # The numerically best action always exists; reject or abstain is reported.
    result={'schema':'physica.mace_x.meta_probe_replay.v014',
            'origin':origin,'meta_status':gate['status'],
            'numerical_only_selected_index':no_meta,
            'meta_selected_index':chosen,'target_observation_budget':1,
            'score_origin':'SIMULATION_ONLY','live_meta_authenticated':False,
            'full_mace_x_prior_used_in_both_arms':True}
    for key,idx in [('numerical_only',no_meta),('meta_suggested',chosen)]:
        if idx is None:continue
        r=calibrated_rows([world['reveal'](idx)],world['calibration'])
        posterior=fit_target(r,mem,mode='mixture',target_id=target)
        estimates=predict(posterior,world['queries'])['mean']
        result[key+'_heldout_rmse']=float(np.sqrt(np.mean((estimates-world['test_truth'])**2)))
    result['test_outcomes_used_to_select_probe']=False
    result['does_not_prove_meta_value_without_authenticated_replicates']=True
    return result
