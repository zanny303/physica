# v0.29 — Reliable Feeling and Evidence-Gated Curiosity

- Fixed absent PADRE replay HTTP 422 by returning an honest unavailable-evidence verdict, not synthetic results. The viewer disables measurement-dependent actions when data is missing.
- Rejects malformed source IDs, replay traversal, and unsafe replay target identifiers. Actual correctly sourced replay files remain supported.
- Added operating-envelope-aware held-out calibration for sensory surprise to the shared printer, turbine and F1 inquiry pipeline, with conservative refusal on unknown/mismatched operating conditions, units, or reused calibration evidence.
- Added a CLI to build calibration profiles from separately recorded normal runs. Profile generation is not a scientific certification.
- Made experiment ranking optionally account for empirically estimated model discrepancy, preventing overconfident candidate likelihoods.
- Added reproducible heavy-tailed synthetic stress comparisons and additional negative-control regression tests.
- Retained original Muse Research Council, A→B sealed prediction workflow, Studio, and all original applications.
- Full legacy suite and all actual Meta/physical device integrations still require independent verification; do not use this software to authorize hazardous machine operation.
