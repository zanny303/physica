"""Sealed promises: what the sensors will read after the action, fixed (Ed25519 + SHA-256 + UTC) before it happens."""
from __future__ import annotations

from physica import seal as _seal


def seal_promise(quantity: str, lo: float, hi: float, what: str, **extra) -> dict:
    return _seal.seal({"intervals": {quantity: [round(float(lo), 3), round(float(hi), 3)]}, **extra}, what)


def grade(sealed: dict, quantity: str, measured: float) -> dict:
    return _seal.reveal(sealed, {quantity: float(measured)}, _seal.interval_grade)
