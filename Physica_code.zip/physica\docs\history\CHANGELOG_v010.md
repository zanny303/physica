# Physica v0.10 MACE — Integrative Research Candidate

Based on complete v0.9 source. Prior Studio, Lab, Discover, Lens, CIRTE/CRATE, remote training, field evidence, SAM, Muse adapters, translators and legacy experiments remain intact.

## Implemented
- A bounded mechanism feature grammar that accepts manually specified or optionally **authenticated Muse-generated** candidate functional forms, refuses unsupported inputs and never executes model-generated code.
- Source-action causal parameter fitting and **episode-disjoint held-out validation** before accepting a candidate; coefficient updates computed only from measured numerical records.
- Reversible, non-actuating experiment ranking from model disagreement, target priorities, costs and bounded risk, with refusal of unsafe/unavailable candidates.
- Independent target probes, selective regularization, and rollout-based transfer checks; post-probe forecasts are signed BEFORE synthetic target test outcome generation.
- Multisensory learned state via existing PCA/ridge model, exercised and scored inside the same end-to-end simulation; this is not deep foundation-model training.
- Conservative virtual-sensor/extra-sense registry (magnetics, radar, ultrasonics, chemistry, electrical and thermal data). Missing or uncalibrated channels never become ground truth.
- Evidence-limited consumer investigation (washing machine, robot arm, 3D printer) via browser and CLI; optional before/after comparisons without fault hallucination.
- Evidence-recomputed **review-only** printer configuration from signed raw accelerometer CSV, optional existing machine translators, no actuator access.
- Prospective real-data CSV manifest importer with raw SHA256 checks and disjoint train/validation/test episodes.
- Strict Muse Spark/Wonder JSON schema mechanism nomination with private opt-in `MODEL_API_KEY` billable calls. Cached nomination can be fed into the numerical mechanism comparison. Requests blocked by default in Studio.
- New `MACE Investigation` area in Unified Studio; HTML evidence exhibit; runnable benchmark and additional adversarial tests.

## Not implemented or verified
- No open-ended autonomous discovery of universal laws, no physical five-sense robot, no electronic nose/tongue hardware, no glasses SDK-native app, no pretrained V-JEPA weights inference and no fine-tuned Muse models. No authenticated Meta request run when assembling this release. No external Paderborn recordings trained in this environment. No real prospective A→B→C hardware trials.
- All demonstration measurements, mechanisms and impressive synthetic fits are known simulator data. A held-out *within-simulator* intervention does not establish scientific novelty.
- Locally generated signatures do not independently verify chronology or honest measurement origin.
- Target-only can outperform transferred knowledge; all outcomes are reported.

See `docs/V010_MACE_RESEARCH_AND_REAL_DEPLOYMENT.md` for implementation, commands, limitations and literature.

### Reproducible synthetic 12-seed benchmark
- 12 simulator seeds, 24 target cases; mean transfer future-camera RMSE **0.005491 m** vs same local/probe budget target-only **0.006038 m** (roughly 9.1% lower mean).
- Transfer beats target-only in **9/24 (37.5%)** of targets. Other targets favor conventional local estimation. This is not a per-case consistent advantage.
- The human-specified temperature-dependent candidate was selected on A in **12/12** synthetic runs. This is **not** evidence of model-discovered physics nor of Meta benefit, because the candidate term matches a mechanism programmed into the simulator.
- A learned PCA/ridge sensory predictor also runs on the source machine; its latent representation is separate from the restricted causal model, not a verified general shared physical state.
