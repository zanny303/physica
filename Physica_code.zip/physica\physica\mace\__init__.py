"""MACE: Multisensory Active Causal Experience research candidate.

API proposal, physical identification, experiment planning and consumer guidance
are isolated. No live Meta or device control without explicit operator action.
"""
