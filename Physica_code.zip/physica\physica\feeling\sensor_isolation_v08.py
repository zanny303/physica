"""Conservative sensor fault isolation with independent measurement redundancy.

A single disagreement among two complementary sensors cannot identify the faulty
one. At least three sensors and a uniquely qualifying calibrated subset are
required for fault isolation. If evidence is ambiguous: abstain, never actuate.
This is a classical robust estimation extension, not a novel sensor theory.
"""
from __future__ import annotations
from itertools import combinations
import math
import numpy as np
from scipy.stats import chi2
from .reliable_fusion import TrustedFeelingFilter


class IsolatingFeelingFilter(TrustedFeelingFilter):
    def step(self,time_s,force_n,measurements):
        if not isinstance(measurements,dict) or any(k not in self.senses for k in measurements):
            raise ValueError('unrecognized sensor')
        if any(not math.isfinite(float(v)) for v in measurements.values()):
            raise ValueError('non-finite observations')
        if not math.isfinite(time_s) or time_s<=self.time_s:
            raise ValueError('timestamps must increase')
        forecast,P=self._prediction(time_s-self.time_s,force_n)
        self.time_s=float(time_s)
        self.state=forecast
        self.covariance=P
        accepted=[]
        rejected={}
        for key,obs in measurements.items():
            s=self.senses[key]
            if not (s.state_range_m[0]<=forecast[0]<=s.state_range_m[1]
                and s.velocity_range_m_s[0]<=forecast[1]<=s.velocity_range_m_s[1]):
                rejected[key]='outside_calibrated_state_domain'
            else:
                accepted.append(key)
        if not accepted:
            return self._report('NO_TRUSTED_SENSATION',[],list(rejected),rejected)
        def candidate(keys):
            H=np.asarray([self.senses[k].state_gains for k in keys],float)
            y=np.asarray([measurements[k]-self.senses[k].offset for k in keys],float)
            R=np.diag([self.senses[k].noise_std**2 for k in keys])
            residual=y-H@forecast
            S=H@P@H.T+R
            nis=float(residual@np.linalg.solve(S,residual))
            std=np.sqrt(np.diag(S))
            personal_limit=math.sqrt(float(chi2.ppf(1-self.false_alarm_probability/len(keys),1)))
            acceptable=(nis<=float(chi2.ppf(1-self.false_alarm_probability,len(keys))) and
                        np.all(np.abs(residual/std)<=personal_limit))
            return acceptable,H,R,residual,S,nis
        keys=tuple(sorted(accepted))
        whole=candidate(keys)
        if whole[0]:
            chosen=keys
        else:
            # Do not isolate an individual culprit from two contradictory senses.
            if len(keys)<3:
                return self._report('ABSTAIN_AMBIGUOUS_SENSOR_CONFLICT',[],list(keys)+list(rejected),rejected)
            alternatives=[]
            for size in range(len(keys)-1,1,-1):
                for subset in combinations(keys,size):
                    if candidate(subset)[0]:
                        H=np.asarray([self.senses[k].state_gains for k in subset],float)
                        if np.linalg.matrix_rank(H,tol=1e-10)==2:
                            alternatives.append(subset)
                if alternatives: break
            # Multiple maximal subsets imply ambiguous sensor identity.
            if len(alternatives)!=1:
                return self._report('ABSTAIN_AMBIGUOUS_SENSOR_CONFLICT',[],list(keys)+list(rejected),rejected)
            chosen=alternatives[0]
        _,H,R,residual,S,nis=candidate(chosen)
        gain=np.linalg.solve(S,H@P).T
        updated=forecast+gain@residual
        if any(not (s.state_range_m[0]<=updated[0]<=s.state_range_m[1]
                        and s.velocity_range_m_s[0]<=updated[1]<=s.velocity_range_m_s[1])
                   for s in self.senses.values()):
            return self._report('ABSTAIN_CALIBRATION_DOMAIN',[],list(keys)+list(rejected),rejected)
        M=np.eye(2)-gain@H
        covariance=M@P@M.T+gain@R@gain.T
        self.state=updated
        self.covariance=(covariance+covariance.T)/2
        drop=sorted(set(keys)-set(chosen))
        return self._report('ISOLATED_SENSOR_FAULT' if drop else 'CONDITIONAL_MULTISENSORY_UPDATE',
                            list(chosen),drop+list(rejected),rejected,nis)

    def _report(self,status,accepted,rejected,reasons,nis=None):
        return {'status':status,'accepted_sensors':accepted,'rejected_sensors':rejected,
                'rejection_reasons':{k:reasons.get(k,'inconsistent_or_unidentifiable') for k in rejected},
                'state_m_m_s':self.state.tolist(),
                'conditional_state_sigma':np.sqrt(np.diag(self.covariance)).tolist(),
                'normalized_innovation_squared':nis,
                'hardware_actuation_allowed':False,
                'warning':'Model-conditional isolation, not certified to control real hardware'}
