"""Synthetic target-directed experimental design benchmark.

Tests whether a proposed source measurement reduces uncertainty on a *specified*
receiving-machine question. This is known-model Bayesian design, not discovery
of unknown physics. The held-out true parameters are NEVER passed to ranking.
"""
from __future__ import annotations
import numpy as np
from .mechanisms import BASE,design
from .experiments import rank


def _update(mu,C,phi,observed,noise_sd):
    denom=float(phi@C@phi+noise_sd**2)
    K=C@phi/denom
    return mu+K*(observed-phi@mu), C-np.outer(K,phi)@C


def simulate(seed=0,trials=100):
    if not (1<=trials<=10000):raise ValueError('trials must be 1..10000')
    rng=np.random.default_rng(seed)
    # Source parameter uncertainty: stiffness, velocity effect, action gain, offset.
    mu=np.asarray([-.6,-.3,1.,0.],float)
    C=np.diag([.18**2,.18**2,.10**2,.02**2])
    noise=.025
    # Target body asks specifically about displacement-conditioned response.
    targets=[{'x':float(x),'v':0.,'u':0.,'intervention_type':'controlled'}
             for x in np.linspace(.25,.75,9)]
    T=design(targets,BASE)
    candidates=[]
    for i in range(24):
        # x and v probes have comparable possible magnitude; only x-rich probes
        # tend to help the receiving machine's predeclared query.
        x,v=(rng.uniform(.45,.85),rng.uniform(-.03,.03)) if i%2==0 else (rng.uniform(-.03,.03),rng.uniform(.45,.85))
        candidates.append({'x':float(x),'v':float(v),'u':0.,'intervention_type':'controlled',
                           'approved_reversible':True,'risk':0.,'cost':0.})
    m={'terms':BASE,'coefficients':mu.tolist(),'covariance':C.tolist(),'noise_rmse':noise}
    # Two plausible mechanisms with nearly identical mean, same uncertainty;
    # experiment value comes from *targeted covariance update*, not lucky labels.
    alternative={**m,'coefficients':(mu+np.array([.005,.005,0.,0.])).tolist()}
    selected=rank(candidates,[m,alternative],targets)['ranked'][0]['index']
    # Comparison: random eligible probe under exact same one-measurement budget.
    errs_target=[];errs_random=[];pred_target=[];pred_random=[]
    for t in range(trials):
        truth=rng.multivariate_normal(mu,C)
        random_idx=int(rng.integers(0,len(candidates)))
        for idx,errors,postvars in ((selected,errs_target,pred_target),(random_idx,errs_random,pred_random)):
            phi=design([candidates[idx]],BASE)[0]
            observation=float(phi@truth+rng.normal(0,noise))
            post,Cpost=_update(mu,C,phi,observation,noise)
            errors.append(float(np.mean((T@post-T@truth)**2)))
            postvars.append(float(np.mean(np.sum((T@Cpost)*T,axis=1))))
    return {'origin':'SIMULATION_ONLY','seed':seed,'trials':trials,'targeted_probe_index':selected,
            'targeted_mean_squared_target_error':float(np.mean(errs_target)),
            'random_mean_squared_target_error':float(np.mean(errs_random)),
            'targeted_posterior_variance':float(np.mean(pred_target)),
            'random_posterior_variance':float(np.mean(pred_random)),
            'selected_before_ground_truth':True,
            'note':'closed-world linear-Gaussian source prior and target queries; source/target sensors assumed calibrated; no live Meta or physical world evidence'}
