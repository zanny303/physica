"""Transparent SYNTHETIC benchmark with favorable and shifted friction physics.

Includes source-sense ablations, physics-only, transfer, and low-force OOD gate.
No Meta, hardware, V-JEPA, or independent reality evidence is represented here.
"""
import json
from pathlib import Path
import numpy as np
from .core import (Interaction,fit_physical_feeling,predict_senses,transfer_check,
                   prepare_low_force_probe,check_low_force_probe)
from .demo import make_lab,mk_trial


def with_only_sensor(tr,sensor_id):
    return Interaction(tr.intervention_id,tr.body,tr.times_s,tr.applied_force_n,
            tr.initial_state_m_m_s,{sensor_id:tr.observations[sensor_id]},
            {sensor_id:tr.senses[sensor_id]},tr.evidence_sha256,tr.origin,tr.human_authorized)


def run_benchmark(trials=20,seed=2026):
    if not isinstance(trials,int) or not 1<=trials<=200:
        raise ValueError('benchmark trial count must be 1..200')
    rows=[]
    for i in range(trials):
        d=make_lab(seed+i)
        B=d['B_main_trial'];s=B.senses['camera']
        observed=np.asarray(B.observations['camera'],float)
        src_ratio=d['source_estimate']['normalized_friction_ratio']
        pred=predict_senses(B.body,B.times_s,B.applied_force_n,B.initial_state_m_m_s,B.senses,
                           friction_force_n=src_ratio*B.body.force_reference_n)['sensations']['camera']
        physics=predict_senses(B.body,B.times_s,B.applied_force_n,B.initial_state_m_m_s,B.senses,
                           friction_force_n=0.)['sensations']['camera']
        mono={}
        for modality in ('mic','tactile'):
            src=fit_physical_feeling([with_only_sensor(t,modality) for t in d['source_train']],
                         [with_only_sensor(t,modality) for t in d['source_validation']])
            mono[modality]={'status':src['status'],
                            'heldout_error':src.get('heldout_sensor_error_normalized')}
        probe=d['B_probe_trial'];a=d['source_lesson']
        # Same basic mechanics (frequency, boundary), but previously unseen
        # contact coefficient, violating the source-normalized mechanism law.
        shifted=mk_trial(probe.body,probe.senses,'shifted_B_probe',ratio=.48,
                         times=np.asarray(probe.times_s),force=np.asarray(probe.applied_force_n),
                         initial_state=probe.initial_state_m_m_s,seed=seed+i+1030)
        proposed=prepare_low_force_probe(a,B.body,B.senses,probe.times_s,
                    probe.applied_force_n,probe.initial_state_m_m_s)
        shift_check=check_low_force_probe(a,proposed,shifted)
        shifted_gate=transfer_check(a,B.body,B.senses,local_probe=shift_check)
        rows.append({'seed':seed+i,'B_unit':s.unit,
                     'physics_only_rmse':float(np.sqrt(np.mean((observed-physics)**2))),
                     'source_transfer_rmse':float(np.sqrt(np.mean((observed-pred)**2))),
                     'A_audio_only_heldout_error':mono['mic'],
                     'A_touch_only_heldout_error':mono['tactile'],
                     'A_two_senses_heldout_error':d['source_estimate']['heldout_sensor_error_normalized'],
                     'B_normal_gate':d['B_transfer_gate']['status'],
                     'B_shifted_gate':shifted_gate['status'],
                     'B_shifted_gate_reason':shifted_gate['reason'],
                     'A_friction_ratio_estimate':src_ratio,
                     'B_updated_friction_ratio_estimate':d['B_new_experience'].get('normalized_friction_ratio')})
    return {'schema':'physica.feeling.benchmark.v06','origin':'SIMULATION',
           'num_seeds':trials,
           'mean_rmse_sensor_unit':{'physics_only':float(np.mean([x['physics_only_rmse'] for x in rows])),
                   'transferred':float(np.mean([x['source_transfer_rmse'] for x in rows]))},
           'transfer_lower_error_count':sum(x['source_transfer_rmse']<x['physics_only_rmse'] for x in rows),
           'source_like_accepted_count':sum(x['B_normal_gate']=='CONDITIONAL_TRANSFER' for x in rows),
           'hidden_mechanism_shift_refused_count':sum(x['B_shifted_gate']=='REFUSE' for x in rows),
           'sensor_ablation_note':'A-only heldout training of identical synthetic mechanism; no real sensor validation',
           'domain_shift_design':'target friction ratio .48 vs source .135; difference intentionally detectable',
           'limitations':['both source and target generated with one known oscillator model',
                  'source-like targets share same normalized contact-friction mechanism',
                  'target mechanics and observer calibrations known upfront',
                  'low-force target probe consumes a real experimental interaction',
                  'zero-shot with respect to full-force target intervention only',
                  'uncertainty and rejection thresholds are not calibrated on real hardware',
                  'no authenticated Meta ablation, V-JEPA, chemical sensor or physical experiment'],
           'rows':rows}


def save_benchmark(path,trials=20,seed=2026):
    obj=run_benchmark(trials,seed);p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,indent=2)+'\n');return obj
