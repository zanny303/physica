"""E5: Sense Evolution on real PADRE flights.

Borrowed reference (select split): healthy calibration windows vs rotor A and B damage windows.
Prove split (never used for selection): held-out healthy windows vs rotor C and D damage windows.
(A first version selected on rotor A only and over-fitted to it. Now selection uses the WORSE of the two rotors'
scores, so a sense must work on every borrowed unit, not on average.)
Compared with a hand-written baseline sense and a plain spectrogram band-power threshold.

In MOCK mode Spark is replaced by a random program generator, so the output is labelled MOCK and is not
a Sense Evolution result. Run with a real Meta API key for the real experiment.
"""
from __future__ import annotations

import numpy as np

from common import SINGLE, healthy_split, padre_features, save_result
from physica.discover import evolve

HAND = """def sense(psd, f):
    m = (f >= 95) & (f <= 200)
    p = psd[:, :, m]
    return np.log10(p.max(-1) + 1e-30).max(axis=1)
"""
SPEC = """def sense(psd, f):
    m = (f >= 95) & (f <= 200)
    return np.log10(psd[:, :, m].sum(-1) + 1e-30).max(axis=1)
"""


def main():
    split = healthy_split()
    h = padre_features("0000")
    cal, ho = np.array(split["calib"]), np.array(split["heldout"])
    parts = [("select_neg", h["psd"][cal]), ("prove_neg", h["psd"][ho])]
    parts += [(f"select_pos_{r}", padre_features(c)["psd"]) for r in "AB" for c in SINGLE[r]]
    parts += [("prove_pos", padre_features(c)["psd"]) for r in "CD" for c in SINGLE[r]]
    psd = np.concatenate([p for _, p in parts])
    f = h["f"]
    keys = ("select_neg", "select_pos", "select_pos_A", "select_pos_B", "prove_neg", "prove_pos")
    masks, i = {k: np.zeros(len(psd), bool) for k in keys}, 0
    for k, p in parts:
        masks[k][i:i + len(p)] = True
        if k.startswith("select_pos_"):
            masks["select_pos"][i:i + len(p)] = True
        i += len(p)
    masks["select_pos_groups"] = [masks["select_pos_A"], masks["select_pos_B"]]
    res = evolve.run(psd, f, masks)
    for name, code in (("hand_written", HAND), ("spectrogram_band_power", SPEC)):
        r = evolve.evaluate(code, psd, f, masks)
        res[name] = {"code": code, "select_auc": r["select_auc"], **evolve.prove(r["scores"], masks)}
    res["label"] = "MOCK (random program search stand-in, not a result)" if res["mock"] else "real Muse Spark run"
    save_result("E5_sense_evolution" + ("_MOCK" if res["mock"] else ""), res)
    for k in ("generation_1_best", "final_best", "hand_written", "spectrogram_band_power"):
        r = res[k]
        print(f"{k:24s} select AUC {r['select_auc']:.3f}  prove AUC {r['prove_auc']:.3f}  "
              f"detect {r['prove_detect']:.2f}  false alarm {r['prove_false_alarm']:.2f}")
    print(res["label"])


if __name__ == "__main__":
    main()
