"""Physica Causal Sensory Grammar: observable interventions before narratives.

Research prototype. Actions are suggestions, never hardware commands.
Meta/LLM observations are NOT numeric physical measurements. They may change
candidate sets only through an explicitly calibrated, auditable context prior.
References and assumptions: docs/V043_RESEARCH_AND_EVIDENCE.md.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import isfinite, pi, log
import numpy as np
from scipy.linalg import expm
from .signals import MechanicalContext

OBSERVABLES={'vision':'displacement','hearing':'velocity','touch':'acceleration',
             'proprioception':'acceleration'}
UNITS={'displacement':'m','velocity':'m/s','acceleration':'m/s^2'}

@dataclass(frozen=True)
class SafeProbe:
    action_id: str
    force_n: float
    risk: float
    cost: float
    modality: str
    sigma_si: float
    reversible: bool = True
    supervisor_approved: bool = True

    def __post_init__(self):
        if not self.action_id or self.modality not in OBSERVABLES:
            raise ValueError('invalid action or modality; chemistry uses separate dynamics')
        if any(not isfinite(v) for v in (self.force_n,self.risk,self.cost,self.sigma_si)):
            raise ValueError('NaN/Inf in experiment candidate')
        if self.force_n<=0 or self.sigma_si<=0 or not 0<=self.risk<=1 or self.cost<0:
            raise ValueError('positive force/sigma, bounded risk, nonnegative cost required')

def prediction(ctx:MechanicalContext, probe:SafeProbe, times_s):
    """Mechanistic oscillator response to a known applied constant force."""
    t=np.asarray(times_s,dtype=float)
    if t.ndim!=1 or len(t)<8 or not np.all(np.isfinite(t)) or t[0]<0 or np.any(np.diff(t)<=0):
        raise ValueError('finite increasing prospective time grid required')
    w=2*pi*ctx.fundamental_hz
    A=np.array([[0.,1.],[-w*w,-2*ctx.damping_ratio*w]])
    B=np.array([0.,probe.force_n/ctx.mass_kg])
    equilibrium=-np.linalg.solve(A,B)
    traj=np.asarray([(np.eye(2)-expm(A*float(tt)))@equilibrium for tt in t])
    if probe.modality=='vision':return traj[:,0]
    if probe.modality=='hearing':return traj[:,1]
    return -w*w*traj[:,0]-2*ctx.damping_ratio*w*traj[:,1]+probe.force_n/ctx.mass_kg

def _validated(priors,contexts):
    if set(priors)!=set(contexts) or len(contexts)<2:
        raise ValueError('at least two fully specified mechanistic hypotheses')
    if any(not isfinite(v) or v<=0 for v in priors.values()):
        raise ValueError('strict positive finite hypothesis priors')
    base=next(iter(contexts.values()))
    if any(c.body_id!=base.body_id or c.boundary_class!=base.boundary_class or
           c.action_family!=base.action_family for c in contexts.values()):
        raise ValueError('do not compare different bodies/boundaries as same causal experiment')
    z=sum(priors.values());return {k:v/z for k,v in priors.items()}

def probe_options(priors,contexts,probes,times_s,*,max_risk=.15,cost_weight=.1,
                  risk_weight=1.,min_separation=1.,max_force_n=None):
    """Select by experimental discrimination (pairwise predictive divergence).

    This is a transparent mean-separation surrogate for mutual information,
    NOT exact EIG and NOT a safety certificate. Identifiability refusal is first
    class: if all candidate responses overlap, ask for a new sensor/experiment.
    """
    prior=_validated(priors,contexts)
    if not probes:raise ValueError('no prospective probes')
    if len({a.action_id for a in probes})!=len(probes):raise ValueError('duplicate experiments')
    if any(not isfinite(v) for v in (max_risk,cost_weight,risk_weight,min_separation)) or not 0<=max_risk<=1 or min_separation<0 or cost_weight<0 or risk_weight<0:
        raise ValueError('nonfinite or invalid experiment policy')
    if max_force_n is not None and (not isfinite(max_force_n) or max_force_n<=0):
        raise ValueError('invalid independent force limit')
    ranked=[]
    for action in probes:
        r={'action_id':action.action_id,'modality':action.modality,
           'force_n':action.force_n,'risk':action.risk}
        if (not action.reversible or not action.supervisor_approved or action.risk>max_risk or
            (max_force_n is not None and action.force_n>max_force_n)):
            ranked.append({**r,'status':'refused_safety'});continue
        predictions={k:prediction(v,action,times_s) for k,v in contexts.items()}
        names=list(contexts)
        distances=[];divergence=0.
        for i in range(len(names)):
            for j in range(i+1,len(names)):
                # Correlated samples are NOT independent. Use RMS separation
                # per timepoint as a transparent diagnostic, not a likelihood.
                d=float(np.sqrt(np.mean((predictions[names[i]]-predictions[names[j]])**2))/action.sigma_si)
                distances.append(d)
                divergence+=prior[names[i]]*prior[names[j]]*min(d*d,100.)
        minimum=min(distances)
        utility=float(np.log1p(divergence)-risk_weight*action.risk-cost_weight*action.cost)
        ranked.append({**r,'status':'eligible' if minimum>=min_separation else 'unidentifiable',
            'minimum_pairwise_separation_sigma':minimum,'mean_disagreement_score':divergence,
            'utility':utility,'observable':OBSERVABLES[action.modality],
            'unit':UNITS[OBSERVABLES[action.modality]],'model_curves':{k:v.tolist() for k,v in predictions.items()}})
    valid=[r for r in ranked if r['status']=='eligible']
    chosen=max(valid,key=lambda x:(x['utility'],x['action_id'])) if valid else None
    return {'status':'propose_supervised_probe' if chosen else 'stop_unidentifiable_or_unsafe',
      'chosen_action_id':chosen['action_id'] if chosen else None,
      'ranking':sorted(ranked,key=lambda r:r.get('utility',float('-inf')),reverse=True),
      'interpretation':'pairwise signal separation surrogate, not exact causal EIG',
      'hardware_actuation_allowed':False,
      'identified_cause':False,
      'if_stop':'Collect a different independently calibrated sensor or propose safer more discriminative intervention'}

def measured_update(priors,contexts,probe,times_s,measurement,*,max_risk=.15,
                    correlated_sample_factor=1.0):
    """Compare measured post-intervention data with preregistered candidates.

    Thinning/effective-sample correction prevents pretending every correlated
    audio sample is an independent trial. Posterior is conditional on Gaussian
    observation errors and a complete candidate set.
    """
    prior=_validated(priors,contexts)
    if probe.risk>max_risk or not probe.reversible or not probe.supervisor_approved:
        raise ValueError('unsafe/unapproved candidate cannot be accepted')
    if not isfinite(correlated_sample_factor) or not 0<correlated_sample_factor<=1:
        raise ValueError('valid effective sample factor required')
    observed=np.asarray(measurement,dtype=float)
    if observed.ndim!=1 or len(observed)!=len(times_s) or not np.all(np.isfinite(observed)):
        raise ValueError('observed sensor shape/timestamps invalid')
    scores={}
    for name,ctx in contexts.items():
        curve=prediction(ctx,probe,times_s)
        z2=float(np.mean(((observed-curve)/probe.sigma_si)**2))
        scores[name]=log(prior[name])-.5*correlated_sample_factor*z2
    best=max(scores.values());p={k:np.exp(v-best) for k,v in scores.items()};z=sum(p.values())
    return {'posterior_under_model':{k:float(v/z) for k,v in p.items()},
            'highest_scoring':max(p,key=p.get),'conditioned_on':'prospective probe, fixed candidate family, Gaussian errors',
            'not_proof_of_causality':True,'hardware_actuation_allowed':False}

def calibrated_meta_prior(base_prior,context_votes,*,calibration_counts=None,min_heldout=30,
                          maximum_log_multiplier=1.5):
    """Optional measured Meta-value layer: evidence must be held-out labelled data.

    calibration_counts maps hypothesis to {'supported': n, 'incorrect': n},
    measured when the model proposed that hypothesis. This adjusts priors
    ONLY after independent calibration; otherwise exact baseline is returned.
    It is not a general statistical guarantee against selection bias.
    """
    if not base_prior or any(not isfinite(v) or v<=0 for v in base_prior.values()):
        raise ValueError('invalid scientific priors')
    if not isfinite(maximum_log_multiplier) or maximum_log_multiplier<0:
        raise ValueError('invalid context influence limit')
    b={k:float(v/sum(base_prior.values())) for k,v in base_prior.items()}
    votes=[h for h in context_votes if h in b]
    if not calibration_counts:
        return {'prior':b,'status':'no_calibrated_meta_effect','reason':'Meta suggestions are untrusted without independent validation'}
    for h in votes:
        stats=calibration_counts.get(h)
        if not stats or set(stats)!={'supported','incorrect'}:
            return {'prior':b,'status':'no_calibrated_meta_effect','reason':'missing held-out calibration'}
        s,n=stats['supported'],stats['incorrect']
        if not isinstance(s,int) or not isinstance(n,int) or s<0 or n<0 or s+n<min_heldout:
            return {'prior':b,'status':'no_calibrated_meta_effect','reason':'not enough held-out calibration'}
    weights=b.copy()
    for h in set(votes):
        s,n=calibration_counts[h]['supported'],calibration_counts[h]['incorrect']
        # bounded empirical log-odds lift relative to 50/50 reference; deliberately
        # conservative and reported only as a heuristic context weighting.
        logodds=float(np.clip(np.log((s+1)/(n+1)),-maximum_log_multiplier,maximum_log_multiplier))
        weights[h]*=np.exp(logodds)
    z=sum(weights.values())
    return {'prior':{k:float(v/z) for k,v in weights.items()},
        'status':'heldout-calibrated-meta-context-heuristic','heldout_trials_min':min_heldout,
        'not_ground_truth':'Model hints only; empirical calibration is required per application'}
