"""Two-phase REAL-sensor A→B transfer interface: prepare B before collecting B.

This interface never performs an experiment or certifies true physical origin.
Requires a trusted signed and raw-CSV-hash-linked source reveal; refuses to
pretend a simulation episode is real. A witness is still needed to prove time.
Data are tip displacement (m) versus time (s) under a calibrated force step.
"""
from __future__ import annotations
import csv
from dataclasses import replace
from pathlib import Path
import hashlib
import json
import numpy as np
from .transport import BodyCalibration, encode, decode_forecast, local_verify
from .frontier_demo import _episode
from .schema import PhysicalEpisode, Provenance, Quantity
from .seal import seal, reveal, verify_seal, verify_reveal, write_json


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _hash_json(data):
    return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()


def read_csv(path, *, response_required=True):
    with Path(path).open(newline='',encoding='utf8') as f:
        reader=csv.DictReader(f)
        names=('time_s','displacement_m') if response_required else ('time_s',)
        if not reader.fieldnames or not all(k in reader.fieldnames for k in names):
            raise ValueError('CSV needs columns: '+', '.join(names))
        t=[];y=[]
        for row in reader:
            t.append(float(row['time_s']))
            if response_required:y.append(float(row['displacement_m']))
    times=np.asarray(t,dtype=float)
    if len(times)<3 or not np.all(np.isfinite(times)) or times[0]<0 or not np.all(np.diff(times)>0):
        raise ValueError('CSV times must be >=0 finite strictly increasing, length >=3')
    if not response_required:return times
    values=np.asarray(y,dtype=float)
    if not np.all(np.isfinite(values)):raise ValueError('nonfinite displacement values')
    return times,values


def read_calibration(path):
    return BodyCalibration(**json.loads(Path(path).read_text()))


def prepare(source_reveal_json, source_csv, source_cal_json, target_cal_json, target_times_csv, output_dir):
    """Prepare signed B prediction using prior verified A only. NO B observation read."""
    root=Path(output_dir);root.mkdir(parents=True,exist_ok=True)
    r=json.loads(Path(source_reveal_json).read_text())
    if not verify_reveal(r) or r.get('result')!='verified':
        raise ValueError('source evidence must contain verified Ed25519 reveal')
    src=PhysicalEpisode.model_validate(r['episode'])
    if src.provenance.origin!='real_sensor':
        raise ValueError('simulation/manual/derived source is not valid for field protocol')
    digest=file_hash(source_csv)
    if r.get('observation_sha256')!=digest:
        raise ValueError('source reveal not linked to these raw sensor CSV bytes')
    source=read_calibration(source_cal_json)
    target=read_calibration(target_cal_json)
    if (src.machine_id!=source.machine_id or src.boundary_class!=source.boundary_class or
            src.action.action_type!=source.action_class or
            not src.sensors or not all(s.calibrated for s in src.sensors)):
        raise ValueError('signed source episode must match calibrated source machine/action/boundary')
    ta,xa=read_csv(source_csv)
    tb=read_csv(target_times_csv,response_required=False)
    token=encode(source,ta,xa,provenance='real_sensor',source_outcome_verified=True,
                 source_evidence_sha256=digest)
    forecast=decode_forecast(token,target,tb)
    if forecast['status']!='unverified_forecast':
        raise ValueError('source and target incompatible: '+str(forecast['comparison']['reasons']))
    idx=len(tb)//2
    y_at_mid=float(forecast['displacement_m'][idx])
    # Robust sample-level uncertainty requires held-out calibration; this scalar
    # fallback derives 5% of the predicted peak amplitude as an *assumption*.
    sigma=max(1e-8,.05*float(np.max(np.abs(forecast['displacement_m']))))
    ep=_episode(target,y_at_mid,sigma)
    ep.episode_id='field-'+target.machine_id+'-pretest-prediction'
    ep.provenance=Provenance(origin='real_sensor',source_uri=str(source_csv),
        evidence_note='Forecast transferred from signed A real sensor evidence; B NOT measured yet. Sigma heuristic, not calibrated interval.')
    ep.annotations={"full_forecast_sha256":_hash_json(forecast),
                    "source_token_sha256":token['token_sha256'],
                    "index_to_verify":idx,"uncertainty_note":"5% peak heuristic; not calibrated confidence"}
    sealed=seal(ep)
    write_json(root/'source_reveal.json',r)
    write_json(root/'physical_token.json',token)
    write_json(root/'target_forecast.json',forecast)
    write_json(root/'target_commitment.json',sealed)
    write_json(root/'manifest.json',{
        'status':'prepared_before_B_observation','requires_independent_witness':True,
        'source_raw_sha256':digest,'target_time_grid_sha256':file_hash(target_times_csv),
        'target_machine_id':target.machine_id,
        'warning':'No hardware actuation; cannot prove file chronology; field calibration and physics assumptions must be checked.'})
    return {'status':'prepared_before_B_observation','target_commitment_sha256':sealed['sha256'],
            'forecast_points':len(tb),'compatible':True,
            'warning':'Keep prepared directory immutable and externally timestamp it before B measurement'}


def check(prepared_dir, target_observation_csv, output_json):
    """After B measured, compare EXACT committed forecast to the B CSV."""
    root=Path(prepared_dir)
    sealed=json.loads((root/'target_commitment.json').read_text())
    forecast=json.loads((root/'target_forecast.json').read_text())
    token=json.loads((root/'physical_token.json').read_text())
    if not verify_seal(sealed):raise ValueError('target prediction tampered/untrusted')
    ep=PhysicalEpisode.model_validate(sealed['prediction'])
    old=dict(token);old_sig=old.pop('token_sha256',None)
    if hashlib.sha256(json.dumps(old,sort_keys=True).encode()).hexdigest()!=old_sig:
        raise ValueError('source physical token tampered')
    original=json.loads((root/'source_reveal.json').read_text())
    if not verify_reveal(original) or original.get('result')!='verified':
        raise ValueError('source reveal invalid')
    if (old.get('source_evidence_sha256')!=original.get('observation_sha256') or
            original['episode']['provenance']['origin']!='real_sensor'):
        raise ValueError('source token not linked to real signed source evidence')
    if (_hash_json(forecast)!=ep.annotations['full_forecast_sha256'] or
            token['token_sha256']!=ep.annotations['source_token_sha256']):
        raise ValueError('committed full forecast or source token was changed')
    ta,ya=read_csv(target_observation_csv)
    local=local_verify(forecast,ta,ya)
    idx=ep.annotations['index_to_verify']
    record=reveal(sealed,Quantity(value=float(ya[idx]),unit='m'),
                  raw_observation_sha256=file_hash(target_observation_csv))
    result={"evidence":"FIELD_SENSOR_USER_PROVIDED_NOT_INDEPENDENTLY_AUDITED",
            "target_signature_valid":verify_reveal(record),"source_token_origin":token['provenance'],
            "local_verification":local,"point_prediction_verdict":record['result'],
            "target_raw_sha256":file_hash(target_observation_csv),
            "warnings":["Calibrations and observations are user-provided; no third-party verification",
                        "Signatures provide integrity, not chronology",
                        "5% heuristic prediction sigma is not a coverage-calibrated interval",
                        "Passing one test does not validate domain transfer"]}
    out=Path(output_json)
    write_json(out,result)
    write_json(out.with_name(out.stem+'_signed_reveal.json'),record)
    return result
