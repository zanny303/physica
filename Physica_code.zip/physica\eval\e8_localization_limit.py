"""E8: the honest limit. Can passive flight data say WHICH rotor is damaged?

Measures how often 'the arm that feels it most' is the damaged rotor, and checks that Physica's
verdict refuses to name a rotor (since localisation has not passed a held-out test) and instead asks
for the experiment that would settle it.
"""
from __future__ import annotations

import numpy as np

from common import CFG, SINGLE, binom_ci, healthy_split, padre_features, save_result
from physica.feel.feel_transform import FeelTransform
from physica.feel.selfmodel import OperatingPointSelfModel


def main():
    split = healthy_split()
    h = padre_features("0000")
    cal = np.array(split["calib"])
    sm = OperatingPointSelfModel(unit_names=list("ABCD")).fit(h["op"][cal], h["lvl"][cal])
    thr = sm.calibrate_threshold(h["op"][cal], h["lvl"][cal], CFG.q, CFG.margin)
    ft = FeelTransform(list("ABCD"), self_model=sm)
    rows, k_all, n_all, refused = {}, 0, 0, 0
    for r in "ABCD":
        for c in SINGLE[r]:
            d = padre_features(c)
            z = sm.z(d["op"], d["lvl"])
            felt = z.max(axis=1) > thr
            correct = (z.argmax(axis=1) == "ABCD".index(r)) & felt
            v = ft.verdict(z)
            refused += int(v["status"] == "felt" and not v["localized"])
            rows[c] = {"damaged_rotor": r, "felt_windows": int(felt.sum()), "strongest_arm_is_damaged": int(correct.sum()),
                       "verdict_strongest": v.get("strongest_unit"), "verdict_localized": v.get("localized"),
                       "verdict_text": v.get("text")}
            k_all += int(correct.sum()); n_all += int(felt.sum())
    acc = k_all / n_all if n_all else float("nan")
    files_felt = sum(1 for v in rows.values() if v["felt_windows"] > 0)
    out = {"threshold_z": thr, "localization_accuracy_on_felt_windows": acc,
           "localization_ci95_exact": binom_ci(k_all, n_all), "n_felt_windows": n_all,
           "chance_level": 0.25, "files_felt": files_felt, "verdicts_that_refused_to_name_a_rotor": refused,
           "why": "The flight controller changes the other rotors' speeds when one is damaged and PADRE has no motor-RPM "
                  "data, so the strongest-shaking arm is often not the damaged rotor.",
           "experiment_requested": CFG.localize_experiment, "per_file": rows}
    save_result("E8_localization_limit", out)
    print(f"localisation on felt windows: {acc:.3f} CI{np.round(out['localization_ci95_exact'],3)} (chance 0.25), "
          f"n={n_all}; verdicts refusing to name a rotor: {refused}/{files_felt}")


if __name__ == "__main__":
    main()
