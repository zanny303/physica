"""Non-actuating target-specific expected reduction in posterior predictive variance.

Linear-Gaussian approximation conditioned on already fitted candidate models.
Scores proposed *source* measurements by their expected value to a receiving
machine's predeclared target queries, not by a candidate-independent multiplier.
No real actuation or scientific discovery is implied.
"""
from __future__ import annotations
import math
import numpy as np
from .mechanisms import design


def _target_variance_reduction(row, model, target_rows):
    terms=model['terms']
    phi=design([row],terms)[0]
    T=design(target_rows,terms)
    cov=np.asarray(model.get('covariance',[]),float)
    if cov.shape!=(len(terms),len(terms)) or not np.isfinite(cov).all():
        raise ValueError('posterior covariance required for target-aware design')
    cov=(cov+cov.T)/2
    sigma=max(float(model.get('noise_rmse',.02))**2,1e-7)
    denom=float(phi@cov@phi+sigma)
    if not np.isfinite(denom) or denom<=0:raise ValueError('invalid predictive variance')
    cross=T@cov@phi
    return float(np.mean(cross*cross)/denom)


def rank(candidate_rows, models, target_rows, *, max_action=1.0, max_state=2.0, risk_penalty=.1, cost_penalty=.03):
    if len(models)<2 or not candidate_rows or not target_rows:raise ValueError('need competing models, probes and target queries')
    ranking=[]
    for i,r in enumerate(candidate_rows):
        if r.get('approved_reversible') is not True or r.get('intervention_type')!='controlled':continue
        if not np.isfinite([r.get('x',float('nan')),r.get('v',float('nan')),r.get('u',float('nan'))]).all():continue
        if abs(r['u'])>max_action or abs(r['x'])>max_state or abs(r['v'])>max_state:continue
        risk=r.get('risk',0);cost=r.get('cost',0);goal=r.get('expected_goal_progress',0)
        if any(type(x) not in (int,float) or not math.isfinite(x) for x in (risk,cost,goal)) or not (0<=risk<=1 and 0<=cost<=1):continue
        preds=[];gains=[];noise=[]
        for model in models:
            try:
                phi=design([r],model['terms'])[0]
                preds.append(float(phi@np.asarray(model['coefficients'])))
                gains.append(_target_variance_reduction(r,model,target_rows))
                noise.append(max(float(model.get('noise_rmse',.02))**2,1e-7))
            except (ValueError,np.linalg.LinAlgError,TypeError):break
        if len(preds)!=len(models):continue
        disagreement=float(np.var(preds));target_gain=float(np.mean(gains))
        # Approximate information gain from model disagreement with measurement noise.
        model_ig=float(.5*np.log1p(disagreement/max(float(np.mean(noise)),1e-7)))
        utility=target_gain+model_ig+.05*goal-risk_penalty*risk-cost_penalty*cost
        if not np.isfinite(utility):continue
        ranking.append({'index':i,'score':utility,'mechanism_information_proxy':model_ig,
                        'expected_target_variance_reduction':target_gain,'target_value_proxy':target_gain,
                        'hypothesis_disagreement':disagreement,'risk':risk,'cost':cost})
    ranking.sort(key=lambda it:(-it['score'],it['index']))
    return {'status':'REVIEW_ONLY_NOT_ACTUATED' if ranking else 'ABSTAIN_NO_SAFE_INFORMATIVE_PROBE',
            'ranked':ranking,'uses_future_outcomes':False,
            'target_query_count':len(target_rows),
            'method':'linear Gaussian posterior covariance update per candidate; no target truth used',
            'note':'requires calibrated parametric noise; approximate model information term, not validated general causal knowledge'}
