"""Turn the public FEMTO/PRONOSTIA bearing recordings into per-snapshot features.

Data: IEEE PHM 2012 Prognostic Challenge, real bearings run to failure on the PRONOSTIA rig (Nectoux et al. 2012).
Copy used: github.com/wkzs111/phm-ieee-2012-data-challenge-dataset. Set PHYSICA_FEMTO to its folder.
Each snapshot is 0.1 s of horizontal vibration at 25.6 kHz. Keeps only derived numbers, not the raw recordings.
"""
from __future__ import annotations

import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np

EDGES = [0, 200, 500, 1000, 2000, 3000, 4000, 6000, 8000, 12800]


def snapshot(path: Path) -> list[float]:
    txt = path.read_text()
    sep = ";" if ";" in txt[:200] else ","
    a = np.fromstring(txt.replace("\n", sep), sep=sep).reshape(-1, 6)
    h = a[:, 4] - a[:, 4].mean()
    t = a[0, 0] * 3600 + a[0, 1] * 60 + a[0, 2] + a[0, 3] * 1e-6
    p = np.abs(np.fft.rfft(h * np.hanning(len(h)))) ** 2
    f = np.fft.rfftfreq(len(h), 1 / 25600)
    bands = [p[(f >= lo) & (f < hi)].sum() for lo, hi in zip(EDGES[:-1], EDGES[1:])]
    rms = float(np.sqrt(np.mean(h ** 2)))
    return [t, rms, float(np.abs(h).max()), float(np.mean(h ** 4) / max(rms ** 4, 1e-12)), *np.log10(np.maximum(bands, 1e-12))]


def bearing(folder: Path) -> tuple[str, np.ndarray]:
    files = sorted(folder.glob("acc_*.csv"))
    rows = np.array([snapshot(p) for p in files])
    rows[:, 0] = np.cumsum(np.r_[0, np.mod(np.diff(rows[:, 0]), 86400)])
    return folder.name, rows


def main(out="eval/results/E32_femto_features.npz"):
    root = Path(os.environ["PHYSICA_FEMTO"])
    folders = sorted(p for s in ("Learning_set", "Full_Test_Set") for p in (root / s).glob("Bearing*"))
    with ProcessPoolExecutor(2) as ex:
        got = dict(ex.map(bearing, folders))
    np.savez_compressed(out, **got)
    for k, v in got.items():
        print(k, len(v), f"{v[-1, 0] / 3600:.2f} h", f"peak {v[-1, 2]:.1f} g")


if __name__ == "__main__":
    main()
