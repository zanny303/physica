"""Validated memory + robust Bayesian transfer with target-directed experiment design.

Design contract:
 - source devices are distinct from targets; no true target coefficients are read;
 - all calibration maps are explicit, with finite nonzero gains and independent
   provenance metadata; unmeasured quantities are not invented;
 - posterior is a two-component Gaussian mixture with evidence-driven weights;
 - source knowledge is soft and can be rejected in favor of broad local prior;
 - probe values are never available to rank_probes; only their planned actions;
 - this is a linear-in-parameters mechanism grammar, NOT open-world discovery.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from hashlib import sha256
import json
import math
from typing import Iterable
import numpy as np

FEATURES = ('x', 'v', 'u', 'offset', 'sin_2x_plus_v')
SCHEMA = 'physica.pel.probabilistic_experience.v014'
EPS = 1e-10


def _finite(a, name='array'):
    v = np.asarray(a, dtype=float)
    if not np.all(np.isfinite(v)):
        raise ValueError(f'{name} contains NaN or infinity')
    return v


def phi(row):
    x, v, u = (float(row[k]) for k in ('x','v','u'))
    if not np.all(np.isfinite([x,v,u])):
        raise ValueError('nonfinite physical state/action')
    return np.array([x, v, u, 1., math.sin(2*x+v)], dtype=float)


@dataclass(frozen=True)
class SensorCalibration:
    modality: str
    gain: float
    bias: float
    noise_sd: float
    calibration_id: str
    provenance: str
    observed_quantity: str = 'acceleration_proxy'

    def __post_init__(self):
        if (self.modality not in ('inertial','acoustic','motor_current','visual_kinematics')
            or self.observed_quantity != 'acceleration_proxy'):
            raise ValueError('only explicitly calibrated acceleration-proxy maps supported')
        if not all(math.isfinite(float(x)) for x in (self.gain,self.bias,self.noise_sd)):
            raise ValueError('calibration must be finite')
        if abs(self.gain)<1e-8 or self.noise_sd<=0:
            raise ValueError('gain must be nonzero and noise positive')
        if not self.calibration_id.strip() or self.provenance not in ('EXTERNALLY_VERIFIED','SIMULATED'):
            raise ValueError('calibration identity and provenance required')


def calibrated_rows(rows, calibration: SensorCalibration, *, real_claim=False):
    """Invert known sensor observation map y=gain*physical acceleration+bias.

    No automatic calibration, no claim that audio/current alone measures force.
    In a real run, a trusted external calibration must be supplied and audited.
    """
    if real_claim and calibration.provenance!='EXTERNALLY_VERIFIED':
        raise ValueError('simulated or unverified calibration cannot support real claims')
    out=[]
    for row in rows:
        if 'acceleration' in row:
            raise ValueError('use raw sensor observation, not ground-truth acceleration')
        y=float(row['observation']);_finite([y])
        if row.get('modality')!=calibration.modality:
            raise ValueError('sensor modality/calibration mismatch')
        val=(y-calibration.bias)/calibration.gain
        d={k:row[k] for k in ('x','v','u','body_id','episode_id','modality')}
        d.update({'acceleration':float(val),'noise_sd':float(calibration.noise_sd/abs(calibration.gain)),
                  'calibration_id':calibration.calibration_id})
        phi(d)
        out.append(d)
    return out


def _matrix(rows):
    if not rows:raise ValueError('at least one observation required')
    X=np.stack([phi(r) for r in rows]); y=_finite([r['acceleration'] for r in rows],'acceleration')
    noise=_finite([r['noise_sd'] for r in rows],'noise')
    if np.any(noise<=0):raise ValueError('positive known measurement noise required')
    return X,y,noise


def _sympd(C):
    C=_finite(C,'covariance')
    if C.shape!=(len(FEATURES),len(FEATURES)):
        raise ValueError('invalid covariance shape')
    C=(C+C.T)/2
    if np.linalg.eigvalsh(C)[0]<=0:raise ValueError('covariance must be positive definite')
    return C


@dataclass(frozen=True)
class ExperienceMemory:
    source_device_ids: tuple[str,...]
    mean: tuple[float,...]
    covariance: tuple[tuple[float,...],...]
    mechanism: tuple[str,...]
    observation_models: tuple[dict,...]
    noise_assumptions: dict
    validity: dict
    provenance: str
    failure_conditions: tuple[str,...]
    evidence_hash: str
    schema: str=SCHEMA

    def __post_init__(self):
        if self.schema!=SCHEMA or tuple(self.mechanism)!=FEATURES:
            raise ValueError('incompatible experience grammar')
        if len(set(self.source_device_ids))<2 or len(set(self.source_device_ids))!=len(self.source_device_ids):
            raise ValueError('need >=2 distinct source machines')
        if _finite(self.mean).shape!=(len(FEATURES),):raise ValueError('prior shape mismatch')
        _sympd(self.covariance)
        if self.provenance not in ('SIMULATION_ONLY','INDEPENDENT_EVIDENCE'):
            raise ValueError('unrecognized evidence provenance')
        if not isinstance(self.validity,dict) or not self.evidence_hash:
            raise ValueError('validity and evidence hash required')

    def to_dict(self):return asdict(self)

    @classmethod
    def from_dict(cls,d):
        x=dict(d)
        for field in ('source_device_ids','mean','mechanism','failure_conditions'):
            x[field]=tuple(x[field])
        x['covariance']=tuple(tuple(row) for row in x['covariance'])
        x['observation_models']=tuple(x['observation_models'])
        return cls(**x)


def fit_source_memory(devices: dict, calibration: dict, *, shrink=.2, floor=.045):
    """Empirical Bayesian between-device prior (not target evidence).

    Each source machine contributes one regularized coefficient estimate, not
    one vote per sensor sample. Uncertainty includes inter-machine variation,
    regularization and a nonzero floor to prevent confident negative transfer.
    """
    if len(devices)<3:raise ValueError('at least three independent source machines required')
    if not 0<=shrink<=1 or floor<=0:raise ValueError('invalid prior shrinkage/floor')
    means=[];variances=[];processed=[];maps=[]
    origins=[]; all_raw=[]; observed_ranges=[]
    for device,raw in sorted(devices.items()):
        if device not in calibration:raise ValueError('missing sensor calibration')
        cal=calibration[device]
        rows=calibrated_rows(raw,cal)
        all_raw.extend({"device":device,"x":float(r["x"]),"v":float(r["v"]),"u":float(r["u"]),"observation":float(r["observation"]),"episode_id":r["episode_id"]} for r in raw)
        observed_ranges.extend((float(r["x"]),float(r["v"]),float(r["u"])) for r in rows)
        if not rows or any(r['body_id']!=device for r in rows):
            raise ValueError('device id mismatch or no evidence')
        X,y,n=_matrix(rows)
        # Weakly regularized per-machine fits in units of physical acceleration.
        P=np.eye(len(FEATURES))*.04
        precision=X.T@((1/n**2)[:,None]*X)+P
        cov=np.linalg.inv(precision)
        mean=cov@(X.T@(y/n**2))
        means.append(mean);variances.append(np.diag(cov));processed.append((device,len(rows)))
        maps.append(asdict(cal));origins.append(cal.provenance)
    M=np.stack(means);mu=M.mean(axis=0)
    between=np.cov(M,rowvar=False,ddof=1)
    between=(1-shrink)*between+shrink*np.diag(np.diag(between))
    C=between+np.diag(np.mean(variances,axis=0)+floor**2)
    C=(C+C.T)/2+np.eye(len(FEATURES))*1e-8
    material=json.dumps({'devices':processed,'calibration':maps,'source_means':M.tolist(),
                          'raw_source_observations':all_raw},sort_keys=True,allow_nan=False).encode()
    bounds=np.asarray(observed_ranges,float)
    ranges={k:{'min':float(bounds[:,i].min()),'max':float(bounds[:,i].max())}
            for i,k in enumerate(('x','v','u'))}
    origin='SIMULATION_ONLY' if all(o=='SIMULATED' for o in origins) else 'INDEPENDENT_EVIDENCE'
    if not (all(o=='SIMULATED' for o in origins) or all(o=='EXTERNALLY_VERIFIED' for o in origins)):
        raise ValueError('cannot mix simulated and real sources in one memory')
    return ExperienceMemory(tuple(sorted(devices)),tuple(mu.tolist()),tuple(tuple(v) for v in C.tolist()),
        FEATURES,tuple(maps),{'source_machine_count':len(devices),'floor_sd':floor},
        {'physical_units':'SI-normalized acceleration','calibration_compatibility':'individually verified required',
         'supported_operating_range':ranges},origin,
        ('calibration mismatch','new physical mechanism','unseen embodiment','different sensor response'),
        sha256(material).hexdigest())


def _component_update(prior_mu,prior_C,X,y,noise):
    """Exact Gaussian conjugate regression + sequential marginal log-evidence."""
    mu=_finite(prior_mu);C=_sympd(prior_C)
    loge=0.
    for xx,yy,ss in zip(X,y,noise):
        innovation=float(yy-xx@mu)
        variance=float(xx@C@xx+ss*ss)
        if variance<=0 or not math.isfinite(variance):raise ValueError('invalid predictive variance')
        k=C@xx/variance
        mu=mu+k*innovation
        C=C-np.outer(k,xx@C)
        C=(C+C.T)/2
        # Numerical stabilization on tiny eigenvalues, not data-derived confidence.
        eig=np.linalg.eigvalsh(C)[0]
        if eig<1e-12:C+=np.eye(len(FEATURES))*(1e-12-eig)
        loge+=-.5*(math.log(2*math.pi*variance)+innovation**2/variance)
    return {'mean':mu,'covariance':C,'log_evidence':loge}


def _logsumexp(a):
    m=max(a);return m+math.log(sum(math.exp(v-m) for v in a))


def fit_target(rows, memory: ExperienceMemory|None, *, mode='mixture', broad_sd=1.2,
               initial_source_weight=.65, target_id=None):
    """Fit B from its own probes; source may supply a fallible mixture component.

    Prior mixture weights are fixed before B measurements, then updated only from
    their likelihood. No test observations are ever accepted by this function.
    """
    if mode not in ('mixture','local','hierarchical'):
        raise ValueError('unknown mode')
    if not (0<initial_source_weight<1) or broad_sd<=0:
        raise ValueError('invalid prior settings')
    if memory and target_id is not None and target_id in memory.source_device_ids:
        raise ValueError('target was part of source training (leakage)')
    if rows:
        X,y,noise=_matrix(rows)
        if target_id and any(r['body_id']!=target_id for r in rows):
            raise ValueError('foreign target samples present')
    else:
        X=np.zeros((0,len(FEATURES)));y=np.zeros(0);noise=np.zeros(0)
    broad_mu=np.zeros(len(FEATURES));broad_mu[2]=.7
    broad_C=np.eye(len(FEATURES))*broad_sd**2
    local=_component_update(broad_mu,broad_C,X,y,noise)
    if memory is not None and mode != 'local' and rows:
        ranges=memory.validity.get('supported_operating_range',{})
        # Detect extrapolation outside the source's sampled operating envelope.
        # The model can still learn locally, but must not trust source transfer.
        incompatible=any(any(float(r[k]) < ranges[k]['min']-.15 or
                             float(r[k]) > ranges[k]['max']+.15
                             for k in ('x','v','u') if k in ranges) for r in rows)
        if incompatible:
            mode='local'
    if mode=='local' or memory is None:
        posterior=[{**local,'weight':1.,'origin':'TARGET_ONLY'}]
    else:
        src=_component_update(_finite(memory.mean),_sympd(memory.covariance),X,y,noise)
        if mode=='hierarchical':
            posterior=[{**src,'weight':1.,'origin':'SOURCE_HIERARCHICAL'}]
        else:
            lws=[math.log(initial_source_weight)+src['log_evidence'],
                 math.log1p(-initial_source_weight)+local['log_evidence']]
            norm=_logsumexp(lws)
            w=math.exp(lws[0]-norm)
            posterior=[{**src,'weight':w,'origin':'SOURCE_COMPONENT'},
                       {**local,'weight':1-w,'origin':'BROAD_FALLBACK'}]
    rng_src=(memory.validity.get('supported_operating_range',{}) if memory is not None else {})
    seen=({k:{'min':float(min(float(r[k]) for r in rows)),'max':float(max(float(r[k]) for r in rows))} for k in ('x','v','u')}
          if rows else {})
    envelope={k:{'min':min([d[k]['min'] for d in (rng_src,seen) if k in d]),'max':max([d[k]['max'] for d in (rng_src,seen) if k in d])}
              for k in ('x','v','u') if k in rng_src or k in seen}
    return {'mode':mode,'target_id':target_id,'n':len(rows),'features':FEATURES,'supported_range':envelope,
            'source_refused_due_to_operating_range':bool(memory is not None and rows and
                  any(any(float(r[k]) < memory.validity['supported_operating_range'][k]['min']-.15 or
                          float(r[k]) > memory.validity['supported_operating_range'][k]['max']+.15
                          for k in ('x','v','u')) for r in rows)),
            'components':posterior,'source_memory_hash':memory.evidence_hash if memory else None,
            'future_outcomes_accessed':False}


def posterior_summary(posterior):
    d={k:v for k,v in posterior.items() if k!='components'}
    d['components']=[{'origin':c['origin'],'weight':float(c['weight']),
                      'mean':c['mean'].tolist(),'covariance':c['covariance'].tolist(),
                      'log_evidence':float(c['log_evidence'])} for c in posterior['components']]
    return d


def out_of_range(posterior,queries,margin=.15):
    """Queries outside everything this posterior was learned from (source envelope and target probes)."""
    env=posterior.get('supported_range') or {}
    return np.array([any(float(q[k])<env[k]['min']-margin or float(q[k])>env[k]['max']+margin for k in env)
                     for q in queries],dtype=bool)


def predict(posterior,queries,refuse_out_of_range=True):
    """Mean and variance per query. Queries outside the supported operating range are REFUSED (NaN) unless
    refuse_out_of_range=False: a linear mechanism grammar must not extrapolate silently."""
    X=np.stack([phi(r) for r in queries]) if queries else np.zeros((0,len(FEATURES)))
    mus=np.stack([X@c['mean'] for c in posterior['components']])
    ws=np.array([c['weight'] for c in posterior['components']])
    mean=ws@mus
    variance=np.zeros(len(X))
    for j,c in enumerate(posterior['components']):
        variance+=ws[j]*(np.einsum('ij,jk,ik->i',X,c['covariance'],X)+(mus[j]-mean)**2)
    variance=np.maximum(variance,0)
    oor=out_of_range(posterior,queries) if queries else np.zeros(0,bool)
    if refuse_out_of_range and oor.any():
        mean=np.where(oor,np.nan,mean);variance=np.where(oor,np.nan,variance)
    return {'mean':mean,'variance':variance,'refused_out_of_range':oor}


def rank_probes(posterior, candidates, target_queries, *, risk_penalty=.1,cost_penalty=.05,
                max_action=1.0,max_state=1.5):
    """Select target-side probe maximizing expected target predictive variance reduction.

    Gauss-mixture *component* covariance reduction is exact under linear-Gaussian
    assumptions. The between-component term is only approximated; not an exact
    expected information gain for the full mixture. No outcomes may be supplied.
    """
    if not target_queries:raise ValueError('predeclared target queries required')
    T=np.stack([phi(t) for t in target_queries]);ranked=[]
    for i,c in enumerate(candidates):
        if c.get('approved_reversible') is not True or c.get('intervention_type')!='controlled':continue
        if 'observation' in c or 'acceleration' in c:
            raise ValueError('candidate outcomes must not be supplied to the experiment planner')
        x,v,u=[float(c.get(k,float('nan'))) for k in ('x','v','u')]
        if not np.isfinite([x,v,u]).all() or abs(u)>max_action or abs(x)>max_state or abs(v)>max_state:continue
        risk=float(c.get('risk',0));cost=float(c.get('cost',0))
        if not np.isfinite([risk,cost]).all() or min(risk,cost)<0 or max(risk,cost)>1:continue
        measurement_noise=float(c.get('expected_noise_sd',.04))
        if not 0<measurement_noise<10:continue
        p=phi(c)
        benefit=0.
        for component in posterior['components']:
            C=component['covariance']
            cross=T@C@p
            reduction=float(np.mean(cross**2)/(p@C@p+measurement_noise**2))
            benefit+=component['weight']*reduction
        utility=benefit-risk_penalty*risk-cost_penalty*cost
        ranked.append({'index':i,'expected_target_variance_reduction':benefit,
                       'score':utility,'risk':risk,'cost':cost})
    ranked.sort(key=lambda x:(-x['score'],x['index']))
    return {'status':'HUMAN_APPROVAL_REQUIRED' if ranked else 'NO_SAFE_PROBE',
            'ranked':ranked,'target_query_count':len(target_queries),
            'outcomes_accessed':False,'approximates_mixture_information_gain':True}


def fuse_calibrated_modalities(readings, calibrations, *, conflict_sigma=4.):
    """Noise-aware physical proxy from independently calibrated simultaneous senses.

    Estimates ONE measured latent acceleration component. It does not infer
    arbitrary hidden forces or create missing senses. Refuses strongly
    inconsistent sensors rather than silently averaging conflicting signals.
    """
    if not readings:raise ValueError('no observed senses supplied')
    values=[];variances=[];used=[]
    for modality,reading in readings.items():
        if modality not in calibrations:raise ValueError('unknown sensor calibration')
        c=calibrations[modality]
        if c.modality!=modality:raise ValueError('calibration modality mismatch')
        observed=float(reading)
        _finite([observed])
        values.append((observed-c.bias)/c.gain)
        variances.append((c.noise_sd/abs(c.gain))**2)
        used.append(modality)
    values=np.array(values);variances=np.array(variances)
    if len(values)>1:
        for i in range(len(values)):
            for j in range(i+1,len(values)):
                z=abs(values[i]-values[j])/np.sqrt(variances[i]+variances[j])
                if z>conflict_sigma:
                    return {'status':'REFUSE_SENSOR_CONFLICT','modalities':used,
                            'max_pairwise_disagreement_sigma':float(z),
                            'estimated_quantity':None,'measured':True}
    w=1/variances
    return {'status':'CALIBRATED_ESTIMATE','modalities':used,
            'estimated_quantity':'acceleration','estimate':float(np.dot(w,values)/w.sum()),
            'sd':float(np.sqrt(1/w.sum())),'measured':False,
            'note':'Fusion estimate from actual measurements, not a new direct sensor'}


def fit_sensor_observation_map(train_pairs,validation_pairs, *, modality,
                               calibration_id, provenance='SIMULATED'):
    """Learn a 1D sensor observation mapping from paired *reference* measurements.

    Requires independent, synchronized SI acceleration reference for each
    training/validation example. Validated only on episodes not used for fit.
    This does NOT learn a body-agnostic latent state, and does not certify the
    truth of external reference measurements or calibration.
    """
    if not train_pairs or not validation_pairs:raise ValueError('paired calibration data required')
    ids_train={r['episode_id'] for r in train_pairs}
    ids_val={r['episode_id'] for r in validation_pairs}
    if ids_train & ids_val:raise ValueError('calibration train/validation episode leakage')
    if len(ids_train)<2 or len(ids_val)<2:
        raise ValueError('independent calibration episodes required')
    def as_xy(rows):
        if any(r.get('modality')!=modality for r in rows):
            raise ValueError('calibration modality mismatch')
        x=_finite([r['reference_acceleration_si'] for r in rows],'reference acceleration')
        y=_finite([r['observation'] for r in rows],'sensor observation')
        return x,y
    x,y=as_xy(train_pairs);xx,yy=as_xy(validation_pairs)
    if len(x)<12 or len(xx)<8 or float(np.std(x))<.04:
        raise ValueError('insufficient independent calibration excitation')
    X=np.column_stack((x,np.ones(len(x))))
    gain,bias=np.linalg.lstsq(X,y,rcond=None)[0]
    if abs(gain)<1e-8:raise ValueError('uninformative sensor map')
    pred=gain*xx+bias
    rmse=float(np.sqrt(np.mean((yy-pred)**2)))
    baseline=float(np.sqrt(np.mean((yy-np.mean(y))**2)))
    if not np.isfinite(rmse) or rmse>=.9*baseline:
        raise ValueError('sensor map failed independent validation')
    cal=SensorCalibration(modality,float(gain),float(bias),max(rmse,1e-6),
                          calibration_id,provenance)
    return {'status':'HELDOUT_LINEAR_SENSOR_MAP_VALIDATED_NOT_PHYSICALLY_ATTESTED',
            'calibration':cal,
            'train_episode_count':len(ids_train),
            'heldout_validation_episode_count':len(ids_val),
            'validation_sensor_rmse':rmse,
            'validation_constant_baseline_rmse':baseline,
            'raw_reference_acceleration_required':True,
            'measured_real_world_calibration_proof':False}
