# META LIVE + REAL WORLD FIELD CHECKLIST

> **Do not include your API key in a ZIP, GitHub issue, screen recording or screenshot.**

## Zero-key

```bash
pip install -e '.[dev]'
python -m physica.cli experience crate-demo --out demo
python -m physica.cli experience meta-preflight
```

Check `demo/physica_v04_experience_lab.html`. All curves are **simulated**.

## Private-key workstation only

1. Obtain a key at Meta Model API dashboard. Set `MODEL_API_KEY` privately. Do **not** send it to ChatGPT.
2. `pip install -e '.[meta]'` (official OpenAI-compatible SDK used; Meta Model API URL and model IDs configured by source code).
3. `python -m physica.cli experience meta-scientist examples/live_facts_example.json --allowed passive_listen calibrated_step --out hypothesis.json`. Verify `mode=LIVE_UNVERIFIED_EXPERIMENTALLY` and actual model ID in the audit.
4. Record one MP4 of a passive controlled strip and a **separate synchronized calibrated sensor CSV** with headers `time_s,displacement_m`.
5. `python -m physica.cli experience sam-video clip.mp4 --concept 'metal ruler' --out sam.json`. Confirm that the bounding boxes track the intended physical component and that the camera is fixed.
6. Only after measuring real `metres_per_pixel` (calibration card in same plane) and FPS, use `meta-fusion-live`; it consumes billed hosted calls and requires `--allow-billed-meta`. Examine the sensor-versus-optical disagreement and don't proceed on a failed cross-check. Keep all raw media/JSON/hash files and record API cost.
7. V-JEPA 2: run the **official open-weight** encoder separately with its checkpoints and hardware, export numeric embeddings and independent measured target values, and validate with body-disjoint train/calibration/test splits. `visual-fit`/`visual-forecast` can then create a physically comparable dual-world prediction; it cannot magically calibrate latent states without observed physical targets.
8. Perform a **human-approved, small, reversible** experiment. Before B's observation use the original `frontier-prepare` command and externally witness its timestamp (for example by a trusted third party). Then measure B and run `frontier-check` on its raw CSV. This is currently a manual human-supervised process.

## Live science checks

- Spark context isn't measurement, SAM pixels aren't metres, V-JEPA embeddings aren't force, Muse explanations aren't safety approval.
- Reject missing calibration, source-body mismatch, boundary mismatch, high risk, destructive experiments, extrapolation, abnormal camera movement and incorrect timestamps.
- Record failed experiments, not just successful ones.
- Independently witness commitment before testing. Ed25519 signature proves content integrity, **not the time at which a prediction was made**.
- Repeat across bodies; report real sample-efficiency, all baselines, the number of physical interventions and uncertainty interval coverage.
