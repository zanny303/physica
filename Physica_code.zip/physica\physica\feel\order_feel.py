"""Order Feel: a sense written in the machine's own rhythm, so it can move between machines.

Plain-frequency senses don't transfer: on the Parrot Bebop 2 a damaged propeller shows up at 1.0x the main
vibration line, on the 3DR Solo at 0.5x (different motors, propellers and blade counts). Written in units of the
machine's OWN main line ("orders"), the same procedure can be carried to a new machine; only the numbers
(what healthy looks like at each order) are relearned there, from healthy data alone.

Steps per 5 s window:
  1. find the machine's main line (searched near the line learned from its healthy data, so damage can't hijack it)
  2. re-time the spectrum into orders of that line (dimensionless)
  3. cancel what the machine causes itself: z-score against its own healthy spectrum at every order
  4. feel = the strongest smoothed leftover across orders and arms
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


def _smooth(z: np.ndarray, k: int) -> np.ndarray:
    if k <= 1:
        return z
    ker = np.ones(k) / k
    return np.apply_along_axis(lambda v: np.convolve(v, ker, mode="same"), -1, z)


@dataclass
class OrderFeel:
    orders: tuple[float, float] = (0.25, 1.25)  # which part of the machine's rhythm the sense watches
    step: float = 0.01
    search_rel: float = 0.25  # main line is searched within +-25% of its healthy value
    smooth_bins: int = 5
    std_floor: float = 0.05
    q: float = 0.99
    margin: float = 0.5
    speed_aware: bool = False  # optional: condition each order's level on speed (hurt in E9 on both drones)
    ridge: float = 1.0
    min_hz: float = 20.0  # lowest main line considered (fans and washing machines can be slower)
    # learned on the machine (numbers, relearned on arrival)
    ref_hz: float | None = None
    grid: np.ndarray | None = None
    mu: np.ndarray | None = None
    sd: np.ndarray | None = None
    coef: np.ndarray | None = None
    s_center: float = 0.0
    s_scale: float = 1.0
    threshold: float | None = None
    fd_range: list | None = None
    meta: dict = field(default_factory=dict)

    # ---- the procedure (this is what transfers) ----
    def main_line(self, psd: np.ndarray, f: np.ndarray) -> np.ndarray:
        lo, hi = self.ref_hz * (1 - self.search_rel), self.ref_hz * (1 + self.search_rel)
        m = (f >= lo) & (f <= hi)
        idx = psd[..., m].argmax(-1)  # (win, units)
        return np.median(f[m][idx], axis=1)  # (win,)

    def to_orders(self, psd: np.ndarray, f: np.ndarray, fd: np.ndarray) -> np.ndarray:
        lp = np.log10(psd + 1e-30)
        out = np.empty(psd.shape[:2] + (len(self.grid),))
        for w in range(psd.shape[0]):
            fq = self.grid * fd[w]
            for u in range(psd.shape[1]):
                out[w, u] = np.interp(fq, f, lp[w, u], left=np.nan, right=np.nan)
        return out

    def leftover(self, psd: np.ndarray, f: np.ndarray) -> np.ndarray:
        """z per window, unit and order: what the machine feels that it didn't cause itself."""
        fd = self.main_line(psd, f)
        X = self.to_orders(psd, f, fd)
        z = (X - self._expected(fd)) / self.sd
        return _smooth(np.nan_to_num(z, nan=0.0), self.smooth_bins)

    def _design(self, fd: np.ndarray) -> np.ndarray:
        s = (fd - self.s_center) / self.s_scale
        return np.stack([np.ones_like(s), s, s ** 2], axis=1)  # (win, 3)

    def _expected(self, fd: np.ndarray) -> np.ndarray:
        if not self.speed_aware or self.coef is None:
            return self.mu
        return np.einsum("wk,kuo->wuo", self._design(fd), self.coef)

    def score(self, psd: np.ndarray, f: np.ndarray) -> np.ndarray:
        return self.leftover(psd, f).max(axis=(1, 2))

    # ---- learning the numbers on a machine (healthy data only) ----
    def fit(self, psd: np.ndarray, f: np.ndarray, fs: float) -> "OrderFeel":
        m = (f > self.min_hz) & (f < 0.98 * fs / 2)
        med = np.median(psd[..., m], axis=(0, 1))
        self.ref_hz = float(f[m][np.argmax(med)])
        fd = self.main_line(psd, f)
        top = min(self.orders[1], 0.98 * (fs / 2) / (fd.max() * 1.05))
        self.grid = np.arange(self.orders[0], top + 1e-9, self.step)
        X = self.to_orders(psd, f, fd)
        self.mu = np.nanmean(X, axis=0)
        if self.speed_aware:  # per arm and order: log level = a + b*s + c*s^2 (ridge), s = normalised speed
            self.s_center, self.s_scale = float(np.mean(fd)), float(max(np.std(fd), 1e-6))
            D = self._design(fd)
            Xf = np.nan_to_num(X - self.mu, nan=0.0).reshape(len(fd), -1)
            A = D.T @ D + self.ridge * np.diag([0.0, 1.0, 1.0])
            C = np.linalg.solve(A, D.T @ Xf)  # (3, units*orders)
            C[0] += self.mu.reshape(-1)
            self.coef = C.reshape((3,) + self.mu.shape)
            resid = X - self._expected(fd)
            self.sd = np.maximum(np.nanstd(resid, axis=0) * np.sqrt(len(fd) / max(len(fd) - 3, 1)), self.std_floor)
        else:
            self.sd = np.maximum(np.nanstd(X, axis=0), self.std_floor)
        s = self.score(psd, f)
        self.threshold = float(np.quantile(s, self.q) + self.margin)
        self.fd_range = [float(fd.min()), float(fd.max())]
        self.meta = {"ref_hz": self.ref_hz, "main_line_range_hz": self.fd_range, "order_range": [float(self.grid[0]), float(self.grid[-1])],
                     "n_healthy_windows": int(psd.shape[0])}
        return self

    def felt(self, psd: np.ndarray, f: np.ndarray) -> np.ndarray:
        return self.score(psd, f) > self.threshold

    def arrival(self, psd: np.ndarray, f: np.ndarray) -> dict:
        """Two-sided arrival check: do this machine's healthy windows sit inside what the card expects?
        (A quieter machine is as much a misfit as a louder one.)"""
        m = (f > self.min_hz) & (f < f.max() * 0.98)
        line = float(f[m][np.argmax(np.median(psd[..., m], axis=(0, 1)))])
        lo, hi = 0.9 * self.fd_range[0], 1.1 * self.fd_range[1]
        if not lo <= line <= hi:  # same proven-range rule as everywhere else in Physica
            return {"inside": "0/%d" % psd.shape[0], "verdict": "doesn't fit here",
                    "why": f"this machine's main line is {line:.0f} Hz, outside the card's proven {lo:.0f}-{hi:.0f} Hz"}
        L = np.abs(self.leftover(psd, f)).max(axis=(1, 2))
        inside = L <= self.threshold
        return {"inside": f"{int(inside.sum())}/{len(inside)}",
                "verdict": "fits" if inside.mean() >= 0.8 else "doesn't fit here"}

    def where(self, psd: np.ndarray, f: np.ndarray) -> np.ndarray:
        """Order at which each window's strongest leftover sits (the 'where' of the feeling)."""
        L = self.leftover(psd, f).max(axis=1)
        return self.grid[L.argmax(-1)]

    # ---- the transferable part, as data ----
    def procedure(self) -> dict:
        return {"coordinates": "orders of the machine's own main vibration line", "orders": list(self.orders),
                "step": self.step, "search_rel": self.search_rel, "smooth_bins": self.smooth_bins,
                "std_floor": self.std_floor, "q": self.q, "margin": self.margin, "speed_aware": self.speed_aware,
                "ridge": self.ridge}

    @classmethod
    def from_procedure(cls, p: dict) -> "OrderFeel":
        return cls(orders=tuple(p["orders"]), step=p["step"], search_rel=p["search_rel"],
                   smooth_bins=p["smooth_bins"], std_floor=p["std_floor"], q=p["q"], margin=p["margin"],
                   speed_aware=p.get("speed_aware", False), ridge=p.get("ridge", 1.0))
