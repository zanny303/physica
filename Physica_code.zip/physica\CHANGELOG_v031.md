# Physica v0.31 — Outcome-conditioned feeling & evidence-gated reoptimization

- Integrated the existing supported beam outcome solver with measured sensory surprise and a staged experiment-to-new-plan workflow.
- `physica outcome-loop start`: goal validation, human-approved physical settings, baseline plan and automatically triggered physical inquiry from qualified model mismatch or no feasible plan; a stored experiment plan is committed before measurements.
- `physica outcome-loop learn`: instrument calibration, identity, unit, probe action and fit/validation checks; bounded affine residual reidentification; source-blind baseline comparison; safe refusal; conservative empirical error envelope and new planned outcome.
- `physica outcome-loop verify`: separate future measurement file, immutable forecast reference, action and calibration match, goal grading, uncertainty grading, review-only physical memory.
- `physica outcome-loop export-beam-model`: converts the existing beam tone-point cache into a serialized model, preserving known limitations of the real data provenance.
- `physica outcome-loop domain-inquiry`: shared Goal + FeltExperience path for printer/turbine/F1 recordings. Optional explicitly authorized Muse science council; no mistaken universal physics or unsafe turbine control.
- Added a bounded, opt-in, training-only Muse Wonder residual hypothesis role, with an independently evaluated source-blind comparison; explicit API opt-in and fallback. Added a clearly marked synthetic end-to-end example, 25+ focused new regression tests, Studio Outcome tab and demo task, updated runbook.
- Strengthened outcome contract to reject nonfinite/malformed numerical constraints and unsupported machines.
- Kept the existing v0.30 Sentinel, v0.27 discovery and Muse workflows intact; no claim that their real-world trials have run.
