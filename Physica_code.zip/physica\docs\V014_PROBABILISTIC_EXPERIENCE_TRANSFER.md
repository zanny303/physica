# Physica v0.14 — Probabilistic experience transfer (MACE-X)

## Goal and claims boundary

MACE-X investigates whether Machine A's *experimentally acquired, uncertain knowledge* can reduce the number of observations Machine B needs to predict future physical responses. This release builds on the original v0.13 mechanism search, Studio and Lab/Discover/Lens modules. It does **not** demonstrate consciousness, autonomous hardware operation, general-purpose physical-law discovery, or live Meta model effectiveness.

The scientifically defensible claim is **simulation-conditioned few-shot improvement on related machine populations**. Do not call this a proven original algorithm: Bayesian linear regression, hierarchical priors, negative-transfer avoidance, posterior predictive variance minimization and sparse identification are established techniques.

## What's new (and what is still experimental)

1. **Probabilistic Physical Experience Language (PEL)** (`physica/mace_x/core.py`). Source machines each fit the same finite, physical-feature model; their coefficient variation and estimation uncertainty form a regularized source prior. The exported experience contains feature names, parameter means/covariances, source IDs, calibrated observation models, operating ranges, failure warnings and a hash of source evidence used. It cannot accept arbitrary executable expressions.
2. **Guarded Bayesian transfer**. Machine B maintains two hypotheses: transferred source prior and a wide local prior. Bayesian marginal likelihood on B's *observed* probes updates their mixture weights. Unfamiliar machines can put nearly all weight on the broad local component; out-of-range inputs force local-only inference.
3. **Cross-sensory alignment**. Each physical sensor has an explicit, independently specified calibration of the restricted form `measured_signal = gain * acceleration_proxy + bias + noise`. Inversion and noise propagation convert recorded sensor data into an acceleration estimate. An optional `fit_sensor_observation_map()` learns the gain and offset from separately measured, synchronized reference-acceleration pairs with disjoint calibration training/validation episodes and refuses weak mappings. It cannot authenticate the supplied reference measurements. It includes noise-aware multisensor fusion and refusal on contradictory measurements. **This is not end-to-end learning of arbitrary camera/audio mappings.** The `visual_kinematics` modality expects a previously calibrated acceleration proxy derived from motion measurements, never raw pixels.
4. **Target-directed safe experiment planning**. Ranks controlled, approved and reversible *B-side* probe candidates by their expected reduction in variance on predeclared B queries. This approximation is exact for each linear-Gaussian posterior component but does not model all mixture-weight changes. No probe is actuated automatically.
5. **Meta transfer strategist (optional)**. A bounded Muse request may choose among preapproved reversible probes, request another real sense, or abstain. Proposed probe indices must exist in the safe list and pass a numerical information-value gate. The model cannot set physical weights, write runnable code, or independently validate a mechanism. No paid calls are made by Studio or the benchmark.
6. **Fair learning curves**. Synthetic, *source-population-related*, parameter-shifted and omitted-mechanism target families. Source machines are distinct from targets. All arms receive the same target probe counts, but active policies can choose different probes. Baselines include target-only Bayesian fitting, target-only active design, in-project STLSQ-style sparse dynamics regression and single-prior hierarchical transfer. The original v0.13 target-only bounded mechanism discovery remains available as a separate comparator for a later full scientific study. No PySINDy implementation was executed in this benchmark.
7. **Prospective field-file interface**. `commit` loads only source-machine observations, local B observations and *planned future queries*; it seals predictions to disk before `reveal` can read a separately supplied outcomes CSV. This enforces file separation but a local hash is not independent timestamp or calibration attestation.

## Quickstart (Windows PowerShell, from the `physica` folder)

```powershell
python -m pip install -e ".[dev]"
python -m physica.mace_x.cli benchmark --seeds 12 --out demo\mace_x_v014\learning_curves.json
python -m physica.mace_x.cli example --out demo\mace_x_v014\experience_memory.json
python -m physica.mace_x.cli meta-advise --preview-only --out demo\mace_x_v014\meta_request_preview.json
python -m physica.studio --open-browser
```

A full multi-seed benchmark reports losses and wins, model evidence, source prior posterior weights, and paired target-device bootstrap confidence intervals. The seed-selected simulator is not independently sampled real-world physics.

### Optional actual Muse transfer strategy (can incur fees)

Set `MODEL_API_KEY` in your private shell and run:

```powershell
python -m physica.mace_x.cli meta-advise --seed 1234 --model muse-wonder-1.0 --allow-billed-meta --out demo\mace_x_v014\live_meta.json
python -m physica.mace_x.cli meta-replay --seed 1234 --nomination demo\mace_x_v014\live_meta.json --out demo\mace_x_v014\meta_probe_ablation.json
```

The first command makes a real billed API request **only if you explicitly provide the flag**. The second uses its frozen candidate proposal for a **simulated single-probe matched-budget comparison**. This is not a test of real-world Meta assistance. The offline preview deliberately makes no API request.

### Field data — two-stage evidence boundary

Only use when you have controlled physical measurements, known calibration and approved low-energy experiments.

```powershell
python -m physica.mace_x.field_transfer commit --manifest experiments\mace_x\field.json --out experiments\mace_x\forecast_SEALED.json
# Perform the supervised experiment independently and record the future outcomes in future.csv.
python -m physica.mace_x.field_transfer reveal --forecast experiments\mace_x\forecast_SEALED.json --outcomes experiments\mace_x\future.csv --out experiments\mace_x\score.json
```

Input manifest example at `examples/mace_x_v014/field_manifest_TEMPLATE.json`. Source/target measurement CSV columns: `body_id,episode_id,modality,x,v,u,observation`. Values of `x,v,u` must represent externally measured, synchronized physical states/actions with understood units, not arbitrary camera pixels. Every source device and B has their own sensor-calibration structure. Source and target files require their exact SHA-256 values calculated from local file bytes. `future_queries.csv` has `query_id,episode_id,x,v,u`; the future outcomes file has `query_id,modality,observation` and is **never named in the commit manifest**.

Calibration is `modality`, `gain`, `bias`, `noise_sd`, `calibration_id`, `provenance` (`EXTERNALLY_VERIFIED` or `SIMULATED`), `observed_quantity` (`acceleration_proxy`). This release validates schema, ranges, noise, hashes and compatibility. It **cannot** authenticate that a person actually performed the stated calibration or that the experiment happened after the local commitment. Real proof requires independently witnessed sensor calibration, external timestamps, raw recordings, unseen hardware and repeated runs.

For audio or motor current, the gain/bias calibration is valid only within the actual physical operating range and for the selected feature/signal processing pipeline. Don't claim a microphone directly measures force or that a camera directly measures acceleration without an independently validated dynamics estimator.

## Experimental interpretation

- **Related population**: B's coefficients are sampled from the same distribution as A's. Bayesian priors help most at 0–4 probes. Gains are expected and do not prove new mathematics.
- **Shifted population**: B's coefficients are displaced far from the source family. The broad-component likelihood should dominate, suppressing negative transfer.
- **Omitted mechanism**: B contains a physical term unavailable in the shared feature grammar. Both algorithms can fail even if the mixture refuses transfer. Use v0.13's unknown-physics detector and Muse nomination/evidence-gated search for *new* hypotheses, but do not claim a causal discovery from surrogate fits.
- **Probing**: Target-aware design matters when the desired target-query distribution differs from uniform experiments. The numerical strategy is an approximation and needs real evaluation against competing designs.
- **Meta ablation**: The standard simulator runs with Meta disabled. No Meta-on performance measurement is included unless an authenticated live proposal is saved and independently replayed/evaluated. To prove the model helps science, conduct many matched trials with the same evidence and probe budgets and report null/negative findings.

## Limitations and research backlog

The shared latent dynamics is currently a *known finite linear-in-parameters grammar*. Sensor observation mappings may be learned from externally measured paired reference accelerations, but are restricted to linear gain/bias and are not an unsupervised embodiment-invariant encoder. Physical state `x,v,u` is presumed independently observable; cross-sensory alignment uses known calibration, not a learned nonlinear embodiment-invariant state encoder. A learned observation model would require independent calibration episodes with uncertainty and identifiability checks. Source-prior estimation uses few source machines and a shrinkage/floor approximation, not a fully hierarchical posterior. Mixture experiment design ignores expected posterior model-weight changes; test with Monte Carlo lookahead. Additional strong competitors (actual PySINDy, GP state-space models, learned latent neural state-space models), actual real hardware, and external Meta-on/off evaluation are still needed.

To make Physica a *genuine research breakthrough candidate*, demonstrate a statistically reliable reduction in B's sample requirements over those competitors on genuinely unseen calibrated machines, ideally with different sensing modalities and an independently validated new mechanism. Until then, this is a reproducible and improved experimental platform.
