# Physica v0.32: film day

**New**
- `physica printer-video baseline | compare | reveal | score`: did this printer change? Answers changed, no change or can't tell against its own healthy films. Verdicts are sealed before the reveal, and misses stay in the score.
- `physica meta senses`: scores Muse with and without Physica's senses on real blade cases, with Physica alone as a third arm. Free preview, resumable live run, receipts. Bundled cases in `eval/results/E28_blade_cases.json`, built by `eval/e28_blade_cases.py`.
- `feel_blade` agent tool, so `physica meta ask` can call the blade sense.
- `--sam "print head"` and `--roi` on the printer commands. Later films reuse the same crop.

**Fixed**
- Compressed video: keyframe spikes set the motion threshold and faked a rhythm for the clock, and flicker counted as extra stops. These caused wrong tones and false "evidence insufficient" results.
- Long slow-motion clips could run out of memory: frames are now cropped and scaled as they load.
- `printer-video check` saves its result, so `--after` can pass the fix to the shared engine and Muse.
- A failed live call now appears in the `synthetic-demo` terminal output, and no longer reports 0 calls.
- `physica outcome` with a missing dataset gives a clear refusal, not a traceback.
- The Studio home page opens with the hook. The banners are gone and the other tools remain in the navigation.

**Tested**: printer steps on simulated video, Muse and SAM steps against a local stand-in. **No live Meta call or real printer film was used in this release.**
