# Physica v0.8.6 · Learned Sensory Experience Candidate

This is a **research release candidate**, not a validated foundation model or a breakthrough.

## New core

A synchronization-aware numeric multisensory encoder learns an SVD/PCA latent space from calibrated sensor streams, and action-conditioned linear latent dynamics are trained to predict **future raw sensory channels without observing future measurements**. Training, chronological holdout evaluation and persistence baseline are reproducible.

This does **not** yet learn raw video/audio encoders, nonparametric unknown physical mechanisms, or reliable cross-embodiment causal generalization. No guaranteed breakthrough is possible from software alone.

## Training right now (Windows Terminal / PowerShell profile)

    ..\.venv\Scripts\python.exe -m physica.latent_experience.cli --out demo\latent_test.json

For actual synced measurements prepare CSV `timestamp,action,sense_camera,sense_microphone,sense_touch`, with action at each row referring to controlled excitation before the next row. Example:

    ..\.venv\Scripts\python.exe -m physica.latent_experience.cli --csv measurements.csv --out demo\my_real_report.json

This path checks monotonic timestamps and finiteness but **does not certify** independent calibration or action provenance. Use independently held-out bodies for scientific claims.

## Meta (authenticated API, no silent billing)

    $env:MODEL_API_KEY = "your key"
    ..\.venv\Scripts\python.exe -m physica.latent_experience.meta_scientist --report demo\latent_test.json --out demo\live_meta.json --allow-billed-meta

Sends **aggregate metrics only**, not sensor recordings, to Meta Model API Responses. Uses Muse Spark 1.3 default or `--model muse-wonder-1.0`. Returned suggestions are unvalidated hypotheses and cannot directly actuate hardware or self-validate. Existing `physica.field.cli meta-doctor`, `meta-live-smoke` and `physica.triad.cli meta-scientist` remain available for advanced workflows.

## What scientific evidence is still missing

- Blind, independent real physical experiments with synchronized calibrated sensors and controlled actions.
- Identical data/experiment budgets against nonlinear system identification and world-model baselines.
- Learned cross-machine transfer that improves over target-only fitting in unfamiliar dynamics.
- Authenticated SAM, Spark, Wonder ablations with measured value.
- Verified PEL cross-device execution and manual safety review of any generated machine configuration.

No external datasets have been downloaded or trained here, and no live authenticated Meta call has been executed without user credentials.
