"""Offline Sentinel CLI. No cloud calls, no hidden downloads and no actuation."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from .sentinel import write_report, DataEvidenceError
from .prepare_ims import prepare_ims


def main(argv=None):
    p=argparse.ArgumentParser(description='Physica Sentinel — physical downtime inquiry and retrospective risk evaluation')
    sub=p.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('evaluate',help='Run leakage-separated retrospective alert evaluation')
    a.add_argument('--manifest',required=True)
    a.add_argument('--out',required=True)
    a.add_argument('--alpha',type=float,default=.1)
    a=sub.add_parser('prepare-ims',help='Extract one NASA IMS waveform channel as chronological snapshot RMS')
    a.add_argument('--source',required=True);a.add_argument('--machine-id',required=True)
    a.add_argument('--channel',type=int,required=True);a.add_argument('--out',required=True)
    a.add_argument('--sample-rate-hz',type=float,default=20000.)
    a=sub.add_parser('merge-features',help='Merge per-machine CSV files without mixing units')
    a.add_argument('--sources',nargs='+',required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('prepare-xjtu',help='Extract one XJTU-SY run-to-failure two-axis bearing folder')
    a.add_argument('--source',required=True);a.add_argument('--machine-id',required=True)
    a.add_argument('--axis',type=int,default=0);a.add_argument('--speed-rpm',type=float,required=True)
    a.add_argument('--load-kn',type=float,required=True);a.add_argument('--out',required=True)
    a=sub.add_parser('meta-council',help='Preview or authorize paid source-only Meta scientist')
    a.add_argument('--report',required=True);a.add_argument('--out',required=True)
    a.add_argument('--allow-billed-meta',action='store_true')
    a=sub.add_parser('synthetic-demo',help='GENERATE SIMULATED UNITS and evaluate without cloud API')
    a.add_argument('--out',required=True);a.add_argument('--seed',type=int,default=33)
    args=p.parse_args(argv)
    try:
        if args.cmd=='prepare-ims':
            data=prepare_ims(args.source,args.out,machine_id=args.machine_id,
                channel=args.channel,sample_rate_hz=args.sample_rate_hz)
        elif args.cmd=='merge-features':
            from .prepare_ims import merge_machine_features
            data=merge_machine_features(args.sources,args.out)
        elif args.cmd=='prepare-xjtu':
            from .prepare_ims import prepare_xjtu
            data=prepare_xjtu(args.source,args.out,machine_id=args.machine_id,
                   axis=args.axis,speed_rpm=args.speed_rpm,load_kn=args.load_kn)
        elif args.cmd=='meta-council':
            from .meta import run_council
            data=run_council(args.report,allow_billed_meta=args.allow_billed_meta)
            out=Path(args.out);out.parent.mkdir(parents=True,exist_ok=True)
            out.write_text(json.dumps(data,indent=2,allow_nan=False),encoding='utf-8')
        elif args.cmd=='synthetic-demo':
            from .synthetic import generate
            base=Path(args.out);base.mkdir(parents=True,exist_ok=True)
            manifest=generate(base,seed=args.seed)
            data=write_report(manifest,base/'REPORT_SIMULATED.json')
        else:
            data=write_report(args.manifest,args.out,args.alpha)
        print(json.dumps({k:data[k] for k in ('status',) if k in data} or
                         {'schema':data.get('schema'),'origin':data.get('data_origin'),
                          'summary':data.get('summary'), 'output':str(args.out)},indent=2))
        return 0
    except (DataEvidenceError,OSError,ValueError,KeyError) as exc:
        print(json.dumps({'status':'REFUSED_UNSUPPORTED_EVIDENCE',
                          'reason':str(exc),'no_machine_action':True}))
        return 2

if __name__=='__main__':raise SystemExit(main())
