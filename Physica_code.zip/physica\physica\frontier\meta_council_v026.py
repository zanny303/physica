"""Physica v0.26 — fresh, authenticated Muse research council.

Meta proposes & critiques structures from SOURCE TRAIN measurements only.
All mathematical acceptance is performed later, on held-out physical data.
There is no hardware control, no arbitrary code execution and no simulated
Meta response reported as a real model call. Model calls cost money.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

from .mechanism_dsl import meta_response_schema, validate_meta_mechanism


def _mechanism(payload: str) -> dict:
    if not isinstance(payload,str) or not payload.strip():
        raise ValueError('Muse returned an empty mechanism')
    payload=payload.strip()
    if payload.startswith('```'):
        lines=payload.splitlines()
        if lines and lines[-1].strip()=='```':
            payload='\n'.join(lines[1:-1]).strip()
    value=json.loads(payload)
    if not isinstance(value,dict) or set(value)!={'name','hypothesis','falsification_test','measured_channels','expression_json'}:
        raise ValueError('Muse mechanism response does not match the strict schema')
    value['expression']=json.loads(value.pop('expression_json'))
    validate_meta_mechanism(value)
    referenced=set()
    def inspect(ast):
        if ast['op'] in ('x','v','u'):
            referenced.add({'x':'x_m','v':'v_m_s','u':'u_m_s2'}[ast['op']])
        if 'arg' in ast:inspect(ast['arg'])
        if 'args' in ast:
            for node in ast['args']:inspect(node)
    inspect(value['expression'])
    if not referenced.issubset(set(value['measured_channels'])):
        raise ValueError('Muse proposed an equation using undeclared measured channels')
    return value


def _critic_schema()->dict:
    props={
      'plausible_alternatives':{'type':'array','items':{'type':'string'}},
      'possible_confounders':{'type':'array','items':{'type':'string'}},
      'falsification_experiment':{'type':'string'},
      'reason_to_doubt':{'type':'string'},
      'revision_guidance':{'type':'string'},
    }
    return {'type':'json_schema','json_schema':{'name':'PhysicaCriticV026',
      'strict':True,'schema':{'type':'object','properties':props,
      'additionalProperties':False,'required':list(props)}}}


def _verified(result:dict, *, expected_role:str, task:str)->dict:
    """A fresh response must be backed by a saved client receipt, not a cache."""
    from physica.llm.meta_client import model_id
    if result.get('mode')!='live':
        raise RuntimeError('Refusing offline/cached/replayed model response as live discovery')
    if result.get('model')!=model_id(expected_role):
        raise RuntimeError('Unexpected Meta model identity')
    path=Path(result.get('receipt_path') or '')
    if not path.is_file():
        raise RuntimeError('Fresh Meta receipt missing; science claim refused')
    receipt=json.loads(path.read_text(encoding='utf-8'))
    if receipt.get('mode')!='LIVE META MODEL API' or receipt.get('task')!=task or receipt.get('model')!=result['model']:
        raise RuntimeError('Untrusted Meta response receipt')
    reply=receipt.get('response') or {}
    if not isinstance(reply,dict) or not reply.get('choices'):
        raise RuntimeError('Meta receipt lacks successful provider response')
    if reply['choices'][0]['message'].get('content')!=result.get('content'):
        raise RuntimeError('Meta receipt content does not match evaluated hypothesis')
    if result.get('api_response_id') and reply.get('id')!=result['api_response_id']:
        raise RuntimeError('Meta API receipt ID differs from response')
    return {'model':result['model'],'task':task,
            'api_response_id':reply.get('id'),
            'receipt_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'receipt_path':str(path), 'source':'FRESH_AUTHENTICATED_META_API'}


def run_meta_research_council(training_context:dict, *, allow_billed_meta:bool=False,
                              with_revision:bool=True)->dict:
    """Run Wonder -> Spark critic -> Wonder revision; return up to two structures.

    Every proposal remains UNVERIFIED. The caller must separately fit coefficients
    on SOURCE TRAIN and score on SOURCE VALIDATION. No extra model call can declare
    a law proven. No live call is made without an API key and an explicit billed flag.
    """
    from physica.llm.meta_client import complete,api_key,is_mock
    if not allow_billed_meta:
        raise PermissionError('Explicit --allow-billed-meta required to run Muse research council')
    if is_mock() or not api_key() or os.environ.get('MOCK','1')!='0':
        raise PermissionError('Set MODEL_API_KEY privately and MOCK=0 for live Meta research')
    if training_context.get('input_split')!='SOURCE_TRAIN_ONLY_NO_VALIDATION_OR_TEST':
        raise ValueError('Meta research context must be generated from source TRAIN data only')
    base_prompt='''You are a scientific collaborator proposing ONE NEW, falsifiable acceleration mechanism.
    You have measured (x,v,u,acceleration) and unexplained residual samples from source TRAIN only.
    Hypothesize the mathematical FORM of residual dynamics, NOT any unmeasured physical outcome.
    Prefer nontrivial testable structures that cannot be represented by the generic
    polynomial and drag feature library. Do not assume the law is identifiable.
    Expression AST operators ONLY x,v,u,const,add,mul,sin,cos,tanh,abs,neg,square,cube.
    Numerical constants are starting guesses only: the physical learner refits them.
    Return EXACT keys name,hypothesis,falsification_test,measured_channels,expression_json.
    expression_json MUST be a JSON STRING containing a bounded AST, with <=3 const leaves.
    Do not copy a canned equation: no examples of candidate physical expressions are given.
    Justify the structure from observed TRAIN residuals, report uncertainty and ask for an independent test.
    Only cite measured channels x_m,v_m_s,u_m_s2,acc_m_s2.
    Do not claim a discovery, sensor calibration, validation, or experiment has happened.'''
    evidence=json.dumps(training_context,sort_keys=True,allow_nan=False)
    task_a='physica_v026_wonder_hypothesis'
    def checked_call(role, messages, task, schema, parse, max_tokens):
        # Only retry invalid structured replies, not network failures, avoiding
        # accidental duplicate expensive calls after an uncertain HTTP error.
        for attempt in range(2):
            result=complete(role,messages,task,
                response_format=schema,max_completion_tokens=max_tokens,require_fresh=True)
            proof=_verified(result,expected_role=role,task=task)
            try:
                return parse(result['content']),proof
            except (ValueError,TypeError,KeyError):
                if attempt==1:raise
        raise AssertionError('Unreachable')
    original, first_proof = checked_call('wonder',[
        {'role':'system','content':base_prompt},
        {'role':'user','content':evidence}],task_a,meta_response_schema(),_mechanism,16000)
    proofs=[first_proof]
    proposals=[original]
    task_b='physica_v026_spark_adversarial_critic'
    critic_prompt='''You are a skeptical scientific critic. Find confounders, non-identifiability,
    alternate explanations and a SAFE discriminating physical experiment. The proposed law is unverified.
    You must NOT claim any experiment was performed, or ask for dangerous actuation. Use exact schema.'''
    critique,critic_proof=checked_call('spark',[{'role':'system','content':critic_prompt},
       {'role':'user','content':json.dumps({'training_evidence':training_context,
            'candidate_hypothesis':proposals[0]},allow_nan=False)}],task_b,
       _critic_schema(),json.loads,16000)
    proofs.append(critic_proof)
    if not isinstance(critique,dict) or set(critique)!={'plausible_alternatives','possible_confounders',
               'falsification_experiment','reason_to_doubt','revision_guidance'}:
        raise ValueError('Muse critic returned incorrect scientific schema')
    if with_revision:
        task_c='physica_v026_wonder_revised_hypothesis'
        updated_prompt=base_prompt+'\\nConsider this critic review and revise only when warranted. Original hypothesis may remain unchanged.'
        updated,proof=checked_call('wonder',[{'role':'system','content':updated_prompt},
             {'role':'user','content':json.dumps({'train_only_evidence':training_context,
                'original_candidate':proposals[0], 'adversarial_critic':critique},allow_nan=False)}],task_c,
             meta_response_schema(),_mechanism,16000)
        proofs.append(proof)
        if updated['expression']!=proposals[0]['expression']:
            proposals.append(updated)
    return {'stage':'AUTHENTICATED_UNVERIFIED_META_HYPOTHESIS_COUNCIL',
        'authenticated_live_calls':len(proofs),'models':[item['model'] for item in proofs],
        'receipts':proofs,'proposals':proposals,'critique':critique,
        'context_split':'SOURCE_TRAIN_ONLY_NO_VALIDATION_OR_TEST',
        'validated_as_physical_discovery':False,'machine_actuation':'PROHIBITED',
        'limits':['The API receipts prove the client processed responses, not scientific correctness',
                  'Model proposals are not independent physical observations',
                  'Mechanism acceptance requires separate measured validation']}
