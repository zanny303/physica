"""Command-line demonstrations and strict no-outcome prospective prediction protocol."""
from __future__ import annotations
import argparse
from pathlib import Path
import json
import numpy as np
from .core import Body,Sense
from .prospective_v08 import seal_future_sensations,score_future_reveal,verify_reveal_receipt
from .sensor_isolation_v08 import IsolatingFeelingFilter
from .v08_benchmark import save


def _load(path):return json.loads(Path(path).read_text())

def _write(path,obj):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,indent=2)+'\n')
    print(f'{obj.get("status",obj.get("origin","RESULT"))}: {p}')


def main(argv=None):
    p=argparse.ArgumentParser(description='Physica v0.8: prospective predictive feeling; no actuation')
    sub=p.add_subparsers(dest='cmd',required=True)
    b=sub.add_parser('benchmark');b.add_argument('--seed',type=int,default=2026)
    b.add_argument('--trials',type=int,default=12);b.add_argument('--out',required=True)
    f=sub.add_parser('forecast');f.add_argument('source');f.add_argument('request');f.add_argument('probe');f.add_argument('--out',required=True)
    f.add_argument('--between-machine-sigma',type=float,default=.02,
                   help='Predeclare on independent training machines; cannot fit from target future')
    f.add_argument('--max-disagreement-z',type=float,default=2.5)
    r=sub.add_parser('reveal');r.add_argument('sealed');r.add_argument('observed');r.add_argument('--out',required=True)
    v=sub.add_parser('verify-reveal',help='verify a signed prediction and receipt against raw target measurements')
    v.add_argument('sealed');v.add_argument('observed');v.add_argument('receipt');v.add_argument('--out',required=True)
    s=sub.add_parser('isolate');s.add_argument('session');s.add_argument('--out',required=True)
    args=p.parse_args(argv)
    if args.cmd=='benchmark':
        result=save(args.out,args.trials,args.seed)
        print('SIMULATED_ONLY',result['mean_camera_rmse_mm'],'coverage',result['accepted_forecast_count'],'/',result['target_trials'])
        return result
    if args.cmd=='forecast':
        o=_load(args.request)
        # Strict allowlist: future state, observations and outcome are not forecast inputs.
        allowed={'experiment_id','target_body','senses','times_s','applied_force_n',
                 'initial_state_m_m_s','displacement_reference_m'}
        extras=set(o)-allowed
        if extras:
            result={'status':'REFUSE_FUTURE_OR_UNRECOGNIZED_INPUT','extra_fields':sorted(extras)}
        else:
            target=Body(**o['target_body'])
            senses={k:Sense(**v) for k,v in o['senses'].items()}
            result=seal_future_sensations(_load(args.source),target,senses,
                times_s=o['times_s'],force_n=o['applied_force_n'],
                initial_state=o['initial_state_m_m_s'],
                displacement_reference_m=o['displacement_reference_m'],
                experiment_id=o['experiment_id'],probe_certificate=_load(args.probe),
                between_machine_sigma=args.between_machine_sigma,
                max_disagreement_z=args.max_disagreement_z)
    if args.cmd=='reveal':
        o=_load(args.observed)
        if set(o)!={'experiment_id','measurement_origin','observed_by_sensor'}:
            result={'status':'REFUSE_INVALID_REVEAL_FORMAT'}
        else:
            result=score_future_reveal(_load(args.sealed),o['observed_by_sensor'],
                measurement_origin=o['measurement_origin'],experiment_id=o['experiment_id'])
    if args.cmd=='verify-reveal':
        observed=_load(args.observed)
        valid=(set(observed)=={'experiment_id','measurement_origin','observed_by_sensor'}
               and verify_reveal_receipt(_load(args.receipt),_load(args.sealed),observed['observed_by_sensor']))
        result={'status':'VERIFIED_SIGNED_REVEAL' if valid else 'REFUSE_INVALID_REVEAL',
                'independent_chronology_established':False,
                'hardware_actuation_allowed':False}
    if args.cmd=='isolate':
        o=_load(args.session)
        body=Body(**o['body']);senses={k:Sense(**v) for k,v in o['senses'].items()}
        flt=IsolatingFeelingFilter(body,senses,np.asarray(o['initial_state_m_m_s'],float),
                                  np.asarray(o['initial_covariance'],float))
        reports=[flt.step(sample['timestamp_s'],sample['force_n'],sample['sensors']) for sample in o['samples']]
        result={'status':'SIMULATION_OR_CALIBRATED_REPLAY_ONLY','samples':reports,
                'hardware_actuation_allowed':False}
    _write(args.out,result)
    return result

if __name__=='__main__':main()
