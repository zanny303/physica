# The demo

The film script is [docs/SCRIPT.md](docs/SCRIPT.md). The steps to make it are [docs/TODAY.md](docs/TODAY.md).
