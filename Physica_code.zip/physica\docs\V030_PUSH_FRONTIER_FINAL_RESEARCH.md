# PHYSICA v0.30 — SENTINEL: Feel the change before the machine stops

**Evidence status: synthetic local demo only. Real run-to-failure source data must be downloaded and evaluated separately. No authenticated Meta calls or hardware interventions were executed in this build.**

## The one-sentence problem

**Industrial engineers can detect anomalous readings but often lack enough evidence to know what changed, why it changed, and which additional measurement would make a maintenance decision trustworthy.** Unplanned downtime and production delays are expensive. Physica proposes a scientific investigation assistant, NOT a certified fault-detection system or autonomous maintenance controller.

NIST estimated **$119.1 billion of preventable U.S. manufacturing losses in 2016**, including $18.1 billion in downtime and $100.2 billion in lost sales from defects and delays. These are *historical macroeconomic estimates*, not savings attributable to Physica. See https://www.nist.gov/el/applied-economics-office/manufacturing/topics-manufacturing/manufacturing-machinery-maintenance .

The Meta hackathon's **Push the Frontier** theme explicitly references manufacturing, robotics and better understanding of physical systems. The Indie lens is creativity, technical ambition and working functionality: https://dev.meta.ai/events/global-hackathon . Submission: **November 4, 2026, 9 PM Eastern (8 PM Central)**, subject to the organizer's live instructions.

## What this implementation really adds

1. **Physica Sentinel / physical-innovation monitoring**: a leakage-separated normal-behavior predictor from train-machine speed, load, temperature, current (only available fields), and vibration RMS. Compare with calibrated RMS-only baseline. Both are conventional methods and **not** novel symbolic discovery.
2. **Independent unit calibration**: thresholds are ranks of the maximum normal score on *separate calibration machines*. If there are too few independent units for the requested alpha, the method abstains rather than inventing a formal bound.
3. **Machine and time separation**: explicit train/calibration/source-discovery/test IDs, strict chronology, blind test data not shared with Meta.
4. **Context/operating-envelope guard**: ignore points outside observed train context. If fewer than 80% of the target's samples are within that envelope, abstain. This is a heuristic safety guard, NOT a proof of exchangeability or sensor calibration.
5. **Historical warning evaluation**: first flag and snapshots before a *documented* run end or failure, plus premature alerts during a separately declared verified-healthy period. Never label early alerts “avoided downtime.”
6. **Source-only Muse council**: Wonder hypothesis → Spark adversarial critique → Wonder revision. Generates *unverified* candidate explanations. It cannot access blind test outcomes or command machines.
7. **NASA IMS waveform and XJTU-SY per-minute CSV importers**, with explicit caveats about sensor units and run-end event labels.
8. **Dedicated Sentinel Studio page** at `/sentinel`, with an intentionally unmistakable SIMULATED warning on the included demo.

**Limitation:** Sentinel's new condition-monitoring regression is not a neural world model or causal discovery method. The previous v0.29 neural–physics mechanisms and full seven-stage feeling loop remain in the project; connecting their numerical mechanism-testing route to genuinely measured industrial interventions remains necessary for any breakthrough claim.

## Data: choose the dataset for the claim

| Source | What it contains | Defensible claim / caveat |
|---|---|---|
| Paderborn KAt DataCenter | Synchronized vibration + motor current, 26 damaged and 6 undamaged states, four operating conditions | Real cross-sensory diagnosis. **Not** an inherent chronological run-to-failure study. CC BY-NC 4.0; cite authors, contact for commercial use. https://mb.uni-paderborn.de/en/kat/research/bearing-datacenter |
| NASA/IMS bearings | Real, historical, timestamped run-to-failure vibration experiments | Evaluate early-warning lead time on specific failed bearings. Other bearings mounted on the same shaft are NOT exchangeable independent machines. Do not assume all failed. https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/ |
| XJTU-SY | 15 run-to-failure bearings, three speeds and loads, two-axis vibration every minute | Independent-bearing early warning and cross-operating-condition tests. Sources and citation at https://github.com/WangBiaoXJTU/xjtu-sy-bearing-datasets . No explicit redistributable commercial license is given on the author's README: verify permissions. |
| NASA C-MAPSS | Engine degradation from a simulator | Useful for scaled cloud simulation and RUL methods; **not a physical field recording**. https://www.nasa.gov/intelligent-systems-division/discovery-and-systems-health/pcoe/pcoe-data-set-repository/ |

Paderborn and NASA/XJTU answer *different scientific questions*. Report their metrics independently. A single NASA rig provides far fewer independent machines than the number of per-snapshot files; frame-level train-test splits would artificially inflate performance.

### Fast local sanity check (all inputs SIMULATED)

```powershell
python -m pip install -e ".[dev]"
python -m physica.maintenance.cli synthetic-demo --out demo/v030_synthetic
python -m physica.studio --open-browser
```

Open http://127.0.0.1:8765/sentinel and observe the deliberately marked synthetic replay. No Meta calls or cloud traffic are made by this page.

### Actual XJTU-SY study (real dataset downloaded by you)

One bearing's CSVs are numbered `1.csv`, `2.csv`, ... and contain horizontal/vertical vibration. Use the real operating conditions from the accompanying metadata:

```powershell
python -m physica.maintenance.cli prepare-xjtu --source data/xjtu/35Hz12kN/Bearing1_1 --machine-id Bearing1_1 --axis 0 --speed-rpm 2100 --load-kn 12 --out real/Bearing1_1.csv
# Repeat for independently measured bearings. Do not reuse the same bearing in two splits.
python -m physica.maintenance.cli merge-features --sources real/Bearing1_1.csv real/Bearing1_2.csv real/Bearing1_3.csv --out real/combined_machine_features.csv
```

You need enough independently measured **train, calibration, discovery and blind test bearings**. Use actual IDs in your `REAL_DATA_MANIFEST_TEMPLATE.json`; select and freeze splits BEFORE inspecting the blind test behavior. Record actual healthy-reference periods, failure events and calibrated sensor units, rather than copying example numbers. This implementation does not auto-infer failures from the final file.

```powershell
python -m physica.maintenance.cli evaluate --manifest real/manifest.json --out real/SENTINEL_REPORT.json
python -m physica.maintenance.cli meta-council --report real/SENTINEL_REPORT.json --out real/muse_preview.json
```

To authorize actual (potentially billed) calls with your key configured privately (the CLI does **not** send blind target recordings to Meta):

```powershell
$env:MODEL_API_KEY = "YOUR_PRIVATE_KEY"
$env:MOCK = "0"
$env:PHYSICA_BUDGET_USD = "5"
python -m physica.maintenance.cli meta-council --report real/SENTINEL_REPORT.json --allow-billed-meta --out real/meta_council.json
```

These proposed explanations need **new independent measurements or interventions** before calling them verified. A time-series alert is not causal proof. Do not operate real wind turbines or other hazardous equipment based on this project.

### NASA IMS preparation

Extract the official NASA dataset, select the proper test and channel using official failure documentation, and then:

```powershell
python -m physica.maintenance.cli prepare-ims --source data/ims/2nd_test --machine-id IMS_TEST2_BEARING1 --channel 0 --out real/IMS_TEST2_BEARING1.csv
```

**Do not** group multiple channels from the same run as independent calibration machines. The default 10% conformal rank requires at least 9 independent calibration **machines**; NASA IMS does not offer that many independent run-to-failure rigs. Sentinel will abstain from calling a finite calibration threshold on insufficient independent units.

## What to measure to make the winning claim credible

**Frozen benchmark preregistration**: identities of unseen physical machines, original sensor files, experiment times, hypothesis library, model hyperparameters, number of trial probes, source-only Muse context, and computational budgets.

**Metrics** (no single accuracy score):
- Alarm lead time *in the dataset's actual time units*, with precise identification of a known failure event vs. mere end of experiment.
- Missed failures and **premature alerts during known-healthy periods**, with costs specified by a domain expert, not invented.
- Held-out next-sensation RMSE and calibrated coverage, separately from event detection.
- Scientific mechanism prediction on a new intervention, blinded from Muse and feature selection.
- Information efficiency: how many safe observations needed before a mechanism or outcome is predicted at a predeclared accuracy?
- Meta vs no-Meta comparison, same observations, same probe budget, same model family and comparable compute.
- Transferred knowledge B vs local-only B under equal target data budget. Publish failures and negative transfer too.

## Deep-research choices, ranked by real incremental value

**1. Residual change detection — BOCPD / ADWIN.** Online Bayesian changepoint detection (Adams & MacKay, 2007, https://arxiv.org/abs/0710.3742) and ADWIN (Bifet & Gavaldà, 2007) provide established alternatives to fixed thresholds. Benchmark on unseen runs and evaluate real false alarm/lead time tradeoffs. More important than introducing a transformer with no demonstrated edge.

**2. Streaming calibration under shifts.** Online conformal prediction (Angelopoulos et al., ICML 2024, https://proceedings.mlr.press/v235/angelopoulos24a.html) and Gibbs & Candès' shift-aware method (JMLR 2024, https://jmlr.org/papers/v25/22-1218.html) are worth exploring, but neither grants unconditional per-machine safety guarantees. Treat drift and unknown sensor accuracy explicitly.

**3. Physical mechanisms, not only anomaly labels.** Use measured speed/load/current/vibration to reject load-confounded warnings; test bearing-frequency hypotheses when speed and bearing geometry are independently known, and compare against PySINDy sparse equation discovery (https://pysindy.readthedocs.io/en/stable/). No physics law should be accepted on a text explanation alone.

**4. Multi-sensory model disagreement and virtual sensing.** Electrical motor current can reveal mechanical behavior indirectly; Paderborn provides real parallel signals. Validate detection with vibration withheld, test whether current meaningfully compensates for missing vibration, and report uncertainty. Virtual force and wear must remain *estimated*.

**5. Goal-directed experiments and decision theory.** Model the cost of needless inspection, missed degradation, production delay, and measurements; choose only approved probes predicted to improve the actual *maintenance decision*, not simply maximize an entropy number. For any economic savings claim, estimate actual maintenance/production costs and compare against an established maintenance policy with the same event definitions.

**6. Transfer with negative-transfer safeguards.** Learn mechanisms across different bearings, loads and sampling modalities; refuse a source lesson when the receiving machine does not satisfy sensor/operating compatibility checks. Baselines: local Ridge/ARX, isolation forest/gradient boosting, PySINDy, Bayesian changepoint and an independently trained neural world model.

**7. Neural–physics discovery with intervention verification.** Physica already has bounded Muse + neural residual + symbolic candidate mechanisms. Expand its hypothesis grammar only when the residual and measured context warrant it; fit on source training data, choose a discriminating *safe* test, and seal its predictions before revealing a different machine's outcome. A breakthrough requires a consistent advantage on genuinely unfamiliar physical systems.

**8. Next applications after Sentinel**: precision robot joints (backlash and encoder/motor-current mismatch; see NIST robot PHM work, https://www.nist.gov/publications/quick-positional-health-assessment-industrial-robot-prognostics-and-health-management); semiconductor fab chambers (sensor drift and expensive metrology; see NIST 2025 online-GP dynamic sampling, https://www.nist.gov/publications/comparative-study-semiconductor-virtual-metrology-methods-and-novel-algorithmic). Wind turbines and F1 remain *advisory and retrospective*, without direct equipment control.

## Final hackathon demonstration — recommended storyboard (2:45–3:15, adjust to submission rules)

**0:00–0:20 — Pain.** “Factories lose time when a machine changes before anyone understands why. An alert says something is wrong; it doesn't tell us which experiment will make the explanation credible.” Cite NIST's *historical* downtime economics, not Physica savings.

**0:20–0:50 — Feel.** Show a **real** bearing current/vibration stream from Paderborn or XJTU/IMS with source name, exact bearing ID and model's earlier prediction. Don't fake live capture from a historical archive. Separate raw measurement and inferred state.

**0:50–1:25 — Curious science.** An unexplained residual triggers Muse Wonder to propose rival mechanisms, Spark to critique, Wonder to revise. Show **actual fresh API receipts** and source-only context. Highlight calibrated missing sensor request rather than generic guesses.

**1:25–2:05 — Try to falsify.** Reveal a precommitted prediction for an independently held-out bearing condition. Compare same-data-budget no-Meta and simple RMS-only models; show false alarms and failures. If Muse loses, explain what it learned and the next measurement rather than fabricating a success.

**2:05–2:35 — Physical action.** Ideally show a safe, supervised real printer vibration before/after. If not possible, keep this as a *planned application* and do not call replay intervention success.

**2:35–2:55 — Versatility.** Show a brief F1 race-engineering or turbine advisory example, and a future robot/semiconductor use case. Label real historical recordings vs simulations.

**2:55–3:15 — Thesis.** “Physica isn't just a model that flags faults. It is an AI that notices missing physical understanding and seeks the right experience to resolve it.”

**Why the industrial application matters:** not “we built a generic physics assistant,” but “we're turning invisible mechanical degradation into *testable physical hypotheses and actions engineers can trust*.”

## Key truthful limitations

- v0.30's newly added Sentinel condition-monitoring model is a standard small statistical predictor, not a novel physics/neural system. Existing v0.29 discoveries are retained, not independently proven on real bearing interventions.
- Packaged Sentinel dataset **is simulated** and favorable to the context-adjusted predictor; the reported warning advantage must not appear as an external benchmark result.
- The full physical feeling → mechanism discovery → experimental verification → transfer loop is not proven on real industrial machinery by this package.
- Real client billing/auth, genuine SAM execution, real cloud dataset training and real machine modifications are not verified here.
- Never infer root cause from RMS alone, ascribe a precise RUL to unlabeled recordings, or claim downtime saved from offline replay.
- For the deadline, trustworthy results and explicit limits beat more unsupported claims.

**Vibration-only caveat:** NASA IMS raw snapshots commonly lack synchronized load/current context in this adapter. When no operating-context signals are available, Sentinel permits only the separately calibrated **RMS-only reference**, not the context-adjusted model; if independent calibration units are also insufficient it abstains entirely. This is a limit of the evidence, not a silent software failure. For a physically informed investigation, supply justified operating metadata and sufficient truly independent calibration machines, or use XJTU-SY/Paderborn as appropriate.
