"""Transparent SIMULATOR used for software/unit experiments, never labelled real evidence."""
from __future__ import annotations
import numpy as np

DT=.035

def plan(seed,n=140):
    rng=np.random.default_rng(seed)
    t=np.arange(n)*DT
    u=np.repeat(rng.uniform(-.65,.65,size=(n+11)//12),12)[:n]
    temp=7*np.sin(1.6*t+seed%7)+3*np.cos(3.3*t+.25*seed)
    return {'dt':DT,'u':u,'temperature_delta':temp,'initial':(.24,.03)}

def roll(body,seed,episode,n=140,noise_sd=.009,*,unmodelled=False):
    spec=plan(seed,n);u=spec['u'];tmp=spec['temperature_delta'];dt=spec['dt'];
    rng=np.random.default_rng(seed+17329)
    x,v=spec['initial'];rows=[]
    for i in range(n):
        a=-.82*x-.34*v+u[i]+body.get('thermal',.78)*(tmp[i]/8.)*np.tanh(v)
        if unmodelled:a+=body.get('extra',.4)*np.sin(4*x+v)
        rows.append({'body_id':body['id'],'episode_id':episode,'intervention_type':'controlled',
            't':i*dt,'x':float(x+rng.normal(0,.0002)),
            'v':float(v+rng.normal(0,.0002)),
            'u':float(u[i]),'temperature_delta':float(tmp[i]),
            'acceleration':float(a+rng.normal(0,noise_sd)),
            'sensors':{'camera_m':float(x+rng.normal(0,.0004)),
                       'audio_m_per_s':float(.85*v+rng.normal(0,.001)),
                       'imu_accel':float(a+rng.normal(0,.02)),
                       'temperature_c':float(22+tmp[i])}})
        v+=dt*a;x+=dt*v
    return rows

def forecast_without_truth(model,initial,planned):
    """Future trajectory only from approved actions/context, never actual future states."""
    from .mechanisms import feature
    x,v=[float(q) for q in initial];out=[];dt=float(planned['dt'])
    if dt<=0 or dt>.25:raise ValueError('invalid integration rate')
    if len(planned['u'])!=len(planned['temperature_delta']):raise ValueError('inconsistent plan')
    for i,(u,tmp) in enumerate(zip(planned['u'],planned['temperature_delta'])):
        r={'x':x,'v':v,'u':float(u),'temperature_delta':float(tmp),'intervention_type':'controlled'}
        acc=sum(float(c)*feature([r],t)[0] for c,t in zip(model['coefficients'],model['terms']))
        if not np.isfinite(acc) or abs(acc)>1000:raise ValueError('unstable forecast')
        v+=dt*acc;x+=dt*v
        if abs(x)>25 or abs(v)>100:raise ValueError('out of domain: abstain')
        out.append({'t':(i+1)*dt,'x':x,'v':v,'acceleration':acc,'camera_m':x,'audio_m_per_s':.85*v})
    return out
