# v0.8.2 Field Readiness + Meta Contract Checks

This patch adds **verification controls**, not a new experimentally validated breakthrough.

- New `physica/field/readiness.py` for real CSV, SI units, calibration, experiment identity, sample clock, natural-frequency sampling, SHA-256 evidence, forecast chronology, and video calibration checks.
- New signed real-CSV comparison path. Rejects synthetic forecasts, mismatched experiment IDs, unverifiable sensor mappings, mismatched time grids and incorrect signatures.
- Meta offline doctor: checks declared Responses schema and available SDK/parser, with no API calls or fake credentials.
- Optional `meta-live-smoke --allow-billed-meta`: explicitly billable Spark/Wonder JSON contract test, **not** physics proof.
- 13 new v0.8.2 field and Meta contract tests plus existing focused regression.
- Field metadata + CSV templates and full documentation.

**Unresolved:** independent witness verification remains manual; live Meta executions, SAM tracking, real hardware tests, calibration quality, real-model superiority and Meta-on/off physical ablations have not been executed here. This release does not actuate hardware.
