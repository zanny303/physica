# Physica v0.5.2: One causal-experience intelligence, three experiences

## Status (2026-10-30)

**Implemented:** a target-directed experiment scorer; a real recorded-video optical-flow ingest and held-out predictor; independent signed prediction/reveal; common evidence manifests; a browser-based Lens proof of concept that invokes the same video analysis; optional actual billable Meta Spark / Wonder / SAM adapter invocation, using only first-observed video frames; an external MAT numerical-array inspection adapter; existing CIRTE/PACER/CSG laboratory and A→B→C modules preserved. A fully generated **synthetic** three-demo example is bundled.

**Not implemented or not validated:** authenticated Meta calls from this runtime; Meta glasses hardware/device access or official display simulator deployment; real, independent camera calibration; direct causal identification from arbitrary video; actual Physics-IQ/Paderborn/DROID downloads or external dataset evaluation; prospective independently witnessed A→B→C real intervention; deployed V-JEPA weights; chemical sensor experiments; statistically established transfer superiority. Do not market these as finished.

## Central research claim to test

> Does choosing a *source intervention* specifically to reduce predictive uncertainty on a **different target machine** make transferable physical experience more sample-efficient than choosing an experiment only to identify the source machine?

This is **target-directed causal experience learning**; the component is a research proposal, not a new mathematical theorem. Bayesian experimental design, residual physics models, cross-embodiment transfer, and multi-modal observation models all have substantial prior art. Physica's proposed contribution is **context-sensitive, sensor-aware, applicability-gated experimental knowledge transport** and measured improvements under fair equal-budget tests.

### Exact implemented target-directed design (locally linear / Gaussian)

Assume uncertain mechanism parameters with posterior covariance Σ. A source probe with sensitivity vector `φ_a`, independently calibrated noise variance `σ_a²`, changes the parameter covariance by

    Σ_after = Σ - (Σ φ_a φ_aᵀ Σ) / (σ_a² + φ_aᵀ Σ φ_a).

A target-machine population with expected feature outer product `Q_B = E[φ_B φ_Bᵀ]` has expected parameter-induced predictive squared-error `tr(Q_B Σ)`. The planner selects an approved reversible source probe to maximize

    target_value(a) = tr[ Q_B (Σ - Σ_after) ] - λ risk(a) - μ cost(a).

If no approved, finite, reversible probe exists, it abstains. The selected action is a **recommendation only** and never triggers hardware. The current implementation requires externally specified source/target features and calibration; automatically inferring those from video is an unsolved part of the bigger program. This is a known A-optimal Bayesian design form applied to transfer, not proof of unprecedented novelty.

In `examples/triad_v052/target_transfer_design.json`, a source-only information-gain maximizer and target-transfer maximizer choose different actions. All data are **illustrative**.

## Three experiences, same trust contract

### 1. Physica Lab — reality is the judge

Existing `examples/cirte_v05/BUILD_NATIVE_SIMULATION.py` executes the signed A→B→C mechanism; real use replaces all simulated measurements with independently calibrated A microphone / IMU, B motion camera, and separate low-force probe data. It requires an independently witnessed prediction seal before later measurements and fair physics-only and conventional-ID controls.

Research demonstrator:

    python examples/cirte_v05/BUILD_NATIVE_SIMULATION.py examples/cirte_v05/native_demo

**Do not confuse successful simulation with a real makerspace experiment**.

### 2. Physica Discover — unfamiliar recorded real physics

New `physica.triad.video` ingests `.mp4` through OpenCV with an ROI fixed *before* prediction, optionally subtracts camera movement using a fixed reference ROI, keeps measurements in pixels unless supplied an independent `pixels_per_metre` calibration, and fits either a constant-velocity baseline or a damped-oscillator surrogate. Model selection uses only observations available before the holdout. It then forecasts unseen frames. It cannot uniquely determine mass, force, friction, or cause from video.

    pip install -e '.[video,dev]'
    python -m physica.triad.cli discover-video my_clip.mp4 --roi 100 60 80 80 --out discover.json

For two-step integrity on a *pre-existing* full clip:

    python -m physica.triad.cli prepare-video my_clip.mp4 --roi 100 60 80 80 --prefix-frames 120 --horizon-frames 30 --out sealed.json
    python -m physica.triad.cli check-video my_clip.mp4 --roi 100 60 80 80 --commit sealed.json --out revealed.json

The `prepare` run reads only prefix frames, though the full original recording already exists. The Ed25519 signature prevents altered forecasts from passing, **not proof of independent chronology**. A truly prospective real experiment requires fresh post-commit filming plus an outside witness or timestamp system.

A bundled synthetic movie shows how to run the pipeline. Replace with a genuine independently sourced recording and document the license, original URL, machine, conditions, and train/test split.

Potential external evidence resources mentioned in the project review (not downloaded or validated here): Physics-IQ Verified for challenging visual physics and Paderborn University's Bearing DataCenter for synchronized motor-current/vibration signals. The included `inspect-mat` command discovers numeric fields in local MAT files rather than inventing field names or operating labels.

    python -m physica.triad.cli inspect-mat downloaded_sample.mat --out fields.json
    python -m physica.triad.cli sample-mat downloaded_sample.mat --field 'EXACT.NUMERIC.FIELD' --sample-rate 64000 --unit V --license-note 'license verified by researcher' --out signal.json

Use held-out physical machines and operating conditions. An accuracy score without calibration and sample-rate metadata is not credible. An existing dataset is real empirical evidence but **does not prove a prospective intervention by Physica**.

### 3. Physica Lens — everyday physical intelligence

A local-only browser server lets the user choose/record an existing video, drag a part ROI, optionally provide known physical scale, and run the same motion analysis as Discover. The result displays measured motion, held-out forecast error versus persistence, possible causes **as hypotheses**, and a safe next observational step.

    python -m physica.triad.cli lens-serve --port 8765

Open `http://127.0.0.1:8765` on the SAME computer. This is not yet a network-secured phone backend or Meta glasses app. It has a 50MB per-upload limit and does not persist uploaded video, automate repairs or control devices. A native phone/glasses connection will require supported SDK integration, access permissions, end-user consent and a secure authenticated service. **Do not present the preview HTML as a functioning standalone app:** it requires the local server.

Context choices deliberately limit advice to general observation, furniture with reversible gentle tests, and observe-only machine operation. Diagnose structural hazards or appliances only with appropriate professional supervision.

## Meta models — measurable involvement, not decorative descriptions

Existing Meta integration code implements an authenticated Responses-compatible Muse Spark and Muse Wonder path, and an official-parser SAM 3.1 adapter. New `meta-scientist` command can send a prefix-only recording to Spark/Wonder to propose scene context and falsifiable explanations; optionally SAM tracks an object and can convert its bounding-box pixel displacement using an independently supplied camera scale. **No live call has been made in this release.**

    export MODEL_API_KEY='...private, never commit...'
    pip install -e '.[meta,video]'
    python -m physica.triad.cli meta-scientist my_clip.mp4 --prefix-frames 120 \
        --sam-concept 'the moving clamp' --allow-billed-meta --out meta_output.json

To attempt calibrated SAM displacement, additionally pass `--sam-object-id N --pixels-per-metre P`, after verifying camera geometry with a fixed reference. A model's scene description is **not** a physical measurement; generated hypotheses must be tested by CIRTE's independently calibrated numerical planner. Calls could fail if a model or API contract has changed; inspect actual responses and follow Meta's current developer documentation. A V-JEPA latent embedding readout requires separate weights and held-out calibration, retained in the existing Physica modules, not automatically called by the hosted API.

### Equal-budget Meta-off versus Meta-on evaluation (not run here)

- Use the same actual recorded scenes, camera calibration, probe budget and held-out outcomes.
- Meta-off: manually fixed ROI + predeclared mechanism family and probe list.
- SAM-on: measure independently validated tracking quality, part identity and error.
- Spark/Wonder-on: score hypothesized confounders and proposed experiments **before** ground truth is revealed; measure number of safe tests to reach target prediction error.
- Full: integrate valid, calibratable geometry and approved candidate mechanisms with CIRTE, then store signed results.
- Record failed calls, API latency, cost, invalid suggestions and cases where Meta adds no advantage.

**An improvement cannot be inferred from a mocked or author-written response.**

## Evidence targets before claiming 9+/10

1. **Lab:** real prediction sealed and independently witnessed before B observation; out-of-family conditions and failure trials reported.
2. **Discover:** genuinely external recorded-video or measured machine dataset, unseen physical systems, a defined metric and matched baselines.
3. **Lens:** real user footage producing a safe, testable hypothesis and a measured follow-up (not scripted text).
4. **Meta:** authenticated Spark/Wonder/SAM outputs with reproducible ablations demonstrating material benefits.
5. **Science:** baseline comparisons for target-directed experiment design versus source-only EIG, physics-only, nearest-neighbor and fitted nonlinear dynamics. Show whether fewer target experiments achieve the *same error threshold*.

No code-only release, regardless of number of tests, can substitute for these measurements. Neither a 9/10 rating, a hackathon win nor scientific novelty is guaranteed.

## Three-minute film structure (proposed, not filmed)

**0:00–0:55 — Lab:** source physical experiment, missing mechanism, sealed target prediction, independent measurement and baseline. Show negative/abstained cases.

**0:55–1:45 — Discover:** unseen, externally recorded real physics clip. Show prefix-only evidence, precommitted future forecast, actual withheld event and an appropriate baseline; show a physics question the video cannot answer.

**1:45–2:30 — Lens:** a safe everyday problem. Upload footage, pick the moving part, see testable alternatives and conduct a reversible check. Explain Meta glasses as future integration unless actually deployed.

**2:30–3:00 — One core algorithm:** Meta establishes scene context, SAM supplies geometry, CIRTE chooses transfer-directed experiments, PEL carries the lesson. Show exactly one measured ablation, not promotional claims.

*Pitch:* **"AI today recognizes the world. Physica learns what changes it — and can teach the consequences to another machine."**

## Literature relationship

The current work builds upon known optical flow, modal identification, transfer and residual dynamics learning, calibration, Bayesian optimal experimental design and scientific active learning. External references worth reviewing (titles verified against the pasted project discussion; precise current online version not re-verified in this environment): **V-JEPA 2**, **TacX**, **Cross-Sensor Touch Generation**, **Physics-IQ Verified**, Paderborn Bearing DataCenter, and SINDy / residual physics transfer. This release claims a new software implementation of a research **hypothesis**, not an established mathematically novel transform.
