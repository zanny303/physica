"""Evidence-grounded consumer/robotic diagnosis, never repair instructions by default."""
from __future__ import annotations
import math

CASES={
 'washing_machine':{
  'possibilities':['uneven load','uneven floor or installation','worn suspension','bearing or drive fault'],
  'safe_check':'Stop the cycle. Follow the manufacturer instructions for checking and redistributing a load, then record a later normal cycle from a safe distance.',
  'stop':'If violent movement, burning smell, leakage, exposed electrical parts or grinding occurs, stop use and contact a qualified technician.'},
 'robot_arm':{
  'possibilities':['load-dependent deflection','joint backlash','increased joint friction','calibration drift','controller tuning or thermal effects'],
  'safe_check':'Use a supervised low-energy, no-contact diagnostic with a human-approved trajectory and logged commanded and measured positions.',
  'stop':'If people could be struck, the arm behaves unpredictably, or an emergency stop is active, do not move the arm; follow site safety procedures.'},
 '3d_printer':{
  'possibilities':['belt tension or carriage play','stepper vibration','frame resonance','input shaper mismatch','loose mounting'],
  'safe_check':'With the machine stationary and safe, inspect obvious mounting issues according to the manual; collect a normal-operation vibration recording without approaching moving or hot parts.',
  'stop':'Do not touch hot surfaces or moving axes; stop and seek maintenance if wiring or fire risk is suspected.'},
}

def diagnose(case,question='',evidence=None,before_after=None):
    if case not in CASES:raise ValueError('unsupported device class; do not invent confident diagnoses')
    if not isinstance(question,str) or len(question)>1500:raise ValueError('invalid question')
    evidence=evidence or {}; red=CASES[case]
    if not isinstance(evidence,dict):raise ValueError('evidence must be object')
    channels=[]
    for k,v in evidence.items():
        if k not in ('dominant_frequency_hz','vibration_rms','motor_current_a','temperature_c','camera_displacement_m','mic_acoustic_rms','spin_rpm','robot_tracking_error_m'):
            raise ValueError('unrecognized measurement channel: '+k)
        if not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v):raise ValueError('non-numeric evidence')
        channels.append(k)
    changes=None
    if before_after is not None:
        if not isinstance(before_after,dict) or set(before_after)!={'before_rms','after_rms','same_operating_condition'}:raise ValueError('invalid before-after evidence')
        b,a=before_after['before_rms'],before_after['after_rms']
        if not all(isinstance(v,(float,int)) and math.isfinite(v) and v>=0 for v in (b,a)):raise ValueError('invalid RMS evidence')
        if before_after['same_operating_condition'] is not True:
            changes={'status':'NOT_COMPARABLE_CONDITIONS'}
        else:
            changes={'status':'BEFORE_AFTER_ASSOCIATION_NOT_CAUSAL_PROOF',
                     'relative_rms_change':(a-b)/max(b,1e-8)}
    return {'status':'EVIDENCE_LIMITED_POSSIBLE_CAUSES','case':case,'question':question[:700],
            'measured_channels_claimed_by_user':channels,'possible_explanations_not_diagnoses':red['possibilities'],
            'safe_next_observation':red['safe_check'],'stop_and_escalate':red['stop'],
            'comparison':changes,'needs_independent_calibration':bool(channels),
            'physical_mechanism_verified':False,'meta_reasoning_executed':False,
            'cannot_determine_hidden_fault_from_single_image':True,'no_actuation':True}
