"""Live experiment loops: Physica asks for a recording, works out what to do, then checks it by feeling again."""
