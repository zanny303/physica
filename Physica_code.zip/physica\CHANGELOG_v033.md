# Physica v0.33: the full loop on a real printer

**New: one real-machine cycle, using Bayesian system identification and the added-mass test from modal testing**
- `printer-video calibrate`: learns the printer's effective moving mass and stiffness, with uncertainty, from films with a known weight fastened on.
- `printer-video plan-test`: when the tone changes, compares "more mass" against "less stiffness", ranks your weights by expected information gain, and seals both forecasts before the test.
- `printer-video test`: answers more mass (with grams), less stiffness (with percent), neither, or can't tell.
- `printer-video predict` and `grade-predict`: seals the tone and shaper setting for a new load before filming it, and scores it against assuming nothing changes.
- `printer-video teach`, plus `predict --card`: passes the mass fraction to another printer as a starting estimate, scored against having no lesson.
- `printer-video report`: one page for the video, listing every trial and miss, with real or simulated labels.

**Fixed**
- Tone readings for change and cause decisions now add up every stop's spectrum, which repeats far better than fitting each stop alone.
- SAM's cost limit assumed 50 frames, so a long clip could go past the budget. It now counts the real frames.
- SAM now gets a short clip around the motion, not the whole film, which cuts cost and upload size. The crop still applies to every film.

**Removed from the plan**: the `physica.vision` add-on isn't in this release, because its demo had two identical machines and could name the wrong mechanism.

**Tested**: on simulated video only. Across 30 simulated MP4 cases the cause test gave 15 right answers, 0 wrong and 15 no-answers. Simulated physics is cleaner than a real printer, so expect real results to differ. **No real printer film or live Meta call was used in this release.** Real printers have more than one mode, so `calibrate` is the first thing to try on your machine.
