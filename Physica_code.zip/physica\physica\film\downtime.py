"""Clip: real bearings that really failed, and how much warning the feel gave."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from physica.maintenance import feel_bearing as FB

from . import style as S

ROOT = Path(__file__).resolve().parents[2] / "eval" / "results"
LABEL = "REAL RUN-TO-FAILURE DATA · FEMTO lab bearings"
HERO = "Bearing1_6"


def _load() -> dict:
    r = json.loads((ROOT / "E32_bearing_downtime.json").read_text())
    f = FB.timed(np.load(ROOT / "E32_femto_features.npz")[HERO])
    s = FB.scores(f)
    u = next(x for x in r["units"] if x["bearing"] == HERO)
    return {"r": r, "t": f[:, 0] / 60, "peak": f[:, 2], "score": s["feel"], "th": r["thresholds"]["feel"], "u": u}


def scene_hero(fig, d, t):
    S.headline(fig, "A real bearing, running until it dies")
    S.label(fig, LABEL)
    u, tm = d["u"], d["t"]
    p = S.ease(t / 10.0)
    now = p * tm[-1]
    m = tm <= now
    ax = S.axes(fig, [0.07, 0.5, 0.62, 0.36])
    ax.plot(tm[m], d["peak"][m], color=S.AMBER, lw=1.6)
    ax.set_xlim(0, tm[-1])
    ax.set_ylim(0, 11.5)
    ax.set_ylabel("peak vibration (g)")
    ax.tick_params(labelbottom=False)
    ax2 = S.axes(fig, [0.07, 0.14, 0.62, 0.31])
    show = np.log1p(d["score"])
    th = float(np.log1p(d["th"]))
    ax2.plot(tm[m], show[m], color=S.TEAL, lw=2.5)
    ax2.axhline(th, color=S.DIM, ls="--", lw=1.2)
    ax2.text(3, th * 1.12, "alarm level, set on other bearings", color=S.DIM, fontsize=15)
    ax2.set_xlim(0, tm[-1])
    ax2.set_ylim(0, max(float(show.max()) * 1.08, th * 2))
    ax2.set_xlabel("minutes running")
    ax2.set_ylabel("feel: added evidence (log)")
    at = u["feel"]["at_min"]
    fired = now >= at
    if fired:
        for a in (ax, ax2):
            a.axvline(at, color=S.TEAL, lw=2.2)
    fig.text(0.73, 0.80, "Feel", color=S.DIM, fontsize=22, fontweight="bold")
    fig.text(0.73, 0.71, "ALARM" if fired else "watching", color=S.TEAL if fired else S.DIM, fontsize=52, fontweight="bold", va="center")
    done = now >= tm[-1] * .995
    a = S.fade(t, 9.9)
    fig.text(0.73, 0.35, f"{int(u['feel']['warning_min'])} min", color=S.TEAL, fontsize=70, fontweight="bold", va="center", alpha=a if done else 0)
    fig.text(0.73, 0.255, "of warning before the run ended", color=S.FG, fontsize=22, alpha=a if done else 0)
    S.caption(fig, f"Learned this bearing's normal in its first 10 minutes. Run ended at {tm[-1]:.0f} min.", S.fade(t, 1.0))


def scene_all(fig, d, t):
    r = d["r"]
    su = r["summary"]
    S.headline(fig, "Warned before failure on 10 of 11 bearings")
    S.label(fig, LABEL)
    units = sorted(r["units"], key=lambda u: -(u["feel"]["warning_min"] if u["feel"] else -1))
    ax = S.axes(fig, [0.08, 0.2, 0.56, 0.67])
    grow = S.ease(t / 1.4)
    for i, u in enumerate(units):
        y = len(units) - 1 - i
        ax.barh(y, u["life_min"] * grow, height=.62, color="#1b2a38")
        if grow > .95 and u["feel"]:
            ax.barh(y, u["feel"]["warning_min"], left=u["feel"]["at_min"], height=.62, color=S.TEAL)
        txt = "no alarm" if not u["feel"] else f"{u['feel']['warning_min']:.1f} min"
        if u["feel"] and u["feel"]["life_used"] < .5:
            txt += " (maybe a false alarm)"
        ax.text(u["life_min"] * grow + 5, y, txt, color=S.FG if u["feel"] else S.RED, fontsize=15, va="center", alpha=S.fade(t, 1.4), clip_on=False)
    ax.set_yticks(range(len(units)), [u["bearing"].replace("Bearing", "#") for u in reversed(units)], color=S.FG, fontsize=15)
    ax.set_xlabel("minutes running. Teal: the warning.")
    ax.set_xlim(0, 410)
    a = S.fade(t, 2.0)
    clean = [u["feel"]["warning_min"] for u in r["units"] if u["feel"] and u["feel"]["life_used"] >= .5]
    for i, (big, name) in enumerate(((f"{su['feel']['alarmed']}/11", "warned before failure"), (f"{int(max(clean))} min", "longest warning"), (f"{su['feel']['median_warning_min']:.0f} min", "typical warning (median)"))):
        y = 0.74 - i * 0.2
        fig.text(0.8, y, big, color=S.TEAL, fontsize=50, fontweight="bold", alpha=a, va="center")
        fig.text(0.8, y - 0.06, name, color=S.FG, fontsize=18, alpha=a, va="center")
    S.caption(fig, "Lab bearings, overloaded to fail within hours. Alarm rules were fixed on 6 other bearings.", S.fade(t, 2.6), width=118)


def scene_cost(fig, d, t):
    S.label(fig, "SOURCE · Siemens, True Cost of Downtime 2024 (estimate)")
    fig.text(0.5, 0.62, "$1.4 trillion a year", color=S.AMBER, fontsize=96, fontweight="bold", ha="center", va="center", alpha=S.fade(t, 0.1))
    fig.text(0.5, 0.48, "what unplanned downtime costs the world's 500 largest companies", color=S.FG, fontsize=32, ha="center", va="center", alpha=S.fade(t, 0.7))
    fig.text(0.5, 0.36, "About 11% of their revenue.", color=S.FG, fontsize=32, ha="center", va="center", alpha=S.fade(t, 1.2))


def render(out: str | Path) -> str:
    d = _load()
    scenes = [(scene_cost, 3.5), (scene_hero, 11.0), (scene_all, 5.5)]

    def draw(fig, t):
        for fn, length in scenes:
            if t < length:
                return fn(fig, d, t)
            t -= length
    return S.render(out, draw, sum(x for _, x in scenes))
