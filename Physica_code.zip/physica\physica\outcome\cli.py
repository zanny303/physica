"""physica outcome "<what you want>"  — say the outcome; get the plan, the machine code, the toolchain check and the
sealed promise.

  physica outcome "A pump beside this beam runs at 31 Hz. Keep the tone 5% away; move the support as little as possible."
  physica outcome "Keep WTG-07 producing through the freeze; never restart a cracked blade" --verdict verdict.json
  physica outcome "Inspect blade 2 of the turbine at 12 m stand-off" --machine drone --lat 56.2 --lon 9.5 --fly
  physica outcome "Make the remote lab motor reach 1 rad within 0.6 s with less than 5% overshoot" [--probe probe.json]
  physica outcome grade --promise out/support_move.promise.json --quantity tone_hz --measured 28.9
Add --live to have Muse Spark read the goal and brief you (needs MOCK=0 and MODEL_API_KEY in your terminal).
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np


def _say(title, obj=None):
    print(f"\n== {title}")
    if obj is not None:
        print(obj if isinstance(obj, str) else json.dumps(obj, indent=1, default=float))


def _beam(spec, args, out: Path):
    from physica.data.dropbear import MM_PER_VOLT_D8
    from physica.outcome import check
    from physica.outcome.compile import gcode
    from physica.outcome.engineer import plan
    from physica.outcome.promise import seal_promise
    from physica.outcome.worlds.beam import BeamWorld, presets, tone_points
    pts = tone_points(cache=os.environ.get("PHYSICA_D8_CACHE", str(Path.home() / ".cache" / "physica" / "d8_points.npz")))
    world = BeamWorld.learn(pts[pts["group"] == "sweep"])
    grid = None if args.continuous else presets(pts[pts["group"] == "random"])
    v0 = (args.from_mm / MM_PER_VOLT_D8) if args.from_mm is not None else float(np.mean(world.v_range))
    if grid is not None:
        v0 = float(grid[np.argmin(np.abs(grid - v0))])
    _say("map (felt, not assumed)", {"felt_range_mm": [round(world.v_range[0] * MM_PER_VOLT_D8, 1),
                                                        round(world.v_range[1] * MM_PER_VOLT_D8, 1)],
                                      "support_now_mm": round(v0 * MM_PER_VOLT_D8, 1),
                                      "tone_now": world.predict(v0)})
    p = plan(spec, world, {"support_v": v0, "presets": grid})
    _say("plan", p.say)
    for a in p.alternatives:
        print("  alternative:", a["say"])
    if p.status != "act":
        return p, None
    s = seal_promise("tone_hz", p.predicted["lo"], p.predicted["hi"], "beam tone after the support move",
                     forcing_hz=spec.context.get("forcing_hz"))
    lo_mm, hi_mm = world.v_range[0] * MM_PER_VOLT_D8, world.v_range[1] * MM_PER_VOLT_D8
    cfg = gcode.klipper_config(lo_mm, hi_mm)
    mv = gcode.klipper_move(v0 * MM_PER_VOLT_D8, p.action["support_v"] * MM_PER_VOLT_D8, s["anchor"])
    (out / "support_actuator.cfg").write_text(cfg)
    (out / "support_move.gcode").write_text(mv)
    (out / "support_move_grbl.gcode").write_text(gcode.grbl_move(v0 * MM_PER_VOLT_D8, p.action["support_v"] * MM_PER_VOLT_D8, s["anchor"]))
    (out / "support_move.promise.json").write_text(json.dumps(s, indent=1))
    _say("machine code (Klipper)", mv)
    _say("checked by real Klipper", check.klipper(cfg, mv, expect_mm=(p.action["support_v"] - v0) * MM_PER_VOLT_D8,
                                                  mm_per_step=8.0 / 3200))
    _say("sealed promise", {"anchor": s["anchor"], "tone_hz": s["payload"]["prediction"]["intervals"]["tone_hz"]})
    return p, s


def _turbine(spec, args, out: Path):
    from scipy import stats
    from physica.outcome import check
    from physica.outcome.compile import plc
    from physica.outcome.promise import seal_promise
    from physica.outcome.contract import turbine_never
    root = Path(__file__).resolve().parents[2]
    never = turbine_never(spec, root / "eval" / "results" / "E20_wind_blade.json")
    if never and not never["promisable"]:
        _say("the goal says 'never'; the evidence says otherwise", never)
        if not args.accept_measured_risk:
            _say("REFUSED", "Re-run with --accept-measured-risk to get review-only PLC logic that states this risk.")
            raise SystemExit(2)
    v = json.loads(Path(args.verdict).read_text()) if args.verdict else {"verdict": "ice", "change_score": 31.0}
    thr = float(stats.chi2.ppf(1 - 1e-3, 7))
    act = {"weather only": "run", "ice": "pause, heat, resume only if the sealed promise holds"}.get(
        v["verdict"], "brake, lock the rotor, send the drone; a human clears it")
    _say("plan", f"Blade verdict '{v['verdict']}' -> {act}.")
    s = seal_promise("change_score", 0.0, thr, "after de-icing the blade feels like itself")
    st = plc.blade_guard(thr, s["anchor"])
    (out / "blade_guard.st").write_text(st)
    _say("machine code", "IEC 61131-3 Structured Text -> blade_guard.st (the PLC enforces the promise)")
    _say("checked by real matiec + gcc", check.matiec(st))
    return None, s


def _drone(spec, args, out: Path):
    from physica.act.turbine import inspection_mission
    from physica.outcome import check
    sm = spec.get("standoff_m", ">=") or 12.0
    w = inspection_mission(args.lat, args.lon, args.heading, args.hub, args.blade, standoff_m=sm, step_m=4)
    (out / "blade_inspection.waypoints").write_text(w)
    _say("machine code", f"MAVLink mission (QGC WPL 110), {len(w.splitlines()) - 1} items -> blade_inspection.waypoints")
    _say("checked by pymavlink", check.mavlink_mission(w))
    if args.fly:
        h = w.splitlines()[1].split("\t")
        r = check.ardupilot_sitl(w, (float(h[8]), float(h[9]), 0, args.heading), tower=(args.lat, args.lon))
        r.pop("track", None)
        _say("flown on real ArduPilot (SITL)", r)
    return None, None


def _pendulum(spec, args, out: Path):
    from physica.outcome.compile import remote
    from physica.outcome.engineer import plan
    from physica.outcome.promise import seal_promise
    from physica.outcome.worlds.pendulum import PendulumWorld, identify
    target = spec.context.get("target") or 1.0
    probe = {"kp": 0.2, "kd": 0.01}
    if not args.probe:
        (out / "run_cloudpendulum.py").write_text(remote.cloudpendulum_script(spec.goal_text, target, probe))
        _say("next", "Run `python run_cloudpendulum.py <token> probe`, then come back with --probe probe.json")
        return None, None
    pr = json.loads(Path(args.probe).read_text())
    a = np.asarray(pr["t_pos_vel"], float)
    idp = identify(a[:, 0] - a[0, 0], a[:, 1] - a[0, 1], pr["kp"], pr["kd"], pr["target"] - a[0, 1])
    _say("felt the joint", idp)
    p = plan(spec, PendulumWorld(idp["J"], idp["b"], target), {})
    _say("plan", p.say)
    if p.status != "act":
        return p, None
    s = {"settle_s": seal_promise("settle_s", p.predicted["settle_lo"], p.predicted["settle_hi"], "settling time"),
         "overshoot_pct": seal_promise("overshoot_pct", p.predicted["overshoot_lo"], p.predicted["overshoot_hi"], "overshoot")}
    (out / "pendulum.promises.json").write_text(json.dumps(s, indent=1))
    (out / "run_cloudpendulum.py").write_text(remote.cloudpendulum_script(spec.goal_text, target, probe,
                                                                          s["settle_s"]["anchor"], p.action))
    return p, s


def _grade(argv):
    from physica.outcome.promise import grade
    ap = argparse.ArgumentParser(prog="physica outcome grade")
    ap.add_argument("--promise", required=True)
    ap.add_argument("--quantity", required=True)
    ap.add_argument("--measured", type=float, required=True)
    a = ap.parse_args(argv)
    print(json.dumps(grade(json.loads(Path(a.promise).read_text()), a.quantity, a.measured), indent=1, default=float))


def main(argv=None):
    import sys
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "grade":
        return _grade(argv[1:])
    from physica.outcome.spec import parse_goal
    ap = argparse.ArgumentParser(prog="physica outcome", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("goal")
    ap.add_argument("--machine", choices=["beam", "turbine", "drone", "pendulum"])
    ap.add_argument("--live", action="store_true", help="Muse Spark reads the goal and briefs you (billed)")
    ap.add_argument("--out", default="outcome_out")
    ap.add_argument("--from-mm", type=float, dest="from_mm")
    ap.add_argument("--continuous", action="store_true", help="beam: any position, not only the actuator presets")
    ap.add_argument("--verdict", help="turbine: a blade verdict JSON from `physica cause` / BladeSense.judge")
    ap.add_argument("--lat", type=float, default=56.2)
    ap.add_argument("--lon", type=float, default=9.5)
    ap.add_argument("--heading", type=float, default=90.0)
    ap.add_argument("--hub", type=float, default=60.0)
    ap.add_argument("--blade", type=float, default=30.0)
    ap.add_argument("--accept-measured-risk", action="store_true", dest="accept_measured_risk",
                    help="turbine: accept the blade sense's measured miss rate (review-only logic)")
    ap.add_argument("--fly", action="store_true", help="drone: fly the mission on ArduPilot SITL (PHYSICA_ARDUPILOT)")
    ap.add_argument("--probe", help="pendulum: probe.json from run_cloudpendulum.py")
    a = ap.parse_args(argv)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    spec = parse_goal(a.goal, a.machine, live=a.live or None)
    _say("goal, as a checkable spec", spec.to_json())
    if spec.unclear:
        print("  unclear:", "; ".join(spec.unclear))
    from physica.outcome.contract import check
    problems = check(spec)
    if problems:
        _say("REFUSED: no plan, no machine code", {"status": "refused: the goal is incomplete", "needs": problems})
        raise SystemExit(2)
    if spec.machine == "f1":
        _say("next", "F1 isn't part of this repository")
        return
    try:
        p, s = {"beam": _beam, "turbine": _turbine, "drone": _drone, "pendulum": _pendulum}[spec.machine](spec, a, out)
    except (FileNotFoundError, KeyError) as e:
        if isinstance(e, KeyError) and not str(e).strip("'").startswith("PHYSICA_"):
            raise
        _say("REFUSED: this goal needs a dataset that isn't on this computer",
             {"status": "refused: missing data", "needs": str(e).strip("'\""), "where_to_get_it": "DATA.md"})
        raise SystemExit(2)
    if a.live and p is not None:
        from physica.outcome import muse
        _say("Muse Spark briefing (numbers from the plan only)", muse.brief(p.to_json()))
    print(f"\nFiles in {out}/")


if __name__ == "__main__":
    main()
