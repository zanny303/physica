"""Validation-selected action-conditioned sensation forecast.

Explicitly compares an interpretable sensor-space ARX model, a learned PCA
latent model and a persistence comparator BEFORE any final test episode.
Nonfinite/unstable rollouts are documented abstentions, not benchmark crashes.
This is conservative engineering, not a novel neural world model.
"""
from __future__ import annotations
import numpy as np
from physica.latent_experience.model import train as train_latent, forecast as forecast_latent


def _as_data(rows):
    if len(rows)<20: raise ValueError('not enough temporally ordered observations')
    y=np.asarray([[r['sensors'][name] for name in ('camera_m','audio_m_per_s','imu_accel')]
                  for r in rows],float)
    a=np.asarray([r['u'] for r in rows[:-1]],float)
    if not np.isfinite(y).all() or not np.isfinite(a).all():raise ValueError('nonfinite sensory records')
    return y,a


def train_arx(y, actions, ridge=.01):
    y=np.asarray(y,float); actions=np.asarray(actions,float)
    if y.ndim!=2 or len(y)<20 or actions.shape!=(len(y)-1,):raise ValueError('invalid ARX training input')
    mu=y[:-1].mean(0);scale=np.maximum(y[:-1].std(0),1e-5)
    normalized=(y-mu)/scale
    am=float(actions.mean());astd=max(float(actions.std()),1e-5)
    X=np.column_stack([normalized[:-1],(actions-am)/astd,np.ones(len(actions))])
    Y=normalized[1:]
    lam=np.eye(X.shape[1])*ridge;lam[-1,-1]=0
    weights=np.linalg.solve(X.T@X+lam,X.T@Y)
    if not np.isfinite(weights).all():raise ValueError('unstable ARX fit')
    return {'mean':mu.tolist(),'scale':scale.tolist(),'action_mean':am,'action_scale':astd,
            'weights':weights.tolist(),'algorithm':'calibrated sensor-space ARX ridge'}


def forecast_arx(model, initial, actions):
    mu=np.asarray(model['mean']);sd=np.asarray(model['scale']);w=np.asarray(model['weights'])
    y=np.asarray(initial,float);actions=np.asarray(actions,float)
    if y.shape!=mu.shape or actions.ndim!=1 or not np.isfinite(y).all() or not np.isfinite(actions).all():raise ValueError('invalid ARX forecast inputs')
    if len(actions)>2000:raise ValueError('forecast horizon exceeds safe limit')
    out=[]
    with np.errstate(all='raise'):
        try:
            for action in actions:
                normalized=(y-mu)/sd
                if np.max(np.abs(normalized))>2e4:raise ValueError('ARX left calibration envelope')
                y=(np.r_[normalized,(action-model['action_mean'])/model['action_scale'],1.]@w)*sd+mu
                if not np.isfinite(y).all() or np.max(np.abs(y))>1e6:raise ValueError('unstable ARX rollout')
                out.append(y.tolist())
        except FloatingPointError as e:raise ValueError('unstable ARX rollout') from e
    return out


def _assess(predictor,y,actions):
    try:
        predicted=np.asarray(predictor(y[0],actions),float)
        if predicted.shape!=y[1:].shape or not np.isfinite(predicted).all():raise ValueError('nonfinite prediction')
        # raw channel units are different; normalized fair sensor scoring
        scale=np.maximum(y[1:].std(axis=0),np.array([.001,.001,.02]))
        score=float(np.sqrt(np.mean(((predicted-y[1:])/scale)**2)))
        if not np.isfinite(score): raise ValueError('nonfinite error')
        return {'status':'SUCCESS','normalized_rmse':score}
    except (ValueError,OverflowError,FloatingPointError,np.linalg.LinAlgError) as e:
        return {'status':'ABSTAIN_UNSTABLE','normalized_rmse':None,'reason':str(e)[:160]}


def select(train_rows,validation_rows,*,max_horizon=140):
    ids={r['episode_id'] for r in train_rows}&{r['episode_id'] for r in validation_rows}
    if ids:raise ValueError('source and validation episodes overlap')
    train_y,train_a=_as_data(train_rows);val_y,val_a=_as_data(validation_rows)
    if len(val_a)>max_horizon:raise ValueError('validation horizon exceeds safe forecast limit')
    methods={}
    for ridge in (.001,.03,.3):
        try:
            model=train_arx(train_y,train_a,ridge)
            metrics=_assess(lambda i,a: forecast_arx(model,i,a),val_y,val_a)
            methods[f'arx_ridge_{ridge}']={**metrics,'model':model}
        except (ValueError,np.linalg.LinAlgError) as e:
            methods[f'arx_ridge_{ridge}']={'status':'ABSTAIN_UNSTABLE','normalized_rmse':None,'reason':str(e)[:160]}
    try:
        latent=train_latent(train_y,train_a,rank=min(2,train_y.shape[1]))
        metrics=_assess(lambda i,a: forecast_latent(latent,i,a),val_y,val_a)
        methods['learned_latent']={**metrics,'model':latent}
    except (ValueError,np.linalg.LinAlgError,OverflowError) as e:
        methods['learned_latent']={'status':'ABSTAIN_UNSTABLE','normalized_rmse':None,'reason':str(e)[:160]}
    persist=_assess(lambda i,a:np.repeat(np.asarray(i)[None,:],len(a),axis=0),val_y,val_a)
    methods['persistence']=persist
    eligible=[(name,detail['normalized_rmse']) for name,detail in methods.items() if detail['status']=='SUCCESS']
    if not eligible: return {'status':'ABSTAIN_NO_STABLE_MODEL','selected':None,'validation':methods,'test_seen':False}
    # Select on disjoint validation episode, then freeze choice for independent test.
    selected=min(eligible,key=lambda it:(it[1],it[0]))[0]
    return {'status':'MODEL_SELECTED_ON_DISJOINT_VALIDATION','selected':selected,'validation':methods,
            'test_seen':False,'not_proof_of_neural_superiority':True}


def predict(chosen,initial,actions):
    method=chosen.get('selected')
    if chosen.get('status')!='MODEL_SELECTED_ON_DISJOINT_VALIDATION' or method not in chosen['validation']:
        raise ValueError('no validated model')
    model=chosen['validation'][method].get('model')
    if method=='persistence':
        predicted=np.repeat(np.asarray(initial,float)[None,:],len(actions),axis=0).tolist()
    elif method=='learned_latent':
        predicted=forecast_latent(model,initial,actions)
    elif method.startswith('arx_ridge_'):
        predicted=forecast_arx(model,initial,actions)
    else:raise ValueError('unknown predictor')
    p=np.asarray(predicted,float)
    if p.ndim!=2 or len(p)!=len(actions) or not np.isfinite(p).all():raise ValueError('unstable selected prediction: abstain')
    return p.tolist()


def evaluate_test(chosen,rows):
    y,a=_as_data(rows)
    try:
        pred=np.asarray(predict(chosen,y[0],a),float)
        scale=np.maximum(y[1:].std(0),np.array([.001,.001,.02]))
        return {'status':'INDEPENDENT_TEST_EVALUATED','selected':chosen['selected'],
                'normalized_rmse':float(np.sqrt(np.mean(((pred-y[1:])/scale)**2))),
                'test_episode_ids':sorted({r['episode_id'] for r in rows})}
    except (ValueError,FloatingPointError,OverflowError) as e:
        return {'status':'ABSTAIN_UNSTABLE_TEST_ROLLOUT','selected':chosen.get('selected'),
                'reason':str(e)[:160], 'test_episode_ids':sorted({r['episode_id'] for r in rows})}
