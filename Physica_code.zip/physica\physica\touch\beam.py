"""Physics the Touch Transform can reason with: a clamped beam (finite elements), feeling where mass was lost, and
planning actions whose felt consequence is known before acting.

feel_mass_change: given the beam's felt modes before and after a change, find where along the beam a point mass
was added or removed, and how heavy it was relative to the beam. Uses only frequencies (a single sensor anywhere is
enough), Euler-Bernoulli beam elements, and a tip mass for the sensor itself.
"""
from __future__ import annotations

import numpy as np
from scipy.linalg import eigh
from scipy.optimize import least_squares


def cantilever_freqs(point_masses=(), n_el: int = 60, n: int = 3, tip_mass: float = 0.0) -> np.ndarray:
    """Dimensionless natural frequencies sqrt(lambda) of a uniform clamped beam (EI = rho*A = L = 1).
    point_masses: [(x in 0..1, mass as a fraction of the beam's mass)]."""
    le = 1.0 / n_el
    k = np.array([[12, 6 * le, -12, 6 * le], [6 * le, 4 * le ** 2, -6 * le, 2 * le ** 2],
                  [-12, -6 * le, 12, -6 * le], [6 * le, 2 * le ** 2, -6 * le, 4 * le ** 2]]) / le ** 3
    m = np.array([[156, 22 * le, 54, -13 * le], [22 * le, 4 * le ** 2, 13 * le, -3 * le ** 2],
                  [54, 13 * le, 156, -22 * le], [-13 * le, -3 * le ** 2, -22 * le, 4 * le ** 2]]) * le / 420
    N = 2 * (n_el + 1)
    K, M = np.zeros((N, N)), np.zeros((N, N))
    for e in range(n_el):
        i = 2 * e
        K[i:i + 4, i:i + 4] += k
        M[i:i + 4, i:i + 4] += m
    pms = list(point_masses) + ([(1.0, tip_mass)] if tip_mass else [])
    for x, mu in pms:  # consistent point mass via the element's shape functions
        e = min(int(x / le), n_el - 1)
        s = (x - e * le) / le
        Nf = np.array([1 - 3 * s ** 2 + 2 * s ** 3, le * (s - 2 * s ** 2 + s ** 3), 3 * s ** 2 - 2 * s ** 3, le * (-s ** 2 + s ** 3)])
        i = 2 * e
        M[i:i + 4, i:i + 4] += mu * np.outer(Nf, Nf)
    w2 = eigh(K[2:, 2:], M[2:, 2:], eigvals_only=True, subset_by_index=[0, n - 1])
    return np.sqrt(w2)


def mode_shapes(n_el: int = 60, n: int = 3, point_masses=(), tip_mass: float = 0.0, points: int = 101):
    """Transverse mode shapes along the beam (unit RMS), for drawing and for imagining touches."""
    le = 1.0 / n_el
    k = np.array([[12, 6 * le, -12, 6 * le], [6 * le, 4 * le ** 2, -6 * le, 2 * le ** 2],
                  [-12, -6 * le, 12, -6 * le], [6 * le, 2 * le ** 2, -6 * le, 4 * le ** 2]]) / le ** 3
    m = np.array([[156, 22 * le, 54, -13 * le], [22 * le, 4 * le ** 2, 13 * le, -3 * le ** 2],
                  [54, 13 * le, 156, -22 * le], [-13 * le, -3 * le ** 2, -22 * le, 4 * le ** 2]]) * le / 420
    N = 2 * (n_el + 1)
    K, M = np.zeros((N, N)), np.zeros((N, N))
    for e in range(n_el):
        i = 2 * e
        K[i:i + 4, i:i + 4] += k
        M[i:i + 4, i:i + 4] += m
    for x, mu in list(point_masses) + ([(1.0, tip_mass)] if tip_mass else []):
        e = min(int(x / le), n_el - 1)
        s = (x - e * le) / le
        Nf = np.array([1 - 3 * s ** 2 + 2 * s ** 3, le * (s - 2 * s ** 2 + s ** 3), 3 * s ** 2 - 2 * s ** 3, le * (-s ** 2 + s ** 3)])
        M[2 * e:2 * e + 4, 2 * e:2 * e + 4] += mu * np.outer(Nf, Nf)
    w2, V = eigh(K[2:, 2:], M[2:, 2:], subset_by_index=[0, n - 1])
    w = np.vstack([np.zeros((1, n)), V[0::2]])  # node displacements, clamp = 0
    xs = np.linspace(0, 1, n_el + 1)
    xi = np.linspace(0, 1, points)
    S = np.stack([np.interp(xi, xs, w[:, j]) for j in range(n)])
    S = S / np.sqrt((S ** 2).mean(1, keepdims=True))
    S = S * np.sign(S[:, -1:])
    return xi, S, np.sqrt(w2)


def fit_body(freqs_hz, n_el: int = 60) -> dict:
    """The beam's scale (Hz per dimensionless unit) and the sensor's tip mass, from its own felt frequencies.
    Tip mass by a 1-D search (0 to 50% of the beam) with the scale solved exactly at each step, so a uniform beam
    gets exactly zero instead of whatever an optimizer stalls at."""
    f = np.asarray(freqs_hz, float)
    best = None
    for mu in np.concatenate([[0.0], np.geomspace(1e-4, 0.5, 120)]):
        lam = cantilever_freqs(n_el=n_el, n=len(f), tip_mass=mu)
        logc = float(np.mean(np.log(f) - np.log(lam)))
        r = np.log(f) - np.log(lam) - logc
        err = float(r @ r)
        if best is None or err < best[0] - 1e-12:
            best = (err, mu, logc, r)
    return {"hz_per_unit": float(np.exp(best[2])), "tip_mass": float(best[1]),
            "residual_pct": [float(100 * (np.exp(-v) - 1)) for v in best[3]]}


def feel_mass_change(before_hz, after_hz, n_el: int = 60, rel_sd: float | None = None) -> dict:
    """Where on the beam did mass change, and how much? 'after' is the plain beam; 'before' carried the mass.
    Grid over position x and mass mu; likelihood from log-frequency errors with sd rel_sd. If rel_sd is None it
    is set from how well the best fit actually explains the frequencies (at least 1%), so the range is honest
    about the model's own error."""
    body = fit_body(after_hz, n_el)
    c, mu_tip = body["hz_per_unit"], body["tip_mass"]
    fb = np.asarray(before_hz, float)
    xs = np.linspace(0.02, 1.0, 99)
    mus = np.exp(np.linspace(np.log(0.01), np.log(10), 120))
    L = np.full((len(xs), len(mus)), np.inf)
    for i, x in enumerate(xs):
        for j, mu in enumerate(mus):
            pred = c * cantilever_freqs([(x, mu)], n_el=n_el, n=len(fb), tip_mass=mu_tip)
            L[i, j] = float(((np.log(pred) - np.log(fb)) ** 2).sum())
    i, j = np.unravel_index(np.argmin(L), L.shape)
    if rel_sd is None:
        rel_sd = max(float(np.sqrt(L.min() / max(len(fb) - 2, 1))), 0.01)
    post = np.exp(-(L - L.min()) / (2 * rel_sd ** 2))
    px = post.sum(1) / post.sum()
    cdf = np.cumsum(px)
    lo, hi = xs[np.searchsorted(cdf, 0.05)], xs[min(np.searchsorted(cdf, 0.95), len(xs) - 1)]
    best_pred = c * cantilever_freqs([(xs[i], mus[j])], n_el=n_el, n=len(fb), tip_mass=mu_tip)
    return {"position": float(xs[i]), "position_90": [float(lo), float(hi)], "mass_fraction": float(mus[j]), "rel_sd": rel_sd,
            "fit_error_pct": [float(100 * (p / f - 1)) for p, f in zip(best_pred, fb)], "body": body,
            "position_posterior": {"x": xs.tolist(), "p": px.tolist()}}
