"""Calibrated multisensory belief and physical prediction-error signal.

This is a modest physical *sensation* interface, NOT human-like consciousness.
Any imputed/virtual sensor is explicitly marked inferred, never observed.
Independent groups are mandatory for trusted redundant fusion.
"""
from __future__ import annotations
from dataclasses import dataclass
import math

UNITS={'position':'m','velocity':'m/s','acceleration':'m/s^2','temperature':'K',
       'current':'A','magnetic_field':'T','pressure':'Pa','frequency':'Hz'}

@dataclass(frozen=True)
class SensorReading:
    quantity:str
    value:float
    sigma:float
    unit:str
    origin:str
    calibration_sha256:str
    independent_group:str
    measured:bool=True

    def validate(self)->None:
        if self.quantity not in UNITS or self.unit!=UNITS[self.quantity]:
            raise ValueError('Unsupported physical dimension or incorrect SI units')
        if not math.isfinite(self.value) or not math.isfinite(self.sigma) or self.sigma<=0:
            raise ValueError('Invalid calibration variance or measurement')
        if not self.origin or not self.independent_group or len(self.calibration_sha256)!=64 or any(
            x not in '0123456789abcdef' for x in self.calibration_sha256.lower()):
            raise ValueError('Missing independent calibration provenance')


def fuse_measurements(readings:list[SensorReading],*,max_inconsistency_z:float=4.)->dict:
    if not readings:raise ValueError('No actual measurements provided')
    for r in readings:r.validate()
    if any(not r.measured for r in readings):
        raise ValueError('Virtual or inferred channels cannot be treated as measured evidence')
    quantities={r.quantity for r in readings}
    if len(quantities)!=1:raise ValueError('Do not fuse unrelated physical quantities')
    groups=[r.independent_group for r in readings]
    if len(groups)!=len(set(groups)):
        raise ValueError('Correlated readings must not be treated as independent sensors')
    precision=[1/r.sigma**2 for r in readings]
    mean=sum(p*r.value for p,r in zip(precision,readings))/sum(precision)
    sigma=math.sqrt(1/sum(precision))
    chi2=sum(((r.value-mean)/r.sigma)**2 for r in readings)
    # Conservative check with unadjusted degree-of-freedom scaling; a flag is not a diagnosis.
    inconsistent=len(readings)>1 and chi2>(len(readings)-1)*max_inconsistency_z**2
    return {'quantity':readings[0].quantity,'value':mean,'unit':readings[0].unit,
            'sigma':sigma,'sensor_count':len(readings),'inconsistent':inconsistent,
            'status':'DISAGREEMENT_ABSTAIN' if inconsistent else 'CALIBRATED_MEASUREMENTS_FUSED',
            'chi2':chi2,'calibration_sources':[r.calibration_sha256 for r in readings]}


def physical_surprise(predicted:dict, observed:dict, *,sigma_model:float)->dict:
    """Standardized prospective sensory prediction error (not a causal explanation)."""
    if predicted['quantity']!=observed['quantity'] or predicted['unit']!=observed['unit']:
        raise ValueError('Predicted and observed senses have incompatible physical units')
    if observed.get('status')!='CALIBRATED_MEASUREMENTS_FUSED':
        return {'status':'ABSTAIN_UNTRUSTED_SENSES','mechanism_discovered':False}
    if not math.isfinite(sigma_model) or sigma_model<0:
        raise ValueError('Invalid model uncertainty')
    z=(float(observed['value'])-float(predicted['value']))/math.sqrt(
        observed['sigma']**2+sigma_model**2)
    return {'status':'UNEXPLAINED_SENSORY_SURPRISE' if abs(z)>3 else 'CONSISTENT_WITH_PREDICTION',
            'signed_innovation':float(observed['value'])-float(predicted['value']),
            'standardized_surprise_z':z,'mechanism_discovered':False,
            'next_step':'Investigate rival mechanisms or recalibrate sensors' if abs(z)>3 else 'Continue monitoring'}
