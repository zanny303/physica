"""Is Muse needed? Is SAM? Is Physica? The same films, with one thing removed at a time, on machines Physica was never tuned on.

The boxes and reference tones come from a person, before any run. The protocol and the win rules are sealed before the first call, and a
failed or empty reply counts as a miss. Six machines can only show large effects, so the table gives counts and no p-values.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from physica import config, seal as _seal
from physica.llm import meta_client as mc
from physica.meta import scout as S

RESULTS = config.REPO_ROOT / "eval" / "results"
OUT = RESULTS / "E33_scout_test.json"
TONE_WITHIN = 0.03
PART_OVERLAP = 0.5
RULES = [
    {"claim": "Muse replaces the specialist", "must_hold": "the full system types 0 words and is within 1 machine of a person typing a noun, on tone", "otherwise": "A typed word did as well. Muse did not add accuracy here."},
    {"claim": "Seeing matters", "must_hold": "the full system beats the wrong-film placebo on the right part by at least 2 machines", "otherwise": "Muse's video did not help."},
    {"claim": "Physica is needed", "must_hold": "Muse alone has a median tone error at least 5 times the full system's", "otherwise": "Muse read the tone unaided."},
    {"claim": "SAM is needed", "must_hold": "the full system beats Physica on the whole frame on tone by at least 2 machines", "otherwise": "On these clips, the crop did not matter."}]
ARMS = {"A": "Physica, whole frame", "B": "Physica, most moving region", "C": "A person types a noun, then SAM, then Physica", "D": "Muse, SAM and Physica, nothing typed",
        "E": "Muse alone", "F": "Muse given another machine's film (placebo)"}


def protocol(manifest: dict) -> dict:
    rows = {k: {f: v[f] for f in ("part", "box", "reference_hz", "reference_how", "fps")} for k, v in manifest["films"].items()}
    return {"arms": ARMS, "rules": RULES, "tone_within": TONE_WITHIN, "part_overlap": PART_OVERLAP, "films": rows}


def tone_score(hz, reference: float) -> dict:
    if hz is None:
        return {"tone_hz": None, "error_pct": None, "tone_right": False}
    e = abs(float(hz) - reference) / reference
    return {"tone_hz": round(float(hz), 2), "error_pct": round(100 * e, 1), "tone_right": bool(e <= TONE_WITHIN)}


def moving_region(V: np.ndarray) -> tuple[int, int, int, int] | None:
    """The plain code alternative to SAM: the largest patch of pixels that change the most."""
    import cv2
    e = np.diff(V, axis=0).std(0)
    b = (e > np.quantile(e, 0.9)).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(cv2.dilate(b, np.ones((3, 3), np.uint8)))
    if n <= 1:
        return None
    i = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    x, y, w, h, _ = stats[i]
    return int(x), int(y), int(x + w), int(y + h)


def _in_box(point_grid, info: dict, box) -> bool:
    x, y = point_grid[0] / 1000 * info["w"], point_grid[1] / 1000 * info["h"]
    return bool(box[0] <= x <= box[2] and box[1] <= y <= box[3])


def _best(rows: list[dict], reference: float) -> dict | None:
    """A system gives one answer: its clearest tone. It doesn't get to pick the one closest to the reference."""
    felt = [r for r in rows if r.get("felt")]
    return max(felt, key=lambda r: r["snr"]) if felt else None


def run_film(key: str, m: dict, folder: Path, other: str | None, arms: str = "ABCDEF", on_step=print) -> dict:
    film, box, ref, fps = folder / key, tuple(m["box"]), float(m["reference_hz"]), float(m["fps"])
    info = S.film_info(film)
    row: dict[str, dict] = {}
    if "A" in arms:
        V, _ = S.load_region(film, None, long_side=256)
        row["A"] = {**tone_score(S.read_tone(V, fps).get("tone_hz"), ref), "typed_words": 0, "right_part": None, "usd": 0}
    if "B" in arms:
        V, k = S.load_region(film, None, long_side=256)
        reg = moving_region(V)
        if reg:
            fb = tuple(int(v / k) for v in reg)
            Vb, _ = S.load_region(film, fb)
            right = _overlap_box(fb, box)
            row["B"] = {**tone_score(S.read_tone(Vb, fps).get("tone_hz"), ref), "typed_words": 0, "right_part": right >= PART_OVERLAP, "overlap": right, "usd": 0}
        else:
            row["B"] = {**tone_score(None, ref), "typed_words": 0, "right_part": False, "usd": 0}
    work = folder / "scout_work"
    if "C" in arms:
        try:
            F = S.Film(film, fps, work)
            F.pin_noun(m["part"])
            got = F.feel(m["part"])
            ov = F.mask_overlap(m["part"], box)
            row["C"] = {**tone_score(got.get("tone_hz") if got.get("felt") else None, ref), "typed_words": len(m["part"].split()), "right_part": ov >= PART_OVERLAP, "overlap": ov, "usd": F.usd}
        except Exception as e:
            row["C"] = {**tone_score(None, ref), "typed_words": len(m["part"].split()), "right_part": False, "failed": str(e)[:200], "usd": 0}
    if "D" in arms:
        try:
            r = S.scout(film, fps, work, on_step=on_step)
            best = _best(r["parts"], ref)
            F = None
            hit = next((p for p in r["parts"] if _in_box(p["grid_point"], info, box)), None)
            row["D"] = {**tone_score(best["tone_hz"] if best else None, ref), "typed_words": 0, "right_part": bool(hit), "chose": best["part"] if best else None, "named": [p["part"] for p in r["parts"]], "usd": r["usd"], "said": r["seen"][:300]}
        except Exception as e:
            row["D"] = {**tone_score(None, ref), "typed_words": 0, "right_part": False, "failed": str(e)[:200], "usd": 0}
    if "E" in arms:
        try:
            with __import__("tempfile").TemporaryDirectory() as d:
                part = mc.video_part(S.muse_clip(film, Path(d) / "watch.mp4"))
            r = mc.respond(S.SPARK, [{"role": "user", "content": [{"type": "input_text", "text": S.ASK_TONE.format(part=m["part"])}, part]}], "physica_scout_muse_alone", media_usd=0.10, effort="medium")
            hz = S.parse_json(r["content"]).get("hz")
            row["E"] = {**tone_score(hz, ref), "typed_words": len(m["part"].split()), "right_part": None, "usd": r["usd"]}
        except Exception as e:
            row["E"] = {**tone_score(None, ref), "typed_words": 0, "right_part": None, "failed": str(e)[:200], "usd": 0}
    if "F" in arms and other:
        try:
            seen = S.watch(folder / other, S.SPARK, task="physica_scout_placebo")
            names = [p["name"] for p in seen["parts"]]
            grid = S.point(S.still(folder / other)[0], names, task="physica_scout_placebo_point") if names else {}
            row["F"] = {"typed_words": 0, "right_part": any(_in_box(g, info, box) for g in grid.values()), "usd": seen["usd"], "tone_hz": None, "tone_right": False}
        except Exception as e:
            row["F"] = {"typed_words": 0, "right_part": False, "failed": str(e)[:200], "usd": 0, "tone_hz": None, "tone_right": False}
    return row


def _overlap_box(a, b) -> float:
    ix, iy = max(0, min(a[2], b[2]) - max(a[0], b[0])), max(0, min(a[3], b[3]) - max(a[1], b[1]))
    area = max((a[2] - a[0]) * (a[3] - a[1]), 1)
    return round(ix * iy / area, 3)


def summary(res: dict) -> dict:
    films = res["films"]
    out = {}
    for arm in ARMS:
        rows = [v[arm] for v in films.values() if arm in v]
        if not rows:
            continue
        errs = [r["error_pct"] for r in rows if r.get("error_pct") is not None]
        parts = [r.get("right_part") for r in rows if r.get("right_part") is not None]
        out[arm] = {"name": ARMS[arm], "machines": len(rows), "tone_right": sum(1 for r in rows if r.get("tone_right")), "right_part": sum(parts) if parts else None, "parts_scored": len(parts),
                    "median_error_pct": round(float(np.median(errs)), 1) if errs else None, "answered": len(errs), "typed_words": sum(r.get("typed_words", 0) for r in rows),
                    "usd": round(sum(r.get("usd", 0) for r in rows), 3), "failed": sum(1 for r in rows if r.get("failed"))}
    return out


def verdicts(s: dict) -> list[dict]:
    g = lambda arm, k, d=0: (s.get(arm) or {}).get(k) if (s.get(arm) or {}).get(k) is not None else d  # noqa: E731
    checks = [("D" in s and "C" in s and g("D", "typed_words") == 0 and g("D", "tone_right") >= g("C", "tone_right") - 1),
              ("D" in s and "F" in s and g("D", "right_part") - g("F", "right_part") >= 2),
              ("D" in s and "E" in s and g("D", "median_error_pct", None) is not None and (g("E", "answered") == 0 or (g("E", "median_error_pct", 0) >= 5 * max(g("D", "median_error_pct"), 0.1)))),
              ("D" in s and "A" in s and g("D", "tone_right") - g("A", "tone_right") >= 2)]
    return [{**r, "held": bool(c), "say": "Held." if c else r["otherwise"]} for r, c in zip(RULES, checks)]


def run(folder: str | Path, manifest: dict, on_step=print, out: Path = OUT, arms: str = "ABCDEF") -> dict:
    folder = Path(folder)
    keys = sorted(manifest["films"])
    if out.exists():
        raise SystemExit(f"{out.name} already holds a run. A first run stays frozen. Move it aside only if you mean to run a labelled second one.")
    sealed = _seal.seal(protocol(manifest), "the test and how it will be scored, before any model call")
    res = {"label": "LIVE META MODEL API. Machines Physica was never tuned on.", "protocol_sealed": sealed, "films": {}, "note": "Few machines, one operator. Only large effects can show."}
    out.parent.mkdir(parents=True, exist_ok=True)
    for i, k in enumerate(keys):
        on_step(f"\n{k}: {manifest['films'][k]['part']}")
        res["films"][k] = run_film(k, manifest["films"][k], folder, keys[(i + 1) % len(keys)] if len(keys) > 1 else None, arms, on_step)
        out.write_text(json.dumps(res, indent=1, default=float))      # kept after each machine, so a stop loses nothing
    res["summary"] = summary(res)
    res["verdicts"] = verdicts(res["summary"])
    out.write_text(json.dumps(res, indent=1, default=float))
    return res


def show(res: dict) -> str:
    s = res.get("summary") or summary(res)
    v = res.get("verdicts") or verdicts(s)
    lines = [f"{'':<46}{'tone right':>11}{'right part':>11}{'median err':>11}{'words typed':>12}{'cost':>8}"]
    for arm, r in s.items():
        part = f"{r['right_part']}/{r['parts_scored']}" if r["right_part"] is not None else "-"
        err = f"{r['median_error_pct']}%" if r["median_error_pct"] is not None else "-"
        lines.append(f"{arm + '. ' + r['name']:<46}{str(r['tone_right']) + '/' + str(r['machines']):>11}{part:>11}{err:>11}{r['typed_words']:>12}{'$' + str(r['usd']):>8}")
    lines.append("")
    lines += [f"{'HELD  ' if x['held'] else 'FAILED'} {x['claim']}: {x['must_hold']}." + ("" if x["held"] else f" Say: {x['otherwise']}") for x in v]
    lines.append(res.get("note", ""))
    return "\n".join(lines)
