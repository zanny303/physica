# Physica v0.25 — From a missing mechanism to a prospective target-machine test

## Scientific claim the code is designed to test

> A **live, authenticated Muse hypothesis** proposes a functional relationship absent from Physica's predeclared source-blind symbolic library. **Source-machine experiments** fit its numeric constants and independently validate it. Physica selects a **review-only target-machine probe** using the disagreement between competing models, checks the resulting calibrated recording against the precommitted probe controls, and uses that evidence to **freeze four target-machine predictions** before a separately collected target test is available. A held-out test then compares **all** methods.

**This is a test protocol and a working synthetic reference implementation, not evidence that the full claim has been established on hardware.** As packaged, authenticated Muse inference and independent real physical machine A/B measurements have **not** occurred.

## How this is stronger than v0.24

1. Predeclared source-blind symbolic equation search remains a **real comparator**; only an additional bounded candidate can be supplied by Muse.
2. New numeric coefficients are fitted from **source training readings**, not accepted because the model described them. The synthetic fixture intentionally supplies approximate, incorrect coefficients.
3. The proposal must improve **separate source validation episodes**, without degrading individual validation episodes beyond tolerance.
4. The target probe is selected from a bounded set via **predicted disagreement and an extrapolation penalty**. This is a *heuristic active-experiment candidate*, not a proven optimal Bayesian information-gain policy.
5. The target machine's parameters are different; only the source's proposed **structural feature** transfers. Target coefficients are refitted from **the same local data budget used by the baselines**.
6. Actual probe measurements must match **initial conditions, control signal, timestamp and machine identity** before entering target training.
7. Four baselines/methods produce full prospective future trajectories: **target-only generic**, **target-only neural**, **source-blind structural transfer**, and **proposed source structural transfer**. All are frozen before the target test.
8. The later `reveal` stage rejects mutated commitments, reused files, wrong actuator schedules, time mismatches, and starting-state mismatches; it reports all outcomes, including failures.

The source-only negative control is designed to refuse a hypothesis that does not improve validation. **The code does not prove general scientific novelty merely by rejecting an equation from the original fixed library.** Other symbolic-regression algorithms may find it.

## What is actually verified offline

Run from the extracted `physica` root:

```powershell
python -m pip install -e ".[dev]"
python -m physica.frontier.discovery_milestone_v025 synthetic-demo --seed 7 --out demo/v025_demo
python -m physica.frontier.discovery_milestone_v025 synthetic-benchmark --seeds 12 --out demo/v025_benchmark
python -m pytest tests/test_discovery_milestone_v025.py -q
python -m physica.studio --open-browser
```

The synthetic demo is **NOT a real Muse test**. It deliberately uses `HUMAN_AUTHORED_HYPOTHESIS_NOT_META.json`: a human-authored hypothesis with a functional family known to the simulator **but rough, inaccurate numeric constants**. Source measurements tune those constants. The simulator's true hidden law is never passed directly to fitting or to probe selection, and target test data are only constructed after the forecast commit. This validates software boundaries, not scientific discovery or an independently witnessed chronology.

Studio includes a v0.25 task in **MACE Investigation**. This is explicitly **simulation-only** and does not invoke the paid API or actuate hardware.

## 1. Real source machine A: prepare measurement evidence

The real source manifest is an ordinary `field_discovery.py` manifest. Create a folder containing:

- `calibration.json`: declared instrument, operator, date, SI units and **independently measured** mechanical baseline (stiffness [s^-2], damping [s^-1], control gain, all in supported range).
- At least **two distinct `train_*.csv`** episodes and **one distinct `val_*.csv`** episode. CSV header exactly: `x_m,v_m_s,u_m_s2,acc_m_s2` (or the same with `time_s` first). Distinct recordings, no duplicate hash, calibrated readings from physical controlled actions.
- `manifest.json`: `fixture_id`, relative `calibration_file`, and `episodes: {train:[...],validation:[...]}`.

You should verify acceleration is truly measured or derived using a documented method and is **not just a numerical derivative of the model being evaluated**. Do not make uncalibrated smartphone pixels into metres or unmeasured force into newtons.

## 2. Authenticate a Muse hypothesis (on your own machine)

Set the private key **only in your environment**, never in uploads or ZIP files:

```powershell
$env:MODEL_API_KEY = "<your-private-key>"
$env:MOCK = "0"
python -m physica.frontier.discovery_milestone_v025 source `
  --manifest real/source_A/manifest.json `
  --live-meta --allow-billed-meta `
  --out real/source_discovery.json
```

The code calls the project's existing Meta Model API client via `live_nominate()` with constrained JSON output. It requires explicit billing approval; the client maintains request receipts and locally reserved estimated budget. A receipt from this client is *client-reported*, not independent cryptographic proof of an API provider. Meta can be wrong, decline, or propose a family already in the standard library. If validation fails, the source receipt marks the proposal **not authorized for transfer**.

For source-blind and negative control, omit `--live-meta` and the proposal. For a controlled supplied-hypothesis test, use `--proposal path.json`; its provenance is **USER_SUPPLIED_OFFLINE_HYPOTHESIS_NOT_META** regardless of its text.

The bounded AST uses measured `x`, `v`, `u` only, restricted ops (`sin`, `cos`, `tanh`, `add`, `mul`, etc.) and no executable model-generated Python. Up to three numeric constants are tuned by Physica with source training only. *It cannot discover latent variables that were not measured.*

See Meta's current docs for `muse-wonder-1.0`, structured outputs, and the Model API at https://dev.meta.ai/docs/overview and https://dev.meta.ai/docs/cookbook/structured-output .

## 3. Real target machine B: choose and measure a discriminating probe

Machine B must be a distinct physical instrumented system with the **same declared SI channels** and its own independently calibrated baseline. First collect two or more target training episodes and at least one target validation episode **without using the test outcome**.

```powershell
python -m physica.frontier.discovery_milestone_v025 design `
  --source real/source_discovery.json `
  --target-manifest real/target_B/manifest.json `
  --out real/probe_commit.json
```

The `probe_commit.json` includes `probe_plan` with `fixture_id`, `dt_s`, starting displacement/velocity, and 95 planned controls. **This is a review-only candidate: an approved, trained researcher must judge physical risk and feasibility before performing it. The code never actuates hardware.** Record the actual probe as CSV with header `time_s,x_m,v_m_s,u_m_s2,acc_m_s2`; do not generate or backfill readings from the model. Append the new probe file to the target manifest's **train** list after recording, leaving the separate validation episodes unchanged.

Probe efficacy versus random must be independently measured across multiple systems. This release does **not** establish that it is better than random.

## 4. Freeze target B's future-action prediction

Prepare a **future** JSON plan with exact keys `fixture_id`, `dt_s`, `x0_m`, `v0_m_s`, `controls_m_s2` (18–1500 finite bounded controls). This describes the intended experiment **without its results**.

```powershell
python -m physica.frontier.discovery_milestone_v025 commit `
  --source real/source_discovery.json `
  --target-manifest real/target_B/manifest.json `
  --probe real/probe_commit.json `
  --probe-recording real/target_B/probe_after_selection.csv `
  --plan real/future_B_plan.json `
  --out real/sealed_target_forecasts.json
```

Commit reports validation selection and freezes *all four methods*, including the ones not selected. **Do not perform or inspect the target future experiment until after the prediction receipt has been committed**. For rigorous external verification, publish or independently timestamp the hash/receipt before running it. A local SHA-256 only proves content integrity against unsanctioned changes and does not provide an independent timeline.

## 5. Reveal independently recorded physical outcome

```powershell
python -m physica.frontier.discovery_milestone_v025 reveal `
  --commit real/sealed_target_forecasts.json `
  --observations real/target_B/future_test_recorded_after_commit.csv `
  --out real/target_reveal.json
```

The reveal step compares independent measured position, velocity and acceleration across all frozen models. The result is a **user-supplied experiment** until external provenance and timing are checked by a reviewer. The code checks identities, controls and sample timestamps but cannot physically authenticate an experiment or distinguish an otherwise plausible fake recording.

## Minimum evidence for a serious scientific claim

- An authenticated Meta response with full receipt and a hypothesis **not present in the predeclared source-blind search library**; register all hypotheses, including incorrect and abstained ones.
- A physically distinct receiving system B under an identical local target-probe budget for all candidate methods.
- Independent A and B sensor calibration and a documented applied-control trace, plus externally witnessed chronology of the forecast commitment.
- Mechanism held-out predictions on multiple prospective interventions, including changed operating conditions, rather than merely fitting one dataset.
- Meta-on versus Meta-off ablations across many tasks and model-call budgets. Compare source-blind neural/symbolic models, a stronger full equation search, transfer baselines, and random versus active probe selection.
- Report *all* failed proposals, negative transfer, uncertainty calibration, whether the identified mechanism is identifiable, and any model refusals.

## What this release does NOT do

- It cannot access your Meta API key or run billable Meta calls on your behalf in the offline build environment.
- It cannot generate or validate actual laboratory measurements without access to physical instruments and externally witnessed sensor data.
- It does not prove arbitrary open-world discovery, five senses, autonomous machine control, or subjective physical feeling.
- The simulation was designed to be expressible by the human-supplied proposed family. A strong result there is **not** evidence that Muse can invent that family or that it improves on unconstrained symbolic regression.

## Research context and baselines

Scientific precedents include sparse nonlinear system identification (SINDy / PySINDy), neural residual dynamics, active learning / Bayesian optimal experimental design, neural-guided symbolic regression, and scientific LLM agents. Physica's potentially distinctive claim is the **validated integration of model proposals, deliberate sensory experiments, prospective prediction and cross-system reuse**. Novelty and superiority must be established through comparisons, not inferred from architecture or its name.
