"""Headline numbers for the app, read straight from eval/results (the app never types a number by hand)."""
from __future__ import annotations

import json

import numpy as np

from physica import config


def _r(name):
    p = config.RESULTS_DIR / f"{name}.json"
    return json.loads(p.read_text()) if p.exists() else None


def _pct(x):
    return None if x is None else round(100 * float(x), 1)


def build() -> dict:
    ev = {"source": "eval/results/*.json (real PADRE flights unless marked)"}
    e1 = _r("E1_feel_without_damage")
    if e1:
        m = e1["methods"]
        p, s, rf = m["physica_selfmodel_no_damage_data"], m["spectrogram_threshold_no_selfmodel"], m["random_forest_trained_on_rotorA_damage"]
        ev["feel"] = {"detect_pct": _pct(p["detect_rate_BCD"]), "detect_ci": [_pct(v) for v in p["detect_ci95_cluster_by_flight"]],
                      "false_alarms": f"{round(p['false_alarm_rate_heldout_healthy'] * p['n_heldout_healthy_windows'])}/{p['n_heldout_healthy_windows']}",
                      "false_alarm_ci": [_pct(v) for v in p["false_alarm_ci95_exact"]],
                      "baseline_spectrogram_pct": _pct(s["detect_rate_BCD"]),
                      "baseline_rf_pct": _pct(rf["detect_rate_BCD"]),
                      "baseline_rf_false_alarms": f"{round(rf['false_alarm_rate_heldout_healthy'] * rf['n_heldout_healthy_windows'])}/{rf['n_heldout_healthy_windows']}",
                      "per_flight": p["per_file"]}
    e8 = _r("E8_localization_limit")
    if e8:
        ev["cant_tell"] = {"passive_localisation_pct": _pct(e8["localization_accuracy_on_felt_windows"]),
                           "ci": [_pct(v) for v in e8["localization_ci95_exact"]], "chance_pct": _pct(e8["chance_level"]),
                           "refusals": f"{e8['verdicts_that_refused_to_name_a_rotor']}/{e8['files_felt']}",
                           "why": e8["why"], "experiment": e8["experiment_requested"]}
    d = _r("discover_padre")
    if d:
        ev["discover"] = d
    e6 = _r("E6_translators")
    if e6:
        a = e6["ardupilot"]
        ev["act"] = {"flights": a["n"], "median_in_band_db": round(a["median_in_band_reduction_db"], 1),
                     "median_out_of_band_db": round(a["median_out_of_band_change_db"], 1),
                     "promises_kept": a.get("promises_kept"), "wrong_rolled_back": a.get("wrong_notches_rolled_back"),
                     "promise": a.get("promise"), "plc_source": e6["plc"]["source"], "marlin_valid": e6["marlin_klipper"]["all_valid"]}
    e4 = _r("E4_compounding")
    if e4:
        ev["compounding"] = {t: {"cold_s": v["cold"]["seconds_to_5pct_false_alarm"],
                                 "library_s": v["library"]["seconds_to_5pct_false_alarm"],
                                 "fixed_truth_s": v["fixed_truth"]["seconds_to_5pct_false_alarm"]}
                             for t, v in e4["targets"].items()}
    e7 = _r("E7_arrival_check")
    if e7:
        mat = e7["matrix"]
        same = [k for k in mat if k[0] == k[-1]]
        diff = [k for k in mat if k[0] != k[-1]]
        dmg = e7["damaged_flight_verdicts"]
        rel = e7["after_relearn"]
        ev["arrival"] = {"same_arm_fits": f"{sum(mat[k]['verdict'] == 'fits' for k in same)}/{len(same)}",
                         "different_arm_rejected": f"{sum(mat[k]['verdict'] != 'fits' for k in diff)}/{len(diff)}",
                         "damaged_rejected": f"{sum(v != 'fits' for v in dmg.values())}/{len(dmg)}",
                         "relearned_fits": f"{sum(v['verdict_after_relearn_on_heldout'] == 'fits' for v in rel.values())}/{len(rel)}"}
    e9 = _r("E9_skill_transfer")
    if e9:
        sk = {}
        for k in ("hz_band", "order_broad", "order_narrow", "spectrogram"):
            v = e9["skills"][k]
            sk[k] = {m: {"detect_pct": _pct(v[m]["detect"]), "false_alarms": v[m]["false_alarms"],
                         "flights": v[m]["flights_caught_majority"]} for m in ("bebop", "solo")}
        w = e9["skills"]["order_broad"]["solo"].get("where_felt_orders_median", {})
        ev["skills"] = {"table": sk, "copy_numbers": e9["copy_numbers"],
                        "solo_where_order": round(float(np.median(list(w.values()))), 2) if w else None,
                        "solo_where_range": [min(w.values()), max(w.values())] if w else None}
    e11 = _r("E11_body_map")
    if e11:
        ev["body_map"] = {m: {"acc_pct": _pct(v["body_map_acc"]), "ci": [_pct(x) for x in v["body_map_ci95_exact"]],
                              "loudest_pct": _pct(v["loudest_arm_acc"]), "flights": v["flights_majority_correct"],
                              "agree_pct": _pct(v["cues_agree"]), "acc_agree_pct": _pct(v["acc_when_cues_agree"]),
                              "named_pct": _pct(v["named_one_rotor"]), "acc_named_pct": _pct(v["acc_when_named"])}
                          for m, v in e11.items()}
    e10 = _r("E10_robot_touch")
    ev["robot"] = {"status": "pending: run eval/e10_robot_touch.py with the voraus-AD robot data" if e10 is None
                   else "done", "result": e10}
    for n, key in (("E2_wobble_units", "wobble"), ("E3_imagine", "imagine")):
        r = _r(n)
        ev[key] = {"status": "pending: run on the Fraunhofer shaft data" if r is None else "done", "result": r}
    e5 = _r("E5_sense_evolution")
    ev["sense_evolution"] = {"status": "pending: needs a live Muse Spark run" if e5 is None else "done", "result": e5}
    return ev
