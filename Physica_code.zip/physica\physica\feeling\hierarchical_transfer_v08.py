"""Conservative source-prior + target-probe adaptation for *known* mechanisms.

No novel dynamics discovery. Cross-machine parameter heterogeneity is a declared
hyperparameter and must be calibrated on TRAINING bodies, not tuned on target test
outcomes. Conditional Gaussian assumptions are unverified on real equipment.
"""
from __future__ import annotations
import math
import numpy as np
from .core import Body
from .mechanism_transfer import feature


def combine_source_and_probe(source, target:Body, probe, reference, *, certificate,
                             between_machine_sigma=.02,
                             force_measurement_sigma=None, max_disagreement_z=2.5):
    if source.get('status')!='CANDIDATE_SIGNED_REQUIRES_TARGET_PROBE':
        raise ValueError('source lesson not supported')
    from .prospective_v08 import _valid_source
    if not _valid_source(source):
        raise ValueError('tampered source lesson')
    p=source['record']['payload']
    if p['source_body']['boundary_class']!=target.boundary_class or p['source_body']['mechanism_family']!=target.mechanism_family:
        raise ValueError('incompatible physical families')
    # Noise is part of the signed raw-probe certificate: never let a caller
    # silently substitute a more optimistic noise model after measurement.
    certified_noise = float(certificate['payload']['measurement_noise_force_n'])
    if force_measurement_sigma is None:
        force_measurement_sigma = certified_noise
    if not math.isclose(float(force_measurement_sigma), certified_noise, rel_tol=1e-12, abs_tol=0):
        raise ValueError('probe noise differs from signed calibration')
    if not all(math.isfinite(float(x)) and x>0 for x in (reference,between_machine_sigma,force_measurement_sigma,max_disagreement_z)):
        raise ValueError('invalid declared cross-body variation or force noise')
    source_beta=float(p['dimensionless_coefficient'])
    source_se=float(p['coefficient_sigma_model_conditional'])
    if not all(math.isfinite(x) for x in (source_beta,source_se)) or source_se<0:
        raise ValueError('invalid source uncertainty')
    from .mechanism_transfer import _load, _recheck_probe
    if not _recheck_probe(source,target,certificate,reference):
        raise ValueError('unsigned, mismatched, or failed target probe')
    if certificate['payload']['measured_episode'] != {k:probe[k] for k in ('intervention_id','displacement_m','velocity_m_s','acceleration_m_s2','force_n')}:
        raise ValueError('probe data differs from signed certificate')
    x,v,a,f=_load(probe,target)
    basis=feature(target,x,v,p['mechanism'],reference)
    norm=float(basis@basis)
    if norm<=1e-20:raise ValueError('probe not sensitive to mechanism')
    local_beta=float(basis@(f-target.mass_kg*a-target.damping_n_s_m*v-target.stiffness_n_m*x)/norm)
    local_var=float(force_measurement_sigma**2/norm)
    source_var=float(source_se**2+between_machine_sigma**2)
    disagreement_z=abs(local_beta-source_beta)/math.sqrt(source_var+local_var)
    # Conservative evidence conflict: the target's calibrated probe contradicts
    # the source mechanism parameter strongly. Revert to target-local estimate.
    # This threshold is model conditional, not a field-calibrated safety bound.
    fallback=bool(disagreement_z>max_disagreement_z)
    source_w=0. if fallback else local_var/(source_var+local_var)
    result=float(source_w*source_beta+(1-source_w)*local_beta)
    posterior_var = float(local_var if fallback else source_var*local_var/(source_var+local_var))
    if not math.isfinite(result) or abs(result)>3.:
        raise ValueError('unstable posterior parameter')
    return {'status':'LOCAL_ONLY_SOURCE_CONFLICT' if fallback else 'MODEL_CONDITIONAL_POSTERIOR','coefficient':result,
            'source_only_coefficient':source_beta,'local_only_coefficient':local_beta,
            'source_weight':source_w,'between_machine_sigma_predeclared':between_machine_sigma,
            'source_target_disagreement_z':disagreement_z,'disagreement_cutoff_model_conditional':max_disagreement_z,
            'local_variance':local_var,'source_variance_with_heterogeneity':source_var,
            'posterior_variance_model_conditional':posterior_var,
            'note':'Cross-machine variability must be calibrated on prior training bodies; not evidence of scientific novelty.'}
