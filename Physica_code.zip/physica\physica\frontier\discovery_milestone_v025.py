"""Physica v0.25: source hypothesis -> target-directed experiment -> blind target forecast.

LIVE Meta is deliberately optional, gated, and never simulated as a live result.
Offline demo uses a labelled human-authored hypothesis and synthetic sensors.
This module never commands machinery and never reads a prospective target outcome
before writing its complete, hash-committed comparison of all baselines.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import minimize

from .curious_discovery import (check_rows, fit_linear, predict_linear, fit_neural_ensemble,
    neural_guided_symbolic_search, known_acceleration, error, simulate)
from .field_discovery import (load_manifest, load_csv, file_hash, to_reference_physics,
    physical_baseline, read_plan, pure_ast_model, predict_frozen, prospective_rollout)
from .mechanism_dsl import feature, validate_meta_mechanism

VERSION = '0.26'


def digest(doc: dict) -> str:
    return hashlib.sha256(json.dumps(doc, sort_keys=True, separators=(',', ':'),
        allow_nan=False).encode()).hexdigest()


def save_sealed(path: Path, doc: dict) -> dict:
    content=dict(doc)
    content['sha256']=digest(doc)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(content, indent=2, allow_nan=False), encoding='utf8')
    return content


def read_sealed(path: Path) -> dict:
    doc=json.loads(path.read_text(encoding='utf8'))
    signature=doc.pop('sha256',None)
    if signature!=digest(doc):
        raise ValueError('Evidence receipt has changed since commitment')
    return doc


def source_evidence(manifest_path:Path):
    manifest, files=load_manifest(manifest_path)
    train=np.concatenate([to_reference_physics(load_csv(p),manifest['_physical_baseline']) for p in files['train']])
    val_groups=[to_reference_physics(load_csv(p),manifest['_physical_baseline']) for p in files['validation']]
    val=np.concatenate(val_groups)
    return manifest,files,train,val,val_groups


def context_for_muse(train:np.ndarray,val:np.ndarray, baseline_model:dict,base_rmse:float)->dict:
    """Share only SOURCE TRAIN observations with Muse; validation remains held out.

    `val` and `base_rmse` are kept for backward compatible callers, but neither
    is read. Observational residuals are facts, not evidence of causal structure.
    """
    from .curious_discovery import generic_basis
    residual=train[:,3]-predict_linear(baseline_model,train)
    rng=np.random.default_rng(2601)
    # A stratified training-only sample avoids returning just one small time region.
    indices=np.sort(rng.choice(len(train),size=min(110,len(train)),replace=False))
    records=[{'x_m':round(float(train[i,0]),5), 'v_m_s':round(float(train[i,1]),5),
              'u_m_s2':round(float(train[i,2]),5),
              'measured_acc_m_s2':round(float(train[i,3]),5),
              'unexplained_acc_m_s2':round(float(residual[i]),5)} for i in indices]
    report={'scientific_question':'Propose a bounded, falsifiable nonlinear acceleration mechanism not in the source-blind generic feature search',
            'input_split':'SOURCE_TRAIN_ONLY_NO_VALIDATION_OR_TEST',
            'sensor_channels':['x_m','v_m_s','u_m_s2','acc_m_s2'],
            'units':{'x_m':'m','v_m_s':'m/s','u_m_s2':'m/s²','acc_m_s2':'m/s²'},
            'training_rows':int(len(train)),
            'known_reference_model':'acc=-1.8*x-0.32*v+u, with fitted generic polynomial/drag corrections',
            'source_train_residual_sd':float(np.std(residual)),
            'source_train_residual_quartiles':[float(v) for v in np.quantile(residual,[.1,.25,.5,.75,.9])],
            'training_examples':records,
            'residual_correlations':{},
            'constraint':'All predictions and hypotheses unverified; parameters must be learned from measured training data; NO SOURCE VALIDATION, TARGET PROBE OUTCOME OR FUTURE TEST is available. Do not invent sensors.'}
    for col,name in enumerate(('x_m','v_m_s','u_m_s2')):
        c=np.corrcoef(train[:,col],residual)[0,1]
        report['residual_correlations'][name]=float(c) if np.isfinite(c) else 0.0
        edges=np.quantile(train[:,col],[0,.2,.4,.6,.8,1])
        report['residual_correlations'][f'{name}_binned_training_residuals']=[float(np.mean(residual[(train[:,col]>=a)&(train[:,col]<=b)]))
                     for a,b in zip(edges[:-1],edges[1:])]
    return report


def fit_tuned_ast(train:np.ndarray, raw_expression:dict)->tuple[dict,dict]:
    """Infer bounded numeric constants ONLY from source training sensor measurements.

    Muse suggests a structural family and rough initial numbers, not the trusted
    physical coefficients. Numerical fitting happens before validation/test.
    """
    import copy
    from .curious_discovery import generic_basis,residual
    validate_meta_mechanism({'name':'candidate','expression':raw_expression,
        'hypothesis':'candidate','falsification_test':'held-out test','measured_channels':['x_m','v_m_s','u_m_s2']})
    roots=[]
    def paths(node,path=()):
        if node['op']=='const':roots.append(path)
        for field in ('arg','args'):
            if field in node:
                if field=='arg':paths(node[field],path+(field,))
                else:
                    for j,child in enumerate(node[field]):paths(child,path+(field,j))
    paths(raw_expression)
    if len(roots)>3:raise ValueError('At most 3 bounded tunable constants in a proposed equation')
    def construct(params):
        expr=copy.deepcopy(raw_expression)
        for path,value in zip(roots,params):
            ptr=expr
            for key in path:ptr=ptr[key]
            ptr['value']=float(value)
        return expr
    init=[]
    for path in roots:
        ptr=raw_expression
        for key in path:ptr=ptr[key]
        init.append(float(ptr['value']))
    x0=np.array(init)
    y=residual(train)
    B=np.column_stack((np.ones(len(train)),generic_basis(train)))
    ridge=np.eye(B.shape[1]+1)*.04;ridge[0,0]=0
    def objective(params):
        if np.any(np.abs(params)>7.99):return 1e4+float(np.linalg.norm(params)**2)
        try:
            z=feature(train,construct(params))
            X=np.column_stack((B,z))
            coef=np.linalg.solve(X.T@X+ridge,X.T@y)
            return float(np.mean((X@coef-y)**2))
        except (ValueError,np.linalg.LinAlgError,FloatingPointError):return 1e4
    if not roots:return pure_ast_model(train,raw_expression),{'tuned_parameters':[],'source':'source_train_only'}
    # Fixed multistarts do not depend on the hidden law or a prospective test.
    seeds=[x0, x0*.75, x0*1.25,np.maximum(-7.5,np.minimum(7.5,x0+np.sign(x0)*.5))]
    result=min((minimize(objective,p,method='Nelder-Mead',
                  options={'maxiter':180,'xatol':.005,'fatol':1e-9}) for p in seeds),
                  key=lambda opt:opt.fun)
    updated=construct(result.x)
    model=pure_ast_model(train,updated)
    return model,{'initial_numeric_hypothesis':init,
                  'fitted_numeric_constants':list(map(float,result.x)),
                  'tuning_measured_split':'SOURCE_TRAIN_ONLY',
                  'tuning_train_mse':float(result.fun)}


def source_discover(manifest_path:Path, out:Path, *, candidate_file:Path|None=None,
                    live_meta:bool=False,allow_billed_meta:bool=False,
                    minimum_gain:float=.05, sensory_trigger:dict|None=None) ->dict:
    if live_meta and candidate_file is not None:
        raise ValueError('Cannot label a supplied offline candidate as live Muse output')
    manifest,files,train,val,val_groups=source_evidence(manifest_path)
    teacher=fit_neural_ensemble(train,seeds=(11,23),max_iter=135)
    baseline_search=neural_guided_symbolic_search(train,val,teacher)
    baseline=baseline_search['chosen']['model']
    base_rmse=error(val[:,3],predict_linear(baseline,val))
    # Council context must not inherit the validation-selected baseline's
    # predictions: fit a separate source-TRAIN-only reference for prompting.
    context_baseline=fit_linear(train)
    ctx=context_for_muse(train,train,context_baseline,0.0)
    if sensory_trigger is not None:
        # A one-step source TRAIN sensory innovation can be passed to Muse;
        # neither source validation nor the future target outcome is available.
        if (sensory_trigger.get('source_id')!=manifest['fixture_id'] or
            sensory_trigger.get('source_calibration_sha256')!=manifest['_calibration_hash'] or
            sensory_trigger.get('source_validation_outcomes_read_for_surprise') is not False or
            sensory_trigger.get('source_train_episode_sha256') not in
                [file_hash(p) for p in files['train']] or
            not sensory_trigger.get('discovery_triggered')):
            raise ValueError('Untrusted or non-triggered sensory context for Muse')
        ctx['physical_feeling_signal']={
            'source':'ONE_STEP_SOURCE_TRAIN_SENSORY_INNOVATION_ONLY',
            'acceleration_units':'m/s^2',
            'physical_baseline_rmse_m_s2':sensory_trigger['physical_baseline_rmse_m_s2'],
            'neural_holdout_rmse_m_s2':sensory_trigger['neural_holdout_rmse_m_s2'],
            'above_threshold_fraction':sensory_trigger['above_threshold_fraction'],
            'sensor_sigma_m_s2':sensory_trigger['sensor_noise_sigma_m_s2'],
            'interpretation':sensory_trigger['trigger_interpretation'],
            'validation_or_future_test_available':False,
        }
    provenance='NO_HYPOTHESIS'
    model_name=None
    council_trace=None
    if live_meta:
        from .meta_council_v026 import run_meta_research_council
        council_trace=run_meta_research_council(ctx,allow_billed_meta=allow_billed_meta)
        proposals=council_trace['proposals']
        if council_trace['authenticated_live_calls']<2:
            raise RuntimeError('Council failed authentic API provenance verification')
        provenance='FRESH_AUTHENTICATED_META_COUNCIL_API_CALLS'
        model_name=council_trace['models']
    elif candidate_file is not None:
        proposals=[json.loads(candidate_file.read_text(encoding='utf8'))]
        provenance='USER_SUPPLIED_OFFLINE_HYPOTHESIS_NOT_META'
    else:
        proposals=[]
    proposal=None
    comparison={'baseline_validation_rmse':base_rmse,'source_blind_term':baseline['term'],
                'gate_threshold_relative':minimum_gain}
    good=False
    candidate=None
    candidate_evaluations=[]
    for proposed in proposals:
        # Every model proposal must independently satisfy the non-executable DSL.
        # Invalid proposals remain rejected; the Council cannot bypass the numerical test.
        validate_meta_mechanism(proposed)
        used=set()
        def _used_fields(expr):
            if expr['op'] in ('x','v','u'):used.add({'x':'x_m','v':'v_m_s','u':'u_m_s2'}[expr['op']])
            for k in ('arg','args'):
                if k in expr:
                    if k=='arg':_used_fields(expr[k])
                    else:
                        for child in expr[k]:_used_fields(child)
        _used_fields(proposed['expression'])
        if not used.issubset(set(proposed['measured_channels'])):
            raise ValueError('Hypothesis references unlisted physical sensor channels')
        # Prevent a supposed "new" mechanism from being merely a duplicate
        # of the source-blind feature library on the measured training support.
        from .curious_discovery import generic_basis
        from .mechanism_dsl import feature
        phi=feature(train,proposed['expression'])
        known=np.column_stack((np.ones(len(train)),generic_basis(train)))
        projected=known@np.linalg.lstsq(known,phi,rcond=None)[0]
        unexplained_fraction=float(np.linalg.norm(phi-projected)/max(np.linalg.norm(phi),1e-10))
        if unexplained_fraction<0.001:
            candidate_evaluations.append({'candidate_name':proposed['name'],
                 'source_library_duplicate_or_unidentifiable':True,
                 'novel_feature_fraction':unexplained_fraction,
                 'source_validation_gate_passed':False})
            continue
        tested,tuning=fit_tuned_ast(train,proposed['expression'])
        candidate_errors=[error(group[:,3],predict_frozen(tested,group)) for group in val_groups]
        baseline_errors=[error(group[:,3],predict_linear(baseline,group)) for group in val_groups]
        cand_rmse=error(val[:,3],predict_frozen(tested,val))
        passes=bool(cand_rmse<base_rmse*(1-minimum_gain) and
                    all(c<=b*1.02 for c,b in zip(candidate_errors,baseline_errors)))
        candidate_evaluations.append({'candidate_name':proposed['name'],
            'candidate_validation_rmse':cand_rmse,
            'per_episode_candidate_rmse':candidate_errors,
            'per_episode_baseline_rmse':baseline_errors,
            'candidate_parameter_estimation':tuning,
            'novel_feature_fraction':unexplained_fraction,
            'source_validation_gate_passed':passes})
        if (proposal is None or cand_rmse < comparison.get('candidate_validation_rmse',float('inf'))):
            proposal=proposed
            candidate=tested
            good=passes
            comparison.update(candidate_parameter_estimation=tuning,
                candidate_validation_rmse=cand_rmse,
                per_episode_candidate_rmse=candidate_errors,
                per_episode_baseline_rmse=baseline_errors,
                source_validation_gate_passed=passes)
    comparison['candidate_evaluations']=candidate_evaluations
    hashes={'source_calibration_sha256':manifest['_calibration_hash'],
            'source_train_sha256':[file_hash(p) for p in files['train']],
            'source_validation_sha256':[file_hash(p) for p in files['validation']]}
    doc={'version':VERSION,'stage':'SOURCE_HYPOTHESIS_VALIDATION',
         'source_machine_id':manifest['fixture_id'],
         'calibration_status':manifest['_calibration_kind'],
         'source_blind_model':baseline,
         'candidate_expression':candidate['expression'] if candidate is not None else None,
         'candidate_name':proposal['name'] if proposal is not None else None,
         'candidate_source_provenance':provenance,
         'authenticated_meta_model_claimed':model_name,
         'meta_council_provenance':council_trace,
         'source_candidate_accepted_for_transfer':good,
         'selection_comparison':comparison,
         'training_evidence_hashes':hashes,
         'muse_context_preview':ctx,
         'muse_received_source_validation_or_target_test':False,
         'source_test_outcomes_seen':False,'hardware_actuation':'PROHIBITED',
         'warning':'Candidate outside a fixed search does not imply new scientific law.'}
    return save_sealed(out,doc)


def fit_reference_transfer(target_train:np.ndarray,source_model:dict)->dict:
    term=source_model['term']
    params=source_model['params']
    return fit_linear(target_train,term=term,params=params)


def plan_probe(source_receipt:Path,target_manifest:Path,out:Path, *,max_distance:float=4.0)->dict:
    src=read_sealed(source_receipt)
    if not src['source_candidate_accepted_for_transfer']:
        raise ValueError('No validated source candidate to investigate')
    if src['candidate_expression'] is None:raise ValueError('No source mechanism')
    target,files,train,val,_=source_evidence(target_manifest)
    if src['source_machine_id']==target['fixture_id']:
        raise ValueError('Source and target machines must be declared distinct')
    # Fit BOTH mechanisms on the identical target pre-probe evidence. Do not read future probe outcomes.
    src_model=fit_reference_transfer(train,src['source_blind_model'])
    meta_model=pure_ast_model(train,src['candidate_expression'])
    x0s=(-.65,-.3,.25,.65)
    v0s=(-.35,0,.35)
    biases=(-.4,0,.4)
    xmu=np.mean(train[:,:3],axis=0)
    spread=np.std(train[:,:3],axis=0).clip(min=.15)
    scores=[]
    for x in x0s:
        for v in v0s:
            for u in biases:
                row=np.array([x,v,u],dtype=float)
                z=float(np.linalg.norm((row-xmu)/spread))
                if z>max_distance:continue
                r=np.array([[x,v,u,0.]])
                disagreement=abs(float(predict_frozen(meta_model,r)[0]-predict_linear(src_model,r)[0]))
                # Only safe, preapproved low-actuation tests. Penalize extrapolation.
                score=disagreement-.018*z
                scores.append((score,disagreement,z,{'x0_m':x,'v0_m_s':v,'control_bias_m_s2':u}))
    if not scores:raise ValueError('No approved in-support probe; request more calibration')
    selected=max(scores,key=lambda s:s[0]);chosen=selected[3]
    probe_controls=[float(chosen['control_bias_m_s2']+.12*np.sin(i*.09)) for i in range(95)]
    probe_plan={'fixture_id':target['fixture_id'],'dt_s':.025,
                'x0_m':chosen['x0_m'],'v0_m_s':chosen['v0_m_s'],
                'controls_m_s2':probe_controls}
    doc={'version':VERSION,'stage':'REVIEW_ONLY_DISCRIMINATING_PROBE',
         'source_commit_sha256':digest(src),'target_machine_id':target['fixture_id'],
         'target_baseline_calibration_sha256':target['_calibration_hash'],
         'target_training_hashes':[file_hash(p) for p in files['train']],
         'target_validation_hashes':[file_hash(p) for p in files['validation']],
         'candidate_count':len(scores),'selection_method':'source-structure disagreement / target local refit - support penalty',
         'chosen_initial_conditions':chosen,'probe_plan':probe_plan,
         'predicted_mechanism_disagreement_m_s2':float(selected[1]),
         'extrapolation_distance':float(selected[2]),'human_approval_required':True,
         'experiment_outcome_seen':False,'hardware_actuation':'PROHIBITED',
         'measurement_request':'Record independently calibrated x, v, applied control and acceleration. Add probe recording to target training manifest AFTER human-reviewed experiment.'}
    return save_sealed(out,doc)



def frozen_neural_parameters(models:list)->list[dict]:
    """Serialize a neural-only target baseline as plain JSON, no unsafe pickle."""
    frozen=[]
    for pipeline in models:
        scaler=pipeline.named_steps['standardscaler']
        nn=pipeline.named_steps['mlpregressor']
        frozen.append({'mean':scaler.mean_.tolist(),'scale':scaler.scale_.tolist(),
           'layers':[layer.tolist() for layer in nn.coefs_],
           'biases':[b.tolist() for b in nn.intercepts_],
           'activation':nn.activation,'output_activation':nn.out_activation_})
    return frozen


def predict_neural_frozen(rows:np.ndarray,models:list[dict])->np.ndarray:
    rows=check_rows(rows,min_rows=1)
    preds=[]
    for model in models:
        if model['activation']!='tanh' or model['output_activation']!='identity':
            raise ValueError('Unsupported frozen neural layer')
        X=(rows[:,:3]-np.array(model['mean']))/np.array(model['scale'])
        for j,(w,b) in enumerate(zip(model['layers'],model['biases'])):
            X=X@np.array(w)+np.array(b)
            if j<len(model['layers'])-1:X=np.tanh(X)
        preds.append(X.reshape(-1))
    return known_acceleration(*rows[:,:3].T)+np.mean(preds,axis=0)


def neural_rollout(plan:dict,models:list[dict],phys:dict)->list[dict]:
    x=float(plan['x0_m']);v=float(plan['v0_m_s']);dt=float(plan['dt_s'])
    rows=[]
    for i,u in enumerate(plan['controls_m_s2']):
        if abs(x)>5 or abs(v)>5:raise ValueError('Neural predictor left operating envelope')
        sample=np.array([[x,v,float(u),0.]])
        baseline=float(known_acceleration(*sample[0,:3]))
        acc=float(predict_neural_frozen(sample,models)[0]-baseline+physical_baseline(sample,phys)[0])
        if not np.isfinite(acc) or abs(acc)>40:raise ValueError('Neural forecast became unstable')
        rows.append({'time_s':round(i*dt,6),'x_m':x,'v_m_s':v,'u_m_s2':u,'predicted_acc_m_s2':acc})
        v+=dt*acc;x+=dt*v
    return rows


def target_commit(source_receipt:Path,target_manifest:Path,plan_file:Path,out:Path,
                  *,probe_receipt:Path|None=None,probe_recording:Path|None=None)->dict:
    source=read_sealed(source_receipt)
    if not source['source_candidate_accepted_for_transfer']:
        raise ValueError('Source mechanism not validated; cannot transfer')
    target,files,train,val,_=source_evidence(target_manifest)
    plan=read_plan(plan_file)
    if target['fixture_id']!=plan['fixture_id'] or target['fixture_id']==source['source_machine_id']:
        raise ValueError('Require distinct declared receiving machine and matching future plan')
    all_hashes=([file_hash(p) for p in files['train']]+[file_hash(p) for p in files['validation']])
    if any(h in all_hashes for h in source['training_evidence_hashes']['source_train_sha256'] +
                                  source['training_evidence_hashes']['source_validation_sha256']):
        raise ValueError('Reused source recordings in target evidence')
    if bool(probe_receipt) != bool(probe_recording):
        raise ValueError('Probe commitment and its subsequent measured CSV must be supplied together')
    if probe_receipt is not None:
        probe=read_sealed(probe_receipt)
        if probe['target_machine_id']!=target['fixture_id'] or probe['source_commit_sha256']!=digest(source):
            raise ValueError('Unrelated probe commitment')
        if not probe['experiment_outcome_seen'] is False:raise ValueError('Invalid probe record')
        expected_hashes=set(probe['target_training_hashes'])
        observed_probe_hash=file_hash(probe_recording)
        if not expected_hashes.issubset(set(all_hashes)) or observed_probe_hash not in set(all_hashes)-expected_hashes:
            raise ValueError('Target manifest must add the particular NEW probe measurement after planning')
        # Separately recorded experimental readings must match the predeclared probe.
        measured=load_csv(probe_recording,require_time=True)
        planned=probe['probe_plan']
        if len(measured)!=len(planned['controls_m_s2']):
            raise ValueError('Probe sample count differs from committed design')
        probe_times=np.loadtxt(probe_recording,delimiter=',',skiprows=1,ndmin=2)[:,0]
        if np.max(np.abs(probe_times-np.arange(len(measured))*planned['dt_s']))>.25*planned['dt_s']:
            raise ValueError('Probe measurement timing does not match committed schedule')
        if abs(measured[0,0]-planned['x0_m'])>.04 or abs(measured[0,1]-planned['v0_m_s'])>.04:
            raise ValueError('Probe was not recorded from the committed initial state')
        if np.max(np.abs(measured[:,2]-np.asarray(planned['controls_m_s2'])))>.03:
            raise ValueError('Probe control inputs differ from committed experiment')
    target_generic=fit_linear(train)
    source_blind_transfer=fit_reference_transfer(train,source['source_blind_model'])
    meta_transfer=pure_ast_model(train,source['candidate_expression'])
    candidates={'target_only_generic':target_generic,
                'source_blind_transfer':source_blind_transfer,
                'source_meta_structure_transfer':meta_transfer}
    validation_rmse={name:error(val[:,3],predict_frozen(model,val)) for name,model in candidates.items()}
    # A conventional neural residual predictor sees exactly the SAME target measurements.
    neural_models=fit_neural_ensemble(train,seeds=(41,59),max_iter=160)
    frozen_neural=frozen_neural_parameters(neural_models)
    validation_rmse['target_only_neural']=error(val[:,3],predict_neural_frozen(val,frozen_neural))
    # An LLM cannot override validation. Even if candidate loses, retain ALL forecasts.
    selected=min(validation_rmse,key=validation_rmse.get)
    forecast={name:prospective_rollout(plan,model,target['_physical_baseline']) for name,model in candidates.items()}
    try:
        forecast['target_only_neural']=neural_rollout(plan,frozen_neural,target['_physical_baseline'])
    except ValueError:
        # A documented neural instability is not grounds to silently exclude its failure.
        forecast['target_only_neural']=None
        if selected=='target_only_neural':selected='target_only_generic'
    doc={'version':VERSION,'stage':'TARGET_PROSPECTIVE_ABLATION_COMMITTED',
         'source_sha256':digest(source),'target_machine_id':target['fixture_id'],
         'calibration_status':target['_calibration_kind'],
         'meta_provenance':source['candidate_source_provenance'],
         'source_candidate_name':source['candidate_name'],
         'candidate_was_prevalidated_on_source':True,
         'models':candidates,'frozen_target_neural_weights':frozen_neural,
         'validation_rmse_m_s2':validation_rmse,
         'selected_without_test_data':selected,'plan':plan,'forecasts':forecast,
         'evidence_sha256':{'source_receipt_sha256':file_hash(source_receipt),
           'target_calibration_sha256':target['_calibration_hash'],
           'target_train_sha256':[file_hash(p) for p in files['train']],
           'target_validation_sha256':[file_hash(p) for p in files['validation']],
           'plan_sha256':file_hash(plan_file),
           'probe_receipt_sha256':file_hash(probe_receipt) if probe_receipt else None,
           'verified_probe_measurements_sha256':file_hash(probe_recording) if probe_recording else None},
         'future_measurements_accessed_at_commit':False,
         'actuation':'PROHIBITED',
         'time_limitation':'Local hash commitment is not independently witnessed or timestamped.'}
    return save_sealed(out,doc)


def target_reveal(commit_file:Path,actual_file:Path,out:Path)->dict:
    commit=read_sealed(commit_file)
    observed=load_csv(actual_file,require_time=True)
    h=file_hash(actual_file)
    evidence=commit['evidence_sha256']
    if h in (*evidence['target_train_sha256'],*evidence['target_validation_sha256']):
        raise ValueError('Prospective test reused previously seen target episode')
    plan=commit['plan']
    if len(observed)!=len(plan['controls_m_s2']):
        raise ValueError('Observed samples do not match precommitted controls')
    times=np.loadtxt(actual_file,delimiter=',',skiprows=1,ndmin=2)[:,0]
    expected=np.arange(len(observed))*float(plan['dt_s'])
    if np.max(np.abs(times-expected))>.25*plan['dt_s']:
        raise ValueError('Measurement timestamps differ from committed schedule')
    if np.max(np.abs(observed[:,2]-np.array(plan['controls_m_s2'])))>.03:
        raise ValueError('Actuator schedule differs from precommitment')
    if abs(observed[0,0]-plan['x0_m'])>.04 or abs(observed[0,1]-plan['v0_m_s'])>.04:
        raise ValueError('Initial state differs from precommitment')
    methods={}
    for method,rows in commit['forecasts'].items():
        if rows is None:
            methods[method]={'x_rmse_m':None,'v_rmse_m_s':None,'acc_rmse_m_s2':None,'status':'NUMERICAL_ABSTENTION'}
            continue
        if len(rows)!=len(observed):raise ValueError('Forecast length mismatch')
        predicted=np.array([[r['x_m'],r['v_m_s'],r['predicted_acc_m_s2']] for r in rows])
        truth=observed[:,[0,1,3]]
        methods[method]={'x_rmse_m':error(truth[:,0],predicted[:,0]),
                         'v_rmse_m_s':error(truth[:,1],predicted[:,1]),
                         'acc_rmse_m_s2':error(truth[:,2],predicted[:,2])}
    doc={'version':VERSION,'stage':'TARGET_REVEAL_ALL_FROZEN_ABLATIONS',
        'measurement_origin':('SYNTHETIC_REPLAY' if commit['calibration_status']=='SYNTHETIC_DECLARED'
                else 'USER_SUPPLIED_RECORDINGS_NOT_EXTERNALLY_AUTHENTICATED'),
        'meta_provenance':commit['meta_provenance'],
        'commit_sha256':digest(commit),'observations_sha256':h,
        'target_machine_id':commit['target_machine_id'],
        'selected_before_test':commit['selected_without_test_data'],
        'held_out_metrics':methods,
        'meta_structure_beats_all_ablations':all(v['x_rmse_m'] is not None and methods['source_meta_structure_transfer']['x_rmse_m']<v['x_rmse_m'] for name,v in methods.items() if name!='source_meta_structure_transfer'),
        'hardware_actuation':'NONE',
        'claim_limit':'No novel law or independent physical verification established from local receipts alone.'}
    return save_sealed(out,doc)


def main():
    p=argparse.ArgumentParser(description='Physica v0.25 empirical Meta-on/off discovery + target adaptation')
    sub=p.add_subparsers(required=True,dest='command')
    s=sub.add_parser('source');s.add_argument('--manifest',required=True);s.add_argument('--proposal');s.add_argument('--out',required=True)
    s.add_argument('--live-meta',action='store_true');s.add_argument('--allow-billed-meta',action='store_true')
    d=sub.add_parser('design');d.add_argument('--source',required=True);d.add_argument('--target-manifest',required=True);d.add_argument('--out',required=True)
    c=sub.add_parser('commit');c.add_argument('--source',required=True);c.add_argument('--target-manifest',required=True);c.add_argument('--plan',required=True);c.add_argument('--probe');c.add_argument('--probe-recording');c.add_argument('--out',required=True)
    r=sub.add_parser('reveal');r.add_argument('--commit',required=True);r.add_argument('--observations',required=True);r.add_argument('--out',required=True)
    z=sub.add_parser('synthetic-demo');z.add_argument('--out',default='demo/v025_discovery');z.add_argument('--seed',type=int,default=7)
    b=sub.add_parser('synthetic-benchmark');b.add_argument('--out',default='demo/v025_benchmark');b.add_argument('--seeds',type=int,default=12)
    args=p.parse_args()
    if args.command=='source':result=source_discover(Path(args.manifest),Path(args.out),candidate_file=Path(args.proposal) if args.proposal else None,
                                  live_meta=args.live_meta,allow_billed_meta=args.allow_billed_meta)
    elif args.command=='design':result=plan_probe(Path(args.source),Path(args.target_manifest),Path(args.out))
    elif args.command=='commit':result=target_commit(Path(args.source),Path(args.target_manifest),Path(args.plan),Path(args.out),
                                      probe_receipt=Path(args.probe) if args.probe else None,
                                      probe_recording=Path(args.probe_recording) if args.probe_recording else None)
    elif args.command=='reveal':result=target_reveal(Path(args.commit),Path(args.observations),Path(args.out))
    elif args.command=='synthetic-demo':
        from .synthetic_milestone_v025 import synthetic_demo
        result=synthetic_demo(Path(args.out),seed=args.seed)
    else:
        from .synthetic_milestone_v025 import synthetic_benchmark
        result=synthetic_benchmark(Path(args.out),seeds=args.seeds)
    print(json.dumps({'status':result['stage'],'out':str(args.out),
        'result':result if args.command in ('synthetic-demo','synthetic-benchmark')
        else {'sha256':digest({k:v for k,v in result.items() if k!='sha256'})}},indent=2))


if __name__=='__main__':main()
