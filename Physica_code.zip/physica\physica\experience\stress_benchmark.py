"""Falsification-friendly synthetic challenge: in-family vs changed hidden physics.

This is NOT a physical or state-of-the-art benchmark. No target leakage.
OOD target retains the same calibration/modal family, but its hidden forcing
residual differs strongly from the training family. Compatibility is necessary,
not sufficient, and held-out conformal bands may fail under this shift.
"""
from __future__ import annotations
import numpy as np
from pathlib import Path
from dataclasses import replace
from .causal_transport import rmse,trace
from .loop_demo import body,true_response,evaluate
from .seal import write_json


def run(out=None, *, seed=42,n_targets=24,threshold_m=1.5e-5):
    if not np.isfinite(threshold_m) or threshold_m<=0:raise ValueError('positive finite accuracy threshold required')
    original,_,memory,_=evaluate(seed=seed,n_targets=n_targets)
    rng=np.random.default_rng(seed+91215)
    shifted=[]; ood_gate=[]; in_family_gate=[]
    for i in range(n_targets):
        c=body(9000+i,rng)
        t=np.linspace(0,8/c.fundamental_hz,240)
        forecast=memory.forecast(c,t,conformal_q=original['conformal']['q_dimensionless'],observation_noise_m=7e-6)
        # A deliberately different hidden forcing family, declared BEFORE measuring.
        observed=true_response(t,c,(.20,.80,.07),rng=rng,sensor_sigma=7e-6)
        p=np.asarray(forecast['displacement_m'])
        low=replace(c,applied_step_force_n=c.applied_step_force_n*.35)
        normal_lat=(float(rng.normal(.085,.010)),float(rng.normal(0.,.06)),float(rng.normal(.012,.008)))
        normal_probe=true_response(t,low,normal_lat,rng=rng,sensor_sigma=7e-6)
        in_family_gate.append(memory.assess_probe_shift(c,trace(low,t,normal_probe),
            conformal_q=original['conformal']['q_dimensionless'],sensor_sigma_m=7e-6)['status'])
        shifted.append({'machine_id':c.machine_id,'rmse_m':rmse(p,observed),
            'whole_response_covered':bool(np.all((observed>=forecast['lower_m'])&(observed<=forecast['upper_m'])))})
        low_response=true_response(t,low,(.20,.80,.07),rng=rng,sensor_sigma=7e-6)
        ood_gate.append(memory.assess_probe_shift(c,trace(low,t,low_response),
            conformal_q=original['conformal']['q_dimensionless'],sensor_sigma_m=7e-6)['status'])
    rows=original['rows']
    counts={
        'crate_zero_probe_success':sum(r['crate_zero_shot_rmse_m']<=threshold_m for r in rows),
        'crate_needs_one_probe_and_succeeds':sum(r['crate_zero_shot_rmse_m']>threshold_m and r['crate_one_probe_rmse_m']<=threshold_m for r in rows),
        'crate_unresolved_after_one_probe':sum(r['crate_one_probe_rmse_m']>threshold_m for r in rows),
        'nearest_zero_probe_success':sum(r['nearest_normalized_rmse_m']<=threshold_m for r in rows),
        'local_only_one_probe_success':sum(r['local_only_rmse_m']<=threshold_m for r in rows),
        'physics_only_zero_probe_success':sum(r['mechanistic_rmse_m']<=threshold_m for r in rows),
    }
    result={'evaluation':'SYNTHETIC_ONLY_OOD_STRESS_AND_MAX_ONE_PROBE',
        'seed':seed,'n_targets':n_targets,
        'target_rmse_threshold_m':threshold_m,
        'source_like':{'crate_mean_rmse_m':original['metrics']['crate_zero_shot_rmse_m'],
            'whole_trajectory_90pct_coverage':original['metrics']['whole_trajectory_band_coverage'],
            'low_force_probe_false_rejections':in_family_gate.count('rejected_domain_shift')},
        'out_of_family':{'description':'shifted hidden residual amplitude .20, phase .80, quirk .07; no fitted target leakage',
            'crate_mean_rmse_m':float(np.mean([r['rmse_m'] for r in shifted])),
            'whole_trajectory_90pct_coverage':float(np.mean([r['whole_response_covered'] for r in shifted])),
            'low_force_probe_shift_rejections':ood_gate.count('rejected_domain_shift')},
        'one_probe_sample_efficiency_counts':counts,
        'notes':['Threshold and shift are simulation settings, not industry metrics.',
            'Low-force probe is a whole waveform, not a single sensor sample.',
            'Results expose failure modes under unmodeled dynamics; no domain-shift confidence guarantee.',
            'Requires a separate REAL hardware A-to-B study for breakthrough claims.']}
    if out is not None:write_json(Path(out),result)
    return result
