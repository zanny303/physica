"""ONE executable (optional paid) Meta -> CSG -> PEL -> sealed B prediction.

Spark: scene hypotheses; SAM: measured tracked geometry *only after an
independent sensor crosscheck*; Wonder: safe experiment critique.
The calibrated SAM displacement is added as a real source sensor, so removing
SAM can quantitatively change the physical posterior. Provenance is explicit.
No live execution can be claimed without the user's own credential + media.
"""
from __future__ import annotations
from pathlib import Path
from dataclasses import asdict
import hashlib,json,csv
import numpy as np
from .field import _read_json,_write,read_timeseries,source_from_manifest,prepare,channel_from_csv
from .signals import MechanicalContext
from .meta_context import curate_context_reply


def run(manifest_path, source_video,target_calibration,target_times_csv,*,out_dir,
        concept,track_id,meters_per_pixel,fps,reference_csv,max_crosscheck_rmse_m,
        camera_sigma_m,allowed_actions,explicit_bill_permission=False):
    """All numbers come from calibrated sensors, never from Muse's guesses."""
    if not explicit_bill_permission:raise PermissionError('requires explicit --allow-billed-meta')
    pars=[meters_per_pixel,fps,max_crosscheck_rmse_m,camera_sigma_m]
    if any(not np.isfinite(v) or v<=0 for v in pars):
        raise ValueError('positive independent calibration/noise/timing required')
    manifest=_read_json(manifest_path)
    ctx=MechanicalContext(**manifest['body_context'])
    if ctx.provenance!='real_sensor':
        raise ValueError('LIVE Meta route requires source instrument readings labelled real_sensor')
    t_ref,y_ref,h_ref=read_timeseries(reference_csv)
    if not allowed_actions:raise ValueError('provide a whitelist of reversible actions')
    if not isinstance(concept,str) or not concept.strip():raise ValueError('one concrete SAM object noun required')
    from physica.experience.meta_live import muse_scientist,sam_video,calibrated_track_displacement
    root=Path(out_dir);root.mkdir(parents=True,exist_ok=True)
    facts={'source_body':ctx.body_id,'boundary_fixture_verified_by':'independent source manifest',
        'body_calibration':ctx.calibration_id,'experiment_action_family':ctx.action_family,
        'sensor_channels':[{'modality':s['modality'],'observable':s['observable'],
                            'calibration':s['calibration_id']}
                           for s in manifest['channels']],
        'source_video_sha256':hashlib.sha256(Path(source_video).read_bytes()).hexdigest(),
        'independent_reference_sha256':h_ref,
        'no_numeric_inference_from_text':True}
    spark=muse_scientist(facts,allowed_actions,role='spark',video_path=source_video)
    sam=sam_video(source_video,concept=concept)
    geometry=calibrated_track_displacement(sam['boxes'],object_id=track_id,
        meters_per_pixel=meters_per_pixel,frames_per_second=fps,min_frames=8)
    t=np.asarray(geometry['time_s']);y=np.asarray(geometry['displacement_m'])
    if t[0]<t_ref[0]-1e-9 or t[-1]>t_ref[-1]+1e-9:
        raise ValueError('SAM video clocks are not synchronized to independent sensor')
    independent_y=np.interp(t,t_ref,y_ref)
    crosscheck_rmse=float(np.sqrt(np.mean(((independent_y-independent_y[0])-y)**2)))
    if crosscheck_rmse>max_crosscheck_rmse_m:
        raise ValueError('SAM geometry disagrees with independent displacement sensor; evidence refused')
    # Crucial: now SAM geometry becomes a constrained, numeric sensor channel
    # in CSG rather than merely an illustration/context sentence.
    sam_csv=root/'sam_calibrated_displacement.csv'
    with sam_csv.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['time_s','value']);w.writerows(zip(t,y))
    updated=json.loads(json.dumps(manifest))
    updated['channels'].append({'path':str(sam_csv),'sensor_id':'meta_sam31_optical',
        'modality':'vision','observable':'displacement',
        'canonical_unit':'m','si_sigma':camera_sigma_m,
        'calibration_id':'meta_SAM31_plus_independent_user_meters_per_pixel',
        'raw_unit':'m','si_per_raw_unit':1.0,'origin':'real_sensor'})
    observed_meta={'sparks_model_id':spark['model_id'],
        'sam_model_id':'sam-3.1','sam_track_id':track_id,
        'sam_video_sha256':sam['video_sha256'],
        'crosscheck_rmse_m':crosscheck_rmse,'independent_ref_sha256':h_ref,
        'source_csg_channel_includes_sam_geometry':True}
    context_facts={**facts,'validated_numeric_SAM_geometry':observed_meta}
    wonder=muse_scientist(context_facts,allowed_actions,role='wonder',video_path=source_video)
    candidates=manifest.get('candidate_hypotheses',[])
    spark_context=curate_context_reply(spark['reply'],candidate_labels=candidates,
        allowed_actions=allowed_actions,evidence_hash=sam['video_sha256'])
    wonder_context=curate_context_reply(wonder['reply'],candidate_labels=candidates,
        allowed_actions=allowed_actions,evidence_hash=sam['video_sha256'])
    updated['context_notes']=list(updated.get('context_notes',[]))+[{
        'meta_context':'suggestions_only','spark_hints':spark_context['candidate_hypotheses'],
        'wonder_hints':wonder_context['candidate_hypotheses'],
        'sam_geometry_crosschecked':True}]
    # Quantitative, separately labelled, in-run sensor ablation.
    # The same reference crosschecks the optical signal; consequently this is
    # a DIAGNOSTIC rather than a held-out Meta accuracy claim.
    from .fusion import infer_state, rank_hypotheses
    originals=[channel_from_csv(s,ctx) for s in manifest['channels']]
    augmented=[channel_from_csv(s,ctx) for s in updated['channels']]
    base=infer_state(originals,ctx)
    plus_sam=infer_state(augmented,ctx)
    def reference_error(estimate):
        t0=np.asarray(estimate['time_s']);x0=np.asarray(estimate['displacement_m'])
        if t0[0]<t_ref[0]-1e-9 or t0[-1]>t_ref[-1]+1e-9:
            return None
        ref=np.interp(t0,t_ref,y_ref)
        return float(np.sqrt(np.mean(((x0-x0[0])-(ref-ref[0]))**2)))
    diagnostic={'without_sam_crosschecked_reference_rmse_m':reference_error(base),
                'with_sam_crosschecked_reference_rmse_m':reference_error(plus_sam),
                'warning':'same reference used in acceptance/crosscheck; NOT held-out accuracy/Meta improvement proof'}
    candidates_spec=manifest.get('candidate_hypothesis_calibrations',{})
    if candidates_spec:
        candidates={name:MechanicalContext(**cal) for name,cal in candidates_spec.items()}
        diagnostic['mechanistic_candidate_posteriors']=rank_hypotheses(augmented,candidates)
        diagnostic['warning']+='; posterior conditional on supplied candidate set'
    manifest2=root/'source_meta_enriched_manifest.json';_write(manifest2,updated)
    source_word=root/'source_meta_grounded_pel.json'
    source_from_manifest(manifest2,source_word)
    prepare(source_word,target_calibration,target_times_csv,
        root/'target_B_signed_forecast.json',modality='vision',observable='displacement')
    return _write(root/'meta_csg_audit.json',{'status':'LIVE_MODEL_CALLS_NOT_INFERRED_HERE',
        'model_facts':observed_meta,'cross_sensory_ablation':diagnostic,
        'source_word':str(source_word),'signed_target_prediction':str(root/'target_B_signed_forecast.json'),
        'spark_context':spark_context,'wonder_context':wonder_context,
        'hardware_actuation_performed':False,
        'limits':['SAM geometry only after calibration and independent sensor crosscheck',
                  'Muse cannot modify a calibrated measurement or approve hardware actuation',
                  'external timestamp required for independent experiment chronology']})
