# Physica v0.8 — Prospective Feeling Prototype

Software deliverable developed from the user's v0.7 archive; new code is simulation-validated only.

**Added**: strictly prospective, signed future sensory forecasts for all v0.7 bounded mechanism families; separately verified target low-force probe; source and target compatibility enforcement; strict future-outcome-excluding CLI; post-seal independent reveal scoring; a redundant-sensor fault isolator that abstains on ambiguous corruption; a signed-certificate-gated hierarchical source-plus-target adaptation rule; a 12-target comparable synthetic forecast benchmark; a reproducible command-line forecast/reveal fixture; and a self-contained offline research exhibit.

**Observed mixed result**: local-only identification using the same target probe beats source-only transfer in the new synthetic benchmark (0.01881 vs 0.02823 mm). However, hierarchical source + target-probe adaptation achieves 0.01463 mm. On 20 additional fresh synthetic seeds (240 targets), combined method averages 0.01852 mm vs 0.02310 mm for target-only: 19.8% lower average error. This remains a mechanism-matched simulator with a declared but not field-calibrated cross-body variability prior, **not** independent proof of real-world advantage. All 3 source interventions are counted separately from 1 target probe.

**Not accomplished**: real tactile hardware, real external video dataset evaluation, authenticated Meta calls, V-JEPA weights, smart glasses integration, general-purpose cross-sensory causal learning, calibrated uncertainty on field data, or verified scientific novelty.

**Safety**: no actuation; no automatically authorized hardware use; signing assures integrity, not provenance truth or independent chronology.

**Additional shift safeguard**: a model-conditional parameter consistency test falls back to the local-only coefficient when source and target probe conflict. Synthetic stress on coefficients 0.30–0.50 demonstrated that a weak low-force probe could pass while source transfer would be harmful; the fallback avoids forcing that transfer. The stress and assumptions are included.
