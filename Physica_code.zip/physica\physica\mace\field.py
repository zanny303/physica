"""Integrity-checked ingestion of calibrated, controlled real interventions.

The manifest is a researcher assertion, not independent proof of calibration,
causal intervention, or chronological provenance. A column is NEVER synthesized.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
from pathlib import Path

MANDATORY = ('t', 'x', 'v', 'u', 'acceleration')
OPTIONAL = ('temperature_delta', 'current', 'magnetic', 'ultrasound')
KNOWN = frozenset((*MANDATORY, *OPTIONAL))


def import_manifest(path):
    manifest_path = Path(path).resolve()
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest.get('schema') != 'physica.mace.controlled.v1':
        raise ValueError('invalid manifest schema')
    if manifest.get('intervention_type') != 'controlled' or manifest.get('independent_calibration') is not True:
        raise ValueError('controlled action log and independently calibrated sensors required')
    if manifest.get('origin') not in ('supervised_real_experiment', 'remote_controlled_real_experiment'):
        raise ValueError('simulated or passive recordings cannot be marked as real intervention evidence')
    recordings = manifest.get('recordings')
    if not isinstance(recordings, list) or not recordings:
        raise ValueError('at least three recording files required')
    groups = {}
    observed_hashes = []
    used_hashes, used_episode_ids = set(), set()
    channels_by_episode = {}
    for entry in recordings:
        if not isinstance(entry, dict) or set(entry) != {'file', 'sha256', 'body_id', 'episode_id', 'split'}:
            raise ValueError('invalid recording entry')
        if entry['split'] not in ('train', 'validation', 'test'):
            raise ValueError('invalid split')
        for key in ('body_id', 'episode_id'):
            if not isinstance(entry[key], str) or not 1 <= len(entry[key]) <= 128:
                raise ValueError('invalid body or episode identifier')
        if entry['episode_id'] in used_episode_ids:
            raise ValueError('duplicate episode identifiers; independent episodes required')
        used_episode_ids.add(entry['episode_id'])
        if not isinstance(entry['file'], str) or not entry['file']:
            raise ValueError('invalid file path')
        fp = (manifest_path.parent / entry['file']).resolve()
        if not fp.is_relative_to(manifest_path.parent) or fp.suffix.lower() != '.csv' or not fp.is_file():
            raise ValueError('unsafe/missing CSV')
        if fp.stat().st_size > 50_000_000:
            raise ValueError('recording too large; split into episodes')
        data = fp.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        if digest != entry['sha256']:
            raise ValueError('tampered recording')
        if digest in used_hashes:
            raise ValueError('duplicate evidence across recording files')
        used_hashes.add(digest)
        rows = []
        reader = csv.DictReader(io.StringIO(data.decode('utf-8-sig')))
        columns = list(reader.fieldnames or [])
        if len(columns) != len(set(columns)) or not set(MANDATORY).issubset(columns):
            raise ValueError('missing mandatory measured fields or duplicate columns')
        present_optional = tuple(k for k in OPTIONAL if k in columns)
        channels_by_episode[entry['episode_id']] = list(MANDATORY) + list(present_optional)
        previous = -float('inf')
        for rec in reader:
            if None in rec:
                raise ValueError('extra CSV columns in row')
            values = {}
            for key in (*MANDATORY, *present_optional):
                try:
                    raw = rec[key]
                    if raw is None or not raw.strip():
                        raise ValueError('missing measured field ' + key)
                    values[key] = float(raw)
                except (TypeError, ValueError) as exc:
                    raise ValueError('invalid measured field ' + key) from exc
            if not all(math.isfinite(q) for q in values.values()) or values['t'] <= previous:
                raise ValueError('bad timestamps or nonfinite values')
            previous = values['t']
            rows.append({**values, 'body_id': entry['body_id'], 'episode_id': entry['episode_id'],
                         'intervention_type': 'controlled'})
        if len(rows) < 12:
            raise ValueError('too-short intervention')
        groups.setdefault(entry['split'], []).extend(rows)
        observed_hashes.append(digest)
    if any(not groups.get(s) for s in ('train', 'validation', 'test')):
        raise ValueError('train/validation/test required')
    # Explicitly do not infer evidence that an intervention or independent
    # sensor calibration really happened from a self-declared manifest.
    return groups, {'origin': manifest['origin'], 'recording_hashes': observed_hashes,
                    'channels_by_episode': channels_by_episode,
                    'measured_optional_channels': sorted({k for v in channels_by_episode.values() for k in v if k in OPTIONAL}),
                    'calibration_self_declared': True, 'independent_chronology_verified': False,
                    'independent_calibration_attested_by_software': False}
