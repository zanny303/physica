"""Reproduce both offline studies; optional user-supplied real measurements.

Do NOT interpret SIMULATED outcomes as physical proof or real Meta usage.
"""
import argparse,json
from pathlib import Path
import numpy as np
from physica.latent_experience.cli import demo,load_csv
from physica.latent_experience.guarded import evaluate_guarded
from .benchmark import evaluate as evaluate_transfer
from .probe_benchmark import evaluate as evaluate_probe

def run(seeds=12,trials=24,real_csv=None):
    if not 1<=seeds<=100:raise ValueError('invalid seed count')
    transfer=[evaluate_transfer(seed=1000+s,trials=trials) for s in range(seeds)]
    sensory=[evaluate_guarded(*demo(seed=2000+s)) for s in range(seeds)]
    probes=[evaluate_probe(seed=3000+s,n_targets=12) for s in range(seeds)]
    kinds=['source_family','parameter_shift','unknown_mechanism']
    def summary(rows):
        means={k:float(np.mean([z['rmse_mean'][k] for z in rows])) for k in ('selective_transfer','local_only','source_only')}
        return {'mean_rmse':means,
                'mean_prospective_sensation_rmse':{k:float(np.mean([z['prospective_sensation_rmse'][k] for z in rows])) for k in ('selective_transfer','local_only')},
                'seed_level_transfer_wins':sum(r['rmse_mean']['selective_transfer']<r['rmse_mean']['local_only'] for r in rows),
                'total_targets':sum(r['n'] for r in rows), 'accepted':sum(r['accepted'] for r in rows)}
    report={'origin':'SIMULATED','n_seeds':seeds,'per_seed_targets':trials,
            'transfer':{'aggregate':summary([r['aggregate'] for r in transfer]),
                        'by_scenario':{k:summary([r['by_scenario'][k] for r in transfer]) for k in kinds}},
            'sensory':{'mean_test_rmse':{k:float(np.mean([x['test_rmse'][k] for x in sensory]))
                         for k in ('latent','ARX','guarded','persistence')},
                        'model_selected_counts':{k:sum(z['selected']==k for z in sensory) for k in ('latent','ARX')}},
            'probe_design':{'mean_rmse':{k:float(np.mean([p['mean_rmse'][k] for p in probes])) for k in ('selected','random')},
                            'seed_level_design_wins':sum(p['mean_rmse']['selected']<p['mean_rmse']['random'] for p in probes),
                            'target_design_wins':sum(p['design_wins'] for p in probes),
                            'total_targets':sum(p['targets'] for p in probes),
                            'target_probe_budget_per_machine':5,'status':'SIMULATED; known feature map and actionable state queries'},
            'scientific_limits':['Synthetic observational sensors used for sensory benchmark',
             'Transfer simulation uses known 5-term dynamics and measured physical state',
             'Source machines supply extra observations; target experiment counts are equal',
             'Unknown dynamics return a local fallback but are not identified',
             'Methods are established empirical Bayes, physical regression and ARX selection',
             'No authenticated Meta inference or real hardware measurements were used']}
    if real_csv:
        Y,A=load_csv(real_csv)
        report['user_supplied_real_signal_study']={**evaluate_guarded(Y,A),
            'origin':'USER_SUPPLIED_RECORDING_UNVERIFIED',
            'causal_status':'Actions and sensor provenance must be independently verified'}
    return report

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--seeds',type=int,default=12)
    p.add_argument('--trials',type=int,default=24);p.add_argument('--real-csv');a=p.parse_args()
    data=run(a.seeds,a.trials,a.real_csv)
    out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
    print(json.dumps(data,indent=2))
if __name__=='__main__':main()
