"""Bounded goal-to-behaviour physical skill transfer, advisory and simulation-only.

A skill is NOT machine code. Embodiment map defines available, measured, reversible
parameters and sensor calibration. Target actions are serialized *proposals*;
no untrusted code, executable command, or device instruction is run.
"""
from __future__ import annotations
import hashlib
import json
import math
from dataclasses import dataclass


def finite(x, name, lo=None, hi=None):
    if isinstance(x, bool): raise ValueError(f'{name}: numeric value required')
    try: x=float(x)
    except (TypeError,ValueError): raise ValueError(f'{name}: numeric value required') from None
    if not math.isfinite(x) or (lo is not None and x<lo) or (hi is not None and x>hi):
        raise ValueError(f'{name}: outside supported range')
    return x


def canonical_hash(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest()


def validate_embodiment(body):
    if not isinstance(body,dict):raise ValueError('Target embodiment must be a JSON object')
    if set(body)-{'name','sensor_scale','sensor_unit','options','operating_limits','independent_evidence'}:
        raise ValueError('Unknown embodiment fields')
    if not isinstance(body.get('name'),str) or not 1<=len(body['name'])<=80:
        raise ValueError('Target name required')
    scale=finite(body.get('sensor_scale'), 'sensor_scale',.000001,1e6)
    limits=body.get('operating_limits',{})
    if not isinstance(limits,dict) or set(limits)-{'max_normalized_displacement','max_acceleration'}:
        raise ValueError('Unsupported target limits')
    max_x=finite(limits.get('max_normalized_displacement',2),'max_normalized_displacement',.01,100)
    max_a=finite(limits.get('max_acceleration',100),'max_acceleration',.01,1e6)
    opts=body.get('options')
    if not isinstance(opts,list) or not 1<=len(opts)<=32:raise ValueError('1–32 approved candidate settings required')
    clean=[]
    for i,opt in enumerate(opts):
        if not isinstance(opt,dict) or set(opt)-{'id','damping_scale','stiffness_scale','cost','approval_required'}:
            raise ValueError('Unsupported candidate setting')
        ident=opt.get('id')
        if not isinstance(ident,str) or not ident.isidentifier() or len(ident)>64:raise ValueError('Invalid option ID')
        clean.append({'id':ident,'damping_scale':finite(opt.get('damping_scale',1),'damping_scale',.05,5),
          'stiffness_scale':finite(opt.get('stiffness_scale',1),'stiffness_scale',.1,3),
          'cost':finite(opt.get('cost',0),'cost',0,1e6), 'approval_required':True})
    if len(set(o['id'] for o in clean))!=len(clean):raise ValueError('Duplicate option ID')
    return {'name':body['name'],'sensor_scale':scale,'sensor_unit':str(body.get('sensor_unit','sensor units'))[:32],
            'options':clean,'max_x':max_x,'max_a':max_a,'independent_evidence':bool(body.get('independent_evidence',False))}


def estimate_parameters(twin):
    if not isinstance(twin,dict) or not isinstance(twin.get('model'),dict):
        raise ValueError('No supported learned dynamics; request controlled observations')
    m=twin['model']; p=m.get('parameters',{})
    omega=finite(p.get('stiffness_per_mass_per_s2'),'source stiffness/mass',.0001,5e6)
    damp=finite(p.get('damping_per_mass_per_s'),'source damping/mass',0,2500)
    return omega,damp


def roll(omega,damp,x0,v0,timestep=0.01,seconds=2.0):
    """Simulated unforced mass-spring-damper, with conservative fixed step."""
    n=int(seconds/timestep);x=x0;v=v0;peak=abs(x);max_a=0; energy=0
    for i in range(n):
        a=-omega*x-damp*v
        if abs(a)>1e7 or abs(x)>1e5 or not math.isfinite(a):
            return {'valid':False,'reason':'unstable or out-of-model dynamics'}
        # semi-implicit Euler; intentionally bounded to low-energy demos
        v+=a*timestep;x+=v*timestep
        peak=max(peak,abs(x));max_a=max(max_a,abs(a));energy+=x*x*timestep
    return {'valid':True,'peak_abs_displacement':round(peak,8),
            'max_abs_acceleration':round(max_a,8),'integrated_displacement_squared':round(energy,8),
            'terminal_abs_displacement':round(abs(x),8),'terminal_abs_velocity':round(abs(v),8)}


def transfer_goal(source_twin, target, goal, *, source_knowledge_accepted=False):
    """Return an inspectable *advisory* skill and conditional setpoint proposals.

    A transferable physical skill is only proposed if source dynamics passed the
    supported fitting gate and source data had logged varied control input.
    No extrapolation/real device execution, and a target with unvalidated evidence
    can only be a simulation candidate, never an approved deployed change.
    """
    emb=validate_embodiment(target)
    if not isinstance(goal,dict) or set(goal)-{'kind','target_terminal_displacement','seconds','initial_sensor_displacement','initial_sensor_velocity'}:
        raise ValueError('Goal must be a bounded outcome contract')
    if goal.get('kind')!='settle_below': raise ValueError('Only settle_below is currently supported')
    seconds=finite(goal.get('seconds',2),'seconds',.2,5)
    threshold=finite(goal.get('target_terminal_displacement'),'target_terminal_displacement',.000001,1e4)
    xs=finite(goal.get('initial_sensor_displacement'),'initial_sensor_displacement',-1e4,1e4)
    vs=finite(goal.get('initial_sensor_velocity',0),'initial_sensor_velocity',-1e4,1e4)
    omega,damping=estimate_parameters(source_twin)
    origin=source_twin.get('evidence',{})
    if origin.get('length_unit') not in ('metre','meter','m'):
        return {'status':'SOURCE_CALIBRATION_REQUIRED','reason':'Source displacement must be independently calibrated in SI length units, not pixels or unspecified units',
                'next_measurement':'Obtain a measured spatial scale and synchronized controlled actions','action_program':None}
    if not bool(source_twin['model'].get('action_logged_and_variable')):
        return {'status':'NEED_CONTROLLED_SOURCE_EVIDENCE','reason':'Source trace lacks varied measured actions; mechanism transfer would be unsupported',
                'next_measurement':'Log a low-energy approved input with synchronized, calibrated position readings',
                'action_program':None}
    # target signal conversion to physically normalized coordinates. Calibration
    # is explicit; no inference of geometry or force from arbitrary video.
    x0=xs/emb['sensor_scale'];v0=vs/emb['sensor_scale'];limit=threshold/emb['sensor_scale']
    if abs(x0)>emb['max_x']:
        return {'status':'OUT_OF_SUPPORT','reason':'Initial displacement exceeds target supported range','action_program':None}
    if not source_knowledge_accepted:
        return {'status':'TARGET_VALIDATION_REQUIRED','reason':'An accepted source mechanism does not automatically apply to a different body',
                'next_measurement':'Run a qualified low-energy target identification and verify source-to-target dynamics before considering interventions',
                'action_program':None}
    candidates=[]
    for opt in emb['options']:
        r=roll(omega*opt['stiffness_scale'],damping*opt['damping_scale'],x0,v0,seconds=seconds)
        valid=r.get('valid',False) and r['peak_abs_displacement']<=emb['max_x'] and r['max_abs_acceleration']<=emb['max_a']
        margin=(limit-r['terminal_abs_displacement']) if valid else -math.inf
        candidates.append({'option':opt['id'],'effective_ratios':{'omega2':omega*opt['stiffness_scale'],
                'damping':damping*opt['damping_scale']},'prediction':r,
                'within_modeled_limits':bool(valid),'goal_margin':round(margin,8) if math.isfinite(margin) else None,
                'cost':opt['cost'],'meets_simulated_goal':bool(valid and margin>=0)})
    winners=[r for r in candidates if r['meets_simulated_goal']]
    winners.sort(key=lambda r:(r['cost'],r['prediction']['terminal_abs_displacement']))
    if not winners:
        return {'status':'NO_SUPPORTED_SOLUTION','reason':'No preapproved target setting satisfies the modeled goal and limits',
                'evaluated':candidates,'action_program':None}
    w=winners[0];proposed={'target':emb['name'],'setting_id':w['option'],
            'goal':goal,'predicted':w['prediction'],'approval_required':True,'execution':'NOT_EXECUTABLE_REVIEW_ONLY',
            'source_evidence_sha256':source_twin.get('evidence',{}).get('sha256'),
            'target_independent_validation':emb['independent_evidence']}
    proposed['commitment_sha256']=canonical_hash(proposed)
    return {'status':'REVIEW_ONLY_SIMULATED_GOAL' if emb['independent_evidence'] else 'TARGET_EVIDENCE_REQUIRED',
      'reason':'The chosen setting is a prediction under a restricted shared model, not a certified safe machine command.',
      'sensor_calibration':{'sensor_units_per_normalized_length':emb['sensor_scale'],'unit':emb['sensor_unit']},
      'evaluated':candidates,'action_program':proposed,
      'next_measurement':'Independent target validation with the approved setting; compare with no-transfer and target-only baselines',
      'safety':'Requires human/operator approval and separate platform-specific code verification. No hardware is actuated.'}


def demo():
    source={'model':{'parameters':{'stiffness_per_mass_per_s2':18.0,'damping_per_mass_per_s':.7},
                    'action_logged_and_variable':True},'evidence':{'sha256':'simulation-only-demo','length_unit':'metre'}}
    target={'name':'Machine B — encoder-equipped oscillator','sensor_scale':1000.,'sensor_unit':'encoder ticks',
      'operating_limits':{'max_normalized_displacement':2,'max_acceleration':100},
      'options':[{'id':'factory_default','damping_scale':1,'cost':0},
                 {'id':'moderate_damping','damping_scale':4,'cost':1.2},
                 {'id':'high_damping','damping_scale':5,'cost':2.5}], 'independent_evidence':False}
    goal={'kind':'settle_below','target_terminal_displacement':200,'seconds':2,
           'initial_sensor_displacement':1000,'initial_sensor_velocity':0}
    return {'origin':'SIMULATED_ASSUMED_SOURCE_AND_TARGET','goal':goal,'target':target,'result':transfer_goal(source,target,goal,source_knowledge_accepted=True),
            'notice':'The source and target share assumed dynamics here; no real causal transfer superiority is established.'}


def main():
    import argparse
    from pathlib import Path
    parser=argparse.ArgumentParser(description='Advisory goal-directed cross-machine skill transfer')
    parser.add_argument('--source',help='Twin JSON with validated model')
    parser.add_argument('--target',help='Target embodiment JSON')
    parser.add_argument('--goal',help='Goal contract JSON')
    parser.add_argument('--accept-source-mechanism',action='store_true',help='Only after independent target compatibility evidence')
    parser.add_argument('--out',required=True)
    a=parser.parse_args()
    if a.source or a.target or a.goal:
        if not (a.source and a.target and a.goal):parser.error('source, target and goal must all be supplied')
        source=json.loads(Path(a.source).read_text());target=json.loads(Path(a.target).read_text());goal=json.loads(Path(a.goal).read_text())
        result=transfer_goal(source,target,goal,source_knowledge_accepted=a.accept_source_mechanism)
    else:result=demo()
    dest=Path(a.out);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(result,indent=2,allow_nan=False))
    print(json.dumps({'out':str(dest),'status':result.get('status',result.get('result',{}).get('status'))}))

if __name__=='__main__':main()
