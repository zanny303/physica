"""Physica Studio: one localhost-only hub around existing research modules.

Allows only predetermined, non-actuating, non-billable tasks. No shell, remote
binding, arbitrary file reads, or hardware-control endpoints. Browser video
analysis remains local in the integrated Physica Lens.
"""
from __future__ import annotations

import argparse
import json
import mimetypes
import os
import re
import secrets
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
STATIC = Path(__file__).parent / 'dashboard.html'
FRONT = Path(__file__).parent / 'front.html'
OBSERVATORY = Path(__file__).parent / 'observatory.html'
TWIN = Path(__file__).parent / 'twin.html'
RECEIVED = ROOT / 'received_cards'
OUTPUT = ROOT / 'demo' / 'studio'
DATASETS = OUTPUT / 'datasets'
MAX_JSON = 8192
MAX_UPLOAD = 100 * 1024 * 1024
MAX_OUTPUT_FILE = 12 * 1024 * 1024

TASKS = {
    'outcome_loop_v031_synthetic': {
        'title': 'v0.31 · Outcome → Feel → Investigate → Reoptimize → Verify',
        'group': 'Outcome',
        'origin': 'SIMULATION ONLY · NO MUSE API CALLS OR HARDWARE CHANGES',
        'argv': ['-m','physica.outcome.closed_loop_v031','synthetic-demo',
                 '--out','demo/studio/outcome_loop_v031'],
        'report': 'outcome_loop_v031/REPORT_SIMULATED.json',
        'explanation': ('Describe a resonance-avoidance goal; commit approved experiments; '
            'fit and validate missing residual physics; change the knob recommendation; '
            'freeze a new forecast and reveal a later synthetic measurement. '
            'Real runs require separate calibrated recordings and human approval.')},
    'sentinel_v030_synthetic': {
        'title':'v0.30 Sentinel · Early-warning physical inquiry',
        'group':'Discover',
        'origin':'SIMULATED BEARING-LIKE SIGNALS · NOT PREVENTED DOWNTIME',
        'argv':['-m','physica.maintenance.cli','synthetic-demo','--out','demo/studio/sentinel'],
        'report':'sentinel/REPORT_SIMULATED.json',
        'explanation':'Strictly disjoint training/calibration/discovery/test units; source-only Muse context; alerts compared with RMS-only and graded against simulated run end. No real industrial data, verified fault diagnosis, live Meta or physical intervention.'},
    'unified_feeling_discovery_v027': {
        'title':'v0.27 · Feel → Curiosity → Muse-style hypothesis → Probe → Learn → Transfer',
        'group':'MACE',
        'origin':'SIMULATED SENSORS + HUMAN-AUTHORED HYPOTHESIS · NO LIVE META OR HARDWARE',
        'argv':['-m','physica.frontier.feeling_discovery_loop_v027','synthetic-demo',
                '--seed','7','--out','demo/studio/feeling_discovery_v027'],
        'report':'feeling_discovery_v027/RESULTS_SYNTHETIC.json',
        'explanation':'A calibrated model/sensor mismatch triggers investigation. A bounded hypothesis is tested on source validation, Physica chooses a review-only B probe, predicts B before its outcome, quantifies new surprise, and stores the measured experience for a later independently tested forecast. Never equates simulation with real physical feeling.'},
    'discovery_milestone_v025': {
        'title':'v0.25 · Unfamiliar mechanism → proposed test → blinded machine B forecast',
        'group':'MACE',
        'origin':'SYNTHETIC DATA + HUMAN-AUTHORED HYPOTHESIS; NEVER LIVE META',
        'argv':['-m','physica.frontier.discovery_milestone_v025','synthetic-demo',
                '--seed','7','--out','demo/studio/discovery_milestone_v025'],
        'report':'discovery_milestone_v025/RESULTS_SYNTHETIC_NOT_META.json',
        'explanation':'A source model compares a structural hypothesis omitted from the old symbolic library; numerical fitting uses source data only. Choose a safe review-only target probe, freeze four target forecasts, then reveal a simulated future outcome. Live Meta and physical hardware require separate credentials/measurements.'},
    'causal_fork_v021': {
        'title':'v0.21 Research Edition · Unknown physics → designed experiment → sealed A/B/C targets',
        'group':'MACE','origin':'SIMULATED PHYSICS · NUMERICAL SOURCE SEARCH · NO BILLED META',
        'argv':['-m','physica.mace.causal_fork_v021','--seed','2026','--out','demo/studio/causal_fork_v021'],
        'report':'causal_fork_v021/03_REVEALED_RESULTS.json',
        'explanation':'Unknown sin-phase physics outside the old search grid; rank an approved low-force probe, request extra target evidence if necessary, seal predictions, then reveal separate camera/audio target traces. Target-only sees the same full mathematical grammar and measurement budget.'},
    'discovery_observatory_v021': {
        'title':'v0.21 · Discovery Observatory · hypothesis and sealed unknown-physics comparison',
        'group':'MACE','origin':'SIMULATED PHYSICS + HUMAN-AUTHORED NOMINATION · NO META CALLS',
        'argv':['-m','physica.mace.discovery_observatory','--mode','human_fixture','--out','demo/studio/discovery_v021.json'],
        'report':'discovery_v021.json',
        'explanation':'Compare source-blind physics search with human-authored candidate, challenge confounders, choose a safe candidate probe, seal forecasts, then open synthetic lockbox. No paid calls.'},
    'mace_x_v014_curves': {
        'title':'v0.14 · Cross-sensory probabilistic A → B transfer learning curves',
        'group':'Transfer','origin':'SIMULATION ONLY · NO LIVE META',
        'argv':['-m','physica.mace_x.cli','benchmark','--seeds','12',
                '--out','demo/studio/mace_x_v014_learning_curves.json'],
        'report':'mace_x_v014_learning_curves.json',
        'explanation':'Related, shifted and omitted-mechanism machine families; same target observation budget, strong local Bayesian and sparse baselines; active probe selection and negative-transfer metrics.'},
    'mace_x_v014_memory': {
        'title':'v0.14 · Portable probabilistic physical experience',
        'group':'Transfer','origin':'SIMULATED CALIBRATED SOURCES · REVIEW ONLY',
        'argv':['-m','physica.mace_x.cli','example',
                '--out','demo/studio/mace_x_v014_memory.json'],
        'report':'mace_x_v014_memory.json',
        'explanation':'Serializable mechanism distribution, sensor calibration mapping, error modes, and human-review-only next experiment.'},
    'mace_x_v014_meta_preview': {
        'title':'v0.14 · Muse strategy request preview for B (does not bill)',
        'group':'Meta','origin':'OFFLINE API PREVIEW · NO META INFERENCE',
        'argv':['-m','physica.mace_x.cli','meta-advise','--preview-only',
                '--out','demo/studio/mace_x_v014_meta_preview.json'],
        'report':'mace_x_v014_meta_preview.json',
        'explanation':'Bounded Meta choice among numerically safe target probes; requires explicit authenticated CLI and independent physical testing.'},
    'mace_agentic_v013': {
        'title':'v0.13 · Autonomous bounded discovery → sealed cross-sensory transfer',
        'group':'MACE','origin':'SIMULATED SCIENTIFIC DEMO · NOT LIVE META',
        'argv':['-m','physica.mace.agentic_v013','demo','--out','demo/studio/v013_discovery'],
        'report':'v013_discovery/DISCOVERY_THEATER.html',
        'explanation':'Search unfamiliar periodic dynamics without supplying the answer; freeze source hypothesis, compare B/C target-only baselines, sign both forecasts BEFORE generating target outcomes. Reports negative transfer results.'},
    'mace_agentic_benchmark_v013': {
        'title':'v0.13 · Independent multi-seed transfer evaluation',
        'group':'MACE','origin':'SIMULATED BENCHMARK',
        'argv':['-m','physica.mace.agentic_v013','benchmark','--seeds','8','--out','demo/studio/v013_benchmark'],
        'report':'v013_benchmark/BENCHMARK.json',
        'explanation':'Compare per-target transfer with target-only search at identical local probe budgets; report all wins and losses, not only the average.'},
    'feeling_lab': {
        'title': 'Predictive Feeling · A → B → C', 'group': 'Lab', 'origin': 'SIMULATION',
        'argv': ['-m', 'physica.feeling.cli', 'demo', '--out', 'demo/studio/feeling'],
        'report': 'feeling/experience_lab.html',
        'explanation': 'Sealed A → B → C mechanical feeling loop; simulated sensors and interventions.'},
    'prospective': {
        'title': 'Prospective signed prediction', 'group': 'Lab', 'origin': 'SIMULATION',
        'argv': ['-m', 'physica.feeling.v081_replay', '--out', 'demo/studio/prospective'],
        'report': 'prospective/07_result_and_fair_baselines.json',
        'explanation': 'Creates a source lesson, seals the forecast, then generates its simulated outcome.'},
    'benchmark': {
        'title': 'Cross-machine benchmark · 24 targets', 'group': 'Lab', 'origin': 'SIMULATION',
        'argv': ['-m', 'physica.feeling.v08_cli', 'benchmark', '--trials', '24', '--out', 'demo/studio/benchmark.json'],
        'report': 'benchmark.json',
        'explanation': 'Prospective source-only vs target-only vs hierarchical transfer on simulated bodies.'},
    'sensor_reliability': {
        'title': 'Reliability-aware feeling benchmark', 'group': 'Lab', 'origin': 'SIMULATION',
        'argv': ['-m', 'physica.feeling.v07_cli', 'benchmark', '--out', 'demo/studio/reliability.json'],
        'report': 'reliability.json',
        'explanation': 'Synthetic sensor conflict, missing channels and mechanism-transfer experiments.'},
    'cloud_pilot': {
        'title': 'Discover · Train simulated sensor models', 'group': 'Discover', 'origin': 'SYNTHETIC TRAINING',
        'argv': ['-m', 'physica.remote_bench.cli', 'pilot', '--out', 'demo/studio/cloud'],
        'report': 'cloud/trained_weights/report.json',
        'explanation': 'Trains actual small classifiers and a future-sensation regressor on synthetic sensor signals.'},
    'cloud_next': {
        'title': 'Discover · Refit future-sensation predictor', 'group': 'Discover', 'origin': 'SYNTHETIC TRAINING',
        'argv': ['-m', 'physica.remote_bench.cli', 'train-next', 'demo/studio/cloud/manifest.json', '--out', 'demo/studio/next'],
        'requires': 'cloud/manifest.json',
        'report': 'next/next_sensation_report.json',
        'explanation': 'Trains a vibration/current conditional predictor on disjoint simulated machines.'},
    'real_train': {
        'title': 'Discover · Train supplied real sensor recordings', 'group': 'Discover', 'origin': 'USER-SUPPLIED RECORDINGS',
        'argv': ['-m', 'physica.remote_bench.cli', 'train', 'demo/studio/datasets/manifest.json', '--out', 'demo/studio/real_training'],
        'requires': 'datasets/manifest.json',
        'report': 'real_training/report.json',
        'explanation': 'Uses provided .mat/.csv files and a valid manifest. Real-world measurement claims are source-declared.'},
    'real_next': {
        'title': 'Discover · Predict future real sensor signals', 'group': 'Discover', 'origin': 'USER-SUPPLIED RECORDINGS',
        'argv': ['-m', 'physica.remote_bench.cli', 'train-next', 'demo/studio/datasets/manifest.json', '--out', 'demo/studio/real_next'],
        'requires': 'datasets/manifest.json',
        'report': 'real_next/next_sensation_report.json',
        'explanation': 'Same physical-body-held-out next-sensation experiment with user-supplied evidence.'},
    'transfer_design': {
        'title': 'Cross-machine experiment planner', 'group': 'Transfer', 'origin': 'ILLUSTRATIVE DESIGN',
        'argv': ['-m', 'physica.triad.cli', 'target-design', 'examples/triad_v052/target_transfer_design.json', '--out', 'demo/studio/transfer.json'],
        'report': 'transfer.json',
        'explanation': 'Ranks permitted source experiments by expected information gain on future target bodies.'},
    'causal_memory': {
        'title': 'Causal Experience Memory · controlled actions', 'group': 'Lab', 'origin': 'SIMULATED TRAINING',
        'argv': ['-m', 'physica.causal_memory.benchmark', '--trials', '24', '--out', 'demo/studio/causal_memory.json'],
        'report': 'causal_memory.json',
        'explanation': 'Trains action-conditioned causal corrections with distinct source/target bodies and equal target probe budgets. Reports losses as well as wins.'},
    'causal_memory': {
        'title': 'Causal Experience Memory · controlled actions', 'group': 'Lab', 'origin': 'SIMULATED TRAINING',
        'argv': ['-m', 'physica.causal_memory.benchmark', '--trials', '24', '--out', 'demo/studio/causal_memory.json'],
        'report': 'causal_memory.json',
        'explanation': 'Trains action-conditioned causal corrections with distinct source/target bodies and equal target probe budgets. Reports losses as well as wins.'},
    'latent_feeling': {
        'title': 'Learned action-conditioned sensory experience', 'group': 'Lab', 'origin': 'SIMULATED TRAINING',
        'argv': ['-m', 'physica.latent_experience.cli', '--out', 'demo/studio/latent_experience.json'],
        'report': 'latent_experience.json',
        'explanation': 'Trains sensory embedding and action dynamics with chronological held-out future forecasting, compares persistence baseline; simulator only.'},
    'experience_v09': {
        'title': 'v0.9 · Cross-sensory prediction and reveal', 'group': 'Lab', 'origin': 'SIMULATED END-TO-END',
        'argv': ['-m', 'physica.research_v09.experience', '--out', 'demo/studio/experience_v09.json'],
        'report': 'experience_v09.json',
        'explanation': 'Simulated A audio/contact → B camera/inertial sensing, chronological forecast commitment and separate reveal. Does not claim real five-sense ability.'},
    'research_v09': {
        'title': 'v0.9 · Selective cross-machine feeling benchmark', 'group': 'Transfer', 'origin': 'SIMULATED RESEARCH',
        'argv': ['-m', 'physica.research_v09.run', '--seeds', '8', '--trials', '24', '--out', 'demo/studio/research_v09.json'],
        'report': 'research_v09.json',
        'explanation': 'Compares source-family, shifted-physics and unknown-mechanism targets with local-only fitting; also tests latent-vs-ARX sensing. No hardware or live Meta.'},
    'mace_investigate': {
        'title':'MACE · Evidence-gated mechanism discovery A → B → C', 'group':'MACE', 'origin':'SYNTHETIC PROSPECTIVE',
        'argv':['-m','physica.mace.cli','demo','--out','demo/studio/mace'],
        'report':'mace/experience_lab.html',
        'explanation':'Action-conditioned source experiment, withheld mechanism test, source-to-target probe, sealed camera forecasts and post-forecast simulator reveal.'},
    'mace_benchmark': {
        'title':'MACE · Repeat causal discovery / transfer stress cases', 'group':'MACE', 'origin':'SYNTHETIC BENCHMARK',
        'argv':['-m','physica.mace.cli','benchmark','--seeds','6','--out','demo/studio/mace_repeats'],
        'report':'mace_repeats/BENCHMARK.json',
        'explanation':'Compares held-out mechanisms, target-only predictions and selective transfer; preserves negative results.'},
    'mace_senses': {
        'title':'MACE · Humans-can’t-sense-this sensor inventory', 'group':'MACE', 'origin':'SENSOR REGISTRY',
        'argv':['-m','physica.mace.cli','sensor-inventory','--out','demo/studio/mace_sensors.json'],
        'report':'mace_sensors.json',
        'explanation':'Thermal, electrical, magnetic, radar, ultrasound, chemical and other physical modalities with explicit hardware requirements.'},
    'mace_target_aware_probes': {
        'title':'MACE v0.11 · Target-directed experiment benchmark', 'group':'MACE', 'origin':'SYNTHETIC ONLY',
        'argv':['-m','physica.mace.cli','target-probe-benchmark','--seeds','24','--trials','100',
                '--out','demo/studio/mace_target_probe.json'],
        'report':'mace_target_probe.json',
        'explanation':'Select source probes to reduce prediction uncertainty on a receiving target. Compare against equal-budget random probes.'},
    'mace_missing_sense': {
        'title':'MACE v0.11 · Choose a missing physical sense', 'group':'MACE', 'origin':'CALIBRATION-CONDITIONAL',
        'argv':['-m','physica.mace.cli','sense-plan','--input','examples/mace_v011/sense_plan_example.json',
                '--out','demo/studio/mace_missing_sense.json'],
        'report':'mace_missing_sense.json',
        'explanation':'Recommend a calibrated measurement based on expected reduction in uncertainty. Does not create sensor data.'},
    'mace_real_investigation': {
        'title':'MACE v0.11 · Field scientific hypothesis evaluation', 'group':'Discover', 'origin':'USER-SUPPLIED CLAIMED REAL',
        'argv':['-m','physica.mace.cli','field-investigate','--manifest','demo/studio/datasets/mace_manifest.json',
                '--out','demo/studio/mace_field_investigation.json'],
        'requires':'datasets/mace_manifest.json','report':'mace_field_investigation.json',
        'explanation':'Numerical candidate validation, target-aware probe selection and independent held-out scoring. No Meta billing.'},
    'mace_unknown_discovery': {
        'title':'v0.12 · Unfamiliar mechanism discovery / lockbox', 'group':'MACE',
        'origin':'SIMULATION · NOT A NEW NATURAL LAW',
        'argv':['-m','physica.mace.cli','discover-unknown','--seed','2026',
                '--out','demo/studio/mace_unknown_discovery.json'],
        'report':'mace_unknown_discovery.html',
        'explanation':'Expands a restricted feature grammar beyond the fixed candidate list, tests two independent validation episodes, opens a lockbox only after selection and reports failures.'},
    'mace_unknown_meta_research': {
        'title':'v0.12.1 · Unknown physics → test a bounded hypothetical Meta nomination',
        'group':'MACE', 'origin':'SIMULATION + HUMAN-AUTHORED HYPOTHESIS; NOT LIVE META',
        'argv':['-m','physica.mace.cli','unknown-investigate','--seed','2026',
                '--nomination','examples/mace_v0121/author_hypothesis_SIMULATED.json',
                '--out','demo/studio/mace_unknown_meta_research.json'],
        'report':'mace_unknown_meta_research.json',
        'explanation':'Detect unexplained residuals, test a manually authored sine-phase hypothesis on separate validation interventions, compare against fixed-grammar alternatives, and score one sealed simulation holdout. Never claims an authenticated Meta call.'},
    'mace_unknown_meta_preview': {
        'title':'v0.12.1 · Prepare the Muse unknown-physics request (no API call)',
        'group':'Meta', 'origin':'OFFLINE STRUCTURED META API REQUEST',
        'argv':['-m','physica.mace.cli','unknown-investigate','--seed','2026',
                '--out','demo/studio/mace_unknown_meta_preview.json'],
        'report':'mace_unknown_meta_preview.json',
        'explanation':'Shows residual diagnosis and a strict-schema Muse Wonder hypothesis request. No billing and no claim of model inference.'},
    'mace_unknown_field': {
        'title':'v0.12 · Discover mechanism from controlled real CSV', 'group':'Discover',
        'origin':'USER-COLLECTED · SELF-DECLARED CALIBRATION',
        'argv':['-m','physica.mace.cli','discover-unknown','--manifest','demo/studio/datasets/mace_manifest.json',
                '--out','demo/studio/mace_unknown_field.json'],
        'requires':'datasets/mace_manifest.json', 'report':'mace_unknown_field.json',
        'explanation':'Test bounded mechanism grammar on user-provided, SHA256-checked source train / validation / test interventions. Causality and chronology need external corroboration.'},
    'mace_meta_preview': {
        'title':'MACE · Meta scientific hypothesis structured API preview', 'group':'MACE', 'origin':'OFFLINE API CONTRACT',
        'argv':['-m','physica.mace.cli','meta-preview','--context','examples/mace_v010/meta_training_context.json',
                '--out','demo/studio/mace_meta_contract.json'],
        'report':'mace_meta_contract.json',
        'explanation':'Shows actual strict Muse hypothesis request. NO model inference or billing.'},
    'mace_real_field': {
        'title':'MACE · Evaluate calibrated controlled-action recordings', 'group':'Discover', 'origin':'USER-SUPPLIED CLAIMED REAL MEASUREMENTS',
        'argv':['-m','physica.mace.cli','field-evaluate','--manifest','demo/studio/datasets/mace_manifest.json',
                '--out','demo/studio/mace_real_field.json'],
        'requires':'datasets/mace_manifest.json', 'report':'mace_real_field.json',
        'explanation':'Requires source-declared controlled independent calibrated CSVs and SHA256 manifest, with train/validation/test episodes distinct.'},
    'meta_contract_v09': {
        'title': 'v0.9 · Meta structured-hypothesis API contract', 'group': 'Meta', 'origin': 'OFFLINE CONTRACT',
        'argv': ['-m', 'physica.research_v09.meta_bridge', '--context', 'examples/research_v09/meta_context.json', '--out', 'demo/studio/meta_contract_v09.json', '--dry-run'],
        'report': 'meta_contract_v09.json',
        'explanation': 'Validate strict Meta schema and review-only candidate list. No Meta request and no API charges.'},
    'meta_doctor': {
        'title': 'Meta Spark / Wonder / SAM readiness', 'group': 'Meta', 'origin': 'OFFLINE CHECK',
        'argv': ['-m', 'physica.field.cli', 'meta-doctor', '--out', 'demo/studio/meta_doctor.json'],
        'report': 'meta_doctor.json',
        'explanation': 'Only local API contract and dependency checks. Sends no requests or billing.'},
    'regression': {
        'title': 'Focused regression tests', 'group': 'System', 'origin': 'LOCAL TESTS',
        'argv': ['-m', 'pytest', '-q', 'tests/test_remote_bench_v083.py', 'tests/test_feeling_v081.py', 'tests/test_triad_v052.py'],
        'report': None,
        'explanation': 'Selected regression tests; not a full end-to-end hardware test.'},
}


def _inside(base: Path, relative: str) -> Path:
    p = (base / relative).resolve()
    if not p.is_relative_to(base.resolve()):
        raise ValueError('path outside allowed folder')
    return p


def _type_for(path: Path) -> str:
    if path.suffix == '.json': return 'application/json; charset=utf-8'
    if path.suffix in ('.txt', '.log'): return 'text/plain; charset=utf-8'
    if path.suffix == '.html': return 'text/html; charset=utf-8'
    return mimetypes.guess_type(str(path))[0] or 'application/octet-stream'


class Studio:
    def __init__(self):
        self.token = secrets.token_urlsafe(32)
        self.lock = threading.RLock()
        self.jobs: dict[str, dict] = {}
        self.active_id: str | None = None
        from physica.studio.front import LiveSensor
        self.live = LiveSensor()
        self.twin_cases = {}

    def catalog(self):
        return {key: {k: val for k, val in spec.items() if k not in ('argv', 'requires')}
                | {'ready': spec.get('requires') is None or _inside(OUTPUT, spec['requires']).is_file(),
                   'available_report': bool(spec.get('report') and _inside(OUTPUT, spec['report']).is_file())}
                for key, spec in TASKS.items()}

    def schedule(self, key: str):
        if key not in TASKS: raise ValueError('unrecognized task')
        spec = TASKS[key]
        if 'requires' in spec and not _inside(OUTPUT, spec['requires']).is_file():
            raise ValueError('missing required prior output / dataset manifest')
        if key in ('real_train', 'real_next'):
            manifest = json.loads((DATASETS/'manifest.json').read_text(encoding='utf-8'))
            if manifest.get('schema') != 'physica.remote.signals.v1' or manifest.get('origin') != 'external_recorded':
                raise ValueError('real-data operation requires external_recorded manifest schema')
        with self.lock:
            if self.active_id and self.jobs[self.active_id]['status'] == 'running':
                raise ValueError('a job is already running; finish it first')
            jid = uuid.uuid4().hex
            job = {'id': jid, 'task': key, 'status': 'running', 'started': time.time(),
                   'output': '', 'report': spec.get('report'), 'exit_code': None}
            self.jobs[jid] = job
            self.active_id = jid
        threading.Thread(target=self.execute, args=(jid, spec), daemon=True).start()
        return job.copy()

    def execute(self, jid, spec):
        env = dict(os.environ)
        env['PYTHONUTF8'] = '1'  # Windows cp1252 UnicodeEncodeError fix
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        # The hub never sends billable calls or untrusted configuration to an actuator.
        env.pop('MODEL_API_KEY', None)
        cmd = [sys.executable] + spec['argv']
        try:
            completed = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True,
                                       text=True, encoding='utf-8', errors='replace', timeout=180)
            output = (completed.stdout + '\n' + completed.stderr)[-16000:]
            status = 'completed' if completed.returncode == 0 else 'failed'
            exit_code = completed.returncode
        except subprocess.TimeoutExpired as e:
            output = 'Timed out after 180 seconds; narrow the experiment or use the CLI for large datasets.'
            status = 'failed'; exit_code = -1
        except Exception as e:
            output = f'{type(e).__name__}: {str(e)[:500]}'
            status = 'failed'; exit_code = -2
        with self.lock:
            self.jobs[jid].update(status=status, output=output, exit_code=exit_code,
                                  finished=time.time())
            if self.active_id == jid: self.active_id = None


def make_handler(studio: Studio):
    class H(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            if not self.path.startswith('/api/jobs'):
                super().log_message(format, *args)

        def send_video(self, path):
            """A clip, with byte ranges so the player can seek."""
            size = path.stat().st_size
            start, end = 0, size - 1
            rng = self.headers.get('Range', '')
            if rng.startswith('bytes='):
                a, _, b = rng[6:].partition('-')
                if a.isdigit():
                    start = int(a)
                    end = min(int(b), size - 1) if b.isdigit() else size - 1
                if start >= size or start > end:
                    self.send_response(416)
                    self.send_header('Content-Range', f'bytes */{size}')
                    self.end_headers()
                    return
            self.send_response(206 if rng else 200)
            self.send_header('Content-Type', 'video/mp4')
            self.send_header('Accept-Ranges', 'bytes')
            self.send_header('Content-Length', str(end - start + 1))
            if rng:
                self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            with path.open('rb') as f:
                f.seek(start)
                self.wfile.write(f.read(end - start + 1))

        def send_data(self, code: int, data: bytes | str | dict, content_type='application/json; charset=utf-8'):
            if isinstance(data, dict): data = json.dumps(data, ensure_ascii=False, allow_nan=False).encode('utf-8')
            if isinstance(data, str): data = data.encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('X-Frame-Options', 'SAMEORIGIN')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self' 'unsafe-inline' blob: data:; frame-ancestors 'self'")
            self.end_headers()
            self.wfile.write(data)

        def _query(self):
            p = urllib.parse.urlsplit(self.path)
            return p.path, {k: v[0] for k, v in urllib.parse.parse_qs(p.query).items()}

        def do_GET(self):
            path, q = self._query()
            try:
                if path in ('/', '/index.html'):
                    page = (Path(__file__).parent / 'demo.html').read_text(encoding='utf-8').replace('@@TOKEN@@', json.dumps(studio.token))
                    return self.send_data(200, page, 'text/html; charset=utf-8')
                if path in ('/more', '/more/'):
                    return self.send_data(200, (Path(__file__).parent / 'more.html').read_text(encoding='utf-8'), 'text/html; charset=utf-8')
                if path in ('/try/box', '/try/box/'):
                    page = (Path(__file__).parent / 'box.html').read_text(encoding='utf-8').replace('@@TOKEN@@', json.dumps(studio.token))
                    return self.send_data(200, page, 'text/html; charset=utf-8')
                if path in ('/everything', '/everything/'):
                    page = FRONT.read_text(encoding='utf-8').replace('@@TOKEN@@', json.dumps(studio.token))
                    return self.send_data(200, page, 'text/html; charset=utf-8')
                if path in ('/try/ruler', '/try/file'):
                    keep = 'live' if path.endswith('ruler') else 'anything'
                    page = FRONT.read_text(encoding='utf-8').replace('@@TOKEN@@', json.dumps(studio.token))
                    page = page.replace('</head>', f'<style>main>section:not(#{keep}){{display:none!important}}header nav,#anyTiles,main>footer,body>footer{{display:none}}</style></head>', 1)
                    page = page.replace('<main>', '<main><p style="padding-top:20px"><a href="/">Back to Physica</a></p>', 1)
                    return self.send_data(200, page, 'text/html; charset=utf-8')
                if path == '/api/run/status':
                    from physica.studio import runner
                    return self.send_data(200, json.dumps(runner.status(), default=float))
                if path.startswith('/made/') and path.endswith('.mp4'):
                    from physica.studio import runner
                    made = runner.clip_file(path[len('/made/'):])
                    if made is None:
                        return self.send_data(404, {'error': 'no such clip'})
                    return self.send_video(made)
                if path == '/api/demo':
                    from physica.studio import demo
                    return self.send_data(200, demo.data(), 'application/json; charset=utf-8')
                if path == '/api/scout/films':
                    from physica.studio import film_api
                    return self.send_data(200, film_api.scout_films())
                if path == '/api/scout/frame':
                    from physica.studio import film_api
                    return self.send_data(200, film_api.scout_frame(q.get('film', '')))
                if path.startswith('/printer/file/'):
                    from physica.studio import film_api
                    f = film_api.gcode_file(urllib.parse.unquote(path[len('/printer/file/'):]))
                    if f is None:
                        return self.send_data(404, {'error': 'no such file'})
                    data = f.read_bytes()
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/plain; charset=utf-8')
                    self.send_header('Content-Disposition', 'attachment; filename="part_goal.gcode"')
                    self.send_header('Content-Length', str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                if path.startswith('/film/') and path.endswith('.mp4'):
                    from physica.studio import demo
                    clip = demo.CLIPS.get(path[len('/film/'):-len('.mp4')])     # named clips only, never a path from the request
                    if clip is None or not clip.exists():
                        return self.send_data(404, {'error': 'no such clip'})
                    return self.send_video(clip)
                if path in ('/sentinel','/sentinel/'):
                    page=(Path(__file__).parent/'sentinel.html').read_text(encoding='utf-8')
                    return self.send_data(200,page,'text/html; charset=utf-8')
                if path == '/api/sentinel/demo':
                    # Fixed source path, no arbitrary filesystem read or billable calls.
                    example=ROOT/'demo'/'v030_synthetic'/'REPORT_SIMULATED.json'
                    if not example.is_file():
                        return self.send_data(404,{'status':'EVIDENCE_UNAVAILABLE','reason':'Generate the explicit synthetic demonstration first'})
                    return self.send_data(200,json.loads(example.read_text(encoding='utf-8')))
                if path in ('/feel','/feel/'):
                    page=(Path(__file__).parent/'feel.html').read_text(encoding='utf-8')
                    return self.send_data(200,page,'text/html; charset=utf-8')
                if path == '/api/unified/demo':
                    from physica.unified.showcase import example
                    if q.get('domain') not in ('printer','turbine','f1'):
                        return self.send_data(400,{'error':'Unsupported domain'})
                    return self.send_data(200,example(q['domain']))
                if path in ('/observatory','/observatory/'):
                    page = OBSERVATORY.read_text(encoding='utf-8').replace('@@TOKEN@@', json.dumps(studio.token))
                    return self.send_data(200, page, 'text/html; charset=utf-8')
                if path in ('/frontier','/frontier/'):
                    page=(Path(__file__).parent/'frontier.html').read_text(encoding='utf-8')
                    return self.send_data(200,page,'text/html; charset=utf-8')
                if path in ('/curiosity','/curiosity/'):
                    page=(Path(__file__).parent/'curiosity.html').read_text(encoding='utf-8')
                    return self.send_data(200,page,'text/html; charset=utf-8')
                if path == '/api/frontier/curiosity':
                    from physica.frontier.curious_discovery import benchmark
                    policy=q.get('policy','mechanism')
                    try:
                        n=int(q.get('seeds','3'))
                    except ValueError:
                        return self.send_data(400,{'error':'seeds must be an integer'})
                    if n<1 or n>5 or policy not in ('none','random','curious','mechanism'):
                        return self.send_data(400,{'error':'Invalid safe offline benchmark arguments'})
                    return self.send_data(200,benchmark(seeds=n,probe_policy=policy))
                if path == '/api/frontier/ablation':
                    from physica.frontier.hybrid import evaluate
                    return self.send_data(200,evaluate(seeds=4))
                if path == '/api/frontier/council-preview':
                    from physica.frontier.council import council_plan
                    return self.send_data(200,council_plan({'measured_channels':['position','velocity','action'],
                      'provenance':'CONTROLLED_SIMULATION_NOT_REAL_SENSOR'},
                      {'kind':'reduce_vibration','constraint':'review_only'}))
                if path in ('/twin','/twin/'):
                    page=TWIN.read_text(encoding='utf-8').replace('@@TOKEN@@',json.dumps(studio.token))
                    return self.send_data(200,page,'text/html; charset=utf-8')
                if path == '/api/twin/demo':
                    from physica.twin.engine import demo_twin
                    twin=demo_twin(); tid=uuid.uuid4().hex
                    with studio.lock:
                        if len(studio.twin_cases)>=8: studio.twin_cases.pop(next(iter(studio.twin_cases)))
                        studio.twin_cases[tid]=twin
                    return self.send_data(200,{'id':tid,'twin':twin})
                if path in ('/lab', '/lab/'):
                    page = STATIC.read_text(encoding='utf-8').replace('@@TOKEN@@', json.dumps(studio.token))
                    return self.send_data(200, page, 'text/html; charset=utf-8')
                if path == '/api/evidence':
                    from physica.studio.front import evidence
                    return self.send_data(200, json.dumps(evidence(), default=float, allow_nan=True).replace('NaN', 'null'))
                if path == '/api/meta/status':
                    from physica.llm import meta_client as mc
                    return self.send_data(200, mc.status())
                if path == '/api/received':
                    items = sorted(RECEIVED.glob('*.json'))[-10:] if RECEIVED.exists() else []
                    return self.send_data(200, {'received': [json.loads(p.read_text())['report'] for p in items]})
                if path == '/api/catalog': return self.send_data(200, studio.catalog())
                if path == '/api/jobs':
                    with studio.lock:
                        return self.send_data(200, {'jobs': list(reversed(list(studio.jobs.values())))[-15:]})
                if path == '/api/job':
                    with studio.lock:
                        job = studio.jobs.get(q.get('id'))
                        return self.send_data(200 if job else 404, job or {'error': 'unknown job'})
                if path.startswith('/outputs/'):
                    rel = urllib.parse.unquote(path[len('/outputs/'):])
                    p = _inside(OUTPUT, rel)
                    if not p.is_file() or p.suffix not in ('.json', '.html', '.txt', '.log') or p.stat().st_size > MAX_OUTPUT_FILE:
                        return self.send_data(404, {'error': 'output unavailable'})
                    return self.send_data(200, p.read_bytes(), _type_for(p))
                if path == '/exhibits/discover':
                    p = ROOT/'examples/cloud_v083/discover_cloud_pilot.html'
                    return self.send_data(200, p.read_bytes(), 'text/html; charset=utf-8')
                if path == '/lens/' or path == '/lens':
                    from physica.triad.lens import app_html
                    page = app_html().replace("'/api/analyze?", "'/lens/api/analyze?")
                    page = page.replace("'Content-Type':blob.type||'video/mp4'", "'Content-Type':blob.type||'video/mp4','X-Physica-Token':" + json.dumps(studio.token))
                    return self.send_data(200, page, 'text/html; charset=utf-8')
                if path == '/feel-check/' or path == '/feel-check':
                    from physica.app.server import STATIC as LEGACY
                    page = (LEGACY/'index.html').read_text(encoding='utf-8')
                    page = page.replace('/api/', '/feel-check/api/').replace('/feelogram/', '/feel-check/feelogram/')
                    return self.send_data(200, page, 'text/html; charset=utf-8')
                if path.startswith('/feel-check/api/') or path.startswith('/feel-check/feelogram/'):
                    from physica.app.server import Replay, DEMO_SOURCES
                    backend = Replay()
                    names = {v['source'] for v in DEMO_SOURCES}
                    op = path.removeprefix('/feel-check/api/')
                    src = q.get('source', '')
                    if op == 'mode': return self.send_data(200, {'mode': 'replay'})
                    if op == 'sources': return self.send_data(200, [{**v, 'replay_available': backend.available(v['source'])} for v in DEMO_SOURCES])
                    if op == 'evidence': return self.send_data(200, backend.evidence())
                    if op == 'discover': return self.send_data(200, backend.discover())
                    if op == 'library': return self.send_data(200, backend.library())
                    if op in ('feel', 'ask', 'translate', 'truth'):
                        if src not in names: raise ValueError('unknown replay source')
                        if op == 'feel': result = backend.feel(src)
                        elif op == 'ask': result = backend.ask(src)
                        elif op == 'translate':
                            if q.get('target') not in ('ardupilot', 'marlin', 'klipper', 'fan'):
                                raise ValueError('unsupported replay target')
                            result = backend.translate(src, q['target'])
                        else:
                            from physica.data.padre import fault_map
                            result = {'source': src, 'faults': fault_map(src.split(':')[1])}
                        return self.send_data(200, result)
                    if path.startswith('/feel-check/feelogram/'):
                        name = Path(path).name
                        if not re.fullmatch(r'[a-zA-Z0-9_-]+\.png', name):
                            raise ValueError('invalid replay image')
                        p = backend.png(name[:-4])
                        if not p.is_file(): return self.send_data(404, {'error': 'image unavailable'})
                        return self.send_data(200, p.read_bytes(), 'image/png')
                    return self.send_data(404, {'error': 'unknown replay route'})
                if path.startswith('/docs/'):
                    allowed = {
                        'start': 'README.md', 'research': 'docs/V081_PROSPECTIVE_EVIDENCE_AND_FIELD_GUIDE.md',
                        'cloud': 'docs/V083_CLOUD_META_TRAINING_AND_THREE_DEMOS.md',
                        'field': 'docs/V082_FIELD_AND_META_READINESS.md',
                        'mace': 'docs/V012_DISCOVERY_AND_STUDIO.md',
                    }
                    key = path.removeprefix('/docs/')
                    if key not in allowed: return self.send_data(404, {'error': 'unknown document'})
                    return self.send_data(200, (ROOT/allowed[key]).read_text(encoding='utf-8'), 'text/plain; charset=utf-8')
                return self.send_data(404, {'error': 'not found'})
            except Exception as e:
                return self.send_data(422, {'error': f'{type(e).__name__}: {str(e)[:400]}'})

        def _authorized(self):
            # No unauthenticated external sites may trigger jobs/upload even on localhost.
            if self.headers.get('X-Physica-Token') != studio.token: return False
            origin = self.headers.get('Origin')
            if origin:
                expected = f'http://{self.headers.get("Host", "")}'
                if origin != expected: return False
            if self.headers.get('Sec-Fetch-Site', 'same-origin') not in ('same-origin', 'none'): return False
            return True

        def do_POST(self):
            path, q = self._query()
            if path == '/api/receive-card':
                # Another machine teaching this one: verify only, store, never execute. No dashboard token needed.
                try:
                    size = int(self.headers.get('Content-Length', '-1'))
                    if size <= 0 or size > 256 * 1024: raise ValueError('invalid card size')
                    env = json.loads(self.rfile.read(size))
                    from physica.cause.transfer import receive
                    report = receive(env)
                    RECEIVED.mkdir(exist_ok=True)
                    (RECEIVED / f"{time.strftime('%Y%m%dT%H%M%S')}_{report['sender_key']}.json").write_text(
                        json.dumps({'report': report, 'envelope': env}, default=float))
                    return self.send_data(200, report)
                except Exception as e:
                    return self.send_data(422, {'error': f'{type(e).__name__}: {str(e)[:300]}'})
            if not self._authorized(): return self.send_data(403, {'error': 'not authorized by local dashboard'})
            if path == '/api/live':
                size = int(self.headers.get('Content-Length', '-1'))
                if size <= 0 or size > 4 * 1024 * 1024: return self.send_data(422, {'error': 'invalid live payload'})
                body = json.loads(self.rfile.read(size))
                if body.get('reset'):
                    studio.live.reset(); return self.send_data(200, {'status': 'reset'})
                return self.send_data(200, json.dumps(studio.live.analyze(body), default=float).replace('NaN', 'null'))
            if path == '/api/agent':
                size = int(self.headers.get('Content-Length', '-1'))
                if size <= 0 or size > MAX_JSON: return self.send_data(422, {'error': 'invalid question'})
                body = json.loads(self.rfile.read(size))
                from physica.meta import agent
                try:
                    r = agent.ask(str(body.get('question', ''))[:2000])
                except Exception as e:
                    return self.send_data(422, {'error': f'{type(e).__name__}: {str(e)[:300]}'})
                return self.send_data(200, json.dumps(r, default=float))
            if path == '/api/film/upload' or path.startswith(('/api/film/', '/api/ruler/', '/api/printer/', '/api/scout/', '/api/cables/', '/api/speak/', '/api/run/')):
                from physica.studio import film_api
                try:
                    size = int(self.headers.get('Content-Length', '-1'))
                    if path == '/api/film/upload':
                        return self.send_data(200, film_api.save_upload(q.get('name', ''), size, self.rfile))
                    if size < 0 or size > MAX_JSON:
                        raise ValueError('invalid request')
                    body = json.loads(self.rfile.read(size) or b'{}')
                    if path == '/api/run/start':
                        from physica.studio import runner
                        from physica.llm import meta_client as _mc2
                        if not _mc2.is_mock() and not body.get('only') and self.headers.get('X-Physica-Billing') != 'I-ACKNOWLEDGE':
                            raise ValueError('Asking Muse uses your Meta credits, so it has to be asked for')
                        return self.send_data(200, json.dumps(runner.start(body.get('only')), default=float))
                    if path == '/api/film/feel':
                        if body.get('live') and self.headers.get('X-Physica-Billing') != 'I-ACKNOWLEDGE':
                            raise ValueError('Asking Muse uses your Meta credits, so it has to be asked for')
                        out = film_api.feel(body)
                    elif path == '/api/film/preset':
                        out = film_api.add_preset(body)
                    elif path == '/api/film/case':
                        from physica.llm import meta_client as _mc
                        if not _mc.is_mock() and self.headers.get('X-Physica-Billing') != 'I-ACKNOWLEDGE':
                            raise ValueError('Asking Muse uses your Meta credits, so it has to be asked for')
                        out = film_api.run_case(body)
                    elif path == '/api/speak/goal':
                        from physica.llm import meta_client as _mc3
                        if not _mc3.is_mock() and self.headers.get('X-Physica-Billing') != 'I-ACKNOWLEDGE':
                            raise ValueError('Asking Muse uses your Meta credits, so it has to be asked for')
                        out = film_api.goal_box(body)
                    elif path == '/api/speak/read':
                        if self.headers.get('X-Physica-Billing') != 'I-ACKNOWLEDGE':
                            raise ValueError('Asking Muse uses your Meta credits, so it has to be asked for')
                        out = film_api.muse_reads(body)
                    elif path == '/api/speak/run':
                        if self.headers.get('X-Physica-Billing') != 'I-ACKNOWLEDGE':
                            raise ValueError('Asking Muse uses your Meta credits, so it has to be asked for')
                        out = film_api.speak(body)
                    elif path == '/api/film/twin':
                        out = film_api.twin_of(body)
                    elif path.startswith('/api/ruler/'):
                        out = film_api.ruler(path.rsplit('/', 1)[1], body)
                    elif path == '/api/printer/twin':
                        out = film_api.printer_twin(body)
                    elif path == '/api/printer/goal':
                        out = film_api.write_file(body)
                    elif path == '/api/cables/forecast':
                        out = film_api.cable_forecast(body)
                    elif path == '/api/scout/save':
                        out = film_api.scout_save(body)
                    else:
                        return self.send_data(404, {'error': 'unknown route'})
                    return self.send_data(200, json.dumps(out, default=float).replace('NaN', 'null'))
                except Exception as e:
                    return self.send_data(422, {'error': str(e)[:400]})
            try:
                size = int(self.headers.get('Content-Length', '-1'))
                if path == '/api/twin/analyze':
                    if size < 12 or size > 55*1024*1024: raise ValueError('Twin recording must be 12 bytes to 55 MB')
                    name=q.get('name','')
                    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,120}',name):
                        raise ValueError('Twin upload requires a simple local filename')
                    from physica.twin.engine import reconstruct
                    ppm=float(q['ppm']) if q.get('ppm') else None
                    fps=float(q['fps']) if q.get('fps') else None
                    roi=[float(v.strip()) for v in q['roi'].split(',')] if q.get('roi') else None
                    twin=reconstruct(name,self.rfile.read(size),pixels_per_metre=ppm,fps=fps,roi=roi)
                    tid=uuid.uuid4().hex
                    with studio.lock:
                        if len(studio.twin_cases)>=8:studio.twin_cases.pop(next(iter(studio.twin_cases)))
                        studio.twin_cases[tid]=twin
                    return self.send_data(200,{'id':tid,'twin':twin})
                if path == '/api/twin/muse-map':
                    if size<=0 or size>MAX_JSON: raise ValueError('Invalid Meta Twin context request')
                    if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise ValueError('JSON required')
                    req=json.loads(self.rfile.read(size))
                    if not isinstance(req,dict) or set(req)!={'id','acknowledge_billing'} or req['acknowledge_billing'] is not True:
                        raise ValueError('Explicit billed Meta map request acknowledgment required')
                    with studio.lock:
                        if getattr(studio,'meta_running',False):raise ValueError('Another Meta request is active')
                        twin=studio.twin_cases.get(req['id'])
                        if twin is None:raise ValueError('Twin unavailable; rebuild it')
                        studio.meta_running=True
                    try:
                        from physica.twin.meta_map import propose_map
                        return self.send_data(200,propose_map(twin,allow_billed=True))
                    finally:
                        with studio.lock:studio.meta_running=False
                if path == '/api/twin/goal-transfer':
                    if size<=0 or size>MAX_JSON: raise ValueError('Invalid target goal contract')
                    if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise ValueError('JSON required')
                    req=json.loads(self.rfile.read(size))
                    if not isinstance(req,dict) or set(req)-{'id','target','goal','accept_source_mechanism'}:
                        raise ValueError('Unexpected goal-transfer fields')
                    with studio.lock:twin=studio.twin_cases.get(req.get('id'))
                    if twin is None:raise ValueError('Source twin not in session')
                    from physica.twin.goal_transfer import transfer_goal
                    result=transfer_goal(twin,req.get('target'),req.get('goal'),
                        source_knowledge_accepted=req.get('accept_source_mechanism') is True)
                    return self.send_data(200,result)
                if path == '/api/twin/simulate':
                    if size <=0 or size > MAX_JSON:raise ValueError('Twin intervention JSON too large')
                    if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise ValueError('JSON required')
                    req=json.loads(self.rfile.read(size))
                    if not isinstance(req,dict) or set(req)-{'id','scenario','stiffness_scale','damping_scale','force'}:
                        raise ValueError('Unexpected intervention fields')
                    with studio.lock:twin=studio.twin_cases.get(req.get('id'))
                    if twin is None:raise ValueError('Twin not in local active session; rebuild the model')
                    from physica.twin.engine import simulate_intervention
                    result=simulate_intervention(twin,scenario=req.get('scenario','custom'),
                        stiffness_scale=req.get('stiffness_scale',1.),damping_scale=req.get('damping_scale',1.),
                        force=req.get('force',0.))
                    return self.send_data(200,result)
                if path == '/api/run':
                    if size <= 0 or size > MAX_JSON: raise ValueError('invalid request size')
                    if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                        raise ValueError('JSON required')
                    value = json.loads(self.rfile.read(size))
                    if not isinstance(value, dict) or set(value) != {'task'} or not isinstance(value['task'], str):
                        raise ValueError('only predefined task IDs may be run')
                    return self.send_data(202, studio.schedule(value['task']))
                if path == '/api/meta/agentic-cycle':
                    if size<=0 or size>MAX_JSON:raise ValueError('invalid Meta scientific cycle request')
                    if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise ValueError('JSON required')
                    content=json.loads(self.rfile.read(size))
                    if not isinstance(content,dict) or set(content)!={'acknowledge_billing','model','rounds'}:
                        raise ValueError('strict Meta authorization required')
                    if content['acknowledge_billing'] is not True or content['model'] not in ('muse-spark-1.3','muse-wonder-1.0') or content['rounds'] not in (1,2):
                        raise ValueError('authorization, supported model and 1 or 2 paid rounds required')
                    if not os.environ.get('MODEL_API_KEY'):raise ValueError('MODEL_API_KEY is not configured locally')
                    with studio.lock:
                        if getattr(studio,'meta_running',False):raise ValueError('another Meta request is active')
                        studio.meta_running=True
                    try:
                        from physica.mace.meta_cycle_v013 import run as run_meta_cycle
                        from physica.mace.simulation import roll
                        source={'id':'A_sound_touch','thermal':.82,'extra':.4}
                        train=roll(source,2026,'A_source_train',unmodelled=True)
                        val=roll(source,2027,'A_source_validation_one',unmodelled=True)+roll(source,2028,'A_source_validation_two',unmodelled=True)
                        result=run_meta_cycle(train,val,model=content['model'],rounds=content['rounds'],allow_billed=True)
                        dst=OUTPUT/'v013_agentic_meta_real_calls.json';dst.parent.mkdir(parents=True,exist_ok=True)
                        dst.write_text(json.dumps(result,indent=2,allow_nan=False,ensure_ascii=False)+'\n',encoding='utf-8')
                        return self.send_data(200,{'status':'completed','report':'/outputs/v013_agentic_meta_real_calls.json',
                            'calls':result['authenticated_calls_attempted'],'selected':result['selected_mechanism'],
                            'warning':'Hypotheses validated on synthetic source signals only; not physical discovery'})
                    finally:
                        with studio.lock:studio.meta_running=False
                if path == '/api/meta/live-science':
                    if size<=0 or size>MAX_JSON: raise ValueError('invalid Meta science request length')
                    if self.headers.get('Content-Type','').split(';')[0]!='application/json': raise ValueError('JSON required')
                    content=json.loads(self.rfile.read(size))
                    if not isinstance(content,dict) or set(content)!={'acknowledge_billing','model'} or content.get('acknowledge_billing') is not True:
                        raise ValueError('explicit billed Meta acknowledgment required')
                    if content['model'] not in ('muse-spark-1.3','muse-wonder-1.0'):raise ValueError('unsupported Meta model')
                    if not os.environ.get('MODEL_API_KEY'): raise ValueError('MODEL_API_KEY not configured in the Studio Terminal')
                    with studio.lock:
                        if getattr(studio,'meta_running',False):raise ValueError('another Meta call is active')
                        studio.meta_running=True
                    try:
                        from physica.mace.meta import live_nomination
                        from physica.mace.simulation import roll
                        from physica.mace.mechanisms import BASE,CANDIDATES,fit,score,compare
                        train=roll({'id':'A_sound_touch','thermal':.82},2026,'meta_source_train',n=140)
                        valid=roll({'id':'A_sound_touch','thermal':.82},2027,'meta_source_validation',n=140)
                        baseline=fit(train,BASE)
                        context={'problem':'Unexpected temperature-sensitive acceleration residual under controlled action',
                            'available_measured_channels':['x','v','u','temperature_delta','acceleration'],
                            'calibrated_units':{'x':'m','v':'m/s','u':'m/s^2','temperature_delta':'K','acceleration':'m/s^2'},
                            'train_residual_rmse':baseline['noise_rmse'],
                            'baseline_validation_rmse':score(valid,baseline),
                            'mechanisms_already_tested':[t['id'] for t in BASE],
                            'safe_observation_options':['independently measured low-force temperature-varying intervention']}
                        nomination=live_nomination(context,model=content['model'],allow_billed=True)
                        no_meta=compare(train,valid,CANDIDATES[:2],improvement=.08)
                        candidate=nomination.get('candidate')
                        with_meta=compare(train,valid,CANDIDATES[:2]+([candidate] if candidate else []),improvement=.08)
                        lockbox=roll({'id':'A_sound_touch','thermal':.82},2029,'meta_source_test_LOCKBOX',n=140)
                        report={'origin':'SIMULATION_WITH_AUTHENTICATED_META_HYPOTHESIS',
                                'model_request_authenticated':True,
                                'meta':nomination, 'candidate_accepted_by_validation':with_meta['selected'],
                                'no_meta_lockbox_acceleration_rmse':score(lockbox,no_meta['model']),
                                'meta_lockbox_acceleration_rmse':score(lockbox,with_meta['model']),
                                'heldout_truth_never_sent_to_meta':True,
                                'caution':'Single simulation case, not replicated physical discovery or performance improvement.'}
                        dst=OUTPUT/'mace_meta_live_v012.json';dst.parent.mkdir(parents=True,exist_ok=True)
                        dst.write_text(json.dumps(report,indent=2,allow_nan=False,ensure_ascii=False)+'\n',encoding='utf-8')
                        return self.send_data(200,{'status':'completed','report':'/outputs/mace_meta_live_v012.json',
                              'selected':with_meta['selected'], 'authenticated':True})
                    finally:
                        with studio.lock:studio.meta_running=False
                if path == '/api/mace/diagnose':
                    if size<=0 or size>MAX_JSON:raise ValueError('invalid diagnosis request length')
                    if self.headers.get('Content-Type','').split(';')[0]!='application/json':
                        raise ValueError('JSON required')
                    from physica.mace.consumer import diagnose
                    content=json.loads(self.rfile.read(size))
                    if not isinstance(content,dict) or set(content)-{'case','question','evidence','before_after'}:
                        raise ValueError('unsupported consumer input')
                    return self.send_data(200,diagnose(**content))
                if path == '/api/auto/inspect':
                    if size <= 0 or size > 35 * 1024 * 1024:
                        raise ValueError('evidence file must be between 1 byte and 35 MB')
                    name=q.get('name','')
                    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,120}', name):
                        raise ValueError('Select a plain local filename (no paths)')
                    ext=Path(name).suffix.lower()
                    if ext not in ('.mp4','.mov','.avi','.mkv','.webm','.csv','.tsv','.txt','.npy'):
                        return self.send_data(200,{
                            'status':'unsupported_or_unreadable',
                            'identified':{'template':'unknown','why':'Unsupported file format'},
                            'investigation':{'status':'insufficient_evidence',
                                'recommended_next_measurement':{'request':'Supply a video or finite numeric time series CSV'}},
                            'sense_map':{'felt':[],'say':'Unsupported input; no physical cause was invented'}})
                    mode=q.get('mode','offline')
                    if mode not in ('offline','meta'):
                        raise ValueError('Unknown analysis mode')
                    billed=mode=='meta'
                    if billed and (self.headers.get('X-Physica-Billing')!='I-ACKNOWLEDGE' or not os.environ.get('MODEL_API_KEY')
                                   or os.environ.get('MOCK')!='0'):
                        raise ValueError('Meta requires MODEL_API_KEY, MOCK=0, and explicit billing acknowledgment')
                    # Separate live calls are serialized; ledger reserves budget across processes.
                    if billed:
                        with studio.lock:
                            if getattr(studio,'meta_running',False):raise ValueError('Another Meta request is in progress')
                            studio.meta_running=True
                    try:
                        with tempfile.TemporaryDirectory(prefix='physica_auto_') as tmp:
                            fp=Path(tmp)/name
                            fp.write_bytes(self.rfile.read(size))
                            from physica.auto import run as auto_run
                            hint=q.get('hint','')[:200]
                            frames=q.get('fps','')
                            fps=float(frames) if frames else None
                            if fps is not None and (not 1 <= fps <= 5000):
                                raise ValueError('frame rate must be between 1 and 5000')
                            result=auto_run(fp,fps=fps,live=billed,hint=hint)
                        result['meta_request']='live_billed' if billed else 'offline_no_meta'
                        result['input_origin']='user_upload_unverified'
                        return self.send_data(200,result)
                    finally:
                        if billed:
                            with studio.lock:studio.meta_running=False
                if path == '/api/upload':
                    name = q.get('name', '')
                    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,120}', name):
                        raise ValueError('upload name must be a plain filename')
                    if name.startswith('.') or name.lower().split('.')[-1] not in ('csv', 'mat', 'json'):
                        raise ValueError('only CSV, MAT and JSON dataset files are accepted')
                    if size <= 0 or size > MAX_UPLOAD: raise ValueError('upload must be 1–100 MB')
                    DATASETS.mkdir(parents=True, exist_ok=True)
                    dst = _inside(DATASETS, name)
                    if dst.exists(): raise ValueError('file already exists; rename to avoid overwriting evidence')
                    with tempfile.NamedTemporaryFile(dir=DATASETS, delete=False) as temp:
                        remaining = size
                        while remaining:
                            chunk = self.rfile.read(min(1024 * 1024, remaining))
                            if not chunk: raise ValueError('truncated upload')
                            temp.write(chunk); remaining -= len(chunk)
                        staging = Path(temp.name)
                    staging.replace(dst)
                    return self.send_data(201, {'stored': name, 'bytes': size,
                                                'note': 'local only; recording origin and calibration remain source-declared'})
                if path == '/lens/api/analyze':
                    if size <= 0 or size > 50 * 1024 * 1024: raise ValueError('video must be 1–50 MB')
                    if self.headers.get('Content-Type', '').split(';')[0] not in (
                            'video/mp4', 'video/quicktime', 'video/webm', 'application/octet-stream'):
                        raise ValueError('unsupported video MIME')
                    from physica.triad.lens import evaluate_uploaded_video
                    roi = [int(i) for i in q['roi'].split(',')]
                    if len(roi) != 4: raise ValueError('invalid region of interest')
                    ppm = float(q['ppm']) if 'ppm' in q else None
                    with tempfile.TemporaryDirectory(prefix='physica_studio_lens_') as d:
                        p = Path(d)/'clip.mp4'; p.write_bytes(self.rfile.read(size))
                        report = evaluate_uploaded_video(p, roi=roi, pixels_per_metre=ppm,
                                                         model_context=q.get('context', 'general'))
                    # Contextual possibilities are clearly NOT automatically verified diagnoses.
                    if q.get('context') in ('washing_machine','robot_arm','3d_printer'):
                        from physica.mace.consumer import diagnose
                        report['mace_evidence_limited_guidance']=diagnose(q['context'])
                    return self.send_data(200, report)
                return self.send_data(404, {'error': 'unknown action'})
            except Exception as e:
                return self.send_data(422, {'error': f'{type(e).__name__}: {str(e)[:400]}'})
    return H


def main(argv=None):
    parser = argparse.ArgumentParser(description='Physica Studio · all experiences in one local browser')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--host', default='127.0.0.1', help='0.0.0.0 lets other machines on your network teach this one '
                        '(only /api/receive-card and read-only pages; everything else still needs this dashboard)')
    parser.add_argument('--open-browser', action='store_true', help='open the dashboard in your default browser')
    args = parser.parse_args(argv)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    if args.port < 1024 or args.port > 65535: parser.error('port must be 1024–65535')
    server = ThreadingHTTPServer((args.host, args.port), make_handler(Studio()))
    print(f'Physica Studio: http://127.0.0.1:{args.port}  (Ctrl+C to exit)' +
          (f'  - listening on {args.host} for other machines' if args.host != '127.0.0.1' else ''), flush=True)
    if args.open_browser:
        import webbrowser
        threading.Timer(.6, lambda: webbrowser.open(f'http://127.0.0.1:{args.port}')).start()
    try: server.serve_forever()
    finally: server.server_close()


if __name__ == '__main__':
    main()
