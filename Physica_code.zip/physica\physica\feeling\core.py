"""Physica v0.6: predictive physical feeling, *not* subjective experience.

A calibrated, deliberately narrow interaction model. Action-conditioned trajectories
are projected into real sensor units. A signed causal lesson may transport a
*dimensionless* contact-force ratio between compatible machines, and prediction
errors become falsifiable evidence. Pure numerical functions NEVER actuate hardware.

This is not a claim of discovering a new dynamical law, a universally calibrated
world model, or safe robotic control. Real data must provide independently validated
calibration, force and clock provenance; otherwise the result is conditional.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json
import math
from typing import Mapping

import numpy as np
from scipy.optimize import least_squares
from physica.library import sign


def _finite(*xs):
    return all(math.isfinite(float(x)) for x in xs)


def _vec(values, name, *, min_count=1):
    a = np.asarray(values, dtype=float)
    if a.ndim != 1 or len(a) < min_count or not np.all(np.isfinite(a)):
        raise ValueError(f'{name} must be a finite one-dimensional sequence')
    return a


@dataclass(frozen=True)
class Body:
    body_id: str
    mass_kg: float
    stiffness_n_m: float
    damping_n_s_m: float
    force_reference_n: float
    max_authorized_force_n: float
    boundary_class: str = 'clamped_strip'
    mechanism_family: str = 'smooth_contact_friction'
    slip_velocity_scale_m_s: float = .025
    provenance: str = 'simulation'

    def __post_init__(self):
        vals = (self.mass_kg, self.stiffness_n_m, self.damping_n_s_m,
                self.force_reference_n, self.max_authorized_force_n, self.slip_velocity_scale_m_s)
        if not self.body_id or not self.boundary_class or not self.mechanism_family or not _finite(*vals):
            raise ValueError('incomplete or non-finite body calibration')
        if min(self.mass_kg, self.stiffness_n_m, self.force_reference_n,
               self.max_authorized_force_n, self.slip_velocity_scale_m_s) <= 0 or self.damping_n_s_m < 0:
            raise ValueError('invalid positive mechanical parameters')
        if self.provenance not in ('simulation','independent_measurement','signed_replay'):
            raise ValueError('unknown body provenance')


@dataclass(frozen=True)
class Sense:
    sensor_id: str
    modality: str
    unit: str
    state_gains: tuple[float, float]
    offset: float
    noise_std: float
    calibration_id: str
    state_range_m: tuple[float,float] = (-.25,.25)
    velocity_range_m_s: tuple[float,float] = (-5.,5.)
    calibration_origin: str = 'simulation'

    def __post_init__(self):
        v = (*self.state_gains, self.offset, self.noise_std, *self.state_range_m,
             *self.velocity_range_m_s)
        if not (self.sensor_id and self.modality and self.unit and self.calibration_id) or not _finite(*v):
            raise ValueError('missing calibrated sense')
        if self.noise_std <= 0 or self.state_range_m[0] >= self.state_range_m[1] or self.velocity_range_m_s[0] >= self.velocity_range_m_s[1]:
            raise ValueError('invalid sensor noise or operating domain')
        if not any(abs(g)>1e-12 for g in self.state_gains):
            raise ValueError('sensor cannot observe calibrated mechanical state')
        if self.calibration_origin not in ('simulation','independent_fixture','signed_replay'):
            raise ValueError('sensor without permitted calibration provenance')


@dataclass(frozen=True)
class Interaction:
    intervention_id: str
    body: Body
    times_s: tuple[float,...]
    applied_force_n: tuple[float,...]
    initial_state_m_m_s: tuple[float,float]
    observations: Mapping[str,tuple[float,...]]
    senses: Mapping[str,Sense]
    evidence_sha256: str
    origin: str = 'simulation'
    human_authorized: bool = False

    def __post_init__(self):
        t = _vec(self.times_s,'timestamps', min_count=25)
        u = _vec(self.applied_force_n,'applied force', min_count=25)
        if not self.intervention_id or len(t)!=len(u) or t[0]<0 or np.any(np.diff(t)<=0):
            raise ValueError('invalid synchronized force/timestamp data')
        if np.max(np.diff(t))*math.sqrt(self.body.stiffness_n_m/self.body.mass_kg)>.35:
            raise ValueError('undersampled dynamics for this integrator')
        if np.any(abs(u)>self.body.max_authorized_force_n+1e-12):
            raise ValueError('force exceeds approved experiment envelope')
        if len(self.initial_state_m_m_s)!=2 or not _finite(*self.initial_state_m_m_s):
            raise ValueError('missing independently measured initial state')
        if set(self.observations)!=set(self.senses) or not self.senses:
            raise ValueError('every observation requires its own calibrated sense')
        for key, values in self.observations.items():
            if key!=self.senses[key].sensor_id or len(_vec(values, key))!=len(t):
                raise ValueError('sensor/time alignment mismatch')
        if self.origin not in ('simulation','real_measurement','signed_replay'):
            raise ValueError('invalid measurement origin')
        if self.origin!='simulation' and (not self.human_authorized or
                self.body.provenance=='simulation' or
                any(s.calibration_origin=='simulation' for s in self.senses.values())):
            raise ValueError('real experiment requires authorization and independent calibration')
        if len(self.evidence_sha256)!=64 or any(x not in '0123456789abcdef' for x in self.evidence_sha256):
            raise ValueError('missing evidence digest')


def simulate(body:Body,times_s,applied_force_n,*,friction_force_n=0.,initial_state=(0.,0.)):
    """Explicit action→physical-state model, fourth-order RK, no external action."""
    t=_vec(times_s,'times',min_count=2); u=_vec(applied_force_n,'force',min_count=2)
    if len(t)!=len(u) or t[0]<0 or np.any(np.diff(t)<=0):
        raise ValueError('invalid simulation time/force axis')
    if not _finite(friction_force_n,*initial_state) or friction_force_n<0:
        raise ValueError('invalid friction or initial state')
    if np.any(np.abs(u)>body.max_authorized_force_n+1e-12):
        raise ValueError('simulation request exceeds authorized force envelope')
    if np.max(np.diff(t))*math.sqrt(body.stiffness_n_m/body.mass_kg)>.35:
        raise ValueError('time step too large for current physical model')
    z=np.zeros((len(t),2));z[0]=initial_state
    def f(x,force):
        q,v=x
        friction=friction_force_n*np.tanh(v/body.slip_velocity_scale_m_s)
        return np.array([v,(force-body.stiffness_n_m*q-body.damping_n_s_m*v-friction)/body.mass_kg])
    for i in range(len(t)-1):
        h=float(t[i+1]-t[i]); x=z[i]; force=u[i]
        k1=f(x,force); k2=f(x+h*k1/2,force); k3=f(x+h*k2/2,force); k4=f(x+h*k3,force)
        z[i+1]=x+h*(k1+2*k2+2*k3+k4)/6
        if not np.all(np.isfinite(z[i+1])):
            raise ValueError('simulation diverged')
    return z


def sense_prediction(body, sensor:Sense, state):
    x=np.asarray(state,dtype=float)
    if x.ndim!=2 or x.shape[1]!=2 or not np.all(np.isfinite(x)):
        raise ValueError('invalid physical states')
    if (np.any(x[:,0]<sensor.state_range_m[0]) or np.any(x[:,0]>sensor.state_range_m[1]) or
        np.any(x[:,1]<sensor.velocity_range_m_s[0]) or np.any(x[:,1]>sensor.velocity_range_m_s[1])):
        raise ValueError('forecast outside independently validated sensor domain')
    return x@np.asarray(sensor.state_gains)+sensor.offset


def predict_senses(body,times_s,force_n,initial_state,senses,*,friction_force_n=0.):
    state=simulate(body,times_s,force_n,friction_force_n=friction_force_n,initial_state=initial_state)
    return {'physical_state':state,
            'sensations':{key:sense_prediction(body,sensor,state) for key,sensor in senses.items()}}


def compare_feeling(trial:Interaction,*,friction_force_n=0.,surprise_threshold=5.):
    """Self-action cancellation: measured sensation minus *action-conditioned* expectation."""
    if not _finite(surprise_threshold) or surprise_threshold<=0:raise ValueError('bad surprise threshold')
    pred=predict_senses(trial.body,trial.times_s,trial.applied_force_n,
                        trial.initial_state_m_m_s,trial.senses,friction_force_n=friction_force_n)
    evidence={}; alerts=[]
    for key,sensor in trial.senses.items():
        observed=_vec(trial.observations[key],key)
        innovation=(observed-pred['sensations'][key])/sensor.noise_std
        rms=float(np.sqrt(np.mean(innovation**2)))
        if rms>surprise_threshold:alerts.append(key)
        evidence[key]={'modality':sensor.modality,'unit':sensor.unit,
                       'normalized_surprise_rms':rms,
                       'signed_residual_mean_in_sensor_units':float(np.mean(observed-pred['sensations'][key])),
                       'calibration_id':sensor.calibration_id,'evidence_sha256':trial.evidence_sha256}
    return {'status':'unexpected_consequence' if alerts else 'consistent_with_self_prediction',
            'surprising_senses':alerts,'sense_evidence':evidence,
            'not_subjective_consciousness':True,
            'causal_mechanism_not_identified_from_surprise_alone':True}


def _residuals(theta,trials, prior=None):
    residuals=[]
    for tr in trials:
        pred=predict_senses(tr.body,tr.times_s,tr.applied_force_n,tr.initial_state_m_m_s,
                            tr.senses,friction_force_n=float(theta[0])*tr.body.force_reference_n)
        for key,sensor in tr.senses.items():
            # Sample balancing: high-rate modalities don't overwhelm slower ones.
            observed=np.asarray(tr.observations[key],dtype=float)
            residuals.extend(((pred['sensations'][key]-observed)/sensor.noise_std/np.sqrt(len(observed))).tolist())
    if prior is not None:
        mu,sigma=prior
        residuals.append(float((theta[0]-mu)/sigma))
    return np.asarray(residuals)


def fit_physical_feeling(train:list[Interaction], heldout:list[Interaction],*,
                         candidate_mechanism='smooth_contact_friction',max_ratio=.8,prior=None):
    """Infer normalized physical consequence from distinct intervention episodes.

    Source observations may be audio pressure, tactile, visual, etc. No fixed
    'audio=velocity' assumption: each stream requires its own calibration.
    Heldout action IDs never contribute to model fitting. Prior is optional and
    represents an already-signed source memory in deployment.
    """
    if len(train)<2 or not heldout: raise ValueError('two training interventions and one heldout required')
    ids=[t.intervention_id for t in train+heldout]
    if len(ids)!=len(set(ids)):raise ValueError('training/heldout action leakage')
    origins={t.origin for t in train+heldout}
    if len(origins)!=1:raise ValueError('cannot mix simulation and genuine physical evidence')
    if candidate_mechanism!='smooth_contact_friction':
        return {'status':'UNKNOWN_MECHANISM','reason':'candidate not in validated bounded dynamics registry'}
    if not _finite(max_ratio) or not 0<max_ratio<=1:
        raise ValueError('invalid bounded force ratio')
    if prior is not None and (len(prior)!=2 or not _finite(*prior) or prior[1]<=0 or not 0<=prior[0]<=max_ratio):
        raise ValueError('invalid source prior')
    for t in train+heldout:
        if t.body.mechanism_family!=candidate_mechanism:
            return {'status':'UNKNOWN_MECHANISM','reason':'physical mechanism family not comparable'}
    # Numerical observability: if two extreme mechanisms cannot change any
    # recorded sensory prediction, there is no identifiable causal parameter.
    observable=0.
    for tr in train:
        p0=predict_senses(tr.body,tr.times_s,tr.applied_force_n,tr.initial_state_m_m_s,tr.senses,friction_force_n=0.)
        p1=predict_senses(tr.body,tr.times_s,tr.applied_force_n,tr.initial_state_m_m_s,tr.senses,
                           friction_force_n=.1*max_ratio*tr.body.force_reference_n)
        for key,s in tr.senses.items():
            observable+=float(np.mean(((p0['sensations'][key]-p1['sensations'][key])/s.noise_std)**2))
    if observable<.25:
        return {'status':'CANNOT_IDENTIFY','reason':'calibrated sensors/experiments insensitive to candidate mechanism'}
    optimize=least_squares(lambda th:_residuals(th,train,prior),
                           [prior[0] if prior is not None else .04],bounds=(0.,max_ratio),
                           loss='soft_l1',f_scale=2.,max_nfev=120,xtol=1e-10)
    if not optimize.success and optimize.optimality>1e-4:
        return {'status':'CANNOT_IDENTIFY','reason':'nonconvergent mechanism estimation'}
    ratio=float(optimize.x[0]);test_error=float(np.sqrt(np.mean(_residuals([ratio],heldout)**2)))
    baseline_error=float(np.sqrt(np.mean(_residuals([0.],heldout)**2)))
    improvement=1-test_error/max(baseline_error,1e-12)
    # This is a statistical diagnostic under assumed model and calibration,
    # NOT a frequentist guarantee or full predictive uncertainty interval.
    jac=np.asarray(optimize.jac,dtype=float).reshape(-1)
    sensitivity=float(jac@jac)
    se=float(1./np.sqrt(sensitivity)) if sensitivity>0 else float('inf')
    status='SUPPORTED_HELDOUT' if improvement>.1 and test_error<baseline_error else 'UNKNOWN_OR_UNSUPPORTED'
    return {'status':status,'mechanism':'smooth_contact_friction',
            'normalized_friction_ratio':ratio,'approximate_parameter_se':se,
            'heldout_sensor_error_normalized':test_error,
            'heldout_baseline_error_normalized':baseline_error,
            'heldout_relative_improvement':float(improvement),
            'observability_score':observable,
            'training_interventions':[t.intervention_id for t in train],
            'heldout_interventions':[t.intervention_id for t in heldout],
            'source_bodies':list(dict.fromkeys(t.body.body_id for t in train)),
            'origin':next(iter(origins)),
            'uncertainty_status':'MODEL_CONDITIONAL_UNCALIBRATED',
            'hardware_actuation_allowed':False}


def sign_lesson(fit_result:dict,body:Body,*,evidence_digests:list[str]):
    if fit_result.get('status')!='SUPPORTED_HELDOUT':
        raise ValueError('cannot teach unverified source mechanism')
    if fit_result.get('origin')!=('simulation' if body.provenance=='simulation' else 'real_measurement'):
        raise ValueError('source origin mismatch')
    if not evidence_digests or any(len(h)!=64 or any(c not in '0123456789abcdef' for c in h) for h in evidence_digests):
        raise ValueError('raw evidence hashes required')
    payload={'schema':'physica.physical-feeling-lesson.v1','body':asdict(body),
             'mechanism_family':fit_result['mechanism'],
             'dimensionless_force_ratio':fit_result['normalized_friction_ratio'],
             'parameter_se_model_conditional':fit_result['approximate_parameter_se'],
             'calibration_scope':{'boundary_class':body.boundary_class,
                                  'force_reference_n':body.force_reference_n,
                                  'slip_velocity_scale_m_s':body.slip_velocity_scale_m_s},
             'training_action_ids':fit_result['training_interventions'],
             'heldout_action_ids':fit_result['heldout_interventions'],
             'source_origin':fit_result['origin'],'raw_evidence_sha256':evidence_digests,
             'model_family':'bounded_smooth_contact_friction',
             'confidence':'MODEL_CONDITIONAL_NOT_GENERAL_TRANSFER_VALIDATION',
             'created_utc':datetime.now(timezone.utc).isoformat()}
    return {'payload':payload,'sha256':sha256(sign.canonical(payload)).hexdigest(),
            'signature_ed25519':sign.sign(payload)}


def verify_lesson(record):
    if not isinstance(record,dict) or not isinstance(record.get('payload'),dict):return False
    return record.get('sha256')==sha256(sign.canonical(record['payload'])).hexdigest() and sign.verify(record['payload'],record.get('signature_ed25519',''))


def transfer_check(lesson,target:Body,senses:Mapping[str,Sense],*,local_probe=None):
    if not verify_lesson(lesson):return {'status':'REFUSE','reason':'tampered_or_unsigned_lesson'}
    p=lesson['payload'];src=Body(**p['body'])
    if src.provenance=='simulation' and target.provenance!='simulation':
        return {'status':'REFUSE','reason':'simulation_cannot_authorize_real_hardware'}
    if src.boundary_class!=target.boundary_class or src.mechanism_family!=target.mechanism_family:
        return {'status':'REFUSE','reason':'incompatible_mechanism_or_boundary'}
    if not senses or any((s.calibration_origin=='simulation') != (target.provenance=='simulation') for s in senses.values()):
        return {'status':'REFUSE','reason':'uncalibrated_target_sensing'}
    frequency_ratio=math.sqrt(target.stiffness_n_m/target.mass_kg)/math.sqrt(src.stiffness_n_m/src.mass_kg)
    if not .5<=frequency_ratio<=2.:
        return {'status':'REFUSE','reason':'out_of_family_resonant_dynamics'}
    ratio=float(p['dimensionless_force_ratio'])
    if not math.isfinite(ratio) or ratio<0 or ratio>.8:
        return {'status':'REFUSE','reason':'invalid_source_parameter'}
    # A similar natural frequency does not prove identical hidden mechanisms.
    # Low-force local verification must be independently recorded before use.
    if local_probe is None:return {'status':'PROBE_FIRST','reason':'hidden_dynamics_not_excluded'}
    score=verify_and_recompute_probe(lesson,target,senses,local_probe)
    if score is None:
        return {'status':'REFUSE','reason':'probe_trace_missing_invalid_or_tampered'}
    # At normalized RMS=1 a well-calibrated noise model has typical residuals.
    # A score >3 is operational *abstention*, not a certified hazard bound.
    if score>3.:
        return {'status':'REFUSE','reason':'low_force_probe_detected_unexplained_dynamics',
                'normalized_rmse':score}
    return {'status':'CONDITIONAL_TRANSFER','reason':'compatible_after_reported_local_low_force_probe',
            'must_measure_target_consequence':True,'hardware_actuation_allowed':False}


def signed_forecast(lesson,target:Body,senses:Mapping[str,Sense],times,force,initial_state,*,
                    probe:dict|None):
    result=transfer_check(lesson,target,senses,local_probe=probe)
    if result['status']!='CONDITIONAL_TRANSFER':
        return {'status':result['status'],'reason':result['reason']}
    x=predict_senses(target,times,force,initial_state,senses,
                     friction_force_n=target.force_reference_n*lesson['payload']['dimensionless_force_ratio'])
    payload={'schema':'physica.felt-forecast.v1','target':asdict(target),
             'senses':{key:asdict(s) for key,s in senses.items()},
             'time_s':list(times),'force_n':list(force),'initial_state':list(initial_state),
             'prediction':{k:v.tolist() for k,v in x['sensations'].items()},
             'expected_physical_state_m_m_s':x['physical_state'].tolist(),
             'source_lesson_sha256':lesson['sha256'],
             'probe_digest':probe['sha256'] if probe else None, 'probe':probe,'model':'action_conditioned_smooth_contact_friction',
             'origin':'simulation' if target.provenance=='simulation' else 'prospective_real_sensor',
             'calibration_notice':'conditional on independently calibrated target sensors and action',
             'hardware_actuation_allowed':False,'signed_utc':datetime.now(timezone.utc).isoformat()}
    return {'status':'SEALED','forecast':payload,
            'sha256':sha256(sign.canonical(payload)).hexdigest(),
            'signature_ed25519':sign.sign(payload)}


def verify_forecast(forecast):
    if not isinstance(forecast,dict) or forecast.get('status')!='SEALED':return False
    p=forecast.get('forecast')
    return isinstance(p,dict) and forecast.get('sha256')==sha256(sign.canonical(p)).hexdigest() and sign.verify(p,forecast.get('signature_ed25519',''))


def verify_consequence(forecast,observed:Interaction):
    if not verify_forecast(forecast):raise ValueError('invalid prediction signature')
    p=forecast['forecast']
    if asdict(observed.body)!=p['target'] or list(observed.times_s)!=p['time_s'] or list(observed.applied_force_n)!=p['force_n'] or list(observed.initial_state_m_m_s)!=p['initial_state']:
        raise ValueError('observation does not match sealed intervention/body/timing')
    if {key:asdict(sensor) for key,sensor in observed.senses.items()}!=p['senses']:
        raise ValueError('different target sensing calibration after commitment')
    errors={};z_all=[]
    for key,s in observed.senses.items():
        y=np.asarray(observed.observations[key],dtype=float)
        pred=np.asarray(p['prediction'][key],dtype=float)
        rms=float(np.sqrt(np.mean((y-pred)**2)))
        errors[key]={'rmse':rms,'unit':s.unit,'normalized_rmse':rms/s.noise_std,
                     'calibration_id':s.calibration_id}
        z_all.extend(((y-pred)/s.noise_std).tolist())
    normalized=float(np.sqrt(np.mean(np.asarray(z_all)**2)))
    # This heuristic intentionally does not certify a real system safe.
    result='CONSISTENT_WITH_PREDICTION' if normalized<=3 else 'CONTRADICTS_PREDICTION'
    payload={'schema':'physica.felt-reveal.v1','forecast_sha256':forecast['sha256'],
             'measurement_sha256':observed.evidence_sha256,'measurement_origin':observed.origin,
             'result':result,'normalized_prediction_error':normalized,
             'sense_errors':errors,'not_an_independent_timestamp_witness':True,
             'revealed_utc':datetime.now(timezone.utc).isoformat()}
    return {'status':result,'reveal':payload,'signature_ed25519':sign.sign(payload)}


def verify_reveal(reveal):
    return isinstance(reveal,dict) and isinstance(reveal.get('reveal'),dict) and sign.verify(reveal['reveal'],reveal.get('signature_ed25519',''))


def parse_body(d):return Body(**d)
def parse_senses(d):return {k:Sense(**v) for k,v in d.items()}
def parse_trial(d):
    return Interaction(d['intervention_id'],parse_body(d['body']),tuple(d['time_s']),
                       tuple(d['force_n']),tuple(d['initial_state']),
                       {k:tuple(v) for k,v in d['observations'].items()},parse_senses(d['senses']),
                       d['evidence_sha256'],d.get('origin','simulation'),d.get('human_authorized',False))


def export_trial(tr):
    return {'intervention_id':tr.intervention_id,'body':asdict(tr.body),
            'time_s':list(tr.times_s),'force_n':list(tr.applied_force_n),
            'initial_state':list(tr.initial_state_m_m_s),
            'observations':{k:list(v) for k,v in tr.observations.items()},
            'senses':{k:asdict(v) for k,v in tr.senses.items()},
            'evidence_sha256':tr.evidence_sha256,'origin':tr.origin,'human_authorized':tr.human_authorized}


def prepare_low_force_probe(lesson,target,senses,times,force,initial_state):
    """Seal an APPROVED SIMULATION/measurement request before seeing outcome.

    No actuation. For physical usage, the person running the experiment must
    independently witness it; local signatures alone do not establish chronology.
    """
    basic=transfer_check(lesson,target,senses)
    if basic['status']!='PROBE_FIRST':return {'status':basic['status'],'reason':basic['reason']}
    u=_vec(force,'probe forces',min_count=25)
    if np.max(np.abs(u)) > .35*target.force_reference_n:
        raise ValueError('low-force probe exceeds 35% of calibrated reference force')
    p=predict_senses(target,times,force,initial_state,senses,
         friction_force_n=target.force_reference_n*lesson['payload']['dimensionless_force_ratio'])
    payload={'schema':'physica.felt-probe-forecast.v1','source_lesson_sha256':lesson['sha256'],
             'target':asdict(target),'senses':{k:asdict(s) for k,s in senses.items()},
             'time_s':list(times),'force_n':list(force),'initial_state':list(initial_state),
             'prediction':{k:v.tolist() for k,v in p['sensations'].items()},
             'simulation_only_without_real_measurements':target.provenance=='simulation',
             'created_utc':datetime.now(timezone.utc).isoformat()}
    return {'status':'SEALED_PROBE','forecast':payload,
            'sha256':sha256(sign.canonical(payload)).hexdigest(),
            'signature_ed25519':sign.sign(payload)}


def verify_probe_forecast(probe):
    if not isinstance(probe,dict) or probe.get('status')!='SEALED_PROBE':return False
    p=probe.get('forecast')
    return isinstance(p,dict) and probe.get('sha256')==sha256(sign.canonical(p)).hexdigest() and sign.verify(p,probe.get('signature_ed25519',''))


def check_low_force_probe(lesson,probe,trial:Interaction):
    """Compute innovation DIRECTLY from measured traces, not supplied error JSON."""
    if not verify_lesson(lesson) or not verify_probe_forecast(probe):
        raise ValueError('tampered source lesson or probe forecast')
    f=probe['forecast']
    if f['source_lesson_sha256']!=lesson['sha256']:
        raise ValueError('probe committed with a different source memory')
    if (asdict(trial.body)!=f['target'] or list(trial.times_s)!=f['time_s'] or
        list(trial.applied_force_n)!=f['force_n'] or list(trial.initial_state_m_m_s)!=f['initial_state'] or
        {k:asdict(s) for k,s in trial.senses.items()}!=f['senses']):
        raise ValueError('probe calibration, body or action changed after commit')
    if np.max(np.abs(trial.applied_force_n))>.35*trial.body.force_reference_n:
        raise ValueError('not a low-force target probe')
    all_z=[]
    for key,s in trial.senses.items():
        all_z.extend(((np.asarray(trial.observations[key])-np.asarray(f['prediction'][key]))/s.noise_std).tolist())
    score=float(np.sqrt(np.mean(np.square(all_z))))
    measured=export_trial(trial)
    payload={'schema':'physica.low-force-probe-check.v1','lesson_sha256':lesson['sha256'],
             'probe_forecast':probe,'measured_interaction':measured,
             'normalized_rmse_computed':score,'measurement_evidence_sha256':trial.evidence_sha256,
             'chronology_independently_witnessed':False,
             'created_utc':datetime.now(timezone.utc).isoformat()}
    return {'status':'PROBE_MEASURED','payload':payload,'sha256':sha256(sign.canonical(payload)).hexdigest(),
            'signature_ed25519':sign.sign(payload)}


def verify_and_recompute_probe(lesson,target,senses,record):
    """Untrusted JSON cannot authorize transfer without a complete signed trace."""
    if not isinstance(record,dict) or record.get('status')!='PROBE_MEASURED':return None
    p=record.get('payload')
    if not isinstance(p,dict) or record.get('sha256')!=sha256(sign.canonical(p)).hexdigest() or not sign.verify(p,record.get('signature_ed25519','')):
        return None
    try:
        trial=parse_trial(p['measured_interaction'])
        probe=p['probe_forecast']
        if asdict(trial.body)!=asdict(target) or {k:asdict(v) for k,v in trial.senses.items()}!={k:asdict(v) for k,v in senses.items()}:
            return None
        recalculated=check_low_force_probe(lesson,probe,trial)
        if abs(recalculated['payload']['normalized_rmse_computed']-p['normalized_rmse_computed'])>1e-8:
            return None
        return float(recalculated['payload']['normalized_rmse_computed'])
    except (ValueError,KeyError,TypeError,IndexError):
        return None
