"""Write the remote-lab run as a script for the lab's own Python client (pycloudpendulum, Chalmers CloudPendulum).

The script is the whole loop: probe the joint gently, send the probe back to Physica (identify), apply the gains
Physica chose, record the response, and grade the sealed promise. Physica never holds your lab token; you run it.
Client calls follow the CloudPendulum onboarding page (start_experiment, set_impedance_controller_params,
set_position, get_position, stop_experiment).
"""
from __future__ import annotations


def cloudpendulum_script(goal: str, target_rad: float, probe: dict, anchor: str | None = None,
                         chosen: dict | None = None, experiment_time: float = 6.0) -> str:
    chosen_txt = (f"KP, KD = {chosen['kp']:.4f}, {chosen['kd']:.5f}  # chosen by Physica, promise {anchor}"
                  if chosen else "KP, KD = None, None  # filled after the probe by: physica outcome pendulum --probe probe.json")
    return f'''"""Physica remote-lab run. Goal: {goal}
Step 1 (probe) runs at gentle known gains; step 2 runs the gains Physica chose and records the result.
Usage:  python run_cloudpendulum.py <user_token> probe   ->  probe.json
        physica outcome "{goal}" --machine pendulum --probe probe.json   (identifies, plans, seals, rewrites this file)
        python run_cloudpendulum.py <user_token> run     ->  result.json   (then: physica outcome grade result.json)
"""
import json, math, sys, time
from pycloudpendulum import Client

TARGET = {target_rad}
PROBE_KP, PROBE_KD = {probe['kp']}, {probe['kd']}
{chosen_txt}
DT = 0.005


def run(token, kp, kd, out):
    c = Client()
    session, live = c.start_experiment(user_token=token, experiment_type="DoubleIntegrator",
                                       experiment_time={experiment_time}, preparation_time=0.0, record=True)
    print("live video:", live)
    c.set_impedance_controller_params([kp], [kd], session)
    t0 = time.time(); rows = []
    c.set_position([TARGET], session)
    while time.time() - t0 < {experiment_time} - 0.5:
        rows.append([time.time() - t0, c.get_position(session)[0], c.get_velocity(session)[0]])
        time.sleep(DT)
    video = c.stop_experiment(session)
    json.dump({{"kp": kp, "kd": kd, "target": TARGET, "t_pos_vel": rows, "video": video}}, open(out, "w"))
    print("saved", out)


if __name__ == "__main__":
    token, step = sys.argv[1], sys.argv[2]
    if step == "probe":
        run(token, PROBE_KP, PROBE_KD, "probe.json")
    else:
        assert KP is not None, "run the probe and let Physica choose the gains first"
        run(token, KP, KD, "result.json")
'''
