"""Self-models: predict what the machine itself causes, so the leftover can be felt.

OperatingPointSelfModel (SPEC 3, step 2c): when there are no command signals (e.g. PADRE flights),
predict each unit's vibration level from its current operating point (here the dominant rotor peak
frequency), fitted on healthy data only. Supports a library prior (compounding, SPEC 7): coefficients
shrink toward the relatives' curve and give way to this machine's own evidence as data accumulates.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class OperatingPointSelfModel:
    degree: int = 2
    sigma_floor: float = 0.05
    unit_names: list[str] = field(default_factory=list)
    coef: np.ndarray | None = None  # (units, degree+1), highest power first, in scaled x
    x_center: float = 0.0
    x_scale: float = 1.0
    sigma: np.ndarray | None = None
    threshold: float | None = None
    n_fit: int = 0
    prior_used: bool = False
    op_range: tuple[float, float] | None = None

    # ---------- fitting ----------
    def _design(self, x: np.ndarray) -> np.ndarray:
        xs = (np.asarray(x, float) - self.x_center) / self.x_scale
        return np.vander(xs, self.degree + 1)

    def fit(self, op: np.ndarray, level: np.ndarray, prior: "OperatingPointSelfModel | None" = None,
            lam: float = 0.0, center: float | None = None, scale: float | None = None) -> "OperatingPointSelfModel":
        """op, level: (n_windows, units). prior + lam>0 shrinks shape terms toward the prior (intercept stays free)."""
        op, level = np.asarray(op, float), np.asarray(level, float)
        n, u = op.shape
        if prior is not None:
            self.x_center, self.x_scale = prior.x_center, prior.x_scale
        else:
            self.x_center = float(np.mean(op)) if center is None else center
            self.x_scale = float(np.std(op) or 1.0) if scale is None else scale
        coefs, sig = [], []
        for k in range(u):
            X = self._design(op[:, k])
            y = level[:, k]
            P = np.zeros((self.degree + 1, self.degree + 1))
            mu = np.zeros(self.degree + 1)
            if prior is not None and lam > 0:
                pk = prior.coef[k] if prior.coef.shape[0] == u else prior.coef.mean(axis=0)
                P[:-1, :-1] = lam * np.eye(self.degree)
                mu[:-1] = pk[:-1]
            elif n <= self.degree:  # too few points: lower order via strong ridge on shape terms
                P[:-1, :-1] = 1e3 * np.eye(self.degree)
            c = np.linalg.solve(X.T @ X + P + 1e-9 * np.eye(self.degree + 1), X.T @ y + P @ mu)
            r = y - X @ c
            s = float(np.std(r, ddof=1)) if n > 2 else 0.0
            if prior is not None and prior.sigma is not None and n < 4:
                s = max(s, float(prior.sigma[k] if len(prior.sigma) == u else np.mean(prior.sigma)))
            coefs.append(c)
            sig.append(max(s, self.sigma_floor))
        self.coef, self.sigma, self.n_fit = np.array(coefs), np.array(sig), n
        self.op_range = (float(op.min()), float(op.max()))
        self.prior_used = prior is not None and lam > 0
        if not self.unit_names:
            self.unit_names = [f"u{k}" for k in range(u)]
        return self

    # ---------- use ----------
    def predict(self, op: np.ndarray) -> np.ndarray:
        op = np.asarray(op, float)
        return np.stack([self._design(op[:, k]) @ self.coef[k] for k in range(op.shape[1])], axis=1)

    def z(self, op: np.ndarray, level: np.ndarray) -> np.ndarray:
        return (np.asarray(level, float) - self.predict(op)) / self.sigma[None, :]

    def calibrate_threshold(self, op: np.ndarray, level: np.ndarray, q: float = 0.99, margin: float = 0.5) -> float:
        self.threshold = float(np.quantile(self.z(op, level).max(axis=1), q) + margin)
        return self.threshold

    # ---------- serialisation (for cards) ----------
    def to_dict(self) -> dict:
        return {"kind": "operating_point_poly", "degree": self.degree, "unit_names": self.unit_names,
                "coef": self.coef.tolist(), "x_center": self.x_center, "x_scale": self.x_scale,
                "sigma": self.sigma.tolist(), "threshold": self.threshold, "n_fit": self.n_fit,
                "prior_used": self.prior_used, "sigma_floor": self.sigma_floor, "op_range": self.op_range}

    @classmethod
    def from_dict(cls, d: dict) -> "OperatingPointSelfModel":
        m = cls(degree=d["degree"], sigma_floor=d.get("sigma_floor", 0.05), unit_names=d["unit_names"])
        m.coef, m.sigma = np.array(d["coef"]), np.array(d["sigma"])
        m.x_center, m.x_scale, m.threshold = d["x_center"], d["x_scale"], d["threshold"]
        m.n_fit, m.prior_used = d.get("n_fit", 0), d.get("prior_used", False)
        m.op_range = tuple(d["op_range"]) if d.get("op_range") else None
        return m
