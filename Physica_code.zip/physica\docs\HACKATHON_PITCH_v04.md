# Physica: A language for physical experience

**Track:** Indie — Push the Frontier. Submission deadline: **November 4, 2026, 9 PM ET** (verify the official event page for updates).

## Submission description (you can adapt, but don't upgrade unvalidated claims)

> Today's AI can describe what a machine looks like. Physica is building the next missing ability: letting machines learn **what an interaction physically causes**, predict the consequences on another calibrated body and share that experience. We combine a mechanistic dynamics twin, a transferable dimensionless causal residual (CRATE), safety-gated experiment selection and cryptographic prediction commitments. Meta's Muse Spark can contextualize the scene; SAM 3.1 can measure tracked geometry once calibrated; Muse Wonder can critique hypotheses and propose tests. We also expose a separately calibrated integration boundary for open-weight V-JEPA 2 world-model features. Our reproducible prototype evaluates the method against mechanics-only, nearest-neighbor normalized transfer, and a strong local-only baseline on 24 held-out synthetic machines, while explicitly separating simulation from hardware and model API validation.

## 180-second hero video script, with two honest production variants

- **0:00–0:12 — The reveal.** Show TWO physical strips and a sealed computer prediction *before* the measured B response. Only show a real physical reveal if you personally performed and filmed the real experiment; otherwise overlay **SYNTHETIC SIMULATION**.
- **0:12–0:30 — The ambition.** "Most AI understands descriptions of things. Physica is teaching AI to understand the consequence of touching them—and transfer that lesson between machines."
- **0:30–1:05 — Machine A experiences.** Show A's baseline and step response, explain calibrated units, hash of sensor source, modal/touch residual and source signature. The mathematical object being transferred is `r_i(τ) = (measured−twin) k/F`.
- **1:05–1:38 — The new prediction.** Show target B with different resonance/scale; the CRATE residual is transported, target physics restores physical units, prediction signed. Run experiment or synthetic observation; compare absolute and relative waveform error with matched mechanics and nearest-neighbor baseline.
- **1:38–1:50 — The refusal.** Change boundary setup C; compatibility vetoes transfer. Show destructive probe proposal rejected too.
- **1:50–2:20 — Meta matters.** On a real authorized workstation, film Spark describing uncertain scene context, SAM returning real tracked masks/boxes, Wonder producing competing hypotheses, and physically ranked safe actions. If API execution was not possible, show only actual code and **label the pipeline as integration ready, not executed**. If V-JEPA 2 was genuinely run with a calibrated readout, show it; otherwise describe it as a separate optional module.
- **2:20–2:42 — Falsifiability.** Show held-out benchmark, conservative interval coverage, normalized vs raw copying plus failure cases. One real preregistered hardware test outranks any scripted simulated animation.
- **2:42–3:00 — Close.** "A model shouldn't just say what it knows. It should remember what happened when it acted. Machines can teach other machines the consequences of physical actions. That's Physica."

## Judge Q&A

**Is 'feel' subjective experience?** No, it means calibrated action–observation–prediction-error feedback.

**Is CRATE a proven breakthrough?** No. It's a new prototype integration of established mechanics/residual/transfer ideas; real comparisons must establish novelty and external validity.

**Did you demonstrate live Meta?** Not in this supplied archive. Real APIs can be run on the user's own machine with credentials; don't assert live calls until audit logs exist.

**Is your cross-machine experiment physical?** The new CRATE benchmark is synthetic; the separate older v0.3 field commands accept user-supplied real data.

**How do you stop unsafe experiments?** Whitelisted and bounded force/risk checks; irreversible actions refused; external supervised experiments only, no actuator implementation.

**Is the prediction actually sealed before an action?** The sample Python demo seals before *generating* synthetic B data. Independently verifiable chronology for a real experiment requires a third-party witness/trusted timestamp. Signing alone does not prove time.

## Ranked completion priorities to maximize real-world competitiveness

1. **One real signed A→B transfer with a video and a blinded scale/sensor**; collect both success and failed trials.
2. **Run the actual Meta Spark + SAM + Wonder inference pipeline on real clip and sensor CSV**, showing original request IDs and uncertainty context in audited output.
3. Train and calibrate real V-JEPA/visual readout only if time/equipment permits; do not substitute an LLM guess for a physical forecast.
4. Abla­te CRATE and compare with physically matched source+target baseline and a Koopman/shared-state baseline on multiple real units.

**Winning cannot be guaranteed**; these steps increase credibility much more than renaming a feature "breakthrough".
