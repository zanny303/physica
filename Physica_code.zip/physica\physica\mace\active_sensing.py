"""Active virtual sensing / missing-sense selection for a linearized physical state.

No sensor is fabricated. A missing channel can be suggested ONLY if calibrated
sensor geometry predicts it will reduce uncertainty in the user's target state.
"""
from __future__ import annotations
import numpy as np

# Linearized x,v state; models must be backed by independent instrument calibration.
CHANNELS={
    'camera_m':{'H':(1.,0.),'unit':'m'},
    'audio_m_per_s':{'H':(0.,1.),'unit':'m/s'},
    'imu_integrated_velocity':{'H':(0.,1.),'unit':'m/s'},
    'encoder_position_m':{'H':(1.,0.),'unit':'m'},
}

def choose(prior_cov, available, candidate_sensors, target_projection=(1.,0.), *, max_cost=1.):
    C=np.asarray(prior_cov,dtype=float); t=np.asarray(target_projection,dtype=float)
    if C.shape!=(2,2) or t.shape!=(2,) or not np.isfinite(C).all() or not np.isfinite(t).all():
        raise ValueError('invalid covariance or target physical property')
    if np.min(np.linalg.eigvalsh((C+C.T)/2))<-1e-9:raise ValueError('prior uncertainty not PSD')
    C=(C+C.T)/2
    if not isinstance(available,(list,tuple)) or not isinstance(candidate_sensors,(list,tuple)):
        raise ValueError('sensor list required')
    if max_cost<0:raise ValueError('invalid cost')
    used=set();records=[]
    for name in available:
        if name not in CHANNELS:raise ValueError('unknown active channel')
        used.add(name)
    for s in candidate_sensors:
        if not isinstance(s,dict) or s.get('name') not in CHANNELS:continue
        name=s['name']
        if name in used:continue
        if s.get('calibration_verified') is not True or s.get('available_for_approved_test') is not True:continue
        sd=s.get('noise_sd');cost=s.get('cost',0);risk=s.get('risk',0)
        if any(type(v) not in (int,float) or not np.isfinite(v) for v in (sd,cost,risk)) or sd<=0 or cost<0 or risk<0 or risk>1 or cost>max_cost:continue
        h=np.asarray(CHANNELS[name]['H'])
        gain=float((t@C@h)**2/(h@C@h+sd*sd))
        records.append({'name':name,'unit':CHANNELS[name]['unit'],
                        'expected_target_variance_reduction':gain,
                        'estimated_value_per_cost':gain/(cost+.01),
                        'risk':float(risk),'status':'SUGGEST_ACQUIRE_REAL_MEASUREMENT',
                        'virtual_sensor_values_are_not_measurements':True})
    records.sort(key=lambda v:(-v['estimated_value_per_cost'],v['name']))
    return {'status':'REVIEW_ONLY' if records else 'ABSTAIN_NO_CALIBRATED_SENSOR',
            'ranking':records,'target_projection':t.tolist(),'measured_new_values':0,
            'no_actuation':True,'assumptions':'linearized state and independently calibrated sensor operators'}
