# Physica

**Muse can see and reason. Physica lets it feel.** Film any cable, strap or belt. Muse finds each one, SAM keeps it separate, and you get how hard it's pulling, from the pixels alone. A scale then proves the sealed answer right or wrong.

Built for the Meta Global AI Developer Hackathon, Indie track, Push the Frontier.

`WATCH → PIN → FEEL → GRADE`

## Where the proof is

| What | Where | Status |
|---|---|---|
| Real films from the internet: Tacoma Narrows 1940 and a 600 fps guitar | Home page, `eval/results/E35_real_footage.json`, `python -m physica.cli meta cases` | Tacoma 17.0 cycles per minute as the film plays, against a published count of 18. Guitar 80.98 and 108.52 Hz, against tuning of 82.41 and 110. These are demonstrations, because the readers were built while looking at these clips. Clips aren't in the repo: see `clips/CREDITS.txt` |
| Hidden loads on four cords, sealed, then a kitchen scale | Home page, `eval/results/real_run/` | **See the video. Not yet run when this line was written** |
| A digital twin of each guitar string, from the film alone | Home page, Try it. `physica/twin/strings.py` | Learned from the first 0.25 s, it forecast the next 0.25 s of raw pixels: match 0.90 and 0.89 |
| A digital twin of a real struck beam, from 10,000 fps film | Home page, Try it. `physica/twin/strike.py` | From the first 30 ms, it forecast the next 50 ms of raw pixels: match 0.74, 32% closer than assuming the beam stops |
| Other results on real recordings | Home page, and `eval/results/` | Saved. `python -m physica.cli verify` recomputes them |

## One language between the world, AI and machines

Feel turns motion into plain numbers with units. Muse reads those numbers and writes the machine's own file: Klipper G-code, PLC Structured Text, or an ArduPilot mission. Code checks every file, including running the PLC logic through each situation and flying the drone's path past the blade. Any failure goes back to Muse with the exact errors. `python -m physica.cli speak --allow-billed-meta`, or with `--engine muse-code` to have Meta's Muse Code agent write them. `--check FILE` checks any file you already have. Results land in `eval/results/E36_muse_writes.json`. Nothing is sent to a machine, and a person reviews each file.

**Type a change.** The page has a box for your own goal, like a new motor speed on a real lab beam. Muse reads it, code tries every place the support could go using a real recording, seals each forecast, tests it on real moments it didn't learn from, and the best becomes G-code. `physica/outcome/goalbox.py`.

## How Meta's models are used

| Model | Its job | Where |
|---|---|---|
| Muse Spark | Watches the film, names each cable by what it holds, and points at it | `physica/meta/scout.py`, `physica/touch/cables_cli.py` |
| Muse Spark | Writes machine files from what was felt, and fixes them when code rejects them | `physica/outcome/speak.py` |
| Muse Wonder | Chooses a target from a person's goal | `physica/touch/cables_cli.py` |
| SAM 3.1 | Follows each cable Muse pointed at. Its masks choose which pixels get felt | `physica/meta/scout.py` |
| Feel (a tool Muse calls) | Reads motion from the pixels, does the arithmetic, seals answers, grades them | `physica/touch/cables.py`, `physica/twin/modes.py` |

Every measured number comes from the pixels, never from generated text. Every live call leaves a receipt in `meta_receipts/`, with no key and no footage.

## Why it's real physics

A taut cable's tone rises with how hard it's pulled, so force follows the tone squared. Engineers use this on stay cables and drive belts. [A published test](https://www.mdpi.com/1424-8220/25/13/3910) with an iPhone came within 3% of accelerometers on a real cable-stayed bridge, and [the Gates 508C](https://res.cloudinary.com/iwh/image/upload/q_auto,g_center/assets/1/26/Seiffert_Industrial_508C_Sonic_Tension_Meter_Data_Sheet.pdf) measures belts this way with a sensor. What this project tests is the loop: an agent finds the cables in an ordinary film, several at once, with no sensor, and a bet locked in advance is checked by a scale.

## Run it

On Windows, double-click `Start Physica.bat`. Anywhere:

```powershell
python -m pip install -e .
python -m physica.studio --open-browser
```

Three real films are loaded and ready. Press **Run**, or remove one and add your own.

The page works without a key: upload a film of something that rings, and push its twin. To ask Muse, set `MODEL_API_KEY` and `MOCK=0` in your own terminal. All commands are on `/more`, and the run sheet is [docs/TODAY.md](docs/TODAY.md).

## Safety

A person reviews and applies everything. Each cable needs known loads first. This isn't a safety verdict on any real structure.

## Built during the event

See [docs/BUILT_DURING_EVENT.md](docs/BUILT_DURING_EVENT.md). Earlier versions from this event are in [docs/HISTORY.md](docs/HISTORY.md), which includes superseded claims.
