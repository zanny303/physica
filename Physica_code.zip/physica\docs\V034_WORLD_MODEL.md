# Physica v0.34: adaptive causal world model

An opt-in research engine in `physica/worldmodel/`. It runs alongside Physica's existing senses and changes none of them.

## How it works

| Job | Method |
|---|---|
| Model | Known physics plus a posterior over symbolic explanations, with a small neural ensemble as a check and fallback |
| Discover | Ensemble sparse regression proposes term sets, scored by Bayesian marginal likelihood with a sparsity prior |
| Reach beyond the library | If the neural check beats every explanation, it searches for periodic terms and products of simple shapes, then judges them like any other. Muse can add terms the same way |
| Learn from many machines | Adds a form's evidence across machines of one kind, and measures how much they really differ for use as a prior |
| Say when it doesn't know | "Unexplained remains" if the neural check still wins. "Rivals remain" if explanations tie, a fit needs too many terms, or two halves of the data disagree |
| Experiment | Expected information gain over the explanations still alive |
| Plan | Cross-entropy search across samples of what might be true, with every live explanation always included. It acts only if the plan holds under each one and stays inside the measured range |
| Transfer | One machine's explanation becomes another's prior, and that machine's own data can reject it. An explanation the source never settled is labeled a starting guess, not a lesson |

## Results on simulated machines (`eval/results/E29_world_model_SIMULATED.json`)

Each machine has random stiffness, damping and gain, and a hidden law. Two laws are outside the term library.

**Discovery, 110 runs**

The two "unreachable" laws are outside anything it can search, so the only right answer there is to say it can't name them.

| Method | Reachable laws (90 runs) | Unreachable laws (20 runs) | Named something wrong |
|---|---|---|---|
| **World model** | **81 right**, 9 "can't tell" | **20 correctly refused** | **0** |
| Standard sparse regression | 60 right | Can't refuse | 50 wrong or missed |
| Four-term pick (the earlier add-on) | 40 right | Can't refuse | 70 wrong or missed |

- It reports "nothing new" when nothing is there (sparse regression got 0 of 10).
- It found a periodic law outside its fixed list in 10 of 10 runs, for example `sin(3.69x + 2.20u)` for a true `sin(3.7x + 2.2u)`.
- It found the saturating law in only 3 of 10 runs, and said "can't tell" in the other 7.
- On the six laws in the term list, it got 58 of 60 against 60 of 60 for sparse regression. It said "can't tell" on the other 2, because rivals must now match across a wider range than the data covers.
- Every named explanation also had to hold on untouched data, because validation data helped choose it. None failed.

I added the search for products of shapes after the first benchmark, and added the two unreachable laws at the same time. So this benchmark helped shape the method, and new laws would be a fairer test.

**Choosing experiments, 25 runs per method**

| Method | Right | Average tests | On a harder menu with noisier sensors |
|---|---|---|---|
| Information gain | 25 | 2.08 | 25 right, 2.12 tests |
| Random tests | 25 | 2.00 | 25 right, 2.40 tests |
| Repeating one gentle test | 14 | 5.36 | 0 right, 8.00 tests |

**Information gain barely differs from random.** It ties on the standard menu and has a small edge on the harder one. Exciting the machine clearly matters, but these tests don't show that choosing cleverly matters much.

**Reaching a goal on the true machine, 30 runs**

| Planner | Plan worked if run anyway | Said act | Said act and it worked | Median final error |
|---|---|---|---|---|
| World model | 29 | 17 | **17** | 0.017 |
| Physics only | 12 | 30 | 12 | 0.053 |
| Given the true law | 30 | 30 | 30 | 0.018 |

The world model said investigate in 13 runs, each time because the plan would have gone beyond what had been measured. The one plan that really would have failed was among them, and the other 12 would have worked, so this caution has a cost. Physics only has no doubt to report, so it said act every time and failed 18 times.

**What a label means**

| Level | Evidence required |
|---|---|
| Proposed | Named by the search, or failed a later test |
| Validated | Won on validation data, which helped choose it |
| Verified | Held on data never used for fitting or choosing. Reused rows are refused by fingerprint |
| Lesson applies on this machine | Verified at the source, and predicted separate data from this machine |

**Transfer to a different machine (median test error)**

| Target samples | Lesson with check | Target only | Copied unchanged | Earned "lesson applies" |
|---|---|---|---|---|
| 15 | **0.049** | 0.390 | 0.098 | 14/20 |
| 30 | **0.034** | 0.139 | 0.098 | 15/20 |
| 60 | 0.033 | 0.034 | 0.098 | 18/20 |

The target test compares misses with sensor noise plus the uncertainty left in the fitted coefficients, and the lesson must also cut the error of known physics at least in half. A limit based on noise alone failed correct lessons for ordinary small coefficient errors: 29 of 60 passed against 51 of 60. Across 180 runs on machines with a wrong mechanism, neither limit let one through (`eval/e29b_transfer_gate.py`, separate seeds).

When the target lacked the mechanism, the lesson was rejected in all 30 runs, and copying it unchanged gave an error of 1.007 against 0.030.

These tests favour the engine in ways real machines won't: clean position, velocity and input signals, known stiffness and damping, and simple noise.

## Results on real data

Real F1 telemetry from 20 cars, full throttle on the straights with the wing closed, with no physics given. The usable speeds are only about 55–85 m/s. Sources: `eval/results/E30_world_model_f1.json` and `E30b_world_model_f1_population.json`.

**One car at a time, it couldn't settle anything.** The known power/v and drag v² pair was the top explanation for 0 of 20 cars, and the median top explanation had 54%.

**All 20 cars together, it settled on a different form than the textbook.** Each form's evidence was added across the cars:
- `1 + v^3` came first, and two separate groups of cars agreed.
- The textbook form ranked 15th of 64, and it didn't beat `1 + v^3` on any car.
- This doesn't prove `1 + v^3` is the law. It's a curve that fits a narrow speed range, and constant thrust isn't real physics. It may mean that power isn't constant along a straight, possibly from limits on hybrid deployment. **That's an untested guess.**
- The probability is also overconfident, because every car shares one session and any wrong assumption adds up across 20 cars.

**Predicting speed along whole straights was a tie.** Median end-of-straight error on later laps:

| Model | Error (m/s) |
|---|---|
| Straight line | 1.47 |
| `1 + v^3` | 1.49 |
| Textbook form | 1.55 |
| Neural network | 1.56 |
| Assuming speed doesn't change | 9.39 |

So every learned model beats doing nothing, and they can't be separated from each other. The extrapolation test I planned couldn't run, because no straight met the rule for it even after I changed the split once.

**Using many cars as the lesson gave a small gain at very few samples only** (median speed error, five draws per car):

| Samples from the car | Lesson from 19 other cars | Lesson from one car | Its own samples only |
|---|---|---|---|
| 5 | **1.68** | 1.82 | 1.94 |
| 10 | 1.58 | 1.60 | 1.60 |
| 20 | 1.62 | 1.60 | 1.60 |
| 40 | 1.53 | 1.55 | 1.56 |

At 5 samples, simply using the other cars' average with no update did about as well (1.67). These are similar machines, so this isn't transfer between different kinds of machine.

**What would actually settle the law:** data from different loads, gears or power settings. No algorithm can get that from this one session, and it's the same reason the printer test uses a known weight.

## Not established

Discovery of a new law, transfer between truly unlike machines, use on the printer, or any benefit from Muse. `muse-test` measures that last one.

## Run it

```powershell
python -m physica.worldmodel demo
python -m physica.worldmodel benchmark --seeds 10
python -m physica.worldmodel muse-test --allow-billed-meta
python eval/e30_world_model_f1.py
```
