"""Out-of-distribution stress: shows low-force probes can miss target changes."""
import json
import numpy as np
from physica.feeling.core import Body
from physica.feeling.v08_benchmark import produce_episode,local_coefficient,rmse_camera
from physica.feeling.prospective_v08 import simulate_future
from physica.feeling.mechanism_transfer import discover_and_sign,make_target_probe_certificate
from physica.feeling.hierarchical_transfer_v08 import combine_source_and_probe

A=Body('source',.12,22.,.13,.25,1.)
B=Body('target',.14,24.,.15,.28,1.)
train=[produce_episode(A,f'train{i}',.22,.01,seed=70+i,amplitude=.07+i*.018) for i in range(2)]
val=[produce_episode(A,'heldout',.22,.01,seed=80,amplitude=.095)]
lesson=discover_and_sign(A,train,val,displacement_reference_m=.01)
rows=[]
for beta in [.22,.30,.40,.50,.80]:
    probe=produce_episode(B,f'probe{beta}',beta,.01,seed=91,amplitude=.025)
    cert=make_target_probe_certificate(lesson,B,probe,displacement_reference_m=.01)
    main=produce_episode(B,f'unseen{beta}',beta,.01,seed=120,amplitude=.105,phase=.6)
    t=main['times_s'];u=main['true_applied_force_n'];init=main['initial_state_m_m_s']
    true=np.column_stack([main['displacement_m'],main['velocity_m_s']])
    local=simulate_future(B,t,u,init,beta=local_coefficient(B,probe,.01))
    row={'true_beta_hidden_from_forecaster':beta,'low_force_probe_status':cert['status'],
         'local_only_rmse_mm':rmse_camera(local,true),'source_plus_probe_rmse_mm':None}
    if cert['status']=='ACCEPT_PROBE_MODEL_CONDITIONAL':
        fused=combine_source_and_probe(lesson,B,probe,.01,certificate=cert,between_machine_sigma=.02)
        combined=simulate_future(B,t,u,init,beta=fused['coefficient'])
        row['source_plus_probe_rmse_mm']=rmse_camera(combined,true)
        row['source_weight']=fused['source_weight']
    rows.append(row)
out={'origin':'SIMULATED_ONLY','status':'STRESS_TEST_NOT_FIELD_PROOF','rows':rows,
    'warning':'Low-force source-compatible probe may not identify strong-amplitude nonlinear parameter shifts; do not claim safe transfer under unverified dynamics.'}
print(json.dumps(out,indent=2))
open('examples/v08_prospective/shift_stress_SIMULATED.json','w').write(json.dumps(out,indent=2)+'\n')
