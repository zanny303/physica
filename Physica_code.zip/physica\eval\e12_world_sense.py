"""E12 - World Sense: sense how printed plastic works from real prints, experiment inside, act through G-code.

Real data: 50 tensile prints (Selcuk University, Ultimaker S5; PLA and ABS). Set PHYSICA_PRINT_DATA (see DATA.md).
  A. What it sensed: law constants with 95% CIs; what the data can't separate (aliased settings).
  B. Does the inner world predict real prints it never saw? Leave-one-out vs black-box models; 90% interval coverage.
  C. Understanding vs memorising: train on part of the range, predict prints outside it.
  D. Experiments: find a print >= 30 MPa using the fewest real prints, with the 50 real prints as the answer key.
  E. Act: the lightest bar that holds 5 kg (inner experiments + beam physics) -> G-code, checked; the rival-theory
     test (fan vs heat) -> G-code if it is worth printing. Predictions are written before any real test exists.
"""
from __future__ import annotations

import datetime as dt
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import norm
from sklearn.ensemble import RandomForestRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel
from sklearn.linear_model import Ridge

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica.act import contract  # noqa: E402
from physica.world import bar, data, gcode_part, laws, sense  # noqa: E402

OUT = ROOT / "eval" / "results"
GOUT = OUT / "world"
NUM = ["layer_height", "wall_thickness", "infill_density", "nozzle_temperature", "bed_temperature", "print_speed",
       "fan_speed"]


def features(X):
    cols = [np.asarray(X[c], float) for c in NUM]
    cols += [(X["material"] == "pla").astype(float), (X["infill_pattern"] == "grid").astype(float)]
    return np.column_stack(cols)


class BlackBox:
    def __init__(self, kind, seed=0, trees=300):
        self.kind, self.seed, self.trees = kind, seed, trees

    def fit(self, X, y):
        F = features(X)
        self.mu, self.sd = F.mean(0), F.std(0) + 1e-9
        Z, ly = (F - self.mu) / self.sd, np.log(y)
        if self.kind == "linear":
            self.m = Ridge(alpha=1.0).fit(Z, ly)
        elif self.kind == "forest":
            self.m = RandomForestRegressor(self.trees, min_samples_leaf=2, random_state=self.seed).fit(Z, ly)
        else:
            k = ConstantKernel(1.0) * RBF(np.ones(Z.shape[1]), (1e-2, 1e3)) + WhiteKernel(0.05, (1e-4, 1.0))
            self.m = GaussianProcessRegressor(k, normalize_y=True, random_state=self.seed).fit(Z, ly)
        return self

    def predict(self, X, std=False):
        Z = (features(X) - self.mu) / self.sd
        if self.kind == "gp":
            m, s = self.m.predict(Z, return_std=True)
            return (np.exp(m), m, s) if std else np.exp(m)
        return np.exp(self.m.predict(Z))


def boot_ci(v, n=2000, seed=0):
    rng = np.random.default_rng(seed)
    v = np.asarray(v, float)
    b = [rng.choice(v, len(v)).mean() for _ in range(n)]
    return [float(np.quantile(b, 0.025)), float(np.quantile(b, 0.975))]


def loo_blackbox(kind, X, y):
    n = len(y)
    pred = np.zeros(n)
    cover = np.zeros(n, bool)
    for i in range(n):
        m = np.arange(n) != i
        bb = BlackBox(kind).fit(sense.take(X, m), y[m])
        if kind == "gp":
            p, mu, s = bb.predict(sense.take(X, [i]), std=True)
            cover[i] = abs(np.log(y[i]) - mu[0]) <= 1.645 * s[0]
            pred[i] = p[0]
        else:
            pred[i] = bb.predict(sense.take(X, [i]))[0]
    return pred, cover


def part_b(X, y):
    out = {}
    loo = sense.leave_one_out(laws.STRENGTH, X, y, k=300)
    out["world_sense (physics law)"] = {"mae": float(loo["abs_err"].mean()), "mae_ci95": boot_ci(loo["abs_err"]),
                                        "coverage_90": float(loo["covered"].mean())}
    for kind in ("linear", "forest", "gp"):
        p, cov = loo_blackbox(kind, X, y)
        e = np.abs(p - y)
        out[kind] = {"mae": float(e.mean()), "mae_ci95": boot_ci(e)}
        if kind == "gp":
            out[kind]["coverage_90"] = float(cov.mean())
    out["predict_the_average"] = {"mae": float(np.abs(y - y.mean()).mean())}
    return out


SPLITS = {"infill <=50% -> predict 60-90%": ("infill_density", 50),
          "walls <=5 mm -> predict 6-10 mm": ("wall_thickness", 5),
          "layers <=0.1 mm -> predict 0.15-0.2 mm": ("layer_height", 0.1)}


def part_c(X, y):
    out = {}
    for name, (col, cut) in SPLITS.items():
        tr, te = X[col] <= cut, X[col] > cut
        Xtr, Xte = sense.take(X, tr), sense.take(X, te)
        row = {"n_train": int(tr.sum()), "n_test": int(te.sum())}
        ws = sense.WorldSense(laws.STRENGTH).fit(Xtr, y[tr])
        p = ws.predict(Xte, k=400)
        e = np.abs(p["median"] - y[te])
        row["world_sense"] = {"mae": float(e.mean()), "mae_ci95": boot_ci(e),
                              "coverage_90": float(((y[te] >= p["lo"]) & (y[te] <= p["hi"])).mean())}
        for kind in ("linear", "forest", "gp"):
            e = np.abs(BlackBox(kind).fit(Xtr, y[tr]).predict(Xte) - y[te])
            row[kind] = {"mae": float(e.mean()), "mae_ci95": boot_ci(e)}
        row["predict_train_average"] = {"mae": float(np.abs(y[te] - y[tr].mean()).mean())}
        out[name] = row
    return out


def part_d(X, y, goal=30.0, n_start=4, seeds=300):
    """Pool-based: each strategy may 'print' only prints that really exist and sees the true result."""
    n = len(y)
    hits = y >= goal

    def p_meet(strategy, obs, cand):
        Xo, yo, Xc = sense.take(X, obs), y[obs], sense.take(X, cand)
        if strategy == "world_sense":
            s = sense.WorldSense(laws.STRENGTH).fit(Xo, yo).imagine(Xc, k=200)
            return (s >= goal).mean(0)
        if strategy == "gp":
            _, mu, sd = BlackBox("gp").fit(Xo, yo).predict(Xc, std=True)
            return 1 - norm.cdf((np.log(goal) - mu) / np.maximum(sd, 1e-6))
        if strategy == "forest_greedy":
            return BlackBox("forest", trees=100).fit(Xo, yo).predict(Xc)
        raise ValueError(strategy)

    # every strategy starts from the same n_start random prints that all MISS the goal, then counts the extra
    # real prints it needs; random search = expected position of the first hit in a random order of the rest
    res = {s: [] for s in ("random", "world_sense", "gp", "forest_greedy")}
    misses = np.where(~hits)[0]
    for seed in range(seeds):
        rng = np.random.default_rng(seed)
        start = list(rng.choice(misses, n_start, replace=False))
        rest = rng.permutation([i for i in range(n) if i not in start])
        res["random"].append(int(np.argmax(hits[rest]) + 1))
        for strat in ("world_sense", "gp", "forest_greedy"):
            obs = list(start)
            while not hits[obs].any():
                cand = [i for i in range(n) if i not in obs]
                score = p_meet(strat, np.array(obs), np.array(cand))
                obs.append(cand[int(np.argmax(score))])
            res[strat].append(len(obs) - n_start)
    out = {"goal": f"find a print with tensile strength >= {goal:.0f} MPa", "prints_meeting_goal": int(hits.sum()),
           "of": n, "start": f"{n_start} random prints that miss the goal", "counted": "extra real prints needed",
           "seeds": seeds}
    for s, v in res.items():
        v = np.array(v)
        out[s] = {"mean_prints": float(v.mean()), "mean_ci95": boot_ci(v), "median": float(np.median(v)),
                  "found_within_3_prints": float((v <= 3).mean())}
    return out


def main():
    X = data.load()
    rows = data.original_prints(data._rows(data.default_path()))
    temp_rule, speed_rule = data.couplings(rows)
    y = X["tension_strength"]
    res = {"data": {"prints": int(len(y)), "pla": int((X["material"] == "pla").sum()),
                    "source": "Selcuk University / Ultimaker S5 tensile prints (Kaggle afumetto/3dprinter)"}}

    # A: what it sensed
    ws = sense.WorldSense(laws.STRENGTH).fit(X, y)
    wr = sense.WorldSense(laws.ROUGHNESS).fit(X, X["roughness"])
    res["A_sensed"] = {
        "strength_law": laws.STRENGTH.name, "strength_constants": ws.constants(), "strength_scatter_log": ws.sigma,
        "roughness_constants": wr.constants(), "roughness_scatter_log": wr.sigma,
        "cant_tell_apart": sense.alias_map(X, ["nozzle_temperature", "bed_temperature", "fan_speed", "print_speed",
                                               "layer_height", "wall_thickness", "infill_density"], within="material"),
        "seen_ranges": ws.seen}
    rl = sense.leave_one_out(laws.ROUGHNESS, X, X["roughness"], k=300)
    res["A_sensed"]["roughness_loo"] = {"mae_um": float(rl["abs_err"].mean()), "coverage_90": float(rl["covered"].mean())}
    print("A done")
    res["B_unseen_prints"] = part_b(X, y)
    print("B done")
    res["C_outside_the_data"] = part_c(X, y)
    print("C done")
    from multiprocessing import Pool
    with Pool(2) as pool:
        d30, d33 = pool.starmap(part_d, [(X, y, 30.0), (X, y, 33.0)])
    res["D_fewest_real_prints"] = {"goal_30": d30, "goal_33": d33}
    print("D done")

    # E: act
    GOUT.mkdir(parents=True, exist_ok=True)
    d = bar.design(ws, goal_kg=5.0, temp_rule=temp_rule, speed_rule=speed_rule)
    c = d["choice"]
    p = contract.promise(
        f"Print bar_5kg.gcode ({c['width_mm']:.0f} x {c['height_mm']:.1f} mm PLA bar, {c['mass_g']:.1f} g)",
        f"Resting on two supports {c['span_mm']:.0f} mm apart, it holds 5 kg hung at the middle for 60 s. "
        f"Predicted break: {c['break_kg_median']:.1f} kg (90% range {c['break_kg_90'][0]:.1f}-{c['break_kg_90'][1]:.1f}).",
        [{"metric": "held_5kg_60s", "op": ">=", "value": 1, "say": "holds 5 kg for 60 s"},
         {"metric": "break_kg", "op": ">=", "value": round(c["break_kg_90"][0], 2), "say": "breaks above the 90% low end"},
         {"metric": "break_kg", "op": "<=", "value": round(c["break_kg_90"][1], 2), "say": "breaks below the 90% high end"}])
    g = gcode_part.bar_gcode(c, title="Physica: lightest bar for 5 kg",
                             notes=[f"promise {p['digest']}: {p['text']}"])
    (GOUT / "bar_5kg.gcode").write_text(g)
    d["gcode_check"] = gcode_part.check(g, expect_mass_g=c["mass_g"])
    d["promise"] = p
    res["E_act"] = {"bar": d}

    rivals = {}
    for m in ("pla", "abs"):
        r = bar.rival_temperature_theories(ws, c, temp_rule, material=m)
        if r["worth_printing"]:
            files = []
            for k, run in enumerate(r["runs"]):
                spec = {**c, "material": m, "nozzle_temperature": run["nozzle_temperature"],
                        "fan_speed": run["fan_speed"], "bed_temperature": run["bed_temperature"]}
                spec["mass_g"] = bar.mass_g(c["length_mm"], c["width_mm"], c["height_mm"], c["wall_mm"], c["infill"], m)
                name = f"test_{m}_nozzle{run['nozzle_temperature']:.0f}_fan{run['fan_speed']:.0f}.gcode"
                gg = gcode_part.bar_gcode(spec, title=f"Physica rival-theory test bar {k + 1}/4",
                                          notes=["Print 2 of each. Break each one; record the weight at the break.",
                                                 f"{m.upper()} warps: use an enclosure if you have one."])
                (GOUT / name).write_text(gg)
                files.append({"file": name, "check": gcode_part.check(gg, spec["mass_g"], material=m)})
            r["gcode"] = files
        rivals[m] = r
    res["E_act"]["fan_or_heat_test"] = rivals
    res["made_at_utc"] = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    (OUT / "E12_world_sense.json").write_text(json.dumps(res, indent=1, default=float))
    pred_dir = ROOT / "predictions"
    pred_dir.mkdir(exist_ok=True)
    (pred_dir / "world_bar_5kg.json").write_text(json.dumps(
        {"promise": p, "design": c, "fan_or_heat": {m: {"say": r["say"], "runs": r["runs"]} for m, r in rivals.items()}},
        indent=1, default=float))
    print(json.dumps({k: res[k] for k in ("B_unseen_prints", "C_outside_the_data", "D_fewest_real_prints")},
                     indent=1, default=float))


if __name__ == "__main__":
    main()
