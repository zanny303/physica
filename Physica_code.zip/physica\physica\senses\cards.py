"""Sense cards and the 'unify' step of the Feel Transform (SPEC section 3, step 1)."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from math import gcd

import numpy as np
from scipy.signal import resample_poly


@dataclass
class SenseCard:
    channel: str
    units: str
    fs: float
    delay_s: float = 0.0
    noise_rms: float | None = None
    source: str = ""
    calibration: str = "datasheet"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Stream:
    card: SenseCard
    x: np.ndarray  # (N,) or (N, k)


def noise_floor(x: np.ndarray) -> float:
    """Robust noise estimate: median absolute successive difference / (0.6745*sqrt(2))."""
    d = np.diff(np.asarray(x, float), axis=0)
    return float(np.median(np.abs(d - np.median(d, axis=0))) / (0.6745 * np.sqrt(2)))


def unify(streams: dict[str, Stream], fs: float | None = None) -> tuple[dict[str, np.ndarray], float, dict[str, SenseCard]]:
    """Resample every stream to a common rate, shift known delays, record noise floors."""
    target = fs or max(s.card.fs for s in streams.values())
    out, cards = {}, {}
    for name, s in streams.items():
        x = np.asarray(s.x, float)
        if abs(s.card.fs - target) > 1e-9:
            up, down = int(round(target)), int(round(s.card.fs))
            g = gcd(up, down)
            x = resample_poly(x, up // g, down // g, axis=0)
        shift = int(round(s.card.delay_s * target))
        if shift > 0:
            x = x[shift:]
        card = SenseCard(**{**s.card.to_dict(), "fs": target})
        card.noise_rms = noise_floor(x)
        out[name], cards[name] = x, card
    n = min(len(v) for v in out.values())
    return {k: v[:n] for k, v in out.items()}, target, cards
