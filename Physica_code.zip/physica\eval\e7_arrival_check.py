"""E7: arrival check. A card learned on one arm is carried to another arm ('a new body').

For every (card arm i) x (arrival arm j) pair, check the card on arm j's healthy calibration windows.
Correct behaviour: 'fits' when i == j, 'doesn't fit here' when the body differs enough to matter.
Then re-learn only the failing part and check again. Also: a healthy-flight card must NOT fit a damaged flight.
"""
from __future__ import annotations

import numpy as np

from common import SINGLE, healthy_split, padre_features, save_result
from physica.feel.selfmodel import OperatingPointSelfModel
from physica.library import arrival


def main():
    split = healthy_split()
    h = padre_features("0000")
    cal = np.array(split["calib"])
    half = len(cal) // 2
    fit_idx, arr_idx = cal[:half], cal[half:]  # card learned on early windows, arrival check on later ones
    full = OperatingPointSelfModel(unit_names=list("ABCD")).fit(h["op"][fit_idx], h["lvl"][fit_idx])
    hw = arrival.conformal_halfwidth(full.z(h["op"][fit_idx], h["lvl"][fit_idx]), coverage=0.9)
    matrix, after = {}, {}
    for i, ci in enumerate("ABCD"):
        card = OperatingPointSelfModel(unit_names=[ci])
        card.coef, card.sigma = full.coef[i:i + 1], full.sigma[i:i + 1]
        card.x_center, card.x_scale = full.x_center, full.x_scale
        for j, cj in enumerate("ABCD"):
            v = arrival.check(card, h["op"][arr_idx, j:j + 1], h["lvl"][arr_idx, j:j + 1], hw)
            matrix[f"{ci}->{cj}"] = {"verdict": v["verdict"], "coverage": v["units"][0]["coverage"],
                                     "median_z": v["units"][0]["median_z"]}
            if v["verdict"] != "fits":
                card2, changed = arrival.relearn_failing(card, h["op"][arr_idx, j:j + 1], h["lvl"][arr_idx, j:j + 1], [ci])
                # re-check on held-out healthy windows of the new arm (not the windows used to re-learn)
                ho = np.array(split["heldout"])
                v2 = arrival.check(card2, h["op"][ho, j:j + 1], h["lvl"][ho, j:j + 1], hw)
                after[f"{ci}->{cj}"] = {"changed": changed, "verdict_after_relearn_on_heldout": v2["verdict"],
                                        "coverage": v2["units"][0]["coverage"]}
    same = [matrix[f"{c}->{c}"]["verdict"] == "fits" for c in "ABCD"]
    diff = [matrix[f"{a}->{b}"]["verdict"] != "fits" for a in "ABCD" for b in "ABCD" if a != b]
    # damaged flights should not pass as 'healthy' for the damaged rotor's own arm
    dmg_rows = {}
    for r in "ABCD":
        i = "ABCD".index(r)
        card = OperatingPointSelfModel(unit_names=[r])
        card.coef, card.sigma = full.coef[i:i + 1], full.sigma[i:i + 1]
        card.x_center, card.x_scale = full.x_center, full.x_scale
        for c in SINGLE[r]:
            d = padre_features(c)
            v = arrival.check(card, d["op"][:, i:i + 1], d["lvl"][:, i:i + 1], hw)
            dmg_rows[c] = v["verdict"]
    out = {"conformal_halfwidth_z": hw, "matrix": matrix, "after_relearn": after,
           "same_arm_fits_rate": float(np.mean(same)), "different_arm_rejected_rate": float(np.mean(diff)),
           "damaged_flight_rejected_rate": float(np.mean([v != "fits" for v in dmg_rows.values()])),
           "damaged_flight_verdicts": dmg_rows}
    save_result("E7_arrival_check", out)
    print(f"same arm fits: {out['same_arm_fits_rate']:.2f}  different arm rejected: {out['different_arm_rejected_rate']:.2f}  "
          f"damaged flight rejected: {out['damaged_flight_rejected_rate']:.2f}")
    print("after re-learning only the failing part (checked on held-out windows):",
          {k: v["verdict_after_relearn_on_heldout"] for k, v in after.items()})


if __name__ == "__main__":
    main()
