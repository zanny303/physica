"""Write a support move in G-code that real motion firmware runs.

Two dialects: Klipper (MANUAL_STEPPER, for a lead-screw stage on a Klipper
board) and GRBL/Marlin (G1 on axis X). The Klipper config also writes the
felt range as hard position limits, so the firmware itself refuses any move
to a place the beam's map has never felt.
"""
from __future__ import annotations


def klipper_config(min_mm: float, max_mm: float, rotation_distance_mm: float = 8.0, microsteps: int = 16,
                   step_pin: str = "gpio20", dir_pin: str = "gpio21", enable_pin: str = "!gpio22") -> str:
    return f"""# Physica: support actuator for the beam. Limits = the positions the beam's map has felt.
[mcu]
serial: /tmp/klipper_host_mcu

[printer]
kinematics: none
max_velocity: 50
max_accel: 500

[manual_stepper support]
step_pin: {step_pin}
dir_pin: {dir_pin}
enable_pin: {enable_pin}
microsteps: {microsteps}
rotation_distance: {rotation_distance_mm}
velocity: 5
accel: 50
position_min: {min_mm:.3f}
position_max: {max_mm:.3f}
"""


def klipper_move(from_mm: float, to_mm: float, anchor: str, settle_s: float = 1.5, speed: float = 5.0) -> str:
    return (f"; Physica plan, sealed promise {anchor}\n"
            f"MANUAL_STEPPER STEPPER=support ENABLE=1\n"
            f"MANUAL_STEPPER STEPPER=support SET_POSITION={from_mm:.3f}\n"
            f"MANUAL_STEPPER STEPPER=support MOVE={to_mm:.3f} SPEED={speed:g} ACCEL=50\n"
            f"G4 P{int(settle_s * 1000)}\n"
            f"; now listen: the promise says where the tone will be\n")


def grbl_move(from_mm: float, to_mm: float, anchor: str, settle_s: float = 1.5, feed_mm_min: float = 300) -> str:
    return (f"( Physica plan, sealed promise {anchor} )\n"
            f"G21 G90\nG92 X{from_mm:.3f}\nG1 X{to_mm:.3f} F{feed_mm_min:g}\nG4 P{settle_s:g}\nM2\n")
