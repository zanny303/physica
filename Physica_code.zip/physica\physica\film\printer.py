"""Clips made from your own printer films: the shake made visible, and the wall Physica forecasts before you print it."""
from __future__ import annotations

from pathlib import Path

import numpy as np

from physica.experiment import printer as P
from physica.touch import printer_video as PV
from physica.touch import video

from . import style as S


def _stops(V: np.ndarray, fps: float, f: float, every: int = 2, most: int = 3) -> list[dict]:
    """The moments after each stop, with the head's measured motion at the felt tone. Every other stop, so the head is
    in the same place each time."""
    from scipy.signal import butter, sosfiltfilt

    out = []
    for w in PV.pauses(V, fps)[::every][:most]:
        seg = V[w]
        mo = video.motion(seg, wavelength=6, sigma=2.5, step=2, keep=0.15, direction="horizontal")
        Y = mo["signals"]
        power = (Y ** 2).mean(0)
        strong = power >= np.quantile(power, 0.7)
        x = np.median(Y[:, strong], axis=1)
        sos = butter(2, [0.6 * f / (fps / 2), min(1.4 * f / (fps / 2), 0.99)], btype="band", output="sos")
        out.append({"frames": seg, "x": sosfiltfilt(sos, x), "rows": mo["rows"][strong], "cols": mo["cols"][strong]})
    if not out:
        raise ValueError("no stops found in this film: same G-code, and keep the head in frame")
    return out


def _box(stop: dict, shape, pad: float = 0.5, aspect: float = 16 / 10) -> tuple[int, int, int, int]:
    """Close in on what moves."""
    r0, r1 = np.quantile(stop["rows"], [.05, .95])
    c0, c1 = np.quantile(stop["cols"], [.05, .95])
    h, w = max(r1 - r0, 12) * (1 + pad), max(c1 - c0, 12) * (1 + pad)
    h, w = max(h, w / aspect), max(w, h * aspect)
    cy, cx = (r0 + r1) / 2, (c0 + c1) / 2
    y0, x0 = int(max(cy - h / 2, 0)), int(max(cx - w / 2, 0))
    return y0, int(min(y0 + h, shape[0])), x0, int(min(x0 + w, shape[1]))


def _shift(frame: np.ndarray, dx: float) -> np.ndarray:
    import cv2
    return cv2.warpAffine(frame, np.float32([[1, 0, dx], [0, 1, 0]]), (frame.shape[1], frame.shape[0]), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def shake(before: np.ndarray, out: str | Path, felt: dict, fps: float, after: np.ndarray | None = None, fps_after: float | None = None,
          drop: float | None = None, simulated: bool = False) -> dict:
    """Same magnification on both films, so what you see shrink is the measured motion shrinking."""
    f = float(felt["freq_hz"])
    A = _stops(before, fps, f)
    B = _stops(after, fps_after or fps, f) if after is not None else None
    n_stops = min(len(A), len(B)) if B else len(A)
    y0, y1, x0, x1 = _box(A[0], before.shape[1:])
    width = x1 - x0
    peak = max(float(np.abs(s["x"]).max()) for s in A[:n_stops])
    gain = float(np.clip(0.10 * width / max(peak, 1e-3), 1, 200))
    frames = [(i, k) for i in range(n_stops) for k in range(len(A[i]["frames"]))]
    tag = ("SIMULATED FILM" if simulated else "YOUR FILM") + f" · motion x{gain:.0f}, measured from pixels"

    def panel(fig, rect, stop, k, title, colour):
        ax = S.axes(fig, rect, off=True)
        m = min(k, len(stop["frames"]) - 1)
        im = _shift(stop["frames"][m], (gain - 1) * float(stop["x"][m]))[y0:y1, x0:x1]
        ax.imshow(im, cmap="gray", vmin=0, vmax=1, interpolation="bicubic", aspect="equal")
        fig.text(rect[0] + rect[2] / 2, rect[1] + rect[3] + 0.02, title, color=colour, fontsize=28, fontweight="bold", ha="center")

    def draw(fig, t):
        i, k = frames[min(int(t * S.FPS), len(frames) - 1)]
        S.headline(fig, "The shake you can't see")
        S.label(fig, tag)
        if B:
            panel(fig, [0.03, 0.34, 0.45, 0.52], A[i], k, "BEFORE", S.AMBER)
            panel(fig, [0.52, 0.34, 0.45, 0.52], B[i], k, "AFTER THE FIX", S.TEAL)
        else:
            panel(fig, [0.25, 0.34, 0.5, 0.52], A[i], k, "THE HEAD, AFTER IT STOPS", S.AMBER)
        ax = S.axes(fig, [0.06, 0.11, 0.62, 0.17])
        tt = np.arange(len(A[i]["x"])) / fps * 1000
        ax.plot(tt, A[i]["x"], color=S.AMBER, lw=2.2)
        if B:
            xb = B[i]["x"][:len(tt)]
            ax.plot(tt[:len(xb)], xb, color=S.TEAL, lw=2.2)
        ax.axvline(tt[min(k, len(tt) - 1)], color=S.FG, lw=1.2)
        ax.set_xlabel("milliseconds after the stop")
        ax.set_ylabel("pixels")
        fig.text(0.72, 0.235, f"Felt {f:.1f} Hz", color=S.FG, fontsize=38, fontweight="bold", va="center")
        fig.text(0.72, 0.17, "from pixels, no sensor, in slow motion", color=S.DIM, fontsize=17, va="center")
        if drop is not None:
            fig.text(0.72, 0.10, f"Ringing {'down' if drop >= 0 else 'up'} {abs(100 * drop):.0f}%", color=S.TEAL if drop >= 0 else S.RED, fontsize=34, fontweight="bold", va="center")

    S.render(out, draw, len(frames) / S.FPS)
    return {"out": str(out), "motion_gain": round(gain, 1), "stops": n_stops, "peak_px": round(peak, 3)}


def _wall(spacing: float, zeta_cycles: float, depth: float, layers_done: float, n_layers: int = 80, length_mm: float = 40.0, per_mm: int = 24) -> np.ndarray:
    """A wall seen from the side, lit from one side so ripples show. Depth is exaggerated, and identical on both walls."""
    x = np.arange(int(length_mm * per_mm)) / per_mm
    ripple = depth * np.exp(-zeta_cycles * x / spacing) * np.cos(2 * np.pi * x / spacing)
    slope = np.gradient(ripple, x)
    shade = np.clip(0.55 + 2.2 * slope, 0.05, 1.0)
    layer_px = 7
    wall = np.zeros((n_layers * layer_px, len(x)))
    bead = 0.8 + 0.2 * np.sin(np.linspace(0, np.pi, layer_px))
    done = int(layers_done)
    for j in range(done):
        wall[(n_layers - 1 - j) * layer_px:(n_layers - j) * layer_px] = shade[None, :] * bead[:, None]
    return wall


def wall_film(sealed: dict, out: str | Path, seconds: float = 9.0) -> str:
    """The forecast as a picture, labelled as simulation, ready to cut against the real part."""
    p = sealed["payload"]["prediction"]
    f, z, v = p["felt_hz"], p["damping"], p["wall_speed_mm_s"]
    spacing = p["spacing_mm"]
    decay = 2 * np.pi * max(z, 0.01)
    left = P.zv_residual(p["tone_range_hz"][1], z, f, z)     # the worst edge of the range, so the fixed wall isn't shown as perfect
    length = 40.0

    def draw(fig, t):
        S.headline(fig, "Sealed before printing: where the ripples fall")
        S.label(fig, "SIMULATED WALL · depth exaggerated · from the felt tone")
        layers = 1 + S.ease(t / 5.0) * 79
        for x0, depth, title, col in ((0.03, 1.0, "NO FIX", S.AMBER), (0.52, left, f"WITH THE FIX ({100 * left:.0f}% of the ringing, at worst)", S.TEAL)):
            ax = S.axes(fig, [x0, 0.40, 0.45, 0.46], off=True)
            ax.imshow(_wall(spacing, decay, 0.14 * depth, layers), cmap="gray", vmin=0, vmax=1, aspect="auto", extent=[0, length, 0, 20], interpolation="bilinear")
            ax.set_xlim(0, length)
            fig.text(x0 + 0.225, 0.88, title, color=col, fontsize=25, fontweight="bold", ha="center", va="center")
            ax2 = S.axes(fig, [x0, 0.355, 0.45, 0.04], off=True)
            ax2.set_xlim(0, length)
            ax2.set_ylim(0, 1)
            ax2.text(0, .5, "corner", color=S.DIM, fontsize=15, va="center")
            if depth == 1.0:
                ticks = spacing * np.arange(2, 8)
                ax2.plot(ticks, [.5] * len(ticks), "|", ms=18, color=S.AMBER, mew=2.5)
        a = S.fade(t, 5.0)
        fig.text(0.03, 0.27, f"{spacing:.2f} mm", color=S.TEAL, fontsize=70, fontweight="bold", va="center", alpha=a)
        fig.text(0.03, 0.195, f"between ripples  (sealed range {p['spacing_range_mm'][0]:.2f} to {p['spacing_range_mm'][1]:.2f})", color=S.FG, fontsize=23, va="center", alpha=a)
        fig.text(0.52, 0.27, f"{v:.0f} mm/s wall speed ÷ {f:.1f} Hz", color=S.FG, fontsize=30, va="center", alpha=a, fontweight="bold")
        fig.text(0.52, 0.205, f"sealed: {sealed['anchor']}", color=S.AMBER, fontsize=24, family="monospace", va="center", alpha=a)
        S.caption(fig, "Next: print the real part and put calipers on it. The calipers never see the camera.", S.fade(t, 6.0))

    return S.render(out, draw, seconds)
