"""E23 - Program machines by outcome: say what you want, Physica writes the machine code and lets reality grade it.

Three machines, three machine languages, each checked by that machine's own real toolchain:

A. BEAM (REAL DATA, DROPBEAR Dataset-8). Goal: "a pump beside this beam runs at F Hz; keep the beam's tone at least 5%
   away from it; move the support as little as possible". Physica's map of the beam (support position -> tone, with
   local conformal error bars) is learned ONLY from the July 2022 slow sweep. Plans are graded on the June 2022
   random-position recordings (different day, different sequences): at the position Physica chose, did the real beam
   ring outside the danger band, and inside the sealed interval? Goals: every F from 25 to 42 Hz (0.5 Hz steps) x every
   position the actuator's index set commands. Moves are written as Klipper G-code with the felt range as firmware
   limits, and run through real Klipper (batch mode). Ablations: the same planner WITHOUT error bars, and "always
   move to the far end".
   Honest notes: the candidate positions are the actuator's preset positions (taken from the June trials' positions,
   never their tones); the DROPBEAR actuator is driven by LabVIEW, so the G-code is for a G-code-driven stage doing
   the same move.

B. WIND TURBINE (REAL VERDICTS from E20, ETH blade session 2). Goal: "keep producing through the freeze; never restart a
   blade that might be cracked". The response becomes IEC 61131-3 Structured Text with the sealed de-icing promise
   enforced by the PLC itself; compiled by matiec (the compiler inside OpenPLC/Beremiz) and gcc.

C. INSPECTION DRONE. The blade-inspection mission flown on the real ArduPilot copter code (SITL: real autopilot,
   simulated physics). This found a real bug in v0.16's mission (fixed): see the report.

Tools: PHYSICA_DROPBEAR8, PHYSICA_KLIPPER, PHYSICA_MATIEC, PHYSICA_ARDUPILOT. A missing tool is reported as not run.
"""
from __future__ import annotations

import json
import os
import sys
from collections import Counter
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from physica.act import turbine  # noqa: E402
from physica.data.dropbear import MM_PER_VOLT_D8  # noqa: E402
from physica.outcome import check, plan  # noqa: E402
from physica.outcome.compile import gcode, plc, remote  # noqa: E402
from physica.outcome.promise import grade, seal_promise  # noqa: E402
from physica.outcome.spec import OutcomeSpec, parse_goal  # noqa: E402
from physica.outcome.worlds.beam import BeamWorld, presets, tone_points  # noqa: E402

OUT = ROOT / "eval" / "results"
CODE = OUT / "outcome"
STEPPER_MM_PER_STEP = 8.0 / (200 * 16)  # rotation_distance 8 mm, 200 full steps, 16 microsteps


def beam_part(points: np.ndarray) -> dict:
    learn = points[points["group"] == "sweep"]
    test = points[(points["group"] == "random") & np.isfinite(points["tone_hz"])]
    world = BeamWorld.learn(learn)
    grid = presets(points[points["group"] == "random"])
    rec_at = {float(v): test["tone_hz"][np.abs(test["pin_v"] - v) <= 0.02] for v in grid}
    pol = {k: Counter() for k in ("physica", "no_error_bar", "far_end")}
    rows, moves, examples, seals_held, seals_total = [], {k: [] for k in pol}, [], 0, 0
    goal_ok = {k: [] for k in pol}
    by_status = {k: {} for k in pol}
    act_moves = {k: [] for k in pol}
    seals_by_anchor = {}
    for F in np.arange(25.0, 42.01, 0.5):
        text = f"A pump beside this beam runs at {F:g} Hz. Keep the beam's tone at least 5% away from it and move the support as little as possible."
        spec = parse_goal(text, "beam", live=False)
        lo_b, hi_b = F * 0.95, F * 1.05
        for v0 in grid:
            state = {"support_v": float(v0), "presets": grid}
            for name in ("physica", "no_error_bar", "far_end"):
                if name == "far_end":
                    far = grid[-1] if abs(world.predict(grid[-1])["tone_hz"] - F) > abs(world.predict(grid[0])["tone_hz"] - F) else grid[0]
                    target, status, pred = float(far), "act", world.predict(float(far))
                else:
                    p = plan(spec, world, state, use_error_bar=(name == "physica"))
                    status = p.status
                    if status == "no action meets the goal":
                        pol[name]["refused (no setting meets the goal)"] += 1
                        continue
                    target = float(v0) if p.action is None else p.action["support_v"]
                    pred = p.predicted
                pol[name][status] += 1
                felt = rec_at.get(target, np.array([]))
                if not len(felt):
                    pol[name]["uncheckable"] += 1
                    continue
                outside = (felt < lo_b) | (felt > hi_b)
                pol[name]["recordings"] += len(felt)
                pol[name]["recordings_outside_band"] += int(outside.sum())
                goal_ok[name].append(bool(outside.all()))
                by_status[name].setdefault(status, []).append(bool(outside.all()))
                moves[name].append(abs(target - v0) * MM_PER_VOLT_D8)
                if status == "act":
                    act_moves[name].append(abs(target - v0) * MM_PER_VOLT_D8)
                if name == "physica":
                    s = seal_promise("tone_hz", pred["lo"], pred["hi"], "beam tone after the support move",
                                     forcing_hz=float(F), support_mm=round(target * MM_PER_VOLT_D8, 2))
                    for f in felt:
                        g = grade(s, "tone_hz", float(f))
                        seals_total += 1
                        seals_held += int(g["held"])
                    want = {27.0, 31.0, 34.0, 38.0} - {e["forcing_hz"] for e in examples}
                    if status == "act" and float(F) in want and len(examples) < 4:
                        seals_by_anchor[s["anchor"]] = s
                        examples.append({"forcing_hz": float(F), "goal": text, "from_mm": round(v0 * MM_PER_VOLT_D8, 1),
                                         "to_mm": round(target * MM_PER_VOLT_D8, 1), "say": p.say,
                                         "sealed": [round(pred["lo"], 2), round(pred["hi"], 2)], "anchor": s["anchor"],
                                         "felt_hz": [round(float(x), 2) for x in felt[:8]],
                                         "all_outside_danger_band": bool(outside.all())})
    summary = {}
    for k, c in pol.items():
        n = c["recordings"]
        summary[k] = {**dict(c), "share_of_recordings_outside_band": round(c["recordings_outside_band"] / max(n, 1), 4),
                      "goals_graded": len(goal_ok[k]), "goals_met_on_every_recording": round(float(np.mean(goal_ok[k])), 4) if goal_ok[k] else None,
                      "mean_move_mm": round(float(np.mean(moves[k])), 1) if moves[k] else None,
                      "mean_move_mm_when_acting": round(float(np.mean(act_moves[k])), 1) if act_moves[k] else None,
                      "goals_met_by_status": {st: [int(sum(v)), len(v)] for st, v in by_status[k].items()}}
    summary["physica"]["sealed_promise_checks"] = seals_total
    summary["physica"]["sealed_promises_held"] = round(seals_held / max(seals_total, 1), 4)
    # one plan written as machine code and run through real Klipper; plus a move outside the felt range
    lo_mm, hi_mm = world.v_range[0] * MM_PER_VOLT_D8, world.v_range[1] * MM_PER_VOLT_D8
    cfg = gcode.klipper_config(lo_mm, hi_mm)
    ex = next(e for e in examples if e["forcing_hz"] == 31.0)
    v0, v1 = ex["from_mm"] / MM_PER_VOLT_D8, ex["to_mm"] / MM_PER_VOLT_D8
    s = seals_by_anchor[ex["anchor"]]
    mv = gcode.klipper_move(ex["from_mm"], ex["to_mm"], s["anchor"])
    CODE.mkdir(parents=True, exist_ok=True)
    (CODE / "support_actuator.cfg").write_text(cfg)
    (CODE / "support_move.gcode").write_text(mv)
    (CODE / "support_move_grbl.gcode").write_text(gcode.grbl_move(ex["from_mm"], ex["to_mm"], s["anchor"]))
    (CODE / "support_move.promise.json").write_text(json.dumps(s, indent=1))
    k_ok = check.klipper(cfg, mv, expect_mm=ex["to_mm"] - ex["from_mm"], mm_per_step=STEPPER_MM_PER_STEP)
    k_bad = check.klipper(cfg, gcode.klipper_move(ex["from_mm"], hi_mm + 20, "outside-felt-range"),
                          mm_per_step=STEPPER_MM_PER_STEP)
    hw = {round(v, 2): round(world.half_width(v), 2) for v in (1.25, 1.5, 2.0, 2.5, 3.0, 3.3)}
    return {"LABEL": "REAL DATA: DROPBEAR Dataset-8; map learned on 2022-07-19 sweep, graded on 2022-06-06 random-position trials",
            "map": {"points_learned": int(np.isfinite(learn["tone_hz"]).sum()), "points_dropped_sensors_disagree":
                    int((~np.isfinite(learn["tone_hz"])).sum()), "felt_range_mm": [round(lo_mm, 1), round(hi_mm, 1)],
                    "error_bar_half_width_hz_by_volts": hw, "presets": len(grid)},
            "goals": {"forcing_hz": [25.0, 42.0, 0.5], "margin_pct": 5, "starts": len(grid)},
            "policies": summary, "examples": examples,
            "machine_code": {"klipper_plan": k_ok, "klipper_move_outside_felt_range": k_bad,
                             "files": ["support_actuator.cfg", "support_move.gcode", "support_move_grbl.gcode",
                                       "support_move.promise.json"]}}


def turbine_part() -> dict:
    from scipy import stats
    from physica.outcome.contract import turbine_never
    e20 = json.loads((OUT / "E20_wind_blade.json").read_text())
    thr = float(stats.chi2.ppf(1 - 1e-3, 7))
    spec = parse_goal("Keep WTG-07 producing through tonight's freeze at -10 C for 12 hours; never restart a blade that "
                      "might be cracked.", "turbine", live=False)
    contract = turbine_never(spec, OUT / "E20_wind_blade.json")
    act = {"weather only": "run", "ice": "pause, heat, then resume only if the sealed promise holds"}
    table = {}
    for r in e20["rows"]:
        a = act.get(r["verdict"], "brake and send the drone")
        table.setdefault(r["truth"], Counter())[a] += 1
    s = seal_promise("change_score", 0.0, thr, "after de-icing the blade feels like itself", turbine="WTG-07")
    st = plc.blade_guard(thr, s["anchor"])
    CODE.mkdir(parents=True, exist_ok=True)
    (CODE / "blade_guard.st").write_text(st)
    # the PLC logic, scan by scan, on the four real cracks that looked like ice: heating does not fix a crack
    sim = plc.simulate([1, 1, 1, 1, 1, 1], [3100] * 6, int(round(thr * 100)))
    return {"LABEL": "REAL VERDICTS from E20 (ETH blade, session 2); PLC compiled by real matiec + gcc",
            "goal": spec.to_json(), "contract": contract,
            "note": "The 'never' goal is refused as a promise: the logic below is review-only and states the measured risk.",
            "actions_by_truth": {k: dict(v) for k, v in table.items()},
            "act_refeel_from_E20": e20["act_refeel"],
            "plc": {"file": "blade_guard.st", "promise_threshold": round(thr, 2), "anchor": s["anchor"],
                    "crack_misread_as_ice_scan_by_scan": [x["state"] for x in sim],
                    "compile": check.matiec(st)}}


def plot_track(track, tower, closest):
    import math
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    lat0, lon0 = tower
    x = [(lo - lon0) * 111_320.0 * math.cos(math.radians(lat0)) for _, lo, _ in track]
    y = [(la - lat0) * 111_320.0 for la, _, _ in track]
    d = [math.hypot(a, b) for a, b in zip(x, y)]
    z = [a for _, _, a in track]
    fig, ax = plt.subplots(figsize=(5.2, 5.6), dpi=130)
    fig.patch.set_facecolor("#0b1118")
    ax.set_facecolor("#0b1118")
    ax.plot([0, 0], [0, 58.5], color="#8aa0b2", lw=6, solid_capstyle="butt", label="tower")
    ax.plot([0.6, 0.6], [28.5, 58.5], color="#f2b84b", lw=3, label="parked blade (30 m)")
    ax.plot(d, z, color="#4fe3c1", lw=2, label="flown by ArduPilot (SITL)")
    ax.axvline(12, color="#4fe3c1", ls=":", lw=1)
    ax.set_xlim(-3, 20)
    ax.set_xlabel("horizontal distance from the tower (m)", color="#cfe0ec")
    ax.set_ylabel("height (m)", color="#cfe0ec")
    ax.tick_params(colors="#cfe0ec")
    for sp in ax.spines.values():
        sp.set_color("#2a3a48")
    ax.set_title(f"Inspection mission flown on real autopilot code\nclosest to the blade: {closest} m", color="#e8f1f8", fontsize=10)
    ax.legend(facecolor="#0b1118", edgecolor="#2a3a48", labelcolor="#cfe0ec", fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(CODE / "sitl_track.png", facecolor=fig.get_facecolor())
    plt.close(fig)


def drone_part() -> dict:
    lat, lon = 56.2, 9.5
    w = turbine.inspection_mission(lat, lon, 90.0, hub_height_m=60, blade_length_m=30, standoff_m=12, step_m=4)
    (CODE / "blade_inspection.waypoints").write_text(w)
    h = w.splitlines()[1].split("\t")
    fly = check.ardupilot_sitl(w, (float(h[8]), float(h[9]), 0, 90), tower=(lat, lon), speedup=10, timeout_s=300)
    track = fly.pop("track", None)
    if track:
        (CODE / "sitl_track.json").write_text(json.dumps(track))
        plot_track(track, (lat, lon), fly.get("closest_to_blade_line_m"))
    return {"LABEL": "Real ArduPilot copter code (SITL: real autopilot, simulated physics)",
            "mission": "blade_inspection.waypoints", "pymavlink": check.mavlink_mission(w), "flight": fly,
            "bug_found_in_v016": ("v0.16 ended the mission with RTL and put home at the tower base. Flown on ArduPilot, "
                                  "RTL brought the drone straight back to the tower and down past the blade tip "
                                  "(closest horizontal approach 0.0 m while above 15 m). v0.17 launches and lands at "
                                  "the stand-off point instead; flown again, closest approach is the stand-off.")}


def main():
    pts = tone_points(cache=os.environ.get("PHYSICA_D8_CACHE", str(Path.home() / ".cache" / "physica" / "d8_points.npz")))
    res = {"A_beam": beam_part(pts), "B_turbine": turbine_part(), "C_drone": drone_part()}
    probe = {"kp": 0.2, "kd": 0.01}
    (CODE / "run_cloudpendulum.py").write_text(remote.cloudpendulum_script(
        "Make the remote lab motor reach 1 rad within 0.6 s with less than 5% overshoot", 1.0, probe))
    res["D_remote_lab"] = {"file": "run_cloudpendulum.py", "status": "written, not run: needs a CloudPendulum account "
                           "approved by Chalmers (pycloudpendulum client)."}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "E23_program_by_outcome.json").write_text(json.dumps(res, indent=1, default=float))
    b = res["A_beam"]["policies"]
    print(json.dumps({k: {kk: b[k].get(kk) for kk in ("act", "already meets the goal", "refused (no setting meets the goal)",
                                                       "recordings", "share_of_recordings_outside_band",
                                                       "goals_met_on_every_recording", "mean_move_mm",
                                                       "sealed_promises_held")} for k in b}, indent=1))
    print("klipper:", {k: res["A_beam"]["machine_code"]["klipper_plan"].get(k) for k in ("passed", "moved_mm", "expected_mm")},
          "| outside range:", res["A_beam"]["machine_code"]["klipper_move_outside_felt_range"].get("errors"))
    print("plc:", res["B_turbine"]["plc"]["compile"]["passed"], res["B_turbine"]["actions_by_truth"])
    print("drone:", {k: res["C_drone"]["flight"].get(k) for k in ("passed", "waypoints_reached", "closest_to_blade_line_m", "max_alt_m")})


if __name__ == "__main__":
    main()
