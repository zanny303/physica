"""Meta Muse contextual map: suggestions only, never an inferred physical measurement."""
from __future__ import annotations
import json
import math

_ALLOWED=('observed_body','stationary_reference','restraint_hypothesis','unknown')


def propose_map(twin, *, allow_billed=False):
    if not allow_billed:
        raise PermissionError('This request requires explicit approval for potentially billed Muse inference')
    if twin.get('status')=='ABSTAIN_UNSUPPORTED' or not twin.get('measurement',{}).get('trace'):
        raise ValueError('No interpretable evidence; Muse cannot make a physical map from empty data')
    import os
    if not os.environ.get('MODEL_API_KEY') or os.environ.get('MOCK')!='0':
        raise PermissionError('MODEL_API_KEY and MOCK=0 are required for authenticated Meta inference')
    from physica.llm.meta_client import complete
    m=twin['measurement']; source=twin['evidence']
    summary={'modality':source.get('modality'),'length_unit':source.get('length_unit'),
       'duration_s':source.get('duration_s'),'n_samples':source.get('n_samples'),
       'dominant_frequency_hz':m.get('dominant_frequency_hz'), 'amplitude':m.get('amplitude'),
       'sensor_signal':source.get('signal'),
       'model_available':bool(twin.get('model')),
       'model_family':twin.get('model',{}).get('family') if twin.get('model') else None,
       'controlled_input_logged':bool((twin.get('model') or {}).get('action_logged_and_variable')),
       'known_limits':twin.get('limits',[])[:5]}
    messages=[{'role':'system','content':('You are an assistant to a human investigator. Provide only hypotheses grounded in available motion and input measurements. '
       'You cannot see the original raw video here, cannot confirm unseen components or failure thresholds, and must not give hardware control or dangerous repair instructions. '
       'Return a JSON object with keys: hypotheses (array of 1 to 3 objects, each has label, evidence_needed, and reason), '
       'scene_annotations (array of exactly 3 objects with node_id: frame,body,restraint and text), uncertainty, suggested_safe_measurement. '
       'Treat frame and body as observed/assumed; restraint is always HYPOTHESIZED. Keep text concise.')},
       {'role':'user','content':json.dumps(summary,allow_nan=False)}]
    r=complete('spark',messages,'twin_map_v0212',max_completion_tokens=950,
       response_format={'type':'json_object'})
    if r['mode'] not in ('live','replay of live'):
        raise RuntimeError('Meta request was not authenticated live or a verified live replay')
    text=(r.get('content') or '').strip()
    try:result=json.loads(text)
    except (ValueError,TypeError) as e:raise ValueError('Muse response was not valid JSON') from e
    if not isinstance(result,dict):raise ValueError('Muse response was not a JSON object')
    hypos=result.get('hypotheses')
    if not isinstance(hypos,list) or not (1<=len(hypos)<=3):
        raise ValueError('Muse proposals must be 1–3 explicitly testable hypotheses')
    clean=[]
    for h in hypos:
        if not isinstance(h,dict) or not all(isinstance(h.get(k),str) and 2<=len(h[k])<=250 for k in ('label','evidence_needed','reason')):
            raise ValueError('Bad proposed hypothesis schema')
        clean.append({k:h[k] for k in ('label','reason','evidence_needed')})
    raw_annotations=result.get('scene_annotations')
    if not isinstance(raw_annotations,list):raise ValueError('Muse scene annotations missing')
    ann={}
    for item in raw_annotations:
        if not isinstance(item,dict) or item.get('node_id') not in ('frame','body','restraint') or not isinstance(item.get('text'),str) or len(item['text'])>120:raise ValueError('Bad scene annotation')
        if item['node_id'] in ann:raise ValueError('Duplicate annotation')
        ann[item['node_id']]=item['text']
    if len(ann)!=3:raise ValueError('Muse must annotate only the three permitted diagram nodes')
    return {'status':'MUSE_SUGGESTIONS_NOT_VERIFIED','model':r.get('model'),'call_origin':r['mode'],
       'diagram_annotations':ann,'candidate_hypotheses':clean,
       'uncertainty':str(result.get('uncertainty') or 'Requires physical verification')[:300],
       'safe_next_measurement':str(result.get('suggested_safe_measurement') or twin['next_measurement'])[:300],
       'proven_physics':False,'permitted_to_control_hardware':False,
       'evidence_sha256':twin['evidence']['sha256']}
