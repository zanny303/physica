"""Follow a body's tone while the world changes it (a support sliding, a mass moving, a crack growing).

Each short window is identified with ESPRIT (a subspace method: the poles that best explain the window, not FFT
bins), then a continuity tracker picks one pole per window, preferring strong, lightly damped poles and small
relative jumps. Live mode decides each window a fixed lag later (half a second by default) from the past only;
offline mode smooths over the whole recording (Viterbi).
"""
from __future__ import annotations

import numpy as np
from scipy import signal


def esprit(x: np.ndarray, fs: float, order: int = 20, rows: int | None = None):
    """Frequencies (Hz), damping ratios and amplitudes of the damped sinusoids that best explain x."""
    x = np.asarray(x, float) - np.mean(x)
    L = rows or len(x) // 3
    H = np.lib.stride_tricks.sliding_window_view(x, L)
    U, _, _ = np.linalg.svd(H.T, full_matrices=False)
    Us = U[:, :order]
    Phi = np.linalg.lstsq(Us[:-1], Us[1:], rcond=None)[0]
    z = np.linalg.eigvals(Phi)
    f = np.angle(z) * fs / (2 * np.pi)
    keep = f > 0.5
    z, f = z[keep], f[keep]
    d = -np.log(np.abs(z)) * fs
    V = np.exp(np.outer(np.arange(len(x)), np.log(z)))
    a = np.linalg.lstsq(np.c_[V, V.conj()], x.astype(complex), rcond=None)[0][:len(z)]
    return f, d / (2 * np.pi * f), np.abs(a)


def decimate_to(x: np.ndarray, fs: float, target: float, causal: bool = False) -> tuple[np.ndarray, float]:
    q = int(max(round(fs / target), 1))
    y, done = np.asarray(x, float), 1
    for s in (8, 5, 4, 3, 2):
        while q % s == 0 and q > 1:
            y = signal.decimate(y, s, zero_phase=not causal)
            q //= s
            done *= s
    if q > 1:
        y = signal.decimate(y, q, zero_phase=not causal)
        done *= q
    return y, fs / done


def candidates(y, fs, win, hop, band, order=20, max_zeta=0.06):
    n, h = int(win * fs), int(hop * fs)
    T, C = [], []
    for i in range(0, len(y) - n, h):
        f, z, a = esprit(y[i:i + n], fs, order=order)
        k = (f > band[0]) & (f < band[1]) & (z < max_zeta) & (z > -0.005)
        T.append(i / fs + win / 2)
        C.append((f[k], a[k]))
    return np.array(T), C


def follow(C, jump_rel: float = 0.04, miss_cost: float = 3.0, lag: int | None = None):
    """Pick one pole per window. lag=None: smooth over the whole recording (offline Viterbi). lag=k: decide each
    window k windows later (fixed-lag, usable live with k*hop seconds of delay). lag=0: decide immediately."""
    states = []
    for f, a in C:
        if len(f):
            la = np.log(a + 1e-30)
            states.append((np.r_[f, np.nan], np.r_[la.max() - la, miss_cost]))
        else:
            states.append((np.array([np.nan]), np.array([miss_cost])))
    n = len(states)
    if n == 0:
        return np.array([])
    cost = states[0][1].copy()
    back = [None]
    out = np.full(n, np.nan)

    def trace(t_end, j, k):
        for t in range(t_end, t_end - k, -1):
            j = int(back[t][j])
        return j

    for t in range(1, n + 1):
        if lag is not None:
            d = t - 1 - lag
            if d >= 0:
                j = int(cost.argmin())
                out[d] = states[d][0][trace(t - 1, j, lag)]
        if t == n:
            break
        fp, fc, ec = states[t - 1][0], states[t][0], states[t][1]
        with np.errstate(invalid="ignore", divide="ignore"):
            J = (np.abs(np.log(fc[None, :] / fp[:, None])) / jump_rel) ** 2
        J = np.where(np.isnan(J), 0.5, J)
        tot = cost[:, None] + J
        bi = tot.argmin(0)
        cost = tot[bi, np.arange(len(fc))] + ec
        back.append(bi)
    j = int(cost.argmin())
    path = [j]
    for t in range(n - 1, 0, -1):
        j = int(back[t][j])
        path.append(j)
    path = path[::-1]
    smooth = np.array([states[t][0][path[t]] for t in range(n)])
    if lag is None:
        return smooth
    tail = max(n - lag, 0)
    out[tail:] = smooth[tail:]  # the last `lag` windows: best guess so far
    return out


def track_tone(x, fs, band, win: float = 0.3, hop: float = 0.05, lag_s: float | None = 0.5,
               target_fs: float | None = None):
    """Times (window centres, s) and the followed tone (Hz, NaN where none) inside `band`.
    lag_s=None: offline (filters and decisions may look ahead). Otherwise live: causal filters, and each window is
    decided lag_s seconds later, so an answer about time t is available at t + win/2 + lag_s."""
    causal = lag_s is not None
    target_fs = target_fs or max(4 * band[1], 400.0)
    y, f2 = decimate_to(x, fs, target_fs, causal=causal)
    hi = min(band[1] * 1.2, f2 * 0.45)
    sos = signal.butter(4, [band[0] * 0.8, hi], "bandpass", fs=f2, output="sos")
    y = signal.sosfilt(sos, y) if causal else signal.sosfiltfilt(sos, y)
    T, C = candidates(y, f2, win, hop, band)
    return T, follow(C, lag=None if lag_s is None else int(round(lag_s / hop)))
