"""Clip: a remote turbine. Cold fools the old alarm, hidden ice gets weighed, a crack can't sneak through, a drone is sent."""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np

from . import style as S

ROOT = Path(__file__).resolve().parents[2] / "eval" / "results"
LABEL_LAB = "REAL LAB DATA · ETH Zurich blade, -15 to +40 °C"


def _load() -> dict:
    e = json.loads((ROOT / "E20_wind_blade.json").read_text())
    g = json.loads((ROOT / "E20b_blade_groups.json").read_text())
    track = np.array(json.loads((ROOT / "outcome" / "sitl_track.json").read_text()))
    east = (track[:, 1] - 9.5) * 111_320.0 * math.cos(math.radians(56.2))
    north = (track[:, 0] - 56.2) * 111_320.0
    healthy = sorted((x for x in g["groups"] if x["truth"] == "healthy"), key=lambda x: x["temp_c"])
    return {"e": e, "g": g, "healthy": healthy, "east": east, "north": north, "alt": track[:, 2]}


def _turbine(ax, t, colour=S.TEAL, spin=True):
    ax.set_xlim(-1.25, 1.25)
    ax.set_ylim(-1.5, 1.2)
    ax.set_aspect("equal")
    ax.plot([0, 0], [-1.5, 0], color="#5c7286", lw=7, solid_capstyle="round")
    a0 = (t * 0.9 if spin else 0.0)
    for k in range(3):
        a = a0 + k * 2 * math.pi / 3
        ax.plot([0, math.cos(a)], [0, math.sin(a)], color=colour, lw=9, solid_capstyle="round")
    ax.plot(0, 0, "o", ms=20, color="#c7d5e1")


def scene_cold(fig, d, t):
    S.headline(fig, "Cold makes a healthy blade look broken")
    S.label(fig, LABEL_LAB)
    n = len(d["healthy"])
    shown = int(S.ease(t / 7.5) * n)
    temp_now = d["healthy"][max(shown - 1, 0)]["temp_c"]
    ax = S.axes(fig, [0.0, 0.14, 0.26, 0.76], off=True)
    _turbine(ax, t)
    fig.text(0.13, 0.13, f"{temp_now:+d} °C", color=S.FG, fontsize=40, fontweight="bold", ha="center", va="center")
    ax = S.axes(fig, [0.31, 0.17, 0.4, 0.68])
    ref = d["g"]["tone1_at_20c"]
    temps = [int(k) for k in d["g"]["tone1_law_hz_by_temp_c"]]
    ax.fill_between([-17, 42], ref * .98, ref * 1.02, color="#1c2c3a")
    ax.text(41, ref * 1.0, "old alarm's safe band", color=S.DIM, fontsize=15, ha="right", va="center")
    ax.plot(temps, list(d["g"]["tone1_law_hz_by_temp_c"].values()), color=S.TEAL, lw=2.5, alpha=S.fade(t, 2.0), label="law it learned")
    for x in d["healthy"][:shown]:
        false_alarm = x["verdict"] != "weather only"
        ax.plot(x["temp_c"] + (hash(x["tone1_hz"]) % 7 - 3) * .22, x["tone1_hz"], "o", ms=11, mfc=S.AMBER if false_alarm else "none", mec=S.FG, mew=1.4)
    ax.set_xlabel("blade temperature (°C)")
    ax.set_ylabel("lowest tone tracked (Hz)")
    ax.set_xlim(-17, 42)
    shown_rows = d["healthy"][:shown]
    old = sum(x["old_alarm"] for x in shown_rows)
    phy = sum(x["verdict"] != "weather only" for x in shown_rows)
    fig.text(0.76, 0.82, "FALSE ALARMS, HEALTHY BLADE", color=S.DIM, fontsize=17, fontweight="bold")
    fig.text(0.76, 0.70, f"{old}", color=S.RED, fontsize=96, fontweight="bold", va="center")
    fig.text(0.76, 0.615, f"of {shown or n} checks · old temperature-blind alarm", color=S.FG, fontsize=14)
    fig.text(0.76, 0.46, f"{phy}", color=S.TEAL, fontsize=96, fontweight="bold", va="center")
    fig.text(0.76, 0.375, f"of {shown or n} checks · with feel", color=S.FG, fontsize=15)
    fig.text(0.76, 0.27, "Every false alarm is a stop\nor a trip up the tower.", color=S.DIM, fontsize=20, alpha=S.fade(t, 7.5), va="top")
    S.caption(fig, "The old alarm is any tone more than 2% from its +20 °C value. Filled dots are false alarms. Learned from an earlier session, tested on a later one.", S.fade(t, 3.0))


def scene_ice(fig, d, t):
    e = d["e"]["score"]
    S.headline(fig, "Then a hidden mass goes on the blade")
    S.label(fig, LABEL_LAB + " · added masses")
    rows = [("A", 44), ("B", 88), ("C", 132)]
    groups = d["g"]["groups"]
    ax = S.axes(fig, [0.1, 0.3, 0.6, 0.53])
    ax.set_xlim(0, 180)
    ax.set_ylim(-0.6, 2.6)
    ax.set_yticks([2, 1, 0], ["44 g", "88 g", "132 g"], fontsize=24, color=S.FG)
    ax.set_xlabel("grams")
    for i, (c, true_g) in enumerate(rows):
        y = 2 - i
        al = S.fade(t, 0.3 + i * 1.0)
        g = [x["ice_grams"] for x in groups if x["case"] == c and x["verdict"] == "ice"]
        n = sum(1 for x in groups if x["case"] == c)
        med = float(np.median(g))
        ax.barh(y + .18, true_g * al, height=.28, color="#3b5266")
        ax.barh(y - .18, med * al, height=.28, color=S.TEAL)
        if len(g) > 1:
            ax.plot([min(g), max(g)], [y - .18, y - .18], color=S.FG, lw=2.2, alpha=al)
        ax.text(min(true_g, 175) * al + 2, y + .18, "true added mass", color=S.DIM, fontsize=15, va="center", alpha=al)
        word = f"felt {med:.0f} g" + (f" (range {min(g):.0f} to {max(g):.0f})" if len(g) > 1 else "")
        ax.text(max(g) + 2, y - .18, f"{word} · called ice {len(g)} of {n}", color=S.FG, fontsize=16, va="center", alpha=al, clip_on=False)
    a = S.fade(t, 3.8)
    fig.text(0.5, 0.17, f"{e['ice_called_ice']} of {e['ice_groups']} checks called it ice.  {e['ice_sent_to_inspection']} sent someone to look.  10 passed as weather.", color=S.AMBER, fontsize=26, ha="center", fontweight="bold", alpha=a)


def scene_crack(fig, d, t):
    conf = d["e"]["score"]["confusion"]["crack"]
    S.headline(fig, "A crack can't hide behind the word “ice”")
    S.label(fig, "REPLAY · heating is replayed from lab data, no real heater")
    total = sum(conf.values())
    ax = S.axes(fig, [0.06, 0.62, 0.88, 0.17], off=True)
    ax.set_xlim(0, total)
    ax.set_ylim(0, 1)
    x = 0
    colours = {"crack": S.TEAL, "structural": "#2fa98f", "can't tell": "#55708a", "ice": S.AMBER, "weather only": S.RED}
    grow = S.ease(t / 1.2)
    for k in ("crack", "structural", "can't tell", "ice", "weather only"):
        v = conf.get(k, 0)
        ax.barh(.5, v * grow, left=x * grow, height=.9, color=colours[k])
        if grow > .95:
            ax.text(x + v / 2, .5, f"{v}" if v < 12 else f"{v} {k}", ha="center", va="center", color=S.BG, fontsize=20, fontweight="bold")
        x += v
    fig.text(0.06, 0.83, f"{total} real checks of a cracked blade", color=S.DIM, fontsize=20)
    fig.text(0.62, 0.565, f"{conf.get('can' + chr(39) + 't tell', 0)} can't tell", color="#8aa0b4", fontsize=20, alpha=S.fade(t, 1.3), ha="right")
    fig.text(0.76, 0.565, f"{conf.get('ice', 0)} called ice", color=S.AMBER, fontsize=20, alpha=S.fade(t, 1.3), ha="right")
    fig.text(0.94, 0.565, f"{conf.get('weather only', 0)} passed as weather", color=S.RED, fontsize=20, alpha=S.fade(t, 1.3), ha="right")
    steps = [("1", "A promise is sealed before heating", "“Once the ice is gone, every tone returns to this blade's law.”"),
             ("2", "Heat the blade, then feel it again", "Ice melts away. A crack is still there."),
             ("3", "Promise broken means it was never ice", "Stop. Don't restart. Send an inspection.")]
    for i, (n, a, b) in enumerate(steps):
        al = S.fade(t, 1.8 + i * 1.0)
        y = 0.45 - i * 0.125
        fig.text(0.07, y, n, color=S.TEAL, fontsize=44, fontweight="bold", alpha=al, va="center")
        fig.text(0.11, y + .018, a, color=S.FG, fontsize=26, fontweight="bold", alpha=al, va="center")
        fig.text(0.11, y - .026, b, color=S.DIM, fontsize=20, alpha=al, va="center")
    S.caption(fig, f"In this replay, all {d['e']['act_refeel']['crack_called_ice']} cracks called ice broke the promise, and none restarted. {conf.get('weather only', 0)} cracks still passed as weather, so this doesn't replace inspection.", S.fade(t, 4.5))


def scene_drone(fig, d, t):
    import matplotlib.pyplot as plt  # noqa: F401
    from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
    S.headline(fig, "Nobody climbs. A drone goes first.")
    S.label(fig, "REAL ARDUPILOT CODE, IN ITS SIMULATOR · no real drone")
    ax = fig.add_axes([0.0, 0.03, 0.62, 0.9], projection="3d")
    ax.set_facecolor(S.BG)
    ax.set_axis_off()
    ax.set_box_aspect((1, 1, 1.15))
    ax.view_init(elev=8, azim=-58 + t * 1.5)
    ax.plot([0, 0], [0, 0], [0, 60], color="#6b8195", lw=6)
    for a in (-90, 30, 150):
        r = math.radians(a)
        col = S.AMBER if a == -90 else "#8fa6ba"
        ax.plot([0, 0], [0, 30 * math.cos(r)], [60, 60 + 30 * math.sin(r)], color=col, lw=6 if a == -90 else 4)
    p = S.ease(t / 8.5)
    n = len(d["alt"])
    i = max(int(p * (n - 1)), 1)
    ax.plot(d["east"][:i], d["north"][:i], d["alt"][:i], color=S.TEAL, lw=2.5)
    ax.plot([d["east"][i]], [d["north"][i]], [d["alt"][i]], "o", ms=12, color=S.TEAL)
    if 30 < d["alt"][i] < 59:
        ax.plot([d["east"][i], 0], [d["north"][i], 0], [d["alt"][i], d["alt"][i]], color=S.TEAL, lw=1, alpha=.5, ls="--")
    top = int(np.argmax(d["alt"]))
    for stop in np.arange(58.5, 30, -4.0) - 1.5:      # photo stops on the blade, lit once the drone has passed them
        passed = i > top and d["alt"][i] <= stop + 1.5
        ax.plot([0], [0], [stop], "o", ms=9, color=S.TEAL if passed else "#39505f", zorder=9)
    ax.set_xlim(-30, 30)
    ax.set_ylim(-30, 30)
    ax.set_zlim(0, 92)
    fig.text(0.63, 0.80, "WHAT IT WROTE", color=S.DIM, fontsize=18, fontweight="bold")
    for k, (a, b) in enumerate((("Stop the turbine", "park the suspect blade straight down"), ("Inspection mission", "12 m from the blade, a photo every 4 m"),
                                ("A person approves", "Nothing moves until they do"))):
        y = 0.71 - k * 0.135
        al = S.fade(t, 0.4 + k * 0.8)
        fig.text(0.63, y, a, color=S.TEAL, fontsize=31, fontweight="bold", alpha=al, va="center")
        fig.text(0.63, y - 0.045, b, color=S.FG, fontsize=19, alpha=al, va="center")
    fig.text(0.63, 0.30, f"altitude {d['alt'][i]:.1f} m", color=S.FG, fontsize=30, va="center", family="monospace")
    S.caption(fig, "Flown on ArduPilot's own flight code in simulation, with a 60 m hub and a 30 m blade.", S.fade(t, 3.0), width=100)


def render(out: str | Path, short: bool = False) -> str:
    d = _load()
    scenes = [(scene_cold, 8.0), (scene_ice, 5.5), (scene_drone, 7.5)] if short else [(scene_cold, 10.0), (scene_ice, 7.0), (scene_crack, 8.5), (scene_drone, 10.0)]

    def draw(fig, t):
        for fn, length in scenes:
            if t < length:
                return fn(fig, d, t)
            t -= length
    return S.render(out, draw, sum(x for _, x in scenes))
